export enum ViewMode {
  Graph = "graph",
  Tree = "tree",
}
