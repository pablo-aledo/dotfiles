/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: "https://jsoncrack.com",
  exclude: ["/widget"],
  autoLastmod: false,
  changefreq: "never",
};
