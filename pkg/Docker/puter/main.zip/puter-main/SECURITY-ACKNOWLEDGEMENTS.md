We would like to thank the following security researchers for their responsible disclosures:


# 2024

- Tim Suess: [GitHub](https://github.com/blackfortresslabs) | [Email](tim@blackfortresslabs.com) | [Website](blackfortresslabs.com)
- xyzeva: [Github](https://github.com/xyzeva) | [Email](mailto:xyzeva@riseup.net) | [Website](https://kibty.town/)
