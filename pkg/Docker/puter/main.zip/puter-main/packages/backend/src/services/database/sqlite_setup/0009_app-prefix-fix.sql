UPDATE `apps` SET `uid` = 'app-129e4bfb-4c8a-47e0-bec2-0279c21ace06' WHERE `name` = 'phoenix';
