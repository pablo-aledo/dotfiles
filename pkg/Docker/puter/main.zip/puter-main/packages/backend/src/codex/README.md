# What is this?

ChatGPT told me to call this codex and that sounds really cool so
I couldn't resist.

This directory contains utilities for modelling code as data, so that
we can use static analysis techniques and prevent detectable errors
from reaching produciton. This is an attempt at making things more robust,
but it's not guarenteed to work or even be useful; we need to try it and
collect data about its effectiveness.
