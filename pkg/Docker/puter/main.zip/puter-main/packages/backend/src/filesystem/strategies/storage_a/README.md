## Class A Storage Strategies

This is the broadest definition of storage strategies.
This is to allow swapping between the behaviour of the original
Puter storage logic, and Class B storage strategies.

- they know the UID of the file
- they can perform post-operations after the fsentry is inserted
- they can access the Puter database
