<?php

// path where dot-to-ascii stores its data
define('DTA_DATA', '/usr/local/share/dot-to-ascii');

define('DTA_DATA_SHARE',    DTA_DATA.'/share');     // shared diagrams
define('DTA_DATA_REQUESTS', DTA_DATA.'/requests');  // all requests

?>
