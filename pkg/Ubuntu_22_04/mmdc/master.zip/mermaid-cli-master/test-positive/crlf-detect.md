```mermaid
flowchart LR
    test-->diagram
```