# Hello!

This is a *markdown* file that contains no mermaid charts.

```
  def test():
    pass
```

mermaid-cli should not crash while handling this case.
