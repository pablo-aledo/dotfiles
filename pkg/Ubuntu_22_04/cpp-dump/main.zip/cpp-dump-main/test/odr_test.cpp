#include "./odr_test.hpp"

#include "../cpp-dump.hpp"

void odr_test() { cpp_dump(class_a(), class_b(), enum_a::s); }
