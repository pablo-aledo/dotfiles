#!/bin/bash -eu

cd ./test/..

rm -rf ./test/logs
