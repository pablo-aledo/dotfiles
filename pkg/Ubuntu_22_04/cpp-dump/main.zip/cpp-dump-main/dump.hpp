// See https://github.com/philip82148/cpp-dump/pull/100 for details of this file.
#pragma once
#pragma message(                                                                                   \
    "WARNING: The 'dump.hpp' header is deprecated. Include the 'cpp-dump.hpp' header instead."     \
)
#include "./cpp-dump.hpp"
