fn main() -> std::io::Result<()> {
    serie::run()
}
