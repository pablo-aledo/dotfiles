mod views;

mod detail;
mod help;
mod list;
mod refs;

pub use views::*;
