//! Steel-writable decoration stores: inlay hints, gutter signs, virtual
//! lines, end-of-line text, extra highlights, and line backgrounds. Not
//! LSP-specific (any plugin can set them): LSP is their first client, not
//! their owner. Every
//! kind is keyed the same way: `BufferId` first, then a per-buffer
//! `Vec<(source, entries)>`, so unrelated plugins' entries for the same
//! buffer coexist without a cross-buffer scan to find them. See
//! `SourceStore`, generic over the source-key type so `hume-editor`'s `lsp/diagnostics.rs`'s
//! `DiagnosticsStore` (keyed by `ServerId` instead of a plugin-chosen
//! `String`) shares this exact write/remap machinery rather than
//! reimplementing it. Every `scope` field here is an already-interned
//! `ScopeId`, not a name: `hume-editor`'s `host_impl.rs`'s `set-*!` handlers intern the
//! Steel-facing scope string once, at the boundary, so render bridges never
//! resolve a name themselves. Every render provider reads these fresh every
//! frame; `virtual_lines` is the exception: the whole-buffer rebuild (not
//! viewport-filtered, since it also runs in scroll/cursor math) gates on
//! `generation` instead (see that field's doc).

use rustc_hash::FxHashMap;

use hume_core::{BufferId, Side};
use hume_editing::changeset::{Assoc, ChangeSet, PosMapCursor};
use hume_editing::edit::TextChange;
use hume_engine::types::ScopeId;
use hume_rope::line::ContentLine;
use hume_rope::offset::{CharOffset, ExclusiveRange};

/// One `(set-inlay-hints! …)` entry: `text` rendered on `side` of the char
/// at `pos`.
pub struct InlayHintEntry {
    pub pos: CharOffset,
    pub text: String,
    pub side: Side,
}

/// One `(set-signs! …)` entry: a gutter marker on `line`, which remaps
/// through edits as a [`LineAnchored`] kind. No `priority` field: a sign's slot is its *source*'s rank
/// among `DecorationStores::sign_sources`, not a per-entry value; the
/// `source` key `SourceStore` already carries is the entry's whole channel
/// identity. `scope` is interned by `hume-editor`'s `host_impl.rs`'s `set_signs` at the
/// `set-signs!` boundary, not resolved later by a render bridge. `text` is
/// `Arc<str>`, not `String`: `hume-editor`'s `Editor::update_sign_providers` clones it
/// straight into `hume_engine::builtins::sign_column::Sign::text` (also
/// `Arc<str>`) for every visible line, every frame, a refcount bump
/// instead of a fresh allocation per sign per frame.
pub struct SignEntry {
    pub line: ContentLine,
    pub text: std::sync::Arc<str>,
    pub scope: ScopeId,
}

/// One `(set-virtual-lines! …)` entry: a synthetic line of text anchored to
/// `line` (rendered on its `side`), which remaps through edits as a
/// [`LineAnchored`] kind. `content` is the text and the interned scope of
/// each segment of it; `scope` styles the bytes no segment covers.
/// `hume-editor`'s `host_impl/decorations.rs`'s `set_virtual_lines`
/// resolves the `ui.virtual` fallback itself when the Steel call passes no
/// scope, so this field is never optional.
pub struct VirtualLineEntry {
    pub line: ContentLine,
    pub content: hume_rope::spanned::SpannedText<ScopeId>,
    pub side: Side,
    pub scope: ScopeId,
}

/// One `(set-eol-text! …)` entry: `text` appended at the end of `line`,
/// which remaps through edits as a [`LineAnchored`] kind. The diagnostics
/// plugin's
/// per-line summary (`"[n] <message>"` or a bare message) is this kind's
/// first client, not its owner, same as every other kind here is to LSP.
/// `scope` is interned by `hume-editor`'s `host_impl.rs`'s `set_eol_text` at the
/// `set-eol-text!` boundary.
pub struct EolTextEntry {
    pub line: ContentLine,
    pub text: String,
    pub scope: ScopeId,
    /// The render side drops this entry on the line holding the primary
    /// cursor of the pane typing in Insert mode.
    pub hide_on_insert_line: bool,
}

/// One `(set-extra-highlights! …)` entry: a char range styled with `scope`,
/// interned by `hume-editor`'s `host_impl.rs`'s `set_extra_highlights` at the
/// `set-extra-highlights!` boundary.
pub struct ExtraHighlightEntry {
    pub start: CharOffset,
    pub end: CharOffset,
    pub scope: ScopeId,
}

/// One `(set-line-backgrounds! …)` entry: a full-row background tint on
/// `line`, which remaps through edits as a [`LineAnchored`] kind. No
/// `priority` field, same as
/// `SignEntry` now: row tints have no per-line slot contention at all, so
/// same-line entries from different sources simply break ties by source
/// name, never claim a reserved column the way a registered sign source does.
/// `scope` is interned by `hume-editor`'s `host_impl.rs`'s `set_line_backgrounds` at the
/// `set-line-backgrounds!` boundary.
pub struct LineBgEntry {
    pub line: ContentLine,
    pub scope: ScopeId,
}

/// What every entry kind is sorted and searched by: a char offset for a
/// decoration on characters, a line for one on a whole line.
/// [`SourceStore::set`] sorts by it so the remap chokepoint can map a
/// source's entries in one monotone pass.
pub trait Anchored {
    type Anchor: Ord + Copy;
    fn anchor(&self) -> Self::Anchor;
}

impl Anchored for InlayHintEntry {
    type Anchor = CharOffset;
    fn anchor(&self) -> CharOffset {
        self.pos
    }
}

impl Anchored for SignEntry {
    type Anchor = ContentLine;
    fn anchor(&self) -> ContentLine {
        self.line
    }
}

impl Anchored for VirtualLineEntry {
    type Anchor = ContentLine;
    fn anchor(&self) -> ContentLine {
        self.line
    }
}

impl Anchored for EolTextEntry {
    type Anchor = ContentLine;
    fn anchor(&self) -> ContentLine {
        self.line
    }
}

impl Anchored for ExtraHighlightEntry {
    type Anchor = CharOffset;
    fn anchor(&self) -> CharOffset {
        self.start
    }
}

impl Anchored for LineBgEntry {
    type Anchor = ContentLine;
    fn anchor(&self) -> ContentLine {
        self.line
    }
}

/// A kind anchored on a whole line: signs, virtual lines, EOL text and line
/// backgrounds. Drives `SourceStore::remap_lines`.
pub trait LineAnchored: Anchored<Anchor = ContentLine> {
    fn set_line(&mut self, line: ContentLine);
}

impl LineAnchored for SignEntry {
    fn set_line(&mut self, line: ContentLine) {
        self.line = line;
    }
}

impl LineAnchored for VirtualLineEntry {
    fn set_line(&mut self, line: ContentLine) {
        self.line = line;
    }
}

impl LineAnchored for EolTextEntry {
    fn set_line(&mut self, line: ContentLine) {
        self.line = line;
    }
}

impl LineAnchored for LineBgEntry {
    fn set_line(&mut self, line: ContentLine) {
        self.line = line;
    }
}

/// A kind anchored on a char range: extra highlights, and `hume-editor`'s
/// diagnostics. [`Anchored::anchor`] supplies the range's start; this
/// supplies the end. Drives [`SourceStore::remap_ranges`].
pub trait RangeAnchored: Anchored<Anchor = CharOffset> {
    fn end(&self) -> CharOffset;
    fn set_range(&mut self, range: ExclusiveRange<CharOffset>);
}

impl RangeAnchored for ExtraHighlightEntry {
    fn end(&self) -> CharOffset {
        self.end
    }
    fn set_range(&mut self, range: ExclusiveRange<CharOffset>) {
        self.start = range.start;
        self.end = range.end;
    }
}

/// One decoration kind's per-source entries, for every buffer
/// (`FxHashMap<BufferId, Vec<(source, Vec<T>)>>`, kept sorted ascending by
/// `source`; see `set`). Written once, instantiated per kind; the type
/// system carries the per-kind payload differences. Generic over the source
/// key `K` (not just `String`) so `hume-editor`'s `lsp/diagnostics.rs`'s `DiagnosticsStore`
/// (keyed by `ServerId`, otherwise the exact same shape: per-buffer,
/// per-source, wholesale-replace, remap-through-a-`ChangeSet`) can wrap
/// this instead of hand-rolling the same write/remap logic a second time.
pub struct SourceStore<K, T> {
    by_buffer: FxHashMap<BufferId, Vec<(K, Vec<T>)>>,
}

impl<K, T> Default for SourceStore<K, T> {
    fn default() -> Self {
        Self {
            by_buffer: FxHashMap::default(),
        }
    }
}

impl<K, T> SourceStore<K, T> {
    /// Every source's entries for `bid`, grouped (not flattened): the
    /// primitive `for_buffer` and a per-source-structure caller
    /// both build on.
    pub fn groups_for_buffer(&self, bid: BufferId) -> impl Iterator<Item = (&K, &[T])> {
        self.by_buffer
            .get(&bid)
            .into_iter()
            .flat_map(|entry| entry.iter().map(|(k, v)| (k, v.as_slice())))
    }

    /// All entries for `bid`, across every source in ascending source-name
    /// order (see `set`), paired with their source. Signs need the source to
    /// look up its registered slot (`DecorationStores::sign_slot`), not for a
    /// tie-break; two signs from different sources never contend for the
    /// same slot, since each registered source owns its own. Virtual lines and extra highlights (the
    /// two kinds with no per-line collapse) rely on this ascending order
    /// directly, so two sources anchored to the same line render in a
    /// name-deterministic order rather than whichever call `set-*!` happened
    /// to land first this session; every other kind's caller discards it.
    pub fn for_buffer(&self, bid: BufferId) -> impl Iterator<Item = (&K, &T)> {
        self.groups_for_buffer(bid)
            .flat_map(|(k, entries)| entries.iter().map(move |e| (k, e)))
    }

    #[cfg(any(test, feature = "test-util"))]
    fn entries_for<Q>(&self, source: &Q, bid: BufferId) -> &[T]
    where
        K: std::borrow::Borrow<Q>,
        Q: PartialEq + ?Sized,
    {
        self.by_buffer
            .get(&bid)
            .and_then(|entry| entry.iter().find(|(s, _)| s.borrow() == source))
            .map(|(_, v)| v.as_slice())
            .unwrap_or(&[])
    }

    /// Every source's entries for `bid`, mutably: the remap chokepoint's
    /// entry point: it rewrites positions in place per source, one batch
    /// call per source rather than per entry.
    fn sources_mut(&mut self, bid: BufferId) -> impl Iterator<Item = &mut Vec<T>> {
        self.by_buffer
            .get_mut(&bid)
            .into_iter()
            .flat_map(|entry| entry.iter_mut().map(|(_, v)| v))
    }

    /// Drops every entry for `bid`. Returns whether `bid` had an entry to
    /// drop.
    pub fn remove_buffer(&mut self, bid: BufferId) -> bool {
        self.by_buffer.remove(&bid).is_some()
    }

    fn is_empty_for(&self, bid: BufferId) -> bool {
        !self
            .by_buffer
            .get(&bid)
            .is_some_and(|entry| entry.iter().any(|(_, v)| !v.is_empty()))
    }

    /// Drops `source`'s entries for `bid` alone; a buffer left with no
    /// source is forgotten. `false` when `source` had nothing for `bid`.
    pub fn remove_source_for_buffer<Q>(&mut self, source: &Q, bid: BufferId) -> bool
    where
        K: std::borrow::Borrow<Q>,
        Q: PartialEq + ?Sized,
    {
        let Some(entry) = self.by_buffer.get_mut(&bid) else {
            return false;
        };
        let before = entry.len();
        entry.retain(|(k, _)| k.borrow() != source);
        let removed = entry.len() != before;
        if entry.is_empty() {
            self.by_buffer.remove(&bid);
        }
        removed
    }

    /// Every buffer with at least one source registered, of any kind.
    pub fn buffers(&self) -> impl Iterator<Item = BufferId> + '_ {
        self.by_buffer.keys().copied()
    }
}

impl<K, T: Anchored> SourceStore<K, T> {
    /// Every source's entries for `bid` whose anchor falls in `range`,
    /// grouped (not flattened): the anchored counterpart to
    /// [`Self::groups_for_buffer`], and [`Self::in_range`]'s primitive.
    /// [`DecorationStores::signs_in_range`] builds directly on this instead
    /// of `in_range`: it needs each source's *name* once per group (to
    /// resolve that source's registered slot), not once per entry.
    ///
    /// Each source's slice is anchor-sorted (`set`), so both bounds come
    /// from a binary search, so a caller filtering a viewport out of a
    /// buffer-wide store pays for the entries it keeps, not for every entry
    /// the servers published. Bounds both ends by the anchor, so a
    /// range-anchored kind whose span can start before `range` (extra
    /// highlights; `DiagnosticsStore::for_range_unsorted`, which prunes only
    /// the upper bound for exactly this reason) must not build on this.
    pub(in crate::decorations) fn groups_in_range(
        &self,
        bid: BufferId,
        range: ExclusiveRange<T::Anchor>,
    ) -> impl Iterator<Item = (&K, &[T])> {
        self.groups_for_buffer(bid).map(move |(source, es)| {
            let lo = es.partition_point(|e| e.anchor() < range.start);
            let hi = es.partition_point(|e| e.anchor() < range.end);
            (source, &es[lo..hi])
        })
    }

    /// Every source's entries for `bid` whose anchor falls in `range`,
    /// flattened, source discarded. [`Self::groups_in_range`] is the one to
    /// build on instead when a caller needs the source name (e.g.
    /// [`DecorationStores::signs_in_range`], to resolve a group's registered
    /// slot once rather than once per entry).
    pub(in crate::decorations) fn in_range(
        &self,
        bid: BufferId,
        range: ExclusiveRange<T::Anchor>,
    ) -> impl Iterator<Item = &T> {
        self.groups_in_range(bid, range)
            .flat_map(|(_, es)| es.iter())
    }
}

impl<K: Ord, T: Anchored> SourceStore<K, T> {
    /// Replaces `source`'s entries for `bid` wholesale, sorted by anchor (see
    /// `Anchored`'s doc). `slot` itself stays sorted ascending by `source`
    /// (a binary-search insert rather than find-or-push), so
    /// `for_buffer`'s iteration order is deterministic
    /// instead of "whichever source called `set` first this session".
    pub fn set(&mut self, source: K, bid: BufferId, mut entries: Vec<T>) {
        entries.sort_by_key(Anchored::anchor);
        *self.source_entries(source, bid) = entries;
    }

    /// Appends `entries` to `source`'s entries for `bid`, keeping them
    /// sorted by anchor.
    pub fn extend(&mut self, source: K, bid: BufferId, entries: Vec<T>) {
        let existing = self.source_entries(source, bid);
        existing.extend(entries);
        existing.sort_by_key(Anchored::anchor);
    }

    /// `source`'s entries for `bid`, inserted empty at its place in the
    /// ascending source order when absent.
    fn source_entries(&mut self, source: K, bid: BufferId) -> &mut Vec<T> {
        let slot = self.by_buffer.entry(bid).or_default();
        let idx = match slot.binary_search_by(|(s, _)| s.cmp(&source)) {
            Ok(idx) => idx,
            Err(idx) => {
                slot.insert(idx, (source, Vec::new()));
                idx
            }
        };
        &mut slot[idx].1
    }
}

impl<K: Ord, T: LineAnchored> SourceStore<K, T> {
    /// [`Self::set`] for a kind with one entry per line per source: of a
    /// source's entries on one line, the first it lists is kept. Remapping
    /// maps distinct lines to distinct lines, so the rule holds through
    /// edits.
    pub fn set_one_per_line(&mut self, source: K, bid: BufferId, mut entries: Vec<T>) {
        entries.sort_by_key(Anchored::anchor);
        entries.dedup_by_key(|e| e.anchor());
        self.set(source, bid, entries);
    }
}

impl<K, T> SourceStore<K, T> {
    /// Remaps every entry for `bid`, one pass per source through a fresh
    /// `new_cursor()`, handing `map_entry` each entry in anchor order to
    /// reposition in place; it returns `false` to drop the entry. Returns
    /// whether `bid` had any entry to remap, so callers can skip a
    /// dirty-tracking stamp bump when `bid` had nothing for this kind.
    fn remap_each<C>(
        &mut self,
        bid: BufferId,
        new_cursor: impl Fn() -> C,
        mut map_entry: impl FnMut(&mut C, &mut T) -> bool,
    ) -> bool {
        let mut touched = false;
        for entries in self.sources_mut(bid) {
            if entries.is_empty() {
                continue;
            }
            touched = true;
            let mut cursor = new_cursor();
            entries.retain_mut(|entry| map_entry(&mut cursor, entry));
        }
        touched
    }
}

impl<K> SourceStore<K, InlayHintEntry> {
    /// Remaps every inlay hint for `bid` through `cs`. A hint sticks to the
    /// char it annotates rather than swallowing newly typed text
    /// (`Assoc::Before`), and a hint whose char a deletion consumed is
    /// dropped (the policy `remap_ranges` applies to a range a deletion
    /// collapses) instead of reappearing at the deletion point.
    fn remap_points(&mut self, bid: BufferId, cs: &ChangeSet) -> bool {
        self.remap_each(
            bid,
            || PosMapCursor::new(cs.ops()),
            |cursor, hint| {
                let mapped = cursor.map_anchor(hint.pos, Assoc::Before);
                hint.pos = mapped.pos;
                !mapped.anchor_deleted
            },
        )
    }
}

impl<K, T: LineAnchored> SourceStore<K, T> {
    /// Remaps every line-anchored entry for `bid` through `change`. A line is
    /// its `\n`: each content line owns one, so an entry follows
    /// its line's break and is dropped only when a deletion consumes it.
    /// Any edit inside the line keeps the entry; joining a line with the
    /// next drops this line's entries and keeps the next one's, on the
    /// joined line. Text inserted at the break stays after it, so typing at
    /// the line's end or opening a line below leaves the entry on its line.
    fn remap_lines(&mut self, bid: BufferId, change: &TextChange) -> bool {
        self.remap_each(
            bid,
            || change.line_cursor(),
            |cursor, entry| match cursor.map_line(entry.anchor()) {
                Some(line) => {
                    entry.set_line(line);
                    true
                }
                None => false,
            },
        )
    }
}

impl<K, T: RangeAnchored> SourceStore<K, T> {
    /// Remaps every range-anchored entry for `bid` through `cs`, dropping any
    /// range a covering deletion collapsed to zero width. Returns whether
    /// `bid` had any entry to remap, same as `remap_points`. The one other
    /// implementor of this policy before it moved here
    /// (`DiagnosticsStore::remap_through`) was a near-verbatim copy of this
    /// method against `StoredDiag` instead of `ExtraHighlightEntry`; this
    /// generic version now backs both.
    pub fn remap_ranges(&mut self, bid: BufferId, cs: &ChangeSet) -> bool {
        let mut touched = false;
        for spans in self.sources_mut(bid) {
            if spans.is_empty() {
                continue;
            }
            touched = true;
            let mut ranges: Vec<ExclusiveRange<CharOffset>> = spans
                .iter()
                .map(|s| ExclusiveRange::new(s.anchor(), s.end()))
                .collect();
            cs.map_ranges(&mut ranges);
            debug_assert!(
                ranges.windows(2).all(|w| w[0].start <= w[1].start),
                "map_ranges must preserve sort order"
            );
            let mut idx = 0;
            spans.retain_mut(|s| {
                let range = ranges[idx];
                idx += 1;
                if range.end <= range.start {
                    false // collapsed by a covering deletion: drop
                } else {
                    s.set_range(range);
                    true
                }
            });
        }
        touched
    }
}

#[derive(Default)]
pub struct DecorationStores {
    inlay_hints: SourceStore<String, InlayHintEntry>,
    signs: SourceStore<String, SignEntry>,
    virtual_lines: SourceStore<String, VirtualLineEntry>,
    extra_highlights: SourceStore<String, ExtraHighlightEntry>,
    eol_text: SourceStore<String, EolTextEntry>,
    line_backgrounds: SourceStore<String, LineBgEntry>,
    /// Every buffer's registered sign sources, each buffer's list kept
    /// sorted `(priority desc, name asc)`: that order *is* the buffer's
    /// sign-priority ladder (`register_sign_source`/`sign_slot`/
    /// `sign_source_count`). A source claims its slot in one buffer at a
    /// time, the first time it becomes relevant there (a plugin calls
    /// `register-sign-source!` from inside the same function that renders
    /// its signs, e.g. `core:lsp` on first diagnostic placement,
    /// `core:git-diff` on first tracked render), and holds it until the
    /// buffer closes or the source withdraws it
    /// (`unregister_sign_source`). A source that stops having anything to
    /// show still keeps its (now blank) slot via
    /// `(set-signs! pane source '())`, same as any other empty `set-signs!`
    /// call. This is what keeps a buffer neither source ever touches (a
    /// plain buffer with no LSP server and no git repo) from ever reserving
    /// either slot. Not touch-stamped: it isn't decoration content, so no
    /// `generation` bump is the right one when it changes.
    sign_sources: FxHashMap<BufferId, Vec<(String, i64)>>,
    /// Per-buffer dirty-tracking stamp, touched by every `set_*` and
    /// `clear_entries` for that buffer, and by `remap_through` when a remap
    /// actually moved one of that buffer's entries. The virtual-lines
    /// render write side mirrors `virtual_lines` into a per-pane Arc only
    /// when *its buffer's* stamp changed since its last sync, rather than
    /// every frame (unlike inlay hints/EOL text, that sync runs in
    /// scroll/cursor math too, not just render, so avoiding needless
    /// per-frame rebuild work matters more there).
    ///
    /// Per-buffer, not one store-wide counter: `remap_through` runs once per
    /// queued edit for *every* LSP-attached buffer, decorated or not
    /// (`record_lsp_edits`'s gate is `lsp_server.is_some() || has_any(bid)`),
    /// so a single global counter would bump on every keystroke in any
    /// LSP-attached buffer, and the virtual-lines resync skip would never
    /// actually fire while typing. Per-buffer stamps mean typing in one
    /// buffer doesn't invalidate every pane on every other buffer.
    generation: FxHashMap<BufferId, u64>,
    /// Shared source for every buffer's stamp (see `touch`). Not itself a
    /// generation to compare against; `reset` carries it forward so a fresh
    /// store's stamps are guaranteed to never repeat a value any earlier
    /// store in this session ever handed out (see `reset`'s doc).
    clock: u64,
}

impl DecorationStores {
    /// A fresh, empty store, for session start (`prior_clock: 0`) and a
    /// config-reload reset (the outgoing store's `clock()`).
    ///
    /// Carries `prior_clock` forward rather than starting over at `0`: with
    /// a per-buffer stamp map that resets to empty (every buffer defaulting
    /// back to stamp `0`) on every reload, a buffer that goes untouched
    /// across two-or-more reloads could otherwise see the *same* stamp
    /// sequence repeat (`0, 1, 2, …` again), which could coincidentally
    /// equal a pane's already-synced stamp in `hume-editor`'s `Editor::virtual_lines_synced`
    /// left over from before the *first* reload, skipping the sync that
    /// should clear the pane's stale `Arc` of the old virtual lines. A
    /// single ever-increasing clock, carried forward across every reset,
    /// guarantees no stamp value is ever reused for the life of the
    /// session, so that ABA collision can't happen no matter how many
    /// reloads a pane sits out.
    pub fn reset(prior_clock: u64) -> Self {
        Self {
            clock: prior_clock.wrapping_add(1),
            ..Default::default()
        }
    }

    /// Stamps `bid` with a fresh value off the shared clock: the one
    /// mutation primitive every `set_*`, `clear_entries`, and a touched
    /// `remap_through` funnel through, so `generation`/`clock` can never
    /// drift out of sync with each other.
    fn touch(&mut self, bid: BufferId) {
        self.clock = self.clock.wrapping_add(1);
        self.generation.insert(bid, self.clock);
    }

    /// The shared clock backing every buffer's stamp. `:reload-config`
    /// carries this forward into the next store via `reset`. Not a
    /// generation to compare a buffer's stamp against; see `generation`.
    pub fn clock(&self) -> u64 {
        self.clock
    }

    /// `bid`'s current stamp: `0` if `bid` has never been touched by this
    /// store (a fresh buffer, or one this store was reset since; see
    /// `reset`). Bumped by every `set_*` call and `clear_entries` for `bid`,
    /// and by `remap_through` when a remap actually moved one of `bid`'s
    /// entries.
    pub fn generation(&self, bid: BufferId) -> u64 {
        self.generation.get(&bid).copied().unwrap_or(0)
    }

    /// Replaces `source`'s inlay hints for `bid` wholesale.
    pub fn set_inlay_hints(&mut self, source: String, bid: BufferId, hints: Vec<InlayHintEntry>) {
        self.inlay_hints.set(source, bid, hints);
        self.touch(bid);
    }

    /// All inlay hints for `bid`, across every source: an assertion helper for
    /// tests that check what a server published rather than what a viewport
    /// shows. Production reads go through [`Self::inlay_hints_in_range`].
    #[cfg(any(test, feature = "test-util"))]
    pub fn inlay_hints_for_buffer(&self, bid: BufferId) -> impl Iterator<Item = &InlayHintEntry> {
        self.inlay_hints.for_buffer(bid).map(|(_, e)| e)
    }

    /// Inlay hints for `bid` anchored inside `range`: the per-frame render
    /// bridge's view, which only ever wants the viewport's worth.
    pub fn inlay_hints_in_range(
        &self,
        bid: BufferId,
        range: ExclusiveRange<CharOffset>,
    ) -> impl Iterator<Item = &InlayHintEntry> {
        self.inlay_hints.in_range(bid, range)
    }

    /// Replaces `source`'s signs for `bid` wholesale, one per line
    /// ([`SourceStore::set_one_per_line`]).
    pub fn set_signs(&mut self, source: String, bid: BufferId, signs: Vec<SignEntry>) {
        self.signs.set_one_per_line(source, bid, signs);
        self.touch(bid);
    }

    #[cfg(any(test, feature = "test-util"))]
    pub fn signs_for(&self, source: &str, bid: BufferId) -> &[SignEntry] {
        self.signs.entries_for(source, bid)
    }

    /// Signs for `bid` on a line in `lines`, paired with their source's
    /// resolved gutter slot: the sign bridge's view, which only ever wants
    /// the viewport's worth and never needs the source name itself (unlike
    /// EOL text/line backgrounds, signs never contend for one line's cell
    /// across sources; see [`Self::sign_slot`]'s doc). Resolves
    /// [`Self::sign_slot`] once per source group via
    /// `SourceStore::groups_in_range`, not once per entry. `set-signs!`
    /// already rejects a source unregistered for `bid` at write time, and a
    /// source never loses its registration for a buffer without that
    /// buffer's signs being cleared alongside it (`Self::remove_buffer`,
    /// `Self::unregister_sign_source`),
    /// so every group this sees has a real slot; the `expect` documents that
    /// invariant at the one place it's owned, rather than at every caller.
    pub fn signs_in_range(
        &self,
        bid: BufferId,
        lines: ExclusiveRange<ContentLine>,
    ) -> impl Iterator<Item = (usize, &SignEntry)> {
        self.signs
            .groups_in_range(bid, lines)
            .filter(|(_, es)| !es.is_empty())
            .flat_map(move |(source, es)| {
                let slot = self
                    .sign_slot(bid, source)
                    .expect("set-signs! only accepts a source registered for this buffer");
                es.iter().map(move |e| (slot, e))
            })
    }

    /// Registers `source` as a sign source at `priority` for `bid`, replacing
    /// any prior registration under that name in *that buffer* (last wins,
    /// matching `register-lsp-server!`) rather than leaving a stale entry at
    /// the old priority's sort position alongside the new one. A no-op when
    /// `source` is already registered for `bid` at this exact `priority`:
    /// callers re-register on every render (see `sign_sources`' doc), so
    /// this is the common case and skips the remove-then-resort dance
    /// entirely rather than repeating it every frame for nothing. See
    /// [`Self::sign_slot`] for what a registration buys a caller.
    pub fn register_sign_source(&mut self, source: String, bid: BufferId, priority: i64) {
        let sources = self.sign_sources.entry(bid).or_default();
        if let Some(idx) = sources.iter().position(|(n, _)| *n == source) {
            if sources[idx].1 == priority {
                return;
            }
            sources.remove(idx);
        }
        // Sorted `(priority desc, name asc)`: a source's slot (`sign_slot`)
        // is its index in this order, so registration order itself must
        // never matter, only the declared priority and name.
        let idx = sources.partition_point(|(n, p)| {
            (std::cmp::Reverse(*p), n.as_str()) < (std::cmp::Reverse(priority), source.as_str())
        });
        sources.insert(idx, (source, priority));
    }

    /// Withdraws `source`'s registration for `bid` and drops its signs
    /// there, so the sources ranked after it move up a slot and the gutter
    /// narrows. A no-op for a source not registered for `bid`.
    pub fn unregister_sign_source(&mut self, source: &str, bid: BufferId) {
        let Some(sources) = self.sign_sources.get_mut(&bid) else {
            return;
        };
        let Some(idx) = sources.iter().position(|(n, _)| n == source) else {
            return;
        };
        sources.remove(idx);
        if sources.is_empty() {
            self.sign_sources.remove(&bid);
        }
        self.signs.remove_source_for_buffer(source, bid);
        self.touch(bid);
    }

    /// `name`'s gutter slot in `bid` (its index in that buffer's
    /// `(priority desc, name asc)` registry), or `None` if `name` was never
    /// registered for `bid` via `register_sign_source`. Stable for the
    /// buffer's life and frame-to-frame: it depends only on the registry,
    /// never on which lines currently carry a sign, so a channel's column
    /// never shifts as signs come and go.
    pub fn sign_slot(&self, bid: BufferId, name: &str) -> Option<usize> {
        self.sign_sources
            .get(&bid)?
            .iter()
            .position(|(n, _)| n == name)
    }

    /// Number of sign sources registered for `bid`: the bare slot count
    /// `SignColumnConfig::slots_for` auto-sizes to (before the `+1` padding
    /// column `SignColumn::width_for_slots` adds).
    pub fn sign_source_count(&self, bid: BufferId) -> usize {
        self.sign_sources.get(&bid).map_or(0, Vec::len)
    }

    /// Replaces `source`'s virtual lines for `bid` wholesale.
    pub fn set_virtual_lines(
        &mut self,
        source: String,
        bid: BufferId,
        lines: Vec<VirtualLineEntry>,
    ) {
        self.virtual_lines.set(source, bid, lines);
        self.touch(bid);
    }

    /// All virtual-line entries for `bid`, across every source. The render
    /// write side merges them all into one per-line bucket.
    pub fn virtual_lines_for_buffer(
        &self,
        bid: BufferId,
    ) -> impl Iterator<Item = &VirtualLineEntry> {
        self.virtual_lines.for_buffer(bid).map(|(_, e)| e)
    }

    #[cfg(any(test, feature = "test-util"))]
    pub fn virtual_lines_for(&self, source: &str, bid: BufferId) -> &[VirtualLineEntry] {
        self.virtual_lines.entries_for(source, bid)
    }

    /// Replaces `source`'s EOL text for `bid` wholesale, one per line
    /// ([`SourceStore::set_one_per_line`]).
    pub fn set_eol_text(&mut self, source: String, bid: BufferId, entries: Vec<EolTextEntry>) {
        self.eol_text.set_one_per_line(source, bid, entries);
        self.touch(bid);
    }

    /// All EOL text entries for `bid`, across every source, paired with
    /// their source name: an assertion helper for tests. Production reads go
    /// through [`Self::eol_text_in_range`].
    #[cfg(any(test, feature = "test-util"))]
    pub fn eol_text_for_buffer(
        &self,
        bid: BufferId,
    ) -> impl Iterator<Item = (&str, &EolTextEntry)> {
        self.eol_text.for_buffer(bid).map(|(s, e)| (s.as_str(), e))
    }

    /// EOL text entries for `bid` on a line in `lines`, paired with their
    /// source name, sources in ascending name order. The render write side
    /// reads that order as the tie-break when two sources write the same
    /// line.
    pub fn eol_text_in_range(
        &self,
        bid: BufferId,
        lines: ExclusiveRange<ContentLine>,
    ) -> impl Iterator<Item = (&str, &EolTextEntry)> {
        self.eol_text
            .groups_in_range(bid, lines)
            .flat_map(|(s, es)| es.iter().map(move |e| (s.as_str(), e)))
    }

    /// Replaces `source`'s line backgrounds for `bid` wholesale, one per
    /// line ([`SourceStore::set_one_per_line`]).
    pub fn set_line_backgrounds(
        &mut self,
        source: String,
        bid: BufferId,
        entries: Vec<LineBgEntry>,
    ) {
        self.line_backgrounds.set_one_per_line(source, bid, entries);
        self.touch(bid);
    }

    #[cfg(any(test, feature = "test-util"))]
    pub fn line_backgrounds_for(&self, source: &str, bid: BufferId) -> &[LineBgEntry] {
        self.line_backgrounds.entries_for(source, bid)
    }

    /// Line-background entries for `bid` on a line in `lines`, paired
    /// with their source name, sources in ascending name order. The render
    /// write side reads that order as the tie-break when two sources tint
    /// the same line.
    pub fn line_backgrounds_in_range(
        &self,
        bid: BufferId,
        lines: ExclusiveRange<ContentLine>,
    ) -> impl Iterator<Item = (&str, &LineBgEntry)> {
        self.line_backgrounds
            .groups_in_range(bid, lines)
            .flat_map(|(s, es)| es.iter().map(move |e| (s.as_str(), e)))
    }

    /// Replaces `source`'s extra highlights for `bid` wholesale.
    pub fn set_extra_highlights(
        &mut self,
        source: String,
        bid: BufferId,
        spans: Vec<ExtraHighlightEntry>,
    ) {
        self.extra_highlights.set(source, bid, spans);
        self.touch(bid);
    }

    /// Adds `spans` to `source`'s extra highlights for `bid`.
    pub fn add_extra_highlights(
        &mut self,
        source: String,
        bid: BufferId,
        spans: Vec<ExtraHighlightEntry>,
    ) {
        self.extra_highlights.extend(source, bid, spans);
        self.touch(bid);
    }

    #[cfg(any(test, feature = "test-util"))]
    pub fn extra_highlights_for(&self, source: &str, bid: BufferId) -> &[ExtraHighlightEntry] {
        self.extra_highlights.entries_for(source, bid)
    }

    /// All extra-highlight entries for `bid`, across every source: an
    /// assertion helper for tests. Production reads go through
    /// [`Self::extra_highlights_starting_before`].
    #[cfg(any(test, feature = "test-util"))]
    pub fn extra_highlights_for_buffer(
        &self,
        bid: BufferId,
    ) -> impl Iterator<Item = &ExtraHighlightEntry> {
        self.extra_highlights.for_buffer(bid).map(|(_, e)| e)
    }

    /// Extra-highlight entries for `bid` that start before `end`, sources in
    /// ascending name order. Each source's entries are sorted by `start`, so
    /// the upper bound is a binary search. `end` isn't sorted, so a caller
    /// wanting a window still drops the spans that end before it.
    pub fn extra_highlights_starting_before(
        &self,
        bid: BufferId,
        end: CharOffset,
    ) -> impl Iterator<Item = &ExtraHighlightEntry> {
        self.extra_highlights
            .groups_for_buffer(bid)
            .flat_map(move |(_, es)| es[..es.partition_point(|e| e.start < end)].iter())
    }

    /// Whether `bid` has any decoration, of any kind, that needs to stay in
    /// sync with edits: every kind remaps through `remap_through` now.
    /// Gates queueing a buffer's edits for the remap chokepoint even with
    /// no LSP server attached: decorations are not LSP-owned, LSP is just
    /// their first client.
    ///
    /// Exhaustive destructuring, no `..`: a new decoration kind fails to
    /// compile here until it is listed, so a kind can never silently go
    /// unreported to `has_any`'s callers.
    pub fn has_any(&self, bid: BufferId) -> bool {
        let Self {
            inlay_hints,
            signs,
            virtual_lines,
            eol_text,
            line_backgrounds,
            extra_highlights,
            sign_sources: _,
            generation: _,
            clock: _,
        } = self;
        !inlay_hints.is_empty_for(bid)
            || !signs.is_empty_for(bid)
            || !virtual_lines.is_empty_for(bid)
            || !eol_text.is_empty_for(bid)
            || !line_backgrounds.is_empty_for(bid)
            || !extra_highlights.is_empty_for(bid)
    }

    /// Drops every entry for `bid`, across every source and every kind,
    /// for a buffer whose text was replaced with no change to remap them
    /// through (`:e!` of a changed file, a view's new text). `bid`'s sign
    /// sources stay registered: a registration holds no position.
    ///
    /// The buffer keeps its `BufferId`, so clearing `virtual_lines` without
    /// touching `bid`'s stamp would leave a pane's `virtual_lines_synced`
    /// entry looking current, mirroring the replaced text's virtual lines.
    /// Touching unconditionally, not only when a kind had entries, forces
    /// every pane on `bid` to resync.
    ///
    /// Exhaustive destructuring, no `..`: a new decoration kind fails to
    /// compile here until it is listed, so a text reset can never leave a
    /// stale kind behind.
    pub fn clear_entries(&mut self, bid: BufferId) {
        let Self {
            inlay_hints,
            signs,
            virtual_lines,
            eol_text,
            line_backgrounds,
            extra_highlights,
            sign_sources: _,
            generation: _,
            clock: _,
        } = self;
        inlay_hints.remove_buffer(bid);
        signs.remove_buffer(bid);
        virtual_lines.remove_buffer(bid);
        eol_text.remove_buffer(bid);
        line_backgrounds.remove_buffer(bid);
        extra_highlights.remove_buffer(bid);
        self.touch(bid);
    }

    /// Drops everything held for `bid`, a closed buffer: its entries, as
    /// [`Self::clear_entries`] does, and its registered sign sources.
    pub fn remove_buffer(&mut self, bid: BufferId) {
        self.clear_entries(bid);
        self.sign_sources.remove(&bid);
    }

    /// Remaps `bid`'s decorations, of every kind, through `change`, from the same
    /// chokepoint as the diagnostics remap (`hume-editor`'s
    /// `PositionStores::carry`), so decoration positions never drift out of
    /// sync with the diagnostics they're often paired with. Touches `bid`'s
    /// stamp only if some kind actually had an entry to remap: that
    /// chokepoint carries *every* edit through here, decorated buffer or
    /// not, so touching unconditionally would stamp a
    /// zero-decoration buffer on every keystroke, defeating the
    /// virtual-lines pane sync's whole reason to check the stamp in the
    /// first place. A remap that *did* touch something still moved
    /// positions, so cached consumers (the virtual-lines pane sync) must
    /// resync even though nothing called a `set_*` method.
    ///
    /// Exhaustive destructuring, no `..`: a new decoration kind fails to
    /// compile here until it is listed, so a kind can never silently skip
    /// the remap chokepoint and drift out of sync with its buffer's edits.
    pub fn remap_through(&mut self, bid: BufferId, change: &TextChange) {
        let Self {
            inlay_hints,
            signs,
            virtual_lines,
            eol_text,
            line_backgrounds,
            extra_highlights,
            sign_sources: _,
            generation: _,
            clock: _,
        } = self;
        // Every kind always attempts its remap; only whether to bump the
        // stamp is conditional. The array literal's eager evaluation (not
        // the iterator adapters below) is what guarantees none of these six
        // calls get short-circuited away.
        let cs = change.changes();
        let touched = [
            inlay_hints.remap_points(bid, cs),
            signs.remap_lines(bid, change),
            virtual_lines.remap_lines(bid, change),
            eol_text.remap_lines(bid, change),
            line_backgrounds.remap_lines(bid, change),
            extra_highlights.remap_ranges(bid, cs),
        ]
        .into_iter()
        .any(|kind_touched| kind_touched);
        if touched {
            self.touch(bid);
        }
    }
}

#[cfg(test)]
mod tests;
