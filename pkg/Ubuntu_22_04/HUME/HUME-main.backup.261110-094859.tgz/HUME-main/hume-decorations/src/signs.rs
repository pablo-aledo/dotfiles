//! Engine-compatible sign source feeding the gutter's `SignColumn`.
//!
//! The one sign source wraps a `SharedSlot<FxHashMap<line_idx, Vec<Sign>>>`
//! that the editor writes once per frame, from `prepare_frame`'s step 3,
//! *before* scrolling (`Editor::update_sign_providers`'s doc: the resolved
//! width feeds `layout::compute_viewport`, which the scroll step's `DisplayLineMap`
//! wraps against). `signs_for_line` is then a cheap map lookup, matching
//! `SignSource`'s per-row-per-frame contract.

use rustc_hash::FxHashMap;

use hume_engine::builtins::sign_column::{Sign, SignSource};
use hume_engine::lock::SharedSlot;
use hume_engine::providers::GutterCtx;
use hume_rope::line::ContentLine;

/// Shared per-frame sign data: at most one `Sign` per resolved slot per
/// line (a line's `Vec` holds whichever slots this map's signs actually
/// claimed, never padded, and never more entries than the buffer's
/// resolved `gutter-signs` slot count). Every registered source (diagnostics
/// included, since `core:lsp` places them through `set-signs!` like any other
/// plugin) is pre-merged into this one map at write time.
pub(crate) type SignMap = SharedSlot<FxHashMap<ContentLine, Vec<Sign>>>;

/// One `SignSource` reading a shared per-frame line->signs map.
pub(crate) struct SharedSignSource {
    data: SignMap,
}

impl SharedSignSource {
    pub(crate) fn new(data: SignMap) -> Self {
        Self { data }
    }
}

impl SignSource for SharedSignSource {
    fn signs_for_line(&self, line_idx: ContentLine, _ctx: &GutterCtx) -> Vec<Sign> {
        self.data.read().get(&line_idx).cloned().unwrap_or_default()
    }
}
