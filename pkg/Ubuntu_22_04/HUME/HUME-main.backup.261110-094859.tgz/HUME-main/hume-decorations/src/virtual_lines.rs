//! Virtual-line rendering: a per-pane VIRTUAL_LINE-kind `DecorationSource`
//! fed from the `virtual_lines` decoration store, keyed by anchor line so
//! `decorations_for_line` is a plain map lookup per queried line.
//!
//! Unlike the popup/menu widgets, this provider is consulted by *scroll and
//! cursor math* through `display_lines::DisplayLineMap`, not just rendering, so the per-line
//! lookup must stay cheap (a `FxHashMap` get + `Vec` clone-out, no per-frame
//! allocation-heavy work).

use rustc_hash::FxHashMap;

use hume_engine::lock::SharedSlot;
use hume_engine::providers::{Decoration, DecorationKinds, DecorationSource, VirtualLine};
use hume_rope::line::ContentLine;

pub(crate) type VirtualLineMap = SharedSlot<FxHashMap<ContentLine, Vec<VirtualLine>>>;

pub(crate) struct PaneVirtualLines {
    pub(crate) data: VirtualLineMap,
}

impl DecorationSource for PaneVirtualLines {
    fn kinds(&self) -> DecorationKinds {
        DecorationKinds::VIRTUAL_LINE
    }

    fn decorations_for_line(&self, line_idx: ContentLine, out: &mut Vec<Decoration>) {
        if let Some(lines) = self.data.read().get(&line_idx) {
            out.extend(lines.iter().cloned().map(Decoration::VirtualLine));
        }
    }
}
