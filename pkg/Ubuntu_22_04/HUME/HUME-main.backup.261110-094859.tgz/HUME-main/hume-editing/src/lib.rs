//! Core text-editing model for HUME: the document representation and the
//! stateless primitives over it. No knowledge of the editor, keymaps,
//! rendering, or scripting.
//!
//! - [`text::BufferText`]: the document rope. Positions are char offsets.
//! - [`selection::SelectionSet`]: sorted, non-overlapping, non-empty set of
//!   [`selection::Selection`]s, each covering whole grapheme clusters, tagged
//!   with the version of the text it was computed for.
//! - [`state::EditState`]: a text and a selection set that fits it; reads go
//!   through [`selection::EditView`] and [`selection::SelectionView`].
//! - [`changeset::ChangeSet`]: an invertible, composable document transform.
//! - [`transaction::Transaction`]: a `ChangeSet` plus resulting selections,
//!   the unit of undo.
//! - [`history::History`]: tree-structured undo/redo.
//!
//! Motion and selection code steps positions cluster by cluster with
//! [`text::ClusterView::next`]/[`text::ClusterView::prev`], and walks with
//! [`text::ClusterView::graphemes_at`]/[`text::ClusterView::before`], never
//! by raw chars. A [`text::BufferText`] hands out [`text::ClusterView`],
//! [`text::LineView`] and [`text::ColumnView`] for its cluster, line and
//! column queries.

#![deny(rustdoc::broken_intra_doc_links)]
#![deny(rustdoc::private_intra_doc_links)]

pub mod change_log;
pub mod changeset;
pub mod diff;
pub mod edit;
pub mod error;
pub mod history;
pub mod hunk;
pub mod indent;
mod line_diff;
#[cfg(any(test, feature = "test-util"))]
pub mod marked;
pub mod selection;
pub mod state;
pub mod tab_style;
pub mod text;
pub mod tracked;
pub mod transaction;
pub mod word;
