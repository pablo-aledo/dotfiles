use std::borrow::Cow;

use hume_rope::line::ContentLine;
use hume_rope::offset::{CharOffset, ExclusiveRange};

use ropey::Rope;

use crate::error::ApplyError;
use crate::text::{BufferText, TextVersion};

/// A single atomic edit operation within a changeset.
///
/// A changeset decomposes any text transformation into three OT primitives,
/// applied sequentially against the old document:
/// - `Retain` advances through both old and new documents (1:1 mapping)
/// - `Delete` consumes from the old document only (chars vanish)
/// - `Insert` produces into the new document only (chars appear)
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum Operation {
    /// Skip `n` chars unchanged. Advances both old and new cursors by `n`.
    Retain(usize),
    /// Remove `n` chars from the old document. Advances old cursor by `n`,
    /// new cursor stays put.
    Delete(usize),
    /// Insert `text` into the new document. Advances new cursor by
    /// `text.chars().count()`, old cursor stays put.
    Insert(String),
}

/// Sticky-side preference when mapping a position through an insertion.
///
/// When an old position coincides with an insertion point, `Before` keeps it
/// before the new text and `After` moves it past. Inserting `"XY"` at offset 3
/// maps 3 to 3 (`Before`) or 5 (`After`).
///
/// Mostly used to re-anchor positions the edit did not produce (bookmarks,
/// LSP ranges) via [`PosMapCursor`]. `>`/`<` (`hume-ops/src/edit/indent.rs`)
/// also relies on it, ordering each line's `Insert` before its `Delete` so a
/// selection endpoint at the line start resolves by `Assoc`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Assoc {
    /// Stay before inserted text ("sticky left").
    /// Use this for anchors and positions that should remain pinned to the
    /// character that was at this offset before the edit.
    Before,
    /// Move past inserted text ("sticky right").
    /// Use this for cursors that should advance past text inserted at their
    /// position (e.g. when replaying where the user's cursor ended up).
    After,
}

/// A complete description of a document transformation.
///
/// Maps an old document of `len_before` chars to a new document of `len_after`
/// chars via a sequence of `Retain`/`Delete`/`Insert` operations. The
/// operations must exactly consume `len_before` old-document chars (via
/// `Retain` + `Delete`) and produce exactly `len_after` new-document chars
/// (via `Retain` + `Insert`).
///
/// # Normalization
///
/// Operations are always normalized: adjacent ops of the same variant are
/// merged (e.g. `Retain(3), Retain(5)` becomes `Retain(8)`), and zero-length
/// ops are omitted. This makes equality comparison meaningful and keeps
/// `compose` simple.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChangeSet {
    ops: Vec<Operation>,
    len_before: usize,
    len_after: usize,
}

/// One region [`ChangeSet::edited_regions`] touched: the old-doc span it
/// replaced, and the text it replaced that span with (empty for a region
/// that only deleted).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EditedRegion<'a> {
    pub old: ExclusiveRange<CharOffset>,
    pub inserted: Cow<'a, str>,
}

/// Appends `s` to `cow` in place: `edited_regions`' own accumulator for a
/// region touched by more than one `Insert` op. Stays `Cow::Borrowed` (no
/// allocation) for the first piece; converts to owned only once a second
/// piece needs concatenating.
fn push_str<'a>(cow: &mut Cow<'a, str>, s: &'a str) {
    if cow.is_empty() {
        *cow = Cow::Borrowed(s);
    } else {
        cow.to_mut().push_str(s);
    }
}

// ── push_merge helper ────────────────────────────────────────────────────────

/// Push an operation onto `ops`, merging with the last element if they are
/// the same variant. Zero-length ops are silently dropped.
///
/// This is the single normalization point. Every path that constructs a `Vec<Operation>` goes
/// through here to guarantee the merged/no-zeros invariant.
pub(super) fn push_merge(ops: &mut Vec<Operation>, op: Operation) {
    match op {
        Operation::Retain(0) | Operation::Delete(0) => return,
        Operation::Insert(ref s) if s.is_empty() => return,
        _ => {}
    }

    match (ops.last_mut(), &op) {
        (Some(Operation::Retain(existing)), Operation::Retain(n)) => {
            *existing += n;
        }
        (Some(Operation::Delete(existing)), Operation::Delete(n)) => {
            *existing += n;
        }
        (Some(Operation::Insert(existing)), Operation::Insert(s)) => {
            existing.push_str(s);
        }
        _ => {
            ops.push(op);
        }
    }
}

// ── compose helpers ──────────────────────────────────────────────────────────

/// How many chars does this operation "consume" from its input side?
///
/// - `Retain(n)` and `Delete(n)` consume `n` chars from the old doc.
/// - `Insert` consumes `n` chars from the intermediate doc (its char length).
fn op_consuming_len(op: &Operation) -> usize {
    match op {
        Operation::Retain(n) | Operation::Delete(n) => *n,
        Operation::Insert(s) => s.chars().count(),
    }
}

/// Consume `n` chars from `op` and return the remainder (or the next op
/// from the iterator if `op` is fully consumed).
///
/// For `Retain(k)` and `Delete(k)`: if `k > n`, return the same variant
/// with `k - n`; otherwise fetch the next op.
///
/// For `Insert(s)`: if `s` has more than `n` chars, return `Insert` with
/// the remaining chars (after skipping the first `n`); otherwise fetch next.
fn advance_op(
    op: Operation,
    n: usize,
    iter: &mut impl Iterator<Item = Operation>,
) -> Option<Operation> {
    let remainder = match op {
        Operation::Retain(k) if k > n => Some(Operation::Retain(k - n)),
        Operation::Delete(k) if k > n => Some(Operation::Delete(k - n)),
        Operation::Insert(mut s) => {
            // `nth` stops at the boundary instead of counting the whole
            // string, and `s` is owned, so the tail is taken in place, with no
            // second scan and no fresh allocation for the remainder.
            match s.char_indices().nth(n) {
                Some((byte_idx, _)) => {
                    s.drain(..byte_idx);
                    Some(Operation::Insert(s))
                }
                None => None,
            }
        }
        _ => None, // fully consumed
    };
    remainder.or_else(|| iter.next())
}

// ── Position mapping cursor ──────────────────────────────────────────────────

/// A resumable, monotone version of `ChangeSet::map_pos` for batch queries.
///
/// Each `map()` call must receive `pos` values in non-decreasing order across
/// the cursor's lifetime. It never revisits an earlier op, so a caller
/// walking `n` sorted positions through one cursor pays O(ops + n) total
/// instead of O(ops × n) for `n` fresh `map_pos` calls. Same amortized-cursor
/// shape as `IntervalCursor` in `hume_engine::style::highlight`.
pub struct PosMapCursor<'a> {
    walk: OpWalk<'a>,
    /// The new-doc char offset matching `walk.old`.
    new: usize,
}

impl<'a> PosMapCursor<'a> {
    pub fn new(ops: &'a [Operation]) -> Self {
        Self {
            walk: OpWalk::new(ops),
            new: 0,
        }
    }

    /// Map `pos` from old-doc to new-doc space. `pos` must be `>=` every
    /// position passed to a prior call on this cursor (see struct docs).
    ///
    /// Thin shorthand over [`Self::map_anchor`] for callers that don't care
    /// whether the position's anchor character survived the edit (selections,
    /// cursors: a collapsed-to-the-deletion-point result is exactly what
    /// they want).
    pub fn map(&mut self, pos: CharOffset, assoc: Assoc) -> CharOffset {
        self.map_anchor(pos, assoc).pos
    }

    /// Map `pos` from old-doc to new-doc space, additionally reporting
    /// whether `pos` named a character a `Delete` op consumed. The mapped
    /// value is then the deletion point, a *neighbour* of the vanished
    /// anchor rather than the anchor itself. Callers that treat `pos` as
    /// naming a specific character (a decoration anchor, not a cursor) use
    /// this to tell "moved" from "its character is gone" apart.
    ///
    /// `ChangeSet::map_pos` is a one-shot convenience built on top of this:
    /// it opens a fresh cursor and delegates a single query to it.
    pub fn map_anchor(&mut self, pos: CharOffset, assoc: Assoc) -> MappedPos {
        let pos = pos.index();
        debug_assert!(
            pos >= self.walk.old,
            "PosMapCursor: queries must be non-decreasing"
        );
        let hit = self.walk.seek(&mut CharProbe {
            pos,
            new: &mut self.new,
        });
        // Bare usize: `old`/`new` are running cursors advanced by op
        // *lengths*, arithmetic `CharOffset` has no `Add`/`Sub` for.
        let (mapped, anchor_deleted) = match hit {
            Hit::Retained => (self.new + (pos - self.walk.old), false),
            Hit::Deleted => (self.new, true),
            Hit::InsertPoint(_) if assoc == Assoc::Before => (self.new, false),
            Hit::InsertPoint(s) => (self.new + s.chars().count(), false),
        };
        MappedPos {
            pos: CharOffset::new(mapped),
            anchor_deleted,
        }
    }
}

/// The op walk both cursors share: the op the previous query stopped at and
/// the old-doc char offset it starts at.
struct OpWalk<'a> {
    ops: &'a [Operation],
    idx: usize,
    old: usize,
}

impl<'a> OpWalk<'a> {
    fn new(ops: &'a [Operation]) -> Self {
        Self {
            ops,
            idx: 0,
            old: 0,
        }
    }

    /// Walks forward from wherever the previous query left off to the op
    /// holding the position `probe` asks about, handing `probe` each op it
    /// walks past. Ops fully behind a past query never matter again for a
    /// non-decreasing sequence of queries, so the walk never restarts.
    ///
    /// The position is at an `Insert` when it lies before `old + 1`: the
    /// queries are monotone, so it never lies before `old` itself.
    fn seek(&mut self, probe: &mut impl Probe) -> Hit<'a> {
        while let Some(op) = self.ops.get(self.idx) {
            match op {
                Operation::Retain(n) => {
                    if probe.lies_before(self.old + n) {
                        return Hit::Retained;
                    }
                    probe.passed(op, self.old);
                    self.old += n;
                }
                Operation::Delete(n) => {
                    if probe.lies_before(self.old + n) {
                        return Hit::Deleted;
                    }
                    probe.passed(op, self.old);
                    self.old += n;
                }
                Operation::Insert(s) => {
                    if probe.lies_before(self.old + 1) {
                        return Hit::InsertPoint(s);
                    }
                    probe.passed(op, self.old);
                }
            }
            self.idx += 1;
        }
        Hit::Retained
    }
}

/// The position an [`OpWalk`] query asks about, in whatever unit the query
/// counts in.
trait Probe {
    /// Whether the position lies before old-doc char offset `old`.
    fn lies_before(&mut self, old: usize) -> bool;

    /// Sees each op the walk passes, with the old-doc offset it starts at.
    fn passed(&mut self, op: &Operation, old: usize);
}

/// Where an [`OpWalk`] query landed: inside a `Retain` (or past every
/// op, which maps the same way), inside a `Delete`, or at the point an
/// `Insert` adds its text.
enum Hit<'a> {
    Retained,
    Deleted,
    InsertPoint(&'a str),
}

/// A query for old-doc char offset `pos`, advancing `new` past the text
/// each op it passes leaves in the new doc.
struct CharProbe<'n> {
    pos: usize,
    new: &'n mut usize,
}

impl Probe for CharProbe<'_> {
    fn lies_before(&mut self, old: usize) -> bool {
        self.pos < old
    }

    fn passed(&mut self, op: &Operation, _: usize) {
        match op {
            Operation::Retain(n) => *self.new += n,
            Operation::Delete(_) => {}
            Operation::Insert(s) => *self.new += s.chars().count(),
        }
    }
}

/// Maps content lines of the text before a change into the text after it.
/// A line is its `\n`: it maps to the line its `\n` lands on, and to `None`
/// once a deletion consumed that `\n`. Text inserted at the `\n` goes before
/// it, joining the line's end, and the line maps to where that text starts.
///
/// The answer is the line of the line's `\n` mapped through a
/// [`PosMapCursor`] with [`Assoc::Before`]: it is the same op walk, asked in
/// line units. Line `L`'s `\n` lies before offset `x` when `L` is below
/// the count of `\n`s before `x`, a count read from the rope once per op, so
/// a batch of lines costs one lookup per op walked, none per line.
pub struct LineMapCursor<'a> {
    walk: OpWalk<'a>,
    probe: LineProbe<'a>,
}

impl<'a> LineMapCursor<'a> {
    pub(crate) fn new(before: &'a BufferText, changes: &'a ChangeSet) -> Self {
        Self {
            walk: OpWalk::new(&changes.ops),
            probe: LineProbe {
                text: before,
                line: 0,
                memo: (0, 0),
                breaks_before_old: 0,
                breaks_before_new: 0,
            },
        }
    }

    /// Where `line` lands, `None` when a deletion consumed its `\n`. `line`
    /// must be `>=` every line passed to a prior call on this cursor.
    ///
    /// # Panics
    /// Panics if `line` is not a content line of the text before the change.
    pub fn map_line(&mut self, line: ContentLine) -> Option<ContentLine> {
        assert!(
            line.index() < self.probe.text.content_line_count().get(),
            "map_line: line {} is not a content line of the text before the change",
            line.index()
        );
        debug_assert!(
            line.index() >= self.probe.line,
            "map_line: lines must be non-decreasing"
        );
        self.probe.line = line.index();
        match self.walk.seek(&mut self.probe) {
            Hit::Deleted => None,
            Hit::Retained | Hit::InsertPoint(_) => {
                let probe = &self.probe;
                Some(ContentLine::new(
                    probe.breaks_before_new + (probe.line - probe.breaks_before_old),
                ))
            }
        }
    }
}

/// A query for content line `line`'s `\n`, carrying the `\n` counts of the
/// walk so far: before the cursor's old-doc offset, and in the new text
/// the walked-past ops produced.
struct LineProbe<'a> {
    text: &'a BufferText,
    line: usize,
    /// The last `(offset, \n count before it)` read from the rope: every
    /// query that stops at an op asks about the same offset, and the op's
    /// `passed` asks about it again.
    memo: (usize, usize),
    breaks_before_old: usize,
    breaks_before_new: usize,
}

impl LineProbe<'_> {
    /// The number of `\n`s before old-doc offset `old`.
    fn breaks_before(&mut self, old: usize) -> usize {
        if self.memo.0 != old {
            let breaks = self.text.ropey_char_to_line(CharOffset::new(old)).index();
            self.memo = (old, breaks);
        }
        self.memo.1
    }
}

impl Probe for LineProbe<'_> {
    fn lies_before(&mut self, old: usize) -> bool {
        self.line < self.breaks_before(old)
    }

    fn passed(&mut self, op: &Operation, old: usize) {
        match op {
            Operation::Retain(n) => {
                let end = self.breaks_before(old + n);
                self.breaks_before_new += end - self.breaks_before_old;
                self.breaks_before_old = end;
            }
            Operation::Delete(n) => self.breaks_before_old = self.breaks_before(old + n),
            Operation::Insert(s) => {
                self.breaks_before_new += s.bytes().filter(|&b| b == b'\n').count();
            }
        }
    }
}

/// A mapped position, plus whether the character it was anchored to was
/// deleted (the position then names the deletion point, a *neighbour* of
/// the anchor, not the anchor).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MappedPos {
    pub pos: CharOffset,
    pub anchor_deleted: bool,
}

// ── ChangeSet impl ───────────────────────────────────────────────────────────

impl ChangeSet {
    /// Builds the identity changeset for a document of `len` chars: retains
    /// everything, changes nothing. Starting point for callers that accumulate
    /// edits via repeated [`compose`](Self::compose) calls (e.g. a session
    /// tracking every edit since some earlier snapshot) and need a neutral
    /// element to compose the first observed edit onto.
    pub fn identity(len: usize) -> ChangeSet {
        let mut ops = Vec::new();
        push_merge(&mut ops, Operation::Retain(len));
        ChangeSet {
            ops,
            len_before: len,
            len_after: len,
        }
    }

    /// `ops`, applying to a text of `len_before` chars, as a changeset.
    /// `None` unless they are normalized, consume `len_before` chars and no
    /// more, and insert no `\r`.
    pub(crate) fn from_ops(ops: Vec<Operation>, len_before: usize) -> Option<ChangeSet> {
        let (mut consumed, mut len_after) = (0usize, 0usize);
        let mut previous = None;
        for op in &ops {
            let kind = std::mem::discriminant(op);
            if previous == Some(kind) {
                return None;
            }
            previous = Some(kind);
            match op {
                Operation::Retain(n) if *n > 0 => {
                    consumed = consumed.checked_add(*n)?;
                    len_after = len_after.checked_add(*n)?;
                }
                Operation::Delete(n) if *n > 0 => consumed = consumed.checked_add(*n)?,
                Operation::Insert(s) if !s.is_empty() && !s.contains('\r') => {
                    len_after = len_after.checked_add(s.chars().count())?;
                }
                _ => return None,
            }
        }
        (consumed == len_before).then_some(ChangeSet {
            ops,
            len_before,
            len_after,
        })
    }

    /// Returns `true` if this changeset is the identity transform: all
    /// operations are `Retain` and the document is unchanged.
    pub fn is_identity(&self) -> bool {
        self.ops.iter().all(|op| matches!(op, Operation::Retain(_)))
    }

    /// The ordered list of operations in this changeset.
    pub fn ops(&self) -> &[Operation] {
        &self.ops
    }

    /// Char length of the document this changeset expects to be applied to.
    pub fn len_before(&self) -> usize {
        self.len_before
    }

    /// Char length of the document this changeset produces.
    pub(crate) fn len_after(&self) -> usize {
        self.len_after
    }

    /// Apply this changeset to `text`, producing a new buffer.
    ///
    /// Clones the buffer's rope and mutates the clone via `Rope::remove`/
    /// `Rope::insert` (each O(log n)); retains are free. Total cost O(k log n)
    /// for k non-retain operations, vs. O(n) for flattening to a `String`
    /// and rebuilding.
    ///
    /// Positions are in **old-document space**; a running `delta` translates
    /// them to the mutated rope's current coordinates, the pattern used
    /// throughout HUME's multi-selection editing.
    ///
    /// Assembling a `Transaction` from outside the editor's named commands?
    /// Use [`crate::transaction::Transaction::apply`] instead; it also
    /// validates the bundled selection against the post-edit buffer.
    ///
    /// # Errors
    ///
    /// - [`ApplyError::LengthMismatch`] if `text.len_chars() != self.len_before`.
    /// - [`ApplyError::TrailingNewlineMissing`] if the result rope doesn't end
    ///   with `\n` (the changeset deleted the structural trailing newline).
    ///
    /// On error the original `text` is untouched, and the caller still owns it.
    pub fn apply(&self, text: &BufferText) -> Result<BufferText, ApplyError> {
        Ok(match self.applied_rope(text)? {
            Some(rope) => text.successor(rope),
            None => text.clone(),
        })
    }

    /// [`Self::apply`], the result tagged `version`: a version whose content
    /// this changeset reproduces, as undo's does. A changeset that changes
    /// nothing relabels `text` without moving its generation.
    ///
    /// # Errors
    /// As [`Self::apply`].
    pub(crate) fn apply_as(
        &self,
        text: &BufferText,
        version: TextVersion,
    ) -> Result<BufferText, ApplyError> {
        Ok(match self.applied_rope(text)? {
            Some(rope) => text.restored(rope, version),
            None => text.relabeled(version),
        })
    }

    /// The rope this changeset makes of `text`'s, `None` for a changeset
    /// that changes nothing.
    fn applied_rope(&self, text: &BufferText) -> Result<Option<Rope>, ApplyError> {
        if text.len_chars() != self.len_before {
            return Err(ApplyError::LengthMismatch {
                buf_len: text.len_chars(),
                expected: self.len_before,
            });
        }
        if self.is_identity() {
            return Ok(None);
        }

        // Clone the rope (O(1), since ropey uses Arc-based tree nodes). We mutate
        // the clone so that `text` remains valid on the error path.
        let mut rope = text.rope().clone();

        // `delta` tracks the net char-count shift from all mutations so far.
        // Changeset positions are in old-doc space; `old_pos + delta` gives
        // the corresponding position in the mutated rope.
        let mut delta: isize = 0;
        let mut old_pos: usize = 0;

        for op in &self.ops {
            match op {
                Operation::Retain(n) => {
                    // Nothing to do: these chars are already in the rope.
                    old_pos += n;
                }
                Operation::Delete(n) => {
                    // `checked_add_signed` fails loudly in both debug and release
                    // if delta somehow drives old_pos below zero.
                    let start = old_pos
                        .checked_add_signed(delta)
                        .expect("changeset apply: rope position underflow");
                    rope.remove(start..start + n);
                    old_pos += n;
                    delta -= *n as isize;
                }
                Operation::Insert(s) => {
                    let pos = old_pos
                        .checked_add_signed(delta)
                        .expect("changeset apply: rope position underflow");
                    // Ropey tracks its own char count in O(1), so the insert's
                    // char length is read off the rope rather than by scanning
                    // `s` a second time.
                    let before = rope.len_chars();
                    rope.insert(pos, s);
                    delta += (rope.len_chars() - before) as isize;
                }
            }
        }

        if !crate::text::is_valid_buffer_rope(&rope) {
            return Err(ApplyError::TrailingNewlineMissing);
        }
        Ok(Some(rope))
    }

    /// Map a single char position from the old document to the new document.
    ///
    /// `assoc` controls what happens when `pos` falls exactly at an insertion
    /// point: `Before` keeps the position before the inserted text, `After`
    /// moves it past. Positions inside a deleted region collapse to the
    /// start of the deletion (the character is gone).
    ///
    /// One-shot convenience over [`PosMapCursor`]. Batch callers mapping
    /// several sorted positions (e.g. a selection set translated through an edit)
    /// should use `PosMapCursor` directly instead, so the walk isn't
    /// restarted per position. Test-only: the tests use it as a reference
    /// implementation that pins `PosMapCursor`'s per-query semantics.
    ///
    /// # Panics
    /// Panics (debug) if `pos > self.len_before`.
    #[cfg(test)]
    pub(crate) fn map_pos(&self, pos: CharOffset, assoc: Assoc) -> CharOffset {
        debug_assert!(
            pos.index() <= self.len_before,
            "map_pos: pos {pos:?} exceeds len_before {}",
            self.len_before,
        );
        PosMapCursor::new(&self.ops).map(pos, assoc)
    }

    // ── map_positions / map_ranges ──────────────────────────────────────────

    /// Map a sorted slice of positions in place, through one [`PosMapCursor`]
    /// pass: O(ops + n) total instead of O(ops × n) for `n` fresh
    /// `ChangeSet::map_pos` calls.
    ///
    /// # Panics
    /// Panics (debug) if `positions` is not sorted ascending, or any position
    /// exceeds `self.len_before`.
    pub fn map_positions(&self, positions: &mut [CharOffset], assoc: Assoc) {
        debug_assert!(
            positions.windows(2).all(|w| w[0] <= w[1]),
            "map_positions: positions must be sorted ascending"
        );
        let mut cursor = PosMapCursor::new(&self.ops);
        for pos in positions.iter_mut() {
            debug_assert!(
                pos.index() <= self.len_before,
                "map_positions: pos {pos:?} exceeds len_before {}",
                self.len_before,
            );
            *pos = cursor.map(*pos, assoc);
        }
    }

    /// Map `(start, end)` ranges in place, sorted by `start`. Starts map with
    /// [`Assoc::After`] and ends with [`Assoc::Before`], so a range shrinks
    /// (never swallows neighbouring text) when edits land exactly at its
    /// boundaries; a range fully inside a deletion collapses to an empty
    /// range at the deletion point (caller may then drop it).
    ///
    /// Two `PosMapCursor` passes (starts, then ends) rather than one
    /// interleaved pass. Starts and ends are each individually sorted but
    /// interleaved with each other, so two O(ops + n) passes are simpler
    /// than merging a tagged list, at the same cost. Nested ranges
    /// (sorted-by-start doesn't imply sorted-by-end, e.g. two LSP
    /// diagnostics on the same span) mean the ends pass walks an index
    /// permutation sorted by end value rather than input order, so the
    /// cursor always sees non-decreasing queries; mapped ends are scattered
    /// back to their original slot before a final O(n) fixup clamps `end` to
    /// `start` where a degenerate zero-width range at an insertion boundary
    /// would otherwise invert.
    ///
    /// # Panics
    /// Panics (debug) if `ranges` is not sorted by `start`, or any input has
    /// `end < start`.
    pub fn map_ranges(&self, ranges: &mut [ExclusiveRange<CharOffset>]) {
        debug_assert!(
            ranges.windows(2).all(|w| w[0].start <= w[1].start),
            "map_ranges: ranges must be sorted by start"
        );
        debug_assert!(
            ranges.iter().all(|r| r.start <= r.end),
            "map_ranges: every range must have start <= end"
        );

        let mut starts = PosMapCursor::new(&self.ops);
        for range in ranges.iter_mut() {
            range.start = starts.map(range.start, Assoc::After);
        }

        let mut end_order: Vec<usize> = (0..ranges.len()).collect();
        end_order.sort_by_key(|&i| ranges[i].end);
        let mut ends = PosMapCursor::new(&self.ops);
        for i in end_order {
            ranges[i].end = ends.map(ranges[i].end, Assoc::Before);
        }

        for range in ranges.iter_mut() {
            range.end = range.end.max(range.start);
        }
    }

    // ── edited_old_ranges / edited_regions ────────────────────────────────────

    /// Old-doc `(start, end)` spans touched by this changeset's edits, sorted
    /// ascending and merged where adjacent/overlapping.
    ///
    /// `Delete(n)` contributes `[old, old+n)`; `Insert` contributes the point
    /// range `[old, old)`: it touches only the exact offset it lands at,
    /// since it doesn't consume any old-doc chars. A point can merge into a
    /// preceding range when it sits exactly at that range's end (e.g. an
    /// Insert immediately following a Delete at the same position).
    ///
    /// One O(ops) walk lets a caller check every selection's line against
    /// these ranges with a single forward-only cursor, instead of re-walking
    /// `self.ops` per selection.
    pub(crate) fn edited_old_ranges(&self) -> Vec<ExclusiveRange<CharOffset>> {
        self.edited_regions().into_iter().map(|r| r.old).collect()
    }

    /// Like `edited_old_ranges`, but also carries
    /// the text each region's edit inserted: the old-doc span plus its
    /// replacement, in one walk. `inserted` is `Cow::Borrowed` in the common
    /// case (a region touched by at most one `Insert` op); a region merging
    /// more than one (an `Insert` sitting between two other touching
    /// ops, which only `compose` of several changesets can produce) copies
    /// into an owned `String` to concatenate them in order.
    pub fn edited_regions(&self) -> Vec<EditedRegion<'_>> {
        let mut regions: Vec<EditedRegion<'_>> = Vec::new();
        let mut old = 0usize;
        for op in &self.ops {
            match op {
                Operation::Retain(n) => old += n,
                Operation::Delete(n) => {
                    let (start, end) = (old, old + n);
                    match regions.last_mut() {
                        Some(last) if start <= last.old.end.index() => {
                            last.old.end = last.old.end.max(CharOffset::new(end));
                        }
                        _ => regions.push(EditedRegion {
                            old: ExclusiveRange::new(CharOffset::new(start), CharOffset::new(end)),
                            inserted: Cow::Borrowed(""),
                        }),
                    }
                    old += n;
                }
                Operation::Insert(s) => match regions.last_mut() {
                    Some(last) if old <= last.old.end.index() => {
                        last.old.end = last.old.end.max(CharOffset::new(old));
                        push_str(&mut last.inserted, s);
                    }
                    _ => regions.push(EditedRegion {
                        old: ExclusiveRange::new(CharOffset::new(old), CharOffset::new(old)),
                        inserted: Cow::Borrowed(s.as_str()),
                    }),
                },
            }
        }
        regions
    }

    /// Produce a changeset that undoes `self`.
    ///
    /// Applying `self` to `text` gives a new buffer; applying the inverted
    /// changeset to that new buffer gives back `text`. This is the foundation
    /// of undo.
    ///
    /// Requires the **original** buffer (`text`) because `Delete` operations
    /// need the actual deleted text to produce `Insert` operations in the
    /// inverse.
    ///
    /// # Panics
    /// Panics if `text.len_chars() != self.len_before`.
    #[must_use]
    pub fn invert(&self, text: &BufferText) -> ChangeSet {
        assert_eq!(
            text.len_chars(),
            self.len_before,
            "ChangeSet::invert: buffer length {} doesn't match len_before {}",
            text.len_chars(),
            self.len_before,
        );

        let mut inv_ops: Vec<Operation> = Vec::new();
        let mut old_pos = CharOffset::new(0);

        for op in &self.ops {
            match op {
                Operation::Retain(n) => {
                    push_merge(&mut inv_ops, Operation::Retain(*n));
                    old_pos = old_pos.shift(*n as isize);
                }
                Operation::Delete(n) => {
                    // To undo a deletion, re-insert the deleted text.
                    let new_pos = old_pos.shift(*n as isize);
                    let removed = text
                        .slice(ExclusiveRange::new(old_pos, new_pos))
                        .to_string();
                    push_merge(&mut inv_ops, Operation::Insert(removed));
                    old_pos = new_pos;
                }
                Operation::Insert(s) => {
                    // To undo an insertion, delete the same number of chars.
                    let len = s.chars().count();
                    push_merge(&mut inv_ops, Operation::Delete(len));
                    // Insert doesn't consume old chars, so old_pos stays.
                }
            }
        }

        ChangeSet {
            ops: inv_ops,
            len_before: self.len_after,
            len_after: self.len_before,
        }
    }

    /// Compose two sequential changesets into one.
    ///
    /// If `self` transforms document A→B and `other` transforms B→C, then
    /// `self.compose(other)` produces a single changeset transforming A→C.
    ///
    /// This is the standard OT compose algorithm: two pointers walk through
    /// `self.ops` and `other.ops` simultaneously, consuming matching amounts
    /// from each side. The key insight is:
    ///
    /// - **A's Delete** doesn't produce anything in B, so B never sees it.
    ///   It goes straight to the output.
    /// - **B's Insert** doesn't consume anything from B (it creates new text).
    ///   It goes straight to the output.
    /// - All other combinations consume from both sides in lockstep.
    ///
    /// # Panics
    /// Panics if `self.len_after != other.len_before`.
    #[must_use]
    pub fn compose(self, other: ChangeSet) -> ChangeSet {
        assert_eq!(
            self.len_after, other.len_before,
            "compose: self.len_after ({}) != other.len_before ({})",
            self.len_after, other.len_before,
        );

        let len_before = self.len_before;
        let len_after = other.len_after;

        // Upper bound: each loop iteration pushes at most one op and fully
        // consumes at least one op from one side (the lockstep arm advances
        // by `min`, the shorter of the two), and `push_merge` only ever
        // merges into an existing entry, never grows the vec on its own.
        let mut result: Vec<Operation> = Vec::with_capacity(self.ops.len() + other.ops.len());

        // We use partial-consumption iterators. Each "current" slot holds
        // the remainder of the operation being consumed. `into_iter()` moves
        // ops out of the vecs without cloning; `Operation` values are owned
        // directly in the cursor slots.
        let mut a_ops = self.ops.into_iter();
        let mut b_ops = other.ops.into_iter();
        let mut a_cur: Option<Operation> = a_ops.next();
        let mut b_cur: Option<Operation> = b_ops.next();

        // Each iteration moves `a_cur` and `b_cur` into a single match,
        // destructures them directly, and writes the results back. Ownership
        // flows through the match arms instead of being plucked out after a
        // separate borrow-only check.
        loop {
            match (a_cur, b_cur) {
                // ── Done ─────────────────────────────────────────────────────
                (None, None) => break,

                // ── A's Delete: emit and advance A only ──────────────────────
                //
                // A removed chars from the original doc. B never saw those
                // chars, so the delete goes straight to output regardless of
                // what B is currently doing. The catch-all `b` rebinds b_cur
                // unconsumed, which correctly handles `(Delete, None)` too
                // (trailing A-deletes after B is exhausted are valid).
                (Some(Operation::Delete(n)), b) => {
                    push_merge(&mut result, Operation::Delete(n));
                    a_cur = a_ops.next();
                    b_cur = b; // put back: B wasn't involved
                }

                // ── B's Insert: emit and advance B only ──────────────────────
                //
                // B added new text that didn't exist in A's output. It goes
                // straight to output regardless of what A is doing. The Delete
                // arm above has higher priority (it comes first in the match),
                // so this arm only fires when A is not a Delete.
                // The catch-all `a` handles `(None, Insert)` correctly too.
                (a, Some(Operation::Insert(s))) => {
                    push_merge(&mut result, Operation::Insert(s));
                    b_cur = b_ops.next();
                    a_cur = a; // put back: A wasn't involved
                }

                // ── Lockstep: both sides consume the intermediate doc ────────
                //
                // At this point we know: A is not Delete (caught above),
                // B is not Insert (caught above). Both are Some.
                // Consume `min` chars from each side, then advance both.
                (Some(a), Some(b)) => {
                    let a_len = op_consuming_len(&a);
                    let b_len = op_consuming_len(&b);
                    let min = a_len.min(b_len);

                    // Insert + Retain → Insert (first `min` chars)
                    //
                    // B retains A's insert, whole or in part: the retained
                    // text moves to the output instead of being copied, and
                    // a partly retained insert is split once at the `min`-th
                    // char, its tail left as A's remainder. An Insert session
                    // composes every keystroke into a group that retains the
                    // whole run typed so far, and every Backspace inside the
                    // run retains all of it but its last char.
                    if matches!(b, Operation::Retain(_))
                        && let Operation::Insert(mut s) = a
                    {
                        a_cur = if min == a_len {
                            a_ops.next()
                        } else {
                            let (end, _) = s
                                .char_indices()
                                .nth(min)
                                .expect("B retains fewer chars than A inserted");
                            Some(Operation::Insert(s.split_off(end)))
                        };
                        push_merge(&mut result, Operation::Insert(s));
                        b_cur = advance_op(b, min, &mut b_ops);
                        continue;
                    }

                    match (&a, &b) {
                        // Retain + Retain → Retain
                        (Operation::Retain(_), Operation::Retain(_)) => {
                            push_merge(&mut result, Operation::Retain(min));
                        }
                        // Retain + Delete → Delete
                        // (A retained chars that B then deletes.)
                        (Operation::Retain(_), Operation::Delete(_)) => {
                            push_merge(&mut result, Operation::Delete(min));
                        }
                        // Insert + Delete → cancel
                        // (A inserted text that B immediately deletes:
                        // the text never existed from the A→C perspective.)
                        (Operation::Insert(_), Operation::Delete(_)) => {
                            // No output: they cancel out.
                        }
                        // The outer arms above guarantee A ∈ {Retain, Insert}
                        // and B ∈ {Retain, Delete}, and Insert + Retain is
                        // handled before this match; this arm is unreachable
                        // in correct usage.
                        _ => unreachable!("compose: unexpected op pair ({a:?}, {b:?})"),
                    }

                    // Borrows from the inner match end here. Now advance both
                    // cursors by consuming the owned `a` and `b` values.
                    // `advance_op` returns the remainder of the op (if any),
                    // or pulls the next op from the iterator.
                    a_cur = advance_op(a, min, &mut a_ops);
                    b_cur = advance_op(b, min, &mut b_ops);
                }

                // ── Invariant violation ──────────────────────────────────────
                //
                // One side still has consuming ops (Retain or Delete for B,
                // Retain or Insert for A) while the other is exhausted.
                // This means self.len_after != other.len_before, which the
                // assert at the top of compose should have caught.
                (a, b) => {
                    panic!(
                        "compose: op sequences exhausted unevenly \
                         (a_cur={a:?}, b_cur={b:?})"
                    );
                }
            }
        }

        ChangeSet {
            ops: result,
            len_before,
            len_after,
        }
    }

    /// Fold a sequence of sequential changesets into one net transform, via
    /// balanced pairwise [`Self::compose`]: O(N log N) op-steps rather than
    /// a left fold's O(N²) (each step of a left fold composes the whole
    /// growing accumulator against the next entry, so the accumulator's own
    /// op count grows toward N over the fold, and `compose` allocates a
    /// fresh `Vec<Operation>` every time). A balanced fold instead halves the
    /// list each round, so no accumulator ever grows past twice the size of
    /// what it's being composed with. `None` for an empty input.
    ///
    /// Every adjacent boundary in `css` is checked exactly once, by
    /// whichever round's `compose` call first pairs those two neighbors,
    /// via `compose`'s own `assert_eq!(self.len_after, other.len_before)`.
    #[must_use]
    pub fn compose_all(css: impl IntoIterator<Item = ChangeSet>) -> Option<ChangeSet> {
        let mut css: Vec<ChangeSet> = css.into_iter().collect();
        while css.len() > 1 {
            let mut folded = Vec::with_capacity(css.len().div_ceil(2));
            let mut pairs = css.into_iter();
            while let Some(a) = pairs.next() {
                folded.push(match pairs.next() {
                    Some(b) => a.compose(b),
                    None => a,
                });
            }
            css = folded;
        }
        css.pop()
    }
}

mod builder;
pub use builder::ChangeSetBuilder;

mod diff_cs;
pub use diff_cs::changeset_from_line_diff;

#[cfg(test)]
mod tests;
