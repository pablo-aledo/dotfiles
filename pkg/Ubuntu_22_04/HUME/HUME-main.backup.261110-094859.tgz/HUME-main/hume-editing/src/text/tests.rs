use super::*;
use hume_rope::line::{ContentLine, RopeyLine};
use hume_rope::offset::{CharOffset, ExclusiveRange};

fn co(n: usize) -> CharOffset {
    CharOffset::new(n)
}

#[test]
fn successor_is_raw() {
    // successor is the changeset algebra path: it has a debug_assert for
    // the trailing \n but does not add one if missing. The caller
    // (ChangeSet::apply) is responsible for ensuring the invariant holds.
    let base = BufferText::from("x\n");
    let text = base.successor(Rope::from_str("hello\n"));
    assert_eq!(text.to_string(), "hello\n");
}

#[test]
fn a_successor_is_the_next_generation_of_the_same_lineage() {
    let base = BufferText::from("x\n");
    let next = base.successor(Rope::from_str("y\n"));
    assert_eq!(next.generation(), base.generation() + 1);
    assert_ne!(next.version(), base.version());
    assert_eq!(base.clone().version(), base.version());
}

#[test]
fn two_successors_of_one_snapshot_get_different_versions() {
    let base = BufferText::from("x\n");
    let a = base.successor(Rope::from_str("a\n"));
    let b = base.successor(Rope::from_str("b\n"));
    assert_ne!(a.version(), b.version());
}

#[test]
fn separately_built_texts_never_share_a_version() {
    let (a, b) = (BufferText::from("x\n"), BufferText::from("x\n"));
    assert_ne!(a.version(), b.version());
    let a_next = a.successor(Rope::from_str("y\n"));
    assert_ne!(a_next.version(), b.version());
    assert_ne!(BufferText::empty().version(), BufferText::empty().version());
}

#[test]
fn replaced_with_continues_the_lineage_and_detects_line_endings() {
    let base = BufferText::from("x\n");
    let next = base.replaced_with("a\r\nb\r\n");
    assert_eq!(next.to_string(), "a\nb\n");
    assert_eq!(next.line_ending(), LineEnding::CrLf);
    assert_eq!(next.generation(), base.generation() + 1);
}

#[test]
fn with_line_ending_keeps_content_and_version() {
    let base = BufferText::from("x\n");
    let crlf = base.clone().with_line_ending(LineEnding::CrLf);
    assert_eq!(crlf.line_ending(), LineEnding::CrLf);
    assert_eq!(crlf.version(), base.version());
    assert_eq!(crlf, base);
}

#[test]
fn empty_buffer() {
    let text = BufferText::empty();
    assert_eq!(text.len_chars(), 1); // structural trailing \n
    assert_eq!(text.ropey_line_count().get(), 2); // "\n" → line 0 = "\n", line 1 = ""
    assert!(text.is_empty());
    assert_eq!(text.to_string(), "\n");
}

#[test]
fn from_str_ascii() {
    let text = BufferText::from("hello\nworld");
    assert_eq!(text.len_chars(), 12); // "hello\nworld\n"
    assert_eq!(text.ropey_line_count().get(), 3); // line 0, line 1, trailing empty line
    assert!(!text.is_empty());
    assert_eq!(text.to_string(), "hello\nworld\n");
}

#[test]
fn from_str_lf_line_ending() {
    let text = BufferText::from("hello\n");
    assert_eq!(text.line_ending(), LineEnding::Lf);
}

#[test]
fn from_str_crlf_normalized() {
    let text = BufferText::from("hello\r\nworld\r\n");
    // \r stripped, content is pure LF
    assert_eq!(text.to_string(), "hello\nworld\n");
    assert_eq!(text.len_chars(), 12); // "hello\nworld\n"
    assert_eq!(text.line_ending(), LineEnding::CrLf);
}

#[test]
fn from_str_mixed_crlf_lf() {
    // Mixed: CRLF wins if any \r\n present.
    let text = BufferText::from("hello\r\nworld\n");
    assert_eq!(text.to_string(), "hello\nworld\n");
    assert_eq!(text.line_ending(), LineEnding::CrLf);
}

#[test]
fn from_str_bare_cr_normalized() {
    // Old Mac bare \r normalizes to \n, same as a \r\n pair.
    let text = BufferText::from("hello\rworld\n");
    assert_eq!(text.to_string(), "hello\nworld\n");
    assert_eq!(text.line_ending(), LineEnding::Lf);
}

#[test]
fn from_str_cr_then_crlf_fully_normalizes() {
    // "\r\r\n": the first '\r' (not itself followed by '\n'; its lookahead
    // is the second '\r') normalizes to '\n' on its own; the second '\r'
    // pairs with the following '\n' and normalizes to a single '\n' too.
    // Two real line breaks in, two '\n's out, and no literal '\r' survives.
    let text = BufferText::from("\r\r\n");
    assert_eq!(text.to_string(), "\n\n");
    // Detection only looks at the original input for a \r\n pair, which is
    // present (the second '\r' + the '\n'), so this still reads as CrLf.
    assert_eq!(text.line_ending(), LineEnding::CrLf);
}

// ── normalize_line_endings ───────────────────────────────────────────────

#[test]
fn normalize_line_endings_crlf() {
    assert_eq!(normalize_line_endings("a\r\nb"), "a\nb");
}

#[test]
fn normalize_line_endings_lone_cr() {
    assert_eq!(normalize_line_endings("a\rb"), "a\nb");
}

#[test]
fn normalize_line_endings_is_noop_on_lf() {
    assert_eq!(normalize_line_endings("a\nb"), "a\nb");
}

/// `buffer_content` is the text `BufferText::from` holds, and borrows a text
/// that already has LF line endings and a final line break.
#[test]
fn buffer_content_is_what_a_buffer_text_holds() {
    for text in ["", "a", "a\n", "a\r\nb", "a\rb\n", "a\nb\r\n", "\r"] {
        assert_eq!(
            buffer_content(text),
            BufferText::from(text).to_string(),
            "{text:?}"
        );
    }
    assert!(matches!(buffer_content("a\nb\n"), Cow::Borrowed(_)));
}

#[test]
fn from_str_trailing_newline() {
    // A trailing newline creates an extra empty line.
    let text = BufferText::from("hello\n");
    assert_eq!(text.ropey_line_count().get(), 2);
}

#[test]
fn line_tokens_at_starts_at_the_requested_line() {
    let text = BufferText::from("a\nb\nc\n");
    let tokens: Vec<_> = text.line_tokens_at(RopeyLine::new(1)).collect();
    assert_eq!(tokens, vec!["b\n", "c\n", ""]);
}

#[test]
fn line_tokens_back_from_starts_at_the_requested_line_itself() {
    let text = BufferText::from("a\nb\nc\n");
    let tokens: Vec<_> = text.line_tokens_back_from(RopeyLine::new(2)).collect();
    assert_eq!(tokens, vec!["c\n", "b\n", "a\n"]);
}

#[test]
fn line_tokens_back_from_zero_yields_only_that_line() {
    let text = BufferText::from("a\nb\n");
    let tokens: Vec<_> = text.line_tokens_back_from(RopeyLine::new(0)).collect();
    assert_eq!(tokens, vec!["a\n"]);
}

#[test]
fn line_tokens_back_from_walks_backward_across_a_chunk_boundary() {
    // ropey's leaf nodes are a few hundred bytes (`MAX_BYTES`/`MIN_BYTES`);
    // 300 short lines guarantee several chunks, so a full backward walk from
    // the last line must step from one chunk into the previous one, not just
    // seek within a single leaf.
    let source: String = (0..300).map(|i| format!("line {i}\n")).collect();
    let text = BufferText::from(source.as_str());
    let last = text.last_content_line();
    let tokens: Vec<_> = text.line_tokens_back_from(last.into()).collect();
    assert_eq!(tokens.len(), text.content_line_count().get());
    // Expected tokens are rebuilt from each line's own content, without
    // going through `line_tokens_back_from`.
    for (steps_back, token) in tokens.iter().enumerate() {
        assert_eq!(
            token.to_string(),
            format!("line {}\n", last.index() - steps_back)
        );
    }
}

#[test]
fn content_line_count_excludes_the_phantom_trailing_line() {
    assert_eq!(BufferText::from("\n").content_line_count().get(), 1);
    assert_eq!(BufferText::from("a\nb\nc\n").content_line_count().get(), 3);
}

#[test]
fn last_content_line_is_content_line_count_minus_one() {
    assert_eq!(BufferText::from("\n").last_content_line().index(), 0);
    assert_eq!(BufferText::from("a\nb\nc\n").last_content_line().index(), 2);
}

#[test]
fn from_str_unicode() {
    // "é" can be represented as a single char (U+00E9) or as two chars
    // (U+0065 + U+0301 combining accent). `BufferText::from` accepts whatever
    // Rust gives us. Here we use the precomposed form, one char.
    let text = BufferText::from("café");
    assert_eq!(text.len_chars(), 5); // c a f é \n
}

#[test]
fn line_to_char() {
    let text = BufferText::from("hello\nworld\nfoo");
    assert_eq!(text.line_to_char(RopeyLine::new(0)), co(0)); // "hello" starts at 0
    assert_eq!(text.line_to_char(RopeyLine::new(1)), co(6)); // "world" starts after "hello\n"
    assert_eq!(text.line_to_char(RopeyLine::new(2)), co(12)); // "foo" starts after "world\n"
}

#[test]
fn char_to_line() {
    let text = BufferText::from("hello\nworld\nfoo");
    assert_eq!(text.char_to_line(co(0)), ContentLine::new(0)); // 'h' is on line 0
    assert_eq!(text.char_to_line(co(5)), ContentLine::new(0)); // '\n' is still line 0
    assert_eq!(text.char_to_line(co(6)), ContentLine::new(1)); // 'w' is on line 1
    assert_eq!(text.char_to_line(co(12)), ContentLine::new(2)); // 'f' is on line 2
}

#[test]
fn char_to_line_clamps_positions_past_the_buffer_end() {
    // "hello\nworld\nfoo\n": len_chars = 16, last content line = 2.
    let text = BufferText::from("hello\nworld\nfoo");
    assert_eq!(text.char_to_line(co(text.len_chars())), ContentLine::new(2));
    assert_eq!(
        text.char_to_line(co(text.len_chars() + 5)),
        ContentLine::new(2)
    );
}

#[test]
fn char_to_line_on_empty_buffer_is_always_line_zero() {
    let text = BufferText::from("");
    assert_eq!(text.char_to_line(co(0)), ContentLine::new(0));
    assert_eq!(
        text.char_to_line(co(text.len_chars() + 5)),
        ContentLine::new(0)
    );
}

#[test]
fn insert_at_start() {
    let text = BufferText::from("world");
    let new = text.insert(0, "hello ");
    assert_eq!(new.to_string(), "hello world\n");
    // Original is unchanged: structural sharing.
    assert_eq!(text.to_string(), "world\n");
}

#[test]
fn insert_at_end() {
    // Insert before the trailing \n (position 5 in "hello\n").
    let text = BufferText::from("hello");
    let new = text.insert(5, " world");
    assert_eq!(new.to_string(), "hello world\n");
}

#[test]
fn insert_in_middle() {
    let text = BufferText::from("helo");
    let new = text.insert(3, "l"); // "hel" + "l" + "o\n"
    assert_eq!(new.to_string(), "hello\n");
}

#[test]
fn remove_whole() {
    let text = BufferText::from("hello");
    let new = text.remove(0..5); // removes "hello", leaving "\n"
    assert_eq!(new.to_string(), "\n");
    assert!(new.is_empty());
    assert_eq!(text.to_string(), "hello\n"); // original unchanged
}

#[test]
fn remove_range() {
    let text = BufferText::from("hello world");
    let new = text.remove(5..11); // remove " world"
    assert_eq!(new.to_string(), "hello\n");
}

#[test]
fn insert_then_remove_is_identity() {
    let original = BufferText::from("hello world");
    let after_insert = original.insert(5, " beautiful");
    let restored = after_insert.remove(5..15);
    assert_eq!(restored, original);
}

#[test]
fn slice() {
    let text = BufferText::from("hello world");
    let s: String = text
        .slice(ExclusiveRange::new(CharOffset::new(6), CharOffset::new(11)))
        .to_string();
    assert_eq!(s, "world");
}

#[test]
fn equality() {
    let a = BufferText::from("hello");
    let b = BufferText::from("hello");
    let c = BufferText::from("world");
    assert_eq!(a, b);
    assert_ne!(a, c);
}

// ── char_at boundary cases ────────────────────────────────────────────────

#[test]
fn char_at_first_position() {
    let text = BufferText::from("hello");
    assert_eq!(text.char_at(co(0)), Some('h'));
}

#[test]
fn char_at_last_position() {
    // "hello" + structural '\n' → last char is '\n' at len_chars()-1.
    let text = BufferText::from("hello");
    assert_eq!(
        text.char_at(CharOffset::new(text.len_chars() - 1)),
        Some('\n')
    );
}

#[test]
fn char_at_out_of_bounds() {
    let text = BufferText::from("hello");
    assert_eq!(text.char_at(CharOffset::new(text.len_chars())), None);
}

// ── single-char buffer ────────────────────────────────────────────────────

#[test]
fn single_char_buffer_has_two_chars() {
    // "x" gets the structural '\n' appended → len_chars() == 2.
    let text = BufferText::from("x");
    assert_eq!(text.len_chars(), 2);
    assert!(!text.is_empty());
    assert_eq!(text.char_at(co(0)), Some('x'));
    assert_eq!(text.char_at(co(1)), Some('\n'));
}

// ── remove with empty range ───────────────────────────────────────────────

#[test]
fn remove_empty_range_is_identity() {
    let text = BufferText::from("hello");
    let same = text.remove(3..3);
    assert_eq!(same.to_string(), "hello\n");
}

// ── insert/remove with multi-byte content ─────────────────────────────────

#[test]
fn insert_grapheme_cluster() {
    // Insert a two-char grapheme (e + combining acute) at position 0.
    let text = BufferText::from("hello");
    let new = text.insert(0, "e\u{0301}");
    // 'e' + U+0301 + "hello" + '\n' = 8 chars.
    assert_eq!(new.len_chars(), 8);
    assert_eq!(new.char_at(co(0)), Some('e'));
    assert_eq!(new.char_at(co(1)), Some('\u{0301}'));
    assert_eq!(new.char_at(co(2)), Some('h'));
}

#[test]
fn remove_grapheme_cluster_range() {
    // Remove a two-char grapheme cluster.
    let text = BufferText::from("e\u{0301}hello");
    // text: 'e'(0) U+0301(1) 'h'(2) 'e'(3) ... '\n'(7) = 8 chars.
    let new = text.remove(0..2); // remove the 'e' + combining accent
    assert_eq!(new.to_string(), "hello\n");
}

#[test]
fn a_line_is_blank_when_it_holds_only_whitespace() {
    let text = BufferText::from("\n  \t\n  x\nx\n");
    let blank: Vec<bool> = (0..4)
        .map(|line| text.lines().is_blank(ContentLine::new(line)))
        .collect();
    assert_eq!(blank, [true, true, false, false]);
}
