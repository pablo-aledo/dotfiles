use std::time::{Duration, SystemTime};

use hume_rope::offset::CharOffset;

use super::children::Children;
use super::*;
use crate::changeset::ChangeSetBuilder;
use crate::selection::{Selection, SelectionSet};
use crate::state::EditState;
use crate::text::BufferText;
use hume_core::PaneId;

/// The time every test history starts at.
pub(super) fn start_time() -> SystemTime {
    SystemTime::UNIX_EPOCH + Duration::from_secs(1_700_000_000)
}

/// A cursor at offset `pos` of one text shared by every call, wide enough
/// that every char below 60 starts a cluster, so two calls with one `pos`
/// give equal sets.
fn sel_at(pos: usize) -> SelectionSet {
    static TEXT: std::sync::OnceLock<BufferText> = std::sync::OnceLock::new();
    let text = TEXT.get_or_init(|| BufferText::from(" ".repeat(60).as_str()));
    let at = text.snap(CharOffset::new(pos));
    assert_eq!(at.offset(), CharOffset::new(pos));
    EditState::with_cursor(text.clone(), at).into_selections()
}

/// Build a simple ChangeSet that inserts `text` at offset 0 in a buffer
/// of `buf_len` characters.
fn insert_cs(buf_len: usize, text: &str) -> ChangeSet {
    let mut b = ChangeSetBuilder::new(CharOffset::new(buf_len));
    b.insert(text);
    b.retain_rest();
    b.finish()
}

/// Record `forward` in `h` at [`start_time`], as an edit of a text of blanks as
/// long as `forward` expects.
fn record(
    h: &mut History,
    owner: Option<PaneId>,
    forward: ChangeSet,
    pre: SelectionSet,
    post: SelectionSet,
) -> Option<RevisionId> {
    record_at(h, start_time(), owner, forward, pre, post)
}

/// [`record`], made at `at`.
fn record_at(
    h: &mut History,
    at: SystemTime,
    owner: Option<PaneId>,
    forward: ChangeSet,
    pre: SelectionSet,
    post: SelectionSet,
) -> Option<RevisionId> {
    let text = BufferText::from(format!("{}\n", " ".repeat(forward.len_before() - 1)).as_str());
    h.record(owner, forward, &text, pre, post, at)
}

// ── Basic undo/redo ───────────────────────────────────────────────────────

#[test]
fn new_history_has_one_revision() {
    let h = History::new(start_time());
    assert_eq!(h.len(), 1);
    assert!(!h.can_undo());
    assert!(!h.can_redo());
}

#[test]
fn record_advances_current() {
    let mut h = History::new(start_time());
    let cs = insert_cs(6, "x");
    record(&mut h, None, cs, sel_at(0), sel_at(1));
    assert_eq!(h.len(), 2);
    assert!(h.can_undo());
    assert!(!h.can_redo());
}

#[test]
fn undo_returns_inverse_and_moves_to_parent() {
    let mut h = History::new(start_time());
    let cs = insert_cs(6, "x");
    record(&mut h, None, cs, sel_at(0), sel_at(1));

    let txn = h.undo().expect("should have something to undo");
    // The inverse Transaction's selection is the pre-edit selection (sel_at(0)).
    assert_eq!(*txn.selection(), sel_at(0));
    assert!(!h.can_undo()); // back at root
}

#[test]
fn undo_at_root_returns_none() {
    let mut h = History::new(start_time());
    assert!(h.undo().is_none());
}

#[test]
fn redo_returns_forward_and_moves_to_child() {
    let mut h = History::new(start_time());
    let cs = insert_cs(6, "x");
    record(&mut h, None, cs.clone(), sel_at(0), sel_at(1));

    h.undo(); // back to root

    let txn = h.redo().expect("should have something to redo");
    assert_eq!(*txn.selection(), sel_at(1)); // post-edit selection
    assert!(!h.can_redo()); // at leaf again
}

#[test]
fn redo_with_no_children_returns_none() {
    let mut h = History::new(start_time());
    assert!(h.redo().is_none());
}

#[test]
fn undo_redo_roundtrip() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "x"), sel_at(0), sel_at(1));
    record(&mut h, None, insert_cs(7, "y"), sel_at(1), sel_at(2));

    assert_eq!(h.current, RevisionId(2));
    h.undo();
    assert_eq!(h.current, RevisionId(1));
    h.undo();
    assert_eq!(h.current, RevisionId(0));
    h.redo();
    assert_eq!(h.current, RevisionId(1));
    h.redo();
    assert_eq!(h.current, RevisionId(2));
    assert!(!h.can_redo());
}

#[test]
fn branching_preserves_old_path() {
    // Record A (rev 1) then B (rev 2). Undo to root. Record C (rev 3).
    // Tree:  root → A → B
    //            ↘ C
    // Redo from root should go to C (last child), not B.
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev 1
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev 2
    h.undo(); // to rev 1
    h.undo(); // to root
    record(&mut h, None, insert_cs(6, "c"), sel_at(0), sel_at(1)); // rev 3

    // Tree has 4 nodes: root, A, B, C.
    assert_eq!(h.len(), 4);

    // current is rev 3.
    assert_eq!(h.current, RevisionId(3));

    // Undo to root.
    h.undo();
    assert_eq!(h.current, RevisionId(0));

    // Root has 2 children: A (rev 1) and C (rev 3). Redo goes to last = C.
    let txn = h.redo().expect("should redo to C");
    assert_eq!(*txn.selection(), sel_at(1)); // C's post-edit selection
    assert_eq!(h.current, RevisionId(3));

    // From C, undo gets us back to root, then we can redo to C again.
    h.undo();
    // Root still has children, so can redo.
    assert!(h.can_redo());
}

// ── undo_n / redo_n (composed multi-step walk) ───────────────────────────

#[test]
fn undo_n_walks_multiple_steps_and_lands_on_target() {
    let mut h = History::new(start_time());
    for i in 0..5 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    assert_eq!(h.current, RevisionId(5));

    let txns = h.undo_n(3);
    assert_eq!(txns.len(), 3, "three real ancestors are available");
    assert_eq!(h.current, RevisionId(2));
    // The last transaction in the up-path is rev3's own inverse, whose
    // selection is rev3's pre-edit selection.
    assert_eq!(*txns.last().expect("non-empty").selection(), sel_at(2));
}

#[test]
fn undo_n_clamps_at_root_short_of_the_requested_count() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2));

    let txns = h.undo_n(10);
    assert_eq!(txns.len(), 2, "only 2 ancestors exist above the root");
    assert_eq!(h.current, RevisionId(0));
}

#[test]
fn undo_n_zero_count_is_empty_and_current_unmoved() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    let before = h.current;

    assert!(h.undo_n(0).is_empty());
    assert_eq!(h.current, before);
}

#[test]
fn undo_n_at_root_is_empty() {
    let mut h = History::new(start_time());
    assert!(h.undo_n(3).is_empty());
    assert_eq!(h.current, RevisionId(0));
}

#[test]
fn redo_n_walks_multiple_steps_and_lands_on_target() {
    let mut h = History::new(start_time());
    for i in 0..4 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    for _ in 0..4 {
        h.undo();
    }
    assert_eq!(h.current, RevisionId(0));

    let txns = h.redo_n(3);
    assert_eq!(txns.len(), 3);
    assert_eq!(h.current, RevisionId(3));
    assert_eq!(*txns.last().expect("non-empty").selection(), sel_at(3));
}

#[test]
fn redo_n_clamps_at_leaf_short_of_the_requested_count() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2));
    h.undo();
    h.undo();

    let txns = h.redo_n(10);
    assert_eq!(txns.len(), 2, "only 2 descendants exist below the root");
    assert_eq!(h.current, RevisionId(2));
}

#[test]
fn redo_n_follows_last_walked_child_through_multiple_hops() {
    // branching_history: root → rev1 → rev2 → rev3, then rev1 gains a second
    // child rev4 (the newest, so rev1's redo target). Current is rev4 after
    // construction.
    let mut h = branching_history();
    h.undo(); // rev4 -> rev1
    h.undo(); // rev1 -> root
    assert_eq!(h.current, RevisionId(0));

    let txns = h.redo_n(2);
    assert_eq!(txns.len(), 2);
    assert_eq!(
        h.current,
        RevisionId(4),
        "must follow rev1's redo child (rev4), not the older rev2"
    );
}

// ── goto_revision ─────────────────────────────────────────────────────────

/// Build a branching tree for goto tests:
///
/// ```text
///      * rev3
///      |
/// *r4  * rev2
/// |    |
/// `----* rev1
///      |
///      * root (rev0)
/// ```
///
/// rev1 = first edit, rev2 = second edit, rev3 = third edit.
/// Undo to rev1, then record rev4 = branch C.
fn branching_history() -> History {
    branching_history_at([start_time(); 5])
}

/// [`branching_history`], with the root and each revision made at its
/// entry of `times`, in id order.
fn branching_history_at([root, a, b, c, d]: [SystemTime; 5]) -> History {
    let mut h = History::new(root);
    record_at(&mut h, a, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1
    record_at(&mut h, b, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev2
    record_at(&mut h, c, None, insert_cs(8, "c"), sel_at(2), sel_at(3)); // rev3
    h.undo(); // back to rev2
    h.undo(); // back to rev1
    record_at(&mut h, d, None, insert_cs(7, "d"), sel_at(1), sel_at(9)); // rev4 (branch)
    h
}

#[test]
fn goto_current_revision_walks_nothing() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    let current = h.current;
    let txns = h
        .goto_revision(current)
        .expect("the current revision is a known id");
    assert!(txns.is_empty());
    assert_eq!(h.current, current);
}

#[test]
fn goto_out_of_bounds_returns_none() {
    let mut h = History::new(start_time());
    assert!(h.goto_revision(RevisionId(999)).is_none());
}

#[test]
fn goto_parent_is_one_inverse() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    let rev0 = RevisionId(0);
    let txns = h.goto_revision(rev0).expect("should move to parent");
    // Should be one transaction: the inverse of rev1.
    assert_eq!(txns.len(), 1);
    // After goto, current is root.
    assert_eq!(h.current, RevisionId(0));
}

#[test]
fn goto_child_is_one_forward() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    h.undo(); // back to root
    let rev1 = RevisionId(1);
    let txns = h.goto_revision(rev1).expect("should move to child");
    assert_eq!(txns.len(), 1);
    assert_eq!(h.current, RevisionId(1));
}

#[test]
fn goto_across_branches_via_lca() {
    // Tree: root → rev1 → rev2 → rev3
    //                  ↘ rev4 (current)
    // Jump from rev4 to rev3: up to rev1 (LCA), down to rev2, down to rev3.
    // Expected: 1 inverse (rev4) + 2 forwards (rev2, rev3) = 3 transactions.
    let mut h = branching_history();
    assert_eq!(h.current, RevisionId(4));

    let txns = h
        .goto_revision(RevisionId(3))
        .expect("should navigate across branches");
    assert_eq!(txns.len(), 3);
    assert_eq!(h.current, RevisionId(3));
}

fn changes_of(path: RevisionPath) -> ChangeSet {
    match path {
        RevisionPath::Changes(cs) => cs,
        RevisionPath::Here => panic!("expected a path, got Here"),
        RevisionPath::Unknown => panic!("expected a path, got Unknown"),
    }
}

#[test]
fn changes_to_across_branches_maps_current_text_to_target_text() {
    let h = branching_history();
    // rev4's text is "dahello\n"; rev3's is "cbahello\n".
    let cs = changes_of(h.changes_to(RevisionId(3)));
    let at_rev4 = BufferText::from("dahello\n");
    let at_rev3 = cs.apply(&at_rev4).expect("changeset fits rev4's text");
    assert_eq!(at_rev3.to_string(), "cbahello\n");
}

#[test]
fn changes_to_parent_undoes_the_last_edit() {
    let h = branching_history();
    let cs = changes_of(h.changes_to(RevisionId(1)));
    let at_rev1 = cs
        .apply(&BufferText::from("dahello\n"))
        .expect("changeset fits rev4's text");
    assert_eq!(at_rev1.to_string(), "ahello\n");
}

#[test]
fn changes_to_leaves_current_redo_and_change_seq_alone() {
    let mut h = branching_history();
    let seq = h.change_seq();
    let _ = h.changes_to(RevisionId(3));
    assert_eq!(h.current_id(), RevisionId(4));
    assert_eq!(h.change_seq(), seq);
    // Redo from rev1 still follows rev4, the branch last walked, not rev3.
    h.undo();
    assert_eq!(h.current_id(), RevisionId(1));
    h.redo();
    assert_eq!(h.current_id(), RevisionId(4));
}

#[test]
fn changes_to_current_is_here() {
    let h = branching_history();
    assert!(matches!(h.changes_to(h.current_id()), RevisionPath::Here));
}

#[test]
fn changes_to_unknown_id_is_unknown() {
    let h = branching_history();
    assert!(matches!(
        h.changes_to(RevisionId(999)),
        RevisionPath::Unknown
    ));
}

#[test]
fn goto_distant_ancestor() {
    let mut h = History::new(start_time());
    for i in 0..5 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    // Jump from rev5 to root in one call: 5 inverses.
    let txns = h
        .goto_revision(RevisionId(0))
        .expect("should navigate to root");
    assert_eq!(txns.len(), 5);
    assert_eq!(h.current, RevisionId(0));
}

#[test]
fn goto_distant_descendant() {
    let mut h = History::new(start_time());
    for i in 0..5 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    h.undo();
    h.undo();
    h.undo();
    h.undo();
    h.undo(); // back to root
    assert_eq!(h.current, RevisionId(0));

    // Jump from root to rev5 in one call: 5 forwards.
    let txns = h
        .goto_revision(RevisionId(5))
        .expect("should navigate to leaf");
    assert_eq!(txns.len(), 5);
    assert_eq!(h.current, RevisionId(5));
}

#[test]
fn multiple_sequential_undos() {
    let mut h = History::new(start_time());
    for i in 0..5 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    assert_eq!(h.len(), 6); // root + 5 revisions
    assert_eq!(h.current, RevisionId(5));

    for expected in (0..5).rev() {
        h.undo();
        assert_eq!(h.current, RevisionId(expected));
    }
    assert!(!h.can_undo());
}

// ── undo-levels cap ──────────────────────────────────────────────────────

#[test]
fn cap_zero_never_evicts() {
    // A cap of 0 means unlimited. Trimming here would leave 1 revision
    // instead of 6.
    let mut h = History::new(start_time());
    for i in 0..5 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    assert_eq!(h.len(), 6);
}

#[test]
fn set_undo_levels_does_not_trim_until_next_record() {
    // Lowering the cap takes effect on the next record. An immediate trim
    // would drop len() to 3 right after the call.
    let mut h = History::new(start_time());
    for i in 0..5 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
    }
    assert_eq!(h.len(), 6);

    h.set_undo_levels(2);
    assert_eq!(h.len(), 6, "lowering the cap must not retroactively trim");

    let promoted = record(&mut h, None, insert_cs(11, "x"), sel_at(5), sel_at(6));
    assert_eq!(h.len(), 3); // root + last 2 revisions
    assert!(promoted.is_some());
}

#[test]
fn linear_chain_promotes_oldest() {
    // Promoting `a` into the root drops len() from 4 (root+a+b+c) to 3 and
    // leaves `a` with no parent at all.
    let mut h = History::new(start_time());
    h.set_undo_levels(2);
    let a = record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // a = RevisionId(1)
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // b
    let promoted = record(&mut h, None, insert_cs(8, "c"), sel_at(2), sel_at(3)); // c

    assert_eq!(h.len(), 3); // root(now=a) + b + c
    assert_eq!(promoted, Some(RevisionId(1))); // a promoted into root
    assert_eq!(a, None); // a's own record didn't trigger a promotion
    assert!(h.parent(RevisionId(1)).is_none()); // a is gone, not just re-parented

    h.undo(); // c -> b
    h.undo(); // b -> new root (was a's parent slot, now root itself)
    assert!(!h.can_undo());
}

#[test]
fn cap_one_current_never_evicted() {
    // Current is never evicted, so len() holds at 2 (root + current).
    let mut h = History::new(start_time());
    h.set_undo_levels(1);
    for i in 0..4 {
        record(
            &mut h,
            None,
            insert_cs(6 + i, "x"),
            sel_at(i),
            sel_at(i + 1),
        );
        assert_eq!(h.len(), 2);
    }
    h.undo();
    assert!(h.can_redo());
}

#[test]
fn oldest_branch_evicted_first() {
    // Tree: root -> A (rev1) -> B (rev2); undo to A; record C (rev3, branch).
    // current is under C. Capping to 1 must drop the whole {A, B} branch
    // and promote C, not touch C's own subtree.
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1 = A
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev2 = B
    h.undo(); // back to A
    h.undo(); // back to root
    h.set_undo_levels(1);
    record(&mut h, None, insert_cs(6, "c"), sel_at(0), sel_at(1)); // rev3 = C

    assert_eq!(h.len(), 2); // root(now=C) + nothing else
    assert!(h.parent(RevisionId(1)).is_none()); // A evicted
    assert!(h.parent(RevisionId(2)).is_none()); // B evicted (subtree of A)
    assert!(h.goto_revision(RevisionId(1)).is_none());
}

#[test]
fn protected_branch_skipped() {
    // Tree: root -> A (rev1) -> B (rev2, current); undo to root; record C
    // (rev3, branch), undo to root; record D (rev4, branch, current).
    // Root has 3 children [A, C, D] (chronological). D is on current's
    // path. Eviction must remove A's branch (oldest non-protected), not D's.
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1 = A
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev2 = B
    h.undo();
    h.undo(); // back to root
    record(&mut h, None, insert_cs(6, "c"), sel_at(0), sel_at(1)); // rev3 = C
    h.undo(); // back to root
    h.set_undo_levels(2);
    let promoted = record(&mut h, None, insert_cs(6, "d"), sel_at(0), sel_at(1)); // rev4 = D

    // Non-root count must be <= 2: A's branch {A, B} (2 nodes) discarded,
    // leaving {C, D} = 2 nodes. No promotion needed since root already had
    // more than one child.
    assert_eq!(h.len(), 3);
    assert!(promoted.is_none());
    assert!(h.parent(RevisionId(1)).is_none()); // A evicted
    assert!(h.parent(RevisionId(2)).is_none()); // B evicted
    assert!(h.parent(RevisionId(3)).is_some()); // C survives
    assert_eq!(h.current, RevisionId(4)); // D survives, still current
}

#[test]
fn subtree_eviction_may_overshoot() {
    // Tree: root -> A -> B -> C (chain of 3), undo to root, record D
    // (branch, current). Cap 3 with 4 non-root nodes triggers eviction;
    // discarding the whole {A, B, C} branch in one step drops to 1 non-root
    // node, well under the cap of 3, matching Vim's overshoot behavior.
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1 = A
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev2 = B
    record(&mut h, None, insert_cs(8, "c"), sel_at(2), sel_at(3)); // rev3 = C
    h.undo();
    h.undo();
    h.undo(); // back to root
    h.set_undo_levels(3);
    record(&mut h, None, insert_cs(6, "d"), sel_at(0), sel_at(1)); // rev4 = D

    assert_eq!(h.len(), 2); // root + D only; overshot below the cap of 3
}

#[test]
fn promotion_reports_last_promoted_only() {
    // A single record call can trigger multiple promotions in the trim
    // loop (linear chain with a very low cap). Only the final promoted id
    // is meaningful (it's the node root now represents), so earlier
    // promotions in the same loop must not leak out.
    let mut h = History::new(start_time());
    h.set_undo_levels(1);
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // a: len 2, no trim
    let promoted_b = record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // b promotes a
    assert_eq!(promoted_b, Some(RevisionId(1))); // a
    let promoted_c = record(&mut h, None, insert_cs(8, "c"), sel_at(2), sel_at(3)); // c promotes b
    assert_eq!(promoted_c, Some(RevisionId(2))); // b, not a
    assert_eq!(h.len(), 2);
}

// ── Time-travel step resolution (:earlier/:later) ────────────────────────────

fn mins(n: u64) -> Duration {
    Duration::from_secs(n * 60)
}

/// `n` minutes after [`start_time`].
fn at(n: u64) -> SystemTime {
    start_time() + mins(n)
}

/// When the aged histories below are queried.
fn now() -> SystemTime {
    at(20)
}

/// Linear chain root(20m) → rev1(15m) → rev2(8m) → rev3(1m, current), as
/// old as of [`now`].
fn aged_chain() -> History {
    let mut h = History::new(at(0));
    record_at(&mut h, at(5), None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1
    record_at(
        &mut h,
        at(12),
        None,
        insert_cs(7, "b"),
        sel_at(1),
        sel_at(2),
    ); // rev2
    record_at(
        &mut h,
        at(19),
        None,
        insert_cs(8, "c"),
        sel_at(2),
        sel_at(3),
    ); // rev3
    h
}

#[test]
fn undo_steps_older_than_walks_to_state_as_of_age() {
    let h = aged_chain();
    assert_eq!(
        h.undo_steps_older_than(mins(5), now()),
        Ok(1),
        ":earlier 5m from 1m-old tip must step once onto rev2 (8m)"
    );
    assert_eq!(
        h.undo_steps_older_than(mins(10), now()),
        Ok(2),
        ":earlier 10m must step twice onto rev1 (15m)"
    );
    assert_eq!(
        h.undo_steps_older_than(mins(30), now()),
        Err(3),
        ":earlier older than the root is unsatisfiable: Err carries the real depth (3), \
         for the shared undo loop's own exhaustion check to report"
    );
    assert_eq!(
        h.undo_steps_older_than(Duration::ZERO, now()),
        Ok(0),
        ":earlier 0s is already satisfied: no steps"
    );
}

#[test]
fn redo_steps_newer_than_walks_last_child_chain() {
    let mut h = aged_chain();
    h.undo();
    h.undo(); // back to rev1 (15m)
    assert_eq!(
        h.redo_steps_newer_than(mins(5), now()),
        Ok(1),
        ":later 5m from rev1 must step once onto rev2 (8m), stopping before rev3 (1m)"
    );
    assert_eq!(
        h.redo_steps_newer_than(Duration::ZERO, now()),
        Err(2),
        ":later 0s walks the whole last-child chain to the tip (2 real hops), still \
         older than now: unsatisfiable, Err carries the real hop count"
    );
    assert_eq!(
        h.redo_steps_newer_than(mins(30), now()),
        Ok(0),
        ":later older than every descendant is already satisfied: no steps"
    );
}

/// A leaf has nothing newer to redo onto regardless of the request: the
/// tip's own age must never be compared against `age` the way a genuine
/// over-travel (walking onto a leaf that is still too old) is.
/// `undo_steps_older_than` has no such case: its clamp only ever fires from
/// inside the walk, at the root.
///
/// Comparing the *current* revision's own age against `age` when it has no
/// children would return `Err(1)`, a false "Already at newest change" extra
/// step, where `Ok(0)` is correct.
#[test]
fn redo_steps_newer_than_at_the_tip_is_satisfied_regardless_of_the_tip_s_own_age() {
    let h = aged_chain(); // current = rev3 (tip), 1m old, no children
    assert_eq!(
        h.redo_steps_newer_than(Duration::from_secs(5), now()),
        Ok(0),
        ":later 5s at the tip is already satisfied; there is nothing newer to redo \
         onto, no matter how old the tip itself is relative to the requested age"
    );
}

#[test]
fn redo_steps_newer_than_follows_last_walked_child() {
    let mut h = aged_chain();
    h.undo();
    h.undo(); // back to rev1
    record_at(
        &mut h,
        at(18),
        None,
        insert_cs(7, "d"),
        sel_at(1),
        sel_at(9),
    ); // rev4, last child of rev1
    h.undo(); // back to rev1, the fork point the queries run from
    // Sibling rev2 is 8m old but is not rev1's redo target; the count must
    // follow rev4 (2m), so `:later 5m` takes no steps.
    assert_eq!(
        h.redo_steps_newer_than(mins(5), now()),
        Ok(0),
        ":later must follow the redo child (rev4, 2m), not the older sibling"
    );
    assert_eq!(
        h.redo_steps_newer_than(Duration::ZERO, now()),
        Err(1),
        ":later 0s steps once along the rev4 branch (1 real hop), whose tip is still \
         older than now: unsatisfiable, Err carries the real hop count"
    );
    h.redo();
    assert_eq!(
        h.current,
        RevisionId(4),
        "the counted step must land on the redo child"
    );
}

// ── Redo follows the last-walked child ───────────────────────────────────────

#[test]
fn undo_makes_the_undone_child_the_redo_target() {
    let mut h = History::new(start_time());
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1
    h.undo();
    record(&mut h, None, insert_cs(6, "c"), sel_at(0), sel_at(2)); // rev2, newer sibling
    h.goto_revision(RevisionId(1));
    h.undo();
    assert_eq!(h.current, History::ROOT);

    h.redo();
    assert_eq!(h.current, RevisionId(1));
}

#[test]
fn goto_into_older_branch_redirects_redo_along_it() {
    // branching_history: rev1 has children rev2 (→ rev3) and rev4; current is rev4.
    let mut h = branching_history();
    h.goto_revision(RevisionId(3));
    h.undo_n(2);
    assert_eq!(h.current, RevisionId(1));

    let txns = h.redo_n(2);
    assert_eq!(txns.len(), 2);
    assert_eq!(h.current, RevisionId(3));
}

#[test]
fn redo_steps_newer_than_follows_the_walked_branch() {
    let mut h = aged_chain();
    h.undo();
    h.undo(); // rev1
    record_at(
        &mut h,
        at(18),
        None,
        insert_cs(7, "d"),
        sel_at(1),
        sel_at(9),
    ); // rev4
    h.goto_revision(RevisionId(2));
    h.undo(); // rev1, redo target now rev2 (8m), not rev4 (2m)

    assert_eq!(
        h.redo_steps_newer_than(mins(5), now()),
        Ok(1),
        ":later 5m must step onto rev2 (8m) and stop before rev3 (1m)"
    );
    h.redo();
    assert_eq!(h.current, RevisionId(2));
}

#[test]
fn promotion_carries_the_redo_target_into_the_root() {
    let mut h = History::new(start_time());
    h.set_undo_levels(3);
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev2
    h.undo();
    record(&mut h, None, insert_cs(7, "c"), sel_at(1), sel_at(3)); // rev3
    h.goto_revision(RevisionId(2));
    let promoted = record(&mut h, None, insert_cs(8, "d"), sel_at(2), sel_at(4)); // rev4
    assert_eq!(promoted, Some(RevisionId(1)));
    h.undo_n(2);
    assert_eq!(h.current, History::ROOT);

    h.redo();
    assert_eq!(h.current, RevisionId(2));
}

#[test]
fn children_push_makes_newest_the_redo_target() {
    let mut c = Children::default();
    assert_eq!(c.redo(), None);
    c.push(RevisionId(1));
    c.push(RevisionId(2));
    assert_eq!(c.redo(), Some(RevisionId(2)));
    assert_eq!(c.iter().collect::<Vec<_>>(), [RevisionId(1), RevisionId(2)]);
    assert_eq!(c.len(), 2);
}

#[test]
fn children_remove_of_redo_target_falls_back_to_newest_remaining() {
    let mut c = Children::default();
    c.push(RevisionId(1));
    c.push(RevisionId(2));
    c.push(RevisionId(3));
    c.set_redo(RevisionId(2));

    c.remove(RevisionId(1));
    assert_eq!(
        c.redo(),
        Some(RevisionId(2)),
        "a non-target removal keeps the target"
    );

    c.remove(RevisionId(2));
    assert_eq!(c.redo(), Some(RevisionId(3)));

    c.remove(RevisionId(3));
    assert_eq!(c.redo(), None);
    assert_eq!(c.len(), 0);
}

#[test]
#[should_panic(expected = "redo target must be a child")]
fn children_set_redo_rejects_a_non_child() {
    let mut c = Children::default();
    c.push(RevisionId(1));
    c.set_redo(RevisionId(7));
}

// ── Enumeration and ids ──────────────────────────────────────────────────────

#[test]
fn revision_id_checked_accepts_live_and_rejects_evicted_ids() {
    let mut h = History::new(start_time());
    h.set_undo_levels(1);
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1)); // rev1
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2)); // rev2, promotes rev1

    assert_eq!(RevisionId::checked(&h, 0), Some(History::ROOT));
    assert_eq!(RevisionId::checked(&h, 1), None, "rev1 was promoted away");
    let live = RevisionId::checked(&h, 2).expect("rev2 is live");
    assert_eq!(live.index(), 2);
    assert_eq!(RevisionId::checked(&h, 99), None);
}

#[test]
fn nodes_enumerate_every_revision_in_id_order_with_parent_and_age() {
    // rev1 → rev2 → rev3, rev1 → rev4
    let h = branching_history_at([at(0), at(4), at(8), at(12), at(16)]);
    let nodes = h.nodes(now());

    let shape: Vec<_> = nodes
        .iter()
        .map(|n| (n.id().index(), n.parent().map(RevisionId::index)))
        .collect();
    assert_eq!(
        shape,
        [
            (0, None),
            (1, Some(0)),
            (2, Some(1)),
            (3, Some(2)),
            (4, Some(1))
        ]
    );
    for (i, node) in nodes.iter().enumerate() {
        assert_eq!(node.age(), mins(20 - 4 * i as u64), "rev{i}");
    }
}

#[test]
fn change_seq_moves_on_every_navigation_and_record_only() {
    let mut h = History::new(start_time());
    let mut seen = h.change_seq();
    let mut moved = |h: &History| {
        let now = h.change_seq();
        let changed = now != seen;
        seen = now;
        changed
    };

    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    assert!(moved(&h), "record");
    h.undo();
    assert!(moved(&h), "undo");
    assert!(h.undo().is_none());
    assert!(!moved(&h), "undo at the root");
    h.redo();
    assert!(moved(&h), "redo");
    assert!(h.redo().is_none());
    assert!(!moved(&h), "redo at a leaf");
    h.goto_revision(h.current);
    assert!(!moved(&h), "goto the current revision");
    h.undo();
    moved(&h);
    h.goto_revision(RevisionId(1));
    assert!(moved(&h), "goto another revision");
    h.undo_n(0);
    h.set_undo_levels(5);
    assert!(!moved(&h), "a zero-step walk and a cap change");
}

// ── Promotion age, reset counter ─────────────────────────────────────────────

#[test]
fn promotion_gives_the_root_the_age_of_the_promoted_state() {
    let mut h = History::new(at(0));
    h.set_undo_levels(1);
    record_at(
        &mut h,
        at(10),
        None,
        insert_cs(6, "a"),
        sel_at(0),
        sel_at(1),
    );

    let promoted = record_at(
        &mut h,
        at(20),
        None,
        insert_cs(7, "b"),
        sel_at(1),
        sel_at(2),
    );

    assert_eq!(promoted, Some(RevisionId(1)));
    let root = &h.nodes(now())[0];
    assert_eq!(root.id, History::ROOT);
    assert_eq!(
        root.age,
        mins(10),
        "the root holds the promoted revision's state, so it is that old"
    );
}

#[test]
fn reset_keeps_change_seq_strictly_increasing() {
    let mut h = History::new(start_time());
    h.set_undo_levels(5);
    record(&mut h, None, insert_cs(6, "a"), sel_at(0), sel_at(1));
    record(&mut h, None, insert_cs(7, "b"), sel_at(1), sel_at(2));
    let before = h.change_seq();

    h.reset(start_time());

    assert!(h.change_seq() > before);
    assert_eq!(h.len(), 1);
    assert_eq!(h.current_id(), History::ROOT);
    assert_eq!(h.undo_levels(), 5);
    let after_reset = h.change_seq();
    h.reset(start_time());
    assert_eq!(
        h.change_seq(),
        after_reset,
        "resetting a root-only tree is not a change"
    );
    record(&mut h, None, insert_cs(6, "c"), sel_at(0), sel_at(1));
    assert!(h.change_seq() > after_reset);
}

// ── Saved selections ──────────────────────────────────────────────────────

/// `text` with the chars in `[from, to)` replaced by `insert`, recorded in
/// `h` by `owner` with `before` as the selection the edit was made with and
/// a cursor at `from` as the one it left. Returns the text it produces.
pub(super) fn record_edit(
    h: &mut History,
    owner: Option<PaneId>,
    text: &BufferText,
    (from, to): (usize, usize),
    insert: &str,
    before: SelectionSet,
) -> BufferText {
    record_edit_leaving(h, owner, text, (from, to), insert, before, (from, from))
}

/// [`record_edit`], with the selection the edit left running from
/// `anchor` to `head` of the text it produces.
fn record_edit_leaving(
    h: &mut History,
    owner: Option<PaneId>,
    text: &BufferText,
    (from, to): (usize, usize),
    insert: &str,
    before: SelectionSet,
    (anchor, head): (usize, usize),
) -> BufferText {
    let mut b = ChangeSetBuilder::new(text.end());
    b.retain_to(CharOffset::new(from));
    b.delete_to(CharOffset::new(to));
    b.insert(insert);
    let cs = b.finish();
    let after = cs.apply(text).expect("built for text");
    let left = selected(&after, anchor, head);
    h.record(owner, cs, text, before, left, start_time());
    after
}

/// One selection of `text` from `anchor` to `head`, both char offsets that
/// start a cluster.
pub(super) fn selected(text: &BufferText, anchor: usize, head: usize) -> SelectionSet {
    let at = |n| text.snap(CharOffset::new(n));
    SelectionSet::new(text, vec![Selection::new(at(anchor), at(head))], 0)
}

fn undo_on(h: &mut History, text: &BufferText) -> BufferText {
    let txn = h.undo().expect("a revision to undo");
    txn.apply(text)
        .expect("the inverse maps the text")
        .0
        .into_parts()
        .0
}

fn pane() -> Option<PaneId> {
    Some(PaneId::default())
}

#[test]
fn the_selection_an_edit_left_is_exact_on_its_own_text() {
    let mut h = History::new(start_time());
    let text = BufferText::from("abcdef\n");
    let after = record_edit(&mut h, pane(), &text, (1, 3), "XY", selected(&text, 1, 2));
    let point = SelectionPoint {
        revision: h.current_id(),
        side: Side::After,
    };

    assert_eq!(h.selection_at(point, &after), Some(selected(&after, 1, 1)));
}

#[test]
fn an_undone_edits_selection_is_exact_on_the_text_undo_restores() {
    let mut h = History::new(start_time());
    let text = BufferText::from("abcdef\n");
    let paragraph = selected(&text, 1, 4);
    let after = record_edit(&mut h, pane(), &text, (1, 5), "", paragraph.clone());
    let revision = h.current_id();
    let restored = undo_on(&mut h, &after);
    let point = SelectionPoint {
        revision,
        side: Side::Before,
    };

    assert_eq!(h.selection_at(point, &restored), Some(paragraph));
}

#[test]
fn a_saved_selection_is_mapped_through_later_edits() {
    let mut h = History::new(start_time());
    let text = BufferText::from("abcdef\n");
    let mid = record_edit(&mut h, pane(), &text, (0, 0), "X", selected(&text, 1, 2));
    let first = h.current_id();
    let last = record_edit(&mut h, pane(), &mid, (0, 0), "Y", selected(&mid, 0, 0));
    let point = SelectionPoint {
        revision: first,
        side: Side::Before,
    };

    assert_eq!(h.selection_at(point, &last), Some(selected(&last, 3, 4)));
}

#[test]
fn selection_points_are_one_owners_newest_first() {
    let mut h = History::new(start_time());
    let t0 = BufferText::from("abcdef\n");
    let left = (0, 1);
    let t1 = record_edit_leaving(&mut h, pane(), &t0, (0, 0), "X", selected(&t0, 1, 2), left);
    let first = h.current_id();
    let t2 = record_edit_leaving(&mut h, None, &t1, (0, 0), "Y", selected(&t1, 1, 2), left);
    record_edit_leaving(&mut h, pane(), &t2, (0, 0), "Z", selected(&t2, 1, 2), left);
    let third = h.current_id();
    let point = |revision, side| SelectionPoint { revision, side };

    assert_eq!(
        h.selection_points(PaneId::default()),
        vec![
            point(third, Side::After),
            point(third, Side::Before),
            point(first, Side::After),
            point(first, Side::Before),
        ]
    );
}

#[test]
fn selection_points_leave_out_single_cursors() {
    let mut h = History::new(start_time());
    let t0 = BufferText::from("abcdef\n");
    let t1 = record_edit(&mut h, pane(), &t0, (0, 0), "X", selected(&t0, 1, 2));
    let left_cursor = h.current_id();
    record_edit_leaving(
        &mut h,
        pane(),
        &t1,
        (0, 0),
        "Y",
        selected(&t1, 2, 2),
        (0, 1),
    );
    let made_at_cursor = h.current_id();
    let point = |revision, side| SelectionPoint { revision, side };

    assert_eq!(
        h.selection_points(PaneId::default()),
        vec![
            point(made_at_cursor, Side::After),
            point(left_cursor, Side::Before),
        ]
    );
}

#[test]
fn a_selection_saved_on_a_text_promoted_into_the_root_is_mapped_from_it() {
    let mut h = History::new(start_time());
    h.set_undo_levels(1);
    let t0 = BufferText::from("abcdef\n");
    let t1 = record_edit(&mut h, pane(), &t0, (0, 0), "X", selected(&t0, 1, 2));
    let t2 = record_edit(&mut h, pane(), &t1, (0, 0), "Y", selected(&t1, 1, 2));
    let t3 = record_edit(&mut h, pane(), &t2, (0, 0), "Z", selected(&t2, 1, 2));
    let point = SelectionPoint {
        revision: h.current_id(),
        side: Side::Before,
    };
    assert_eq!(h.len(), 2, "sanity: the first two revisions were promoted");

    assert_eq!(h.selection_at(point, &t3), Some(selected(&t3, 2, 3)));
}
