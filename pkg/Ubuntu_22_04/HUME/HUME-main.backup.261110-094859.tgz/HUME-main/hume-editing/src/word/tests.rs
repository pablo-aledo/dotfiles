use super::*;

// ── classify_char ────────────────────────────────────────────────────────

#[test]
fn classify_newline_is_eol() {
    assert_eq!(classify_char('\n'), CharClass::Eol);
}

#[test]
fn classify_space_and_tab_are_space() {
    assert_eq!(classify_char(' '), CharClass::Space);
    assert_eq!(classify_char('\t'), CharClass::Space);
}

#[test]
fn classify_invisible_unicode_spaces_are_space() {
    assert_eq!(classify_char('\u{A0}'), CharClass::Space); // NBSP
    assert_eq!(classify_char('\u{3000}'), CharClass::Space); // ideographic space
}

#[test]
fn classify_other_unicode_whitespace_stays_punctuation() {
    // Deliberate: form feed and bare \r are rare enough that `w` stopping
    // on them beats silently skipping them.
    assert_eq!(classify_char('\u{C}'), CharClass::Punctuation); // form feed
    assert_eq!(classify_char('\r'), CharClass::Punctuation);
}

#[test]
fn classify_ascii_alnum_and_underscore_are_word() {
    assert_eq!(classify_char('a'), CharClass::Word);
    assert_eq!(classify_char('Z'), CharClass::Word);
    assert_eq!(classify_char('5'), CharClass::Word);
    assert_eq!(classify_char('_'), CharClass::Word);
}

#[test]
fn classify_unicode_letters_are_word() {
    // Accented letter (Latin Extended): alphanumeric in Unicode
    assert_eq!(classify_char('é'), CharClass::Word);
    // CJK ideograph: alphanumeric in Unicode
    assert_eq!(classify_char('文'), CharClass::Word);
}

#[test]
fn classify_punctuation_and_symbols() {
    for ch in ['.', ',', '!', '(', ')', '-', '+', '@', '#'] {
        assert_eq!(
            classify_char(ch),
            CharClass::Punctuation,
            "expected Punctuation for {:?}",
            ch
        );
    }
}

// ── is_word_boundary ─────────────────────────────────────────────────────

#[test]
fn word_boundary_any_class_change() {
    use CharClass::*;
    // Same class → no boundary
    assert!(!is_word_boundary(Word, Word));
    assert!(!is_word_boundary(Space, Space));
    assert!(!is_word_boundary(Punctuation, Punctuation));
    assert!(!is_word_boundary(Eol, Eol));
    // Different class → boundary
    assert!(is_word_boundary(Word, Punctuation));
    assert!(is_word_boundary(Word, Space));
    assert!(is_word_boundary(Word, Eol));
    assert!(is_word_boundary(Punctuation, Space));
    assert!(is_word_boundary(Space, Eol));
}

// ── is_uppercase_word_boundary ─────────────────────────────────────────────────

#[test]
fn uppercase_word_boundary_merges_word_and_punctuation() {
    use CharClass::*;
    // Word ↔ Punctuation are merged, so no long-word boundary between them
    assert!(!is_uppercase_word_boundary(Word, Punctuation));
    assert!(!is_uppercase_word_boundary(Punctuation, Word));
    // Same class → no boundary
    assert!(!is_uppercase_word_boundary(Word, Word));
    assert!(!is_uppercase_word_boundary(Space, Space));
    // Space/Eol transitions are still boundaries
    assert!(is_uppercase_word_boundary(Word, Space));
    assert!(is_uppercase_word_boundary(Punctuation, Space));
    assert!(is_uppercase_word_boundary(Word, Eol));
    assert!(is_uppercase_word_boundary(Space, Eol));
}

// ── WordChars ────────────────────────────────────────────────────────────

#[test]
fn word_chars_promotes_listed_punctuation() {
    assert_eq!(WordChars::new("-").classify('-'), CharClass::Word);
}

#[test]
fn word_chars_leaves_unlisted_punctuation_alone() {
    assert_eq!(WordChars::new("-").classify('.'), CharClass::Punctuation);
}

#[test]
fn word_chars_empty_matches_classify_char() {
    let chars = WordChars::default();
    for ch in [
        'a', 'Z', '5', '_', 'é', '文', '.', ',', '-', '+', ' ', '\t', '\u{A0}', '\u{3000}', '\n',
        '\r', '\u{C}',
    ] {
        assert_eq!(chars.classify(ch), classify_char(ch), "mismatch for {ch:?}");
    }
}

#[test]
fn word_chars_cannot_promote_space_or_eol() {
    // Defense in depth: even if a caller bypasses `validate`, `classify` must
    // never turn whitespace/newline into `Word`: every scan here finds a
    // word's end by hitting one of those two classes.
    assert_eq!(WordChars::new(" ").classify(' '), CharClass::Space);
    assert_eq!(WordChars::new("\n").classify('\n'), CharClass::Eol);
}

#[test]
fn validate_rejects_space_and_eol_chars() {
    for ch in [' ', '\t', '\u{A0}', '\u{3000}', '\n'] {
        assert!(
            WordChars::validate(&ch.to_string()).is_err(),
            "expected {ch:?} to be rejected"
        );
    }
}

/// `validate` must reject every Unicode whitespace character, not just the
/// five `classify_char` calls `Space`/`Eol`. A word run promoted over one of
/// the others would have no terminator on a line built from it.
#[test]
fn validate_rejects_every_unicode_whitespace_char() {
    for ch in [
        '\r', '\u{B}', '\u{C}', '\u{85}', '\u{2028}', '\u{2029}', '\u{202F}',
    ] {
        assert!(
            WordChars::validate(&ch.to_string()).is_err(),
            "expected {ch:?} to be rejected"
        );
    }
}

#[test]
fn validate_accepts_redundant_word_char() {
    assert!(WordChars::validate("_a").is_ok());
}

#[test]
fn validate_accepts_punctuation() {
    assert!(WordChars::validate("-*?!<>/").is_ok());
}

// ── word_runs ────────────────────────────────────────────────────────────────
//
// The `core:buffer-words` completion plugin's `split-words` builtin reuses
// this function directly (see `hume-scripting/src/builtins/words.rs`), so its
// own tokenization is what these tests pin.

fn runs(s: &str, chars: WordChars<'_>) -> Vec<String> {
    let text = BufferText::from(s);
    word_runs(&text, chars)
        .into_iter()
        .map(|range| text.slice(range.chars()).to_string())
        .collect()
}

#[test]
fn word_runs_splits_a_plain_sentence_on_spaces_and_punctuation() {
    assert_eq!(
        runs("hello, world!", WordChars::default()),
        vec!["hello", "world"]
    );
}

#[test]
fn word_runs_keeps_a_combining_grapheme_cluster_whole() {
    // "café" = c, a, f, e, U+0301 (combining acute). The trailing mark must
    // stay attached to its base char, not classify as a separate run (or as
    // punctuation splitting the run early).
    assert_eq!(
        runs("cafe\u{0301} latte", WordChars::default()),
        vec!["cafe\u{0301}", "latte"]
    );
}

#[test]
fn word_runs_does_not_absorb_non_ascii_punctuation() {
    // U+2019 (right single quotation mark) is Punctuation per `classify_char`.
    // Treating every char `>= 128` as a word char would merge the whole
    // thing into one run.
    assert_eq!(
        runs("l\u{2019}\u{e9}l\u{e9}ment", WordChars::default()),
        vec!["l", "\u{e9}l\u{e9}ment"]
    );
}

#[test]
fn word_runs_does_not_absorb_an_em_dash() {
    assert_eq!(
        runs("foo\u{2014}bar", WordChars::default()),
        vec!["foo", "bar"]
    );
}

#[test]
fn word_runs_honors_word_chars() {
    assert_eq!(
        runs("foo-bar baz", WordChars::new("-")),
        vec!["foo-bar", "baz"]
    );
    assert_eq!(
        runs("foo-bar baz", WordChars::default()),
        vec!["foo", "bar", "baz"]
    );
}

#[test]
fn word_runs_on_an_empty_or_all_punctuation_string_is_empty() {
    assert_eq!(runs("", WordChars::default()), Vec::<String>::new());
    assert_eq!(
        runs("... !!! ,,,", WordChars::default()),
        Vec::<String>::new()
    );
}

/// Runs of `Word`-class grapheme clusters, from `unicode-segmentation` over a
/// plain `&str` and classified by each cluster's first char: an
/// implementation independent of the rope walk `word_runs` uses.
fn segmentation_runs(s: &str, chars: WordChars<'_>) -> Vec<String> {
    use unicode_segmentation::UnicodeSegmentation;
    let mut runs = Vec::new();
    let mut current = String::new();
    for g in s.graphemes(true) {
        let first = g.chars().next().expect("a grapheme is never empty");
        if chars.classify(first) == CharClass::Word {
            current.push_str(g);
        } else if !current.is_empty() {
            runs.push(std::mem::take(&mut current));
        }
    }
    if !current.is_empty() {
        runs.push(current);
    }
    runs
}

#[test]
fn word_runs_matches_a_plain_string_segmentation_on_unicode_text() {
    for s in [
        "hello, world! foo_bar baz42",
        "cafe\u{301} au lait, na\u{ef}ve",
        "l\u{2019}\u{e9}l\u{e9}ment foo\u{2014}bar",
        "family \u{1F468}\u{200D}\u{1F469}\u{200D}\u{1F467} flags \u{1F1EE}\u{1F1F9}\u{1F1EB}\u{1F1F7}",
        "漢字とかな、句読点。abc",
        "foo-bar baz\nnext-line qux\n",
    ] {
        for word_chars in ["", "-"] {
            let chars = WordChars::new(word_chars);
            assert_eq!(
                runs(s, chars),
                segmentation_runs(s, chars),
                "text {s:?}, word-chars {word_chars:?}"
            );
        }
    }
}
