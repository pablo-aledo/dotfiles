use super::*;

/// Split `s` on `\n` into line slices for test inputs. No trailing
/// separators, matching how a rope would slice lines.
fn lines(s: &str) -> Vec<&str> {
    s.split('\n').collect::<Vec<_>>()
}

// … line-level ………………………………………………………………………………………

#[test]
fn diff_lines_basic() {
    let old = lines("a\nb\nc\nd");
    let new = lines("a\nB\nc\nd");
    let d = diff_lines(&old, &new);
    // Expect: equal "a", replace "b"→"B", equal "c\nd".
    assert_eq!(d.len(), 3);
    assert_eq!(d[0].kind, LineHunkKind::Equal);
    assert_eq!(d[0].old, 0..1);
    assert_eq!(d[1].kind, LineHunkKind::Replace);
    assert_eq!(d[1].old, 1..2);
    assert_eq!(d[1].new, 1..2);
    assert_eq!(old[d[1].old.clone()].join(""), "b");
    assert_eq!(new[d[1].new.clone()].join(""), "B");
    assert_eq!(d[2].kind, LineHunkKind::Equal);
    assert_eq!(d[2].old, 2..4);
    assert_eq!(d[2].new, 2..4);
}

#[test]
fn diff_lines_all_equal() {
    let old = lines("x\ny\nz");
    let new = lines("x\ny\nz");
    let d = diff_lines(&old, &new);
    assert_eq!(d.len(), 1);
    assert_eq!(d[0].kind, LineHunkKind::Equal);
    assert_eq!(d[0].old, 0..3);
    assert_eq!(d[0].new, 0..3);
}

#[test]
fn diff_lines_pure_insert() {
    let old = lines("a\nc");
    let new = lines("a\nb\nc");
    let d = diff_lines(&old, &new);
    let insert = d
        .iter()
        .find(|h| h.kind == LineHunkKind::Insert)
        .expect("should have an insert hunk");
    assert_eq!(insert.old, 1..1);
    assert_eq!(insert.new, 1..2);
    assert_eq!(new[insert.new.clone()].join(""), "b");
}

#[test]
fn diff_lines_pure_delete() {
    let old = lines("a\nb\nc");
    let new = lines("a\nc");
    let d = diff_lines(&old, &new);
    let delete = d
        .iter()
        .find(|h| h.kind == LineHunkKind::Delete)
        .expect("should have a delete hunk");
    assert_eq!(delete.old, 1..2);
    assert_eq!(delete.new, 1..1);
    assert_eq!(old[delete.old.clone()].join(""), "b");
}

#[test]
fn diff_lines_replace_block() {
    let old = lines("a\n1\n2\n3\nz");
    let new = lines("a\nX\nY\nz");
    let d = diff_lines(&old, &new);
    let replace = d
        .iter()
        .find(|h| h.kind == LineHunkKind::Replace)
        .expect("should have a replace hunk");
    assert_eq!(replace.old, 1..4);
    assert_eq!(replace.new, 1..3);
    assert_eq!(old[replace.old.clone()].join(""), "123");
    assert_eq!(new[replace.new.clone()].join(""), "XY");
}

// … word-level ………………………………………………………………………………………

#[test]
fn diff_words_basic() {
    let d = diff_words("foo bar baz", "foo baz qux");
    // Tokens: old ["foo", " ", "bar", " ", "baz"], new ["foo", " ", "baz",
    // " ", "qux"]. Any minimal diff keeps three tokens and changes four: it
    // keeps either the second space or "baz". Myers keeps "baz", so "bar "
    // goes and " qux" arrives around it.
    assert_eq!(
        d,
        vec![
            WordHunk {
                old: 0..4,
                new: 0..4,
                kind: WordHunkKind::Equal
            },
            WordHunk {
                old: 4..8,
                new: 4..4,
                kind: WordHunkKind::Delete("bar ".into())
            },
            WordHunk {
                old: 8..11,
                new: 4..7,
                kind: WordHunkKind::Equal
            },
            WordHunk {
                old: 11..11,
                new: 7..11,
                kind: WordHunkKind::Insert(" qux".into())
            },
        ]
    );
}

#[test]
fn diff_words_replace() {
    let d = diff_words("hello world", "hello there");
    let replace = d
        .iter()
        .find(|h| matches!(h.kind, WordHunkKind::Replace { .. }))
        .expect("should have a replace hunk");
    assert_eq!(
        replace.kind,
        WordHunkKind::Replace {
            old: "world".into(),
            new: "there".into()
        }
    );
    // "world" starts at char offset 6 in "hello world".
    assert_eq!(replace.old, 6..11);
    // "there" starts at char offset 6 in "hello there".
    assert_eq!(replace.new, 6..11);
}

#[test]
fn diff_words_grapheme_safe() {
    // `é` as `e` + U+0301 combining accent. Unicode word boundaries treat
    // the combining sequence as part of the same word, so the token split
    // must not land between `e` and U+0301.
    let old = "cafe\u{0301} bar";
    let new = "cafe\u{0301} baz";
    let d = diff_words(old, new);
    // The change should be "bar" → "baz"; the "café" prefix (with its
    // combining sequence) must be an Equal run covering chars 0..6
    // (c, a, f, e, U+0301, space).
    let prefix = d
        .iter()
        .find(|h| matches!(h.kind, WordHunkKind::Equal))
        .expect("should have an equal prefix hunk");
    assert_eq!(prefix.old, 0..6);
    assert_eq!(prefix.new, 0..6);
}

// ── edge cases ────────────────────────────────────────────────────────────

#[test]
fn diff_lines_empty() {
    // No lines on either side → no hunks. Pins the empty-input contract.
    let d = diff_lines::<&str>(&[], &[]);
    assert!(d.is_empty());
}

#[test]
fn diff_lines_completely_different() {
    // Zero lines in common → a single Replace spanning the whole input.
    let old = lines("aaa\nbbb");
    let new = lines("xxx\nyyy\nzzz");
    let d = diff_lines(&old, &new);
    assert_eq!(d.len(), 1);
    assert_eq!(d[0].kind, LineHunkKind::Replace);
    assert_eq!(d[0].old, 0..2);
    assert_eq!(d[0].new, 0..3);
    assert_eq!(old[d[0].old.clone()].join(""), "aaabbb");
    assert_eq!(new[d[0].new.clone()].join(""), "xxxyyyzzz");
}

#[test]
fn diff_lines_trailing_newline() {
    // `"a\n".split('\n')` yields `["a", ""]`: the trailing empty line is
    // a real line index and must be covered by the Equal hunk, not dropped.
    let old = lines("a\n");
    let new = lines("a\n");
    assert_eq!(old.len(), 2);
    let d = diff_lines(&old, &new);
    assert_eq!(d.len(), 1);
    assert_eq!(d[0].kind, LineHunkKind::Equal);
    assert_eq!(d[0].old, 0..2);
    assert_eq!(d[0].new, 0..2);
}

#[test]
fn diff_words_empty() {
    // Empty strings → no hunks, guard not triggered. Pins the empty-input
    // contract.
    let d = diff_words("", "");
    assert!(d.is_empty());
}

#[test]
fn diff_words_zwj_emoji() {
    // 👨‍👩‍👧 = man + ZWJ + woman + ZWJ + girl (5 chars). UAX #29 must treat
    // the whole ZWJ sequence as one word, so the token boundary never lands
    // inside it. Input layout: "x " (2 chars) + family (5 chars) + " " (1)
    // + "y" (1) = 9 chars total; the family word covers chars 2..7.
    let family = "\u{1F468}\u{200D}\u{1F469}\u{200D}\u{1F467}";
    assert_eq!(family.chars().count(), 5);
    let old = format!("x {} y", family);
    let new = format!("x {} z", family);
    let d = diff_words(&old, &new);
    // Equal prefix "x 👨‍👩‍👧 " covers chars 0..8 on both sides; the ZWJ
    // sequence is inside it and never split.
    let prefix = d
        .iter()
        .find(|h| matches!(h.kind, WordHunkKind::Equal))
        .expect("should have an equal prefix hunk");
    assert_eq!(prefix.old, 0..8);
    assert_eq!(prefix.new, 0..8);
    // "y" → "z" is the only change, at char offset 8..9 on both sides.
    assert_eq!(d.len(), 2);
    assert_eq!(d[1].old, 8..9);
    assert_eq!(d[1].new, 8..9);
    assert_eq!(
        d[1].kind,
        WordHunkKind::Replace {
            old: "y".into(),
            new: "z".into(),
        }
    );
}

#[test]
fn diff_words_cjk() {
    // CJK scripts have no whitespace word boundaries under UAX #29: each
    // ideograph is its own word. "日本語 abc" tokenizes as
    // ["日","本","語"," ","abc"], so editing "語" and "abc" exercises the
    // per-ideograph granularity.
    let old = "日本語 abc";
    let new = "日本 go";
    let d = diff_words(old, new);
    // Expected hunks (char offsets):
    //   Equal "日本"     old 0..2  new 0..2
    //   Delete "語"      old 2..3  new 2..2
    //   Equal " "        old 3..4  new 2..3
    //   Replace abc→go   old 4..7  new 3..5
    assert_eq!(d.len(), 4);
    assert_eq!(d[0].kind, WordHunkKind::Equal);
    assert_eq!(d[0].old, 0..2);
    assert_eq!(d[0].new, 0..2);
    assert_eq!(d[1].kind, WordHunkKind::Delete("語".into()));
    assert_eq!(d[1].old, 2..3);
    assert_eq!(d[1].new, 2..2);
    assert_eq!(d[2].kind, WordHunkKind::Equal);
    assert_eq!(d[2].old, 3..4);
    assert_eq!(d[2].new, 2..3);
    assert_eq!(
        d[3].kind,
        WordHunkKind::Replace {
            old: "abc".into(),
            new: "go".into(),
        }
    );
    assert_eq!(d[3].old, 4..7);
    assert_eq!(d[3].new, 3..5);
}

// ── Algorithm choice ─────────────────────────────────────────────────────

/// `u1` and `u2` each occur once on both sides. Histogram anchors on `u1`, so
/// `u1` and the braces around it stay put and `u2 }` reads as moved: inserted
/// above them, deleted below them.
#[test]
fn diff_lines_anchors_on_a_line_unique_to_both_sides() {
    let old = ["}", "}", "u1", "}", "}", "u2", "}", "}"];
    let new = ["}", "u2", "}", "}", "u1", "}", "}", "}"];
    let d = diff_lines(&old, &new);
    let got: Vec<_> = d
        .iter()
        .map(|h| (h.kind, h.old.clone(), h.new.clone()))
        .collect();
    assert_eq!(
        got,
        vec![
            (LineHunkKind::Equal, 0..1, 0..1),
            (LineHunkKind::Insert, 1..1, 1..3),
            (LineHunkKind::Equal, 1..5, 3..7),
            (LineHunkKind::Delete, 5..7, 7..7),
            (LineHunkKind::Equal, 7..8, 7..8),
        ]
    );
}

#[test]
fn histogram_runs_only_while_its_estimated_work_fits() {
    assert!(histogram_fits(10, 3, 30));
    assert!(!histogram_fits(10, 4, 30));
    assert!(histogram_fits(usize::MAX, 0, 0));
    assert!(!histogram_fits(usize::MAX, 2, usize::MAX - 1));
}

/// Past the work limit the Myers result stands. Both sides hold six braces,
/// so the longest common run is the six braces and any minimal diff changes
/// four lines; Myers keeps the braces where histogram kept `u1`.
#[test]
fn past_the_work_limit_the_myers_result_stands() {
    let old = ["}", "}", "u1", "}", "}", "u2", "}", "}"];
    let new = ["}", "u2", "}", "}", "u1", "}", "}", "}"];
    let within = diff_lines_within(&old, &new, usize::MAX);
    let past = diff_lines_within(&old, &new, 0);
    assert_ne!(past, within);
    let changed: usize = past
        .iter()
        .filter(|h| h.kind != LineHunkKind::Equal)
        .map(|h| h.old.len() + h.new.len())
        .sum();
    assert_eq!(changed, 4);
}

// ── Property-based round-trip tests ──────────────────────────────────────
//
// The hunk ranges must partition the input, so
// concatenating the covered slices reconstructs the original input. This
// catches off-by-one range bugs without mirroring the implementation.

use proptest::prelude::*;

fn arb_small_text(max_len: usize) -> impl Strategy<Value = String> {
    // Mix letters, spaces, newlines, and a combining accent so we exercise
    // both line/word tokenization and grapheme safety.
    prop::collection::vec(
        prop::sample::select(vec!['a', 'b', ' ', '\n', '\u{0301}']),
        0..max_len,
    )
    .prop_map(|chars| chars.into_iter().collect())
}

proptest! {
    #[test]
    fn diff_lines_round_trip(old in arb_small_text(12), new in arb_small_text(12)) {
        let old_lines: Vec<&str> = old.split('\n').collect();
        let new_lines: Vec<&str> = new.split('\n').collect();
        let d = diff_lines(&old_lines, &new_lines);
        // The old-side ranges must partition 0..old_lines.len(): concatenating
        // each hunk's old lines (joined with no separator, matching the
        // payload policy) reconstructs old_lines joined with no separator.
        let recon_old: String =
            d.iter().map(|h| old_lines[h.old.clone()].join("")).collect();
        prop_assert_eq!(&recon_old, &old_lines.join(""));
        // Same for the new side.
        let recon_new: String =
            d.iter().map(|h| new_lines[h.new.clone()].join("")).collect();
        prop_assert_eq!(&recon_new, &new_lines.join(""));
        // Ranges must be contiguous and cover the whole input.
        let mut old_end = 0;
        for h in &d {
            prop_assert_eq!(h.old.start, old_end);
            old_end = h.old.end;
        }
        prop_assert_eq!(old_end, old_lines.len());
        let mut new_end = 0;
        for h in &d {
            prop_assert_eq!(h.new.start, new_end);
            new_end = h.new.end;
        }
        prop_assert_eq!(new_end, new_lines.len());
    }

    #[test]
    fn diff_words_round_trip(old in arb_small_text(12), new in arb_small_text(12)) {
        let old_n = old.chars().count();
        let new_n = new.chars().count();
        // Hunk ranges are char offsets, but `&str[range]` slices by bytes, so
        // we build char→byte tables to reconstruct by byte range.
        let old_bytes: Vec<usize> = old.char_indices().map(|(b, _)| b).chain(std::iter::once(old.len())).collect();
        let new_bytes: Vec<usize> = new.char_indices().map(|(b, _)| b).chain(std::iter::once(new.len())).collect();
        let d = diff_words(&old, &new);
        // Char-offset ranges must partition the input string: slicing and
        // concatenating reconstructs the original.
        let recon_old: String =
            d.iter().map(|h| &old[old_bytes[h.old.start]..old_bytes[h.old.end]]).collect();
        prop_assert_eq!(&recon_old, &old);
        let recon_new: String =
            d.iter().map(|h| &new[new_bytes[h.new.start]..new_bytes[h.new.end]]).collect();
        prop_assert_eq!(&recon_new, &new);
        // Ranges contiguous and cover the whole input.
        let mut old_end = 0;
        for h in &d {
            prop_assert_eq!(h.old.start, old_end);
            old_end = h.old.end;
        }
        prop_assert_eq!(old_end, old_n);
        let mut new_end = 0;
        for h in &d {
            prop_assert_eq!(h.new.start, new_end);
            new_end = h.new.end;
        }
        prop_assert_eq!(new_end, new_n);
    }
}

// ── word token limit ─────────────────────────────────────────────────────

#[test]
fn tokenize_with_offsets_stops_one_token_past_the_limit() {
    // "a b c" is five tokens: three words and two spaces.
    let (tokens, offsets) = tokenize_with_offsets("a b c", 2);
    assert_eq!(tokens, ["a", " ", "b"]);
    assert_eq!(offsets, [0, 1, 2, 3]);
}

#[test]
fn tokenize_with_offsets_keeps_every_token_within_the_limit() {
    let (tokens, offsets) = tokenize_with_offsets("a b c", 5);
    assert_eq!(tokens, ["a", " ", "b", " ", "c"]);
    assert_eq!(offsets, [0, 1, 2, 3, 4, 5]);
}

#[test]
fn word_tokens_within_a_limit_counts_both_sides_together() {
    assert!(WordTokens::within("a", "b", 2).is_some());
    assert!(WordTokens::within("a b c", "x", 3).is_none());
    assert!(WordTokens::within("a", "b c", 2).is_none());
}

#[test]
#[allow(clippy::single_range_in_vec_init)] // each side's list holds one changed range
fn word_change_ranges_spends_the_tokens_it_diffed() {
    // "a b" and "a c" are three tokens each; the changed word is the third.
    let mut budget = 6;
    let ranges = word_change_ranges("a b", "a c", &mut budget);
    assert_eq!(ranges, Some((vec![2..3], vec![2..3])));
    assert_eq!(budget, 0);
}

#[test]
fn word_change_ranges_over_the_budget_leaves_it_untouched() {
    let mut budget = 5;
    assert_eq!(word_change_ranges("a b", "a c", &mut budget), None);
    assert_eq!(budget, 5);
}
