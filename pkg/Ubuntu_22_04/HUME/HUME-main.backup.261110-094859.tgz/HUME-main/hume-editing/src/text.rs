use hume_rope::cluster::{ClusterRange, ClusterStart};
use hume_rope::cursor::CharCursor;
use hume_rope::offset::{CharOffset, ExclusiveRange};
use ropey::{Rope, RopeSlice};
use std::borrow::Cow;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};

/// Whether the original file used LF or CRLF line endings.
///
/// Stored in the buffer so we can write the file back with the same endings.
/// A buffer's content never carries a `\r` at all (see
/// [`crate::changeset::ChangeSetBuilder::insert`] for why). This flag
/// therefore governs only *how `\n` is written back out*, never what the
/// rope holds.
///
/// A CRLF file round-trips; a CR-only (old Mac) file does not: it has no
/// `\r\n` pair to detect, so it loads as `Lf` and saves back as LF.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LineEnding {
    /// Unix / macOS (default)
    Lf,
    /// Windows / DOS
    CrLf,
}

/// Collapse every line-ending convention (`\r\n`, bare `\r`) to `\n`. See
/// [`crate::changeset::ChangeSetBuilder::insert`] for why every text-insertion
/// path funnels through this.
///
/// A borrow (no allocation) on the common case of text with no `\r` at all.
pub fn normalize_line_endings(text: &str) -> Cow<'_, str> {
    normalize_line_endings_detecting(text).0
}

/// [`normalize_line_endings`] for owned text, returning `text` itself when it
/// holds no `\r`.
pub fn normalize_line_endings_owned(text: String) -> String {
    match normalize_line_endings(&text) {
        Cow::Borrowed(_) => text,
        Cow::Owned(normalized) => normalized,
    }
}

/// Text with every line ending already collapsed to `\n`, owned so an edit
/// can move it into its changeset. Minted only by normalizing, so an edit
/// operation cannot carry a `\r` into a rope.
#[derive(Debug, Default, Clone)]
pub(crate) struct LfText(String);

impl LfText {
    pub(crate) fn new(text: &str) -> Self {
        Self(normalize_line_endings(text).into_owned())
    }

    pub(crate) fn as_str(&self) -> &str {
        &self.0
    }

    pub(crate) fn into_string(self) -> String {
        self.0
    }
}

/// [`normalize_line_endings`], also reporting whether the *original* input
/// contained a `\r\n` pair: the one thing detectable about a file's
/// convention that survives normalization, and what `BufferText::from`
/// records so a save can re-expand. A bare `\r` (old-Mac-style) forms no such
/// pair and reads as plain `Lf`. If any `\r\n` is present, `CrLf` is returned
/// even when other lines use LF alone ("mixed" files are treated as CRLF).
///
/// Detection rides along with the rewrite rather than pre-scanning for
/// `"\r\n"`: the loop already has to look at every `\r` and its successor to
/// decide how many chars to skip, so the pair is free to notice there.
///
/// One `find`-per-run scan for `\r`, copying each clean run with `push_str`
/// rather than pushing one `char` at a time. On a large CRLF file that's a
/// `push_str` per line instead of a `push` per byte.
fn normalize_line_endings_detecting(text: &str) -> (Cow<'_, str>, LineEnding) {
    let Some(first) = text.find('\r') else {
        return (Cow::Borrowed(text), LineEnding::Lf);
    };
    let mut out = String::with_capacity(text.len());
    let mut rest = &text[first..];
    out.push_str(&text[..first]);
    let mut found_crlf = false;
    while let Some(i) = rest.find('\r') {
        out.push_str(&rest[..i]);
        out.push('\n');
        rest = &rest[i + 1..];
        if let Some(after_lf) = rest.strip_prefix('\n') {
            found_crlf = true;
            rest = after_lf;
        }
    }
    out.push_str(rest);
    let ending = if found_crlf {
        LineEnding::CrLf
    } else {
        LineEnding::Lf
    };
    (Cow::Owned(out), ending)
}

/// The core text storage type.
///
/// `BufferText` wraps a [`ropey::Rope`], which is a balanced B-tree of Unicode
/// scalar values ("chars"). All positions exposed by this API are **char
/// offsets**: indices into the sequence of Unicode scalar values, not byte
/// offsets or grapheme-cluster indices.
///
/// Why char offsets and not bytes? Ropey's native and most stable API is
/// char-indexed. Byte indices are an implementation detail we never expose.
/// Grapheme-cluster awareness (for cursor movement) lives in `grapheme.rs`
/// and converts char offsets to grapheme boundaries on the fly.
///
/// Why an immutable-style API? `insert` and `remove` return a *new* `BufferText`
/// instead of mutating in place. A ropey clone is one reference-count bump,
/// and an edit copies only the O(log n) B-tree nodes on its path, sharing the
/// rest with the old version ("structural sharing"). This makes cloning cheap
/// when needed, though the primary undo mechanism is changeset inversion
/// (see `ChangeSet::invert`), not buffer snapshots.
#[derive(Debug, Clone)]
pub struct BufferText {
    rope: Rope,
    /// Original line-ending style. The rope is always LF-normalized internally;
    /// this field records what to write back on save.
    line_ending: LineEnding,
    version: TextVersion,
    /// This text's place in the order its lineage's texts were made in.
    generation: u64,
    /// The last number issued in this text's lineage, shared by every text
    /// derived from the same original, so two edits applied to one snapshot
    /// never receive the same version or generation.
    generations: Arc<AtomicU64>,
}

/// Which content a [`BufferText`] holds. Equal versions mean equal content.
///
/// A text built from a string starts a new lineage. Applying a
/// non-identity [`crate::changeset::ChangeSet`] gives a new version of the
/// same lineage; a clone or an identity apply keeps the version. Versions
/// say nothing about order: [`BufferText::generation`] does.
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct TextVersion {
    lineage: u64,
    id: u64,
}

static NEXT_LINEAGE: AtomicU64 = AtomicU64::new(0);

/// A new lineage's first version and generation, and its counter.
fn new_lineage() -> (TextVersion, u64, Arc<AtomicU64>) {
    let version = TextVersion {
        lineage: NEXT_LINEAGE.fetch_add(1, Ordering::Relaxed),
        id: 0,
    };
    (version, 0, Arc::new(AtomicU64::new(0)))
}

/// True if `rope` satisfies the invariant every `BufferText` upholds by
/// construction: non-empty, and ending with `'\n'`. Stricter than
/// [`hume_rope::lines::ends_with_newline`]. That one (correctly, for its own
/// generic-rope callers) treats a truly empty rope as vacuously fine; a HUME
/// buffer never is, so `ChangeSet::apply`, the gate, requires it non-empty
/// too, and `BufferText::successor` debug-checks it.
pub(crate) fn is_valid_buffer_rope(rope: &Rope) -> bool {
    rope.len_chars() > 0 && hume_rope::lines::ends_with_newline(rope)
}

/// True if `rope` holds no `\r` anywhere. Unlike [`is_valid_buffer_rope`]
/// this can't be checked in O(log n): `\r` can be anywhere in the buffer,
/// so every chunk has to be looked at. Walking `str::contains` over ropey's
/// own chunks (rather than decoding char-by-char through its cursor API)
/// keeps that scan's constant small: benchmarked at ~70µs for a 1 MB buffer,
/// vs ~20ms for `rope.chars().any(|c| c == '\r')` on the same input.
pub(crate) fn is_cr_free(rope: &Rope) -> bool {
    !rope.chunks().any(|chunk| chunk.contains('\r'))
}

impl BufferText {
    /// `rope` as the next generation of this text's lineage, keeping its
    /// line ending: the result of applying a non-identity changeset.
    ///
    /// The trailing-`\n` invariant is enforced
    /// by `ChangeSet::apply` returning `Err(TrailingNewlineMissing)` before
    /// this constructor is called; the `\r`-free invariant has no such
    /// production-path gate (see `is_cr_free`'s doc for why: it's O(n), not
    /// O(log n), so a runtime `Err` would cost every edit a full-buffer scan).
    /// Both `debug_assert`s here are defense-in-depth for internal bugs in
    /// non-production builds.
    pub(crate) fn successor(&self, rope: Rope) -> Self {
        // Raw constructor for ChangeSet::apply. No line-ending normalization
        // needed: the rope it hands over is the source buffer's own (already
        // `\r`-free) content plus insertions the changeset builder normalized
        // as it recorded them.
        debug_assert!(
            is_valid_buffer_rope(&rope),
            "BufferText invariant violated: rope must end with '\\n' (len={})",
            rope.len_chars(),
        );
        debug_assert!(
            is_cr_free(&rope),
            "BufferText invariant violated: rope must not contain '\\r'",
        );
        let (version, generation) = self.next_version();
        Self {
            rope,
            line_ending: self.line_ending,
            version,
            generation,
            generations: Arc::clone(&self.generations),
        }
    }

    /// `rope`, whose content is that of `version`, a version of this text's
    /// lineage, as the next generation: undo returning to an earlier text.
    pub(crate) fn restored(&self, rope: Rope, version: TextVersion) -> Self {
        debug_assert_eq!(
            version.lineage, self.version.lineage,
            "restored: a version of another lineage"
        );
        let (_, generation) = self.next_version();
        Self {
            rope,
            line_ending: self.line_ending,
            version,
            generation,
            generations: Arc::clone(&self.generations),
        }
    }

    /// This text as `version`, a version of its lineage with the same
    /// content. The generation does not move: nothing about the text changed.
    pub(crate) fn relabeled(&self, version: TextVersion) -> Self {
        debug_assert_eq!(
            version.lineage, self.version.lineage,
            "relabeled: a version of another lineage"
        );
        Self {
            version,
            ..self.clone()
        }
    }

    /// A new version of this text's lineage and the generation it is made in,
    /// one number serving as both.
    fn next_version(&self) -> (TextVersion, u64) {
        let n = self.generations.fetch_add(1, Ordering::Relaxed) + 1;
        let version = TextVersion {
            lineage: self.version.lineage,
            id: n,
        };
        (version, n)
    }

    /// `content` as the next generation of this text's lineage: a wholesale
    /// replacement that stays one document, as a refreshed view buffer does.
    /// The line ending is detected from `content`.
    pub fn replaced_with(&self, content: &str) -> Self {
        let fresh = Self::from(content);
        let (version, generation) = self.next_version();
        Self {
            version,
            generation,
            generations: Arc::clone(&self.generations),
            ..fresh
        }
    }

    /// This text with `line_ending` recorded for saving. The content and
    /// version are unchanged.
    pub fn with_line_ending(self, line_ending: LineEnding) -> Self {
        Self {
            line_ending,
            ..self
        }
    }

    pub fn version(&self) -> TextVersion {
        self.version
    }

    /// Where this text stands in the order its lineage's texts were made in.
    /// Every text made from this one has a greater generation, so it orders
    /// what a language server, the syntax tree and change announcements see.
    /// It may skip numbers: a text computed and then dropped still used one.
    pub fn generation(&self) -> u64 {
        self.generation
    }

    /// Borrow the inner `Rope`.
    ///
    /// Ropey's `Rope::clone` is O(log n) (reference-counted tree nodes), so
    /// calling `.rope().clone()` is cheap and is the preferred way to get a
    /// mutable copy for operations that take `&BufferText` instead of consuming it.
    ///
    /// # Design note
    /// This exposes the `ropey` type directly. Callers need raw `Rope` / `RopeSlice` access for
    /// performance, so the boundary is intentionally permeable here. `ropey`
    /// is a stable, semver-pinned dependency; changing it would require
    /// touching the caller sites regardless.
    pub fn rope(&self) -> &Rope {
        &self.rope
    }

    /// This text, for a line diff against another.
    pub fn content(&self) -> BufferContent<'_> {
        BufferContent(Content::Rope(self.rope.slice(..)))
    }

    /// Create an empty buffer (contains only the structural trailing newline).
    pub fn empty() -> Self {
        let (version, generation, generations) = new_lineage();
        Self {
            rope: Rope::from_str("\n"),
            line_ending: LineEnding::Lf,
            version,
            generation,
            generations,
        }
    }

    /// The line-ending style of the original file.
    ///
    /// The rope is always stored with LF (`\n`) only; this records what
    /// to write back on save.
    pub fn line_ending(&self) -> LineEnding {
        self.line_ending
    }

    /// Total number of Unicode scalar values (chars) in the buffer.
    ///
    /// This is the unit used for all positions and ranges in HUME.
    pub fn len_chars(&self) -> usize {
        self.rope.len_chars()
    }

    /// The last addressable char position, `len_chars() - 1`. Every buffer
    /// has at least the structural trailing `\n`, so this never underflows.
    pub fn last_char(&self) -> CharOffset {
        CharOffset::new(self.len_chars().saturating_sub(1))
    }

    /// One past the last char: the buffer's exclusive end bound.
    pub fn end(&self) -> CharOffset {
        CharOffset::new(self.len_chars())
    }

    /// Returns `true` if the buffer contains no visible content, i.e., it
    /// holds only the structural trailing newline.
    #[cfg(test)]
    fn is_empty(&self) -> bool {
        debug_assert!(
            self.rope.len_chars() > 0,
            "BufferText invariant violated: len_chars() == 0 (buffer must always contain at least a trailing \\n)"
        );
        self.rope.len_chars() == 1 && self.rope.char(0) == '\n'
    }

    /// Raw ropey line count, phantom trailing line included. See
    /// [`hume_rope`]'s crate docs for the ropey-domain / content-domain
    /// distinction. Callers wanting the buffer's real line count want
    /// [`BufferText::content_line_count`] instead.
    pub fn ropey_line_count(&self) -> hume_rope::line::RopeyLineCount {
        hume_rope::lines::ropey_line_count(&self.rope)
    }

    /// Index of the last ropey line: the phantom trailing line.
    pub fn last_ropey_line(&self) -> hume_rope::line::RopeyLine {
        hume_rope::lines::last_ropey_line(&self.rope)
    }

    /// Number of content lines: every HUME buffer ends with a structural
    /// `\n`, which ropey counts as one extra empty line past the content;
    /// this subtracts it. The single source of truth for "how many lines
    /// does this buffer have" from a caller's point of view (line counts
    /// shown to the user, range-checked line indices).
    pub fn content_line_count(&self) -> hume_rope::line::ContentLineCount {
        hume_rope::lines::content_line_count(&self.rope)
    }

    /// Index of the last content line (`content_line_count() - 1`). Callers
    /// clamping a target line to stay within real content use this.
    pub fn last_content_line(&self) -> hume_rope::line::ContentLine {
        hume_rope::lines::last_content_line(&self.rope)
    }

    /// Line tokens from `line_idx` forward, each keeping its trailing line
    /// break (see [`hume_rope::lines::line_token_strs`] for why).
    ///
    /// # Panics
    /// Panics if `line_idx > self.ropey_line_count()` (matches `line_to_char`).
    pub fn line_tokens_at(
        &self,
        line_idx: hume_rope::line::RopeyLine,
    ) -> impl Iterator<Item = RopeSlice<'_>> {
        hume_rope::lines::line_tokens_at(&self.rope, line_idx)
    }

    /// Same tokens as [`BufferText::line_tokens_at`], walking backward from
    /// `line_idx` itself. See [`hume_rope::lines::line_tokens_back_from`]
    /// for the mirror-shape rationale.
    ///
    /// # Panics
    /// Panics if `line_idx >= self.ropey_line_count()`.
    pub fn line_tokens_back_from(
        &self,
        line_idx: hume_rope::line::RopeyLine,
    ) -> impl Iterator<Item = RopeSlice<'_>> {
        hume_rope::lines::line_tokens_back_from(&self.rope, line_idx)
    }

    /// Returns the char offset of the first character on `line_idx` (0-based).
    /// `line_idx` may be one past the last line, yielding `len_chars()`.
    ///
    /// # Panics
    /// Panics if `line_idx > self.ropey_line_count()`.
    pub fn line_to_char(&self, line_idx: hume_rope::line::RopeyLine) -> CharOffset {
        hume_rope::lines::line_start_char(&self.rope, line_idx)
    }

    /// Returns the 0-based line number that contains char offset `char_idx`,
    /// in the content domain.
    ///
    /// Clamps `char_idx` to `len_chars()`: a stale position past the buffer
    /// end (a saved offset reused after the buffer shrank) resolves to the
    /// last content line instead of panicking: fail-fast is fine, losing
    /// unsaved work to it is not. A clamped `len_chars()` lands on the
    /// phantom trailing line (ropey counts a `\n` as ending its own line, so
    /// only the one-past-every-char position is phantom), which maps back to
    /// the last content line; on an empty buffer that is line 0.
    pub fn char_to_line(&self, char_idx: CharOffset) -> hume_rope::line::ContentLine {
        let clamped = CharOffset::new(char_idx.index().min(self.len_chars()));
        hume_rope::lines::char_to_ropey_line(&self.rope, clamped)
            .to_content(&self.rope)
            .unwrap_or_else(|| hume_rope::lines::last_content_line(&self.rope))
    }

    /// Returns the 0-based ropey line that contains char offset `char_idx`,
    /// phantom trailing line included, for a caller that must resolve a
    /// position possibly one past the last real char (an `'after` decoration
    /// anchor probing `pos + 1`, LSP wire-position encoding, a jump-list or
    /// FFI position restored without first proving it's in content domain).
    /// Every other caller wants [`BufferText::char_to_line`].
    ///
    /// # Panics
    /// Panics if `char_idx > self.len_chars()`.
    pub fn ropey_char_to_line(&self, char_idx: CharOffset) -> hume_rope::line::RopeyLine {
        hume_rope::lines::char_to_ropey_line(&self.rope, char_idx)
    }

    /// Returns a slice of the buffer over the given char range.
    ///
    /// [`ropey::RopeSlice`] is a lightweight view with no allocation. It is the
    /// input type for grapheme-cluster iteration in `grapheme.rs`.
    ///
    /// Takes [`ExclusiveRange`]; a cluster range crosses via
    /// `ClusterRange::chars`.
    ///
    /// # Panics
    /// Panics if `range.start > range.end` or either bound is out of range.
    pub fn slice(&self, range: ExclusiveRange<CharOffset>) -> ropey::RopeSlice<'_> {
        self.rope.slice(range.start.index()..range.end.index())
    }

    /// A slice spanning the entire buffer.
    pub fn full_slice(&self) -> ropey::RopeSlice<'_> {
        self.rope.slice(..)
    }

    /// The cluster holding the char at `offset`, or the last cluster (the
    /// structural `\n`) when `offset` is at or past the end. The entry point
    /// for a position from a foreign coordinate system.
    pub fn snap(&self, offset: CharOffset) -> ClusterStart {
        hume_rope::grapheme::snap_to_cluster(self.full_slice(), offset)
            .expect("a buffer is never empty")
            .start()
    }

    /// See [`ClusterRange::covering`].
    pub fn covering(&self, chars: ExclusiveRange<CharOffset>) -> Option<ClusterRange> {
        ClusterRange::covering(self.full_slice(), chars)
    }

    /// See [`ClusterRange::covering_bytes`].
    pub fn covering_bytes(&self, bytes: std::ops::Range<usize>) -> Option<ClusterRange> {
        ClusterRange::covering_bytes(self.full_slice(), bytes)
    }

    /// See [`ClusterRange::within`].
    pub fn within(&self, chars: ExclusiveRange<CharOffset>) -> Option<ClusterRange> {
        ClusterRange::within(self.full_slice(), chars)
    }

    /// Grapheme-cluster queries over this text.
    pub fn clusters(&self) -> ClusterView<'_> {
        ClusterView(self)
    }

    /// Line queries over this text.
    pub fn lines(&self) -> LineView<'_> {
        LineView(self)
    }

    /// Column conversions over this text.
    pub fn columns(&self) -> ColumnView<'_> {
        ColumnView(self)
    }

    /// Returns the Unicode scalar value at `char_idx`, or `None` if out of bounds.
    pub fn char_at(&self, char_idx: CharOffset) -> Option<char> {
        if char_idx.index() >= self.len_chars() {
            return None;
        }
        Some(self.rope.char(char_idx.index()))
    }

    /// A cursor over chars starting at `pos`, for scanning a contiguous range
    /// without re-paying ropey's O(log n) tree descent on every step (unlike
    /// repeated `char_at` calls in a loop). See [`CharCursor`].
    ///
    /// # Panics
    /// Panics if `pos > self.len_chars()`.
    pub fn chars_at(&self, pos: CharOffset) -> CharCursor<'_> {
        hume_rope::cursor::chars_at(&self.rope, pos)
    }

    /// Convert a byte offset to a char (Unicode scalar value) offset.
    ///
    /// Used to convert regex match byte offsets (from `regex-cursor`) back to
    /// HUME's native char-offset coordinate system. The byte offset must lie on
    /// a UTF-8 codepoint boundary; behaviour is unspecified otherwise.
    pub fn byte_to_char(&self, byte_idx: usize) -> CharOffset {
        CharOffset::new(self.rope.byte_to_char(byte_idx))
    }

    /// Convert a char offset to a byte offset.
    ///
    /// Used to translate HUME's char-indexed cursor positions into the byte
    /// offsets that `regex-cursor` operates on.
    pub fn char_to_byte(&self, char_idx: CharOffset) -> usize {
        self.rope.char_to_byte(char_idx.index())
    }

    /// Total byte length of the buffer content.
    pub fn len_bytes(&self) -> usize {
        self.rope.len_bytes()
    }

    /// Returns a new buffer with `text` inserted at char offset `at`.
    ///
    /// All char offsets at or after `at` in the old buffer are shifted forward
    /// by `text.chars().count()`. Selection offsets must be updated by the
    /// caller after calling this method.
    ///
    /// # Panics
    /// Panics if `at > self.len_chars()`.
    #[cfg(test)]
    fn insert(&self, at: usize, text: &str) -> Self {
        // Clone is O(log n) due to ropey's structural sharing.
        let mut rope = self.rope.clone();
        rope.insert(at, text);
        self.successor(rope)
    }

    /// Returns a new buffer with `range` of chars removed.
    ///
    /// All char offsets at or after `range.end` in the old buffer are shifted
    /// back by `range.len()`. Selection offsets must be updated by the caller.
    ///
    /// Using `Range<usize>` (rather than two separate `from`/`to` parameters)
    /// matches ropey's own convention: `text.remove(5..11)` mirrors
    /// `rope.remove(5..11)`. (Production slicing goes through the typed
    /// [`Self::slice`], not this test-only helper.)
    ///
    /// # Panics
    /// Panics if `range.start > range.end` or `range.end > self.len_chars()`.
    #[cfg(test)]
    fn remove(&self, range: std::ops::Range<usize>) -> Self {
        let mut rope = self.rope.clone();
        rope.remove(range);
        self.successor(rope)
    }
}

// `From<&str>`, not `FromStr`, since construction here always succeeds
// (worst case we append a '\n'); `FromStr` is reserved for fallible parsing.
// Note `BufferText::from(&my_string)` won't compile (`&String != &str`); call sites
// with a `String` must be explicit: `BufferText::from(my_string.as_str())`.
impl From<&str> for BufferText {
    fn from(text: &str) -> Self {
        let (content, line_ending) = content_and_line_ending(text);
        let rope = Rope::from_str(&content);
        let (version, generation, generations) = new_lineage();
        Self {
            rope,
            line_ending,
            version,
            generation,
            generations,
        }
    }
}

/// Text with the shape a [`BufferText`] holds, LF line endings and a final
/// line break: what a line diff of two texts reads. Made from a buffer's
/// text ([`BufferText::content`]), or from a string, normalized as
/// `BufferText::from` normalizes it, and borrowed when the string already has
/// that shape, so diffing a string builds no rope.
pub struct BufferContent<'a>(Content<'a>);

enum Content<'a> {
    Rope(RopeSlice<'a>),
    Str(Cow<'a, str>),
}

impl<'a> From<&'a str> for BufferContent<'a> {
    fn from(text: &'a str) -> Self {
        Self(Content::Str(buffer_content(text)))
    }
}

impl BufferContent<'_> {
    pub(crate) fn slice(&self) -> RopeSlice<'_> {
        match &self.0 {
            Content::Rope(slice) => *slice,
            Content::Str(text) => RopeSlice::from(text.as_ref()),
        }
    }
}

/// `text` as buffer content, the text `BufferText::from(text)` holds: LF line
/// endings and a final line break. Borrowed when `text` already has both.
fn buffer_content(text: &str) -> Cow<'_, str> {
    content_and_line_ending(text).0
}

/// [`buffer_content`], and the line ending `text` was written with.
fn content_and_line_ending(text: &str) -> (Cow<'_, str>, LineEnding) {
    let (content, line_ending) = normalize_line_endings_detecting(text);
    let content = match content {
        content if content.ends_with('\n') => content,
        Cow::Borrowed(text) => Cow::Owned([text, "\n"].concat()),
        Cow::Owned(mut text) => {
            text.push('\n');
            Cow::Owned(text)
        }
    };
    (content, line_ending)
}

// Implementing `Display` gives us `.to_string()` for free via the blanket
// `impl<T: Display> ToString for T`. This is the idiomatic Rust way: an
// inherent `to_string` method would shadow that blanket impl and trigger
// the `clippy::inherent_to_string` lint.
//
// Use `.to_string()` for tests, file I/O, and display, not in hot edit paths
// (it allocates a full String from the rope).
impl std::fmt::Display for BufferText {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.rope.fmt(f)
    }
}

// `PartialEq` for tests: compare text content only.
// `line_ending` is file-origin metadata and the version names a lineage, so
// two buffers with identical content are equal whatever their origin.
impl PartialEq for BufferText {
    fn eq(&self, other: &Self) -> bool {
        self.rope == other.rope
    }
}

impl Eq for BufferText {}

mod views;
pub use views::{ClusterView, ColumnView, LineView};

#[cfg(test)]
mod tests;
