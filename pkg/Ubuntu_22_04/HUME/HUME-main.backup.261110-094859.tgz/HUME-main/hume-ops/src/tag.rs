//! Lexical `<tag>` / `</tag>` scanning: `%`-style matching ([`matching_tag`])
//! and the tag-pair objects and navigation ([`inner_tag`], [`around_tag`],
//! [`adjacent_tag`]) that `hume-editor` falls back to where no tree-sitter
//! element object applies.
//!
//! Not tree-sitter-backed: `hume-ops` cannot depend on `hume-treesitter`.
//! This scan works in any buffer, including a scratch buffer with no
//! language at all. It's the same trade [`crate::pair`]'s lexical bracket
//! and quote scans make.
//!
//! Scans one char at a time via `chars_at` (never grapheme boundaries): the
//! same sanctioned exception `pair.rs` uses, since no grapheme cluster can be
//! mistaken for `<`, `>`, `/`, or a quote. Tag names are Unicode letters,
//! digits and combining marks, plus `_ : . -`.
//!
//! Tag names are compared case-sensitively (XML/JSX semantics). HUME has no
//! per-buffer markup-language config to decide HTML's case-insensitive
//! convention from.

use hume_editing::text::BufferText;
use hume_rope::cluster::{ClusterRange, ClusterStart};
use hume_rope::cursor::CharCursor;
use hume_rope::offset::{CharOffset, ExclusiveRange};
use unicode_normalization::char::is_combining_mark;

use crate::text_object::trim_blank;

/// One parsed `<name…>`, `<name…/>`, or `</name>` construct.
#[derive(Clone, Copy)]
struct Tag {
    closing: bool,
    self_closing: bool,
    name: ExclusiveRange<CharOffset>,
    lt_pos: CharOffset,
    gt_pos: CharOffset,
}

fn same_name(
    text: &BufferText,
    a: ExclusiveRange<CharOffset>,
    b: ExclusiveRange<CharOffset>,
) -> bool {
    // Equal names have equal char counts: a zero-cost rejection that skips
    // two `RopeSlice` tree walks (`slice`'s `PartialEq` only short-circuits on
    // `len_bytes` *after* building both) for the common case of hunting one
    // tag name through many others.
    a.end.chars_since(a.start) == b.end.chars_since(b.start) && text.slice(a) == text.slice(b)
}

const COMMENT_OPEN: &str = "<!--";

/// True if `<!--` starts at `lt_pos`.
fn is_comment_start(text: &BufferText, lt_pos: CharOffset) -> bool {
    let mut cursor = text.chars_at(lt_pos);
    COMMENT_OPEN
        .chars()
        .all(|expected| cursor.next().is_some_and(|(_, ch)| ch == expected))
}

/// Consume `cursor` through the terminator of an HTML comment whose `<!--`
/// prefix `cursor` has already consumed, or to the end of the buffer if it's
/// never closed, and return the terminator's `>`. An unterminated comment
/// swallows everything after it, so no tag inside it is reachable.
///
/// Also recognizes HTML5's abruptly-closed forms `<!-->` and `<!--->` (a
/// comment with zero or one dash before the first `>`), and `--!>` in place
/// of `-->`. All three are HTML5 parse errors but real markup hits them.
fn skip_comment_body(cursor: &mut CharCursor<'_>) -> Option<CharOffset> {
    let mut dashes = 0u32;
    // offset: chars consumed since the confirmed "<!--"
    for (offset, (i, ch)) in cursor.by_ref().enumerate() {
        match ch {
            '-' => dashes += 1,
            // `--!>` closes like `-->`, so keep `dashes` alive across the `!`.
            '!' if dashes >= 2 => {}
            '>' if dashes >= 2 || offset == 0 || (offset == 1 && dashes == 1) => return Some(i),
            _ => dashes = 0,
        }
    }
    None
}

/// The `>` ending the comment whose `<!--` starts at `lt_pos`.
fn comment_end(text: &BufferText, lt_pos: CharOffset) -> Option<CharOffset> {
    let mut cursor = text.chars_at(lt_pos.shift(COMMENT_OPEN.len() as isize));
    skip_comment_body(&mut cursor)
}

/// True if the `>` at `gt_pos` directly follows `--` or `--!`, the shape of
/// a comment terminator.
fn ends_like_a_comment(text: &BufferText, gt_pos: CharOffset) -> bool {
    let mut cursor = text.chars_at(gt_pos);
    let mut before = || cursor.prev().map(|(_, ch)| ch);
    let last = match before() {
        Some('!') => before(),
        last => last,
    };
    last == Some('-') && before() == Some('-')
}

/// The `<!--` of the comment the `>` at `gt_pos` terminates, or `None` when
/// that `>` ends no comment. The opener is the nearest `<!--` before it with
/// no other terminator-shaped `>` between, and [`skip_comment_body`] reading
/// forward from it has to stop at `gt_pos`, so a stray `-->` after a closed
/// comment hides nothing.
fn comment_start_before(text: &BufferText, gt_pos: CharOffset) -> Option<CharOffset> {
    if !ends_like_a_comment(text, gt_pos) {
        return None;
    }
    let mut cursor = text.chars_at(gt_pos);
    while let Some((i, ch)) = cursor.prev() {
        match ch {
            '<' if is_comment_start(text, i) => {
                return (comment_end(text, i) == Some(gt_pos)).then_some(i);
            }
            '>' if ends_like_a_comment(text, i) => return None,
            _ => {}
        }
    }
    None
}

/// Parse the tag construct starting at `lt_pos` (must be `<`, and not the
/// start of a comment) via `cursor`, which must already sit at `lt_pos + 1`
/// with `first` the pair that position yielded. [`next_tag`]'s shared
/// forward scan has already consumed it to rule out a comment, and a
/// `CharCursor` can't be rewound to hand it back. `None` for anything that
/// isn't a well-formed `<name…>`, `<name…/>`, or `</name>`: `<!DOCTYPE`,
/// `<?xml`, a bare `<` in running text or code, or an unterminated `<`.
/// Quote-aware: a `>` inside a `"…"`/`'…'` attribute value doesn't end the
/// tag, and braced expression attributes (`onClick={() => f()}`) don't end
/// early at the arrow's `>`. An unquoted, unbraced `<` (a stray comparison
/// operator or the start of the *next* tag) ends the parse with `None`
/// rather than being consumed as part of this one.
fn parse_tag(
    cursor: &mut CharCursor<'_>,
    lt_pos: CharOffset,
    first: (CharOffset, char),
) -> Option<Tag> {
    let (mut i, mut ch) = first;
    let closing = ch == '/';
    if closing {
        (i, ch) = cursor.next()?;
    }
    if !(ch.is_alphabetic() || ch == '_') {
        return None;
    }
    let name_start = i;
    let (mut i, mut ch) = loop {
        match cursor.next()? {
            (_, c)
                if c.is_alphanumeric()
                    || is_combining_mark(c)
                    || matches!(c, '_' | ':' | '.' | '-') => {}
            next => break next,
        }
    };
    let name = ExclusiveRange::new(name_start, i);

    let mut last_significant = None;
    let mut brace_depth = 0u32;
    loop {
        match ch {
            '"' | '\'' => {
                let quote = ch;
                loop {
                    let (_, c) = cursor.next()?;
                    if c == quote {
                        break;
                    }
                }
                last_significant = None;
            }
            '{' => {
                brace_depth += 1;
                last_significant = Some(ch);
            }
            '}' => {
                brace_depth = brace_depth.saturating_sub(1);
                last_significant = Some(ch);
            }
            '<' if brace_depth == 0 => return None,
            '>' if brace_depth == 0 => {
                return Some(Tag {
                    closing,
                    self_closing: !closing && last_significant == Some('/'),
                    name,
                    lt_pos,
                    gt_pos: i,
                });
            }
            c if !c.is_whitespace() => last_significant = Some(c),
            _ => {}
        }
        (i, ch) = cursor.next()?;
    }
}

/// Find the next tag construct `cursor` reaches, skipping HTML comments and
/// any `<` that doesn't parse as a well-formed tag. Advances `cursor` in
/// place rather than taking a `from: usize`: [`close_after`]/[`open_before`]
/// share one cursor across every tag in their scan, so ropey's O(log n) tree
/// descent to seek a starting position is paid once per scan, not once per
/// tag. A failed attempt (a stray `<`, or a `<!` that isn't a comment after
/// all) still needs to resume scanning right after that `<`. Reseeking
/// there with a fresh [`BufferText::chars_at`] is the one exception, kept to
/// that uncommon case instead of paid on every well-formed tag.
fn next_tag<'a>(text: &'a BufferText, cursor: &mut CharCursor<'a>) -> Option<Tag> {
    loop {
        let (lt_pos, ch) = cursor.next()?;
        if ch != '<' {
            continue;
        }
        let Some(first) = cursor.next() else {
            return None; // buffer ends right after '<', nothing more to find.
        };
        if first.1 == '!' {
            // Comments are the one construct `parse_tag` doesn't parse: it
            // would reject '!' as a name-start character regardless of what
            // follows, so a well-formed comment is resolved here instead of
            // costing a doomed `parse_tag` call.
            if matches!(cursor.next(), Some((_, '-'))) && matches!(cursor.next(), Some((_, '-'))) {
                skip_comment_body(cursor);
                continue;
            }
            // Not a comment either (`<!DOCTYPE`, stray `<!` junk). `parse_tag`
            // would reject '!' anyway, so fall through to the reseek below
            // instead of calling it.
        } else if let Some(tag) = parse_tag(cursor, lt_pos, first) {
            return Some(tag);
        }
        // Failed to parse a tag at `lt_pos`: resume right after it,
        // discarding whatever the comment check or `parse_tag` looked ahead
        // at, which could itself be the next tag's own `<` (as in `a<b\n<div>`).
        *cursor = text.chars_at(lt_pos.shift(1));
    }
}

/// Find the tag construct whose own markup (its `<`, its `>`, the name, or
/// an attribute) contains `pos`. Walks left from `pos` for the nearest `<`
/// and parses forward from there. Matching matchit/vim's `%`, which fires
/// from anywhere in a tag's own markup, not just its two delimiter chars.
///
/// The nearest preceding `<` does *not* always settle the answer on its own:
/// a `<` can sit inside an *enclosing* tag's own markup, such as a quoted attribute
/// value (`<a t="<">`) or a braced JSX expression (`<div onClick={a < b}>`),
/// where it parses as nothing at all. When that happens, `pos` may still
/// be inside that enclosing tag, so scanning must continue left past it.
/// Two other outcomes end the walk immediately: a `<` starting a comment (no
/// tag can be found through it), and a `<` that parses into a well-formed
/// tag not reaching `pos` (a real tag boundary lies between it and `pos`,
/// which therefore isn't inside any tag's markup).
///
/// This keeps the common case (`#` pressed somewhere that isn't inside any
/// tag) to a short local walk instead of a whole-buffer parse.
fn tag_at(text: &BufferText, pos: CharOffset) -> Option<Tag> {
    let mut cursor = text.chars_at(pos.shift(1));
    while let Some((i, ch)) = cursor.prev() {
        if ch != '<' {
            continue;
        }
        let lt_pos = i;
        if is_comment_start(text, lt_pos) {
            return None;
        }
        match parse_tag_at(text, lt_pos) {
            Some(tag) if tag.lt_pos <= pos && pos <= tag.gt_pos => {
                return Some(tag);
            }
            Some(_) => return None,
            None => continue,
        }
    }
    None
}

/// [`parse_tag`] for a one-off call, building its own cursor from `lt_pos`.
/// [`tag_at`]'s single backward-search call per `#` press is the only
/// caller. Sharing a cursor across calls buys nothing there, unlike
/// [`next_tag`]'s forward multi-tag scans.
fn parse_tag_at(text: &BufferText, lt_pos: CharOffset) -> Option<Tag> {
    let mut cursor = text.chars_at(lt_pos.shift(1));
    let first = cursor.next()?;
    parse_tag(&mut cursor, lt_pos, first)
}

/// Forward scan for the tag that closes `open` (`<name>` → matching
/// `</name>`), tracking nesting depth for same-name tags only: the same
/// technique [`crate::pair::scan_right_for_close`] uses for brackets.
/// `open` must be a non-closing, non-self-closing tag.
fn close_after(text: &BufferText, open: &Tag) -> Option<Tag> {
    let mut depth = 0usize;
    let mut cursor = text.chars_at(open.gt_pos.shift(1));
    while let Some(tag) = next_tag(text, &mut cursor) {
        if tag.self_closing || !same_name(text, tag.name, open.name) {
            continue;
        }
        if tag.closing {
            if depth == 0 {
                return Some(tag);
            }
            depth -= 1;
        } else {
            depth += 1;
        }
    }
    None
}

/// Backward counterpart to [`next_tag`]: the nearest tag construct strictly
/// before `before`, skipping any `<` that doesn't parse as a well-formed tag.
/// Reuses the forward [`parse_tag_at`] rather than a mirrored reverse lexer:
/// finding `<` backward is unambiguous, but a lexer that also had to
/// un-consume a quoted attribute or braced JSX expression in reverse would
/// duplicate [`parse_tag`]'s whole state machine for zero correctness gain
/// over just parsing forward from each candidate.
///
/// A comment is skipped whole: a `>` that [`comment_start_before`] pairs
/// with a `<!--` moves the walk to before that `<!--`, so a tag-shaped
/// fragment in the comment's body is never returned.
///
/// The reuse has a gap: a `<` inside an *enclosing* tag's own quoted
/// attribute or JSX brace (`title="</div>"`) is invisible to the forward
/// lexer (consumed whole as part of the enclosing tag's own parse) but can
/// itself parse as a well-formed tag when found this way, corrupting
/// [`open_before`]'s depth count. An unbalanced fragment there (one
/// tag-shaped construct, not a real pair) triggers it; a balanced one
/// cancels itself out and is harmless. A comment that is never closed, or
/// whose `<!--` is not the nearest one before its end (a doubled `<!--`, or
/// one inside a quoted attribute), has the same gap. Accepted as known
/// limitations of the lexical scanner.
fn prev_tag(text: &BufferText, before: CharOffset) -> Option<Tag> {
    let mut cursor = text.chars_at(before);
    while let Some((i, ch)) = cursor.prev() {
        if ch == '<'
            && !is_comment_start(text, i)
            && let Some(tag) = parse_tag_at(text, i)
        {
            return Some(tag);
        }
        if ch == '>'
            && let Some(start) = comment_start_before(text, i)
        {
            cursor = text.chars_at(start);
        }
    }
    None
}

/// Every tag construct before `before`, nearest first: [`prev_tag`] repeated.
fn tags_before(text: &BufferText, mut before: CharOffset) -> impl Iterator<Item = Tag> + '_ {
    std::iter::from_fn(move || {
        let tag = prev_tag(text, before)?;
        before = tag.lt_pos;
        Some(tag)
    })
}

/// Depth-tracked backward walk from `close` for the innermost still-open
/// same-name tag: the same technique [`crate::pair::scan_left_for_open`]
/// uses for brackets, applied via [`prev_tag`] instead of a raw char scan.
/// Scans outward from the cursor rather than from the start of the buffer:
/// depth-tracked matching is direction-symmetric, so this returns the same
/// answer [`close_after`]'s forward, from-open-tag scan would give in
/// reverse, while typically touching only the handful of tags between
/// `close` and its partner instead of the whole preceding buffer. See
/// [`prev_tag`]'s doc for the one case this reuse doesn't handle.
fn open_before(text: &BufferText, close: &Tag) -> Option<Tag> {
    let mut depth = 0usize;
    for tag in tags_before(text, close.lt_pos) {
        if tag.self_closing || !same_name(text, tag.name, close.name) {
            continue;
        }
        if tag.closing {
            depth += 1;
        } else if depth == 0 {
            return Some(tag);
        } else {
            depth -= 1;
        }
    }
    None
}

/// Find the matching partner of the tag at `pos`: given the cursor anywhere
/// inside a `<name…>` or `</name>` construct (its `<`, its `>`, the name, or
/// an attribute), return the cluster holding its partner's `<`. `None` when `pos` isn't
/// inside a tag's own markup, the tag is self-closing (no partner), or it's
/// never closed or opened.
///
/// A same-name open discarded by an unmatched close never affects an
/// enclosing tag of a *different* name. [`close_after`] and
/// [`open_before`] each track only the one name they were asked about, so a
/// stray `</span>` can't drain an unrelated `<div>` off some shared stack.
pub(crate) fn matching_tag(text: &BufferText, pos: ClusterStart) -> Option<ClusterStart> {
    let tag = tag_at(text, pos.offset())?;
    let element = Element::of(text, tag)?;
    let partner = if tag.closing {
        element.open
    } else {
        element.close?
    };
    Some(text.snap(partner.lt_pos))
}

/// An opening tag and the tag that closes it. `close` is `None` for a
/// self-closing tag and for one never closed (an HTML void `<br>`), whose
/// element is the tag alone.
struct Element {
    open: Tag,
    close: Option<Tag>,
}

impl Element {
    /// The element `tag` opens or closes. `None` for a closing tag with no
    /// opening partner.
    fn of(text: &BufferText, tag: Tag) -> Option<Self> {
        if tag.closing {
            open_before(text, &tag).map(|open| Self {
                open,
                close: Some(tag),
            })
        } else {
            Some(Self::from_open(text, tag))
        }
    }

    /// `open` must be a non-closing tag.
    fn from_open(text: &BufferText, open: Tag) -> Self {
        let close = if open.self_closing {
            None
        } else {
            close_after(text, &open)
        };
        Self { open, close }
    }

    /// From the opening `<` through the closing `>`.
    fn around(&self, text: &BufferText) -> Option<ClusterRange> {
        let last = self.close.unwrap_or(self.open);
        text.covering(ExclusiveRange::new(self.open.lt_pos, last.gt_pos.shift(1)))
    }

    /// The content between the two tags, trimmed of blanks on both sides,
    /// which is the span a tree-sitter `xml-element.inside` capture hulls.
    /// `None` without a closing tag or when the content is blank.
    fn inner(&self, text: &BufferText) -> Option<ClusterRange> {
        let close = self.close?;
        let content = text.within(ExclusiveRange::new(self.open.gt_pos.shift(1), close.lt_pos))?;
        trim_blank(text, content)
    }
}

/// The elements enclosing `pos`, innermost first. With `pos` on a tag's own
/// markup the first is that tag's element (an opening tag, its closing
/// partner, or a lone void or self-closing tag); a closing tag with no
/// opening partner contributes nothing.
///
/// The rest come from walking tags backward. A closing tag counts against
/// the next same-name opening tag; an opening tag left over is an enclosing
/// element when [`close_after`] finds its partner, and a void tag otherwise.
/// A name whose opening tag had no partner goes in `unclosed`: an earlier
/// opening tag of that name, with no closing tag pending, has none either,
/// so one void name costs one scan to the end of the buffer, not one per
/// occurrence. A void tag under `pos` starts the list.
fn enclosing_elements(text: &BufferText, pos: CharOffset) -> impl Iterator<Item = Element> + '_ {
    let (own, before) = match tag_at(text, pos) {
        Some(tag) => {
            let own = Element::of(text, tag);
            let before = own.as_ref().map_or(tag.lt_pos, |e| e.open.lt_pos);
            (own, before)
        }
        None => (None, pos),
    };
    let mut closes = Vec::new();
    let mut unclosed: Vec<_> = own
        .as_ref()
        .filter(|e| e.close.is_none() && !e.open.self_closing)
        .map(|e| e.open.name)
        .into_iter()
        .collect();
    let ancestors = tags_before(text, before).filter_map(move |tag| {
        if tag.self_closing {
            return None;
        }
        if tag.closing {
            closes.push(tag.name);
            return None;
        }
        if let Some(i) = closes
            .iter()
            .position(|&name| same_name(text, name, tag.name))
        {
            closes.swap_remove(i);
            return None;
        }
        if unclosed.iter().any(|&name| same_name(text, name, tag.name)) {
            return None;
        }
        match close_after(text, &tag) {
            Some(close) => Some(Element {
                open: tag,
                close: Some(close),
            }),
            None => {
                unclosed.push(tag.name);
                None
            }
        }
    });
    own.into_iter().chain(ancestors)
}

/// The innermost element whose markup or content holds `pos`, from its
/// opening `<` through its closing `>`.
pub fn around_tag(text: &BufferText, pos: ClusterStart) -> Option<ClusterRange> {
    enclosing_elements(text, pos.offset()).next()?.around(text)
}

/// The content of the innermost element whose trimmed content holds `pos`.
/// On a tag's own markup that is the parent's content, as with a
/// tree-sitter `xml-element.inside` capture, which never covers its own
/// tags.
pub fn inner_tag(text: &BufferText, pos: ClusterStart) -> Option<ClusterRange> {
    enclosing_elements(text, pos.offset())
        .find_map(|e| e.inner(text).filter(|range| range.contains(pos)))
}

/// The whole element whose opening tag starts nearest after `pos`
/// (`backward`: before it), skipping closing tags. The element under the
/// cursor counts backward but not forward, so a backward step from inside
/// an element lands on its own start first. The returned start always lies
/// strictly past (before) `pos`'s cluster, the progress
/// [`crate::motion::apply_object_motion`] requires.
pub fn adjacent_tag(text: &BufferText, pos: ClusterStart, backward: bool) -> Option<ClusterRange> {
    let open = if backward {
        tags_before(text, pos.offset()).find(|tag| !tag.closing)?
    } else {
        let from = tag_at(text, pos.offset()).map_or(pos.offset(), |t| t.gt_pos.shift(1));
        let mut cursor = text.chars_at(from);
        std::iter::from_fn(|| next_tag(text, &mut cursor))
            .find(|tag| !tag.closing && text.snap(tag.lt_pos) > pos)?
    };
    Element::from_open(text, open).around(text)
}
