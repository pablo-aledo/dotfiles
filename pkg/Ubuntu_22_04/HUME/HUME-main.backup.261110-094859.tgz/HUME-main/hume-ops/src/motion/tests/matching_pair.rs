use super::super::*;
use test_fixtures::assert_state;

// ── Brackets ──────────────────────────────────────────────────────────────

#[test]
fn goto_matching_pair_paren_open_to_close() {
    assert_state!(
        "-[(]>hello)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "(hello-[)]>\n"
    );
}

#[test]
fn goto_matching_pair_paren_close_to_open() {
    assert_state!(
        "(hello-[)]>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[(]>hello)\n"
    );
}

#[test]
fn goto_matching_pair_bracket() {
    assert_state!(
        "-[[]>hello]\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "[hello-[]]>\n"
    );
}

#[test]
fn goto_matching_pair_brace() {
    assert_state!(
        "-[{]>hello}\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "{hello-[}]>\n"
    );
}

#[test]
fn goto_matching_pair_nested() {
    // Cursor on the inner '(' must land on the inner ')', not the outer one.
    assert_state!(
        "(a -[(]>b) c)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "(a (b-[)]> c)\n"
    );
}

#[test]
fn goto_matching_pair_unmatched_is_noop() {
    assert_state!(
        "-[(]>hello\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[(]>hello\n"
    );
}

#[test]
fn goto_matching_pair_not_on_delimiter_is_noop() {
    // Strict mode: no forward line-scan. Cursor mid-word does nothing.
    assert_state!(
        "hel-[l]>o(x)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "hel-[l]>o(x)\n"
    );
}

#[test]
fn goto_matching_pair_extend_keeps_anchor() {
    // Head starts on the '(' itself. The motion only fires from a
    // delimiter, so the anchor grows the selection to cover the whole pair.
    assert_state!(
        "-[foo(]>x)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Extend
        ),
        "-[foo(x)]>\n"
    );
}

// ── Selection-wide resolution ────────────────────────────────────────────
//
// A `w`-style selection ends on the whitespace following a bracket, not on
// the bracket itself (word-selects-whitespace is by design). `#` must still
// resolve from anywhere in the selection, not just the head.

#[test]
fn goto_matching_pair_head_on_whitespace_after_close_resolves() {
    // Forward selection, head past the ')'. Head is the selection's own
    // far edge, so resolution walks inward (leftward) toward the anchor.
    assert_state!(
        "pub(crate-[) ]>foo\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "pub-[(]>crate) foo\n"
    );
}

#[test]
fn goto_matching_pair_backward_selection_head_before_open_resolves() {
    // Backward selection, head before the '('. Head is again the
    // selection's near edge, so resolution walks inward (rightward).
    assert_state!(
        "x<[ (y)]- z\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "x (y-[)]> z\n"
    );
}

#[test]
fn goto_matching_pair_picks_nearest_bracket_not_leftmost() {
    // Selection spans two independent pairs, "(a)(b". The nearest bracket to
    // the head is the second pair's '(' (distance 1), not the leftmost
    // bracket in the selection, the first pair's '(' (distance 4), which
    // would jump somewhere else entirely.
    assert_state!(
        "-[(a)(b]>)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "(a)(b-[)]>\n"
    );
}

#[test]
fn goto_matching_pair_extend_from_non_head_bracket_keeps_anchor() {
    assert_state!(
        "(-[x) ]>z\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Extend
        ),
        "<[(x]-) z\n"
    );
}

#[test]
fn goto_matching_pair_bracket_outside_selection_is_noop() {
    // '(f)' sits past the selection's own end, so it must not be picked up:
    // resolution is bounded by the selection, not the whole line. Move mode
    // still collapses to the (unchanged) head, same as any other no-op.
    assert_state!(
        "a-[bc d]>e(f)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "abc -[d]>e(f)\n"
    );
}

#[test]
fn goto_matching_pair_multiline_selection_ignores_bracket_elsewhere_in_span() {
    // The '(' is inside the selection but on a different line than the head.
    // A multi-line selection only ever probes the head's own cluster
    // (bounding the scan to O(line) instead of O(selection length), since
    // this resolver also runs once per frame for the bracket-match
    // highlight). `w`/`W`/`maw` selections never cross a line (their
    // whitespace bookend stops at a newline), so this never loses the
    // motivating `") "` case.
    assert_state!(
        "-[(x\ny]>)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "(x\n-[y]>)\n"
    );
}

#[test]
fn goto_matching_pair_multiline_selection_head_on_bracket_still_resolves() {
    // Same multi-line shape, but the head itself sits on the bracket. The
    // single-line restriction only narrows the *fallback* scan; it must
    // never stop the head's own cluster from resolving.
    assert_state!(
        "-[x\n(]>y)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "x\n(y-[)]>\n"
    );
}

#[test]
fn goto_matching_pair_tag_in_selection_but_not_under_head_is_noop() {
    // Brackets-only span-wide resolution: a tag fully inside the selection
    // doesn't make `#` jump when the head itself isn't on the tag's markup.
    assert_state!(
        "-[<div>x]>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div>-[x]>\n"
    );
}

// ── Tags ──────────────────────────────────────────────────────────────────

#[test]
fn goto_matching_pair_tag_open_to_close() {
    assert_state!(
        "-[<]>div>x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div>x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_close_to_open() {
    assert_state!(
        "<div>x-[<]>/div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>div>x</div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_gt_lands_on_partner_lt() {
    // Cursor on the *opening* tag's own '>' still resolves, landing on the
    // closing tag's '<', not its own '>'.
    assert_state!(
        "<div-[>]>x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div>x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_cursor_on_name_resolves() {
    // Cursor inside the tag name, not on '<' or '>' at all: matchit/vim's
    // `%` fires from anywhere in the tag, not just its two delimiters.
    assert_state!(
        "<d-[i]>v class=\"x\">y</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div class=\"x\">y-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_cursor_in_attribute_value_resolves() {
    assert_state!(
        "<div class=\"-[x]>\">y</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div class=\"x\">y-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_self_closing_tag_cursor_inside_is_noop() {
    // Still no-op from inside a self-closing tag's own markup: it has no
    // partner regardless of where the cursor sits within it.
    assert_state!(
        "<b-[r]> class=\"x\"/>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<b-[r]> class=\"x\"/>\n"
    );
}

#[test]
fn goto_matching_pair_element_body_content_is_noop() {
    // Cursor in the element's body content (outside either tag's own
    // markup span) must NOT resolve; widening covers the tag itself, not
    // everything between an open and close tag.
    assert_state!(
        "<div>-[x]></div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div>-[x]></div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_nested_same_name() {
    assert_state!(
        "-[<]>div><div>x</div></div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div><div>x</div>-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_self_closing_tag_is_noop() {
    assert_state!(
        "-[<]>br/>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>br/>\n"
    );
}

#[test]
fn goto_matching_pair_tag_in_comment_is_noop() {
    assert_state!(
        "<!-- -[<]>div> -->\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<!-- -[<]>div> -->\n"
    );
}

#[test]
fn goto_matching_pair_gt_inside_quoted_attribute_is_not_tag_end() {
    // The '>' inside the quoted attribute value doesn't close the tag, so
    // the real terminating '>' (the last char) is what the open tag matches.
    assert_state!(
        "-[<]>div title=\"a>b\">x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div title=\"a>b\">x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_gt_after_quoted_lt_attribute_resolves() {
    // The opening tag's own attribute value contains a literal '<'. `#` on
    // the tag's real closing '>' must still walk past that quoted '<' to
    // find the tag's own '<', not bail out at it.
    assert_state!(
        "<a t=\"<\"-[>]>x</a>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<a t=\"<\">x-[<]>/a>\n"
    );
}

#[test]
fn goto_matching_pair_angle_generic_is_noop() {
    // `Vec<String>` parses as a plausible open tag lexically, but there is
    // no matching `</String>` anywhere, so it never resolves.
    assert_state!(
        "Vec-[<]>String>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "Vec-[<]>String>\n"
    );
}

#[test]
fn goto_matching_pair_comparison_operators_are_noop() {
    assert_state!(
        "a -[<]> b && c > d\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a -[<]> b && c > d\n"
    );
}

#[test]
fn goto_matching_pair_doctype_is_noop() {
    assert_state!(
        "-[<]>!DOCTYPE html>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>!DOCTYPE html>\n"
    );
}

#[test]
fn goto_matching_pair_stray_close_does_not_drain_enclosing_open() {
    // A `</span>` with no matching `<span>` must not discard `<div>` off a
    // shared stack: `#` on `<div>` still finds its own `</div>`.
    assert_state!(
        "-[<]>div>\n</span>\n<b>x</b>\n</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div>\n</span>\n<b>x</b>\n-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_unspaced_comparison_does_not_swallow_next_tag() {
    // `a<b` with no space read as a lexical `<` start, but the following
    // `<div>` must still parse as its own tag rather than being consumed as
    // part of `a<b`'s (nonexistent) markup.
    assert_state!(
        "a<b\n-[<]>div>x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a<b\n<div>x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_doubled_lt_does_not_hide_nested_same_name_open() {
    // The stray second '<' in "<<div>" fails to parse as a tag itself, but
    // scanning must still rediscover the *inner* "<div>" starting right
    // after it. Missing that open would leave its depth uncounted, and the
    // outer "</div>" would wrongly resolve to the inner tag's own close.
    assert_state!(
        "-[<]>div><<div>x</div></div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div><<div>x</div>-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_close_to_open_nested_same_name() {
    // Mirror of `_tag_nested_same_name`, in the close-to-open direction:
    // from the outer close, must walk past the inner (already-matched) pair
    // to land on the outer open, not stop at the inner one.
    assert_state!(
        "<div><div>x</div>-[<]>/div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>div><div>x</div></div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_close_to_open_picks_innermost_unclosed_open() {
    // Two opens, one close: the close must pair with the nearer
    // (innermost) open, leaving the outer one permanently unmatched: the
    // "unmatched same-name open earlier in the buffer" case.
    assert_state!(
        "<div>\n<div>x-[<]>/div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div>\n-[<]>div>x</div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_close_to_open_doubled_lt_does_not_stop_walk() {
    // Backward mirror of `_doubled_lt_does_not_hide_nested_same_name_open`:
    // the stray second '<' between the outer and inner open must not stop
    // the backward walk before it reaches the outer open.
    assert_state!(
        "<div><<div>x</div>-[<]>/div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>div><<div>x</div></div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_close_to_open_skips_a_commented_close_tag() {
    assert_state!(
        "<div><!-- </div> -->x-[<]>/div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>div><!-- </div> -->x</div>\n"
    );
}

#[test]
fn goto_matching_pair_tag_quoted_close_tag_before_partner_is_known_limitation() {
    // Known limitation of the backward scan: a `<` inside an enclosing
    // tag's own quoted attribute can itself parse as a well-formed tag when
    // found by walking backward for `<` (the forward lexer never sees it,
    // since the whole attribute is consumed by one `parse_tag` call). Here
    // it throws off the depth count enough that the real open is never
    // reached. Accepted rather than fixed; see `prev_tag`'s doc comment.
    assert_state!(
        "<div title=\"</div>\">x-[<]>/div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div title=\"</div>\">x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_unspaced_comparison_body_text_is_noop() {
    // The cursor sits in ordinary body text after an unspaced `a<b`. It must
    // not resolve as if it were inside `a<b`'s markup.
    assert_state!(
        "a<b -[t]>hen</b>x</b>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a<b -[t]>hen</b>x</b>\n"
    );
}

#[test]
fn goto_matching_pair_jsx_expression_attribute_resolves() {
    // The arrow function's own `=>` must not be read as the tag's closing
    // `>`: the real closing `>` is four characters later.
    assert_state!(
        "-[<]>div onClick={() => f()}>x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div onClick={() => f()}>x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_jsx_expression_attribute_ignores_quoted_close_tag() {
    // A later attribute's quoted value contains literal `</div>` text. The
    // partner must be the real closing tag, not the string.
    assert_state!(
        "-[<]>div onClick={() => f()} title=\"</div>\">x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<div onClick={() => f()} title=\"</div>\">x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_abruptly_closed_comment_zero_dashes() {
    // `<!-->` is HTML5's abrupt comment close (zero dashes before `>`). The
    // comment must not swallow the well-formed tag after it.
    assert_state!(
        "<!-->\n-[<]>div>x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<!-->\n<div>x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_abruptly_closed_comment_one_dash() {
    // `<!--->` is HTML5's other abrupt comment close (one dash before `>`).
    assert_state!(
        "<!--->\n-[<]>div>x</div>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<!--->\n<div>x-[<]>/div>\n"
    );
}

#[test]
fn goto_matching_pair_lands_on_grapheme_boundary_not_mid_cluster() {
    // U+0600 (ARABIC NUMBER SIGN) is a `GC_Prepend` codepoint that joins
    // forward with the following ')' into one grapheme cluster. The partner
    // offset falls on the ')' itself (one char into that cluster), so the
    // cursor lands on the cluster's start.
    assert_state!(
        "-[(]>\u{0600})\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "(-[\u{0600})]>\n"
    );
}

#[test]
fn goto_matching_pair_twice_is_involution_across_prepend_cluster() {
    // A second `#` press from the grapheme-snapped landing position (see
    // the test above) must still resolve: `matching_bracket` has to
    // recognize the bracket even when `pos` sits on the GC_Prepend
    // codepoint leading its cluster, not on the bracket char itself.
    assert_state!(
        "-[(]>\u{0600})\n",
        |(text, sels)| {
            let once = cmd_goto_matching_pair(
                test_fixtures::testing::state(text, sels),
                1,
                MotionMode::Move,
            );
            cmd_goto_matching_pair(once, 1, MotionMode::Move)
        },
        "-[(]>\u{0600})\n"
    );
}

#[test]
fn goto_matching_pair_ignores_count() {
    // `#` is an involution: folding it N times would make even counts a
    // no-op and odd counts identical to a bare `#`. Vim's `count%` means "go
    // to N% of the file", a different operation this motion doesn't
    // implement, so count is ignored entirely rather than folded.
    assert_state!(
        "-[(]>hello)\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            2,
            MotionMode::Move
        ),
        "(hello-[)]>\n"
    );
}

#[test]
fn goto_matching_pair_tag_with_an_accented_name() {
    assert_state!(
        "-[<]>caf\u{e9}>x</caf\u{e9}>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<caf\u{e9}>x-[<]>/caf\u{e9}>\n"
    );
}

#[test]
fn goto_matching_pair_tag_with_a_decomposed_accent_in_its_name() {
    assert_state!(
        "-[<]>cafe\u{301}>x</cafe\u{301}>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<cafe\u{301}>x-[<]>/cafe\u{301}>\n"
    );
}

#[test]
fn goto_matching_pair_tag_with_a_cjk_name() {
    assert_state!(
        "-[<]>\u{65e5}\u{672c}>x</\u{65e5}\u{672c}>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<\u{65e5}\u{672c}>x-[<]>/\u{65e5}\u{672c}>\n"
    );
}

#[test]
fn goto_matching_pair_tag_self_closing_with_a_non_breaking_space_before_the_gt() {
    assert_state!(
        "-[<]>a><a/\u{a0}></a>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<a><a/\u{a0}>-[<]>/a>\n"
    );
}

#[test]
fn goto_matching_pair_tag_with_non_ascii_text_and_attributes_between() {
    assert_state!(
        "-[<]>p title=\"caf\u{e9}>\">\u{6f22}\u{5b57}e\u{301}</p>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<p title=\"caf\u{e9}>\">\u{6f22}\u{5b57}e\u{301}-[<]>/p>\n"
    );
}

#[test]
fn goto_matching_pair_tag_close_to_open_over_a_multi_codepoint_cluster() {
    assert_state!(
        "<p>\u{1f468}\u{200d}\u{1f469}-[<]>/p>\n",
        |(text, sels)| cmd_goto_matching_pair(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[<]>p>\u{1f468}\u{200d}\u{1f469}</p>\n"
    );
}
