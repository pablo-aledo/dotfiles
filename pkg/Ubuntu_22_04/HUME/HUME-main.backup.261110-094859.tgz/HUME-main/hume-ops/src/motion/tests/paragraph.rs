use super::super::*;
use test_fixtures::assert_state;

// ── goto_next_paragraph (`}`) ────────────────────────────────────────────────

#[test]
fn goto_next_paragraph_basic() {
    // Selects the next paragraph. No trailing gap here ("foo" is the last
    // paragraph), so the span stops at its own text.
    assert_state!(
        "-[h]>ello\nworld\n\nfoo\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "hello\nworld\n\n<[foo]-\n"
    );
}

#[test]
fn goto_next_paragraph_multiline() {
    assert_state!(
        "-[a]>\n\nfoo\nbar\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n<[foo\nbar]-\n"
    );
}

#[test]
fn goto_next_paragraph_includes_trailing_gap() {
    // The target paragraph isn't the last one, so its own trailing gap is
    // part of the selection too.
    assert_state!(
        "-[a]>\n\nfoo\n\nbar\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n<[foo\n\n]-bar\n"
    );
}

#[test]
fn goto_next_paragraph_gap_reaches_buffer_end() {
    // The target paragraph's trailing gap runs all the way to EOF (two
    // blank lines, no paragraph below), so the span must stop at the
    // buffer's last valid position (content domain), not walk onto the
    // phantom trailing line one past it. See `paragraph_span`'s doc
    // comment.
    assert_state!(
        "-[a]>\n\nb\n\n\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n<[b\n\n\n]-"
    );
}

#[test]
fn goto_next_paragraph_multiple_empty_lines() {
    // A two-line gap between the current and target paragraphs: both are
    // swallowed reaching "foo", not just the nearer one.
    assert_state!(
        "-[a]>\n\n\nfoo\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n\n<[foo]-\n"
    );
}

#[test]
fn goto_next_paragraph_from_empty_line() {
    assert_state!(
        "-[\n]>\nfoo\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "\n\n<[foo]-\n"
    );
}

#[test]
fn goto_next_paragraph_no_paragraph_below_is_noop() {
    assert_state!(
        "-[h]>ello\nworld\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[h]>ello\nworld\n"
    );
}

#[test]
fn goto_next_paragraph_at_eof_is_noop() {
    assert_state!(
        "hello-[\n]>",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "hello-[\n]>"
    );
}

#[test]
fn goto_next_paragraph_empty_buffer_is_noop() {
    assert_state!(
        "-[\n]>",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[\n]>"
    );
}

#[test]
fn goto_next_paragraph_sequential() {
    // Two consecutive `}` presses walk through three paragraphs.
    assert_state!(
        "-[a]>\n\nb\n\nc\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n<[b\n\n]-c\n"
    );
    assert_state!(
        "a\n\n<[b\n\n]-c\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\nb\n\n<[c]-\n"
    );
}

#[test]
fn goto_next_paragraph_count_two_matches_two_presses() {
    assert_state!(
        "-[a]>\n\nb\n\nc\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            2,
            MotionMode::Move
        ),
        "a\n\nb\n\n<[c]-\n"
    );
}

#[test]
fn goto_next_paragraph_count_overshoot_stops_at_last() {
    // Only 2 paragraphs lie below "a", so a count of 5 stops at "c" (the last
    // one) rather than erroring or wrapping past it.
    assert_state!(
        "-[a]>\n\nb\n\nc\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            5,
            MotionMode::Move
        ),
        "a\n\nb\n\n<[c]-\n"
    );
}

// ── goto_prev_paragraph (`{`) ────────────────────────────────────────────────

#[test]
fn goto_prev_paragraph_basic() {
    assert_state!(
        "hello\n\nwor-[l]>d\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[hello\n\n]-world\n"
    );
}

#[test]
fn goto_prev_paragraph_multiline() {
    assert_state!(
        "foo\nbar\n\nba-[z]>\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[foo\nbar\n\n]-baz\n"
    );
}

#[test]
fn goto_prev_paragraph_multiple_empty_lines() {
    assert_state!(
        "hello\n\n\nwor-[l]>d\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[hello\n\n\n]-world\n"
    );
}

#[test]
fn goto_prev_paragraph_no_paragraph_above_is_noop() {
    assert_state!(
        "-[h]>ello\nworld\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[h]>ello\nworld\n"
    );
}

#[test]
fn goto_prev_paragraph_from_gap_selects_nearest_paragraph() {
    // Cursor sits in the gap above one preceding paragraph: that paragraph
    // (plus the gap it's already in) is the target.
    assert_state!(
        "hello\n-[\n]>world\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[hello\n\n]-world\n"
    );
}

#[test]
fn goto_prev_paragraph_from_gap_selects_nearest_not_the_one_before_it() {
    // Two paragraphs precede the gap: the nearest one ("hello") is the
    // target, not the one before it ("foo"). A backward scan that skipped
    // an extra paragraph here would land on "foo" instead.
    assert_state!(
        "foo\n\nhello\n-[\n]>world\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "foo\n\n<[hello\n\n]-world\n"
    );
}

#[test]
fn goto_prev_paragraph_from_gap_includes_blank_lines_below_the_cursor() {
    // The backward walk only counts the blanks at or above the cursor; the
    // target paragraph's gap continues past it, so the span must still reach
    // the last blank line.
    assert_state!(
        "hello\n-[\n]>\nworld\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[hello\n\n\n]-world\n"
    );
}

#[test]
fn goto_prev_paragraph_from_leading_gap_is_noop() {
    // Nothing precedes the gap itself: no previous paragraph exists.
    assert_state!(
        "-[\n]>hello\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[\n]>hello\n"
    );
}

#[test]
fn goto_prev_paragraph_count_overshoot_stops_at_first() {
    // Only 2 paragraphs lie above "c", so a count of 5 stops at "a" (the
    // first one) rather than erroring or wrapping past it.
    assert_state!(
        "a\n\nb\n\n-[c]>\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            5,
            MotionMode::Move
        ),
        "<[a\n\n]-b\n\nc\n"
    );
}

#[test]
fn goto_prev_paragraph_sequential() {
    assert_state!(
        "a\n\nb\n\n-[c]>\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n<[b\n\n]-c\n"
    );
    assert_state!(
        "a\n\n<[b\n\n]-c\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[a\n\n]-b\n\nc\n"
    );
}

#[test]
fn goto_prev_paragraph_empty_buffer_is_noop() {
    assert_state!(
        "-[\n]>",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "-[\n]>"
    );
}

// ── Extend variants ───────────────────────────────────────────────────────────

#[test]
fn extend_goto_next_paragraph_creates_selection() {
    assert_state!(
        "-[h]>ello\n\nworld\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Extend
        ),
        "-[hello\n\nworld]>\n"
    );
}

#[test]
fn extend_goto_next_paragraph_after_move_keeps_both_paragraphs() {
    assert_state!(
        "a\n\n<[b\n\n]-c\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Extend
        ),
        "a\n\n-[b\n\nc]>\n"
    );
}

#[test]
fn extend_goto_prev_paragraph_creates_selection() {
    assert_state!(
        "hello\n\n-[w]>orld\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Extend
        ),
        "<[hello\n\nw]-orld\n"
    );
}

#[test]
fn extend_goto_prev_paragraph_after_move_keeps_both_paragraphs() {
    assert_state!(
        "a\n\n<[b\n\n]-c\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Extend
        ),
        "<[a\n\nb\n\n]-c\n"
    );
}

// ── Multi-cursor ─────────────────────────────────────────────────────────────

#[test]
fn goto_next_paragraph_multi_cursor_merges_when_target_overlaps() {
    // The 'w' cursor's target ("foo") fully contains the 'f' cursor's own
    // unchanged position (no paragraph below it), so the two merge.
    assert_state!(
        "hello\n\n-{w}>orld\n\n-[f]>oo\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "hello\n\nworld\n\n<[foo]-\n"
    );
}

#[test]
fn goto_prev_paragraph_multi_cursor() {
    assert_state!(
        "hello\n\n-{w}>orld\n\n-[f]>oo\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<{hello\n\n}-<[world\n\n]-foo\n"
    );
}

// ── Rope chunk boundaries ────────────────────────────────────────────────────
//
// One unbroken 300-line paragraph, several times larger than a rope leaf
// (`MAX_BYTES`/`MIN_BYTES` are a few hundred bytes each), so a scan that
// walks the whole paragraph must step from one chunk to the next, not just
// seek within a single leaf. The cursor sits at one end of that paragraph so
// the *scan itself* (not just the O(log n) seek to reach it) crosses chunks.

fn chunk_boundary_padding() -> String {
    (0..300).map(|i| format!("padding line {i}\n")).collect()
}

#[test]
fn goto_next_paragraph_crosses_rope_chunk_boundaries() {
    // Cursor on the paragraph's first line: `}`'s skip-current-paragraph
    // phase must walk all 300 lines forward, across every chunk boundary, to
    // find this paragraph's own end before it can land on `foo`.
    let padding = chunk_boundary_padding();
    let (first_byte, rest) = padding.split_at(1);
    let initial = format!("-[{first_byte}]>{rest}\n\nfoo\n");
    let expected = format!("{padding}\n\n<[foo]-\n");
    assert_state!(
        initial.as_str(),
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        expected.as_str()
    );
}

#[test]
fn goto_prev_paragraph_crosses_rope_chunk_boundaries() {
    // Cursor in the short paragraph after the padding: `{`'s backward cursor
    // must walk from the padding's last line to its first, across every
    // chunk boundary, to find where the target paragraph begins.
    let padding = chunk_boundary_padding();
    let initial = format!("{padding}\n\n-[f]>oo\n");
    let expected = format!("<[{padding}\n\n]-foo\n");
    assert_state!(
        initial.as_str(),
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        expected.as_str()
    );
}

#[test]
fn goto_next_paragraph_ending_in_a_combining_mark_covers_the_whole_last_cluster() {
    assert_state!(
        "-[a]>\n\nfoo\nba\u{301}\n",
        |(text, sels)| cmd_goto_next_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "a\n\n<[foo\nba\u{301}]-\n"
    );
}

#[test]
fn goto_prev_paragraph_starting_with_a_wide_char_selects_it_whole() {
    assert_state!(
        "\u{6f22}a\n\nfoo\n-[b]>ar\n",
        |(text, sels)| cmd_goto_prev_paragraph(
            test_fixtures::testing::state(text, sels),
            1,
            MotionMode::Move
        ),
        "<[\u{6f22}a\n\n]-foo\nbar\n"
    );
}
