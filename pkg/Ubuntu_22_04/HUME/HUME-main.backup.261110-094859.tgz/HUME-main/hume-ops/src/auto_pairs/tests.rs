use super::*;
use hume_editing::marked::{bound_at, start_at};
use hume_editing::word::WordChars;
use test_fixtures::assert_state;

// ── insert_pair_close — cursor ────────────────────────────────────────────

#[test]
fn auto_close_at_start() {
    // Cursor on 'h' at start of line. Auto-close inserts '(' + ')' before
    // 'h', cursor lands on ')' (the close bracket).
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_pair_close(test_fixtures::testing::state(text, sels), '(', ')'),
        "(-[)]>hello\n"
    );
}

#[test]
fn auto_close_at_middle() {
    assert_state!(
        "hel-[l]>o\n",
        |(text, sels)| insert_pair_close(test_fixtures::testing::state(text, sels), '(', ')'),
        "hel(-[)]>lo\n"
    );
}

#[test]
fn auto_close_before_newline() {
    // Cursor on the structural '\n', a valid insert position.
    assert_state!(
        "hello-[\n]>",
        |(text, sels)| insert_pair_close(test_fixtures::testing::state(text, sels), '(', ')'),
        "hello(-[)]>\n"
    );
}

#[test]
fn auto_close_square_bracket() {
    assert_state!(
        "-[x]>\n",
        |(text, sels)| insert_pair_close(test_fixtures::testing::state(text, sels), '[', ']'),
        "[-[]]>x\n"
    );
}

#[test]
fn auto_close_symmetric_quote() {
    assert_state!(
        "-[x]>\n",
        |(text, sels)| insert_pair_close(test_fixtures::testing::state(text, sels), '"', '"'),
        "\"-[\"]>x\n"
    );
}

#[test]
fn auto_close_multi_cursor() {
    // Two cursors both get auto-closed independently.
    assert_state!(
        "-{a}>b-[c]>d\n",
        |(text, sels)| insert_pair_close(test_fixtures::testing::state(text, sels), '(', ')'),
        "(-{)}>ab(-[)]>cd\n"
    );
}

// ── delete_pair ───────────────────────────────────────────────────────────

#[test]
fn delete_pair_parens() {
    // Text: `(|)` where cursor is on `)`. Both are deleted.
    assert_state!(
        "(-[)]>\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "-[\n]>"
    );
}

#[test]
fn delete_pair_of_two_cursors_sharing_a_quote_deletes_all_three_quotes() {
    assert_state!(
        "\"-{\"}>-[\"]>\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "-[\n]>"
    );
}

#[test]
fn delete_pair_inside_word() {
    assert_state!(
        "foo(-[)]>bar\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "foo-[b]>ar\n"
    );
}

#[test]
fn delete_pair_square() {
    assert_state!(
        "[-[]]>\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "-[\n]>"
    );
}

#[test]
fn delete_pair_quote() {
    assert_state!(
        "\"-[\"]>\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "-[\n]>"
    );
}

#[test]
fn delete_pair_multi_cursor() {
    assert_state!(
        "(-{)}>(-[)]>\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "-[\n]>"
    );
}

// ── should_auto_pair_at ───────────────────────────────────────────────────

fn default_pairs() -> Vec<Pair> {
    vec![
        Pair {
            open: '(',
            close: ')',
        },
        Pair {
            open: '[',
            close: ']',
        },
        Pair {
            open: '{',
            close: '}',
        },
        Pair {
            open: '"',
            close: '"',
        },
        Pair {
            open: '\'',
            close: '\'',
        },
        Pair {
            open: '`',
            close: '`',
        },
    ]
}

fn paren() -> Pair {
    Pair {
        open: '(',
        close: ')',
    }
}
fn quote() -> Pair {
    Pair {
        open: '"',
        close: '"',
    }
}

#[test]
fn auto_pair_symmetric_after_same_quote_rejects() {
    // Cursor at 2, after ""; a third `"` must not open a new pair.
    let text = BufferText::from("\"\"\n");
    let pairs = default_pairs();
    assert!(!should_auto_pair_at(
        &text,
        bound_at(&text, 2),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_symmetric_after_other_quote_accepts() {
    // Cursor at 1, after a single `'`; typing `"` still pairs.
    let text = BufferText::from("'\n");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 1),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_next_alphanumeric_rejects_asymmetric() {
    // Cursor at 0, next char 'b': should NOT auto-pair `(`.
    let text = BufferText::from("bar");
    let pairs = default_pairs();
    assert!(!should_auto_pair_at(
        &text,
        bound_at(&text, 0),
        &paren(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_next_alphanumeric_rejects_symmetric() {
    // Cursor at 0, next char 'b': should NOT auto-pair `"`.
    let text = BufferText::from("bar");
    let pairs = default_pairs();
    assert!(!should_auto_pair_at(
        &text,
        bound_at(&text, 0),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_next_space_accepts() {
    // Cursor at 4 (space between words): next char is space.
    let text = BufferText::from("foo bar");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 3),
        &paren(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_next_newline_accepts() {
    // Cursor on the structural `\n`: next char is newline.
    let text = BufferText::from("hello");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 5),
        &paren(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_next_closing_bracket_accepts() {
    // Cursor at 1 (inside `()`), next char is `)`.
    let text = BufferText::from("()");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 1),
        &paren(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_symmetric_prev_alphanumeric_rejects() {
    // `don't`: cursor at 3 (the `'`), prev char is `n`.
    // Should NOT auto-pair the quote.
    let text = BufferText::from("don't");
    let pairs = default_pairs();
    assert!(!should_auto_pair_at(
        &text,
        bound_at(&text, 3),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_symmetric_prev_space_accepts() {
    // `say `: cursor at 4 (the `\n`), prev char is space.
    let text = BufferText::from("say ");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 4),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_symmetric_at_position_zero_accepts() {
    // Cursor at 0 in an empty buffer (just the structural `\n`).
    // No prev char and next char is `\n` (whitespace) → should auto-pair.
    let text = BufferText::from("");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 0),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_symmetric_prev_open_bracket_accepts() {
    // `( `: cursor at 1 (space), prev char is `(` (not alphanumeric), next is space.
    let text = BufferText::from("( foo");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 1),
        &quote(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_asymmetric_ignores_prev_word_char() {
    // `x `: cursor at 1 (space), prev is `x`. Parens are asymmetric so
    // only the next-char rule applies; next is space → accept.
    let text = BufferText::from("x foo");
    let pairs = default_pairs();
    assert!(should_auto_pair_at(
        &text,
        bound_at(&text, 1),
        &paren(),
        &pairs,
        WordChars::default()
    ));
}

#[test]
fn auto_pair_symmetric_prev_extra_word_char_rejects() {
    // `foo-` with '-' configured as a word char: the '-' now counts as a
    // word character, so pairing right after it must be suppressed the same
    // way it already is right after 'o', matching every other word
    // operation's word-chars-aware notion of "word".
    let text = BufferText::from("foo-");
    let pairs = default_pairs();
    assert!(!should_auto_pair_at(
        &text,
        bound_at(&text, 4),
        &quote(),
        &pairs,
        WordChars::new("-")
    ));
}

// ── Clusters and non-ASCII neighbours ─────────────────────────────────────

/// `should_auto_pair_at` for `pair` with the cursor at the end of `before`,
/// where `after` follows it.
fn auto_pairs_between(before: &str, after: &str, pair: &Pair) -> bool {
    let text = BufferText::from(format!("{before}{after}").as_str());
    should_auto_pair_at(
        &text,
        bound_at(&text, before.chars().count()),
        pair,
        &default_pairs(),
        WordChars::default(),
    )
}

#[test]
fn auto_pair_quote_after_a_word_ending_in_a_combining_mark_is_rejected() {
    assert!(!auto_pairs_between("cafe\u{301}", " ", &quote()));
}

#[test]
fn auto_pair_quote_after_a_cjk_char_is_rejected() {
    assert!(!auto_pairs_between("\u{6f22}", " ", &quote()));
}

#[test]
fn auto_pair_quote_after_an_emoji_cluster_is_accepted() {
    assert!(auto_pairs_between(
        test_fixtures::unicode::ZWJ_FAMILY,
        " ",
        &quote()
    ));
}

#[test]
fn auto_pair_paren_before_a_non_breaking_space_is_accepted() {
    assert!(auto_pairs_between("a", "\u{a0}", &paren()));
}

#[test]
fn auto_pair_paren_before_an_accented_letter_is_rejected() {
    assert!(!auto_pairs_between("a", "e\u{301}", &paren()));
}

#[test]
fn delete_pair_removes_a_close_delimiter_that_carries_a_combining_mark() {
    assert_state!(
        "(-[)\u{301}]>\n",
        |(text, sels)| delete_pair(test_fixtures::testing::state(text, sels)),
        "-[\n]>"
    );
}

// ── pair_around ───────────────────────────────────────────────────────────

#[test]
fn pair_around_finds_the_pair_whose_open_precedes_and_close_sits_at_the_cursor() {
    let text = BufferText::from("x{}\n");
    let pairs = default_pairs();
    assert_eq!(
        pair_around(&text, start_at(&text, 2), &pairs),
        Some(&Pair {
            open: '{',
            close: '}'
        })
    );
}

#[test]
fn pair_around_finds_a_symmetric_pair() {
    let text = BufferText::from("\"\"\n");
    let pairs = default_pairs();
    assert_eq!(
        pair_around(&text, start_at(&text, 1), &pairs),
        Some(&quote())
    );
}

#[test]
fn pair_around_rejects_mismatched_neighbours() {
    let text = BufferText::from("{)\n");
    assert_eq!(
        pair_around(&text, start_at(&text, 1), &default_pairs()),
        None
    );
}

#[test]
fn pair_around_is_none_at_the_text_start() {
    let text = BufferText::from("}\n");
    assert_eq!(
        pair_around(&text, start_at(&text, 0), &default_pairs()),
        None
    );
}

#[test]
fn pair_around_reads_the_cluster_before_the_cursor() {
    let text = BufferText::from("{\u{301}}\n");
    assert_eq!(
        pair_around(&text, start_at(&text, 2), &default_pairs()),
        Some(&Pair {
            open: '{',
            close: '}'
        })
    );
}
