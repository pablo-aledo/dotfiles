//! Scanning primitives for paired delimiters (brackets and quotes).

use hume_editing::selection::SelectionView;
use hume_editing::text::BufferText;
use hume_rope::cluster::{ClusterRange, ClusterStart};
use hume_rope::offset::{CharOffset, ExclusiveRange};

/// The clusters from the one holding the delimiter at `open` through the one
/// holding the delimiter at `close`. The scans below walk chars, and a
/// delimiter can share its cluster with a preceding prepend mark, so every
/// pair they find leaves this module through here.
fn delimited(text: &BufferText, open: CharOffset, close: CharOffset) -> ClusterRange {
    ClusterRange::through(text.full_slice(), text.snap(open), text.snap(close))
        .expect("an open delimiter precedes its close")
}

/// The first char of the cluster at `pos` that `is_delimiter` accepts, with
/// its offset. A delimiter joined to a preceding prepend mark is not its
/// cluster's first char.
pub(crate) fn delimiter_at(
    text: &BufferText,
    pos: ClusterStart,
    is_delimiter: impl Fn(char) -> bool,
) -> Option<(CharOffset, char)> {
    let len = text
        .clusters()
        .end_of(pos)
        .offset()
        .chars_since(pos.offset());
    text.chars_at(pos.offset())
        .take(len)
        .find(|&(_, ch)| is_delimiter(ch))
}

// Bracket pairs

/// The bracket pairs `%`-style matching and the argument text object both
/// scan for. `<>` is absent: in real code it's a comparison
/// operator (`a < b`) far more often than a delimiter, which is why vim's own
/// `matchpairs` default excludes it too; `<div>`/`</div>` tag matching is a
/// separate scan ([`crate::tag`]).
const BRACKET_PAIRS: [(char, char); 3] = [('(', ')'), ('[', ']'), ('{', '}')];

/// Scan left from `pos` (exclusive) to find an unmatched `open` bracket at
/// or after `bound.start`.
pub(crate) fn scan_left_for_open(
    text: &BufferText,
    pos: CharOffset,
    open: char,
    close: char,
    bound: ExclusiveRange<CharOffset>,
) -> Option<CharOffset> {
    let mut depth = 0usize;
    let mut cursor = text.chars_at(pos);
    while let Some((i, ch)) = cursor.prev() {
        if i < bound.start {
            return None;
        }
        if ch == close {
            depth += 1;
        } else if ch == open {
            if depth == 0 {
                return Some(i);
            }
            depth -= 1;
        }
    }
    None
}

/// Scan right from `pos` (exclusive) to find an unmatched `close` bracket
/// before `bound.end`.
pub(crate) fn scan_right_for_close(
    text: &BufferText,
    pos: CharOffset,
    open: char,
    close: char,
    bound: ExclusiveRange<CharOffset>,
) -> Option<CharOffset> {
    let mut depth = 0usize;
    for (i, ch) in text.chars_at(pos) {
        if i >= bound.end {
            return None;
        }
        if ch == open {
            depth += 1;
        } else if ch == close {
            if depth == 0 {
                return Some(i);
            }
            depth -= 1;
        }
    }
    None
}

/// The char offsets of the innermost `(open, close)` bracket pair enclosing
/// the char at `pos`.
///
/// If `pos` is ON an open bracket, that bracket itself is the start.
/// If ON a close bracket, that bracket is the end.
/// Otherwise, scans both directions for the enclosing pair. Neither scan
/// leaves `bound`.
fn bracket_pair_chars(
    text: &BufferText,
    pos: CharOffset,
    open: char,
    close: char,
    bound: ExclusiveRange<CharOffset>,
) -> Option<(CharOffset, CharOffset)> {
    match text.char_at(pos)? {
        ch if ch == open => {
            // `pos.shift(1)` cannot panic: `char_at` above already proved
            // `pos < text.len_chars()`.
            let close_pos = scan_right_for_close(text, pos.shift(1), open, close, bound)?;
            Some((pos, close_pos))
        }
        ch if ch == close => Some((scan_left_for_open(text, pos, open, close, bound)?, pos)),
        _ => Some((
            scan_left_for_open(text, pos, open, close, bound)?,
            scan_right_for_close(text, pos, open, close, bound)?,
        )),
    }
}

/// The innermost `open`/`close` bracket pair enclosing `pos`, delimiters
/// included. A cluster on either bracket belongs to that bracket's pair.
pub(crate) fn find_bracket_pair(
    text: &BufferText,
    pos: ClusterStart,
    open: char,
    close: char,
) -> Option<ClusterRange> {
    let at =
        delimiter_at(text, pos, |ch| ch == open || ch == close).map_or(pos.offset(), |(at, _)| at);
    let whole = ExclusiveRange::new(CharOffset::default(), text.end());
    let (open_pos, close_pos) = bracket_pair_chars(text, at, open, close, whole)?;
    Some(delimited(text, open_pos, close_pos))
}

/// `bracket_role` for every ASCII byte, built from `BRACKET_PAIRS` so the
/// table can never drift out of sync with the pairs it indexes. Every
/// `BRACKET_PAIRS` char is ASCII, so a 128-entry table covers all of them;
/// `bracket_role` is the hot per-char dispatch in
/// [`find_tightest_bracket_pair`]'s scanning loops, where a linear scan over
/// `BRACKET_PAIRS` would otherwise run on every character those loops visit,
/// most of which aren't brackets at all.
const BRACKET_ROLE_TABLE: [Option<(u8, bool)>; 128] = {
    let mut table = [None; 128];
    let mut k = 0;
    while k < BRACKET_PAIRS.len() {
        let (open, close) = BRACKET_PAIRS[k];
        table[open as usize] = Some((k as u8, true));
        table[close as usize] = Some((k as u8, false));
        k += 1;
    }
    table
};

/// Which `BRACKET_PAIRS` entry `ch` belongs to, and whether it's the open
/// side (`true`) or the close side (`false`). `None` for any other char.
///
/// `pub(crate)`, not just the tables it's built from, so a caller that needs
/// "is this char a bracket, and which side" (currently `text_object::argument`'s
/// comma-depth counter) can ask the crate's one answer
/// instead of hardcoding its own copy of `BRACKET_PAIRS`'s contents.
pub(crate) fn bracket_role(ch: char) -> Option<(usize, bool)> {
    let byte = u32::from(ch);
    if byte >= BRACKET_ROLE_TABLE.len() as u32 {
        return None;
    }
    let (k, is_open) = BRACKET_ROLE_TABLE[byte as usize]?;
    Some((k as usize, is_open))
}

/// Feeds one scanned char into a bracket type's depth counter, resolving
/// `slots[k]` (`opens` when `seek_open`, scanning left for an unmatched
/// open; `closes` when scanning right for an unmatched close) the first
/// time depth returns to zero on the side being sought. Returns the type
/// index just resolved, if any.
///
/// Shared by both scan directions in [`find_tightest_bracket_pair`]: the two
/// differ only in which side they're seeking and which array they fill, so
/// one function serves both, called with `depths`/`slots` swapped.
fn step_bracket(
    (i, c): (CharOffset, char),
    seek_open: bool,
    depths: &mut [usize; BRACKET_PAIRS.len()],
    slots: &mut [Option<CharOffset>; BRACKET_PAIRS.len()],
) -> Option<usize> {
    let (k, is_open) = bracket_role(c)?;
    if slots[k].is_some() {
        return None;
    }
    if is_open != seek_open {
        depths[k] += 1;
        return None;
    }
    if depths[k] > 0 {
        depths[k] -= 1;
        return None;
    }
    slots[k] = Some(i);
    Some(k)
}

/// Find the tightest (smallest-span) of the three `BRACKET_PAIRS` pairs that
/// encloses `pos`.
///
/// Each bracket type is an independent candidate with its own depth counter
/// per direction. On `{(abc}    )` with the cursor on `b`, the nearest
/// unmatched open is `(`, but `{}` (span 5) beats `()` (span 9); a shared
/// counter would return `()`. If `pos` is on a type's open or close, that side
/// costs no scan for that type.
///
/// The leftward and rightward scans run interleaved, one char at a time, at
/// distances `dl` and `dr` from `pos`. Once some type resolves with span `s`,
/// a type still missing its open lies more than `dl` back and closes at
/// `pos + 1` or later, so it can't beat `s` once `dl >= s`; the rightward
/// scan is bounded by `dr` the same way. The common case (one type never
/// resolving) thus costs O(winning span) instead of O(buffer).
///
/// A side also stops when it has nothing left to find (`opens_missing` or
/// `right_pending` at zero). The rightward scan only runs while some type has
/// a known open, but it tracks every type, so a close can resolve out of order
/// before its own open; each side checks for the other's answer. Ties break
/// in `BRACKET_PAIRS` order.
pub(crate) fn find_tightest_bracket_pair(
    text: &BufferText,
    pos: ClusterStart,
) -> Option<ClusterRange> {
    let (pos, ch) = match delimiter_at(text, pos, |ch| bracket_role(ch).is_some()) {
        Some(delimiter) => delimiter,
        None => (pos.offset(), text.char_at(pos.offset())?),
    };
    let role = bracket_role(ch);

    let mut opens: [Option<CharOffset>; BRACKET_PAIRS.len()] = [None; BRACKET_PAIRS.len()];
    let mut closes: [Option<CharOffset>; BRACKET_PAIRS.len()] = [None; BRACKET_PAIRS.len()];
    let mut depths_left = [0usize; BRACKET_PAIRS.len()];
    let mut depths_right = [0usize; BRACKET_PAIRS.len()];

    // `ch` can be at most one type's open char, so at most one slot is
    // seeded here, so `opens_missing` always starts at 2 or 3, never 0.
    let mut opens_missing = BRACKET_PAIRS.len();
    // Types with a known open and unknown close: what the rightward scan
    // is still live for. Excludes a type whose close is already known (the
    // on-close shortcut just below, or the "resolved out of order" case
    // documented above) the moment its open is found, since neither needs
    // any further scanning.
    let mut right_pending = 0usize;
    if let Some((k, true)) = role {
        opens[k] = Some(pos);
        opens_missing -= 1;
        right_pending += 1;
    }

    let mut best_span: Option<usize> = None;
    let within_bound = |best: Option<usize>, d: usize| best.is_none_or(|s| d < s);

    let mut left_cursor = text.chars_at(pos);
    // `pos.shift(1)` cannot panic: `text.char_at(pos)` above already proved
    // `pos < text.len_chars()`.
    let mut right_cursor = text.chars_at(pos.shift(1));
    let (mut dl, mut dr) = (0usize, 0usize);
    let (mut left_exhausted, mut right_exhausted) = (false, false);

    loop {
        let left_live = !left_exhausted && opens_missing > 0 && within_bound(best_span, dl);
        let right_live = !right_exhausted && right_pending > 0 && within_bound(best_span, dr);
        if !left_live && !right_live {
            break;
        }

        if left_live {
            match left_cursor.prev() {
                Some(hit) => {
                    dl += 1;
                    if let Some(k) = step_bracket(hit, true, &mut depths_left, &mut opens) {
                        opens_missing -= 1;
                        let open_pos = hit.0;
                        if role == Some((k, false)) {
                            // On-close shortcut: `pos` itself is this
                            // type's close.
                            closes[k] = Some(pos);
                            let span = pos.chars_since(open_pos);
                            best_span = Some(best_span.map_or(span, |s| s.min(span)));
                        } else if let Some(close_pos) = closes[k] {
                            // Rightward scan already found this type's
                            // close before its open resolved here.
                            let span = close_pos.chars_since(open_pos);
                            best_span = Some(best_span.map_or(span, |s| s.min(span)));
                        } else {
                            right_pending += 1;
                        }
                    }
                }
                None => left_exhausted = true,
            }
        }

        if right_live {
            match right_cursor.next() {
                Some(hit) => {
                    dr += 1;
                    if let Some(k) = step_bracket(hit, false, &mut depths_right, &mut closes)
                        && let Some(open_pos) = opens[k]
                    {
                        right_pending -= 1;
                        let close_pos = hit.0;
                        let span = close_pos.chars_since(open_pos);
                        best_span = Some(best_span.map_or(span, |s| s.min(span)));
                    }
                }
                None => right_exhausted = true,
            }
        }
    }

    opens
        .iter()
        .zip(&closes)
        .filter_map(|(&open_pos, &close_pos)| open_pos.zip(close_pos))
        .min_by_key(|&(open_pos, close_pos)| close_pos.chars_since(open_pos))
        .map(|(open_pos, close_pos)| delimited(text, open_pos, close_pos))
}

/// Find the bracket nearest `sel`'s head, scanning the selection span.
///
/// `sel`'s head is always one extremity of the span (its first or last
/// cluster; for a cursor the two coincide), never interior, so
/// "nearest to head, within the selection" is just "scan the span from the
/// head's end inward"; the first hit is the nearest one.
/// Uses `chars_at` rather than indexed `char_at` calls so the scan pays
/// ropey's O(log n) tree descent once, not once per char (same reason
/// `scan_left_for_open`/`scan_right_for_close` above use it).
///
/// The span scanned is the selection itself only when it sits on one line:
/// this resolver also runs once per frame for the bracket-match highlight,
/// so scanning a selection of unbounded length (e.g. `%` select-all) would
/// put an unbounded-cost scan on every keystroke. A selection crossing a
/// line boundary falls back to probing just the head's own cluster, the
/// same one-cluster check the resolver made before it went selection-wide.
/// This never loses the motivating `") "` case: `expand_word_unit`'s
/// whitespace bookend stops at a newline, so a `w`/`W`/`maw` selection never
/// crosses one.
fn nearest_bracket(sel: SelectionView<'_>) -> Option<(CharOffset, char, char)> {
    let classify = |(i, ch): (CharOffset, char)| {
        let (k, _) = bracket_role(ch)?;
        let (o, c) = BRACKET_PAIRS[k];
        Some((i, o, c))
    };
    let text = sel.text();
    let lines = sel.lines();
    let span: ExclusiveRange<CharOffset> = if lines.start == lines.end {
        sel.covered().chars()
    } else {
        ClusterRange::of(text.full_slice(), sel.head()).chars()
    };
    if sel.head().offset() == span.start {
        text.chars_at(span.start)
            .take(span.end.chars_since(span.start))
            .find_map(classify)
    } else {
        let mut cursor = text.chars_at(span.end);
        while let Some(hit) = cursor.prev() {
            if hit.0 < span.start {
                return None;
            }
            if let Some(found) = classify(hit) {
                return Some(found);
            }
        }
        None
    }
}

/// Find the partner of the bracket nearest `sel`'s head, within `sel`.
///
/// Resolves against the whole selection, not just the head's own grapheme
/// cluster: a `w`-motion selection like `") "` leaves the head on the
/// trailing space rather than the bracket itself (`word-selects-whitespace`
/// gives a run with no whitespace before it the whitespace after it), and
/// `%`-style matching should still find the `)`. The
/// head's own cluster is always checked first: a bracket char is always
/// ASCII and never itself combines forward, but a `GC_Prepend` codepoint
/// immediately before one (e.g. U+0600 ARABIC NUMBER SIGN) joins *into* it,
/// so a head landing on that leading codepoint (where every position that
/// matches such a bracket lands, since it is the cluster's start) must still
/// resolve, or a second `%`-style press
/// (an involution) finds nothing and the cursor-match highlight goes dark on
/// a bracket the cursor is visibly beside.
///
/// This is the resolver `%`-style matching needs ("which pair is this
/// delimiter part of, and where's the other end") that `find_bracket_pair`
/// doesn't provide on its own, since that function is only ever called with
/// one already-known pair. Also the single resolver for the bracket-match
/// cursor highlight (`hume-editor`'s `decoration_providers`). Both need the
/// same answer to "what does this character pair with", so there is exactly
/// one place `BRACKET_PAIRS` gets consulted for it.
///
/// The partner scan stays inside `bound` and yields `None` past it. The
/// highlight runs on every frame and paints only visible lines, so it bounds
/// the scan to them; `%` passes the whole text.
pub fn matching_bracket(
    sel: SelectionView<'_>,
    bound: ExclusiveRange<CharOffset>,
) -> Option<ClusterStart> {
    let text = sel.text();
    let (bracket_pos, open, close) = nearest_bracket(sel)?;
    let (open_pos, close_pos) = bracket_pair_chars(text, bracket_pos, open, close, bound)?;
    let partner = if bracket_pos == open_pos {
        close_pos
    } else {
        open_pos
    };
    Some(text.snap(partner))
}

// Quote pairs

/// Find the quote pair on the current line that encloses or is nearest to `pos`.
///
/// Quotes don't span lines (current limitation). Strategy: scan the current line
/// tracking parity: odd occurrences are opening quotes, even occurrences are
/// closing quotes. Returns the pair that contains `pos`.
///
/// If `pos` is ON a quote char, parity resolves whether it is open or close.
pub(crate) fn find_quote_pair(
    text: &BufferText,
    pos: ClusterStart,
    quote: char,
) -> Option<ClusterRange> {
    let pos = delimiter_at(text, pos, |ch| ch == quote).map_or(pos.offset(), |(at, _)| at);
    let line = text.lines().range(text.char_to_line(pos)).chars();

    // Single pass: track the opening quote position; on every second hit we
    // have a complete pair and can test whether `pos` falls inside it.
    let mut open: Option<CharOffset> = None;
    for (i, ch) in text
        .chars_at(line.start)
        .take(line.end.chars_since(line.start))
    {
        if ch == quote {
            match open {
                None => open = Some(i), // odd occurrence → opening quote
                Some(open_pos) => {
                    // even occurrence → closing quote
                    if open_pos <= pos && pos <= i {
                        return Some(delimited(text, open_pos, i));
                    }
                    open = None; // reset for next pair
                }
            }
        }
    }
    None
}

#[cfg(test)]
mod tests;
