use hume_editing::edit::{EditBuilder, Edited, Landing, Landings, edit};
use hume_editing::selection::SelectionView;
use hume_editing::state::EditState;

mod align;
mod case;
mod comment;
mod delete;
mod electric;
mod increment;
mod indent;
mod insert;
mod join;
mod paste;
mod pipe;
mod replace;
mod sort;

pub use align::align_selections;
pub use case::{make_text_capitalized, make_text_lowercase, make_text_uppercase};
pub use comment::{
    CommentPlan, CommentPlanError, MultiLineComments, apply_comment_plan, plan_comment_toggle,
};
pub use delete::{
    Removal, dedent_tab_backward, delete_char_backward, delete_char_forward, delete_selection,
    delete_selection_content, delete_word_backward, yank_selections,
};
pub use electric::{
    ArmedIndent, ElectricCandidates, ElectricPlan, apply_electric_plan, electric_candidates,
    plan_electric_dedent,
};
pub use increment::{
    IncrementPlan, IncrementRefusal, Stepping, apply_increment_plan, plan_increment,
};
pub use indent::{indent_lines, unindent_lines};
pub use insert::{
    LineBreak, LineBreakPlan, NewLineIndent, apply_line_break_plan, clear_blank_line_indent,
    insert_char, insert_str, insert_tab, insert_values, owned_blank_indent, plan_line_breaks,
};
pub use join::join_lines_select_spaces;
pub use paste::{paste_after, paste_before};
pub use pipe::fit_pipe_output;
pub use replace::{
    replace_around_cursors, replace_each_selection, replace_selections,
    replace_span_around_cursors, word_start_before,
};
pub use sort::{SortOpts, SortRefusal, sort_lines};

/// One edit made selection by selection. `f` receives the builder and the
/// selection, and returns where that selection lands; the primary stays on
/// the primary's result. The builder applies its operations in position
/// order, so the order `f` records them in does not matter.
pub(crate) fn apply_edit<F>(state: EditState, mut f: F) -> Edited
where
    F: for<'a, 'id> FnMut(&mut EditBuilder<'a, 'id>, SelectionView<'a>) -> Landing<'id>,
{
    let primary = state.view().primary().index();
    edit(&state, |plan| {
        let landings = state.view().iter().map(|sel| f(plan, sel)).collect();
        Landings::new(landings, primary)
    })
}

#[cfg(test)]
mod tests;
