//! Multi-cursor "replace around each head" primitives (`r`, and LSP
//! completion's fallback insert path), replacing each selection with its
//! own value (`pipe`, case transforms), and word-boundary lookup.

use hume_editing::edit::Edited;
use hume_editing::edit::Landing;
use hume_editing::state::EditState;
use hume_editing::text::BufferText;
use hume_editing::word::{CharClass, WordChars};
use hume_rope::cluster::ClusterRange;
use hume_rope::offset::{CharOffset, ExclusiveRange};

use super::apply_edit;

/// Replace selection `i` with `values[i]`, in document order. Each result
/// covers its replacement and keeps its facing; an empty value leaves a
/// cursor on the cluster after the removed text.
///
/// # Panics
/// Panics if `values` and the selections differ in number.
pub fn replace_each_selection(state: EditState, values: &[String]) -> Edited {
    assert_eq!(
        values.len(),
        state.view().len(),
        "replace_each_selection: needs one value per selection"
    );
    apply_edit(state, |b, sel| {
        let mark = b.replace(sel.covered(), &values[sel.index()]);
        Landing::covering(mark, sel.facing())
    })
}

/// The start of the run of identifier (`Word`-class) clusters ending at
/// `pos`: the token immediately preceding it, or `pos` itself when the
/// cluster before it is not a word character. `chars` folds this buffer's
/// extra word characters into the scan, so a configured run (e.g. `foo-bar`
/// with `-` as a word char) is treated as one token, matching every other
/// word operation, including what the LSP completion fallback this backs is
/// replacing on the buffer's behalf.
pub fn word_start_before(text: &BufferText, pos: CharOffset, chars: WordChars<'_>) -> CharOffset {
    text.clusters()
        .before(text.snap(pos).into())
        .take_while(|cluster| chars.classify(cluster.first()) == CharClass::Word)
        .last()
        .map_or(pos, |cluster| cluster.start().offset())
}

/// Multi-cursor "replace around each head": for every selection, delete from
/// `start_of(text, i, head)` through `forward` chars past the head and insert
/// `replacement`.
///
/// [`replace_around_cursors`] is the uniform case, one backward char count
/// for every cursor. LSP completion accept calls this directly with a count
/// per cursor: the server's `textEdit` range gives every cursor the same
/// count, and the `insertText` fallback scans each cursor's own token start.
///
/// `text` may already include an earlier edit from the same group (e.g.
/// `additionalTextEdits`), so a fresh scan could wander into inserted text.
/// `i` (the cursor's sorted index) lets `start_of` read a per-cursor count
/// computed before that edit instead.
///
/// Where the delete ranges of two cursors overlap (cursors closer than the
/// span, or near the buffer start), the text they share is deleted once and
/// each cursor still receives `replacement`.
pub fn replace_span_around_cursors(
    state: EditState,
    start_of: impl Fn(&BufferText, usize, CharOffset) -> CharOffset,
    forward: usize,
    replacement: &str,
) -> Edited {
    apply_edit(state, |b, sel| {
        let text = b.text();
        let head = sel.head().offset();
        // The span comes from a char count taken at one cursor, so at another
        // it can cut a cluster: it widens to whole clusters.
        let chars = ExclusiveRange::new(
            start_of(text, sel.index(), head),
            head.shift(forward as isize),
        );
        let mark = match text.covering(chars) {
            Some(span) => b.replace(span, replacement),
            None => b.insert(sel.head(), replacement),
        };
        Landing::cursor(mark.end())
    })
}

/// Replaces `back` chars behind each selection's head and `forward` chars
/// ahead of it with `replacement`: the multi-cursor form of "the user typed
/// this text here." Dot-repeat uses it to replay a recorded completion
/// accept, whose `(back, forward)` pair was measured at the primary cursor
/// and applies the same span at every cursor.
pub fn replace_around_cursors(
    state: EditState,
    back: usize,
    forward: usize,
    replacement: &str,
) -> Edited {
    replace_span_around_cursors(
        state,
        // Saturating, not `retreat`: a cramped cursor's `head` can sit fewer
        // than `back` chars into the buffer.
        |_text, _i, head| head.retreat_saturating(back),
        forward,
        replacement,
    )
}

/// Replace every grapheme in every selection with `ch` (normal-mode `r`).
///
/// - **Cursor selection**: the single character under the cursor is replaced.
///   The cursor remains on the replacement character.
/// - **Multi-character selection**: every grapheme in the selected region is
///   replaced with `ch`, preserving the selection direction. Multi-codepoint
///   grapheme clusters (e.g. `é` = U+0065 + U+0301) are replaced atomically:
///   the replacement shrinks the cluster down to one char without orphaning
///   combining marks.
/// - **Newline skipping**: `\n` graphemes are never replaced; they are
///   retained as-is. This preserves line structure when the selection spans
///   multiple lines. The structural trailing `\n` is protected by the same
///   rule.
pub fn replace_selections(state: EditState, ch: char) -> Edited {
    apply_edit(state, |b, sel| {
        let text = b.text();
        // A cursor typing a pair char resolves open/close from what it sits
        // on; see `surround::smart_replace_char`.
        let current = crate::pair::delimiter_at(text, sel.start(), crate::surround::is_pair_char)
            .map(|(_, ch)| ch)
            .or_else(|| text.char_at(sel.start().offset()));
        let effective_ch = match current {
            Some(current) if sel.is_cursor() => {
                crate::surround::smart_replace_char(ch, current, sel.index())
            }
            _ => ch,
        };
        let mark = b.keep(sel.covered());
        // One replace per run of clusters between `\n`s; the `None` after the
        // last cluster closes the final run.
        let mut run: Option<(ClusterRange, usize)> = None;
        for cluster in sel.clusters().map(Some).chain(std::iter::once(None)) {
            match cluster {
                Some(cluster) if cluster.first() != '\n' => {
                    let (range, count) = run.get_or_insert((cluster.range(), 0));
                    *range = range.hull(cluster.range());
                    *count += 1;
                }
                _ => {
                    if let Some((range, count)) = run.take() {
                        b.replace(
                            range,
                            &std::iter::repeat_n(effective_ch, count).collect::<String>(),
                        );
                    }
                }
            }
        }
        Landing::covering(mark, sel.facing())
    })
}
