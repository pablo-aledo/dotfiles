use super::super::*;
use hume_editing::selection::SelectionSet;
use hume_editing::text::BufferText;
use hume_editing::word::WordChars;
use hume_rope::offset::CharOffset;
use pretty_assertions::assert_eq;
use test_fixtures::assert_state;
use test_fixtures::testing::{parse_state, state};
use test_fixtures::unicode::ALL;

// ── replace_around_cursors ───────────────────────────────────────────────────
//
// The multi-cursor "as if typed" primitive behind LSP completion accept:
// replaces `back` chars behind each cursor's head and `forward` chars ahead
// of it with `text`, uniformly at every selection.

#[test]
fn replace_around_cursors_single_cursor_baseline() {
    // head=2 ('l'); back=2 deletes "he"; forward=0 leaves the head char and
    // everything after untouched.
    assert_state!(
        "he-[l]>lo\n",
        |(text, sels)| replace_around_cursors(
            test_fixtures::testing::state(text, sels),
            2,
            0,
            "XYZ"
        ),
        "XYZ-[l]>lo\n"
    );
}

#[test]
fn replace_around_cursors_two_cursors_uniform_spacing() {
    // The op-level shape of multi-cursor completion: two cursors,
    // each right after its own typed "st", both get the same replacement.
    assert_state!(
        "st-{ }>st-[\n]>",
        |(text, sels)| replace_around_cursors(
            test_fixtures::testing::state(text, sels),
            2,
            0,
            "XY"
        ),
        "XY-{ }>XY-[\n]>"
    );
}

#[test]
fn replace_around_cursors_forward_consumes_chars_ahead_of_head() {
    // head=2 ('l'); back=1 deletes "e"; forward=1 also consumes the head
    // char itself ('l'): completing in the middle of a token, where the
    // server's range extends past the live cursor.
    assert_state!(
        "he-[l]>lo\n",
        |(text, sels)| replace_around_cursors(
            test_fixtures::testing::state(text, sels),
            1,
            1,
            "XYZ"
        ),
        "hXYZ-[l]>o\n"
    );
}

#[test]
fn replace_around_cursors_clamps_underflow_at_buffer_start() {
    // head=2 ('c'); back=5 asks for more chars than exist before the cursor
    // and is clamped to the buffer start (0) rather than underflowing.
    assert_state!(
        "ab-[c]>de\n",
        |(text, sels)| replace_around_cursors(test_fixtures::testing::state(text, sels), 5, 0, "Z"),
        "Z-[c]>de\n"
    );
}

#[test]
fn replace_around_cursors_clamps_when_cursors_are_closer_than_back() {
    // Cursors at 'c' and 'd' (1 char apart) with back=2 each: the ideal
    // start for the second cursor (1 char before 'c') would fall inside
    // territory the first cursor's edit already claimed. Clamped to the
    // first edit's end instead of erroring: the second cursor still gets
    // "Z", it just eats one char ('c') instead of two ("b","c").
    assert_state!(
        "ab-{c}>-[d]>ef\n",
        |(text, sels)| replace_around_cursors(test_fixtures::testing::state(text, sels), 2, 0, "Z"),
        "Z-{Z}>-[d]>ef\n"
    );
}

#[test]
fn replace_around_cursors_snaps_start_outward_past_a_combining_mark() {
    // "café" = c,a,f,e,{combining acute}. One grapheme cluster spans chars
    // [3,5). head=6 ('x'), back=2 puts the raw start at char 4, splitting
    // the cluster between the base 'e' and its accent. The snap floors it
    // to 3, deleting the whole cluster instead of orphaning the accent.
    assert_state!(
        "cafe\u{0301} -[x]>\n",
        |(text, sels)| replace_around_cursors(test_fixtures::testing::state(text, sels), 2, 0, "Z"),
        "cafZ-[x]>\n"
    );
}

#[test]
fn replace_around_cursors_normalizes_crlf_in_replacement() {
    // LSP completion's insertText/textEdit fallback isn't guaranteed
    // `\n`-only, and this is the sole insertion point for that whole path.
    assert_state!(
        "he-[l]>lo\n",
        |(text, sels)| replace_around_cursors(
            test_fixtures::testing::state(text, sels),
            2,
            0,
            "X\r\nY"
        ),
        "X\nY-[l]>lo\n"
    );
}

#[test]
fn replace_around_cursors_over_the_last_break_with_a_newline_adds_no_blank_line() {
    assert_state!(
        "abc\nde-[f]>\n",
        |(text, sels)| replace_around_cursors(
            test_fixtures::testing::state(text, sels),
            0,
            2,
            "x\n"
        ),
        "abc\ndex-[\n]>"
    );
}

#[test]
fn replace_around_cursors_zero_span_matches_insert_str() {
    // back=0 forward=0 degenerates to a pure multi-cursor insert.
    // insert_str is a separately implemented op, so
    // agreement here isn't circular against replace_around_cursors's own
    // logic.
    let text = BufferText::from("foo bar\n");
    let sels = SelectionSet::new(
        &text,
        vec![
            test_fixtures::testing::cursor(&text, 0),
            test_fixtures::testing::cursor(&text, 4),
        ],
        0,
    );
    let (text_replace, sels_replace, cs_replace) =
        test_fixtures::testing::parts(replace_around_cursors(
            test_fixtures::testing::state(text.clone(), sels.clone()),
            0,
            0,
            "X",
        ));
    let (text_insert, sels_insert, cs_insert) =
        test_fixtures::testing::parts(insert_str(test_fixtures::testing::state(text, sels), "X"));
    assert_eq!(
        test_fixtures::testing::serialize_state(&text_replace, &sels_replace),
        test_fixtures::testing::serialize_state(&text_insert, &sels_insert),
    );
    assert_eq!(cs_replace, cs_insert);
}

#[test]
fn replace_around_cursors_forward_past_the_end_does_not_delete_the_structural_newline() {
    // `forward` reaching (or exceeding) the buffer's length always makes
    // `raw_end == len_chars()`, one past the structural trailing `\n`'s own
    // single-char cluster, so `ceiled` then lands past `last` (the `\n`'s
    // position) on every such buffer, not just one with an unusual
    // multi-char terminator cluster. Floor back to that cluster's start
    // instead of ceiling through it and deleting the structural newline.
    let text = BufferText::from("ab\n");
    let sels = SelectionSet::new(&text, vec![test_fixtures::testing::cursor(&text, 0)], 0);
    let (new_text, new_sels, _cs) = test_fixtures::testing::parts(replace_around_cursors(
        test_fixtures::testing::state(text, sels),
        0,
        10,
        "X",
    ));
    assert_eq!(
        new_text.to_string(),
        "X\n",
        "structural trailing newline must survive"
    );
    assert!(
        hume_editing::selection::EditView::bind(&new_text, &new_sels)
            .primary()
            .head()
            .offset()
            < new_text.end(),
        "cursor must land before the structural newline, not on/after it"
    );
}

// ── replace_span_around_cursors ─────────────────────────────────────────────
//
// The general primitive `replace_around_cursors` wraps with a uniform-count
// `start_of`. These pin the per-cursor case: a `start_of` that
// computes a *different* start at each cursor (LSP completion accept's own
// `insertText`-fallback use, via `word_start_before`).

#[test]
fn replace_span_around_cursors_start_of_receives_each_cursors_own_index_and_head() {
    // Two cursors, each retreating by its *own* index-selected count (3 for
    // the first, 1 for the second) rather than one shared count. This proves
    // `i` and `head` both reach `start_of` correctly, independent of
    // `replace_around_cursors`'s own (uniform) wrapper.
    let text = BufferText::from("abcdefgh\n");
    let sels = SelectionSet::new(
        &text,
        vec![
            test_fixtures::testing::cursor(&text, 3),
            test_fixtures::testing::cursor(&text, 8),
        ],
        0,
    );
    let counts = [3usize, 1usize];
    let (new_text, _sels, _cs) = test_fixtures::testing::parts(replace_span_around_cursors(
        test_fixtures::testing::state(text, sels),
        |_text, i, head| head.retreat_saturating(counts[i]),
        0,
        "Z",
    ));
    // Cursor 1: retreat 3 from char 3 → char 0, deletes "abc" → "Z".
    // Cursor 2: retreat 1 from char 8 → char 7, deletes "h" → "Z".
    assert_eq!(new_text.to_string(), "ZdefgZ\n");
}

#[test]
fn replace_span_around_cursors_word_start_before_stops_each_cursor_at_its_own_boundary() {
    // The actual `accept.rs` shape: each cursor's own `word_start_before`
    // scan, not a shared count: a shorter word before the second cursor
    // must not retreat into the (unrelated, longer) word before the first.
    let text = BufferText::from("ab c\n");
    let sels = SelectionSet::new(
        &text,
        vec![
            test_fixtures::testing::cursor(&text, 2), // right after "ab"
            test_fixtures::testing::cursor(&text, 4), // right after "c"
        ],
        0,
    );
    let chars = WordChars::default();
    let (new_text, _sels, _cs) = test_fixtures::testing::parts(replace_span_around_cursors(
        test_fixtures::testing::state(text, sels),
        |text, _i, head| word_start_before(text, head, chars),
        0,
        "Z",
    ));
    assert_eq!(
        new_text.to_string(),
        "Z Z\n",
        "each cursor's own word is replaced in place, not a uniform count \
         derived from the other"
    );
}

// ── replace_selections ────────────────────────────────────────────────────

#[test]
fn replace_cursor_single_char() {
    // Cursor on 'h'; replace with 'x' → cursor stays on 'x'.
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[x]>ello\n"
    );
}

#[test]
fn replace_cursor_middle() {
    // Cursor on 'l' at offset 2; replace with 'x'.
    assert_state!(
        "he-[l]>lo\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "he-[x]>lo\n"
    );
}

#[test]
fn replace_cursor_on_structural_newline_is_noop() {
    // Structural trailing '\n' is skipped like any other '\n'.
    assert_state!(
        "hello-[\n]>",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "hello-[\n]>"
    );
}

#[test]
fn replace_cursor_on_mid_buffer_newline_is_noop() {
    // Cursor on the '\n' between two lines: preserved, not replaced.
    assert_state!(
        "hello-[\n]>world\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "hello-[\n]>world\n"
    );
}

#[test]
fn replace_empty_buffer_is_noop() {
    // Text is just the structural '\n'.
    assert_state!(
        "-[\n]>",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[\n]>"
    );
}

#[test]
fn replace_forward_selection() {
    // Forward selection covers "hell" (offsets 0-3); replace each with 'x'.
    assert_state!(
        "-[hell]>o\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[xxxx]>o\n"
    );
}

#[test]
fn replace_backward_selection() {
    // Backward selection anchor=3, head=0 covers "hell"; direction preserved.
    assert_state!(
        "<[hell]-o\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "<[xxxx]-o\n"
    );
}

#[test]
fn replace_whole_line() {
    // Forward selection covers all content chars (not the structural '\n').
    assert_state!(
        "-[hello]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[xxxxx]>\n"
    );
}

#[test]
fn replace_two_cursors() {
    // Two cursors; each independently replaced.
    assert_state!(
        "-{h}>ell-[o]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-{x}>ell-[x]>\n"
    );
}

#[test]
fn replace_two_selections() {
    // Two non-overlapping selections each get all their chars replaced.
    assert_state!(
        "-{he}>l-[lo]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-{xx}>l-[xx]>\n"
    );
}

#[test]
fn replace_grapheme_cluster_cursor() {
    // Cursor on 'é' (e + U+0301, 2 codepoints). Replaced with 'x' (1 codepoint).
    // Text shrinks by 1 char; cursor lands on 'x'.
    assert_state!(
        "caf-[e\u{0301}]>z\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "caf-[x]>z\n"
    );
}

#[test]
fn replace_selection_ending_on_a_combining_mark_stops_at_its_own_cluster() {
    // A word-end motion leaves the inclusive end on a cluster's trailing
    // combining mark, not its base char: the selection here ends on the
    // U+0301 itself, one char past "cafe". The stop test must recognize
    // that the é cluster it's already inside is the last one selected,
    // rather than reading the raw char offset and wandering into the
    // untouched " x" that follows.
    assert_state!(
        "-[cafe\u{0301}]> x\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[xxxx]> x\n"
    );
}

#[test]
fn replace_multiline_selection_skips_newline() {
    // Selection spans two lines. The '\n' between them is retained;
    // only the visible characters are replaced. Lines stay separate.
    assert_state!(
        "-[hello\nworld]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[xxxxx\nxxxxx]>\n"
    );
}

#[test]
fn replace_selection_including_structural_trailing_newline_preserves_newline() {
    // When the selection reaches the structural trailing '\n', that newline
    // must be preserved: replace_selections skips '\n' graphemes entirely.
    assert_state!(
        "-[hello\n]>",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-[xxxxx\n]>"
    );
}

// ── Smart replace (pair-aware) ───────────────────────────────────────────

#[test]
fn smart_replace_opening_bracket_to_opening() {
    // Two cursors on `(` and `)`, replace with `[` → `[` and `]`.
    assert_state!(
        "-{(}>hello-[)]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), '['),
        "-{[}>hello-[]]>\n"
    );
}

#[test]
fn smart_replace_asym_to_sym() {
    // `(` and `)` replaced with `"` → both become `"`.
    assert_state!(
        "-{(}>hello-[)]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), '"'),
        "-{\"}>hello-[\"]>\n"
    );
}

#[test]
fn smart_replace_sym_to_asym_uses_index() {
    // Two cursors on `"` and `"`, replace with `(` → `(` and `)`.
    assert_state!(
        "-{\"}>hello-[\"]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), '('),
        "-{(}>hello-[)]>\n"
    );
}

#[test]
fn smart_replace_sym_to_sym() {
    // Two cursors on `"` and `"`, replace with `'` → both `'`.
    assert_state!(
        "-{\"}>hello-[\"]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), '\''),
        "-{'}>hello-[']>\n"
    );
}

#[test]
fn smart_replace_non_delimiter_is_literal() {
    // Cursor on `x`, replace with `[` → literal `[` (no smart logic).
    assert_state!(
        "-[x]>hello\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), '['),
        "-[[]>hello\n"
    );
}

#[test]
fn smart_replace_range_selection_no_smart_logic() {
    // Range selection (not a cursor): all chars become `[`, no smart logic.
    assert_state!(
        "-[(he]>llo)\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), '['),
        "-[[[[]>llo)\n"
    );
}

#[test]
fn smart_replace_non_pair_replacement_is_literal() {
    // Replacement is not a pair char: always literal, even on delimiters.
    assert_state!(
        "-{(}>hello-[)]>\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), 'x'),
        "-{x}>hello-[x]>\n"
    );
}

// ── Word start and cluster edges ──────────────────────────────────────────

#[test]
fn word_start_before_walks_back_over_a_word_ending_in_a_combining_mark() {
    let (text, _) = test_fixtures::testing::parse_state("x cafe\u{301}-[ ]>y\n");
    assert_eq!(
        word_start_before(&text, CharOffset::new(7), WordChars::default()),
        CharOffset::new(2)
    );
}

#[test]
fn word_start_before_walks_back_over_cjk_chars() {
    let (text, _) = test_fixtures::testing::parse_state("x \u{6f22}\u{5b57}-[ ]>y\n");
    assert_eq!(
        word_start_before(&text, CharOffset::new(4), WordChars::default()),
        CharOffset::new(2)
    );
}

#[test]
fn replace_around_cursors_forward_span_that_ends_inside_a_cluster_covers_it_whole() {
    // Three chars from 'a' end on the 'e' of {e◌́}; the whole cluster goes.
    assert_state!(
        "-[a]>be\u{301}c\n",
        |(text, sels)| replace_around_cursors(test_fixtures::testing::state(text, sels), 0, 3, "Z"),
        "Z-[c]>\n"
    );
}

#[test]
fn replace_a_prepend_led_open_paren_keeps_it_an_opener() {
    assert_state!(
        "-[\u{600}(]>x)\n",
        |(text, sels)| replace_selections(test_fixtures::testing::state(text, sels), ']'),
        "-[[]>x)\n"
    );
}

// ── replace_each_selection ──────────────────────────────────────────────────

fn values(v: &[&str]) -> Vec<String> {
    v.iter().map(|s| s.to_string()).collect()
}

#[test]
fn replace_each_selection_covers_the_output() {
    assert_state!(
        "-[hello]> world\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["HI"])),
        "-[HI]> world\n"
    );
}

#[test]
fn replace_each_selection_gives_each_selection_its_own_value() {
    assert_state!(
        "-[ab]> -{cd}> -[ef]>\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["1", "22", "333"])),
        "-[1]> -{22}> -[333]>\n"
    );
}

#[test]
fn replace_each_selection_keeps_a_backward_selection_backward() {
    assert_state!(
        "<[ab]-\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["xyz"])),
        "<[xyz]-\n"
    );
}

#[test]
fn replace_each_selection_with_empty_output_leaves_a_cursor_after_the_removed_text() {
    assert_state!(
        "a-[bc]>d\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&[""])),
        "a-[d]>\n"
    );
}

#[test]
fn replace_each_selection_takes_multi_line_output() {
    assert_state!(
        "-[ab]>\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["x\ny"])),
        "-[x\ny]>\n"
    );
}

#[test]
fn replace_each_selection_over_the_whole_text_keeps_the_final_break() {
    assert_state!(
        "-[b\na\n]>",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["a\nb\n"])),
        "-[a\nb\n]>"
    );
}

#[test]
fn replace_each_selection_over_the_final_break_with_output_lacking_one_keeps_it() {
    assert_state!(
        "-[b\na\n]>",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["a\nb"])),
        "-[a\nb]>\n"
    );
}

#[test]
fn replace_each_selection_with_empty_output_over_the_final_break_keeps_it() {
    assert_state!(
        "x-[a\n]>",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&[""])),
        "x-[\n]>"
    );
}

#[test]
fn replace_each_selection_output_starting_with_a_combining_mark_joins_the_cluster_before() {
    assert_state!(
        "e-[x]>\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["\u{301}"])),
        "-[e\u{301}]>\n"
    );
}

#[test]
fn replace_each_selection_normalizes_crlf_inside_the_output() {
    assert_state!(
        "-[ab]>\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["x\r\ny"])),
        "-[x\ny]>\n"
    );
}

#[test]
fn replace_each_selection_with_empty_outputs_keeps_each_facing() {
    assert_state!(
        "-[ab]> <{cd}-x\n",
        |(text, sels)| replace_each_selection(state(text, sels), &values(&["", ""])),
        "-[ ]><{x}-\n"
    );
}

#[test]
fn replace_each_selection_with_identical_output_changes_nothing() {
    let (text, sels) = parse_state("-[ab]> -{cd}>\n");
    let edited = replace_each_selection(state(text, sels), &values(&["ab", "cd"]));
    assert!(edited.changes().is_identity());
}

#[test]
fn replace_each_selection_replaces_every_corpus_sample_whole() {
    for s in ALL {
        assert_state!(
            &format!("x\n-[{s}]>b\n"),
            |(text, sels)| replace_each_selection(state(text, sels), &values(&["Z"])),
            "x\n-[Z]>b\n"
        );
    }
}

#[test]
#[should_panic(expected = "one value per selection")]
fn replace_each_selection_refuses_a_count_mismatch() {
    let (text, sels) = parse_state("-[ab]> -{cd}>\n");
    replace_each_selection(state(text, sels), &values(&["x"]));
}
