use super::super::*;
use crate::auto_pairs::{DEFAULT_PAIRS, Pair};
use crate::edit::insert::line_indent_range;
use hume_editing::indent::BreakIndent;
use hume_editing::selection::{EditView, SelectionSet};
use hume_editing::tab_style::TabStyle;
use hume_editing::text::BufferText;
use hume_rope::cluster::ClusterStart;
use hume_rope::column::BufferLineCol;
use hume_rope::offset::{CharOffset, ExclusiveRange};
use test_fixtures::assert_state;
use test_fixtures::testing::IntoTestResult;

/// Test-only stand-in for `arm_autoindent`: treats every current selection's
/// line as owned, as a session that has copied indent onto every cursor's
/// current line would.
fn owns_every_line(text: &BufferText, sels: &SelectionSet) -> Vec<ExclusiveRange<CharOffset>> {
    hume_editing::selection::EditView::bind(text, sels)
        .iter()
        .map(|sel| line_indent_range(text, sel.head().offset()).chars())
        .collect()
}

fn line_break_owning(text: BufferText, sels: SelectionSet) -> Edited {
    let allowed = owns_every_line(&text, &sels);
    break_with(
        text,
        sels,
        LineBreak::AtCursor,
        &allowed,
        &[],
        None,
        &mut Vec::new(),
    )
}

/// Plans and applies one line break with a provider that logs the offset of
/// every split it is asked for and answers `indent`.
fn break_with(
    text: BufferText,
    sels: SelectionSet,
    place: LineBreak,
    allowed: &[ExclusiveRange<CharOffset>],
    pairs: &[Pair],
    indent: Option<BreakIndent>,
    asked: &mut Vec<usize>,
) -> Edited {
    let plan = plan_line_breaks(
        EditView::bind(&text, &sels),
        place,
        allowed,
        pairs,
        TabStyle::Soft,
        4,
        NewLineIndent::Smart(|split: ClusterStart| {
            asked.push(split.offset().index());
            indent
        }),
    );
    apply_line_break_plan(test_fixtures::testing::state(text, sels), plan)
}

fn clear_blank_line_indent_owning(text: BufferText, sels: SelectionSet) -> Edited {
    let allowed = owns_every_line(&text, &sels);
    clear_blank_line_indent(test_fixtures::testing::state(text, sels), &allowed)
}

// ── insert_char ───────────────────────────────────────────────────────────

#[test]
fn insert_char_at_cursor_start() {
    // Cursor on 'h'; 'x' inserted before it; cursor advances to 'h'.
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "x-[h]>ello\n"
    );
}

#[test]
fn insert_char_at_cursor_middle() {
    // Cursor on second 'l' (offset 3); 'x' inserted, cursor on 'l'.
    assert_state!(
        "hel-[l]>o\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "helx-[l]>o\n"
    );
}

#[test]
fn insert_char_at_cursor_eof() {
    // Cursor at EOF (offset 5); 'x' appended; cursor at new EOF.
    assert_state!(
        "hello-[\n]>",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "hellox-[\n]>"
    );
}

#[test]
fn insert_char_into_empty_buffer() {
    assert_state!(
        "-[\n]>",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "x-[\n]>"
    );
}

#[test]
fn insert_char_replaces_forward_selection() {
    // Selection anchor=0, head=3 covers 'h','e','l','l' (4 chars).
    // Delete [0,4), insert 'x', cursor at 1.
    assert_state!(
        "-[hell]>o\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "x-[o]>\n"
    );
}

#[test]
fn insert_char_replaces_selection_grapheme_base() {
    // The selection's last cluster is {e\u{0301}} = é, so typing 'Z' replaces
    // all of "café" and leaves no orphaned accent: "Z x\n", cursor on ' '.
    assert_state!(
        "-[cafe\u{0301}]> x\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'Z'),
        "Z-[ ]>x\n"
    );
}

#[test]
fn insert_char_replaces_whole_buffer() {
    assert_state!(
        "-[hello]>\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "x-[\n]>"
    );
}

#[test]
fn insert_char_replaces_backward_selection() {
    // anchor=3, head=0 covers chars 0-3 ('h','e','l','l'): "hell" (4 chars).
    // Delete [0,4), insert 'x' at 0, cursor at 1.
    // Text "hello" → remove "hell" → "o", insert 'x' → "xo".
    assert_state!(
        "<[hell]-o\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "x-[o]>\n"
    );
}

#[test]
fn insert_char_two_cursors() {
    // Cursors at 0 and 3. Insert 'x' at both positions.
    // Changeset: Insert("x"), Retain(3), Insert("x"), Retain(4).
    // Result: "xfoox bar", cursors at 1 and 5.
    assert_state!(
        "-{f}>oo-[ ]>bar\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'x'),
        "x-{f}>oox-[ ]>bar\n"
    );
}

#[test]
fn insert_char_unicode() {
    // Insert a multi-byte char (2 bytes in UTF-8, 1 char offset).
    assert_state!(
        "caf-[é]>\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), 'à'),
        "cafà-[é]>\n"
    );
}

// ── insert_values ─────────────────────────────────────────────────────────

fn iv(text: BufferText, sels: SelectionSet, values: &[&str]) -> Edited {
    let values: Vec<String> = values.iter().map(|v| v.to_string()).collect();
    insert_values(test_fixtures::testing::state(text, sels), &values)
}

#[test]
fn insert_values_gives_each_cursor_its_own_value_when_counts_match() {
    assert_state!(
        "-{h}>ell-[o]>\n",
        |(text, sels)| iv(text, sels, &["AB", "CD"]),
        "AB-{h}>ellCD-[o]>\n"
    );
}

#[test]
fn insert_values_joins_them_at_every_cursor_when_counts_differ() {
    assert_state!(
        "-{h}>ell-[o]>\n",
        |(text, sels)| iv(text, sels, &["A", "B", "C"]),
        "ABC-{h}>ellABC-[o]>\n"
    );
}

#[test]
fn insert_values_joins_them_at_a_single_cursor() {
    assert_state!(
        "-[h]>i\n",
        |(text, sels)| iv(text, sels, &["A", "B"]),
        "AB-[h]>i\n"
    );
}

#[test]
fn insert_values_of_an_empty_list_changes_nothing() {
    assert_state!("-[h]>i\n", |(text, sels)| iv(text, sels, &[]), "-[h]>i\n");
}

#[test]
fn insert_values_leaves_a_cursor_whose_value_is_empty_in_place() {
    assert_state!(
        "-{h}>ell-[o]>\n",
        |(text, sels)| iv(text, sels, &["", "CD"]),
        "-{h}>ellCD-[o]>\n"
    );
}

#[test]
fn insert_values_replaces_each_selection_with_its_own_value() {
    assert_state!(
        "-{he}>l-[lo]>\n",
        |(text, sels)| iv(text, sels, &["AB", "CD"]),
        "AB-{l}>CD-[\n]>"
    );
}

// ── insert_str ────────────────────────────────────────────────────────────
//
// Bulk-string counterpart of insert_char, used for terminal paste. Mirrors
// insert_char's cases plus multi-char-specific ones (multi-line text,
// grapheme clusters spanning the inserted text, identity on empty string).

#[test]
fn insert_str_at_cursor_start() {
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xyz"),
        "xyz-[h]>ello\n"
    );
}

#[test]
fn insert_str_at_cursor_eof() {
    assert_state!(
        "hello-[\n]>",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xyz"),
        "helloxyz-[\n]>"
    );
}

#[test]
fn insert_str_replaces_forward_selection() {
    // Selection covers "hell" (4 chars); replaced by "xyz".
    assert_state!(
        "-[hell]>o\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xyz"),
        "xyz-[o]>\n"
    );
}

#[test]
fn insert_str_replaces_backward_selection() {
    assert_state!(
        "<[hell]-o\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xyz"),
        "xyz-[o]>\n"
    );
}

#[test]
fn insert_str_over_last_line_ending_in_newline_adds_no_blank_line() {
    assert_state!(
        "abc\n-[def\n]>",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xyz\n"),
        "abc\nxyz-[\n]>"
    );
}

#[test]
fn insert_str_over_middle_line_ending_in_newline_adds_no_blank_line() {
    assert_state!(
        "abc\n-[def\n]>ghi\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xyz\n"),
        "abc\nxyz\n-[g]>hi\n"
    );
}

#[test]
fn insert_str_two_cursors() {
    // Cursors at 0 and 3; "xy" inserted at both.
    assert_state!(
        "-{f}>oo-[ ]>bar\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "xy"),
        "xy-{f}>ooxy-[ ]>bar\n"
    );
}

#[test]
fn insert_str_normalizes_line_endings() {
    // Insert-mode paste and dot-repeat replay both land here, and neither
    // guarantees LF. The builder normalizes every insertion, so no op in
    // this crate has to.
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "x\r\ny"),
        "x\ny-[h]>ello\n"
    );
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "x\ry"),
        "x\ny-[h]>ello\n"
    );
}

#[test]
fn insert_str_unicode_grapheme() {
    // Pasted text itself contains a combining sequence (é = e + combining
    // acute). Cursor lands after the whole pasted span via new_pos(), never
    // mid-cluster.
    assert_state!(
        "caf-[é]>\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "e\u{0301}"),
        "cafe\u{0301}-[é]>\n"
    );
}

#[test]
fn insert_str_multiline() {
    // Pasted text contains an embedded newline; buffer's structural trailing
    // \n is untouched.
    assert_state!(
        "h-[e]>llo\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), "X\nY"),
        "hX\nY-[e]>llo\n"
    );
}

#[test]
fn insert_str_empty_is_identity() {
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_str(test_fixtures::testing::state(text, sels), ""),
        "-[h]>ello\n"
    );
}

// ── insert_tab ────────────────────────────────────────────────────────────

#[test]
fn insert_tab_hard_at_cursor() {
    // Hard tab at col 0 → inserts '\t', cursor stays on the original char.
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Hard, 4),
        "\t-[h]>ello\n"
    );
}

#[test]
fn insert_tab_hard_mid_line() {
    assert_state!(
        "hel-[l]>o\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Hard, 4),
        "hel\t-[l]>o\n"
    );
}

#[test]
fn insert_tab_hard_replaces_selection() {
    // Tab over a selection replaces it, same as typing any char.
    assert_state!(
        "-[hell]>o\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Hard, 4),
        "\t-[o]>\n"
    );
}

#[test]
fn insert_tab_hard_two_cursors() {
    assert_state!(
        "-{f}>oo-[ ]>bar\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Hard, 4),
        "\t-{f}>oo\t-[ ]>bar\n"
    );
}

#[test]
fn insert_tab_soft_at_display_col0_inserts_full_width() {
    // Soft tab at col 0, tw=4 → 4 spaces.
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "    -[h]>ello\n"
    );
}

#[test]
fn insert_tab_soft_at_display_col2_inserts_two_spaces() {
    // Soft tab at col 2, tw=4 → 2 spaces (to reach next stop at col 4).
    assert_state!(
        "he-[l]>lo\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "he  -[l]>lo\n"
    );
}

#[test]
fn insert_tab_soft_at_display_col4_inserts_full_width() {
    // Already on a tab stop (col 4) → full tab-width of spaces.
    assert_state!(
        "abcd-[e]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "abcd    -[e]>\n"
    );
}

#[test]
fn insert_tab_soft_after_tab_uses_current_display_col() {
    // "\tx" → cursor after 'x' is at display col 5, tw=4 → 3 spaces to col 8.
    assert_state!(
        "\tx-[y]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "\tx   -[y]>\n"
    );
}

#[test]
fn insert_tab_soft_measures_a_later_cursor_against_the_line_the_deletion_left() {
    // The first selection spans into line 1 and leaves "x" + 3 spaces + "d" on
    // one line, so the cursor on "e" sits at display col 5 and needs 3 spaces,
    // though "e" is at col 2 of its own line in the original text.
    assert_state!(
        "x-{ab\nc}>d-[e]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "x   -{d}>   -[e]>\n"
    );
}

#[test]
fn insert_tab_soft_tab_width_8() {
    // tw=8 at col 0 → 8 spaces.
    assert_state!(
        "-[h]>i\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 8),
        "        -[h]>i\n"
    );
}

#[test]
fn insert_tab_soft_replaces_selection() {
    // Soft tab over a selection: delete selection, insert spaces for the
    // cursor's column (which is the selection start).
    assert_state!(
        "-[hell]>o\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "    -[o]>\n"
    );
}

#[test]
fn insert_tab_soft_two_cursors_different_lines() {
    // Two cursors on different lines: each column is independent.
    // Line 0: cursor on 'c' (col 2) → 2 spaces to reach col 4.
    // Line 1: cursor on 'z' (col 2) → 2 spaces to reach col 4.
    assert_state!(
        "ab-{c}>\nxy-[z]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "ab  -{c}>\nxy  -[z]>\n"
    );
}

#[test]
fn insert_tab_soft_two_cursors_same_line() {
    // Two cursors on the SAME line: cursor 1's effective column accounts for
    // the spaces cursor 0 already inserted, so it aligns to the correct stop.
    //
    // "abc xyz\n": cursor 0 on 'c' (col 2), cursor 1 on 'z' (col 6). tw=4.
    // Cursor 0: col 2 → 2 spaces to reach col 4. display_col_shift = +2.
    // Cursor 1: original col 6 + shift 2 = effective col 8. 8 is a tab stop,
    //           so a full tw=4 spaces to reach col 12.
    // After cursor 0's 2 spaces, 'z' sits at col 8; next stop = 12;
    // spaces needed = 4.
    assert_state!(
        "ab-{c}> xy-[z]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "ab  -{c}> xy    -[z]>\n"
    );
}

#[test]
fn insert_tab_soft_two_cursors_same_line_not_on_stop() {
    // Both cursors on the same line; cursor 0 is NOT at col 0, so cursor 1's
    // effective col is not a multiple of tw. Verifies the arithmetic mid-stop.
    //
    // "abcde fgh\n": cursor 0 on 'd' (col 3), cursor 1 on 'h' (col 8). tw=4.
    // Cursor 0: col 3 → 1 space to reach col 4. display_col_shift = +1.
    // Cursor 1: original col 8 + shift 1 = effective col 9. Next stop = 12.
    //           Spaces = 12 - 9 = 3.
    // After cursor 0's 1 space, 'h' is at col 9; next stop at col 12;
    // spaces needed = 3.
    assert_state!(
        "abc-{d}>e fg-[h]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "abc -{d}>e fg   -[h]>\n"
    );
}

#[test]
fn insert_tab_soft_expands_a_tab_between_cursors_from_the_stop_the_first_left() {
    // "a\tx": cursor 0 on the tab (col 1) gets 3 spaces and so ends on col 4.
    // The tab then runs from col 4 to col 8, where cursor 1 sits and gets a
    // full 4. Measured against the original text the tab would end at col 4.
    assert_state!(
        "a-{\t}>-[x]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "a   -{\t}>    -[x]>\n"
    );
}

#[test]
fn insert_tab_soft_tab_width_1() {
    // Minimum tab width: every column is a stop, so exactly one space is
    // inserted regardless of the cursor's column.
    assert_state!(
        "-[h]>i\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 1),
        " -[h]>i\n"
    );
    assert_state!(
        "he-[l]>lo\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 1),
        "he -[l]>lo\n"
    );
}

// ── insert_char edge cases ────────────────────────────────────────────────

#[test]
fn insert_char_newline() {
    // Inserting '\n' is mechanically identical to any other char: it goes
    // before the cursor character, cursor stays on the original char (now shifted).
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), '\n'),
        "\n-[h]>ello\n"
    );
}

// ── Line break at the cursor (Enter, `o`) ──────────────────────────

#[test]
fn newline_indent_copies_tab_indent() {
    // "\tfoo" cursor on 'f' → new line gets "\t", cursor on 'f' (new line).
    assert_state!(
        "\t-[f]>oo\n",
        |(text, sels)| line_break_owning(text, sels),
        "\t\n\t-[f]>oo\n"
    );
}

#[test]
fn newline_indent_copies_space_indent() {
    // "    bar" cursor on 'b' → new line gets "    ".
    assert_state!(
        "    -[b]>ar\n",
        |(text, sels)| line_break_owning(text, sels),
        "    \n    -[b]>ar\n"
    );
}

#[test]
fn newline_indent_no_indent_on_bare_line() {
    // "foo" cursor on 'o' (last char) → new line bare.
    assert_state!(
        "fo-[o]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "fo\n-[o]>\n"
    );
}

#[test]
fn newline_indent_at_line_start_no_indent_before_cursor() {
    // "foo\n" cursor on 'f' (line start, no indent before cursor) → new line
    // is bare, original 'f' moves to new line.
    assert_state!(
        "-[f]>oo\n",
        |(text, sels)| line_break_owning(text, sels),
        "\n-[f]>oo\n"
    );
}

#[test]
fn newline_indent_mid_line_preserves_content_before_cursor() {
    // "\tfoo" cursor on 'o' (mid content) → content before cursor stays on
    // old line; new line gets indent; cursor on 'o'.
    assert_state!(
        "\tfo-[o]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "\tfo\n\t-[o]>\n"
    );
}

#[test]
fn newline_indent_mixed_indent() {
    // "\t  x" cursor on 'x' → new line gets "\t  ".
    assert_state!(
        "\t  -[x]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "\t  \n\t  -[x]>\n"
    );
}

#[test]
fn newline_indent_replaces_selection() {
    // Selection over "foo" in "\tfoo\n": delete selection, insert "\n" + indent.
    // Cursor lands on the structural trailing '\n' (the retained original).
    assert_state!(
        "\t-[foo]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "\t\n\t-[\n]>"
    );
}

#[test]
fn newline_indent_second_line() {
    // "a\n\tb\n" cursor on 'b' (line 1, indented) → new line gets "\t".
    assert_state!(
        "a\n\t-[b]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "a\n\t\n\t-[b]>\n"
    );
}

#[test]
fn newline_indent_two_cursors_different_indents() {
    // Two cursors on differently-indented lines get their own indent.
    // Line 0 "  a" (cursor on 'a'), line 1 "\tb" (cursor on 'b').
    assert_state!(
        "  -{a}>\n\t-[b]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "  \n  -{a}>\n\t\n\t-[b]>\n"
    );
}

#[test]
fn newline_indent_cursor_on_structural_newline() {
    // Cursor on the structural '\n' of an indented line ("  x\n"): the '\n'
    // is retained, a new line is opened after it with the line's indent
    // copied across, and the cursor lands on the new line's '\n'. Mirrors
    // `insert_char` behaviour for a cursor on the structural newline.
    assert_state!(
        "  x-[\n]>",
        |(text, sels)| line_break_owning(text, sels),
        "  x\n  -[\n]>"
    );
}

#[test]
fn newline_indent_replaces_multi_line_selection() {
    // Selection spans "ab\n\txy" in "\tab\n\txy\n": the whole span is deleted,
    // then a '\n' + the source line's indent ("\t") is inserted at the
    // selection's start. With the retained leading '\t' and the trailing
    // structural '\n', the buffer collapses to "\t\n\t\n" and the cursor ends
    // on that final '\n', the same "land on the structural '\n'" rule as the
    // single-line selection case.
    assert_state!(
        "\t-[ab\n\txy]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "\t\n\t-[\n]>"
    );
}

#[test]
fn newline_indent_trims_blank_line_on_second_enter() {
    // Cursor on the structural '\n' of a blank, auto-indented line ("  \n"):
    // vim autoindent parity: that whitespace is vacated (not carried
    // forward) before opening a fresh indented line below it.
    assert_state!(
        "x\n  -[\n]>",
        |(text, sels)| line_break_owning(text, sels),
        "x\n\n  -[\n]>"
    );
}

#[test]
fn newline_indent_trims_blank_line_cursor_mid_whitespace() {
    // Collapsed cursor anywhere within a blank line's whitespace (not just
    // at its end) still triggers the trim. The whole line is judged blank,
    // not just the region before the cursor.
    assert_state!(
        "x\n -[ ]> \n",
        |(text, sels)| line_break_owning(text, sels),
        "x\n\n   -[\n]>"
    );
}

#[test]
fn newline_indent_trim_blank_false_preserves_pre_existing_blank_line() {
    // Empty `allowed`: the first Enter on a line that was already blank
    // before this insert session touched it (nothing has armed a record for
    // it yet) leaves the pre-existing whitespace alone; only the *new* line
    // gets a copied indent, same as the non-blank-line case.
    assert_state!(
        "x\n  -[\n]>",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "x\n  \n  -[\n]>"
    );
}

#[test]
fn newline_indent_two_cursors_same_blank_line_each_open_a_line() {
    // Two collapsed cursors on the same whitespace-only line: both vacate the
    // line and each opens its own indented line.
    assert_state!(
        "-{ }> -[ ]>\n",
        |(text, sels)| line_break_owning(text, sels),
        "\n   -{\n}>   -[\n]>"
    );
}

#[test]
fn newline_indent_two_cursors_second_on_blank_line_newline() {
    // The second cursor sits on the blank line's structural '\n'. Both
    // cursors vacate "  \n" and each opens its own line with the copied
    // indent.
    assert_state!(
        "-{ }> -[\n]>",
        |(text, sels)| line_break_owning(text, sels),
        "\n  -{\n}>  -[\n]>"
    );
}

// ── Line break above the line (`O`) ──────────────────────────────────

#[test]
fn above_line_copies_tab_indent() {
    // "\tfoo" cursor on 'f' → blank indented line inserted above it, cursor
    // on that line's own '\n'.
    assert_state!(
        "\t-[f]>oo\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "\t-[\n]>\tfoo\n"
    );
}

#[test]
fn above_line_copies_space_indent() {
    assert_state!(
        "    -[b]>ar\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "    -[\n]>    bar\n"
    );
}

#[test]
fn above_line_no_indent_on_bare_line() {
    assert_state!(
        "fo-[o]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "-[\n]>foo\n"
    );
}

#[test]
fn above_line_second_line_leaves_first_untouched() {
    // Indent comes from the selection's own line, not the buffer's first
    // line: "foo" (no indent) stays untouched above the new blank line.
    assert_state!(
        "foo\n\t-[b]>ar\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "foo\n\t-[\n]>\tbar\n"
    );
}

#[test]
fn above_line_two_cursors_different_indents() {
    assert_state!(
        "\t-{a}>\n  -[b]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "\t-{\n}>\ta\n  -[\n]>  b\n"
    );
}

// ── Line breaks with automatic indentation off ────────────────────────────

/// Plans and applies one line break with automatic indentation off, with
/// the default auto-pairs in effect.
fn break_unindented(
    text: BufferText,
    sels: SelectionSet,
    place: LineBreak,
    allowed: &[ExclusiveRange<CharOffset>],
) -> Edited {
    let plan = plan_line_breaks(
        EditView::bind(&text, &sels),
        place,
        allowed,
        DEFAULT_PAIRS,
        TabStyle::Soft,
        4,
        NewLineIndent::<fn(ClusterStart) -> Option<BreakIndent>>::LeftMargin,
    );
    apply_line_break_plan(test_fixtures::testing::state(text, sels), plan)
}

#[test]
fn unindented_line_break_mid_line_moves_the_rest_to_the_left_margin() {
    assert_state!(
        "\tfo-[o]>\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "\tfo\n-[o]>\n"
    );
}

#[test]
fn unindented_line_break_at_the_end_of_an_indented_line_opens_a_bare_line() {
    assert_state!(
        "  x-[\n]>",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "  x\n-[\n]>"
    );
}

#[test]
fn unindented_line_break_keeps_a_blank_lines_whitespace_it_does_not_own() {
    assert_state!(
        "x\n  -[\n]>",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "x\n  \n-[\n]>"
    );
}

#[test]
fn unindented_line_break_vacates_a_blank_lines_owned_whitespace() {
    assert_state!(
        "x\n  -[\n]>",
        |(text, sels)| {
            let allowed = owns_every_line(&text, &sels);
            break_unindented(text, sels, LineBreak::AtCursor, &allowed)
        },
        "x\n\n-[\n]>"
    );
}

#[test]
fn unindented_line_break_between_a_pair_does_not_open_a_block() {
    assert_state!(
        "  f() {-[}]>\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "  f() {\n-[}]>\n"
    );
}

#[test]
fn unindented_line_breaks_at_cursors_on_several_lines() {
    assert_state!(
        "  -{a}>\n\t-[b]>\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "  \n-{a}>\n\t\n-[b]>\n"
    );
}

#[test]
fn unindented_line_breaks_at_cursors_on_one_line() {
    assert_state!(
        "\ta-{b}>c-[d]>\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "\ta\n-{b}>c\n-[d]>\n"
    );
}

#[test]
fn unindented_line_break_replaces_a_selection_with_a_bare_break() {
    assert_state!(
        "  a-[bc]>d\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "  a\n-[d]>\n"
    );
}

#[test]
fn unindented_line_break_over_a_selection_to_the_line_end() {
    assert_state!(
        "\t-[foo]>\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AtCursor, &[]),
        "\t\n-[\n]>"
    );
}

#[test]
fn unindented_above_line_on_line_zero_opens_an_empty_line() {
    assert_state!(
        "\t-[f]>oo\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AboveLine, &[]),
        "-[\n]>\tfoo\n"
    );
}

#[test]
fn unindented_above_line_below_line_zero_opens_an_empty_line() {
    assert_state!(
        "foo\n\t-[b]>ar\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AboveLine, &[]),
        "foo\n-[\n]>\tbar\n"
    );
}

#[test]
fn unindented_above_line_at_cursors_on_several_lines() {
    assert_state!(
        "\t-{a}>\n  -[b]>\n",
        |(text, sels)| break_unindented(text, sels, LineBreak::AboveLine, &[]),
        "-{\n}>\ta\n-[\n]>  b\n"
    );
}

// ── owned_blank_indent (autoindent ownership containment) ────────────────
//
// `line_break_owning`/`clear_blank_line_indent_owning` above cover
// the common case: a session that owns exactly its cursor's current line. These exercise the containment check itself: what
// changes ownership once a session's record and the buffer diverge.

#[test]
fn owned_blank_indent_rejects_whitespace_typed_past_owned_end() {
    // Buffer "x\n  \n": line 1 is "  " (chars 2..4) + '\n' at 4. `allowed`
    // records an *empty* range at the line's start (as if nothing was
    // copied there, an unindented `o`/`O`), but the line now reads as blank
    // because whitespace was typed past what the session actually owns.
    let (text, sels) = test_fixtures::testing::parse_state("x\n-[ ]> \n");
    let head = hume_editing::selection::EditView::bind(&text, &sels)
        .primary()
        .head()
        .offset();
    let line_start = text.line_to_char(text.char_to_line(head).into());
    let allowed = ExclusiveRange::new(line_start, line_start);
    assert_eq!(owned_blank_indent(&text, head, Some(allowed)), None);
}

#[test]
fn owned_blank_indent_accepts_backspaced_indent_within_owned_range() {
    // Same buffer, but `allowed` records a range wider than the line's
    // *current* whitespace, as if more was typed and then backspaced away.
    // The remaining whitespace is a subset of what the session owns, so
    // ownership still holds: vim's own `<BS>` carve-out, for free.
    let (text, sels) = test_fixtures::testing::parse_state("x\n-[ ]> \n");
    let head = hume_editing::selection::EditView::bind(&text, &sels)
        .primary()
        .head()
        .offset();
    let line_start = text.line_to_char(text.char_to_line(head).into());
    let allowed = ExclusiveRange::new(line_start, line_start.shift(10));
    assert!(owned_blank_indent(&text, head, Some(allowed)).is_some());
}

#[test]
fn owned_blank_indent_rejects_a_different_blank_line() {
    // Buffer "  \n  \n": two identical blank lines. `allowed` records
    // ownership of line 0's indent, but the cursor sits on line 1: blank in
    // its own right, but not the line this session armed. This is the
    // arrow-key-onto-another-blank-line case: a cursor motion never has to
    // clear the record explicitly, because the record's `line_start` simply
    // no longer matches wherever the cursor now is.
    let (text, sels) = test_fixtures::testing::parse_state("  \n-[ ]> \n");
    let head = hume_editing::selection::EditView::bind(&text, &sels)
        .primary()
        .head()
        .offset();
    let allowed = ExclusiveRange::new(CharOffset::new(0), CharOffset::new(2));
    assert_eq!(owned_blank_indent(&text, head, Some(allowed)), None);
}

// ── clear_blank_line_indent (vim autoindent parity on Insert-mode exit) ───

#[test]
fn clear_blank_line_indent_clears_whitespace_only_line() {
    // Cursor on a blank, auto-indented line: its whitespace is cleared,
    // cursor lands on the resulting (now truly empty) line's '\n'.
    assert_state!(
        "-[ ]> \n",
        |(text, sels)| clear_blank_line_indent_owning(text, sels),
        "-[\n]>"
    );
}

#[test]
fn clear_blank_line_indent_no_op_on_content_line() {
    // Cursor on a line with real content: identity edit, nothing cleared.
    assert_state!(
        "-[f]>oo\n",
        |(text, sels)| clear_blank_line_indent_owning(text, sels),
        "-[f]>oo\n"
    );
}

#[test]
fn clear_blank_line_indent_multi_cursor_only_clears_blank_line() {
    // One cursor on a content line, one on a blank auto-indented line: only
    // the blank line's whitespace is cleared; the content-line cursor is an
    // identity edit.
    assert_state!(
        "-{f}>oo\n -[ ]>\n",
        |(text, sels)| clear_blank_line_indent_owning(text, sels),
        "-{f}>oo\n-[\n]>"
    );
}

#[test]
fn clear_blank_line_indent_two_cursors_same_line_merge() {
    // Two cursors on the same blank line: both clear it and land on the same
    // spot, so the selections merge into one.
    assert_state!(
        "-{ }> -[ ]>\n",
        |(text, sels)| clear_blank_line_indent_owning(text, sels),
        "-[\n]>"
    );
}

#[test]
fn clear_blank_line_indent_second_cursor_on_blank_line_newline() {
    // The second cursor sits on the blank line's structural '\n'. Both
    // cursors clear the line and land on the same spot, so they merge.
    assert_state!(
        "-{ }> -[\n]>",
        |(text, sels)| clear_blank_line_indent_owning(text, sels),
        "-[\n]>"
    );
}

#[test]
fn clear_blank_line_indent_preserves_non_collapsed_selection() {
    // One collapsed cursor on a blank indented line, plus a non-collapsed
    // selection elsewhere: the blank line is trimmed as usual, but the
    // other selection's anchor and head must both survive, not collapse to
    // its head. "foo\n \nbar\n" (line1 is a single-space blank line);
    // selection B covers "ar" in "bar" on line2.
    assert_state!(
        "foo\n-{ }>\nb-[ar]>\n",
        |(text, sels)| clear_blank_line_indent_owning(text, sels),
        "foo\n-{\n}>b-[ar]>\n"
    );
}

#[test]
fn insert_char_combining_codepoint() {
    // Inserting a bare combining accent (U+0301) before 'h'. Mechanically
    // fine: the accent is stored as its own codepoint at position 0, and
    // the cursor lands on 'h' (now at position 1).
    assert_state!(
        "-[h]>ello\n",
        |(text, sels)| insert_char(test_fixtures::testing::state(text, sels), '\u{0301}'),
        "\u{0301}-[h]>ello\n"
    );
}

// ── Clusters, wide chars and unicode indent ───────────────────────────────

#[test]
fn line_break_copies_a_space_and_combining_mark_indent_whole() {
    assert_state!(
        " \u{301}-[x]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        " \u{301}\n \u{301}-[x]>\n"
    );
}

#[test]
fn line_break_copies_a_non_breaking_space_indent() {
    assert_state!(
        "\u{a0}\u{3000}-[x]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "\u{a0}\u{3000}\n\u{a0}\u{3000}-[x]>\n"
    );
}

#[test]
fn above_line_copies_a_non_breaking_space_indent() {
    assert_state!(
        "\u{a0}-[b]>ar\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "\u{a0}-[\n]>\u{a0}bar\n"
    );
}

#[test]
fn insert_tab_soft_counts_a_wide_char_as_two_columns() {
    // Cursor after one 2-cell CJK char sits at display col 2: two spaces to col 4.
    assert_state!(
        "\u{6f22}-[x]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "\u{6f22}  -[x]>\n"
    );
}

#[test]
fn insert_tab_soft_counts_a_combining_cluster_as_one_column() {
    assert_state!(
        "e\u{301}-[x]>\n",
        |(text, sels)| insert_tab(test_fixtures::testing::state(text, sels), TabStyle::Soft, 4),
        "e\u{301}   -[x]>\n"
    );
}

#[test]
fn line_break_over_the_last_line_adds_no_blank_line() {
    assert_state!(
        "abc\n-[def\n]>",
        |(text, sels)| line_break_owning(text, sels),
        "abc\n-[\n]>"
    );
}

#[test]
fn line_break_over_an_indented_last_line_keeps_the_indent() {
    assert_state!(
        "  abc\n  -[def\n]>",
        |(text, sels)| line_break_owning(text, sels),
        "  abc\n  \n  -[\n]>"
    );
}

#[test]
fn line_break_over_a_middle_selection_lands_after_it() {
    assert_state!(
        "abc\n-[def\n]>ghi\n",
        |(text, sels)| line_break_owning(text, sels),
        "abc\n\n-[g]>hi\n"
    );
}

// ── Line breaks with a computed indent ────────────────────────────────────

fn indent(width: u32, after_token: bool) -> Option<BreakIndent> {
    Some(BreakIndent {
        width: BufferLineCol::new(width),
        after_token,
    })
}

#[test]
fn line_break_after_content_uses_the_computed_width() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "foo-[\n]>",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(4, false),
            &mut asked.borrow_mut()
        ),
        "foo\n    -[\n]>"
    );
    assert_eq!(*asked.borrow(), vec![3]);
}

#[test]
fn line_break_renders_the_computed_width_in_the_tab_style() {
    let (text, sels) = test_fixtures::testing::parse_state("a-[\n]>");
    let plan = plan_line_breaks(
        EditView::bind(&text, &sels),
        LineBreak::AtCursor,
        &[],
        &[],
        TabStyle::Hard,
        4,
        NewLineIndent::Smart(|_| indent(6, false)),
    );
    let (text, sels) =
        apply_line_break_plan(test_fixtures::testing::state(text, sels), plan).into_test_result();
    assert_eq!(
        test_fixtures::testing::serialize_state(&text, &sels),
        "a\n\t  -[\n]>"
    );
}

#[test]
fn line_break_copies_without_asking_when_the_cursor_is_in_leading_whitespace() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "   -[ ]>x\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(8, false),
            &mut asked.borrow_mut()
        ),
        "   \n    -[ ]>x\n"
    );
    assert_eq!(*asked.borrow(), Vec::<usize>::new());
}

#[test]
fn line_break_copies_without_asking_on_the_first_non_blank_char() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "  -[x]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(8, false),
            &mut asked.borrow_mut()
        ),
        "  \n  -[x]>\n"
    );
    assert_eq!(*asked.borrow(), Vec::<usize>::new());
}

#[test]
fn line_break_copies_without_asking_at_column_zero_of_an_unindented_line() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "-[f]>oo\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(8, false),
            &mut asked.borrow_mut()
        ),
        "\n-[f]>oo\n"
    );
    assert_eq!(*asked.borrow(), Vec::<usize>::new());
}

#[test]
fn line_break_on_an_owned_blank_line_vacates_it_and_uses_the_computed_width() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "x\n  -[\n]>",
        |(text, sels)| {
            let allowed = owns_every_line(&text, &sels);
            break_with(
                text,
                sels,
                LineBreak::AtCursor,
                &allowed,
                &[],
                indent(4, false),
                &mut asked.borrow_mut(),
            )
        },
        "x\n\n    -[\n]>"
    );
    assert_eq!(*asked.borrow(), vec![4]);
}

#[test]
fn line_break_between_a_pair_after_a_token_opens_a_block() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "x{-[}]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            DEFAULT_PAIRS,
            indent(0, true),
            &mut asked.borrow_mut()
        ),
        "x{\n    -[\n]>}\n"
    );
    assert_eq!(*asked.borrow(), vec![2]);
}

#[test]
fn line_break_between_a_pair_not_after_a_token_is_plain() {
    assert_state!(
        "x{-[}]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            DEFAULT_PAIRS,
            indent(0, false),
            &mut Vec::new()
        ),
        "x{\n-[}]>\n"
    );
}

#[test]
fn line_break_between_a_symmetric_pair_does_not_open_a_block() {
    assert_state!(
        "x\"-[\"]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            DEFAULT_PAIRS,
            indent(4, true),
            &mut Vec::new()
        ),
        "x\"\n    -[\"]>\n"
    );
}

#[test]
fn line_break_between_a_pair_without_a_computed_indent_copies() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "x{-[}]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            DEFAULT_PAIRS,
            None,
            &mut asked.borrow_mut()
        ),
        "x{\n-[}]>\n"
    );
    assert_eq!(*asked.borrow(), vec![2]);
}

#[test]
fn line_break_over_a_selection_copies_without_asking() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "\t-[foo]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(8, false),
            &mut asked.borrow_mut()
        ),
        "\t\n\t-[\n]>"
    );
    assert_eq!(*asked.borrow(), Vec::<usize>::new());
}

#[test]
fn above_line_on_line_zero_copies_without_asking() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "\t-[f]>oo\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            indent(8, false),
            &mut asked.borrow_mut()
        ),
        "\t-[\n]>\tfoo\n"
    );
    assert_eq!(*asked.borrow(), Vec::<usize>::new());
}

#[test]
fn above_line_asks_at_the_previous_lines_break() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "a\nb\n-[c]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            indent(4, false),
            &mut asked.borrow_mut()
        ),
        "a\nb\n    -[\n]>c\n"
    );
    assert_eq!(*asked.borrow(), vec![3]);
}

#[test]
fn above_line_without_a_computed_indent_copies() {
    assert_state!(
        "a\n\t-[b]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            None,
            &mut Vec::new()
        ),
        "a\n\t-[\n]>\tb\n"
    );
}

#[test]
fn line_breaks_at_several_cursors_ask_in_selection_order() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "a-{\n}>b-[\n]>",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(2, false),
            &mut asked.borrow_mut()
        ),
        "a\n  -{\n}>b\n  -[\n]>"
    );
    assert_eq!(*asked.borrow(), vec![1, 3]);
}

#[test]
fn line_break_asks_at_the_cluster_start_after_a_combining_mark_and_cjk() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "\u{6f22}e\u{301}-[\n]>",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AtCursor,
            &[],
            &[],
            indent(0, false),
            &mut asked.borrow_mut()
        ),
        "\u{6f22}e\u{301}\n-[\n]>"
    );
    assert_eq!(*asked.borrow(), vec![3]);
}

#[test]
fn above_line_asks_at_the_break_of_a_combining_mark_and_cjk_line() {
    let asked = std::cell::RefCell::new(Vec::new());
    assert_state!(
        "\u{6f22}e\u{301}\n-[x]>\n",
        |(text, sels)| break_with(
            text,
            sels,
            LineBreak::AboveLine,
            &[],
            &[],
            indent(0, false),
            &mut asked.borrow_mut()
        ),
        "\u{6f22}e\u{301}\n-[\n]>x\n"
    );
    assert_eq!(*asked.borrow(), vec![3]);
}

#[test]
#[should_panic(expected = "computed for another text")]
fn applying_a_line_break_plan_to_another_text_panics() {
    let (text, sels) = test_fixtures::testing::parse_state("-[a]>\n");
    let plan = plan_line_breaks(
        EditView::bind(&text, &sels),
        LineBreak::AtCursor,
        &[],
        &[],
        TabStyle::Soft,
        4,
        NewLineIndent::Smart(|_| None),
    );
    let (other_text, other_sels) = test_fixtures::testing::parse_state("-[b]>\n");
    apply_line_break_plan(test_fixtures::testing::state(other_text, other_sels), plan);
}

#[test]
#[should_panic(expected = "the plan has 2 breaks for 1 selections")]
fn applying_a_line_break_plan_to_another_number_of_selections_panics() {
    let (text, sels) = test_fixtures::testing::parse_state("-{a}>\n-[b]>\n");
    let plan = plan_line_breaks(
        EditView::bind(&text, &sels),
        LineBreak::AtCursor,
        &[],
        &[],
        TabStyle::Soft,
        4,
        NewLineIndent::Smart(|_| None),
    );
    let first = text.clusters().first();
    apply_line_break_plan(EditState::with_cursor(text, first), plan);
}
