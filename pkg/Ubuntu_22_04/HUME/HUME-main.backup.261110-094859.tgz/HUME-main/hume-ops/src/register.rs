use std::borrow::Cow;
use std::collections::VecDeque;

use rustc_hash::FxHashMap;
use termina::event::KeyEvent;

use hume_editing::text::normalize_line_endings_owned;

// ── Register name constants ────────────────────────────────────────────────────
//
// HUME uses mnemonic single-char register names: 10 named registers (0-9)
// cover real workflows, freeing letters for intuitive special names.
//
// User-facing register names:
//   '0'–'9'  Named storage for text or macros (last write wins). Symmetric:
//            `"5y` and `"5p` use the same in-memory slot. Not kill-ring slots.
//   'k'      Kill-ring head. Paste reads the most-recently-pushed entry;
//            yank/delete/change push onto the ring (ring-only, no clipboard).
//            Older ring entries reachable only via `[`/`]` cycling.
//   'q'      Default macro register. `QQ` records, `qq` replays.
//            `Q3` records into register '3', `q3` replays from it.
//   'c'      System clipboard (requires OS integration).
//   'b'      Black hole: writes discarded, reads return None.
//   's'      Search register: last search pattern.
//
// '0'–'9' are durable storage; 'k' + `[`/`]` address the kill ring, whose
// head shifts with every d/c/y.
//
/// The kill-ring register (`k`). See the module doc above for how it
/// differs from the durable `0`–`9` registers.
pub const KILL_RING_REGISTER: char = 'k';

/// The black-hole register (`b`): writes are silently discarded, reads return `None`.
/// Use `"by` to yank without touching the default register.
pub const BLACK_HOLE_REGISTER: char = 'b';

/// The search register (`s`): holds the last search pattern.
/// Written on search confirm and by `*`/Ctrl-/; read only to reseed a
/// buffer's compiled pattern. Not addressable via the `"` prefix; go
/// through [`RegisterSet::search_register`] / [`RegisterSet::set_search_register`].
pub(crate) const SEARCH_REGISTER: char = 's';

/// The default macro register (`q`).
/// `QQ` starts/stops recording into this register; `qq` replays from it.
/// Can also hold yanked text if the user explicitly writes to it.
pub const MACRO_REGISTER: char = 'q';

/// The system clipboard register (`c`).
/// Reads and writes the OS clipboard via `arboard`. Falls back to in-memory
/// storage with a warning when the clipboard is unavailable (headless CI/SSH).
pub const CLIPBOARD_REGISTER: char = 'c';

/// The registers a macro can be recorded into and replayed from: the default
/// macro register (`q`) and the numbered storage registers (`0`–`9`).
/// Special registers (`b`, `c`, `s`) are not valid macro targets.
pub const MACRO_REGISTERS: [char; 11] = [
    MACRO_REGISTER,
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
];

/// Returns `true` if `ch` is one of [`MACRO_REGISTERS`].
pub fn is_valid_macro_register(ch: char) -> bool {
    MACRO_REGISTERS.contains(&ch)
}

/// Returns `true` if `ch` is a valid register name for the `"<reg>` prefix.
///
/// Accepts the numbered storage registers (`0`–`9`), kill-ring head (`k`),
/// black hole (`b`), and clipboard (`c`). The default register (`"`), search
/// register (`s`), and macro register (`q`) are intentionally excluded: `q`
/// is written via `Q` recording, not the prefix; the others cannot be named.
pub fn is_valid_register_name(ch: char) -> bool {
    ch.is_ascii_digit()
        || ch == KILL_RING_REGISTER
        || ch == CLIPBOARD_REGISTER
        || ch == BLACK_HOLE_REGISTER
}

/// How a piece of register text pastes: as whole lines, or inline.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Shape {
    Charwise,
    Linewise,
}

/// One selection's text in a register, with the shape it pastes in.
///
/// A yank takes its shape from the selection it came from. Text that did not
/// come from a selection (the OS clipboard, a script, a test) has none
/// recorded, so it converts with [`From`]: linewise when it ends with a `\n`,
/// the only signal such text carries, read after line endings are
/// normalized. The text is always `\r`-free (the same guarantee
/// [`normalize_line_endings`](hume_editing::text::normalize_line_endings)
/// gives `BufferText`), so a register filled from the OS clipboard or a
/// plugin can't smuggle a foreign line ending into a paste or a byte-exact
/// repeat-paste comparison.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Piece {
    text: String,
    shape: Shape,
}

impl Piece {
    pub fn new(text: impl Into<String>, shape: Shape) -> Self {
        Self {
            text: normalize_line_endings_owned(text.into()),
            shape,
        }
    }

    pub fn text(&self) -> &str {
        &self.text
    }

    pub fn shape(&self) -> Shape {
        self.shape
    }

    pub fn is_linewise(&self) -> bool {
        self.shape == Shape::Linewise
    }

    pub fn is_empty(&self) -> bool {
        self.text.is_empty()
    }
}

/// Which value each selection gets when several are pasted at once: one each
/// when there are as many values as selections, otherwise every value joined
/// at every selection.
pub enum Placement<'a, T: Clone> {
    Each(&'a [T]),
    Joined(Cow<'a, T>),
}

impl<'a, T: Clone> Placement<'a, T> {
    /// `join` builds the value every selection gets when the counts differ,
    /// and must return a lone value unchanged: `new` borrows a lone value
    /// without calling it.
    pub fn new(values: &'a [T], selections: usize, join: impl FnOnce(&[T]) -> T) -> Self {
        match values {
            _ if values.len() == selections => Self::Each(values),
            [one] => Self::Joined(Cow::Borrowed(one)),
            _ => Self::Joined(Cow::Owned(join(values))),
        }
    }

    /// The value selection `i` gets; `i` is below the selection count.
    pub fn get(&self, i: usize) -> &T {
        match self {
            Self::Each(values) => &values[i],
            Self::Joined(value) => value,
        }
    }
}

/// A piece compares to text by its text alone, for tests that check what a
/// register holds without naming a shape.
#[cfg(any(test, feature = "test-util"))]
impl PartialEq<&str> for Piece {
    fn eq(&self, other: &&str) -> bool {
        self.text == *other
    }
}

#[cfg(any(test, feature = "test-util"))]
impl PartialEq<String> for Piece {
    fn eq(&self, other: &String) -> bool {
        &self.text == other
    }
}

impl From<String> for Piece {
    fn from(text: String) -> Self {
        let piece = Self::new(text, Shape::Charwise);
        if piece.text.ends_with('\n') {
            Self {
                shape: Shape::Linewise,
                ..piece
            }
        } else {
            piece
        }
    }
}

impl From<&str> for Piece {
    fn from(text: &str) -> Self {
        Self::from(text.to_owned())
    }
}

/// The content of a register: either yanked text or a recorded macro.
///
/// Registers are single-slot: the last write wins. Writing a macro to a register
/// that previously held text replaces it (and vice-versa).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RegisterContent {
    /// Yanked text: one [`Piece`] per selection that was active at yank time,
    /// in document order. A single-cursor yank produces a `Vec` of length 1.
    Text(Vec<Piece>),
    /// A recorded macro: the raw sequence of key events captured during recording.
    Macro(Vec<KeyEvent>),
}

/// One named register.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Register {
    content: RegisterContent,
}

impl Register {
    fn new(content: RegisterContent) -> Self {
        Self { content }
    }

    /// This register's text or macro.
    pub fn content(&self) -> &RegisterContent {
        &self.content
    }

    /// If this register holds text, borrow its pieces. Returns `None` for macro registers.
    ///
    /// Callers that try to paste a macro register get `None` and treat it as a no-op.
    pub fn as_pieces(&self) -> Option<&[Piece]> {
        match &self.content {
            RegisterContent::Text(v) => Some(v),
            RegisterContent::Macro(_) => None,
        }
    }

    /// If this register holds a recorded macro, borrow the key slice. Returns `None` for text registers.
    pub fn as_macro(&self) -> Option<&[KeyEvent]> {
        match &self.content {
            RegisterContent::Macro(keys) => Some(keys),
            RegisterContent::Text(_) => None,
        }
    }
}

/// The full collection of named registers.
///
/// Each register holds a [`RegisterContent`]: either yanked text or a recorded macro.
///
/// Special registers (enforced here):
/// - `BLACK_HOLE_REGISTER` (`'b'`): writes discarded silently; reads return `None`.
///
/// Named registers `'0'`–`'9'` are user storage. Special registers `'c'`
/// (clipboard), `'s'` (search), and `'q'` (macro) are reserved by constants
/// above; their behaviour is wired in the editor layer.
#[derive(Debug, Clone, Default)]
pub struct RegisterSet {
    registers: FxHashMap<char, Register>,
    /// Snapshot of the blob last written to the OS clipboard.
    /// Compared on read to detect external modifications: when the clipboard
    /// content matches this blob the in-memory `'c'` register is in sync and
    /// its pieces (preserving multi-selection boundaries and shapes) are
    /// preferred over the flattened single-string OS clipboard representation.
    clipboard_blob: Option<String>,
}

impl RegisterSet {
    pub fn new() -> Self {
        Self::default()
    }

    /// Look up a register by name.
    ///
    /// Returns `None` for the black-hole register and for any register that has
    /// not been written yet.
    pub fn read(&self, name: char) -> Option<&Register> {
        if name == BLACK_HOLE_REGISTER {
            return None;
        }
        self.registers.get(&name)
    }

    /// Write text to a register, replacing its previous contents. `values`
    /// are [`Piece`]s, or text from outside the selection model, which
    /// converts as [`Piece`]'s `From` impls say.
    ///
    /// Writes to the black-hole register (`'b'`) are silently discarded.
    pub fn write_text<P: Into<Piece>>(&mut self, name: char, values: Vec<P>) {
        let pieces = values.into_iter().map(Into::into).collect();
        self.write(name, RegisterContent::Text(pieces));
    }

    /// Write `values` to the clipboard register and record the flattened
    /// text the OS clipboard should hold, which is returned. Pieces are
    /// separated by a '\n' unless the previous piece's text already ends in
    /// one, whatever its shape.
    pub fn write_clipboard(&mut self, values: Vec<Piece>) -> &str {
        let mut blob = String::new();
        for (i, v) in values.iter().enumerate() {
            if i > 0 && !values[i - 1].text().ends_with('\n') {
                blob.push('\n');
            }
            blob.push_str(v.text());
        }
        self.write_text(CLIPBOARD_REGISTER, values);
        self.clipboard_blob.insert(blob)
    }

    /// Write a recorded macro to a register, replacing its previous contents.
    ///
    /// Writes to the black-hole register (`'b'`) are silently discarded.
    pub fn write_macro(&mut self, name: char, keys: Vec<KeyEvent>) {
        self.write(name, RegisterContent::Macro(keys));
    }

    fn write(&mut self, name: char, content: RegisterContent) {
        if name == BLACK_HOLE_REGISTER {
            return;
        }
        self.registers.insert(name, Register::new(content));
    }

    pub fn clipboard_blob(&self) -> Option<&str> {
        self.clipboard_blob.as_deref()
    }

    /// The last search pattern, or `None` when unset (or when the slot was
    /// overwritten with a macro). Single-source for the `'s'` register's
    /// one-string-in-a-`Vec` encoding; callers deal in `&str`.
    pub fn search_register(&self) -> Option<&str> {
        self.read(SEARCH_REGISTER)
            .and_then(Register::as_pieces)
            .and_then(|v| v.first())
            .map(Piece::text)
    }

    pub fn set_search_register(&mut self, pattern: String) {
        self.write_text(SEARCH_REGISTER, vec![pattern]);
    }
}

/// Bounded ring buffer of deleted / yanked text entries.
///
/// Newest entry is always at index 0 (the "head"). Entries are accessed via
/// `"kp` (head), by cycling with `[`/`]`, or by slot (a bare smart paste
/// resuming from wherever a prior cycle left off). The digit registers
/// `"0`–`"9` are independent in-memory storage, not aliases for ring slots.
/// The ring holds no two equal entries: [`KillRing::push`] moves a
/// re-captured entry to the head instead of duplicating it.
///
/// `cycle` persists until the next paste re-seeds it; a lingering value
/// between sessions is harmless because every fresh paste re-seeds before
/// reading the cursor.
#[derive(Debug, Clone, Default)]
pub struct KillRing {
    /// Entries newest-first; max `KILL_RING_DEPTH` entries.
    entries: VecDeque<Vec<Piece>>,
    /// Active `[`/`]` cycle position.
    /// `Some(n)` = the paste shows slot `n`.
    /// `None` = the paste shows text from outside the ring that is not the
    /// head's (conceptually before slot 0).
    cycle: Option<usize>,
}

/// Maximum number of entries the kill ring retains.
pub(crate) const KILL_RING_DEPTH: usize = 10;

impl KillRing {
    pub fn new() -> Self {
        Self::default()
    }

    /// Push a new entry to the head of the ring, evicting the oldest if full.
    ///
    /// Dedupe: if an equal entry already exists elsewhere in the ring, it is
    /// removed before insertion. Re-capturing the same text moves it to the
    /// head (a recency refresh) rather than taking a second slot. Checked
    /// before the whitespace collapse below: collapsing first would write
    /// `values` into the whitespace head while an equal older entry survived
    /// deeper in the ring, defeating the dedupe.
    ///
    /// Whitespace collapse: when the current head is a *pure whitespace* entry
    /// (every string, every char `is_whitespace`), the new entry overwrites
    /// it in place instead of taking a fresh slot. This keeps from filling the
    /// ring with entries you never want to cycle back to.
    pub fn push<P: Into<Piece>>(&mut self, values: Vec<P>) {
        let values: Vec<Piece> = values.into_iter().map(Into::into).collect();
        if let Some(pos) = self.entries.iter().position(|entry| *entry == values) {
            if pos == 0 {
                return;
            }
            self.entries.remove(pos);
        }
        let head_is_ws = self
            .entries
            .front()
            .is_some_and(|head| entry_is_whitespace(head));
        if head_is_ws && let Some(slot) = self.entries.front_mut() {
            *slot = values;
            return;
        }
        self.entries.push_front(values);
        if self.entries.len() > KILL_RING_DEPTH {
            self.entries.pop_back();
        }
    }

    /// Seed the cycle cursor for a paste read from ring slot `slot`.
    pub fn seed_cycle_at(&mut self, slot: usize) {
        self.cycle = Some(slot);
    }

    /// Seed the cycle cursor for a paste of `pasted` from outside the ring.
    ///
    /// Pieces equal to the head's start the cycle at the head, so the first
    /// `[` steps past the text the paste already shows instead of pasting it
    /// again.
    pub fn seed_cycle_outside(&mut self, pasted: &[Piece]) {
        self.cycle = (self.head() == Some(pasted)).then_some(0);
    }

    /// Borrow the head entry (most recently pushed), if any.
    pub fn head(&self) -> Option<&[Piece]> {
        self.entries.front().map(Vec::as_slice)
    }

    /// Borrow ring slot `n` (0-based), where 0 = head.
    pub fn slot(&self, n: usize) -> Option<&[Piece]> {
        self.entries.get(n).map(Vec::as_slice)
    }

    /// The ring slot the open paste shows, or `None` when it shows text from
    /// outside the ring that is not the head's.
    pub fn cycle_position(&self) -> Option<usize> {
        self.cycle
    }

    /// Advance the cycle cursor one step older and return that entry.
    ///
    /// `None → 0`, `Some(n) → n+1`. Noop (returns `None`, leaves `cycle`
    /// unchanged) when the next slot would be out of bounds or the ring is
    /// empty.
    pub fn cycle_older(&mut self) -> Option<&[Piece]> {
        let next = match self.cycle {
            None => 0,
            Some(n) => n + 1,
        };
        if next >= self.entries.len() {
            return None;
        }
        self.cycle = Some(next);
        self.entries.get(next).map(Vec::as_slice)
    }

    /// Retreat the cycle cursor one step newer and return that entry.
    ///
    /// Noop (returns `None`, leaves `cycle` unchanged) when `cycle` is `None`
    /// or `Some(0)`: there is nowhere newer to go. Otherwise
    /// `Some(n) → Some(n-1)`.
    pub fn cycle_newer(&mut self) -> Option<&[Piece]> {
        let prev = match self.cycle {
            None | Some(0) => return None,
            Some(n) => n - 1,
        };
        self.cycle = Some(prev);
        self.entries.get(prev).map(Vec::as_slice)
    }

    /// Number of entries currently in the ring. Used in tests, including
    /// `hume-editor`'s (a downstream crate); see the `test-util` feature.
    ///
    /// No `is_empty` companion: every test caller checks a specific count
    /// (e.g. depth-capping), never emptiness. `head()` is the actual
    /// production-code check for "is there anything to paste".
    #[cfg(any(test, feature = "test-util"))]
    #[allow(clippy::len_without_is_empty)]
    pub fn len(&self) -> usize {
        self.entries.len()
    }
}

/// Whether a kill-ring entry is pure whitespace: every piece, every char
/// `char::is_whitespace`.
fn entry_is_whitespace(entry: &[Piece]) -> bool {
    entry
        .iter()
        .all(|piece| piece.text().chars().all(char::is_whitespace))
}

#[cfg(test)]
mod tests;
