use super::super::*;
use test_fixtures::assert_state;

// ── Quotes ────────────────────────────────────────────────────────────────

#[test]
fn inner_double_quote_cursor_inside() {
    assert_state!(
        "\"hel-[l]>o\"\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "\"-[hello]>\"\n"
    );
}

#[test]
fn around_double_quote_cursor_inside() {
    // around includes both quote chars; head = closing `"`.
    assert_state!(
        "\"hel-[l]>o\"\n",
        |(text, sels)| cmd_around_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "-[\"hello\"]>\n"
    );
}

#[test]
fn inner_double_quote_cursor_on_open() {
    assert_state!(
        "-[\"]>hello\"\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "\"-[hello]>\"\n"
    );
}

#[test]
fn inner_double_quote_cursor_on_close() {
    assert_state!(
        "\"hello-[\"]>\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "\"-[hello]>\"\n"
    );
}

#[test]
fn inner_double_quote_empty_is_noop() {
    assert_state!(
        "-[\"]>\"foo\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "-[\"]>\"foo\n"
    );
}

#[test]
fn inner_double_quote_second_pair() {
    // Two pairs on the same line: cursor in second pair selects second.
    assert_state!(
        "\"a\" \"b-[c]>\"\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "\"a\" \"-[bc]>\"\n"
    );
}

#[test]
fn inner_single_quote_basic() {
    assert_state!(
        "'hel-[l]>o'\n",
        |(text, sels)| cmd_inner_single_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "'-[hello]>'\n"
    );
}

#[test]
fn inner_backtick_basic() {
    assert_state!(
        "`hel-[l]>o`\n",
        |(text, sels)| cmd_inner_backtick(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "`-[hello]>`\n"
    );
}

#[test]
fn inner_double_quote_not_inside_is_noop() {
    assert_state!(
        "hel-[l]>o\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "hel-[l]>o\n"
    );
}

// ── around_quote variants ─────────────────────────────────────────────────

#[test]
fn around_single_quote_basic() {
    assert_state!(
        "'hel-[l]>o'\n",
        |(text, sels)| cmd_around_single_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "-['hello']>\n"
    );
}

#[test]
fn around_backtick_basic() {
    assert_state!(
        "`hel-[l]>o`\n",
        |(text, sels)| cmd_around_backtick(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "-[`hello`]>\n"
    );
}

#[test]
fn inner_double_quote_starts_after_an_opening_quote_that_carries_a_combining_mark() {
    assert_state!(
        "\"\u{301}-[a]>b\"\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "\"\u{301}-[ab]>\"\n"
    );
}

#[test]
fn inner_double_quote_from_a_quote_joined_to_a_prepend_mark() {
    assert_state!(
        "-[\u{600}\"]>x\"\n",
        |(text, sels)| cmd_inner_double_quote(
            test_fixtures::testing::state(text, sels),
            0,
            MotionMode::Move
        ),
        "\u{600}\"-[x]>\"\n"
    );
}
