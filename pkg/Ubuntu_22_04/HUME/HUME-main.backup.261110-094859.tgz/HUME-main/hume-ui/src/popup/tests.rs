use super::*;
use crate::list_row::SpanScopes;
use hume_engine::types::{ResolvedStyle, ScopeId};
use hume_grid::{Rect, Rgb};
use hume_rope::spanned::SpannedText;

// ── wrap_text ──────────────────────────────────────────────────────────
//
// Production code has no separate `wrap_text`. Plain popup text
// is exactly a single default-style run through `wrap_styled` (see
// `PopupContent::plain`). This local helper keeps that single-style edge-
// case coverage (word boundaries, hard breaks, explicit newlines) without a
// production wrapper.
fn wrap_text(text: &str, max_width: u16) -> Vec<String> {
    wrap_styled([(text, ResolvedStyle::default())], max_width)
        .into_iter()
        .map(|row| row.into_iter().map(|(s, _)| s).collect())
        .collect()
}

#[test]
fn wrap_text_short_line_is_unchanged() {
    assert_eq!(wrap_text("hello", 60), vec!["hello"]);
}

#[test]
fn wrap_text_breaks_on_word_boundary() {
    assert_eq!(wrap_text("hello world foo", 11), vec!["hello world", "foo"]);
}

#[test]
fn wrap_text_preserves_explicit_newlines() {
    assert_eq!(
        wrap_text("line one\nline two", 60),
        vec!["line one", "line two"]
    );
}

#[test]
fn wrap_text_hard_breaks_an_overlong_word() {
    assert_eq!(wrap_text("abcdefghij", 4), vec!["abcd", "efgh", "ij"]);
}

#[test]
fn wrap_text_empty_line_preserved() {
    assert_eq!(wrap_text("a\n\nb", 60), vec!["a", "", "b"]);
}

#[test]
fn wrap_text_keeps_leading_indentation() {
    assert_eq!(
        wrap_text("{\n    let x = 1;\n}", 60),
        vec!["{", "    let x = 1;", "}"]
    );
}

#[test]
fn wrap_text_keeps_indentation_on_the_first_row_only() {
    assert_eq!(wrap_text("  aaa bbb", 6), vec!["  aaa", "bbb"]);
}

#[test]
fn wrap_text_hard_breaks_an_indented_word_after_its_indentation() {
    assert_eq!(wrap_text("    abcdef", 6), vec!["    ab", "cdef"]);
}

// ── wrap_styled ────────────────────────────────────────────────────────

fn red() -> ResolvedStyle {
    ResolvedStyle {
        fg: Some(Rgb(255, 0, 0)),
        ..Default::default()
    }
}

#[test]
fn wrap_styled_preserves_a_style_boundary_within_one_row() {
    let runs = [("hello ", ResolvedStyle::default()), ("world", red())];
    let rows = wrap_styled(runs, 60);
    assert_eq!(rows.len(), 1, "both words fit on one row");
    assert_eq!(
        rows[0],
        vec![
            ("hello".to_string(), ResolvedStyle::default()),
            (" world".to_string(), red()),
        ],
        "the style change must land at the word boundary, not bleed into \
         the plain run or get lost (the synthetic separator space carries \
         the *following* word's style, so it coalesces with \"world\")"
    );
}

#[test]
fn wrap_styled_splits_a_style_change_across_two_wrapped_rows() {
    // "aaaa bbbb" at width 4: "aaaa" and "bbbb" each land on their own row
    // (the too-narrow-for-both-words case `wrap_text_breaks_on_word_boundary`
    // already covers for plain text). Here "bbbb" carries a different style,
    // which must survive onto its own row's run list untouched.
    let runs = [("aaaa ", ResolvedStyle::default()), ("bbbb", red())];
    let rows = wrap_styled(runs, 4);
    assert_eq!(rows.len(), 2);
    assert_eq!(
        rows[0],
        vec![("aaaa".to_string(), ResolvedStyle::default())]
    );
    assert_eq!(rows[1], vec![("bbbb".to_string(), red())]);
}

// ── resolve_popup_geometry ────────────────────────────────────────────

fn rect(x: u16, y: u16, w: u16, h: u16) -> Rect {
    Rect::new(x, y, w, h)
}

#[test]
fn geometry_places_below_cursor_by_default() {
    let pane = rect(0, 0, 40, 20);
    let (x, y, w, h) = resolve_popup_geometry(2, 1, (5, 5), pane);
    assert_eq!((x, y, w, h), (5, 6, 2, 1), "one line below the cursor row");
}

/// Content fits below the anchor even though there happens to be *more*
/// room above than below. It must still place it below. Distinguishes the
/// "fits below" condition from a "prefer whichever side has more room"
/// condition, which would flip it above unnecessarily here.
#[test]
fn geometry_stays_below_when_content_fits_even_with_more_room_above() {
    let pane = rect(0, 0, 40, 100);
    let (_, y, _, _) = resolve_popup_geometry(5, 10, (5, 50), pane);
    assert_eq!(
        y, 51,
        "content (height 10) fits in the 49 rows below: must not flip \
             just because 50 rows happen to be available above"
    );
}

#[test]
fn geometry_flips_above_near_bottom_edge() {
    let pane = rect(0, 0, 40, 20);
    // Cursor near the bottom: only 2 rows below, 17 above, so flip.
    let (_, y, _, _) = resolve_popup_geometry(5, 5, (5, 18), pane);
    assert_eq!(y, 13, "flips to render entirely above the cursor row");
}

#[test]
fn geometry_clamps_horizontally_at_right_edge() {
    let width = hume_rope::width::str_width("a very long popup line here", 0, 1) as u16;
    // Pane wide enough to hold the content, but the anchor sits close
    // enough to the right edge that placing the popup there unclamped
    // would overflow.
    let pane = rect(0, 0, 32, 20);
    let (x, _, w, _) = resolve_popup_geometry(width, 1, (15, 5), pane);
    assert!(
        x + w <= pane.x + pane.width,
        "popup must not cross the pane's right edge, got x={x}, w={w}"
    );
}

#[test]
fn geometry_never_escapes_pane_bounds_even_at_corner() {
    let pane = rect(2, 2, 10, 10);
    let (x, y, w, _) = resolve_popup_geometry(5, 1, (2, 2), pane);
    assert!(x >= pane.x && x + w <= pane.x + pane.width);
    assert!(y >= pane.y && y < pane.y + pane.height);
}

/// A box wider than the pane must be clamped to the pane's width, not
/// merely repositioned. An unclamped over-wide box fails
/// `PopupOverlay`'s bounds check and the whole popup is silently
/// dropped instead of painting a clamped one.
#[test]
fn geometry_clamps_width_to_pane_when_content_is_wider() {
    let pane = rect(0, 0, 20, 20);
    let (x, _, w, _) = resolve_popup_geometry(50, 1, (5, 5), pane);
    assert_eq!(w, 20, "width must clamp to the full pane width");
    assert_eq!(
        x, 0,
        "clamped box has nowhere to go but the pane's left edge"
    );
}

/// Same as above for height: a box taller than a short/split pane must
/// shrink to fit rather than being positioned off-bounds.
#[test]
fn geometry_clamps_height_to_pane_when_content_is_taller() {
    let pane = rect(0, 0, 40, 8);
    let (_, y, _, h) = resolve_popup_geometry(5, 20, (5, 3), pane);
    assert_eq!(h, 8, "height must clamp to the full pane height");
    assert_eq!(
        y, 0,
        "clamped box has nowhere to go but the pane's top edge"
    );
}

// ── resolve_popup / fits_cursor_box ──────────────────────────────────

fn numbered(n: usize) -> PopupContent {
    let text = (0..n)
        .map(|i| format!("line{i}"))
        .collect::<Vec<_>>()
        .join("\n");
    PopupContent::plain(&text)
}

fn cursor_box(content: &PopupContent, pane_height: u16) -> PopupState {
    let pane = rect(0, 0, 80, pane_height);
    let placement = PopupPlacement {
        anchor: (0, 0),
        pane_rect: pane,
        content_width: 80,
    };
    resolve_popup(content, placement, 0, true)
}

/// A third of a 23-row pane is 7 rows, 2 of them the frame.
#[test]
fn cursor_box_on_a_23_row_pane_shows_five_content_rows() {
    assert_eq!(cursor_box(&numbered(30), 23).inner_height(), 5);
}

#[test]
fn fits_cursor_box_agrees_with_what_resolve_popup_shows() {
    for pane_height in [9, 17, 23, 40] {
        for lines in 1..=12 {
            let content = numbered(lines);
            let shown = cursor_box(&content, pane_height).inner_height();
            assert_eq!(
                fits_cursor_box(&content, pane_height, 80),
                lines <= shown,
                "{lines} lines on a {pane_height}-row pane"
            );
        }
    }
}

// ── resolve_menu ──────────────────────────────────────────────────────

fn placement(pane: Rect) -> PopupPlacement {
    PopupPlacement {
        anchor: (0, 0),
        pane_rect: pane,
        content_width: pane.width,
    }
}

/// The two-phase call every production menu makes: resolve the window from
/// counts, slice the list to it, resolve from that slice alone.
fn menu(rows: &[MenuRow], selected: usize, pane: Rect) -> MenuState {
    let window = menu_window(rows.len(), Some(selected), pane);
    resolve_menu(&rows[window.range.clone()], window, placement(pane), true)
}

/// The composed rows' texts, one per line.
fn texts(state: &MenuState) -> String {
    state
        .rows
        .iter()
        .map(ListRow::text)
        .collect::<Vec<_>>()
        .join("\n")
}

/// A candidate scrolled out of the visible window must never widen the
/// box. `menu_window` resolves the window from counts alone and
/// `resolve_menu` only ever receives that window's rows, so the 100-char
/// row 0 below is never even handed to the resolver.
#[test]
fn resolve_menu_width_reflects_only_the_visible_window_not_the_whole_list() {
    let mut rows: Vec<MenuRow> = (0..15)
        .map(|i| MenuRow::plain(ListRow::plain(format!("r{i}"))))
        .collect();
    rows[0] = MenuRow::plain(ListRow::plain("x".repeat(100)));

    // selected = 14 (the last row) centers the window well past the wide
    // row 0: window_range(15, 14 - 10/2 = 9, 10) clamps to [5, 15).
    let window = menu_window(rows.len(), Some(14), rect(0, 0, 200, 50));
    assert_eq!(window.range, 5..15, "sanity: the wide row 0 is outside");
    let state = menu(&rows, 14, rect(0, 0, 200, 50));
    assert_eq!(
        state.rect.width, 5,
        "widest *visible* row is \"r10\"..\"r14\" (3 chars) + the 2-cell frame, \
         not the 100-char row scrolled out of view"
    );
}

/// With nothing picked the window starts at the top and highlights no row.
#[test]
fn menu_window_with_no_selection_starts_at_the_top_and_highlights_nothing() {
    let window = menu_window(15, None, rect(0, 0, 200, 50));
    assert_eq!(window.range, 0..10);
    assert_eq!(window.selected_rel, None);
}

/// The contract's own tripwire: handing `resolve_menu` anything other than
/// the window's exact slice (here, the whole list) is a caller bug, caught
/// in debug builds rather than silently measured.
#[test]
#[cfg(debug_assertions)]
#[should_panic(expected = "must be the window's own slice")]
fn resolve_menu_rejects_rows_that_are_not_the_windows_slice() {
    let rows: Vec<MenuRow> = (0..15)
        .map(|i| MenuRow::plain(ListRow::plain(format!("r{i}"))))
        .collect();
    let pane = rect(0, 0, 200, 50);
    let window = menu_window(rows.len(), Some(0), pane);
    resolve_menu(&rows, window, placement(pane), true);
}

/// Two-column composition: `trailing` right-aligned flush against the
/// widest of it in the window, `main` left-aligned and padded to the
/// widest of it: an exact fit, no truncation.
#[test]
fn resolve_menu_right_aligns_trailing_when_it_fits() {
    let rows = vec![
        MenuRow {
            main: ListRow::plain("kitty_support".into()),
            trailing: Some("bool".into()),
        },
        MenuRow {
            main: ListRow::plain("kind".into()),
            trailing: Some("Kind".into()),
        },
    ];
    let state = menu(&rows, 0, rect(0, 0, 200, 50));
    // main padded to the widest main ("kitty_support", 13), a 2-cell gap,
    // then trailing right-aligned to the widest trailing (4).
    insta::assert_snapshot!(texts(&state), @r"
    kitty_support  bool
    kind           Kind
    ");
}

/// A pane too narrow for both columns truncates `trailing` with an
/// ellipsis rather than pushing the box past the pane clamp.
#[test]
fn resolve_menu_truncates_trailing_when_the_pane_is_too_narrow() {
    let rows = vec![MenuRow {
        main: ListRow::plain("assert!".into()),
        trailing: Some("macro_rules! assert".into()),
    }];
    // max_inner = pane.width - 2 = 10; main_col = 7 ("assert!"); trail_col
    // = min(19, 10 - 7 - 2) = 1, just enough for the ellipsis marker.
    let state = menu(&rows, 0, rect(0, 0, 12, 50));
    insta::assert_snapshot!(texts(&state), @"assert!  …");
}

/// When there's no room left for a trailing column at all (`trail_col`
/// clamps to 0), every row's trailing part is dropped uniformly, never a
/// half-truncated fragment with no gap before it.
#[test]
fn resolve_menu_drops_trailing_entirely_when_no_room_is_left() {
    let rows = vec![MenuRow {
        main: ListRow::plain("ab".into()),
        trailing: Some("xy".into()),
    }];
    // max_inner = pane.width - 2 = 2, all consumed by `main` alone.
    let state = menu(&rows, 0, rect(0, 0, 4, 50));
    insta::assert_snapshot!(texts(&state), @"ab");
}

/// A styled main column cut to a narrow pane keeps the part of its span the
/// cut leaves, and the trailing column joins it unstyled.
#[test]
fn resolve_menu_cuts_a_styled_main_column_keeping_its_span_on_what_survives() {
    let scope = ScopeId(7);
    let scopes = SpanScopes {
        scope,
        selected: None,
    };
    let main = SpannedText::new("abcdefgh".to_string(), vec![(2, 8, scopes)]).unwrap();
    let rows = vec![MenuRow {
        main: ListRow::styled(main),
        trailing: Some("xy".into()),
    }];
    // max_inner = 8; trailing needs 2 + the 2-cell gap, so `main` gets the
    // whole width first and the trailing column none.
    let state = menu(&rows, 0, rect(0, 0, 8, 50));
    insta::assert_snapshot!(texts(&state), @"abcde…");
    let expected = SpannedText::new("abcde…".to_string(), vec![(2, 5, scopes)]).unwrap();
    assert_eq!(state.rows, vec![ListRow::styled(expected)]);
}

/// A session narrowed to zero matches must not panic computing `selected`
/// against an empty list. This is a real path (`sync_completion_menu_view` calls
/// `menu_window`/`resolve_menu` unconditionally, whether or not the filter
/// matched anything).
#[test]
fn resolve_menu_on_an_empty_list_does_not_panic() {
    let state = menu(&[], 0, rect(0, 0, 40, 20));
    assert!(state.rows.is_empty());
    assert_eq!(state.selected, None);
}

// ── band_visible_rows ─────────────────────────────────────────────────

/// The overflow-safety guard on the shared arithmetic itself lives in
/// `menu_box::tests` (`band_capacity_clamps_instead_of_overflowing_u16`);
/// this pins the popup band's own 2-row frame against it instead of
/// re-testing the arithmetic.
#[test]
fn band_visible_rows_reserves_the_frame_row_pair_below_the_cap() {
    assert_eq!(
        band_visible_rows(3, 20),
        3,
        "well under the cap: all 3 lines fit"
    );
}

// ── Side popup ───────────────────────────────────────────────────────────────

/// `beside` sits below its anchor row, as a menu opening downward does.
fn side(text: &str, beside: Rect, pane: Rect) -> Option<PopupState> {
    let slot = side_slot(beside, beside.y.saturating_sub(1), pane)?;
    Some(resolve_side_popup(
        &PopupContent::plain(text),
        &slot,
        0,
        true,
    ))
}

#[test]
fn side_popup_beside_a_box_above_its_anchor_grows_upward_from_its_bottom_edge() {
    let text = (0..12)
        .map(|i| format!("line {i}"))
        .collect::<Vec<_>>()
        .join("\n");
    let beside = rect(10, 10, 20, 6);
    let anchor_row = beside.bottom();
    let slot = side_slot(beside, anchor_row, rect(0, 0, 80, 24)).expect("room on the right");
    let state = resolve_side_popup(&PopupContent::plain(&text), &slot, 0, true);
    assert_eq!(state.rect.bottom(), beside.bottom());
    assert_eq!(
        state.rect.height, 8,
        "a third of the pane, taller than the box"
    );
}

#[test]
fn side_popup_sits_right_of_the_box_with_its_top_edge_level() {
    let state =
        side("hello world", rect(10, 5, 20, 6), rect(0, 0, 80, 24)).expect("room on the right");
    assert_eq!(state.rect, rect(30, 5, 13, 3));
}

#[test]
fn side_popup_flips_left_when_the_right_is_too_narrow() {
    let state =
        side("hello world", rect(50, 5, 25, 6), rect(0, 0, 80, 24)).expect("room on the left");
    assert_eq!(state.rect, rect(37, 5, 13, 3));
}

#[test]
fn side_popup_is_absent_when_neither_side_has_room() {
    assert_eq!(side_slot(rect(12, 5, 20, 6), 4, rect(0, 0, 40, 24)), None);
}

#[test]
fn side_popup_wraps_to_the_room_beside_the_box() {
    let text = "word ".repeat(20);
    let state = side(&text, rect(0, 0, 55, 6), rect(0, 0, 80, 24)).expect("25 cells on the right");
    assert_eq!(state.rect.x, 55);
    assert!(
        state.rect.width <= 25,
        "width {} exceeds the room",
        state.rect.width
    );
    assert!(
        state.rows.total_rows > 1,
        "the text wraps instead of overflowing"
    );
}

#[test]
fn side_popup_width_caps_at_120_cells_in_a_wide_pane() {
    let text = "x".repeat(300);
    let state = side(&text, rect(0, 0, 20, 6), rect(0, 0, 300, 40)).expect("room on the right");
    assert_eq!(state.rect.width, 120);
}

#[test]
fn side_popup_height_stops_at_the_pane_bottom() {
    let text = "line\n".repeat(10);
    let state = side(&text, rect(0, 8, 20, 4), rect(0, 0, 80, 12)).expect("room on the right");
    assert_eq!(state.rect.y, 8);
    assert_eq!(state.rect.bottom(), 12);
    assert_eq!(state.rows.visible, 0..2);
}
