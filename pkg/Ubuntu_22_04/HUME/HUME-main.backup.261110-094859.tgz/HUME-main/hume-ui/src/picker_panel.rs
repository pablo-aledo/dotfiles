//! Centered fuzzy-picker panel: bordered box with a query input line on
//! top and a ranked, scrolling item list below.
//!
//! A sibling of [`super::menu_box`], not built on it: this
//! panel is a *fixed-size* box (sized as a fraction of the panes region,
//! independent of item count) with a two-zone layout (input row + list) and
//! an edge-anchored scroll model owned by `PickerSession`. `menu_box`'s
//! selected-row window centers the selection instead, a different and
//! conflicting scroll model. What it shares with the other lists is the
//! border (`super::menu_box::draw_box_border`) and its rows: a
//! [`ListRow`] each, cut by the write side and painted by `draw_row`, as
//! the drawer's and a menu's are.
//!
//! Write side (`Editor::sync_picker_view`) resolves geometry once per
//! frame against the current panes region and writes a [`PickerViewState`]
//! snapshot; `PickerOverlay` only paints it, the same split as
//! `super::popup::PopupOverlay`.
//!
use std::sync::Arc;

use hume_engine::types::ResolvedStyle;
use hume_grid::Rect;

use hume_engine::lock::SharedSlot;

use hume_engine::providers::OverlayProvider;
use hume_engine::render::Canvas;
use hume_engine::theme::Theme;
use hume_engine::theme::ui_scopes;
use hume_engine::types::Scope;
use hume_rope::width::{chrome_width, truncate_suffix_to_width, truncate_to_width};

use super::list_row::{ListRow, draw_row};

/// Maximum panel width/height in terminal cells, before the pane-fraction
/// clamp. Mirrors `MAX_POPUP_WIDTH`'s role for the popup widget.
const MAX_PANEL_WIDTH: u16 = 100;
const MAX_PANEL_HEIGHT: u16 = 30;

/// Smallest panel `panel_geometry`/`draw_picker_panel` will paint into: a
/// single shared bound so the two can't drift on what counts as "too small
/// to render" (one place returned `None`, the other painted a truncated box
/// for the same input).
const MIN_PANEL_WIDTH: u16 = 3;
const MIN_PANEL_HEIGHT: u16 = 4;

/// Rows the border and input line always claim: the top border, the input
/// row, and the bottom border. Subtracted from the outer height once, in
/// `panel_geometry`, to produce `PanelGeometry::list_rows`, so the
/// row budget a keystroke pages against and the one a frame paints
/// (`PickerViewState::list_rows`, carried from the same call) are the same
/// number rather than two derivations that have to agree.
const CHROME_ROWS: u16 = 3;

/// Fully-resolved panel content and position, computed once per frame by
/// the write side (`Editor::sync_picker_view`); the overlay only paints.
pub struct PickerViewState {
    /// Label painted before the query on the input row, e.g. `"files: "`.
    /// Empty by default, which takes no cells: the query starts at the
    /// row's left edge. Not yet width-clipped (a paint-time concern, same as
    /// `query`).
    pub prompt: String,
    /// Raw query text (not yet tail-truncated; that's a paint-time
    /// concern, so this snapshot stays a dumb value, not pre-formatted UI).
    pub query: String,
    /// The rows of the current scroll window, in ranked order, already
    /// scrolled and cut to the list width; the widget never re-windows. A
    /// `#:render` row is shared with the item it shows, and is `None`, which
    /// paints blank, until rendered; any other row is the item's display,
    /// cut for this frame.
    pub rows: Vec<Option<Arc<ListRow>>>,
    /// On-screen index into `rows` of the selected row (`selected - scroll`
    /// from the store); `None` when `rows` is empty.
    pub selected_row: Option<usize>,
    /// `PickerSession::matched_len` / `total_len`, rendered as a
    /// right-aligned `"matched/total"` counter on the input row.
    pub matched: usize,
    pub total: usize,
    /// `PickerSession::is_pending`: appends a "still arriving" marker to
    /// the counter so a picker opened empty (`spawn-async!`-backed, or a
    /// live `picker-source-spawn!` source) doesn't read as "zero results"
    /// while its job is still running.
    pub pending: bool,
    /// Outer footprint (including the 1-cell frame), centered in the panes
    /// region this same frame.
    pub rect: Rect,
    /// `PanelGeometry::list_rows` from the same `panel_geometry` call that
    /// produced `rect`, carried alongside it rather than re-subtracted
    /// from `rect.height` at paint time, so the row budget a keystroke
    /// paged against and the one a frame paints can never drift apart.
    pub list_rows: usize,
    /// Fed from the `popup-border` setting, same as popup/menu/drawer.
    pub border: bool,
}

/// Resolved panel geometry: the single source of truth shared by the write
/// side (`sync_picker_view`, sizing the paint) and the input-handling side
/// (`Editor::picker_input`, sizing `move_selection`'s `visible_rows`). Both
/// call this against the pane area of the editor's current screen layout,
/// so a keystroke and the next paint agree on how many rows are visible.
pub struct PanelGeometry {
    pub rect: Rect,
    /// Inner list capacity: outer height minus `CHROME_ROWS`.
    pub list_rows: usize,
}

impl PanelGeometry {
    /// Cells one list row gets: the inner width `draw_picker_panel` paints
    /// rows into, whether or not the border is drawn.
    pub fn list_width(&self) -> usize {
        inner_area(self.rect).width as usize
    }
}

/// The panel's area inside its frame: the input line, then the list.
fn inner_area(outer: Rect) -> Rect {
    outer.inset(super::menu_box::FRAME_EDGE, super::menu_box::FRAME_EDGE)
}

/// Size the panel as a fraction of `pane_area` (width `min(80%, 100 cols)`,
/// height `min(60%, 30 rows)`), then center it. Returns `None` when the
/// region can't host a viable panel (narrower than `MIN_PANEL_WIDTH` or
/// shorter than `MIN_PANEL_HEIGHT`, i.e. not even one list row). Callers
/// then paint nothing rather than a degenerate box.
pub fn panel_geometry(pane_area: Rect) -> Option<PanelGeometry> {
    let width = ((pane_area.width as u32 * 80 / 100) as u16)
        .min(MAX_PANEL_WIDTH)
        .min(pane_area.width);
    let height = ((pane_area.height as u32 * 60 / 100) as u16)
        .min(MAX_PANEL_HEIGHT)
        .min(pane_area.height);
    if width < MIN_PANEL_WIDTH || height < MIN_PANEL_HEIGHT {
        return None;
    }
    Some(PanelGeometry {
        rect: pane_area.centered(width, height),
        list_rows: (height - CHROME_ROWS) as usize,
    })
}

/// Resolved styles for the picker body. These are Helix's own picker scopes, not a
/// HUME invention: `ui.background` (panel fill), `ui.text` (border/rows/
/// query), `ui.text.focus` (the selected row, which Helix's docs call "the
/// currently selected line in the picker"), `ui.cursor.primary` (query block
/// cursor). `Theme::resolve_raw`'s prefix-trim already degrades each of
/// these to `default` when a theme omits it, so no custom fallback layer is
/// needed here.
#[derive(Clone, Copy)]
pub(in crate::picker_panel) struct PickerStyles {
    pub background: ResolvedStyle,
    pub text: ResolvedStyle,
    pub selected: ResolvedStyle,
    pub cursor: ResolvedStyle,
}

pub(in crate::picker_panel) fn picker_styles(theme: &Theme) -> PickerStyles {
    let by = |name| theme.resolve_by_name(Scope(name));
    PickerStyles {
        background: by(ui_scopes::BACKGROUND),
        text: by(ui_scopes::TEXT),
        selected: by(ui_scopes::TEXT_FOCUS),
        cursor: by(hume_engine::theme::CURSOR_PRIMARY),
    }
}

/// Paint the panel into `state`'s resolved outer rect. Pure function of its
/// arguments (styles pre-resolved by the caller, mirroring
/// `draw_menu_box`'s shape). Safe to call once per pane per frame even
/// though the overlay loop hands every pane the same whole-panes-region
/// rect (`hume-engine/src/pipeline/mod.rs`'s "may span panes" overlay pass).
///
/// Layout: row 0 inside the frame is the input line (query tail, a block
/// cursor cell at the end styled `ui.cursor.primary`, and a right-aligned
/// `matched/total` counter when it fits); the remaining rows are `state.rows`, with
/// `state.selected_row` highlighted across the full inner width. `rows` is
/// never re-windowed here: the store already scrolled it.
pub(in crate::picker_panel) fn draw_picker_panel(
    canvas: &mut Canvas,
    state: &PickerViewState,
    styles: PickerStyles,
    theme: &Theme,
) {
    let outer = state.rect;
    if outer.width < MIN_PANEL_WIDTH || outer.height < MIN_PANEL_HEIGHT {
        return;
    }

    // `styles.background` (`ui.background`) is bg-only by Helix convention
    // (see `PickerStyles`'s own doc): layering `text` under it gives the
    // panel's blank cells a concrete fg too, which a reversed-only cursor
    // cell written over them needs to swap against.
    canvas.fill_rect_bg(outer, styles.text.layer(styles.background));

    if state.border {
        super::menu_box::draw_box_border(canvas, outer, styles.text);
    }

    let inner = inner_area(outer);
    let inner_x = inner.x;
    let inner_width = inner.width as usize;
    // One bound for every text write below: the panel's inner right edge.
    // Each string is already truncated to fit, so this is a backstop that
    // keeps a mis-sized one inside the border instead of over it.
    let inner_right = inner.right();
    let input_y = inner.y;

    let counts = if state.pending {
        format!("{}/{} …", state.matched, state.total)
    } else {
        format!("{}/{}", state.matched, state.total)
    };
    let counts_width = chrome_width(&counts);

    // Clip the prompt itself only in the pathological case where it alone
    // exceeds the inner width. The common case (empty or a short label)
    // leaves this a no-op, so an empty prompt renders identically to no
    // prompt at all. The readable prefix matters more than the tail for a
    // fixed label, so this keeps the *head* (unlike the query's own
    // tail-truncation below).
    let (prompt_shown, prompt_width) = truncate_to_width(&state.prompt, inner_width);
    if prompt_width > 0 {
        canvas.write_text_run(inner_x, input_y, prompt_shown, styles.text, inner_right);
    }

    let after_prompt_width = inner_width.saturating_sub(prompt_width);
    // Reserve 1 col for the cursor cell + 1 col of gap before the counter.
    let show_counts = after_prompt_width >= counts_width + 2;
    let query_budget = if show_counts {
        after_prompt_width - counts_width - 2
    } else {
        after_prompt_width.saturating_sub(1)
    };
    // Remove leading graphemes until the query fits `query_budget`, keeping
    // the *tail*, so the cursor cell (always at the end of the query, per
    // the store's append/pop-at-end-only editing model) stays visible.
    let (query_tail, query_width) = truncate_suffix_to_width(&state.query, query_budget);

    let query_x = inner_x + prompt_width as u16;
    canvas.write_text_run(query_x, input_y, query_tail, styles.text, inner_right);
    let cursor_x = query_x + query_width as u16;
    if cursor_x < inner_right {
        canvas.write_text_run(cursor_x, input_y, " ", styles.cursor, inner_right);
    }
    if show_counts {
        let counts_x = inner.right() - counts_width as u16;
        canvas.write_text_run(counts_x, input_y, &counts, styles.text, inner_right);
    }

    for (i, row) in state.rows.iter().take(state.list_rows).enumerate() {
        // Row 0 of `inner` is the input line (`input_y`); the list starts on
        // the row below it.
        let y = inner.y + 1 + i as u16;
        draw_row(
            canvas,
            Rect::new(inner_x, y, inner.width, 1),
            row.as_deref(),
            theme,
            state.selected_row == Some(i),
            styles.selected,
            styles.text,
        );
    }
}

/// Overlay provider painting the picker panel, last in
/// [`OverlayViews::overlays`](super::OverlayViews::overlays) so it sits above
/// every other overlay: the picker is full-modal.
pub(crate) struct PickerOverlay {
    pub(crate) data: SharedSlot<Option<PickerViewState>>,
}

impl OverlayProvider for PickerOverlay {
    fn is_active(&self) -> bool {
        self.data.read().is_some()
    }

    fn render(&self, theme: &Theme, canvas: &mut Canvas) {
        let guard = self.data.read();
        let Some(state) = guard.as_ref() else {
            return;
        };

        let styles = picker_styles(theme);
        draw_picker_panel(canvas, state, styles, theme);
    }
}

#[cfg(test)]
mod tests;
