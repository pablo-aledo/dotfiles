use super::super::symbols_in;
use super::*;
use crate::list_row::SpanScopes;
use hume_engine::theme::{ScopeRegistry, Theme};
use hume_engine::types::{Modifiers, ResolvedStyle, ScopeId};
use hume_grid::{Grid, Rect};
use hume_rope::spanned::SpannedText;

fn list_rows(texts: &[String]) -> Vec<ListRow> {
    texts.iter().cloned().map(ListRow::plain).collect()
}

fn rows(n: usize) -> Vec<String> {
    (0..n).map(|i| format!("item{i}")).collect()
}

fn style() -> ResolvedStyle {
    ResolvedStyle::default()
}

fn styles() -> MenuBoxStyles {
    MenuBoxStyles {
        base: style(),
        scroll: style(),
    }
}

#[test]
fn a_row_wider_than_the_box_is_clipped_at_the_border() {
    // Rows reach `draw_menu_box` untruncated: the box was sized to the
    // widest of them, then clamped to the pane it has to fit inside (see
    // `resolve_popup_geometry`), so a long LSP label on a narrow terminal is
    // wider than the box it lands in. It must stop at the inner edge: the
    // right border has to survive, and nothing may be written past it.
    let mut buf = Grid::new(20, 5);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    let outer = Rect::new(2, 0, 8, 3); // inner text spans x 3..9
    let long = vec!["abcdefghij".to_string()];
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::List {
            rows: &list_rows(&long),
            selected: Some(0),
            selected_style: style(),
            theme: &theme,
        },
        1,
        0,
        true,
        styles(),
    );

    // The row fills the inner width and stops; the border stands and the
    // cells beyond it are untouched.
    insta::assert_snapshot!(symbols_in(&buf, Rect::new(0, 1, 20, 1)), @"  │abcdef│");
}

#[test]
fn draw_menu_box_border_frame_snapshot() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    let outer = Rect::new(2, 3, 8, 4);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::List {
            rows: &list_rows(&rows(2)),
            selected: Some(0),
            selected_style: style(),
            theme: &theme,
        },
        2,
        0,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌──────┐
    │item0 │
    │item1 │
    └──────┘
    ");
}

#[test]
fn draw_menu_box_no_border_leaves_plain_margin() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    let outer = Rect::new(2, 3, 8, 4);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::List {
            rows: &list_rows(&rows(2)),
            selected: Some(0),
            selected_style: style(),
            theme: &theme,
        },
        2,
        0,
        false,
        styles(),
    );

    // Corners stay background-filled space, never a box-drawing glyph.
    insta::assert_snapshot!(symbols_in(&buf, outer), @"

    item0
    item1
    ");
}

/// Windowing is the write side's job (`resolve_menu`/`resolve_popup`, via
/// `window_range`), not `draw_menu_box`'s. This test pre-slices `rows` the
/// same way a caller must, and checks `draw_menu_box` paints exactly that
/// slice, not the full list.
#[test]
fn draw_menu_box_scrolls_to_keep_selected_visible() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Inner height 3 (outer height 5), 10 rows total, selected near the end.
    let outer = Rect::new(0, 0, 10, 5);
    let data = rows(10);
    // Window of size 3 anchored so index 9 is visible: start = 9 - 1 = 8,
    // clamped to total-max = 7 → window [7, 10) = item7,item8,item9.
    let range = window_range(10, 8, 3);
    assert_eq!(range, 7..10, "sanity: window lands where the comment says");
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::List {
            rows: &list_rows(&data[range.clone()]),
            selected: Some(9 - range.start),
            selected_style: style(),
            theme: &theme,
        },
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item7   │
    │item8   │
    │item9   ┃
    └────────┘
    ");
}

/// Unlike a menu (which windows around `selected`), a plain popup
/// (`selected: None`) windows from `scroll` directly. This is what makes
/// `Ctrl-u`/`Ctrl-d` page a scrollable hover popup instead of the window
/// always anchoring back to row 0.
#[test]
fn draw_menu_box_scroll_windows_from_offset_when_no_selection() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Inner height 3 (outer height 5), 10 rows total, scrolled to row 4.
    let outer = Rect::new(0, 0, 10, 5);
    let data = rows(10);
    let range = window_range(10, 4, 3);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::Plain(&data[range.clone()]),
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item4   │
    │item5   ┃
    │item6   │
    └────────┘
    ");
}

#[test]
fn draw_menu_box_shows_scrollbar_thumb_at_top_when_scrolled_to_top() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Inner height 3, 10 rows total, scroll = 0: thumb flush at the top.
    let outer = Rect::new(0, 0, 10, 5);
    let data = rows(10);
    let range = window_range(10, 0, 3);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::Plain(&data[range.clone()]),
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item0   ┃
    │item1   │
    │item2   │
    └────────┘
    ");
}

#[test]
fn draw_menu_box_shows_scrollbar_thumb_in_the_middle_when_scrolled_to_the_middle() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Inner height 3, 10 rows total, scroll = 4: thumb centered.
    let outer = Rect::new(0, 0, 10, 5);
    let data = rows(10);
    let range = window_range(10, 4, 3);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::Plain(&data[range.clone()]),
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item4   │
    │item5   ┃
    │item6   │
    └────────┘
    ");
}

#[test]
fn draw_menu_box_shows_scrollbar_thumb_at_bottom_when_scrolled_to_bottom() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Inner height 3, 10 rows total, scroll = 7 (max_scroll): thumb flush at the bottom.
    let outer = Rect::new(0, 0, 10, 5);
    let data = rows(10);
    let range = window_range(10, 7, 3);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::Plain(&data[range.clone()]),
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item7   │
    │item8   │
    │item9   ┃
    └────────┘
    ");
}

/// `inner_h == 1` (`outer.height == 3`): the thumb has nowhere to move, so
/// `scrollbar_thumb` degenerates to a single full-height thumb regardless of
/// `scroll`, still distinguishing "more to scroll" from "nothing to scroll".
#[test]
fn draw_menu_box_single_row_window_shows_a_solid_thumb() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Inner height 1, 10 rows total, scroll = 4 (mid-range).
    let outer = Rect::new(0, 0, 10, 3);
    let data = rows(10);
    let range = window_range(10, 4, 1);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::Plain(&data[range.clone()]),
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item4   ┃
    └────────┘
    ");
}

#[test]
fn draw_menu_box_no_overflow_shows_no_scrollbar() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // 2 rows fit entirely inside inner height 3, so there is nothing to scroll.
    let outer = Rect::new(0, 0, 10, 5);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::Plain(&rows(2)),
        2,
        0,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item0   │
    │item1   │
    │        │
    └────────┘
    ");
}

#[test]
fn draw_menu_box_scrolled_menu_shows_scrollbar_thumb() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Same overflowing case as the middle-scroll test above, but with a
    // selection (a menu): the highlight signals *which* row, the thumb
    // signals how much more there is to scroll past; both show together.
    let outer = Rect::new(0, 0, 10, 5);
    let data = rows(10);
    let range = window_range(10, 5usize.saturating_sub(3 / 2), 3);
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::List {
            rows: &list_rows(&data[range.clone()]),
            selected: Some(5 - range.start),
            selected_style: style(),
            theme: &theme,
        },
        10,
        range.start,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, outer), @"
    ┌────────┐
    │item4   │
    │item5   ┃
    │item6   │
    └────────┘
    ");
}

#[test]
fn widest_is_the_widest_texts_display_width() {
    assert_eq!(widest(["a", "abc", "ab"].into_iter()), 3);
}

#[test]
fn widest_of_an_empty_run_is_zero() {
    assert_eq!(widest(std::iter::empty::<&str>()), 0);
}

// ── band_capacity ──────────────────────────────────────────────────────

/// A terminal whose band ceiling, 35% of its height, is 20 rows.
const HEIGHT_WITH_CEILING_20: u16 = 58;

/// `band_capacity` adds in `usize`, saturating, and clamps to the ceiling
/// before narrowing to `u16`, so a row count at or past `u16::MAX` cannot
/// wrap to a near-zero `u16`.
#[test]
fn band_capacity_clamps_instead_of_overflowing_u16() {
    assert_eq!(band_capacity(65_535, 1, HEIGHT_WITH_CEILING_20), 20);
    assert_eq!(band_capacity(usize::MAX, 1, HEIGHT_WITH_CEILING_20), 20);
    assert_eq!(band_capacity(65_535, 2, HEIGHT_WITH_CEILING_20), 20);
    assert_eq!(band_capacity(usize::MAX, 2, HEIGHT_WITH_CEILING_20), 20);
}

#[test]
fn band_capacity_reserves_chrome_rows_below_the_cap() {
    assert_eq!(band_capacity(3, 1, HEIGHT_WITH_CEILING_20), 4);
    assert_eq!(band_capacity(3, 2, HEIGHT_WITH_CEILING_20), 5);
}

#[test]
fn band_visible_rows_is_band_capacity_minus_chrome() {
    assert_eq!(band_visible_rows(3, 1, HEIGHT_WITH_CEILING_20), 3);
    assert_eq!(band_visible_rows(3, 2, HEIGHT_WITH_CEILING_20), 3);
    assert_eq!(band_visible_rows(usize::MAX, 2, HEIGHT_WITH_CEILING_20), 18);
}

// ── clamp_scroll_to_window ───────────────────────────────────────────────
//
// A list shrinking out from under a stale, deep `scroll` is
// *not* covered here: this function only keeps `selected` in view, and does
// not know the list's own length (see its own doc). That case is
// `EditorState::clamp_drawer_scroll_to_terminal`'s own test, in
// `hume-editor/src/editor/input_stack/drawer.rs`.

#[test]
fn clamp_scroll_to_window_keeps_ordinary_behavior() {
    assert_eq!(clamp_scroll_to_window(4, 0, 10), 0);
    assert_eq!(clamp_scroll_to_window(15, 0, 10), 6);
    assert_eq!(clamp_scroll_to_window(2, 5, 10), 2);
}

#[test]
fn clamp_scroll_to_window_is_a_noop_with_no_visible_rows() {
    assert_eq!(clamp_scroll_to_window(4, 12, 0), 12);
}

#[test]
fn draw_menu_box_too_small_outer_does_nothing() {
    let mut buf = Grid::new(20, 20);
    let before = buf.clone();
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    draw_menu_box(
        &mut canvas,
        Rect::new(0, 0, 2, 2),
        BoxRows::List {
            rows: &list_rows(&rows(1)),
            selected: Some(0),
            selected_style: style(),
            theme: &theme,
        },
        1,
        0,
        true,
        styles(),
    );
    assert_eq!(buf, before, "sub-3x3 outer must not panic or paint");
}

// scrollbar_thumb: pure geometry, independent of the painter

#[test]
fn scrollbar_thumb_none_when_content_fits() {
    assert_eq!(scrollbar_thumb(3, 3, 0), None);
    assert_eq!(scrollbar_thumb(5, 3, 0), None);
}

#[test]
fn scrollbar_thumb_some_the_moment_content_overflows() {
    assert!(scrollbar_thumb(3, 4, 0).is_some());
}

#[test]
fn scrollbar_thumb_flush_top_at_scroll_zero() {
    let (start, _) = scrollbar_thumb(3, 10, 0).expect("overflowing");
    assert_eq!(start, 0);
}

#[test]
fn scrollbar_thumb_flush_bottom_at_max_scroll() {
    let (start, len) = scrollbar_thumb(3, 10, 7).expect("overflowing");
    assert_eq!(
        start + len,
        3,
        "thumb's bottom edge must touch the track's bottom edge"
    );
}

/// The `scroll > 0` nudge keeps floor division from leaving the thumb at the
/// same start as `scroll == 0` here, which reads as "haven't scrolled at all".
#[test]
fn scrollbar_thumb_moves_off_the_top_after_one_line_of_scroll() {
    let (start_at_zero, _) = scrollbar_thumb(3, 100, 0).expect("overflowing");
    let (start_at_one, _) = scrollbar_thumb(3, 100, 1).expect("overflowing");
    assert_eq!(start_at_zero, 0);
    assert_ne!(start_at_one, start_at_zero);
}

#[test]
fn scrollbar_thumb_length_is_proportional_and_leaves_track_visible() {
    let (_, len) = scrollbar_thumb(3, 4, 0).expect("overflowing");
    assert_eq!(
        len, 2,
        "3 of 4 rows visible must not fill the whole 3-cell track"
    );
}

/// The `(view*view).div_ceil(total)` proportional term drives the thumb
/// length below the `(view-1).max(1)` clamp. The test above
/// (`view=3,total=4`) reaches only the clamp: its ratio term (`ceil(9/4)=3`)
/// clamps down to 2. The hand-computed lengths here land below the clamp
/// ceiling.
#[test]
fn scrollbar_thumb_length_scales_with_visible_fraction_not_just_the_clamp() {
    let (_, len_10_of_100) = scrollbar_thumb(10, 100, 0).expect("overflowing");
    assert_eq!(
        len_10_of_100, 1,
        "10 of 100 rows visible: ceil(10*10/100)=1, near-minimal"
    );

    let (_, len_10_of_20) = scrollbar_thumb(10, 20, 0).expect("overflowing");
    assert_eq!(
        len_10_of_20, 5,
        "10 of 20 rows visible (half): ceil(10*10/20)=5, about half the track"
    );

    assert!(
        len_10_of_20 > len_10_of_100,
        "a larger visible fraction (10/20) must give a longer thumb than a \
         smaller one (10/100); proves length scales with the fraction \
         rather than being pinned to the view-1 clamp ceiling (which would \
         give 9 for both)"
    );
}

#[test]
fn scrollbar_thumb_single_row_window_is_a_solid_cell() {
    assert_eq!(scrollbar_thumb(1, 10, 0), Some((0, 1)));
    assert_eq!(scrollbar_thumb(1, 10, 9), Some((0, 1)));
}

/// A caller that hands more rows than the box's inner height fits (a
/// pre-windowing bug, since production always slices to `window_range`
/// first) must not paint past the box: the vertical twin of
/// `a_row_wider_than_the_box_is_clipped_at_the_border`. The bottom border
/// row, and everything below the box, must survive untouched.
#[test]
fn draw_menu_box_clips_extra_rows_at_the_bottom_border() {
    let mut buf = Grid::new(20, 20);
    let theme = Theme::default();
    let mut canvas = Canvas::new(&mut buf, theme.ui.invisible, None);
    // Outer height 5 → inner height 3, but 5 rows are handed in unwindowed.
    let outer = Rect::new(2, 3, 8, 5);
    // `total_rows` matches the 3 that should actually be visible. This
    // test is about the row-count mismatch alone, not the scrollbar thumb
    // a real `total_rows > view` would also draw.
    draw_menu_box(
        &mut canvas,
        outer,
        BoxRows::List {
            rows: &list_rows(&rows(5)),
            selected: Some(0),
            selected_style: style(),
            theme: &theme,
        },
        3,
        0,
        true,
        styles(),
    );

    insta::assert_snapshot!(symbols_in(&buf, Rect::new(0, 0, 12, 9)), @"



    ┌──────┐
    │item0 │
    │item1 │
    │item2 │
    └──────┘

    ");
}

// ── outer_rows ───────────────────────────────────────────────────────────────

/// A `row_count` well past `u16::MAX` (a large `buffer-words` index on an
/// empty prefix) must still clamp to `row_cap`, not wrap through a `u16`
/// truncation before the `min` runs.
#[test]
fn outer_rows_clamps_a_huge_row_count_instead_of_wrapping() {
    // 65_536 is an exact multiple of u16::MAX + 1, so truncating to u16
    // *before* the min wraps it to 0, which then wins the min against
    // `row_cap` and produces the wrong (much too small) result.
    assert_eq!(outer_rows(65_536, MAX_MENU_ROWS), MAX_MENU_ROWS + 2);
}

#[test]
fn outer_rows_stays_under_the_cap_for_a_small_row_count() {
    assert_eq!(outer_rows(3, MAX_MENU_ROWS), 3 + 2);
}

const MENU_FG: hume_grid::Rgb = hume_grid::Rgb(1, 2, 3);
const MENU_BG: hume_grid::Rgb = hume_grid::Rgb(4, 5, 6);
const MENU_SELECTED_BG: hume_grid::Rgb = hume_grid::Rgb(7, 8, 9);
const ROW_BG: hume_grid::Rgb = hume_grid::Rgb(10, 11, 12);

/// A theme styling the menu, its selected row, `"span"` as italic and
/// `"row"` in its own background, with the ids of the last two.
fn menu_theme() -> (Theme, ScopeId, ScopeId) {
    let colors = |fg, bg| ResolvedStyle {
        fg: Some(fg),
        bg: Some(bg),
        ..Default::default()
    };
    let styles = std::collections::HashMap::from([
        ("ui.menu", colors(MENU_FG, MENU_BG)),
        (
            "ui.menu.selected",
            ResolvedStyle {
                bg: Some(MENU_SELECTED_BG),
                ..Default::default()
            },
        ),
        (
            "span",
            ResolvedStyle {
                modifiers: Modifiers::ITALIC,
                ..Default::default()
            },
        ),
        (
            "row",
            ResolvedStyle {
                bg: Some(ROW_BG),
                ..Default::default()
            },
        ),
    ]);
    let mut registry = ScopeRegistry::new();
    let span = registry.intern("span");
    let row = registry.intern("row");
    let mut theme = Theme::new(styles, ResolvedStyle::default());
    theme.bake(&registry);
    (theme, span, row)
}

/// Paints `rows` as a menu in the box `Rect::new(0, 0, 10, rows + 2)`, row 0
/// selected, in `theme`'s menu styles.
fn paint_menu(theme: &Theme, rows: &[ListRow], grid: &mut Grid) {
    let mut canvas = Canvas::new(grid, theme.ui.invisible, None);
    draw_menu_box(
        &mut canvas,
        Rect::new(0, 0, 10, rows.len() as u16 + 2),
        BoxRows::List {
            rows,
            selected: Some(0),
            selected_style: theme.resolve_by_name(Scope(ui_scopes::MENU_SELECTED)),
            theme,
        },
        rows.len(),
        0,
        false,
        MenuBoxStyles::menu(theme),
    );
}

#[test]
fn a_menu_rows_span_layers_over_the_selected_style() {
    let (theme, span, _) = menu_theme();
    let scopes = SpanScopes {
        scope: span,
        selected: None,
    };
    let row = ListRow::styled(SpannedText::new("abcd".to_string(), vec![(1, 3, scopes)]).unwrap());
    let mut grid = Grid::new(10, 4);
    paint_menu(&theme, &[row.clone(), row], &mut grid);

    let italic = |x: u16, y: u16| grid[(x, y)].style().modifiers.contains(Modifiers::ITALIC);
    for x in [2, 3] {
        assert_eq!(grid[(x, 1)].style().bg, Some(MENU_SELECTED_BG), "x={x}");
        assert!(italic(x, 1), "selected span italic at x={x}");
        assert!(italic(x, 2), "span italic at x={x}");
    }
    assert!(!italic(1, 1) && !italic(4, 1), "outside the span");
}

#[test]
fn a_menu_rows_selected_scope_replaces_ui_menu_selected() {
    let (theme, _, row_scope) = menu_theme();
    let row = ListRow::plain("ab".into()).with_selected_scope(Some(row_scope));
    let mut grid = Grid::new(10, 4);
    paint_menu(&theme, &[row.clone(), row], &mut grid);

    for x in [1, 2, 5] {
        assert_eq!(
            grid[(x, 1)].style().bg,
            Some(ROW_BG),
            "selected bg at x={x}"
        );
        assert_eq!(grid[(x, 2)].style().bg, Some(MENU_BG), "bg at x={x}");
    }
}
