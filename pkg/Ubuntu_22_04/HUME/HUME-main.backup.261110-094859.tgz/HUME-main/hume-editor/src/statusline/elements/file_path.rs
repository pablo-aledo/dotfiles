use hume_engine::types::ResolvedStyle;
use std::borrow::Cow;
use unicode_segmentation::UnicodeSegmentation;

use hume_platform::path::is_path_sep;

use crate::statusline::HumeStatusline;
use crate::statusline::colors::EditorColors;
use hume_rope::width::{ELLIPSIS, ELLIPSIS_WIDTH, chrome_width, truncate_to_width};

/// The `FilePath` element does not implement [`super::StatuslineElement`]:
/// its content isn't read from `Editor` directly, but computed externally by
/// `render_statusline`'s two-pass sizing pass (measure with `""`, then
/// [`shorten_path_to_width`] against the remaining budget) and handed in as
/// `filepath_text`.
pub(in crate::statusline) fn render<'a>(
    filepath_text: &'a str,
    colors: &EditorColors,
) -> (Cow<'a, str>, ResolvedStyle) {
    (Cow::Borrowed(filepath_text), colors.statusline)
}

/// Returns the display path for the `FilePath` element: the buffer's
/// display-ready path string, printed verbatim, falling back to the buffer's
/// display name (label, or the scratch buffer's name) for scratch and
/// synthetic buffers.
pub(in crate::statusline) fn statusline_display_path<'a>(
    editor: &'a HumeStatusline<'_>,
) -> Cow<'a, str> {
    editor.doc().display_path_or_name()
}

/// Shorten `display` (a `~`-collapsed path string) to fit within `max_display_cols`
/// terminal columns by abbreviating leading directory components.
///
/// Algorithm:
/// 1. If it already fits, return as-is.
/// 2. Replace leading dir components with their first grapheme cluster,
///    left-to-right, re-checking width each time.
/// 3. If still too wide after all dirs are abbreviated, truncate the filename
///    with a trailing `…`, shrinking until it fits or only `…` remains.
pub(in crate::statusline) fn shorten_path_to_width(
    display: &str,
    max_display_cols: usize,
) -> Cow<'_, str> {
    shorten_path_to_width_with(display, max_display_cols, is_path_sep)
}

/// `is_sep` is injected so the separator handling (`/` everywhere, plus `\` on
/// Windows) is exercisable in tests regardless of the host platform. Splits
/// keep each component's trailing separator character so mixed `/`/`\` input
/// (as can appear in a Windows path) survives reassembly unchanged.
fn shorten_path_to_width_with(
    display: &str,
    max_display_cols: usize,
    is_sep: fn(char) -> bool,
) -> Cow<'_, str> {
    if chrome_width(display) <= max_display_cols {
        return Cow::Borrowed(display);
    }
    if max_display_cols == 0 {
        return Cow::Borrowed("");
    }

    // The last component is the filename; abbreviate the leading dirs (all
    // but the last) one by one.
    let mut components: Vec<Cow<'_, str>> =
        display.split_inclusive(is_sep).map(Cow::Borrowed).collect();
    let n = components.len();
    if n == 0 {
        return Cow::Borrowed("");
    }

    for i in 0..n.saturating_sub(1) {
        let (content, sep) = split_trailing_sep(&components[i], is_sep);
        // Skip components that are already at minimum width: empty, "~", or
        // single-grapheme entries (abbreviated in a previous run).
        let grapheme_count = content.graphemes(true).count();
        if grapheme_count <= 1 {
            continue;
        }
        // Abbreviate to the first grapheme cluster, keeping the separator.
        let first = content.graphemes(true).next().unwrap_or("");
        components[i] = Cow::Owned(format!("{first}{sep}"));

        let candidate = components.concat();
        if chrome_width(&candidate) <= max_display_cols {
            return Cow::Owned(candidate);
        }
    }

    // All dirs abbreviated, still too wide. Truncate the filename with `…`.
    let prefix = components[..n.saturating_sub(1)].concat();
    // Available columns for the filename (after prefix + ellipsis). The
    // prefix already carries its own trailing separator, if any.
    let prefix_w = chrome_width(&prefix);
    let available = max_display_cols.saturating_sub(prefix_w + ELLIPSIS_WIDTH);

    let filename = &components[n - 1];
    let (truncated, _) = truncate_to_width(filename, available);

    if truncated.is_empty() {
        // Not even one grapheme of filename fits; just show the ellipsis.
        if prefix.is_empty() {
            Cow::Borrowed(ELLIPSIS)
        } else {
            Cow::Owned(format!("{prefix}{ELLIPSIS}"))
        }
    } else {
        Cow::Owned(format!("{prefix}{truncated}{ELLIPSIS}"))
    }
}

/// Split `s` into `(content, sep)` where `sep` is the trailing separator
/// character (as injected by `is_sep`), or `(s, "")` if `s` has none.
fn split_trailing_sep(s: &str, is_sep: fn(char) -> bool) -> (&str, &str) {
    match s.chars().next_back() {
        Some(c) if is_sep(c) => {
            let split_at = s.len() - c.len_utf8();
            (&s[..split_at], &s[split_at..])
        }
        _ => (s, ""),
    }
}

#[cfg(test)]
mod tests;
