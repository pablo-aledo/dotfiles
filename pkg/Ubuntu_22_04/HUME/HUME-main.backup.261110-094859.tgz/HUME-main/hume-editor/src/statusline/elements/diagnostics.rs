use hume_core::DiagSeverity;
use hume_engine::types::ResolvedStyle;
use std::borrow::Cow;

use super::StatuslineElement;
use crate::editor::lsp::introspect::LspActivity;
use crate::statusline::HumeStatusline;
use crate::statusline::colors::EditorColors;

/// Braille spinner frames for the loading state, indexed by
/// `frame % SPINNER.len()`.
const SPINNER: [char; 10] = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];

pub(in crate::statusline) struct DiagnosticsElement;

impl StatuslineElement for DiagnosticsElement {
    /// The focused buffer's LSP loading state, its `(errors, warnings)`
    /// counts, and the current spinner animation frame, rendered together
    /// (spinner prefix + counts suffix) so a background progress task never
    /// hides the counts the user already has.
    ///
    /// Diagnostic counts are read directly from the diagnostics store in
    /// Rust: the statusline renders every frame, so this never goes
    /// through Steel's `(diagnostic-counts …)` builtin (that one is for
    /// plugins, not the render path).
    type Data<'a> = (LspActivity, usize, usize, usize);

    fn read<'a>(editor: &'a HumeStatusline<'_>) -> Self::Data<'a> {
        let bid = editor.focused_buffer_id();
        let counts = editor.diagnostic_counts(bid);
        (
            editor.lsp_activity(bid),
            counts.error,
            counts.warning,
            editor.lsp_spinner_frame(),
        )
    }

    fn format<'a>(
        (activity, errors, warnings, frame): Self::Data<'a>,
        colors: &EditorColors,
    ) -> (Cow<'a, str>, ResolvedStyle) {
        let spinner = SPINNER[frame % SPINNER.len()];
        // `Starting` and a percentage-less `Progress` render identically:
        // neither has anything more specific to show than "a server task is
        // running".
        let spinner_prefix = match activity {
            LspActivity::Idle => None,
            LspActivity::Starting | LspActivity::Progress { percentage: None } => {
                Some(format!("{spinner} lsp"))
            }
            LspActivity::Progress {
                percentage: Some(p),
            } => Some(format!("{spinner} {p}%")),
        };
        let error = DiagSeverity::Error.glyph();
        let warning = DiagSeverity::Warning.glyph();
        let counts = match (errors, warnings) {
            (0, 0) => None,
            (e, 0) => Some(format!("{error} {e}")),
            (0, w) => Some(format!("{warning} {w}")),
            (e, w) => Some(format!("{error} {e} {warning} {w}")),
        };
        let label = match (spinner_prefix, counts) {
            (Some(s), Some(c)) => format!("{s} {c}"),
            (Some(s), None) => s,
            (None, Some(c)) => c,
            (None, None) => String::new(),
        };
        (Cow::Owned(label), colors.statusline)
    }
}
