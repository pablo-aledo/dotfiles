use hume_engine::types::ResolvedStyle;
use std::borrow::Cow;

use super::StatuslineElement;
use crate::statusline::HumeStatusline;
use crate::statusline::colors::EditorColors;

pub(in crate::statusline) struct PositionElement;

/// The cursor's position, plus what the field needs to size itself.
pub(in crate::statusline) struct Position {
    /// 1-based line number of the cursor.
    line: usize,
    /// 1-based grapheme column (CLAUDE.md's "Displayed value" invariant).
    grapheme_col: usize,
    /// Highest 1-based line number the cursor can reach in the buffer:
    /// sizes the padding field.
    max_line: usize,
}

impl StatuslineElement for PositionElement {
    type Data<'a> = Position;

    fn read<'a>(editor: &'a HumeStatusline<'_>) -> Self::Data<'a> {
        let text = editor.doc().text();
        let head = editor.current_view().primary().head();
        let head_line = text.char_to_line(head.offset());
        let grapheme_col = text.columns().grapheme_col(head_line, head.offset());
        Position {
            line: head_line.number(),
            grapheme_col: grapheme_col.number(),
            max_line: text.content_line_count().get(),
        }
    }

    fn format<'a>(
        Position {
            line,
            grapheme_col,
            max_line,
        }: Self::Data<'a>,
        colors: &EditorColors,
    ) -> (Cow<'a, str>, ResolvedStyle) {
        // Right-align into a field sized for the largest line number this
        // buffer can show (min 3 digits) and a fixed 3-digit column budget,
        // so the element's right edge stays put as the cursor moves and
        // elements after it (e.g. FilePath) don't jitter left-right. A
        // column past the 3-digit budget just overflows the field rather
        // than shifting it.
        let line_digits = hume_engine::builtins::line_number::digit_count(max_line).max(3) as usize;
        let width = line_digits + 1 + 3;
        (
            Cow::Owned(format!("{:>width$}", format!("{line}:{grapheme_col}"))),
            colors.statusline,
        )
    }
}
