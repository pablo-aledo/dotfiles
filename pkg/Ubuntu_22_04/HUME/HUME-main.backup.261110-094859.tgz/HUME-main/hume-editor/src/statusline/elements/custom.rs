use hume_engine::types::ResolvedStyle;
use std::borrow::Cow;

use crate::statusline::HumeStatusline;
use crate::statusline::colors::EditorColors;

/// The `Custom` element does not implement [`super::StatuslineElement`]:
/// `read`/`format` have no room for the element's own `name`, the same
/// reason [`super::file_path`]'s `render` is a free function instead.
///
/// Renders the focused buffer's last-pushed text for `name` (`(set-
/// statusline-text! pane source text)`), or empty if nothing has been pushed
/// yet: same "absent = empty" convention as every other element.
pub(in crate::statusline) fn render<'a>(
    editor: &'a HumeStatusline<'_>,
    name: &str,
    colors: &EditorColors,
) -> (Cow<'a, str>, ResolvedStyle) {
    let text = editor
        .state
        .config
        .statusline_text
        .get(&editor.focused_buffer_id())
        .and_then(|by_name| by_name.get(name))
        .map_or("", Box::as_ref);
    (Cow::Borrowed(text), colors.statusline)
}
