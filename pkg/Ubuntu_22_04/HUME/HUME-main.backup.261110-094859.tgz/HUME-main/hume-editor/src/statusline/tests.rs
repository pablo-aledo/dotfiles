use super::elements::file_path::{shorten_path_to_width, statusline_display_path};
use super::*;
use hume_engine::types::ResolvedStyle;
use hume_grid::Rgb;

fn s(text: &'static str) -> (Cow<'static, str>, ResolvedStyle) {
    (Cow::Borrowed(text), ResolvedStyle::default())
}

// ── section_width ─────────────────────────────────────────────────────────

#[test]
fn section_width_empty() {
    assert_eq!(section_width(&[]), 0);
}

#[test]
fn section_width_ascii() {
    let spans = vec![s("NOR"), s(" "), s("│")];
    // "NOR"=3, " "=1, "│"=1 (U+2502 is width 1)
    assert_eq!(section_width(&spans), 5);
}

#[test]
fn section_width_cjk() {
    // CJK character is display-width 2.
    let spans = vec![s("A"), (Cow::Borrowed("中"), ResolvedStyle::default())];
    assert_eq!(section_width(&spans), 3);
}

// ── pad_left / pad_right ──────────────────────────────────────────────────

#[test]
fn pad_left_prepends_space() {
    let colors = crate::statusline::colors::EditorColors::default();
    let spans = pad_left(vec![s("NOR")], &colors);
    assert_eq!(spans.len(), 2);
    assert_eq!(spans[0].0.as_ref(), " ");
    assert_eq!(spans[1].0.as_ref(), "NOR");
}

#[test]
fn pad_left_empty_is_noop() {
    let colors = crate::statusline::colors::EditorColors::default();
    let spans = pad_left(vec![], &colors);
    assert!(spans.is_empty());
}

#[test]
fn pad_right_appends_space() {
    let colors = crate::statusline::colors::EditorColors::default();
    let spans = pad_right(vec![s("NOR")], &colors);
    assert_eq!(spans.len(), 2);
    assert_eq!(spans[0].0.as_ref(), "NOR");
    assert_eq!(spans[1].0.as_ref(), " ");
}

#[test]
fn pad_right_empty_is_noop() {
    let colors = crate::statusline::colors::EditorColors::default();
    let spans = pad_right(vec![], &colors);
    assert!(spans.is_empty());
}

// ── MacroRecording element ────────────────────────────────────────────────

fn test_editor() -> crate::editor::Editor {
    use hume_editing::text::BufferText;
    let text = BufferText::from("hello\n");
    crate::editor::Editor::for_testing(text)
}

#[test]
fn macro_recording_element_idle_renders_empty() {
    // When not recording, MacroRecording should contribute an empty string.
    let ed = test_editor();
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::MacroRecording, &statusline, &colors, "");
    assert!(
        text.is_empty(),
        "expected empty string when not recording, got {:?}",
        text
    );
}

#[test]
fn macro_recording_element_active_renders_label() {
    // While recording into register 'q', MacroRecording renders its label.
    let mut ed = test_editor();
    for ch in ['Q', 'q'] {
        ed.step(termina::event::KeyEvent::new(
            termina::event::KeyCode::Char(ch),
            termina::event::Modifiers::NONE,
        ));
    }
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::MacroRecording, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"[recording @q]");
}

#[test]
fn macro_recording_element_named_register() {
    // Same but for a named register '3'.
    let mut ed = test_editor();
    for ch in ['Q', '3'] {
        ed.step(termina::event::KeyEvent::new(
            termina::event::KeyCode::Char(ch),
            termina::event::Modifiers::NONE,
        ));
    }
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::MacroRecording, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"[recording @3]");
}

// ── Pipe element ──────────────────────────────────────────────────────────

#[test]
fn pipe_element_idle_renders_empty() {
    let ed = test_editor();
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Pipe, &statusline, &colors, "");
    assert!(text.is_empty(), "got {text:?}");
}

#[test]
fn pipe_element_shows_the_command_and_progress() {
    use crate::editor::PipeProgress;
    let colors = crate::statusline::colors::EditorColors::default();
    fn progress(command: &str, done: usize, total: usize) -> Option<PipeProgress<'_>> {
        Some(PipeProgress {
            command,
            done,
            total,
        })
    }
    let (one, _) = PipeElement::format(progress("sort", 0, 1), &colors);
    insta::assert_snapshot!(one, @"running `sort`");
    let (many, _) = PipeElement::format(progress("uuidgen", 3, 10), &colors);
    insta::assert_snapshot!(many, @"running `uuidgen` 3/10");
}

#[test]
fn pipe_element_is_named_and_in_the_default_right_section() {
    assert_eq!("Pipe".parse::<StatusElement>(), Ok(StatusElement::Pipe));
    assert!(
        StatusLineConfig::default()
            .right
            .contains(&StatusElement::Pipe)
    );
}

// ── Whole-row mode coloring ───────────────────────────────────────────────
//
// `EditorColors::default()` uses a reversed style for every mode, which can't
// distinguish one mode's style from another. These tests need a theme with a
// distinct color per mode scope instead.

fn make_mode_theme() -> hume_engine::theme::Theme {
    use hume_engine::types::ResolvedStyle;
    use std::collections::HashMap;

    let mut styles: HashMap<&'static str, ResolvedStyle> = HashMap::new();
    styles.insert(
        "ui.statusline",
        ResolvedStyle {
            fg: Some(Rgb(255, 255, 255)),
            bg: Some(Rgb(0, 0, 0)),
            ..Default::default()
        },
    );
    for (scope, color) in [
        ("ui.statusline.normal", Rgb(255, 0, 0)),
        ("ui.statusline.insert", Rgb(0, 255, 255)),
        ("ui.statusline.select", Rgb(255, 255, 0)),
        ("ui.statusline.search", Rgb(255, 0, 255)),
        ("ui.statusline.command", Rgb(0, 255, 0)),
        ("ui.statusline.sift", Rgb(0, 0, 255)),
    ] {
        styles.insert(
            scope,
            ResolvedStyle {
                fg: Some(color),
                bg: Some(Rgb(0, 0, 0)),
                ..Default::default()
            },
        );
    }
    hume_engine::theme::Theme::new(styles, ResolvedStyle::default())
}

#[test]
fn mode_element_uses_row_style_not_a_per_mode_pill() {
    // Reintroducing a per-mode pill style (instead of colors.statusline) would
    // make this fail: the label's style must equal the resolved row style for
    // that mode, whatever mode is active. The label text itself is appearance,
    // pinned via inline snapshot rather than a hardcoded assertion.
    //
    // The expected fg comes straight from make_mode_theme's
    // per-scope color table, not from colors.statusline: asserting against
    // colors.statusline itself would pass even if from_theme resolved the wrong
    // scope entirely.
    use hume_engine::types::EditorMode;

    let theme = make_mode_theme();
    for (mode, expected_fg) in [
        (EditorMode::Normal, Rgb(255, 0, 0)),
        (EditorMode::Insert, Rgb(0, 255, 255)),
        (EditorMode::Extend, Rgb(255, 255, 0)),
        (EditorMode::Search, Rgb(255, 0, 255)),
        (EditorMode::Command, Rgb(0, 255, 0)),
        (EditorMode::Sift, Rgb(0, 0, 255)),
    ] {
        let colors = crate::statusline::colors::EditorColors::from_theme(&theme, Some(mode));
        let (text, style) = ModeElement::format(mode, &colors);
        assert_eq!(style.fg, Some(expected_fg));
        assert_eq!(style.bg, Some(Rgb(0, 0, 0)));
        match mode {
            EditorMode::Normal => insta::assert_snapshot!(text, @"NOR"),
            EditorMode::Insert => insta::assert_snapshot!(text, @"INS"),
            EditorMode::Extend => insta::assert_snapshot!(text, @"EXT"),
            EditorMode::Search => insta::assert_snapshot!(text, @"SRC"),
            EditorMode::Command => insta::assert_snapshot!(text, @"CMD"),
            EditorMode::Sift => insta::assert_snapshot!(text, @"SIF"),
        }
    }
}

#[test]
fn macro_recording_uses_row_style() {
    // The recording label must match whatever the row is currently tinted,
    // not a fixed accent of its own. Expected colors come from the theme's
    // scope table, for the same reason as in
    // mode_element_uses_row_style_not_a_per_mode_pill above.
    use hume_engine::types::EditorMode;

    let theme = make_mode_theme();
    let colors =
        crate::statusline::colors::EditorColors::from_theme(&theme, Some(EditorMode::Search));
    let (text, style) = MacroRecordingElement::format(Some('q'), &colors);
    assert_eq!(style.fg, Some(Rgb(255, 0, 255)));
    assert_eq!(style.bg, Some(Rgb(0, 0, 0)));
    insta::assert_snapshot!(text, @"[recording @q]");
}

// ── LineEnding element ────────────────────────────────────────────────────

fn test_editor_with_text(s: &str) -> crate::editor::Editor {
    use hume_editing::text::BufferText;
    let text = BufferText::from(s);
    crate::editor::Editor::for_testing(text)
}

#[test]
fn line_ending_element_lf() {
    let ed = test_editor_with_text("hello\n");
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::LineEnding, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"LF");
}

#[test]
fn line_ending_element_crlf() {
    let ed = test_editor_with_text("hello\r\n");
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::LineEnding, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"CRLF");
}

// ── Position element ──────────────────────────────────────────────────────

fn test_editor_with_text_and_cursor(s: &str, head: usize) -> crate::editor::Editor {
    use hume_editing::text::BufferText;
    let text = BufferText::from(s);
    let sels = test_fixtures::testing::single(&text, test_fixtures::testing::cursor(&text, head));
    crate::editor::Editor::for_testing_with(test_fixtures::testing::state(text, sels))
}

#[test]
fn position_element_single_line_pads_to_min_field() {
    let ed = test_editor_with_text("hello\n");
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Position, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"    1:1");
}

#[test]
fn position_element_two_digit_line_stays_in_min_field() {
    // 14 empty lines, then a 3-char line so the cursor lands at line 14, col 3.
    let s = format!("{}abc\n", "\n".repeat(13));
    let head = 13 + 2; // start of line 14 (char 13) + 2 chars ('a','b') before 'c'
    let ed = test_editor_with_text_and_cursor(&s, head);
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Position, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"   14:3");
}

#[test]
fn position_element_three_digit_line_and_col() {
    // 142 empty lines, then a 49-char line (line 143), then 7 more empty
    // lines so the buffer has 150 lines total; cursor lands at line 143, col 49.
    let s = format!("{}{}\n{}", "\n".repeat(142), "a".repeat(49), "\n".repeat(7));
    let head = 142 + 48; // start of line 143 (char 142) + 48 chars before the 49th 'a'
    let ed = test_editor_with_text_and_cursor(&s, head);
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Position, &statusline, &colors, "");
    insta::assert_snapshot!(text, @" 143:49");
}

/// Cross-surface column-agreement fixture, shared (restated here, not
/// imported, since this crate has no path to the LSP-dependent
/// `tests/unix/column_display_agreement.rs`) with that file's diagnostics/
/// goto-references assertions: the line `"e\u{0301}\u{1D11E}x"` puts three
/// different "column" units at three different values for the same
/// position (before 'x'). Each count is taken from the string itself, not
/// from any HUME helper:
/// - grapheme: 2. `"e\u{0301}"` (e + combining acute, one cluster) then
///   `"\u{1D11E}"` (one astral-plane cluster) = 2 clusters before 'x'.
/// - char: 3. Those same two clusters are 2 + 1 = 3 Rust `char`s.
/// - UTF-16 code unit: 4. The combining mark is 1 unit (2 so far), the
///   astral char needs a surrogate pair (2 more = 4).
///
/// The statusline must show the grapheme count (displayed 3), not either of
/// the other two. This is the fixture proving `:diagnostics` and the LSP
/// goto/references drawer, which historically showed the char count and the
/// UTF-16 count respectively, now agree with it.
#[test]
fn position_element_shows_grapheme_column_not_char_or_utf16_count() {
    let s = "e\u{0301}\u{1D11E}x\n";
    let head = 3; // char offset of 'x': 'e', combining mark, astral char, then 'x'
    let ed = test_editor_with_text_and_cursor(s, head);
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Position, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"    1:3");
}

#[test]
fn position_element_widens_field_past_1000_lines() {
    let s = "\n".repeat(1000);
    let ed = test_editor_with_text_and_cursor(&s, 0);
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Position, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"     1:1");
}

#[test]
fn position_element_width_stable_across_line_digit_growth() {
    // Cursor on line 9 vs line 10 must render to the same width, so
    // downstream statusline elements (e.g. FilePath) don't shift.
    let s = "\n".repeat(20);
    let colors = crate::statusline::colors::EditorColors::default();

    let ed9 = test_editor_with_text_and_cursor(&s, 8); // line 9
    let statusline = ed9.statusline();
    let spans9 = pad_left(
        render_section(&[StatusElement::Position], &statusline, &colors, ""),
        &colors,
    );

    let ed10 = test_editor_with_text_and_cursor(&s, 9); // line 10
    let statusline = ed10.statusline();
    let spans10 = pad_left(
        render_section(&[StatusElement::Position], &statusline, &colors, ""),
        &colors,
    );

    assert_eq!(section_width(&spans9), section_width(&spans10));
}

// ── Cwd element ───────────────────────────────────────────────────────────

#[test]
fn cwd_element_renders_nonempty() {
    // Smoke test: the element renders the editor's cwd.
    let ed = test_editor();
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Cwd, &statusline, &colors, "");
    assert!(
        !text.is_empty(),
        "Cwd rendered empty; expected a path string"
    );
}

// ── Language element ──────────────────────────────────────────────────────

#[test]
fn language_element_empty_when_none() {
    let ed = test_editor();
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Language, &statusline, &colors, "");
    assert!(
        text.is_empty(),
        "expected empty string for undetected language, got {:?}",
        text
    );
}

#[test]
fn language_element_renders_bracketed() {
    let ed = crate::editor::tests::editor_with_language("hello\n", "rust");
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::Language, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"[rust]");
}

// ── ReadOnly element ──────────────────────────────────────────────────────

#[test]
fn readonly_element_empty_for_normal_buffer() {
    let ed = test_editor();
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::ReadOnly, &statusline, &colors, "");
    assert!(
        text.is_empty(),
        "expected empty for writable buffer, got {text:?}"
    );
}

#[test]
fn readonly_element_renders_ro_label() {
    let ed = crate::editor::tests::editor_with_read_only_view("hello\n", "test");
    let colors = crate::statusline::colors::EditorColors::default();
    let statusline = ed.statusline();
    let (text, _) = render_element(&StatusElement::ReadOnly, &statusline, &colors, "");
    insta::assert_snapshot!(text, @"[RO]");
}

// ── Diagnostics element (format) ──────────────────────────────────────────
//
// `format` is deterministic (`Data` carries the spinner frame as a plain
// `usize`, no clock involved), so these exercise it directly with synthetic
// `Data` rather than through a full `Editor` fixture. See the
// `StatuslineElement` trait's doc comment. These are the appearance tests
// (exact glyphs/spacing pinned via inline snapshots); data flow driven by a
// live LSP server (the `Starting` → `Progress` → `Idle` transitions, and the
// counts themselves) is covered as data assertions in
// `editor::tests::lsp_statusline`.

use crate::editor::lsp::introspect::LspActivity;

#[test]
fn diagnostics_element_starting_shows_spinner() {
    let colors = crate::statusline::colors::EditorColors::default();
    let (text, _) = DiagnosticsElement::format((LspActivity::Starting, 0, 0, 0), &colors);
    insta::assert_snapshot!(text, @"⠋ lsp");
}

#[test]
fn diagnostics_element_progress_with_percentage() {
    let colors = crate::statusline::colors::EditorColors::default();
    let data = (
        LspActivity::Progress {
            percentage: Some(45),
        },
        0,
        0,
        0,
    );
    let (text, _) = DiagnosticsElement::format(data, &colors);
    insta::assert_snapshot!(text, @"⠋ 45%");
}

#[test]
fn diagnostics_element_progress_with_no_percentage_shows_generic_label() {
    let colors = crate::statusline::colors::EditorColors::default();
    let data = (LspActivity::Progress { percentage: None }, 0, 0, 0);
    let (text, _) = DiagnosticsElement::format(data, &colors);
    insta::assert_snapshot!(text, @"⠋ lsp");
}

#[test]
fn diagnostics_element_spinner_indexes_by_frame() {
    let colors = crate::statusline::colors::EditorColors::default();
    // Frame 3 selects the 4th glyph in the SPINNER table (⠋⠙⠹⠸…).
    let (text, _) = DiagnosticsElement::format((LspActivity::Starting, 0, 0, 3), &colors);
    insta::assert_snapshot!(text, @"⠸ lsp");
}

#[test]
fn diagnostics_element_idle_shows_counts_with_no_spinner() {
    let colors = crate::statusline::colors::EditorColors::default();
    let data = (LspActivity::Idle, 3, 12, 0);
    let (text, _) = DiagnosticsElement::format(data, &colors);
    insta::assert_snapshot!(text, @"✘ 3 ⚠ 12");
}

#[test]
fn diagnostics_element_omits_zero_warning_half() {
    let colors = crate::statusline::colors::EditorColors::default();
    let (text, _) = DiagnosticsElement::format((LspActivity::Idle, 1, 0, 0), &colors);
    insta::assert_snapshot!(text, @"✘ 1");
}

#[test]
fn diagnostics_element_omits_zero_error_half() {
    let colors = crate::statusline::colors::EditorColors::default();
    let (text, _) = DiagnosticsElement::format((LspActivity::Idle, 0, 1, 0), &colors);
    insta::assert_snapshot!(text, @"⚠ 1");
}

/// A `$/progress` task in flight must not hide diagnostic counts already
/// known for the buffer: the spinner and the counts render together.
#[test]
fn diagnostics_element_progress_and_counts_render_together() {
    let colors = crate::statusline::colors::EditorColors::default();
    let data = (
        LspActivity::Progress {
            percentage: Some(45),
        },
        3,
        12,
        0,
    );
    let (text, _) = DiagnosticsElement::format(data, &colors);
    insta::assert_snapshot!(text, @"⠋ 45% ✘ 3 ⚠ 12");
}

#[test]
fn diagnostics_element_idle_with_no_diagnostics_is_empty() {
    let colors = crate::statusline::colors::EditorColors::default();
    let (text, _) = DiagnosticsElement::format((LspActivity::Idle, 0, 0, 0), &colors);
    assert!(text.is_empty(), "expected empty, got {text:?}");
}

// ── center_x arithmetic ───────────────────────────────────────────────────

#[test]
fn center_x_does_not_overflow_when_wider_than_the_gap() {
    // `render_statusline` computes `center_x` via `Rect::centered` on a
    // `gap`-wide span; when `center_w` exceeds it, `centered` clamps its own
    // width to `gap` rather than the caller's, so this must not panic and
    // must never place `center_x` before `left_end`, the same safety
    // `center_fits`'s separate `center_w <= gap` check relies on rather than
    // trusting this arithmetic to reject an oversized `center_w` itself.
    let left_end: u16 = 5;
    let gap: u16 = 2;
    let center_w: u16 = 10;
    let center_x = Rect::new(left_end, 0, gap, 1).centered(center_w, 1).x;
    assert!(center_x >= left_end);
}

// ── shorten_path_to_width ─────────────────────────────────────────────────

#[test]
fn shorten_path_fits_unchanged() {
    // Path that already fits: returned verbatim.
    let path = "~/dev/foo.txt";
    let result = shorten_path_to_width(path, 50);
    assert_eq!(result, path);
}

#[test]
fn shorten_path_exactly_at_limit_is_unchanged() {
    let path = "~/foo/bar.txt"; // width = 13
    let result = shorten_path_to_width(path, 13);
    assert_eq!(result, path, "path at exact limit should not be shortened");
}

#[test]
fn shorten_path_abbreviates_first_dir() {
    // "~/foo/bar/baz.txt" → "~/f/bar/baz.txt" when narrowed enough.
    let path = "~/foo/bar/baz.txt";
    // Full width = 17. At 15 we expect first dir abbreviated.
    // "~/f/bar/baz.txt" = 15 chars = 15 cols.
    let result = shorten_path_to_width(path, 15);
    assert_eq!(result, "~/f/bar/baz.txt");
}

#[test]
fn shorten_path_abbreviates_multiple_dirs() {
    // "~/foo/bar/baz.txt" → "~/f/b/baz.txt" when even narrower.
    let path = "~/foo/bar/baz.txt";
    // "~/f/b/baz.txt" = 13 cols.
    let result = shorten_path_to_width(path, 13);
    assert_eq!(result, "~/f/b/baz.txt");
}

#[test]
fn shorten_path_abbreviation_stops_early_when_it_fits() {
    // Should abbreviate minimally: stop as soon as it fits.
    // "~/foo/bar/baz.txt" = 17.  At budget 16: first dir abbreviated →
    // "~/f/bar/baz.txt" = 15 ≤ 16 → done (second dir NOT abbreviated).
    let path = "~/foo/bar/baz.txt";
    let result = shorten_path_to_width(path, 16);
    assert_eq!(result, "~/f/bar/baz.txt");
}

#[test]
fn shorten_path_ellipsis_on_very_narrow() {
    // When even all dirs abbreviated still too wide, truncate filename.
    // "~/foo/bar/baz.txt" fully abbreviated dirs = "~/f/b/baz.txt" = 13.
    // At budget 10: "~/f/b/" (6) + "…" (1) = 7; filename available = 3.
    // "baz" = 3, so result = "~/f/b/baz…".
    let path = "~/foo/bar/baz.txt";
    let result = shorten_path_to_width(path, 10);
    assert_eq!(result, "~/f/b/baz…");
}

#[test]
fn shorten_path_zero_budget_returns_empty() {
    // A zero budget must yield an empty string.
    let result = shorten_path_to_width("~/foo/bar.txt", 0);
    assert_eq!(result, "");
}

#[test]
fn shorten_path_no_dirs_abbreviates_only_filename() {
    // Flat filename with no directory component, so only ellipsis can help.
    // "readme.txt" = 10. At budget 6: need to truncate. "readm" (5) + "…" (1) = 6.
    let result = shorten_path_to_width("readme.txt", 6);
    assert_eq!(result, "readm…");
}

#[test]
fn shorten_path_tilde_alone_not_abbreviated() {
    // "~" is a 1-grapheme component and must not be shortened further.
    let path = "~/very-long-filename.txt";
    // All dirs abbreviated: "~" stays "~", filename gets truncated if needed.
    // Width of "~/very-long-filename.txt" = 24. At budget 10:
    // dirs fully abbreviated → still "~/very-long-filename.txt" (~ is the only dir)
    // Truncate filename to fit budget 10: "~/…" prefix = 3; available = 7.
    // "very-lon" = 8 > 7, "very-lo" = 7 → result = "~/very-lo…"
    let result = shorten_path_to_width(path, 10);
    assert_eq!(result, "~/very-lo…");
}

#[test]
fn shorten_path_unicode_dir_name() {
    // A CJK dir name (each char = 2 display cols). "中文" = 4 cols.
    // Path: "/中文/foo/bar.txt". Full width = 1+4+1+3+1+7 = 17.
    // At budget 13: abbreviate /中文/ to its first grapheme → "/中/foo/bar.txt"
    // = 1 + 2 + 1 + 3 + 1 + 7 = 15. Still too wide.
    // Abbreviate /foo/ → "/中/f/bar.txt" = 1+2+1+1+1+7 = 13. Fits.
    let path = "/中文/foo/bar.txt";
    let result = shorten_path_to_width(path, 13);
    assert_eq!(result, "/中/f/bar.txt");
}

#[test]
fn shorten_path_actually_abbreviates_when_too_wide() {
    // Returning the input unchanged must fail this.
    let path = "~/aaaa/bbbb/cccc.txt"; // 20 cols
    let result = shorten_path_to_width(path, 15);
    assert_ne!(
        result, path,
        "path was not shortened when it should have been"
    );
    // Width measured without the code under test. See `clippy.toml`'s
    // `disallowed-methods` entry.
    #[allow(clippy::disallowed_methods)]
    let oracle_width = unicode_width::UnicodeWidthStr::width(&*result);
    assert!(
        oracle_width <= 15,
        "shortened path {result:?} exceeds budget of 15 cols"
    );
}

// `shorten_path_to_width_with`'s own separator-injection tests are co-located
// with it in `elements::file_path::tests`: it has no caller outside that
// file, unlike `shorten_path_to_width` above (called from `render_statusline`
// in this module, hence tested here).

// ── statusline_display_path (label fallback for path-less buffers) ────────
//
// Scratch/synthetic buffers have no path, so display_path()/path() alone
// would render "". The label-aware display_name() (same as `:ls` in
// input_stack/drawer.rs) is required for their name to show. The expected strings
// below are literal names (`*scratch*`, `[plugin-status]`), not derived from
// display_name()'s own logic.

#[test]
fn statusline_display_path_scratch_buffer_shows_scratch_name() {
    // test_editor()'s buffer has no path and no label: the scratch case.
    let ed = test_editor();
    assert_eq!(statusline_display_path(&ed.statusline()), "*scratch*");
}

#[test]
fn statusline_display_path_names_a_later_scratch_buffer_by_its_number() {
    let ed = crate::editor::tests::editor_on_a_second_scratch();
    assert_eq!(statusline_display_path(&ed.statusline()), "*scratch-2*");
}

#[test]
fn statusline_display_path_synthetic_buffer_shows_label() {
    let ed = crate::editor::tests::editor_with_read_only_view("hello\n", "plugin-view");
    assert_eq!(statusline_display_path(&ed.statusline()), "[plugin-view]");
}

#[test]
fn statusline_display_path_real_file_still_shows_path() {
    // The label fallback must not shadow a real path.
    //
    // Expectation is the path's own text, not `display_form(path)`, since that
    // would be circular with `BufferFile::new`, which derives the display path
    // by calling the very same function. The path has no `$HOME` prefix and no
    // Windows verbatim prefix, so `display_form` is a no-op on it and it must
    // come back byte-identical.
    let path = hume_platform::path::AbsolutePath::rooted("/some/absolute/path/file.rs");
    let ed = crate::editor::tests::editor_with_path("hello\n", &path);
    assert_eq!(
        statusline_display_path(&ed.statusline()),
        path.display().to_string()
    );
}

// ── StatusElement::Custom ("steel:<name>") ─────────────────────────────────

#[test]
fn steel_prefixed_name_parses_to_custom_and_round_trips_through_display() {
    let elem: StatusElement = "steel:git-branch".parse().unwrap();
    assert_eq!(elem, StatusElement::Custom("git-branch".into()));
    assert_eq!(elem.to_string(), "steel:git-branch");
}

#[test]
fn steel_prefix_with_empty_name_is_rejected() {
    let err = "steel:".parse::<StatusElement>().unwrap_err();
    assert!(err.contains("steel:"), "got: {err}");
}

#[test]
fn steel_name_containing_the_wire_format_separators_is_rejected() {
    // See `StatusElement::custom`'s doc for why `,`/`|` are rejected.
    assert!("steel:a,b".parse::<StatusElement>().is_err());
    assert!("steel:a|b".parse::<StatusElement>().is_err());
}

#[test]
fn custom_element_renders_the_focused_buffers_pushed_text_or_empty() {
    let mut ed = test_editor();
    let colors = crate::statusline::colors::EditorColors::default();
    let bid = ed.focused_buffer_id();

    let statusline = ed.statusline();
    let (empty, _) = render_element(
        &StatusElement::Custom("greeting".into()),
        &statusline,
        &colors,
        "",
    );
    assert_eq!(empty, "", "nothing pushed yet must render empty");

    ed.state
        .config
        .statusline_text
        .entry(bid)
        .or_default()
        .insert("greeting".into(), "hi".into());
    let statusline = ed.statusline();
    let (text, style) = render_element(
        &StatusElement::Custom("greeting".into()),
        &statusline,
        &colors,
        "",
    );
    assert_eq!(text, "hi");
    assert_eq!(
        style, colors.statusline,
        "a custom element renders in the row style, same as every element but Separator"
    );
}
