use hume_engine::types::ResolvedStyle;
use hume_grid::Rect;
use std::borrow::Cow;
use std::fmt;
use std::str::FromStr;

use hume_engine::render::Canvas;

use crate::editor::EditorState;
use colors::EditorColors;
use hume_core::BufferId;
use hume_rope::width::chrome_width;
use hume_scripting::host::DiagnosticCounts;

pub(crate) mod colors;
mod elements;
use elements::{
    CwdElement, DiagnosticsElement, DirtyIndicatorElement, FileNameElement, KittyProtocolElement,
    LanguageElement, LineEndingElement, MacroRecordingElement, MiniBufElement, ModeElement,
    PipeElement, PositionElement, ReadOnlyElement, SearchMatchesElement, SeparatorElement,
    StatuslineElement,
};

/// Hardcoded left section for Command/Search modes.
const MINIBUF_LEFT: &[StatusElement] = &[StatusElement::MiniBuf];

// ── Configuration ─────────────────────────────────────────────────────────────

/// A named element that can appear in a statusline section.
///
/// Elements are the building blocks of the statusline. The mode indicator,
/// separators, and data fields are all first-class element variants:
/// there is no special chrome. You control the layout by choosing which
/// elements appear in each section and in what order.
///
/// The Steel scripting layer constructs [`StatusLineConfig`] values at
/// runtime; this enum is the wire format for those configurations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StatusElement {
    /// The mode indicator: `"NOR"`, `"INS"`, `"EXT"`, `"CMD"`, `"SRC"`, or `"SIF"`.
    ///
    /// Rendered in the row style, like every other element: the whole row
    /// tints with the mode, not just this label. Contains no padding; the
    /// renderer's edge padding and inter-element spacing handle surrounding
    /// whitespace.
    Mode,
    /// A thin vertical bar `│`, styled from `ui.statusline.separator` (falls
    /// back to the row style when a theme omits that scope).
    ///
    /// Place this explicitly between elements that need a visual divider.
    Separator,
    /// The file's basename, or `"*scratch*"`/`"*scratch-N*"` for unnamed
    /// buffers.
    FileName,
    /// Full path to the focused file, with the home prefix collapsed to `~`.
    ///
    /// Shows the path as the user typed it (symlinks **not** resolved). When the
    /// terminal row is too narrow the path is progressively shortened: leading
    /// directory components are abbreviated to their first grapheme cluster
    /// left-to-right; the filename is truncated with `…` only as a last resort.
    ///
    /// Intended for the `left` section where it has the most available space.
    /// For scratch and synthetic buffers (no path) this falls back to the
    /// buffer's display name: its label, or the scratch buffer's name.
    FilePath,
    /// Current working directory, with the home prefix replaced by `~`.
    ///
    /// Read from `editor.state.cwd`, which is cached at startup and updated by `:cd`.
    /// Renders empty when the working directory path is unavailable.
    Cwd,
    /// Cursor position as `"line:col"` (both 1-based, col = grapheme index).
    Position,
    /// Kitty keyboard protocol indicator: `"ᓚᘏᗢ"` when active, empty otherwise.
    ///
    /// Useful for diagnosing whether the protocol was successfully negotiated.
    KittyProtocol,
    /// Dirty indicator: `"[+]"` when the buffer has unsaved changes, empty otherwise.
    DirtyIndicator,
    /// Line-ending indicator: `"LF"` or `"CRLF"` reflecting the buffer's write-back
    /// encoding. Always shown: LF is the common case but worth making explicit.
    LineEnding,
    /// Search match count: `"[3/42]"` when a search regex is active, empty otherwise.
    ///
    /// The current index is 1-based: the match whose range contains the primary
    /// cursor head. Shows `0` when the cursor is between matches (e.g. the live
    /// search has no hit yet).
    SearchMatches,
    /// The mini-buffer input field: prompt character followed by typed text.
    ///
    /// Rendered only when `editor.state.minibuf()` is `Some`; empty otherwise.
    MiniBuf,
    /// Macro recording indicator: `"[recording @q]"` while a macro is being
    /// recorded, empty otherwise.
    MacroRecording,
    /// Shell command indicator: ``"running `sort`"`` while `pipe` waits for
    /// its command, with a `"3/10"` count of finished processes when it runs
    /// over more than one selection; empty otherwise.
    Pipe,
    /// The focused buffer's language identifier, rendered as `"[rust]"`, or
    /// empty when no language is detected (scratch buffers, unknown filetypes).
    Language,
    /// Read-only indicator: `"[RO]"` when the buffer is read-only, empty otherwise.
    ReadOnly,
    /// Diagnostic counts for the focused buffer: `"✘ 3 ⚠ 12"`, empty when
    /// both counts are zero. Reads the diagnostics store directly in
    /// Rust. The statusline renders every frame, so this never goes
    /// through Steel's `(diagnostic-counts …)` builtin (that one is for
    /// plugins, not the render path).
    Diagnostics,
    /// A plugin-defined element, named by `(set-statusline-text! pane source
    /// text)`'s `source` argument. Wire name is `steel:<source>`; carries
    /// the name rather than an interned id, which is what costs this enum
    /// its `Copy` derive.
    ///
    /// Renders the focused buffer's last-pushed text for `name`, or empty
    /// if nothing has been pushed yet: same "absent = empty" convention as
    /// every other element. Steel is never called on the render path (see
    /// `Diagnostics`'s doc above); this element only ever reads the cache
    /// `set-statusline-text!` already wrote.
    Custom(Box<str>),
}

/// Wire-format name for every non-[`Custom`](StatusElement::Custom)
/// `StatusElement` variant: the single source both directions of the
/// name↔variant mapping read from, so adding a variant here (`Custom` is
/// exempt: a data-carrying variant can't live in a fixed table, so `Display`
/// and `FromStr` special-case it directly instead) is one entry instead of
/// three hand-kept-in-sync lists (`Display`, `FromStr`, and the error
/// message's own name list, which had already drifted out of alphabetical
/// order from the other two).
const ELEMENT_NAMES: &[(&str, StatusElement)] = &[
    ("Mode", StatusElement::Mode),
    ("Separator", StatusElement::Separator),
    ("FileName", StatusElement::FileName),
    ("FilePath", StatusElement::FilePath),
    ("Cwd", StatusElement::Cwd),
    ("Position", StatusElement::Position),
    ("KittyProtocol", StatusElement::KittyProtocol),
    ("DirtyIndicator", StatusElement::DirtyIndicator),
    ("LineEnding", StatusElement::LineEnding),
    ("SearchMatches", StatusElement::SearchMatches),
    ("MiniBuf", StatusElement::MiniBuf),
    ("MacroRecording", StatusElement::MacroRecording),
    ("Pipe", StatusElement::Pipe),
    ("Language", StatusElement::Language),
    ("ReadOnly", StatusElement::ReadOnly),
    ("Diagnostics", StatusElement::Diagnostics),
];

/// Wire-format prefix for [`StatusElement::Custom`]: one constant so
/// `Display` and `FromStr` can't drift out of agreement on the string that
/// makes a name round-trip through both.
const CUSTOM_PREFIX: &str = "steel:";

impl StatusElement {
    /// Validates and builds a [`Custom`](StatusElement::Custom) element from
    /// a bare name (no `steel:` prefix). Shared by `FromStr`'s parse path
    /// and `set_statusline_text`'s push path (`host_impl.rs`). A name that
    /// fails here can never round-trip through `"left|center|right"`
    /// (`settings::parse_statusline` splits on `,`/`|` with no escaping), so
    /// both the place that names an element and the place that pushes to
    /// one must reject it, or a pushed-but-unplaceable name silently never
    /// renders.
    pub(crate) fn custom(name: &str) -> Result<Self, String> {
        if name.is_empty() || name.contains([',', '|']) {
            Err(format!(
                "a {CUSTOM_PREFIX} element name must be non-empty and must not contain ',' or '|', got '{name}'"
            ))
        } else {
            Ok(StatusElement::Custom(name.into()))
        }
    }
}

impl fmt::Display for StatusElement {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let StatusElement::Custom(name) = self {
            return write!(f, "{CUSTOM_PREFIX}{name}");
        }
        let (name, _) = ELEMENT_NAMES
            .iter()
            .find(|(_, elem)| elem == self)
            .expect("every non-Custom StatusElement variant has an ELEMENT_NAMES entry");
        f.write_str(name)
    }
}

impl FromStr for StatusElement {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        // `StatusElement::custom` also gates `set-statusline-text!`'s push
        // path (`host_impl.rs`): a name rejected there can never be placed
        // here, and vice versa.
        if let Some(name) = s.strip_prefix(CUSTOM_PREFIX) {
            return StatusElement::custom(name).map_err(|e| format!("unknown element '{s}': {e}"));
        }
        ELEMENT_NAMES
            .iter()
            .find(|(name, _)| *name == s)
            .map(|(_, elem)| elem.clone())
            .ok_or_else(|| {
                let mut names: Vec<&str> = ELEMENT_NAMES.iter().map(|(name, _)| *name).collect();
                names.sort_unstable();
                format!(
                    "unknown element '{s}'; valid names: {} (or '{CUSTOM_PREFIX}<name>' for a \
                     plugin-defined element)",
                    names.join(" ")
                )
            })
    }
}

/// Describes the content layout of the statusline's three sections.
///
/// Each section is a sequence of [`StatusElement`]s rendered in order. Adjacent
/// elements within a section are joined with a boundary-aware spacing rule so
/// that spacing feels natural without any element needing to hard-code its
/// neighbours.
///
/// The default config reproduces the built-in statusline layout exactly, so
/// the editor looks identical with no configuration:
///
/// ```text
/// 42:7 notes.txt              │ NOR
/// ```
#[derive(Debug, Clone)]
pub struct StatusLineConfig {
    /// Elements rendered left-aligned at the start of the statusline row.
    pub left: Vec<StatusElement>,
    /// Elements centered between the left and right sections. Empty by default.
    pub center: Vec<StatusElement>,
    /// Elements rendered right-aligned at the end of the statusline row.
    pub right: Vec<StatusElement>,
}

impl Default for StatusLineConfig {
    fn default() -> Self {
        Self {
            left: vec![
                StatusElement::Position,
                StatusElement::FilePath,
                StatusElement::Language,
                StatusElement::ReadOnly,
                StatusElement::DirtyIndicator,
            ],
            center: vec![],
            right: vec![
                StatusElement::Pipe,
                StatusElement::MacroRecording,
                StatusElement::SearchMatches,
                StatusElement::Diagnostics,
                StatusElement::KittyProtocol,
                StatusElement::Separator,
                StatusElement::Mode,
            ],
        }
    }
}

// ── Edge padding ─────────────────────────────────────────────────────────────

/// Prepend a 1-space padding span to the left section.
///
/// This gives every left section a consistent left margin without requiring
/// individual elements to be edge-aware.
fn pad_left<'a>(
    mut spans: Vec<(Cow<'a, str>, ResolvedStyle)>,
    colors: &EditorColors,
) -> Vec<(Cow<'a, str>, ResolvedStyle)> {
    if !spans.is_empty() {
        spans.insert(0, (Cow::Borrowed(" "), colors.statusline));
    }
    spans
}

/// Append a 1-space padding span to the right section.
///
/// Mirrors [`pad_left`] for the trailing edge; supplies the right-margin
/// offset used by the placement arithmetic.
fn pad_right<'a>(
    mut spans: Vec<(Cow<'a, str>, ResolvedStyle)>,
    colors: &EditorColors,
) -> Vec<(Cow<'a, str>, ResolvedStyle)> {
    if !spans.is_empty() {
        spans.push((Cow::Borrowed(" "), colors.statusline));
    }
    spans
}

// ── Drawing helpers ───────────────────────────────────────────────────────────

/// Total display-column width of a rendered section.
fn section_width(spans: &[(Cow<'_, str>, ResolvedStyle)]) -> u16 {
    spans
        .iter()
        .map(|(t, _)| chrome_width(t.as_ref()) as u16)
        .sum()
}

/// Draw a section's spans left-to-right starting at `x`.
fn draw_section(
    canvas: &mut Canvas,
    spans: &[(Cow<'_, str>, ResolvedStyle)],
    mut x: u16,
    y: u16,
    right_edge: u16,
) {
    for (text, style) in spans {
        // Advance by what the write consumed rather than re-measuring the
        // span: `write_text_run` returns the column it stopped at, and it
        // measures by the same rule `section_width` laid the spans out with,
        // so the two cannot drift apart.
        x = canvas.write_text_run(x, y, text.as_ref(), *style, right_edge);
    }
}

// ── Engine integration ────────────────────────────────────────────────────────

/// Short-lived statusline provider holding exactly the `Editor` fields the
/// statusline reads, rather than `&Editor`.
///
/// Created each frame and passed to `EngineView::render()`. No snapshot, no
/// Arc, no Mutex: it reads editor state on demand during the render call.
///
/// Narrow on purpose: `EngineView::render` takes `&mut self`, so a provider
/// holding `&Editor` would keep the whole editor (`view` included) borrowed
/// across it. The things here that come from `view` are the focused buffer's
/// id and the focused pane's selections and search cursor for it, read out
/// once up front.
pub(crate) struct HumeStatusline<'a> {
    pub(crate) state: &'a EditorState,
    pub(crate) kitty_enabled: bool,
    pub(crate) focused_bid: BufferId,
    pub(crate) focused_view: hume_editing::selection::EditView<'a>,
    pub(crate) focused_search_cursor: &'a crate::editor::search::SearchCursor,
}

impl HumeStatusline<'_> {
    /// The elements' accessors, mirroring the `Editor` methods of the same
    /// names so each element body reads identically either way.
    pub(in crate::statusline) fn focused_buffer_id(&self) -> BufferId {
        self.focused_bid
    }

    pub(in crate::statusline) fn doc(&self) -> &crate::editor::buffer::Buffer {
        self.state.buffers.get(self.focused_bid)
    }

    pub(in crate::statusline) fn current_view(&self) -> &hume_editing::selection::EditView<'_> {
        &self.focused_view
    }

    pub(in crate::statusline) fn current_search_cursor(
        &self,
    ) -> &crate::editor::search::SearchCursor {
        self.focused_search_cursor
    }

    pub(in crate::statusline) fn diagnostic_counts(&self, bid: BufferId) -> DiagnosticCounts {
        crate::editor::lsp::introspect::diagnostic_counts(self.state, bid, None)
    }

    pub(in crate::statusline) fn lsp_activity(
        &self,
        bid: BufferId,
    ) -> crate::editor::lsp::introspect::LspActivity {
        crate::editor::lsp::introspect::activity(self.state, bid)
    }

    pub(in crate::statusline) fn lsp_spinner_frame(&self) -> usize {
        crate::editor::lsp::introspect::spinner_frame(self.state)
    }
}

impl hume_engine::providers::ChromeProvider for HumeStatusline<'_> {
    fn render(&self, area: Rect, theme: &hume_engine::theme::Theme, canvas: &mut Canvas) {
        let editor = self;
        let mode = editor
            .state
            .settings
            .statusline_mode_colors
            .then(|| editor.state.mode());
        let colors = EditorColors::from_theme(theme, mode);
        let y = area.y;

        // An open confirm overlay (disk-change reload, …) owns the whole
        // row when it's still the one driving the keyboard. `EditorState::
        // confirm()` reads `Some` only while the confirm is `top()`: a
        // Steel-initiated push (a timer's `prompt!`) can otherwise land
        // above it without truncating it (`push_mode_layer` only truncates
        // the outgoing *mode* layer, never an overlay sitting on `Base`),
        // and rendering a buried confirm's row while the minibuffer above
        // it owns the keys would show the wrong prompt for what's actually
        // answerable right now.
        if let Some(confirm) = editor.state.confirm() {
            fill_row_colors(canvas, &colors, area, y);
            canvas.write_text_run(
                area.x + 1,
                y,
                &confirm.render_line(),
                colors.statusline,
                area.right(),
            );
            return;
        }

        if editor.state.minibuf().is_none() {
            // A fresh status_msg (set this frame) takes priority. Falling back
            // to the log summary keeps unseen-message context visible between
            // keypresses, without adding a separate status row.
            //
            // Evaluate summary_text lazily to avoid allocating a String every
            // frame when there is nothing to show.
            let summary;
            let display_msg: Option<&str> = if let Some(msg) = editor.state.status_msg.text() {
                Some(msg)
            } else {
                summary = editor
                    .state
                    .message_log
                    .summary_text(editor.state.settings.messages_min_severity);
                summary.as_deref()
            };

            if let Some(msg) = display_msg {
                fill_row_colors(canvas, &colors, area, y);
                canvas.write_text_run(area.x + 1, y, msg, colors.statusline, area.right());
                return;
            }
        }

        render_statusline(canvas, editor, &colors, area, y);
    }
}

fn fill_row_colors(canvas: &mut Canvas, colors: &EditorColors, area: Rect, y: u16) {
    canvas.fill_rect_bg(Rect::new(area.x, y, area.width, 1), colors.statusline);
}

fn render_statusline(
    canvas: &mut Canvas,
    editor: &HumeStatusline<'_>,
    colors: &EditorColors,
    area: Rect,
    y: u16,
) {
    let config = editor.state.settings.statusline();

    let (left_elems, center_elems, right_elems): (
        &[StatusElement],
        &[StatusElement],
        &[StatusElement],
    ) = if editor.state.minibuf().is_some() {
        (MINIBUF_LEFT, &[], &config.right)
    } else {
        (&config.left, &config.center, &config.right)
    };

    fill_row_colors(canvas, colors, area, y);

    // ── FilePath two-pass sizing ──────────────────────────────────────────────
    // The FilePath element is flexible: it shrinks when the row is narrow.
    // Measure pass: render with FilePath = "" to find the total fixed width.
    // Final pass: shorten the path to the remaining budget, then render for
    // real, but only the section(s) that actually place `FilePath`. It
    // contributes no width to a section that doesn't contain it, so that
    // section's measure-pass spans are already its final ones; re-rendering
    // it again would just reallocate every other element's `Cow` a second
    // time for an identical result.
    let filepath_full = elements::file_path::statusline_display_path(editor);
    // Outside the branch that sets it: the final spans borrow it.
    let filepath_display;
    let (left_spans, center_spans, right_spans) = if filepath_full.is_empty() {
        (
            pad_left(render_section(left_elems, editor, colors, ""), colors),
            render_section(center_elems, editor, colors, ""),
            pad_right(render_section(right_elems, editor, colors, ""), colors),
        )
    } else {
        let m_left = pad_left(render_section(left_elems, editor, colors, ""), colors);
        let m_center = render_section(center_elems, editor, colors, "");
        let m_right = pad_right(render_section(right_elems, editor, colors, ""), colors);
        let fixed_w = section_width(&m_left) as usize
            + section_width(&m_center) as usize
            + section_width(&m_right) as usize;
        // Subtract 1 for the inter-element space that render_section inserts
        // before a non-empty FilePath span (conservatively safe for all cases).
        let budget = (area.width as usize).saturating_sub(fixed_w + 1);
        filepath_display = elements::file_path::shorten_path_to_width(&filepath_full, budget);

        let left = if left_elems.contains(&StatusElement::FilePath) {
            pad_left(
                render_section(left_elems, editor, colors, &filepath_display),
                colors,
            )
        } else {
            m_left
        };
        let center = if center_elems.contains(&StatusElement::FilePath) {
            render_section(center_elems, editor, colors, &filepath_display)
        } else {
            m_center
        };
        let right = if right_elems.contains(&StatusElement::FilePath) {
            pad_right(
                render_section(right_elems, editor, colors, &filepath_display),
                colors,
            )
        } else {
            m_right
        };
        (left, center, right)
    };

    let left_w = section_width(&left_spans);
    let center_w = section_width(&center_spans);
    let right_w = section_width(&right_spans);

    let left_x = area.x;
    let left_end = left_x + left_w;
    let right_x = area.right().saturating_sub(right_w);
    let right_fits = right_x >= left_end;
    let right_fence = if right_fits { right_x } else { area.right() };
    let gap = right_fence.saturating_sub(left_end);
    // `Rect::centered`'s own rounding convention (bias up/left on an odd
    // remainder) rather than a second, independently-rounded formula.
    let center_x = Rect::new(left_end, y, gap, 1).centered(center_w, 1).x;
    let center_fits = !center_spans.is_empty()
        && center_w <= gap
        && center_x >= left_end
        && center_x + center_w <= right_fence;

    // Each section is bounded by whatever sits to its right: the left
    // section stops where the right one starts (or at the row's end when the
    // right section didn't fit), and the right section at the row's end. Only
    // `FilePath` shortens itself to fit, so without these an over-long
    // element would write across its neighbour and off the row.
    draw_section(canvas, &left_spans, left_x, y, right_fence);
    if right_fits {
        draw_section(canvas, &right_spans, right_x, y, area.right());
    }
    if center_fits {
        draw_section(canvas, &center_spans, center_x, y, right_fence);
    }
}

/// Crate-wide, not `pub(in crate::statusline)`: two independent test
/// suites call this directly by design (see the module doc split in
/// `editor::tests::lsp_statusline`): `statusline::tests` pins exact
/// glyphs/spacing with synthetic `Data`, `editor::tests::lsp_statusline`
/// checks that a live LSP diagnostics flow produces the right *counts*
/// without re-asserting their rendering. Pure formatting function, no
/// mutable state; the crossing carries no risk `pub(in ...)` would avoid.
pub(crate) fn render_element<'a>(
    seg: &StatusElement,
    editor: &'a HumeStatusline<'_>,
    colors: &EditorColors,
    // Pre-computed text for the FilePath element. "" = render as empty (measure
    // pass); any other string = use verbatim (already shortened by caller).
    filepath_text: &'a str,
) -> (Cow<'a, str>, ResolvedStyle) {
    match seg {
        StatusElement::Mode => ModeElement::render(editor, colors),
        StatusElement::Separator => SeparatorElement::render(editor, colors),
        StatusElement::FileName => FileNameElement::render(editor, colors),
        StatusElement::FilePath => elements::file_path::render(filepath_text, colors),
        StatusElement::Position => PositionElement::render(editor, colors),
        StatusElement::KittyProtocol => KittyProtocolElement::render(editor, colors),
        StatusElement::DirtyIndicator => DirtyIndicatorElement::render(editor, colors),
        StatusElement::LineEnding => LineEndingElement::render(editor, colors),
        StatusElement::Cwd => CwdElement::render(editor, colors),
        StatusElement::SearchMatches => SearchMatchesElement::render(editor, colors),
        StatusElement::MiniBuf => MiniBufElement::render(editor, colors),
        StatusElement::MacroRecording => MacroRecordingElement::render(editor, colors),
        StatusElement::Pipe => PipeElement::render(editor, colors),
        StatusElement::Language => LanguageElement::render(editor, colors),
        StatusElement::ReadOnly => ReadOnlyElement::render(editor, colors),
        StatusElement::Diagnostics => DiagnosticsElement::render(editor, colors),
        StatusElement::Custom(name) => elements::custom::render(editor, name, colors),
    }
}

fn render_section<'a>(
    elements: &[StatusElement],
    editor: &'a HumeStatusline<'_>,
    colors: &EditorColors,
    filepath_text: &'a str,
) -> Vec<(Cow<'a, str>, ResolvedStyle)> {
    let mut spans: Vec<(Cow<'a, str>, ResolvedStyle)> = Vec::with_capacity(elements.len() * 2);

    for seg in elements {
        let (text, style) = render_element(seg, editor, colors, filepath_text);
        if text.is_empty() {
            continue;
        }

        if let Some((prev_text, _)) = spans.last() {
            let a_ends_space = prev_text.ends_with(' ');
            let b_starts_space = text.starts_with(' ');

            if !a_ends_space && !b_starts_space {
                spans.push((Cow::Borrowed(" "), colors.statusline));
                spans.push((text, style));
            } else if a_ends_space && b_starts_space {
                let trimmed = match text {
                    Cow::Borrowed(s) => Cow::Borrowed(s.strip_prefix(' ').unwrap_or(s)),
                    Cow::Owned(mut s) => {
                        s.drain(..1);
                        Cow::Owned(s)
                    }
                };
                spans.push((trimmed, style));
            } else {
                spans.push((text, style));
            }
        } else {
            spans.push((text, style));
        }
    }

    spans
}

#[cfg(test)]
mod tests;
