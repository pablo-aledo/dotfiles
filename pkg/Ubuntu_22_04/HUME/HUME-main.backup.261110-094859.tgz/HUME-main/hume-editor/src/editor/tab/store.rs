//! Per-editor tab store: the display order of every open tab page and the
//! stashed window layout of every inactive one.
//!
//! A "tab" here is Vim's sense: a saved window layout (its own
//! [`FocusedLayout`]: a tree and its focused pane), not a per-buffer strip. Panes are
//! never shared across tabs, but all live in the single global pool
//! (`EngineView::panes`) regardless of which tab is active. Only which
//! panes a tab's `LayoutTree` *reaches* differs.
//! The fields are private to this file, and the methods that move a layout
//! in or out are private to `editor::tab`, whose functions pair each with
//! the `EngineView` side of the exchange.

use slotmap::{SecondaryMap, SlotMap, new_key_type};

use hume_core::PaneId;
use hume_engine::pipeline::{Cycle, FocusedLayout};

new_key_type! {
    /// Opaque handle to a tab. Minted only in `hume-editor`: the engine has
    /// no notion of tabs, only of the one `LayoutTree` currently active.
    /// `pub(crate)`, wider than the rest of this module: `crate::tabline`
    /// (a sibling of `editor`, matching where `crate::statusline` lives;
    /// see that module's own doc) holds and displays `TabId`s built by
    /// `EditorState::sync_tabline_view` (`frame.rs`), so the type must be
    /// visible on both sides of that boundary.
    pub(crate) struct TabId;
}

/// Refusal of `tab::close_tab`: the current tab is the only one.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::editor) struct SingleTab;

/// Display/cycle order for every open tab, and the layout of each one not
/// on screen. The active tab's layout lives in `EngineView` instead, so
/// every layout exists once.
///
/// A switch moves layouts rather than copying them: the caller installs the
/// incoming layout in `EngineView` (an existing tab's comes out of here
/// through [`Self::take`]), which hands back the outgoing one, then finishes
/// with [`Self::switch`], [`Self::open_after_current`] or
/// [`Self::close_current`]. Between `take` and that call, the taken tab has
/// a layout in neither place.
pub(in crate::editor) struct TabStore {
    order: Vec<TabId>,
    current: TabId,
    ids: SlotMap<TabId, ()>,
    stash: SecondaryMap<TabId, FocusedLayout>,
}

impl TabStore {
    /// A single-tab store whose one tab is the layout already live in
    /// `EngineView`.
    pub(in crate::editor) fn new() -> Self {
        let mut ids = SlotMap::with_key();
        let id = ids.insert(());
        Self {
            order: vec![id],
            current: id,
            ids,
            stash: SecondaryMap::new(),
        }
    }

    pub(in crate::editor) fn current(&self) -> TabId {
        self.current
    }

    /// Display/cycle order: every tab, including the active one.
    #[cfg(test)]
    pub(in crate::editor) fn order(&self) -> &[TabId] {
        &self.order
    }

    pub(in crate::editor) fn len(&self) -> usize {
        self.order.len()
    }

    /// Every tab in display order with its focused pane, reading the active
    /// tab's from `live` (`EngineView::focused_layout`).
    pub(in crate::editor) fn focused_panes<'a>(
        &'a self,
        live: &'a FocusedLayout,
    ) -> impl Iterator<Item = (TabId, PaneId)> {
        self.layouts(live)
            .map(|(id, layout)| (id, layout.focused()))
    }

    /// Every tab with its layout in display order, reading the active tab's
    /// from `live` (`EngineView::focused_layout`).
    pub(in crate::editor) fn layouts<'a>(
        &'a self,
        live: &'a FocusedLayout,
    ) -> impl Iterator<Item = (TabId, &'a FocusedLayout)> {
        self.order.iter().map(move |&id| {
            let layout = if id == self.current {
                live
            } else {
                &self.stash[id]
            };
            (id, layout)
        })
    }

    /// `current`'s index in `order`. Every method below that needs it reads
    /// this instead of taking a caller-supplied id: `TabStore` reads its
    /// own `current` field, so a missing position would mean `order` and
    /// `current` had already gone out of sync, the corruption
    /// `open_after_current`'s own insert below would otherwise mask instead
    /// of failing loudly.
    ///
    /// `pub(in crate::editor)` rather than private: `EditorState::sync_tabline_view`
    /// needs the same index. It reads it from here rather than re-deriving it
    /// from `order()`/`current()` separately, which would let the tabline's
    /// own copy silently drift from this one's panic message the moment
    /// either changes.
    pub(in crate::editor) fn current_pos(&self) -> usize {
        self.order
            .iter()
            .position(|&t| t == self.current)
            .expect("current tab is always present in order")
    }

    /// Move inactive tab `id`'s layout out, for the caller to install in
    /// `EngineView` before finishing the switch (see the struct doc).
    pub(in crate::editor::tab) fn take(&mut self, id: TabId) -> FocusedLayout {
        self.stash
            .remove(id)
            .expect("only an inactive tab is taken, and only once")
    }

    /// Stash `outgoing`, the layout `EngineView` displaced, as the current
    /// tab's, and make `target` current. `target`'s layout was taken first.
    pub(in crate::editor::tab) fn switch(&mut self, outgoing: FocusedLayout, target: TabId) {
        self.stash_current(outgoing);
        self.current = target;
    }

    /// Stash `outgoing` as the current tab's (same as [`Self::switch`]),
    /// allocate a fresh id for the new tab whose layout `EngineView` now
    /// holds, insert it into `order` right after `current` (Vim's `:tabnew`
    /// placement), and make it current.
    pub(in crate::editor::tab) fn open_after_current(&mut self, outgoing: FocusedLayout) -> TabId {
        let pos = self.current_pos() + 1;
        self.stash_current(outgoing);
        let id = self.ids.insert(());
        self.order.insert(pos, id);
        self.current = id;
        id
    }

    fn stash_current(&mut self, outgoing: FocusedLayout) {
        let replaced = self.stash.insert(self.current, outgoing);
        assert!(replaced.is_none(), "the active tab has no stashed layout");
    }

    /// The refusal closing `current` gives, without closing anything: `Err`
    /// when it is the only tab.
    pub(in crate::editor) fn refuse_close(&self) -> Result<(), SingleTab> {
        if self.order.len() == 1 {
            return Err(SingleTab);
        }
        Ok(())
    }

    /// The tab that should gain focus once `current` closes: its right
    /// neighbour, or its left one when `current` is already the rightmost
    /// tab (Vim's own `:tabclose` placement: adjacent, never a wrap to the
    /// far end). Refused when `current` is the only tab.
    pub(in crate::editor::tab) fn adjacent(&self) -> Result<TabId, SingleTab> {
        self.refuse_close()?;
        let pos = self.current_pos();
        let neighbor = if pos + 1 < self.order.len() {
            pos + 1
        } else {
            pos - 1
        };
        Ok(self.order[neighbor])
    }

    /// Remove `current` from the store and make `survivor`, the
    /// [`Self::adjacent`] tab whose layout was taken first, current.
    pub(in crate::editor::tab) fn close_current(&mut self, survivor: TabId) {
        let closed = self.current;
        self.order.retain(|&t| t != closed);
        self.ids.remove(closed);
        self.current = survivor;
    }

    /// The tab one step from the current one in display order, wrapping at
    /// either end. Returns `current()` if only one tab is open.
    pub(in crate::editor) fn step(&self, cycle: Cycle) -> TabId {
        self.order[cycle.step(self.current_pos(), self.order.len())]
    }
}

#[cfg(test)]
mod tests;
