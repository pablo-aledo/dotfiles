//! Jump list: a navigable history of cursor positions before large movements.
//!
//! Records the cursor position (as a full [`SelectionSet`]) before "jump"
//! commands like `goto-first-line`, `goto-last-line`, `search-next`,
//! `search-prev`, page scroll, buffer switches, and any motion that crosses
//! more than `EditorSettings::jump_list_min_lines` lines. The user navigates
//! the history with `jump-backward` and `jump-forward`.
//!
//! Internally this is a [`VecDeque<JumpEntry>`] with a cursor index, capped
//! at `EditorSettings::jump_list_capacity`. When the user navigates backward
//! and then makes a new jump, forward history is truncated, matching
//! Vim/Helix semantics.

use std::collections::VecDeque;

use hume_core::{BufferId, PaneId};
use hume_engine::pipeline::EngineView;

use hume_editing::edit::TextChange;
use hume_editing::selection::{EditView, Selection, SelectionSet};
use hume_editing::state::EditState;
use hume_editing::text::BufferText;

use super::commands::{CommandPane, pane_view};
use super::{Editor, EditorState};

/// Default capacity, used in tests to construct jump lists without importing `EditorSettings`.
#[cfg(test)]
pub(in crate::editor::jump_list) const DEFAULT_JUMP_LIST_CAPACITY: usize = 100;

/// A single saved cursor position in the jump list.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::editor) struct JumpEntry {
    /// Buffer this position belongs to, needed for cross-buffer Ctrl-o/I.
    pub buffer_id: BufferId,
    /// Full selection state at the moment of the jump.
    pub selections: SelectionSet,
    /// Line number of the primary selection's head, cached for O(1) dedup.
    pub primary_line: hume_rope::line::ContentLine,
}

impl JumpEntry {
    /// `primary_line`'s one derivation: the primary selection's head, resolved
    /// to a line via `text`.
    fn primary_line_of(
        selections: &SelectionSet,
        text: &BufferText,
    ) -> hume_rope::line::ContentLine {
        EditView::bind(text, selections).primary().head_line()
    }

    /// The primary selection, read against `text`, the text these selections
    /// belong to.
    pub(in crate::editor) fn primary_selection(&self, text: &BufferText) -> Selection {
        EditView::bind(text, &self.selections).primary().selection()
    }

    /// Carry this entry through `change`, keeping `primary_line` in step.
    fn translate(&mut self, change: &TextChange<'_>) {
        let head = self.selections.translate(change);
        self.primary_line = change.after().char_to_line(head.offset());
    }

    /// Build a jump entry from selections of `text`, the buffer's current
    /// text, deriving `primary_line` from it so callers don't have to.
    pub(in crate::editor) fn new(
        selections: SelectionSet,
        text: &BufferText,
        buffer_id: BufferId,
    ) -> Self {
        let primary_line = Self::primary_line_of(&selections, text);
        Self {
            buffer_id,
            selections,
            primary_line,
        }
    }
}

/// Navigable history of cursor positions before large movements.
///
/// `cursor` indexes into `entries`. When `cursor == entries.len()`, the user
/// is "at the present": no backward navigation is active. Navigating backward
/// decrements cursor; navigating forward increments it. A new `push` truncates
/// any forward history (entries after cursor) before appending.
#[derive(Debug)]
pub(in crate::editor) struct JumpList {
    entries: VecDeque<JumpEntry>,
    /// Current position. `cursor == entries.len()` means "at the present".
    cursor: usize,
    /// Maximum number of entries. Oldest entry is dropped when exceeded.
    capacity: usize,
    /// Entries captured before a navigation that may edit their buffer, one
    /// per open [`PendingJump`], innermost last. They are carried through
    /// edits like `entries`, but belong to no history until pushed.
    pending: Vec<Option<JumpEntry>>,
}

/// A clone is a history snapshot: the pending captures belong to navigations
/// running against the original, and their handles index the original's
/// list.
impl Clone for JumpList {
    fn clone(&self) -> Self {
        Self {
            entries: self.entries.clone(),
            cursor: self.cursor,
            capacity: self.capacity,
            pending: Vec::new(),
        }
    }
}

/// A position captured before a navigation, held by its [`JumpList`] until
/// [`JumpList::end_pending`] takes it back.
#[must_use = "a pending jump stays in its list until `end_pending` takes it"]
#[derive(Debug)]
struct PendingJump(usize);

impl JumpList {
    /// Create a new jump list with the given capacity limit.
    ///
    /// `capacity == 0` is a silent black hole (every `push` immediately
    /// evicts what it just pushed) rather than a documented "unlimited",
    /// unlike `undo-levels`, where `0` means exactly that. The settings
    /// parser (`UsizeNonzero`) already rejects `0` for `jump-list-capacity`
    /// before it can reach here; this just makes the trap loud if that
    /// guard is ever bypassed (a test constructing a `JumpList` directly).
    pub(in crate::editor) fn new(capacity: usize) -> Self {
        debug_assert!(capacity > 0, "JumpList capacity must be non-zero");
        Self {
            entries: VecDeque::new(),
            cursor: 0,
            capacity,
            pending: Vec::new(),
        }
    }

    /// A list holding `entries`, oldest first, standing at `cursor` in them
    /// (`entries.len()` at the present), as an earlier run left it. Past
    /// `capacity` the oldest entries drop and the cursor moves with them.
    pub(in crate::editor) fn resumed(
        capacity: usize,
        entries: Vec<JumpEntry>,
        cursor: usize,
    ) -> Self {
        debug_assert!(capacity > 0, "JumpList capacity must be non-zero");
        debug_assert!(cursor <= entries.len(), "the cursor stands within the list");
        let dropped = entries.len().saturating_sub(capacity);
        Self {
            entries: entries.into_iter().skip(dropped).collect(),
            cursor: cursor.saturating_sub(dropped),
            capacity,
            pending: Vec::new(),
        }
    }

    /// Change the capacity limit. Takes effect on the *next* `push`, not
    /// immediately, matching Vim's `undolevels` semantics (see
    /// `hume_editing::history::UndoTree::set_undo_levels`): lowering the cap
    /// does not retroactively trim existing entries. No cursor adjustment is
    /// needed here, since no entries are removed by this call.
    pub(in crate::editor) fn set_capacity(&mut self, capacity: usize) {
        debug_assert!(capacity > 0, "JumpList capacity must be non-zero");
        self.capacity = capacity;
    }

    /// Record a jump. Truncates forward history, deduplicates against the
    /// last entry by line number, and caps the list at `self.capacity`: a
    /// `while`, not an `if`, so a `set_capacity` shrink of any size converges
    /// to the new cap in this one call rather than one entry per push.
    pub(in crate::editor) fn push(&mut self, entry: JumpEntry) {
        self.entries.truncate(self.cursor);

        // Deduplicate against the immediately preceding entry only, by (line,
        // buffer); cross-buffer same-line entries are distinct.
        match self
            .entries
            .back_mut()
            .filter(|l| l.primary_line == entry.primary_line && l.buffer_id == entry.buffer_id)
        {
            Some(last) => *last = entry,
            None => self.entries.push_back(entry),
        }

        while self.entries.len() > self.capacity {
            self.entries.pop_front();
        }

        self.cursor = self.entries.len();
    }

    /// Remove all entries for `id`. Adjusts the cursor so its relative position
    /// in the remaining entries is preserved, `entries.len()` staying "at the
    /// present".
    pub(in crate::editor) fn prune_buffer(&mut self, id: BufferId) {
        let (entries, cursor) = kept_with_cursor(
            self.entries
                .drain(..)
                .map(|e| (e.buffer_id != id).then_some(e)),
            self.cursor,
        );
        self.entries = entries.into();
        self.cursor = cursor;
        for slot in &mut self.pending {
            if slot.as_ref().is_some_and(|e| e.buffer_id == id) {
                *slot = None;
            }
        }
    }

    /// Hold `entry` until the navigation it precedes is over. The list carries
    /// it through any edit that navigation makes, so it still names the text
    /// it was captured from when [`Self::end_pending`] returns it.
    fn begin_pending(&mut self, entry: JumpEntry) -> PendingJump {
        self.pending.push(Some(entry));
        PendingJump(self.pending.len() - 1)
    }

    /// The entry `pending` held, carried through every edit since; `None` when
    /// its buffer was replaced meanwhile. Also drops any pending entry begun
    /// after it and never ended.
    fn end_pending(&mut self, pending: PendingJump) -> Option<JumpEntry> {
        let entry = self.pending.get_mut(pending.0).and_then(Option::take);
        self.pending.truncate(pending.0);
        entry
    }

    /// Remap every entry for `buf_id` through an edit, keeping stored
    /// positions pointing at the same text rather than the same offset, and
    /// merge any two adjacent entries an edit has newly collapsed onto one
    /// line. Other buffers' entries are untouched, and never merge because
    /// their lines don't change.
    ///
    /// Each entry runs its own `PosMapCursor`: entries aren't sorted relative
    /// to each other, so one shared forward cursor can't walk them. That costs
    /// `O(entries × ops)` for large changesets (`:%s`, multi-cursor, format).
    /// Selections within an entry are sorted and do share one cursor.
    ///
    /// The change's new text recomputes each entry's cached `primary_line`.
    ///
    /// Merging is write-index compaction in the same pass (swaps, no
    /// allocation). Only a pair whose lines differed before the edit and match
    /// after it merges, keeping the newer entry as `push` does. Pre-existing
    /// same-line pairs survive, since `backward()` appends them on purpose so
    /// `forward()` can return. The cursor shifts by the number of merged-away
    /// entries before it, as in `prune_buffer`.
    pub(in crate::editor) fn translate_in_place(
        &mut self,
        buf_id: BufferId,
        change: &TextChange<'_>,
    ) {
        for entry in self.pending.iter_mut().flatten() {
            if entry.buffer_id == buf_id {
                entry.translate(change);
            }
        }

        let mut write = 0usize;
        let mut removed_before_cursor = 0usize;
        // (buffer_id, pre-remap line, post-remap line, original index) of the
        // entry currently kept at slot `write - 1`.
        let mut last: Option<(
            BufferId,
            hume_rope::line::ContentLine,
            hume_rope::line::ContentLine,
            usize,
        )> = None;

        for read in 0..self.entries.len() {
            let bid = self.entries[read].buffer_id;
            let pre_line = self.entries[read].primary_line;
            if bid == buf_id {
                self.entries[read].translate(change);
            }
            let post_line = self.entries[read].primary_line;

            if let Some((lbid, lpre, lpost, lread)) = last
                && lbid == bid
                && lpost == post_line
                && lpre != pre_line
            {
                // A collision this edit just created: overwrite the older
                // entry's slot with this one.
                write -= 1;
                removed_before_cursor += usize::from(lread < self.cursor);
            }
            self.entries.swap(write, read);
            last = Some((bid, pre_line, post_line, read));
            write += 1;
        }
        self.entries.truncate(write);
        self.cursor = self
            .cursor
            .saturating_sub(removed_before_cursor)
            .min(self.entries.len());
    }

    /// Navigate backward. If at the present, saves `current` first so that
    /// `forward()` can return to it. Returns the entry to restore, or `None`
    /// if the list is empty / already at the oldest entry.
    pub(in crate::editor) fn backward(&mut self, current: JumpEntry) -> Option<&JumpEntry> {
        if self.entries.is_empty() {
            return None;
        }

        // At the present: always save the current position so `jump-forward`
        // can return to it. No dedup here. Unlike `push()`, the "save current"
        // path must preserve the exact return point even if it's on the same
        // line as the last recorded jump (e.g., two search matches on one line).
        if self.cursor == self.entries.len() {
            self.entries.push_back(current);
            // Same cap enforcement as `push()`: this is the list's other
            // append site, and without it a list already at capacity grows
            // to `capacity + 1` here (capacity stops being an invariant of
            // the type). `while`, matching `push`, for the same
            // shrink-converges-in-one-call reasoning.
            while self.entries.len() > self.capacity {
                self.entries.pop_front();
            }
            self.cursor = self.entries.len() - 1;
        }

        if self.cursor == 0 {
            return None;
        }

        self.cursor -= 1;
        Some(&self.entries[self.cursor])
    }

    /// Navigate forward. Returns the next entry, or `None` if already at the
    /// present.
    pub(in crate::editor) fn forward(&mut self) -> Option<&JumpEntry> {
        if self.cursor + 1 >= self.entries.len() {
            return None;
        }
        self.cursor += 1;
        Some(&self.entries[self.cursor])
    }

    /// The entries, oldest first, and where the list stands in them:
    /// `entries.len()` at the present.
    pub(in crate::editor) fn history(&self) -> (&VecDeque<JumpEntry>, usize) {
        (&self.entries, self.cursor)
    }

    #[cfg(test)]
    pub(in crate::editor) fn len(&self) -> usize {
        self.entries.len()
    }

    /// Returns `true` if any entry in the list belongs to `id`.
    #[cfg(test)]
    pub(in crate::editor) fn entries_for_buffer(&self, id: BufferId) -> bool {
        self.entries.iter().any(|e| e.buffer_id == id)
    }
}

/// What a navigation records in the pane's jump list, and when. A command
/// declares it at registration and its dispatcher applies it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::editor) enum JumpRule {
    /// The whole selection set, whenever the pane's buffer or selections
    /// changed. Every goto and buffer switch records this.
    Selections,
    /// The primary selection only, whenever the buffer or that selection
    /// changed: search, page scroll, `select-all`.
    Primary,
    /// The primary selection only, when it changed and its line moved
    /// further than `EditorSettings::jump_list_min_lines`: any other
    /// motion. Selection commands never get it: a large text-object
    /// selection is a select-then-act staging step, not navigation.
    PrimaryPastThreshold,
}

/// Snapshot `t`'s pane's current selections as a `JumpEntry`.
pub(in crate::editor) fn current_jump_entry(
    state: &EditorState,
    view: &EngineView,
    t: CommandPane,
) -> JumpEntry {
    let bid = t.bid(view);
    let sels = t.state(&state.panes.entries, view).selections().clone();
    JumpEntry::new(sels, state.buffers.get(bid).text(), bid)
}

/// Runs `body`, a navigation of `t`'s pane, and records where it started in
/// the pane's jump list according to `rule`. Returns `body`'s result and
/// whether the pane moved (its buffer, or the selections `rule` compares,
/// changed). See [`JumpCapture`] for how the start is held and
/// recorded.
///
/// The only recorder: the entry point that runs a navigation (the key
/// pipeline, the `:` dispatcher, the buffer drawer, `switch-to-buffer!`, a
/// goto landing) calls it, and the switch and landing primitives it wraps
/// record nothing themselves.
pub(in crate::editor) fn with_jump<R>(
    state: &mut EditorState,
    view: &mut EngineView,
    t: CommandPane,
    rule: JumpRule,
    body: impl FnOnce(&mut EditorState, &mut EngineView) -> R,
) -> (R, bool) {
    let capture = JumpCapture::begin(state, view, t, rule);
    let result = body(state, view);
    (result, capture.finish(state, view))
}

impl Editor {
    /// [`with_jump`] for a body that needs the whole editor, such as a native
    /// typed command run from `:`.
    pub(in crate::editor) fn with_jump<R>(
        &mut self,
        t: CommandPane,
        rule: JumpRule,
        body: impl FnOnce(&mut Self) -> R,
    ) -> R {
        let capture = JumpCapture::begin(&mut self.state, &self.view, t, rule);
        let result = body(self);
        capture.finish(&mut self.state, &self.view);
        result
    }
}

/// A navigation's starting position, held by the pane's jump list from
/// [`Self::begin`] until [`Self::finish`] records it. While held, an edit the
/// navigation makes to that buffer (leaving Insert trims auto-indent)
/// carries it, so it still names the text it was captured from.
#[must_use = "the start stays pending in the pane's jump list until `finish` takes it"]
struct JumpCapture {
    pid: PaneId,
    pre_bid: BufferId,
    rule: JumpRule,
    pending: PendingJump,
}

impl JumpCapture {
    /// Capture where `t`'s pane stands under `rule`.
    ///
    /// An Insert session's typed run on the pane is invalidated here: it
    /// would otherwise select across text the cursor jumped away from once
    /// Insert exits. Done before the navigation, since an entry command
    /// (`i`/`a`/`o`/`c`) has opened its session by the time its own body
    /// returns and would wipe the pins `begin_typed_run` just installed.
    fn begin(state: &mut EditorState, view: &EngineView, t: CommandPane, rule: JumpRule) -> Self {
        let pid = t.pid();
        let pre_bid = t.bid(view);
        let entry = match rule {
            JumpRule::Selections => current_jump_entry(state, view, t),
            JumpRule::Primary | JumpRule::PrimaryPastThreshold => {
                let text = state.buffers.get(pre_bid).text();
                let selections = t.state(&state.panes.entries, view).selections().clone();
                JumpEntry::new(
                    EditState::bind(text.clone(), selections)
                        .keep_primary()
                        .into_selections(),
                    text,
                    pre_bid,
                )
            }
        };
        if let Some(insert) = state
            .input
            .insert_session_mut()
            .filter(|s| s.owned_by(pid, pre_bid))
        {
            insert.typed_run = None;
        }
        let pending = state.panes.entries[pid].jumps.begin_pending(entry);
        Self {
            pid,
            pre_bid,
            rule,
            pending,
        }
    }

    /// Record the start if the pane moved, and return whether it did.
    ///
    /// `moved` guards every push: `JumpList::push` truncates forward history
    /// unconditionally, so a navigation that turned out to be a no-op (`:42`
    /// already on line 42, `goto-first-line` already on line 1, a search
    /// confirmed on the match already under the cursor) must not push at
    /// all. The whole `Selection` is compared, not just its head:
    /// `select-all` from the buffer's own last char moves only the anchor.
    /// A pane the navigation closed has no list left to record in.
    fn finish(self, state: &mut EditorState, view: &EngineView) -> bool {
        let Self {
            pid,
            pre_bid,
            rule,
            pending,
        } = self;
        let Some(t) = CommandPane::existing(view, pid) else {
            return false;
        };
        let entry = state.panes.entries[pid].jumps.end_pending(pending);
        let post_bid = t.bid(view);
        match (rule, entry) {
            (JumpRule::Selections, Some(entry)) => record_if_moved(state, view, t, entry),
            (rule @ (JumpRule::Primary | JumpRule::PrimaryPastThreshold), Some(entry)) => {
                let post = pane_view(state, view, t).primary();
                let moved = post_bid != pre_bid
                    || entry.primary_selection(state.buffers.get(pre_bid).text())
                        != post.selection();
                if moved
                    && (rule == JumpRule::Primary
                        || entry.primary_line.abs_diff(post.head_line())
                            > state.settings.jump_list_min_lines)
                {
                    state.panes.entries[pid].jumps.push(entry);
                }
                moved
            }
            (_, None) => post_bid != pre_bid,
        }
    }
}

/// Pushes `pre`, a position captured before some navigation however long
/// ago, when `t`'s buffer or selections have changed since. Returns whether
/// they did. [`with_jump`]'s `Selections` rule, and the one entry point for a
/// navigation whose start was captured outside a single call (a search
/// confirmed after many keystrokes).
pub(in crate::editor) fn record_if_moved(
    state: &mut EditorState,
    view: &EngineView,
    t: CommandPane,
    pre: JumpEntry,
) -> bool {
    let moved = pre.buffer_id != t.bid(view)
        || pre.selections != *t.state(&state.panes.entries, view).selections();
    if moved {
        state.panes.entries[t.pid()].jumps.push(pre);
    }
    moved
}

/// The `Some` items of `items`, and where `cursor`, a place in `items`,
/// stands among them: after every kept item before it. A cursor at
/// `items`' end lands at the kept items' end.
pub(in crate::editor) fn kept_with_cursor<T>(
    items: impl IntoIterator<Item = Option<T>>,
    cursor: usize,
) -> (Vec<T>, usize) {
    let mut kept = Vec::new();
    let mut kept_cursor = 0;
    for (i, item) in items.into_iter().enumerate() {
        if let Some(item) = item {
            if i < cursor {
                kept_cursor += 1;
            }
            kept.push(item);
        }
    }
    (kept, kept_cursor)
}

#[cfg(test)]
mod tests;
