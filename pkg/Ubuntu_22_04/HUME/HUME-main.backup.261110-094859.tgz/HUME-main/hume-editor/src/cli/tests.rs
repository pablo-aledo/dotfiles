use super::*;
use std::cell::Cell;

// `tmp.path().join(name)` below is guaranteed absent from disk: `tmp` is a
// freshly created, otherwise empty tempdir.

#[test]
fn literal_probe_is_skipped_without_a_suffix() {
    let calls = Cell::new(0);
    let result = split_path_position("foo.rs", |_| {
        calls.set(calls.get() + 1);
        false
    });
    assert_eq!(result, Ok(("foo.rs", None)));
    assert_eq!(
        calls.get(),
        0,
        "no :<digits> suffix means nothing to disambiguate, so literal_exists must not run"
    );
}

#[test]
fn line_only_suffix() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs:12");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(tmp.path().join("foo.rs")));
    assert_eq!(
        parsed.pos,
        Some(PathPosition {
            line: hume_rope::line::ContentLine::from_number(12).unwrap(),
            grapheme_col: GraphemeCol::from_number(1).unwrap()
        })
    );
}

#[test]
fn line_and_column_suffix() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs:12:24");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(tmp.path().join("foo.rs")));
    assert_eq!(
        parsed.pos,
        Some(PathPosition {
            line: hume_rope::line::ContentLine::from_number(12).unwrap(),
            grapheme_col: GraphemeCol::from_number(24).unwrap()
        })
    );
}

#[test]
fn trailing_colon_is_tolerated() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs:12:");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(tmp.path().join("foo.rs")));
    assert_eq!(
        parsed.pos,
        Some(PathPosition {
            line: hume_rope::line::ContentLine::from_number(12).unwrap(),
            grapheme_col: GraphemeCol::from_number(1).unwrap()
        })
    );
}

#[test]
fn no_suffix_is_a_plain_path() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(&arg));
    assert_eq!(parsed.pos, None);
}

#[test]
fn non_digit_suffix_is_a_literal_path() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs:abc");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(&arg));
    assert_eq!(parsed.pos, None);
}

#[test]
fn bare_colon_number_with_no_path_is_literal() {
    let tmp = tempfile::tempdir().unwrap();
    // `tmp.path().join(":12")` is `/tmp/…/:12`: rsplit_once(':') leaves a
    // remainder ending in the path separator (`/tmp/…/`), which
    // `split_trailing_number`'s `rest.ends_with(is_separator)` check rejects
    // as naming no file. A relative `":12"` (remainder truly empty, not just
    // separator-terminated) exercises the check's other arm; see
    // `relative_bare_colon_number_is_literal` below.
    let arg = tmp.path().join(":12");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(&arg));
    assert_eq!(parsed.pos, None);
}

#[test]
fn relative_bare_colon_number_is_literal() {
    // A *relative* ":12" (no directory component at all, unlike
    // `tmp.path().join(":12")` above) is the shape that actually leaves
    // `split_trailing_number`'s `rsplit_once(':')` remainder empty,
    // exercising `rest.is_empty()` rather than `rest.ends_with(is_separator)`.
    let arg = PathBuf::from(":12");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(std::env::temp_dir())).unwrap();
    assert_eq!(
        parsed.path,
        AbsolutePath::rooted(std::env::temp_dir().join(&arg))
    );
    assert_eq!(parsed.pos, None);
}

#[test]
fn line_zero_is_rejected() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs:0");
    let err = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap_err();
    assert!(err.contains(LINE_NUMBERS_START_AT_1), "got: {err}");
    assert!(
        err.contains(&arg.display().to_string()),
        "error must name the offending argument, got: {err}"
    );
}

#[test]
fn column_zero_is_rejected() {
    let tmp = tempfile::tempdir().unwrap();
    let arg = tmp.path().join("foo.rs:12:0");
    let err = parse_file_arg(&arg, &AbsolutePath::rooted(tmp.path())).unwrap_err();
    // A valid line paired with a bad column must not blame the line: the
    // two 1-based contracts get distinct error text.
    assert!(err.contains(GRAPHEME_COL_NUMBERS_START_AT_1), "got: {err}");
    assert!(
        !err.contains(LINE_NUMBERS_START_AT_1),
        "line was valid, must not be blamed, got: {err}"
    );
    assert!(
        err.contains(&arg.display().to_string()),
        "error must name the offending argument, got: {err}"
    );
}

#[cfg(unix)]
#[test]
fn a_real_file_named_with_a_colon_opens_literally() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("weird:12");
    std::fs::write(&path, "hello\n").unwrap();
    let parsed = parse_file_arg(&path, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(&path));
    assert_eq!(
        parsed.pos, None,
        "an existing literal path must never be split"
    );
}

#[cfg(unix)]
#[test]
fn a_broken_symlink_named_with_a_colon_opens_literally() {
    // `symlink_metadata` (not `.exists()`, which follows symlinks and would
    // report this one absent) is the deliberate disambiguation probe here:
    // a dangling symlink still names a path the user chose on disk, so it
    // must win over splitting the same as a real file does.
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("weird:12");
    std::os::unix::fs::symlink(tmp.path().join("does-not-exist-target"), &path).unwrap();
    let parsed = parse_file_arg(&path, &AbsolutePath::rooted(tmp.path())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(&path));
    assert_eq!(
        parsed.pos, None,
        "a broken symlink still counts as the user's chosen path: must never be split"
    );
}

#[cfg(unix)]
#[test]
fn non_utf8_path_is_always_literal() {
    use std::ffi::OsStr;
    use std::os::unix::ffi::OsStrExt;

    let raw = OsStr::from_bytes(b"weird-\xff-path:12");
    let path = PathBuf::from(raw);
    let parsed = parse_file_arg(&path, &AbsolutePath::rooted(std::env::temp_dir())).unwrap();
    assert_eq!(
        parsed.path,
        AbsolutePath::rooted(std::env::temp_dir().join(&path))
    );
    assert_eq!(parsed.pos, None);
}

#[cfg(windows)]
#[test]
fn bare_drive_letter_is_not_split_as_a_position() {
    // Split, `C` would be an ordinary file name; unsplit, `C:12` is
    // drive-relative and cannot be made absolute.
    let arg = PathBuf::from("C:12");
    let err = parse_file_arg(&arg, &AbsolutePath::rooted(std::env::temp_dir())).unwrap_err();
    assert!(err.starts_with("C:12: "), "got: {err}");
}

#[cfg(windows)]
#[test]
fn drive_absolute_path_with_line_suffix_splits_normally() {
    let arg = PathBuf::from(r"C:\src\a.rs:12");
    let parsed = parse_file_arg(&arg, &AbsolutePath::rooted(std::env::temp_dir())).unwrap();
    assert_eq!(parsed.path, AbsolutePath::rooted(r"C:\src\a.rs"));
    assert_eq!(
        parsed.pos,
        Some(PathPosition {
            line: hume_rope::line::ContentLine::from_number(12).unwrap(),
            grapheme_col: GraphemeCol::from_number(1).unwrap()
        })
    );
}
