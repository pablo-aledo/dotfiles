//! Terminal lifecycle management.
//!
//! Entry point is [`init`]: enables raw mode, enters the alternate screen, and
//! returns a [`Screen`](crate::screen::Screen) ready to render. [`restore`]
//! reverses all of that and must be called before the process exits.
//!
//! [`probe_kitty`] is a separate step, called *before* [`init`]. It runs on
//! the normal screen (raw mode only, no alt-screen) so the caller can finish
//! scripting initialisation (which installs kitty-only default keybinds
//! before user `bind-key!` calls run) while the shell is still visible.
//!
//! Also provides cursor shape/colour control, DEC 2026 synchronized-update
//! framing, and the inline-subprocess-output flow
//! ([`enter_inline_output`]/[`InlineOutputScreen::close`]).
//!
//! [`SharedTerm`] is a cheap-to-clone handle: every owner that keeps the
//! terminal (the render loop, the signal handler, the inline-output bracket)
//! holds a clone, and a write or mode switch needs only a `&SharedTerm`.
//! Event reads/polls never lock the shared
//! mutex (they go straight to the cloned [`EventReader`]), so a blocking
//! read on one thread can never stall a write on another.

use std::io::{self, Write};
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Duration;

use crate::file_url::path_to_file_url;
use termina::Terminal as _;
use termina::escape::csi::{
    Csi, Cursor, DecPrivateMode, DecPrivateModeCode, Keyboard, KittyKeyboardFlags, Mode,
};
use termina::escape::osc::{ColorOrQuery, DynamicColorNumber, Osc, Selection};
use termina::escape::{OSC, ST};
use termina::event::KeyEventKind;
use termina::style::RgbColor;
use termina::{Event, EventReader, PlatformHandle, PlatformTerminal, WindowSize};

/// Re-exported so callers choosing a shape (`hume-editor`'s
/// `insert-cursor-shape` setting) don't need their own `termina` import just
/// to name the value they're passing to [`set_cursor_shape`].
pub use termina::style::CursorStyle;

/// A cheap-to-clone handle to the process's terminal.
///
/// Wraps the platform terminal behind a mutex so it can be shared between the
/// render loop, the signal handler, and the inline-output bracket, plus a
/// cloned [`EventReader`] captured once at [`create`] time. The mutex guards
/// only short operations (writes and mode switches); blocking `poll`/`read`
/// calls go through the `EventReader` directly and never take the lock, so a
/// pending read can never stall a writer on another thread.
#[derive(Clone)]
pub struct SharedTerm {
    inner: Arc<Mutex<PlatformTerminal>>,
    reader: EventReader,
    /// OSC 7 URL of the directory the shell started HUME in. Teardown reports
    /// it again, because the shell will not re-send it.
    launch_cwd_url: Option<Arc<str>>,
    /// Raised for the lifetime of the one [`InlineOutputScreen`] that
    /// [`enter_inline_output`] returns. Read by the terminator, which drops
    /// the terminal's own interrupts then.
    inline_output: Arc<AtomicBool>,
}

impl SharedTerm {
    fn lock(&self) -> MutexGuard<'_, PlatformTerminal> {
        self.inner.lock().unwrap_or_else(|e| e.into_inner())
    }

    pub(crate) fn in_inline_output(&self) -> bool {
        self.inline_output.load(Ordering::Acquire)
    }

    /// A cloneable reader for blocking or non-blocking event reads.
    pub fn event_reader(&self) -> EventReader {
        self.reader.clone()
    }
}

// Every operation locks internally, so a shared reference does all of them,
// as `&File` does. The owned impls forward to these.
impl io::Write for &SharedTerm {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.lock().write(buf)
    }

    fn flush(&mut self) -> io::Result<()> {
        self.lock().flush()
    }
}

impl termina::Terminal for &SharedTerm {
    fn enter_raw_mode(&mut self) -> io::Result<()> {
        self.lock().enter_raw_mode()
    }

    fn enter_cooked_mode(&mut self) -> io::Result<()> {
        self.lock().enter_cooked_mode()
    }

    fn get_dimensions(&self) -> io::Result<WindowSize> {
        self.lock().get_dimensions()
    }

    fn event_reader(&self) -> EventReader {
        self.reader.clone()
    }

    fn poll<F: Fn(&Event) -> bool>(
        &self,
        filter: F,
        timeout: Option<Duration>,
    ) -> io::Result<bool> {
        self.reader.poll(timeout, filter)
    }

    fn read<F: Fn(&Event) -> bool>(&self, filter: F) -> io::Result<Event> {
        self.reader.read(filter)
    }

    fn set_panic_hook(&mut self, f: impl Fn(&mut PlatformHandle) + Send + Sync + 'static) {
        self.lock().set_panic_hook(f);
    }
}

impl io::Write for SharedTerm {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        (&*self).write(buf)
    }

    fn flush(&mut self) -> io::Result<()> {
        (&*self).flush()
    }
}

impl termina::Terminal for SharedTerm {
    fn enter_raw_mode(&mut self) -> io::Result<()> {
        <&Self as termina::Terminal>::enter_raw_mode(&mut &*self)
    }

    fn enter_cooked_mode(&mut self) -> io::Result<()> {
        <&Self as termina::Terminal>::enter_cooked_mode(&mut &*self)
    }

    fn get_dimensions(&self) -> io::Result<WindowSize> {
        <&Self as termina::Terminal>::get_dimensions(&self)
    }

    fn event_reader(&self) -> EventReader {
        <&Self as termina::Terminal>::event_reader(&self)
    }

    fn poll<F: Fn(&Event) -> bool>(
        &self,
        filter: F,
        timeout: Option<Duration>,
    ) -> io::Result<bool> {
        <&Self as termina::Terminal>::poll(&self, filter, timeout)
    }

    fn read<F: Fn(&Event) -> bool>(&self, filter: F) -> io::Result<Event> {
        <&Self as termina::Terminal>::read(&self, filter)
    }

    fn set_panic_hook(&mut self, f: impl Fn(&mut PlatformHandle) + Send + Sync + 'static) {
        <&Self as termina::Terminal>::set_panic_hook(&mut &*self, f);
    }
}

/// Open the process terminal. Call once at startup; clone the result for
/// every owner that keeps it. `launch_cwd` is the
/// directory the shell started HUME in.
///
/// On Windows, `PlatformTerminal::new` enables VT input/output mode
/// unconditionally (HUME has no legacy-console fallback); a console that
/// can't provide it (older than Windows 10 1809, or a raw pipe such as
/// mintty without winpty) fails here.
pub fn create(launch_cwd: &Path) -> io::Result<SharedTerm> {
    #[cfg(windows)]
    let inner = PlatformTerminal::new().map_err(|e| {
        io::Error::new(
            e.kind(),
            format!("{e} (HUME requires Windows 10 1809+ and a VT-capable console)"),
        )
    })?;
    #[cfg(not(windows))]
    let inner = PlatformTerminal::new()?;

    let reader = inner.event_reader();
    Ok(SharedTerm {
        inner: Arc::new(Mutex::new(inner)),
        reader,
        launch_cwd_url: working_directory_url(launch_cwd).map(Arc::from),
        inline_output: Arc::new(AtomicBool::new(false)),
    })
}

// ── Shared escape-sequence helpers ───────────────────────────────────────────

pub(crate) fn dec_set(code: DecPrivateModeCode) -> Csi {
    Csi::Mode(Mode::SetDecPrivateMode(DecPrivateMode::Code(code)))
}

pub(crate) fn dec_reset(code: DecPrivateModeCode) -> Csi {
    Csi::Mode(Mode::ResetDecPrivateMode(DecPrivateMode::Code(code)))
}

fn kitty_flags() -> KittyKeyboardFlags {
    // REPORT_ALTERNATE_KEYS is required so that Ctrl-shifted-chars (e.g.
    // Ctrl-}) arrive with the correct keycode instead of the base key plus
    // SHIFT. See docs/learning/command-keymap-dispatch.md.
    //
    // Known limitation: WezTerm 20240203-110809-5046fc22 does not fully
    // support REPORT_ALTERNATE_KEYS: Ctrl-shifted-char one-shot extend may
    // not work on that version.
    KittyKeyboardFlags::DISAMBIGUATE_ESCAPE_CODES
        | KittyKeyboardFlags::REPORT_EVENT_TYPES
        | KittyKeyboardFlags::REPORT_ALTERNATE_KEYS
}

fn write_kitty_push(out: &mut impl io::Write) -> io::Result<()> {
    write!(out, "{}", Csi::Keyboard(Keyboard::PushFlags(kitty_flags())))?;
    out.flush()
}

fn write_kitty_pop(out: &mut impl io::Write) -> io::Result<()> {
    // Pop one level of the keyboard enhancement stack. Fixed protocol
    // sequence (no flag argument); harmless no-op when the stack is empty.
    write!(out, "{}", Csi::Keyboard(Keyboard::PopFlags(1)))?;
    out.flush()
}

fn write_mouse_enable(out: &mut impl io::Write, select: bool) -> io::Result<()> {
    // Normal tracking (1000): button press/release and scroll wheel.
    // SGR extended coordinates (1006): removes the 223-column limit of the
    // legacy X10 encoding; required for wide terminals.
    write!(
        out,
        "{}{}",
        dec_set(DecPrivateModeCode::MouseTracking),
        dec_set(DecPrivateModeCode::SGRMouse)
    )?;
    if select {
        // Button-event tracking (1002) additionally reports drag motion.
        // Without it, drag events never reach the application, so the
        // terminal handles drag-select natively.
        write!(out, "{}", dec_set(DecPrivateModeCode::ButtonEventMouse))?;
    }
    out.flush()
}

fn write_mouse_disable(out: &mut impl io::Write) -> io::Result<()> {
    // The reset sequences are harmless no-ops if the corresponding mode was
    // never enabled.
    write!(
        out,
        "{}{}{}",
        dec_reset(DecPrivateModeCode::ButtonEventMouse),
        dec_reset(DecPrivateModeCode::MouseTracking),
        dec_reset(DecPrivateModeCode::SGRMouse)
    )?;
    out.flush()
}

fn write_paste_enable(out: &mut impl io::Write) -> io::Result<()> {
    write!(out, "{}", dec_set(DecPrivateModeCode::BracketedPaste))?;
    out.flush()
}

fn write_paste_disable(out: &mut impl io::Write) -> io::Result<()> {
    write!(out, "{}", dec_reset(DecPrivateModeCode::BracketedPaste))?;
    out.flush()
}

fn write_focus_enable(out: &mut impl io::Write) -> io::Result<()> {
    write!(out, "{}", dec_set(DecPrivateModeCode::FocusTracking))?;
    out.flush()
}

fn write_focus_disable(out: &mut impl io::Write) -> io::Result<()> {
    write!(out, "{}", dec_reset(DecPrivateModeCode::FocusTracking))?;
    out.flush()
}

fn write_sync_reset(out: &mut impl io::Write) -> io::Result<()> {
    write!(out, "{}", dec_reset(DecPrivateModeCode::SynchronizedOutput))?;
    out.flush()
}

fn write_enter_alt_screen(out: &mut impl io::Write) -> io::Result<()> {
    write!(
        out,
        "{}",
        dec_set(DecPrivateModeCode::ClearAndEnableAlternateScreen)
    )?;
    out.flush()
}

fn write_leave_alt_screen(out: &mut impl io::Write) -> io::Result<()> {
    write!(
        out,
        "{}",
        dec_reset(DecPrivateModeCode::ClearAndEnableAlternateScreen)
    )?;
    out.flush()
}

/// The OSC 7 URL for `cwd`, naming this machine as the host. `None` for a
/// path that has no URL (relative, or not UTF-8).
fn working_directory_url(cwd: &Path) -> Option<String> {
    let host = gethostname::gethostname();
    path_to_file_url(cwd, &host.to_string_lossy()).ok()
}

/// OSC 7 with `url`, or with an empty URL for `None`. WezTerm reads an
/// unparsable URL as "no reported directory", which hands the pane back to
/// inspecting its processes.
fn write_cwd_report(out: &mut impl io::Write, url: Option<&str>) -> io::Result<()> {
    write!(out, "{OSC}7;{}{ST}", url.unwrap_or(""))?;
    out.flush()
}

/// Runs every step in `steps`, even if an earlier one fails. The goal is to
/// leave the shell as usable as possible rather than abandon teardown at the
/// first error. Returns the first error encountered; later ones are silently
/// discarded.
///
/// Each element of `steps` is a call expression (e.g. `write_sync_reset(out)`)
/// already evaluated (and so already run for its side effect) by the time
/// this function sees it; array elements evaluate left to right, so passing
/// an array literal here preserves the steps' intended order.
fn run_all(steps: impl IntoIterator<Item = io::Result<()>>) -> io::Result<()> {
    let mut first_err: Option<io::Error> = None;
    for r in steps {
        if first_err.is_none() {
            first_err = r.err();
        }
    }
    match first_err {
        Some(e) => Err(e),
        None => Ok(()),
    }
}

/// SSOT byte sequence that undoes every application-level mode [`init`]
/// turns on: closes any open synchronized-update envelope, disables focus
/// tracking and bracketed paste, pops the kitty keyboard stack, disables
/// mouse tracking, leaves the alternate screen, and reports the launch
/// directory again, undoing [`set_working_directory`]. Shared between
/// [`restore`] and the panic hook installed by [`init`]. The hook can only
/// write bytes (no raw/cooked mode switch), and termina restores the
/// platform mode itself right after the hook returns.
fn write_unwind_escapes(out: &mut impl io::Write, launch_cwd_url: Option<&str>) -> io::Result<()> {
    run_all([
        write_sync_reset(out),
        write_focus_disable(out),
        write_paste_disable(out),
        write_kitty_pop(out),
        write_mouse_disable(out),
        write_leave_alt_screen(out),
        write_cwd_report(out, launch_cwd_url),
        // Second pop. Since `init()` pushes onto the alt screen's stack, the
        // first pop (above) clears it. This extra pop handles terminals with
        // a global keyboard stack; a harmless no-op on per-screen-buffer
        // terminals (WezTerm, kitty).
        write_kitty_pop(out),
    ])
}

// ── Public terminal lifecycle API ─────────────────────────────────────────────

/// Probe for kitty keyboard protocol support on the normal screen.
///
/// Enables raw mode (required to read the terminal's reply to the probe
/// query), runs the probe, then disables raw mode again before returning:
/// callers get a cooked terminal back on every path, since scripting
/// initialisation (which may spawn subprocesses, e.g. grammar installs) runs
/// on the normal screen between this call and [`init`].
///
/// Probe failures (channel errors, not mere timeouts) are surfaced to the
/// user as a one-line stderr hint: kitty support degrades to "off" but the
/// editor still starts. A plain timeout reports `Ok(false)` upstream.
pub fn probe_kitty(term: &SharedTerm) -> io::Result<bool> {
    let mut term = term;
    term.enter_raw_mode()?;
    let kitty_enabled = match crate::probe_kitty_support(term) {
        Ok(v) => v,
        Err(e) => {
            // Disable raw mode so the hint prints with normal line discipline
            // (no staircase) before we report it.
            let _ = term.enter_cooked_mode();
            eprintln!("hume: kitty keyboard probe failed: {e}");
            return Ok(false);
        }
    };
    term.enter_cooked_mode()?;
    Ok(kitty_enabled)
}

/// Switch the terminal into raw mode + alternate screen and return a
/// [`Screen`](crate::screen::Screen) ready to render.
///
/// `kitty_enabled` is a prior [`probe_kitty`] result; when `true` the caller
/// should filter `KeyEventKind::Release` events. Focus tracking (DECSET 1004)
/// is always enabled, since unsupporting terminals just never send focus
/// events (tmux needs `set -g focus-events on`). `mouse_enabled` turns on
/// click and scroll tracking with SGR coordinates, leaving drag-select to the
/// terminal; `mouse_select` also reports drags so the editor can select.
///
/// Call [`restore`] before exiting. A panic hook, armed before any mode is
/// entered, also restores, and a failure partway through is unwound before
/// `Err` is returned.
pub fn init(
    term: &SharedTerm,
    mouse_enabled: bool,
    mouse_select: bool,
    kitty_enabled: bool,
) -> io::Result<crate::screen::Screen> {
    let mut term = term;

    // Arm before entering any mode: a panic during the enable sequence below
    // still unwinds through this hook, and every escape it emits is a
    // documented no-op for a mode not yet entered.
    let launch_cwd_url = term.launch_cwd_url.clone();
    term.set_panic_hook(move |handle| {
        let _ = write_unwind_escapes(handle, launch_cwd_url.as_deref());
    });

    let enter = editor_modes(kitty_enabled, mouse_enabled, mouse_select)
        .rev()
        .try_for_each(|mode| mode.reenter(&mut term));

    if let Err(e) = enter {
        // A partial enable must not leak: the caller propagates this error
        // and never reaches the happy-path `restore()` in `run()`.
        let _ = restore(term);
        return Err(e);
    }

    Ok(crate::screen::Screen::new(term.clone()))
}

/// Undo everything [`init`] did: run `write_unwind_escapes` then leave raw
/// mode. Both are attempted even if the first fails; the goal is to leave
/// the shell as usable as possible. The first error encountered is returned;
/// a second is silently discarded.
pub fn restore(term: &SharedTerm) -> io::Result<()> {
    let mut out = term;
    run_all([
        write_unwind_escapes(&mut out, term.launch_cwd_url.as_deref()),
        out.enter_cooked_mode(),
    ])
}

/// Emit an OSC 12 sequence to set the terminal cursor colour.
///
/// When `black` is `true`, sets the cursor to black. Used when the cursor
/// sits on a light-background surface (e.g. the statusline in Command/Search
/// mode) where the default colour would be invisible.
///
/// When `black` is `false`, resets to the user's configured terminal default.
///
/// Buffered: the sequence reaches the terminal at the next flush, which
/// [`end_synchronized_update`] makes at the end of every frame.
pub fn set_cursor_color(term: &SharedTerm, black: bool) -> io::Result<()> {
    let mut term = term;
    if black {
        write!(
            term,
            "{}",
            Osc::ChangeDynamicColors(
                DynamicColorNumber::TextCursorColor,
                vec![ColorOrQuery::Color(RgbColor::new(0, 0, 0))],
            )
        )
    } else {
        write!(
            term,
            "{}",
            Osc::ResetDynamicColor(DynamicColorNumber::TextCursorColor)
        )
    }
}

/// Tell the terminal the working directory (OSC 7), so a new split or tab
/// opens there instead of the terminal guessing from the process tree. A
/// `cwd` with no URL (relative, or not UTF-8) clears the report so the
/// terminal does not keep a stale directory. [`restore`] and the panic hook
/// report the launch directory again.
pub fn set_working_directory(term: &SharedTerm, cwd: &Path) -> io::Result<()> {
    let mut term = term;
    write_cwd_report(&mut term, working_directory_url(cwd).as_deref())
}

/// Ask the terminal to put `text` on the user's clipboard (OSC 52).
///
/// Fire-and-forget: a terminal that doesn't implement or permit OSC 52
/// ignores the sequence, so success here only means the bytes were written.
pub fn set_clipboard(term: &SharedTerm, text: &str) -> io::Result<()> {
    let mut term = term;
    write!(term, "{}", Osc::SetSelection(Selection::CLIPBOARD, text))?;
    term.flush()
}

/// Emit a DECSCUSR escape for the cursor shape.
///
/// Takes the `termina` style directly rather than HUME's own `CursorShape`
/// setting enum: that enum lives in `hume-editor` (a settings concept this
/// crate has no business depending on), so the `CursorShape` → `CursorStyle`
/// mapping is the caller's job.
///
/// Buffered, like [`set_cursor_color`].
pub fn set_cursor_shape(term: &SharedTerm, style: CursorStyle) -> io::Result<()> {
    let mut term = term;
    write!(term, "{}", Csi::Cursor(Cursor::CursorStyle(style)))
}

/// Ask the terminal to defer display updates until [`end_synchronized_update`]
/// is called.
///
/// Call once per frame, before `term.draw(…)`. Terminals that do not
/// recognise DEC 2026 silently ignore the sequence, so this is safe to emit
/// unconditionally. The `let _ = …` pattern at the call site is intentional:
/// a write failure here must never abort the render loop. Buffered, like the
/// rest of the frame, until [`end_synchronized_update`] flushes it.
pub fn begin_synchronized_update(term: &SharedTerm) -> io::Result<()> {
    let mut term = term;
    write!(term, "{}", dec_set(DecPrivateModeCode::SynchronizedOutput))
}

/// Signal the terminal that the current frame is complete and it may paint
/// the accumulated output atomically.
///
/// Call after every write that contributes to the current frame (draw,
/// cursor shape, cursor colour). Pairs with [`begin_synchronized_update`].
/// This is the frame's one flush: the writes before it only buffer.
pub fn end_synchronized_update(term: &SharedTerm) -> io::Result<()> {
    let mut term = term;
    write_sync_reset(&mut term)
}

/// Holds a flag raised for its own lifetime.
struct FrameFlag(Arc<AtomicBool>);

impl FrameFlag {
    /// `None` while another `FrameFlag` holds `flag` raised.
    fn try_raise(flag: &Arc<AtomicBool>) -> Option<Self> {
        flag.compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .ok()?;
        Some(Self(Arc::clone(flag)))
    }
}

impl Drop for FrameFlag {
    fn drop(&mut self) {
        self.0.store(false, Ordering::Release);
    }
}

/// The line-discipline switches an [`EditorMode`] makes besides its escape
/// writes. Named apart from `termina::Terminal`'s own methods so both
/// traits can be in scope for a `SharedTerm`.
trait ModeSwitch: io::Write {
    fn raw_mode(&mut self) -> io::Result<()>;
    fn cooked_mode(&mut self) -> io::Result<()>;
}

impl ModeSwitch for &SharedTerm {
    fn raw_mode(&mut self) -> io::Result<()> {
        self.enter_raw_mode()
    }

    fn cooked_mode(&mut self) -> io::Result<()> {
        self.enter_cooked_mode()
    }
}

impl ModeSwitch for SharedTerm {
    fn raw_mode(&mut self) -> io::Result<()> {
        (&*self).raw_mode()
    }

    fn cooked_mode(&mut self) -> io::Result<()> {
        (&*self).cooked_mode()
    }
}

/// An editor terminal mode [`init`] turns on and the inline-output frame
/// turns off, then back on.
#[derive(Clone, Copy)]
enum EditorMode {
    Focus,
    Paste,
    Kitty,
    Mouse { select: bool },
    Raw,
    AltScreen,
}

impl EditorMode {
    fn leave(self, term: &mut impl ModeSwitch) -> io::Result<()> {
        match self {
            Self::Focus => write_focus_disable(term),
            Self::Paste => write_paste_disable(term),
            Self::Kitty => write_kitty_pop(term),
            Self::Mouse { .. } => write_mouse_disable(term),
            Self::Raw => term.cooked_mode(),
            Self::AltScreen => write_leave_alt_screen(term),
        }
    }

    fn reenter(self, term: &mut impl ModeSwitch) -> io::Result<()> {
        match self {
            Self::Focus => write_focus_enable(term),
            Self::Paste => write_paste_enable(term),
            Self::Kitty => write_kitty_push(term),
            Self::Mouse { select } => write_mouse_enable(term, select),
            Self::Raw => term.raw_mode(),
            Self::AltScreen => write_enter_alt_screen(term),
        }
    }
}

/// The editor's modes in the order the inline-output frame turns them off.
/// Turning them on walks this in reverse, which puts the alt-screen enter
/// ahead of the kitty push: some terminals (WezTerm, kitty) keep a keyboard
/// stack per screen, and key reads consult the active screen's.
fn editor_modes(
    kitty_enabled: bool,
    mouse_enabled: bool,
    mouse_select: bool,
) -> impl DoubleEndedIterator<Item = EditorMode> {
    [
        Some(EditorMode::Focus),
        Some(EditorMode::Paste),
        kitty_enabled.then_some(EditorMode::Kitty),
        mouse_enabled.then_some(EditorMode::Mouse {
            select: mouse_select,
        }),
        Some(EditorMode::Raw),
        Some(EditorMode::AltScreen),
    ]
    .into_iter()
    .flatten()
}

/// The inline-output frame's terminal work, apart from the banners and the
/// keypress wait that need a real terminal.
struct Frame<T> {
    term: T,
    /// Every mode [`Self::open`] tried to turn off, in order. A failed write
    /// may still have reached the terminal, so a tried mode counts as off.
    /// For kitty, a push the pop did not need beats a missing one, which
    /// would break key encoding for the rest of the session.
    left: Vec<EditorMode>,
    _interrupts_to_child: FrameFlag,
}

impl<T: ModeSwitch> Frame<T> {
    fn open(
        term: T,
        flag: &Arc<AtomicBool>,
        kitty_enabled: bool,
        mouse_enabled: bool,
        mouse_select: bool,
    ) -> io::Result<Self> {
        // Raised first, so a refused open writes nothing, and before the
        // switch, so no Ctrl-c the cooked terminal turns into a signal can
        // reach the terminator ahead of it.
        let interrupts_to_child = FrameFlag::try_raise(flag)
            .ok_or_else(|| io::Error::other("an inline-output screen is already open"))?;
        let mut frame = Self {
            term,
            left: Vec::new(),
            _interrupts_to_child: interrupts_to_child,
        };
        // Close any open synchronized-output envelope (harmless if none is open).
        let _ = write_sync_reset(&mut frame.term);
        for mode in editor_modes(kitty_enabled, mouse_enabled, mouse_select) {
            frame.left.push(mode);
            if let Err(e) = mode.leave(&mut frame.term) {
                let _ = frame.close();
                return Err(e);
            }
        }
        Ok(frame)
    }

    /// Turn back on every mode in `left`, last first (see [`editor_modes`]).
    /// The flag lowers when the frame drops, after the last step.
    fn close(mut self) -> io::Result<()> {
        let term = &mut self.term;
        run_all(self.left.iter().rev().map(|mode| mode.reenter(term)))
    }
}

/// The inline-output frame: the terminal in cooked mode on the normal
/// screen, from [`enter_inline_output`] until [`Self::close`] or drop.
///
/// While it lives, Ctrl-c and Ctrl-\ interrupt the child in the foreground
/// process group and never quit HUME (see [`crate::spawn_terminator`]).
/// Dropping it without `close` restores nothing on screen but gives Ctrl-c
/// back to HUME.
#[must_use = "dropping the screen hands Ctrl-c back to HUME without restoring the editor"]
pub struct InlineOutputScreen(Frame<SharedTerm>);

impl InlineOutputScreen {
    /// Print the return prompt, wait for a key, then re-enter raw mode and
    /// the alt-screen with kitty and mouse as they were before
    /// [`enter_inline_output`]. Ctrl-c quits HUME again afterwards, whether
    /// or not the restore succeeded.
    pub fn close(self) -> io::Result<()> {
        print_return_prompt();
        wait_for_keypress(&self.0.term);
        self.0.close()
    }
}

/// Leave the alt-screen and raw mode so subprocess output streams to the user's
/// terminal live, under a `--- running NAME ---` banner. Call before spawning
/// blocking processes (git clone, formatters) that would otherwise be
/// invisible inside the TUI.
///
/// `kitty_enabled`, `mouse_enabled` and `mouse_select` are the editor's
/// current state, which [`InlineOutputScreen::close`] re-applies. Also
/// disables focus tracking for the duration: a subprocess reading raw
/// terminal input shouldn't see stray `CSI I`/`CSI O` bytes.
///
/// A failure once the frame has begun unwinds it before `Err` is returned.
/// At most one screen is open per terminal: while one lives, this returns
/// `Err` without touching the terminal.
pub fn enter_inline_output(
    term: &SharedTerm,
    name: &str,
    kitty_enabled: bool,
    mouse_enabled: bool,
    mouse_select: bool,
) -> io::Result<InlineOutputScreen> {
    let frame = Frame::open(
        term.clone(),
        &term.inline_output,
        kitty_enabled,
        mouse_enabled,
        mouse_select,
    )?;
    print_running_banner(name);
    Ok(InlineOutputScreen(frame))
}

/// Reapply the mouse-tracking mode to match `mouse_enabled`/`mouse_select`.
///
/// Always disables tracking first (a harmless no-op for modes not currently
/// set; see `write_mouse_disable`) then re-enables per the new flags, so
/// it's safe to call whenever the desired mode changes at runtime, not just
/// once at startup (unlike [`init`], which only applies the startup mode).
pub fn set_mouse_mode(
    term: &SharedTerm,
    mouse_enabled: bool,
    mouse_select: bool,
) -> io::Result<()> {
    let mut term = term;
    write_mouse_disable(&mut term)?;
    if mouse_enabled {
        write_mouse_enable(&mut term, mouse_select)?;
    }
    Ok(())
}

/// Print the `--- running NAME ---` bold banner and flush stdout.
fn print_running_banner(name: &str) {
    print!("\r\n\x1b[1m--- running {name} ---\x1b[0m\r\n\r\n");
    let _ = std::io::Write::flush(&mut std::io::stdout());
}

/// Print the `--- press any key to return ---` dim prompt and flush stdout.
fn print_return_prompt() {
    print!("\r\n\x1b[2m--- press any key to return to editor ---\x1b[0m\r\n");
    let _ = std::io::Write::flush(&mut std::io::stdout());
}

/// Block until the user presses a key, ignoring resize, mouse, and key-release
/// events. Holds subprocess output on screen until the user is ready to return
/// to the TUI. Leaves the terminal in raw mode.
fn wait_for_keypress(term: &SharedTerm) {
    let mut term = term;
    let _ = term.enter_raw_mode();
    let reader = term.event_reader();
    loop {
        match reader.read(|_| true) {
            // A background thread (LSP transport, parse worker) can hold this
            // reader's `PlatformWaker` while the editor is suspended here for a
            // subprocess; since termina 0.4.0 its wake surfaces as `Interrupted`
            // instead of being silently absorbed, so it must not be mistaken for
            // "return to editor" and must resume the wait instead.
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Ok(Event::Key(k)) if k.kind != KeyEventKind::Release => break,
            Ok(_) => continue,
            Err(_) => break,
        }
    }
}

#[cfg(test)]
mod tests;
