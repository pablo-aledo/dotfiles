//! Process-wide tracking of long-lived children, so a force-exit can still
//! reap them.
//!
//! `std::process::exit` (the last step of `crate::force_exit`) runs no
//! destructors, so the `Drop` impls that kill LSP servers and line-source
//! children never fire. Each long-lived child registers via
//! [`TrackedChild::new`](crate::process::tracked::TrackedChild::new), and
//! `force_exit` calls `kill_tracked_children` as a fail-safe; `Drop` still
//! owns cleanup on a normal exit. The table is global because the terminator
//! thread has no other path to children spawned elsewhere.
//!
//! Children run to completion in place (`run_capture`, `run_inline_output`)
//! are not tracked and can be orphaned by a force-exit.
//! They are short-lived and self-terminating.

use std::sync::{Arc, Mutex, TryLockError, Weak};

use super::GroupedChild;
use std::time::Duration;

#[cfg(unix)]
use nix::sys::signal::{Signal, killpg};
#[cfg(unix)]
use nix::unistd::{Pid, getpgid};

struct TrackedInner {
    grouped: GroupedChild,
    /// Recorded once at registration rather than re-checked at kill time:
    /// by the time `force_exit` runs the child may already be gone, and
    /// `getpgid` on a dead pid would just report `ESRCH`. This remembers
    /// what `spawn_in_own_group` actually established, not what's still
    /// true this instant.
    #[cfg(unix)]
    group_leader: bool,
}

impl TrackedInner {
    /// Kill the child and the processes it started: through its process
    /// group on Unix when it leads one, through its job on Windows, so
    /// grandchildren (rust-analyzer's `proc-macro-srv`, build scripts, the
    /// command under a `sh -c` or `cmd /C`, ...) go down with it. Shared by
    /// every kill path (a normal-exit `Drop`'s [`TrackedChild::reap`] and
    /// [`kill_tracked_children`]'s force-exit reap) so a grandchild is never
    /// left behind depending on which one happens to run.
    fn kill(&mut self) {
        // A job handle names the job, never a pid the system may have
        // reused, so the job is ended even after the child exited: a
        // process the child started can still be running in it.
        #[cfg(windows)]
        let job_ended = self.grouped.job.terminate().is_ok();
        // `Child::kill`'s own pid-reuse guard (checked in the vendored `std`
        // source: it no-ops once the child's exit status has been cached)
        // does not cover the `killpg` path below, which bypasses `Child`
        // entirely and signals a raw pid via `nix`. Consult (and cache) the
        // exit status the same way `Child::kill` does internally, so a
        // child that already exited (and whose pid the kernel may already
        // have reused) is never signalled by pid, group or otherwise.
        if !matches!(self.grouped.child.try_wait(), Ok(None)) {
            return;
        }
        // Each group kill falls through to the direct kill below on failure:
        // an unconditional `return` would leave the child unsignalled and
        // `reap()`'s `wait()` blocking forever on it.
        #[cfg(unix)]
        if self.group_leader
            && let Ok(pid) = i32::try_from(self.grouped.child.id())
            && killpg(Pid::from_raw(pid), Signal::SIGKILL).is_ok()
        {
            return;
        }
        #[cfg(windows)]
        if job_ended {
            return;
        }
        let _ = self.grouped.child.kill();
    }
}

type ChildSlot = Mutex<TrackedInner>;

/// A table of live registrations, held as `Weak` so a consumer's own
/// `Drop`/reap (the common case, on every normal exit) needs no explicit
/// deregistration call; an entry is simply unreachable once nothing
/// strong-refs it.
///
/// A value type, not a bare `static`, so tests can hold a private instance:
/// a shared global would make [`kill_all`](Self::kill_all) in one test kill
/// children a *different*, concurrently-running test just spawned:
/// `cargo test` runs the whole crate's tests as threads in one process, and
/// nothing here scopes a table to a single test.
struct ChildRegistry {
    entries: Mutex<Vec<Weak<ChildSlot>>>,
}

impl ChildRegistry {
    const fn new() -> Self {
        ChildRegistry {
            entries: Mutex::new(Vec::new()),
        }
    }

    fn register(&self, slot: &Arc<ChildSlot>) {
        let mut table = lock_recovering(&self.entries);
        table.retain(|w| w.strong_count() > 0);
        table.push(Arc::downgrade(slot));
    }

    /// Kills every still-registered child, best-effort. Must never block the
    /// exit this exists to make possible on a *slot*: each is a `try_lock`,
    /// and a slot already held (a concurrent normal-shutdown `Drop` reaping
    /// the same child) is skipped rather than waited on, not fought over.
    /// The table lock itself is a plain blocking `lock`: it only ever guards
    /// a `Vec` retain + push in [`register`](Self::register), never a
    /// syscall, so waiting for it is bounded and cheap, unlike skipping it,
    /// which would abandon every child rather than just one.
    fn kill_all(&self) {
        let table = lock_recovering(&self.entries);
        for weak in table.iter() {
            if let Some(slot) = weak.upgrade() {
                kill_slot(&slot);
            }
        }
    }

    #[cfg(all(test, unix))]
    fn live_count(&self) -> usize {
        lock_recovering(&self.entries)
            .iter()
            .filter(|w| w.strong_count() > 0)
            .count()
    }
}

static GLOBAL: ChildRegistry = ChildRegistry::new();

/// Kills every child still registered in the process-wide table. Called
/// from `force_exit`, immediately before tearing the terminal down and
/// exiting.
pub(crate) fn kill_tracked_children() {
    GLOBAL.kill_all();
}

/// A spawned child registered with the process-wide force-exit reaper.
///
/// Not a replacement for a type's own kill/wait `Drop`: `ServerHandle` and
/// `SpawnedLineSource` still do that themselves on every normal exit. This
/// only exists to cover the abnormal case where nothing gets to run a `Drop`
/// at all. `Child::kill`/`wait` cache the reaped exit status and turn a
/// repeat call into a no-op (verified in the vendored `std` source), which
/// is what makes it safe for both a normal-exit `Drop` and this table's own
/// reap to call [`reap`](Self::reap) without coordinating who goes first.
#[derive(Clone)]
pub struct TrackedChild(Arc<ChildSlot>);

impl TrackedChild {
    /// Registers `child`, spawned by [`spawn_piped`](super::spawn_piped),
    /// with the process-wide reaper.
    pub fn new(child: GroupedChild) -> Self {
        Self::in_registry(child, &GLOBAL)
    }

    fn in_registry(grouped: GroupedChild, registry: &ChildRegistry) -> Self {
        let inner = TrackedInner {
            #[cfg(unix)]
            group_leader: i32::try_from(grouped.child.id())
                .map(Pid::from_raw)
                .is_ok_and(|pid| getpgid(Some(pid)) == Ok(pid)),
            grouped,
        };

        let slot = Arc::new(Mutex::new(inner));
        registry.register(&slot);
        TrackedChild(slot)
    }

    /// The child's OS process id.
    pub fn id(&self) -> u32 {
        lock_recovering(&self.0).grouped.child.id()
    }

    /// Non-blocking wait that does not kill. Mirrors `Child::try_wait`; callers
    /// that need the "still running → kill it" fallback call
    /// [`reap`](Self::reap) themselves on `Ok(None)`.
    pub fn try_wait(&self) -> std::io::Result<Option<std::process::ExitStatus>> {
        lock_recovering(&self.0).grouped.child.try_wait()
    }

    /// Blocks until the child exits and returns its status. The slot's lock
    /// is held only for each `try_wait`, never while blocked, so a
    /// concurrent [`reap`](Self::reap) or force-exit kill is not held up.
    #[cfg(unix)]
    pub fn wait_for_exit(&self) -> std::io::Result<std::process::ExitStatus> {
        let signal = super::exit_watch::exit_signal()?;
        loop {
            let seen = signal.generation();
            if let Some(status) = self.try_wait()? {
                return Ok(status);
            }
            signal.wait_past(seen);
        }
    }

    /// Blocks until the child exits and returns its status. The wait is on
    /// a clone of the process handle, so the slot's lock is not held while
    /// blocked and a concurrent [`reap`](Self::reap) or force-exit kill is
    /// not held up.
    #[cfg(windows)]
    pub fn wait_for_exit(&self) -> std::io::Result<std::process::ExitStatus> {
        use std::os::windows::io::{AsHandle, AsRawHandle};
        use windows_sys::Win32::Foundation::WAIT_OBJECT_0;
        use windows_sys::Win32::System::Threading::{INFINITE, WaitForSingleObject};

        let process = lock_recovering(&self.0)
            .grouped
            .child
            .as_handle()
            .try_clone_to_owned()?;
        // SAFETY: `process` is an open process handle this function owns
        // until it returns, so it outlives the wait.
        if unsafe { WaitForSingleObject(process.as_raw_handle(), INFINITE) } != WAIT_OBJECT_0 {
            return Err(std::io::Error::last_os_error());
        }
        self.try_wait()?
            .ok_or_else(|| std::io::Error::other("the process exited but has no exit status"))
    }

    /// Kill (group-directed when this child leads its own process group;
    /// see `TrackedInner::kill`) + wait. Safe to call more than once,
    /// including racing a concurrent `kill_tracked_children` (see the
    /// type doc).
    pub fn reap(&self) -> Option<std::process::ExitStatus> {
        let mut inner = lock_recovering(&self.0);
        inner.kill();
        inner.grouped.child.wait().ok()
    }
}

/// Attempts before a contended slot is abandoned. A slot held by a
/// concurrent [`TrackedChild::reap`] needs no help (that path kills the
/// child itself), but [`TrackedChild::id`]/[`TrackedChild::try_wait`] hold
/// the same mutex without killing anything, so one failed `try_lock` is not
/// proof the child is being dealt with. Bounded: force-exit must never wait
/// indefinitely on a slot.
const KILL_LOCK_ATTEMPTS: u32 = 5;

/// Delay between [`KILL_LOCK_ATTEMPTS`] retries.
const KILL_LOCK_RETRY: Duration = Duration::from_millis(1);

fn kill_slot(slot: &Arc<ChildSlot>) {
    kill_slot_with(slot, KILL_LOCK_ATTEMPTS, KILL_LOCK_RETRY)
}

/// [`kill_slot`] over injectable retry parameters, so a test can widen the
/// retry budget against a lock held for a fixed, known duration instead of
/// racing it against the production constants (a comparison of two
/// scheduler-controlled durations, which is exactly what makes that race
/// flaky).
fn kill_slot_with(slot: &Arc<ChildSlot>, attempts: u32, retry: Duration) {
    for attempt in 0..attempts {
        match try_lock_recovering(slot) {
            Some(mut inner) => {
                inner.kill();
                return;
            }
            None if attempt + 1 < attempts => {
                std::thread::sleep(retry);
            }
            None => {}
        }
    }
}

fn lock_recovering<T>(m: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

fn try_lock_recovering<T>(m: &Mutex<T>) -> Option<std::sync::MutexGuard<'_, T>> {
    match m.try_lock() {
        Ok(guard) => Some(guard),
        Err(TryLockError::Poisoned(e)) => Some(e.into_inner()),
        Err(TryLockError::WouldBlock) => None,
    }
}

#[cfg(test)]
mod tests;
