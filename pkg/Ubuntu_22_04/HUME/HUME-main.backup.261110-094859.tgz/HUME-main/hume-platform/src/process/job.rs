//! One-shot subprocess capture: run a command to completion and deliver its
//! whole stdout, whole stderr, and exit status once: the shape
//! `spawn-async!` and `pipe` need, as opposed to `line_source`'s per-line
//! streaming.
//!
//! Completion here is the child *exiting*, which is not implied by its
//! pipes reaching EOF. A child can close (or exec away from) its stdio
//! while continuing to run, so "both pipes at EOF" is not "the child is
//! done". The capture thread this module spawns is free to block, so it
//! reads stdout to EOF, joins the stderr thread, then waits for the child's
//! real exit status with
//! [`TrackedChild::wait_for_exit`](crate::process::tracked::TrackedChild::wait_for_exit),
//! which leaves the shared slot's lock free for a concurrent
//! `cancel-async!`/`SpawnedJob`'s `Drop`, and only then sends the complete
//! result. [`SpawnedJob::try_take_result`](crate::process::job::SpawnedJob::try_take_result)
//! is a pure receive with no reaping of its own, unlike
//! `line_source::SpawnedLineSource::finish`, which reaps on the main thread
//! because EOF really is completion for a line source.
//!
//! Two capture threads, not one: reading stdout to EOF and then stderr
//! would deadlock on a child that fills its stderr pipe while this thread
//! is still blocked reading stdout, the same hazard
//! [`run_capture`] closes for the sync path.
//! Input is written by a third thread for the same reason: a child that
//! fills its stdout pipe stops reading stdin until someone drains it.

use std::io::{self, Write};
use std::process::{ChildStdin, ExitStatus};
use std::sync::mpsc;
use std::thread::JoinHandle;

use crate::process::child::{OutputCapture, spawn_bridge, spawn_bridge_waking, spawn_piped};
use crate::process::tracked::TrackedChild;
use crate::process::{Launch, decode_lossy};
use crate::wake::WakeCallback;

/// The complete output of a finished [`SpawnedJob`]: whole stdout as raw
/// bytes, left to the caller to decode (never truncated: capped
/// at `STDOUT_CAPTURE_CAP`, but exceeding it fails the job rather than handing
/// back a short prefix), stderr (capped at `STDERR_CAPTURE_CAP`;
/// diagnostic only, so truncation there is fine), and exit status (`None`
/// on a stdout read failure/overflow or a failed stdin write, or if the
/// capture thread's wait for the exit failed or the thread panicked before
/// sending, the last two vanishingly rare).
///
/// Also what the capture thread sends the main thread over the channel,
/// every case above but the panic: a thread that panics before sending is
/// handled separately, by [`SpawnedJob::try_take_result`] synthesizing an
/// empty `JobResult` on channel disconnect.
pub struct JobResult {
    pub stdout: Vec<u8>,
    pub stderr: String,
    pub status: Option<ExitStatus>,
}

impl JobResult {
    /// The result of a job that produced no usable output: no stdout, no
    /// exit status, and `stderr` saying why.
    pub fn failed(stderr: String) -> Self {
        Self {
            stdout: Vec::new(),
            stderr,
            status: None,
        }
    }
}

/// A running external command whose whole output is being captured to
/// completion.
///
/// Owns the child: dropping it kills the child (`Drop` = kill + wait,
/// matching `SpawnedLineSource`), so an abandoned job (cancelled from
/// Steel, or the registry holding it torn down on `:reload-config`) can't
/// leak a process. The child is a [`TrackedChild`], its own process-group
/// leader, so it's also reaped on a force-exit that skips this `Drop`
/// entirely; see `tracked`'s module doc.
pub struct SpawnedJob {
    child: TrackedChild,
    rx: Option<mpsc::Receiver<JobResult>>,
}

/// Spawns `cmd` with `args` (direct argv, no shell) and piped stdio, with
/// `input` written to its stdin, which then closes (at once when `input`
/// is empty). One thread reads stderr to EOF (capped, lenient); a second
/// reads stdout to EOF (capped at `STDOUT_CAPTURE_CAP`, strict: a read error or
/// overflow fails the job), joins the first and the stdin writer, then
/// sends the combined capture once and fires `wake`.
pub fn spawn_job(
    cmd: &str,
    args: &[String],
    launch: Launch<'_>,
    input: Vec<u8>,
    wake: WakeCallback,
) -> io::Result<SpawnedJob> {
    let (child, stdin, stdout, stderr) = spawn_piped(cmd, args, launch, &[])?;
    // Converted to a `TrackedChild` up front, not deferred to the end like
    // `line_source` does. The job thread below needs its own handle to
    // wait for the child's exit status, so it and this function's returned
    // `SpawnedJob` must share the same tracked slot from the start. From
    // here on this function owns reaping the child on every early return
    // (the disarmed `ReapOnDrop` guard no longer covers it).
    let child = TrackedChild::new(child.into_inner());
    let failed = |e| {
        child.reap();
        e
    };

    let (tx, rx) = mpsc::sync_channel::<JobResult>(1);

    let writer = feed_stdin(cmd, stdin, input).map_err(failed)?;

    let capture = OutputCapture::start(cmd, stderr).map_err(failed)?;

    let job_child = child.clone();
    let job_cmd = cmd.to_string();
    // The returned `JoinHandle` is intentionally dropped, not stored:
    // dropping it detaches the thread (same as a bare `thread::spawn`
    // whose handle is discarded). Nothing here ever needs to join it, so
    // keeping it around would just be a field that's written once and read
    // never.
    //
    // The wake fires as the body returns, after the send below, so a
    // panicking read still wakes the drain to observe the synthesized
    // result `try_take_result` produces on disconnect.
    spawn_bridge_waking(cmd, "hume-job", wake, move |_| {
        let (stdout_result, stderr_bytes) = capture.finish(stdout, || {
            job_child.reap();
        });
        let status = job_child.wait_for_exit().ok();
        // Joined after the exit: a writer still blocked on a full pipe
        // is released by the child's death, never the other way round.
        let stdin_result = writer.map_or(Ok(()), |writer| {
            writer
                .join()
                .unwrap_or_else(|_| Err(io::Error::other("stdin writer panicked")))
        });
        let result = match stdout_result.and_then(|out| stdin_result.map(|()| out)) {
            Ok(stdout_bytes) => JobResult {
                stdout: stdout_bytes,
                stderr: decode_lossy(stderr_bytes),
                status,
            },
            // A truncated stdout, or output computed from truncated
            // input, is worse than none: hand back the documented
            // spawn-failure shape (empty stdout, a message in stderr,
            // no exit code) rather than short data.
            Err(e) => JobResult::failed(format!("{job_cmd}: {e}")),
        };
        let _ = tx.send(result);
    })
    .map_err(failed)?;

    Ok(SpawnedJob {
        child,
        rx: Some(rx),
    })
}

/// Writes `input` to `stdin` on its own thread and closes it; empty input
/// closes it at once, with no thread.
fn feed_stdin(
    cmd: &str,
    stdin: ChildStdin,
    input: Vec<u8>,
) -> io::Result<Option<JoinHandle<io::Result<()>>>> {
    if input.is_empty() {
        return Ok(None);
    }
    let writer = spawn_bridge(cmd, "hume-job-stdin", move || {
        let mut stdin = stdin;
        match stdin.write_all(&input) {
            // A child may exit without reading all of its input
            // (`head -1`); its exit status decides whether it failed.
            Err(e) if e.kind() == io::ErrorKind::BrokenPipe => Ok(()),
            other => other.map_err(|e| io::Error::new(e.kind(), format!("writing stdin: {e}"))),
        }
    })?;
    Ok(Some(writer))
}

impl SpawnedJob {
    /// The child's OS process id, for a signal-0 liveness probe independent
    /// of this handle's own state. Test-support only; mirrors
    /// `SpawnedLineSource::pid`.
    #[cfg(any(test, feature = "test-util"))]
    pub fn pid(&self) -> u32 {
        self.child.id()
    }

    /// Non-blocking: `Some` at most once, the moment the capture thread's
    /// single message (stdout, stderr, and the child's real exit status,
    /// already waited for) arrives (or, if that thread panicked before
    /// sending, synthesized as empty output with no status, since the callback
    /// must still fire exactly once). Nothing left to reap here: unlike
    /// `SpawnedLineSource::finish`, the capture thread already confirmed
    /// the child exited before sending.
    pub fn try_take_result(&mut self) -> Option<JobResult> {
        let Some(rx) = &self.rx else {
            return None;
        };
        let result = match rx.try_recv() {
            Ok(result) => result,
            Err(mpsc::TryRecvError::Empty) => return None,
            Err(mpsc::TryRecvError::Disconnected) => JobResult::failed(String::new()),
        };
        self.rx = None;
        Some(result)
    }
}

impl Drop for SpawnedJob {
    fn drop(&mut self) {
        self.child.reap();
        // Bounded channel (capacity 1): the job thread can be blocked
        // mid-`send` if `try_take_result` was never polled; dropping the
        // receiver makes that `send` return `Err`, letting the detached
        // thread exit on its own.
        self.rx = None;
    }
}

#[cfg(test)]
mod tests;
