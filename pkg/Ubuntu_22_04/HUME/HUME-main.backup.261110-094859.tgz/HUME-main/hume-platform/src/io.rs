//! Atomic file I/O with permission and ownership preservation.
//!
//! The key primitive is [`write_file_atomic`]: write to a sibling temp file,
//! restore the original file's permissions and ownership, then `rename(2)` it
//! into place. The caller always sees either the old content or the new content,
//! never a partial write. [`FileMeta`] bundles the metadata captured on open
//! so it can be faithfully restored on save.

use std::fs;
use std::io;
use std::path::Path;
use std::time::SystemTime;

use crate::path::AbsolutePath;

/// A cheap fingerprint of a file's on-disk state, used to detect external
/// changes without reading or hashing content.
///
/// Compares mtime **and** size: some filesystems (HFS+, FAT) only report
/// mtime to one-second resolution, so a same-second rewrite can be invisible
/// to mtime alone. Equality (`!=`), not ordering: restoring a file from a
/// backup moves mtime *backwards* and must still count as a change.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct FileSignature {
    /// `None` on platforms/filesystems that don't report a modification
    /// time. Never conjured into a fake value, since that could compare
    /// equal to a different unset case.
    mtime: Option<SystemTime>,
    size: u64,
}

impl FileSignature {
    /// Extracts the mtime+size fingerprint from an already-fetched
    /// `fs::Metadata`.
    fn from_metadata(metadata: &fs::Metadata) -> Self {
        FileSignature {
            mtime: metadata.modified().ok(),
            size: metadata.len(),
        }
    }
}

/// Read the current [`FileSignature`] of the file at `path`, already
/// resolved, without touching its content.
fn read_signature(path: &Path) -> io::Result<FileSignature> {
    Ok(FileSignature::from_metadata(&fs::metadata(path)?))
}

/// Metadata captured from a file on open, restored when saving atomically.
///
/// Bundles everything the I/O layer needs for a faithful round-trip: the real
/// write target (symlink-resolved), permissions, and ownership. Constructed
/// only by [`read_file_meta`] and [`read_file`]; never built directly.
pub struct FileMeta {
    /// The canonical path after following all symlinks.
    ///
    /// Writes always target this path so the symlink itself is preserved:
    /// `rename(2)` replaces inodes, not symlink targets.
    ///
    /// Private: always produced by [`AbsolutePath::resolve`] inside
    /// `read_file_meta`. A `FileMeta` with an unresolved path would replace
    /// a symlink with a regular file on the next atomic write.
    resolved_path: AbsolutePath,

    /// Original permission bits. Restored on the temp file before the rename
    /// so the file is never transiently exposed with wrong permissions.
    permissions: fs::Permissions,

    /// Original owner UID. Restored with `fchown` (best-effort, Unix only).
    #[cfg(unix)]
    uid: u32,

    /// Original group GID. Restored with `fchown` (best-effort, Unix only).
    #[cfg(unix)]
    gid: u32,

    /// The file's fingerprint as of the last read or write through this
    /// `FileMeta`. Compared against a fresh [`read_file_meta`]'s to detect
    /// external changes; refreshed by [`write_file_atomic`] after a
    /// successful write so the editor's own saves never look external.
    signature: FileSignature,
}

impl FileMeta {
    /// The canonical path after following all symlinks.
    ///
    /// This is the target for atomic writes. Using it ensures the symlink
    /// itself is preserved while the content behind it is updated.
    pub fn resolved_path(&self) -> &AbsolutePath {
        &self.resolved_path
    }

    /// The file's fingerprint as of the last read or write.
    pub fn signature(&self) -> FileSignature {
        self.signature
    }
}

/// Capture metadata for an existing file without reading its content.
///
/// Used when saving over an existing file: we need the permissions and
/// ownership to preserve them, but not the content itself.
pub fn read_file_meta(path: &AbsolutePath) -> io::Result<FileMeta> {
    let resolved = path.resolve()?;
    let metadata = fs::metadata(&resolved)?;
    let signature = FileSignature::from_metadata(&metadata);

    #[cfg(unix)]
    let meta = {
        use std::os::unix::fs::MetadataExt;
        FileMeta {
            resolved_path: resolved,
            permissions: metadata.permissions(),
            uid: metadata.uid(),
            gid: metadata.gid(),
            signature,
        }
    };

    #[cfg(not(unix))]
    let meta = FileMeta {
        resolved_path: resolved,
        permissions: metadata.permissions(),
        signature,
    };

    Ok(meta)
}

/// Read a file from disk, resolving symlinks and capturing metadata.
///
/// Returns `(content, meta)` where:
/// - `content` is the raw file text (CRLF normalization happens in `Buffer::from`)
/// - `meta` carries the resolved path, permissions, ownership, and fingerprint
///   for write-back and external-change detection
///
/// The stat backing `meta.signature` happens in `read_file_meta`, before the
/// content read below. If a writer races us here, storing the *older*
/// signature means a later disk-change check reports a change instead of
/// silently missing one: biased toward a spurious check, never toward a
/// miss.
pub fn read_file(path: &AbsolutePath) -> io::Result<(String, FileMeta)> {
    let meta = read_file_meta(path)?;
    let content = fs::read_to_string(&meta.resolved_path)?;
    Ok((content, meta))
}

/// Write `content` atomically to the path recorded in `meta`. Returns `true`
/// when the `force` chmod-retry path was taken.
///
/// The temp file lives in the target's directory so the rename stays on one
/// filesystem, and gets the target's permissions before the rename. `fchown`
/// (Unix) is best-effort. `force` retries once after a `PermissionDenied`
/// rename by clearing the target's readonly attribute. Atomic on POSIX; on
/// Windows `MoveFileEx` replacement is not crash-atomic.
///
/// On success, re-stats the target to refresh `meta.signature`, otherwise the
/// editor's own save looks like an external change on the next disk-state
/// check. A failed re-stat does not fail the write: the content is already on
/// disk, and a stale signature only biases toward a spurious "changed".
pub fn write_file_atomic(content: &str, meta: &mut FileMeta, force: bool) -> io::Result<bool> {
    let target = &meta.resolved_path;
    let dir = target.parent().unwrap_or(Path::new("."));

    let mut tmp = tempfile::NamedTempFile::new_in(dir)?;
    io::Write::write_all(&mut tmp, content.as_bytes())?;

    // Set permissions before rename, so the window with wrong perms is zero.
    tmp.as_file().set_permissions(meta.permissions.clone())?;

    // fchown requires root or matching uid to succeed; ignore errors so a
    // non-privileged user can still save their own files even if the
    // group-change portion is rejected.
    #[cfg(unix)]
    {
        use nix::unistd::{Gid, Uid, fchown};
        let _ = fchown(
            tmp.as_file(),
            Some(Uid::from_raw(meta.uid)),
            Some(Gid::from_raw(meta.gid)),
        );
    }

    // Note: on POSIX, rename(2) ignores the target file's permission bits when
    // the containing directory is writable, so this PermissionDenied branch is
    // primarily reached on Windows (READONLY attribute) and on exotic POSIX
    // filesystems / ACL setups. It is hard to exercise from a
    // unit test on macOS/Linux without root or chflags.
    let result = match tmp.persist(target) {
        Ok(_) => Ok(false),
        Err(persist_err)
            if force && persist_err.error.kind() == io::ErrorKind::PermissionDenied =>
        {
            // Target is readonly; make it writable just long enough for the
            // rename. After rename(2) the old inode (transiently writable) is
            // unlinked; the new inode already carries meta.permissions, so
            // `set_readonly(false)` on a clone of meta.permissions is enough
            // (the value we pass is overwritten by the rename anyway).
            // Using the cross-platform API is deliberate; PermissionsExt is Unix-only.
            let mut perms = meta.permissions.clone();
            #[allow(clippy::permissions_set_readonly_false)]
            perms.set_readonly(false);
            fs::set_permissions(target, perms)?;
            match persist_err.file.persist(target) {
                Ok(_) => Ok(true),
                Err(retry_err) => {
                    // A failed `:w!` must not leave the target more permissive
                    // than it was. Best-effort restore: if this also fails,
                    // surface the original retry error rather than masking it.
                    let _ = fs::set_permissions(target, meta.permissions.clone());
                    Err(retry_err.error)
                }
            }
        }
        Err(persist_err) => Err(persist_err.error),
    };

    if result.is_ok()
        && let Ok(sig) = read_signature(&meta.resolved_path)
    {
        meta.signature = sig;
    }
    result
}

// ── write_file_new ────────────────────────────────────────────────────────────

/// Write `content` to a **new** file at `path`, creating it with default
/// permissions (0o644 on Unix, inherited from the temp file on Windows).
///
/// Uses the same temp-file + rename strategy as [`write_file_atomic`] so the
/// file is never partially visible even for a new path.
///
/// The file is created at [`AbsolutePath::resolve`]'s form of `path`, so a
/// dangling symlink is written through to the file it names instead of
/// being replaced, as [`write_file_atomic`] does for an existing file. A
/// missing directory on the way fails as `tempfile::NamedTempFile::new_in`
/// fails for it.
///
/// Returns the `FileMeta` for the newly created file, suitable for storing on
/// the `Editor` so that subsequent `:w` (no argument) targets the same path.
pub fn write_file_new(content: &str, path: &AbsolutePath) -> io::Result<FileMeta> {
    let target = path.resolve()?;
    let dir = target.parent().unwrap_or(Path::new("."));

    let mut tmp = tempfile::NamedTempFile::new_in(dir)?;
    io::Write::write_all(&mut tmp, content.as_bytes())?;

    // Set 0o644 (rw-r--r--) before rename: safe default for a new file.
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        tmp.as_file()
            .set_permissions(fs::Permissions::from_mode(0o644))?;
    }

    tmp.persist(&target).map_err(|e| e.error)?;

    // Read back the metadata now that the file exists on disk.
    read_file_meta(&target)
}

/// Fails with `PermissionDenied` unless `meta` describes a regular file that
/// the current user owns. A symlink never passes: its own metadata is not a
/// regular file's.
fn require_own_regular_file(meta: &fs::Metadata) -> io::Result<()> {
    #[cfg(unix)]
    let owned = {
        use std::os::unix::fs::MetadataExt;
        meta.uid() == nix::unistd::geteuid().as_raw()
    };
    #[cfg(not(unix))]
    let owned = true;
    if meta.is_file() && owned {
        Ok(())
    } else {
        Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "not a regular file owned by you",
        ))
    }
}

/// Check, without reading it, that `path` is a regular file the current user
/// owns ([`read_own_file`]'s precondition), not following a symlink.
pub fn check_own_file(path: &Path) -> io::Result<()> {
    require_own_regular_file(&fs::symlink_metadata(path)?)
}

/// Read `path` as text, refusing anything but a regular file the current
/// user owns, as [`open_own_file`] does. Content that is not UTF-8 is an
/// `InvalidData` error.
pub fn read_own_file(path: &Path) -> io::Result<String> {
    let mut content = String::new();
    io::Read::read_to_string(&mut open_own_file(path)?, &mut content)?;
    Ok(content)
}

/// Open `path` for reading, refusing anything but a regular file the current
/// user owns. On Unix the open itself refuses a symlink and the ownership
/// check runs on the opened handle, so the file cannot be swapped between
/// the check and the read.
pub fn open_own_file(path: &Path) -> io::Result<fs::File> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        let file = fs::OpenOptions::new()
            .read(true)
            .custom_flags(nix::fcntl::OFlag::O_NOFOLLOW.bits())
            .open(path)?;
        require_own_regular_file(&file.metadata()?)?;
        Ok(file)
    }
    #[cfg(not(unix))]
    {
        check_own_file(path)?;
        fs::File::open(path)
    }
}

/// Write `content` to `path`, replacing any existing file, readable by the
/// owner only: a crash dump or a saved undo history holds a copy of a
/// possibly private file, so it must not come out world-readable like a
/// freshly created user file. On Unix the temp file keeps `tempfile`'s
/// owner-only mode.
///
/// Same temp-file-and-rename strategy as [`write_file_new`]. There is no
/// fsync: the file has to survive the process ending, which the OS cache
/// guarantees, and a crash dump per buffer inside the terminator's grace
/// period cannot afford one flush each. A machine crash can still lose it.
pub fn write_private_file(content: &[u8], path: &Path) -> io::Result<()> {
    let dir = path.parent().unwrap_or(Path::new("."));

    let mut tmp = tempfile::NamedTempFile::new_in(dir)?;
    io::Write::write_all(&mut tmp, content)?;
    tmp.persist(path).map_err(|e| e.error)?;
    Ok(())
}

/// Create `path` and every missing parent. On Unix each directory this
/// creates is owner-only (`0700`); directories that already exist keep their
/// mode.
pub fn create_private_dir_all(path: &Path) -> io::Result<()> {
    let mut builder = fs::DirBuilder::new();
    builder.recursive(true);
    #[cfg(unix)]
    std::os::unix::fs::DirBuilderExt::mode(&mut builder, 0o700);
    builder.create(path)
}

#[cfg(test)]
mod tests;
