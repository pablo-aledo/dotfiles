//! Unix-only tests, gated once at the `mod unix;` declaration
//! in the parent.

use super::*;

#[test]
fn config_dir_respects_xdg_config_home() {
    let tmp = tempfile::tempdir().unwrap();
    let xdg = tmp.path().to_string_lossy().into_owned();
    let result = config_dir_with(|k| match k {
        "XDG_CONFIG_HOME" => Some(xdg.clone()),
        _ => None,
    });
    assert_eq!(result, Some(tmp.path().join("hume")));
}

#[test]
fn resolve_joins_relative_xdg_dirs_onto_the_startup_cwd() {
    let cwd = tempfile::tempdir().unwrap();
    let dirs = Dirs::resolve(
        |k| match k {
            "XDG_CONFIG_HOME" => Some("cfg".to_string()),
            "XDG_DATA_HOME" => Some("data".to_string()),
            "XDG_STATE_HOME" => Some("state".to_string()),
            _ => None,
        },
        None,
        Some(cwd.path().to_path_buf()),
        PathBuf::from("/tmp"),
        None,
    )
    .unwrap();
    assert_eq!(dirs.config, Some(cwd.path().join("cfg").join("hume")));
    assert_eq!(dirs.data, Some(cwd.path().join("data").join("hume")));
    assert_eq!(dirs.state, Some(cwd.path().join("state").join("hume")));
}

#[test]
fn state_dir_respects_xdg_state_home() {
    let result = state_dir_with(|k| match k {
        "XDG_STATE_HOME" => Some("/xdg/state".to_owned()),
        "HOME" => Some("/home/alice".to_owned()),
        _ => None,
    });
    assert_eq!(result, Some(PathBuf::from("/xdg/state/hume")));
}

#[test]
fn state_dir_falls_back_to_home_local_state() {
    let result = state_dir_with(|k| match k {
        "HOME" => Some("/home/alice".to_owned()),
        _ => None,
    });
    assert_eq!(result, Some(PathBuf::from("/home/alice/.local/state/hume")));
}

#[test]
fn resolve_rejects_a_runtime_that_reaches_the_data_dir_through_a_symlink() {
    let base = tempfile::tempdir().unwrap();
    let data = base.path().join("real").join("hume");
    std::fs::create_dir_all(&data).unwrap();
    let link = base.path().join("link");
    std::os::unix::fs::symlink(base.path().join("real"), &link).unwrap();
    let link_str = link.to_string_lossy().into_owned();
    let data_str = data.to_string_lossy().into_owned();

    let result = Dirs::resolve(
        |k| match k {
            "XDG_DATA_HOME" => Some(link_str.clone()),
            "HUME_RUNTIME" => Some(data_str.clone()),
            _ => None,
        },
        None,
        None,
        PathBuf::from("/tmp"),
        None,
    );
    assert_eq!(result, Err(DirsError::RuntimeIsDataDir(data)));
}

#[test]
fn data_dir_respects_xdg_data_home() {
    let tmp = tempfile::tempdir().unwrap();
    let xdg = tmp.path().to_string_lossy().into_owned();
    let result = data_dir_with(|k| match k {
        "XDG_DATA_HOME" => Some(xdg.clone()),
        _ => None,
    });
    assert_eq!(result, Some(tmp.path().join("hume")));
}

#[test]
fn runtime_dir_prefers_installed_share_layout_over_exe_relative_runtime() {
    // Installed FHS layout: <prefix>/bin/hume -> <prefix>/share/hume/runtime, even
    // when an exe-relative runtime/ also happens to exist (share/ wins).
    let prefix = tempfile::tempdir().unwrap();
    let bin_dir = prefix.path().join("bin");
    std::fs::create_dir(&bin_dir).unwrap();
    std::fs::create_dir(bin_dir.join("runtime")).unwrap();
    let share_runtime = prefix.path().join("share").join("hume").join("runtime");
    std::fs::create_dir_all(&share_runtime).unwrap();

    let result = runtime_dir_with(|_| None, Some(&bin_dir.join("hume")), None);
    assert_eq!(result, Some(share_runtime));
}

#[test]
fn runtime_dir_skips_a_share_hume_without_a_runtime_subdir() {
    // With <prefix> = ~/.local, <prefix>/share/hume is the data dir.
    let prefix = tempfile::tempdir().unwrap();
    let bin_dir = prefix.path().join("bin");
    std::fs::create_dir(&bin_dir).unwrap();
    std::fs::create_dir_all(prefix.path().join("share").join("hume").join("plugins")).unwrap();

    let result = runtime_dir_with(|_| None, Some(&bin_dir.join("hume")), None);
    assert_eq!(result, None);
}

#[test]
fn home_dir_uses_home_env() {
    let result = home_dir_with(|k| match k {
        "HOME" => Some("/home/alice".to_owned()),
        _ => None,
    });
    assert_eq!(result, Some(PathBuf::from("/home/alice")));
}

#[test]
fn home_dir_none_when_home_unset() {
    let result = home_dir_with(|_| None);
    assert_eq!(result, None);
}
