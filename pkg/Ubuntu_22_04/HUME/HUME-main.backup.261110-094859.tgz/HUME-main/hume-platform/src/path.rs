//! Cross-platform path utilities.
//!
//! On Unix the only path separator is `/`.  On Windows both `/` and `\` are
//! accepted by the OS; we recognise either when parsing user input but always
//! emit `/` in completion replacements (Windows file APIs accept forward
//! slashes, and it keeps the rest of the completion logic uniform).
//!
//! Text a person typed becomes a path only through
//! [`AbsolutePath::from_typed`], which applies shell-style tilde and
//! environment-variable expansion (`expand`) first.  Env-var syntax is native
//! per platform: `$VAR` / `${VAR}` on Unix, `%VAR%` on Windows.

use std::borrow::Cow;
use std::io;
use std::path::{Component, Path, PathBuf};

mod absolute;
pub mod programs;

pub use absolute::AbsolutePath;

// ── Path expansion ────────────────────────────────────────────────────────────

/// Platform env-var sigil: `$` on Unix, `%` on Windows.
#[cfg(not(windows))]
const ENV_SIGIL: char = '$';
#[cfg(windows)]
const ENV_SIGIL: char = '%';

/// Expand shell-style tilde and environment-variable references in a
/// user-supplied path string.
///
/// **Tilde**: A leading `~` followed by a path separator or end-of-string is
/// replaced by the current user's home directory (`$HOME` on Unix,
/// `%USERPROFILE%` on Windows).  `~user/foo` forms are **not** expanded (no
/// `getpwnam` lookup).
///
/// **Env vars**: Native syntax per platform: `$VAR` / `${VAR}` on Unix;
/// `%VAR%` on Windows.  Unknown variables are left **literal** (not replaced
/// with an empty string) so that mistyped `$NONEXISTENT/foo` produces a
/// recognisable "no such file" error rather than silently resolving to `/foo`.
///
/// Returns `Cow::Borrowed(s)` unchanged when no expansion is needed, avoiding
/// allocation for the common case of plain absolute or relative paths.
fn expand(s: &str) -> Cow<'_, str> {
    expand_with(s, |k| std::env::var(k), crate::dirs::home_dir)
}

/// Whether `text` a person typed names an absolute path once expanded as
/// [`AbsolutePath::from_typed`] expands it.
pub fn is_absolute_typed(text: &str) -> bool {
    Path::new(expand(text).as_ref()).is_absolute()
}

/// Testable core of [`expand`].
///
/// `env_lookup` mirrors `std::env::var`.  `home_fn` is called at most once to
/// obtain the home directory for tilde expansion.
fn expand_with(
    s: &str,
    env_lookup: impl Fn(&str) -> Result<String, std::env::VarError>,
    home_fn: impl FnOnce() -> Option<std::path::PathBuf>,
) -> Cow<'_, str> {
    if !needs_expansion(s) {
        return Cow::Borrowed(s);
    }

    let mut out = String::with_capacity(s.len() + 16);
    let mut rest = s;

    // Stage 1: tilde
    if let Some(tail) = strip_tilde(rest) {
        if let Some(home) = home_fn() {
            out.push_str(&home.to_string_lossy());
        } else {
            out.push('~'); // HOME unset: pass through literally
        }
        rest = tail; // tail is the portion after `~` (may start with `/`)
    }

    // Stage 2: env vars
    expand_env_vars(rest, &env_lookup, &mut out);

    Cow::Owned(out)
}

fn needs_expansion(s: &str) -> bool {
    s.starts_with('~') || s.contains(ENV_SIGIL)
}

/// If `s` begins with an expandable `~` (i.e. `~` alone, `~/`, or `~\` on
/// Windows), returns the slice **after** the `~`.  Returns `None` for `~user`
/// and any string not starting with `~`.
fn strip_tilde(s: &str) -> Option<&str> {
    if !s.starts_with('~') {
        return None;
    }
    let after = &s[1..];
    if after.is_empty() || after.starts_with('/') || (cfg!(windows) && after.starts_with('\\')) {
        Some(after)
    } else {
        None // `~user` form: do not expand
    }
}

/// Scan `s` for env-var references (Unix `$VAR`/`${VAR}` syntax) and append
/// the expanded result to `out`.  Unknown variables are emitted literally.
#[cfg(not(windows))]
fn expand_env_vars(
    s: &str,
    env_lookup: &impl Fn(&str) -> Result<String, std::env::VarError>,
    out: &mut String,
) {
    let mut remaining = s;
    while let Some(pos) = remaining.find('$') {
        out.push_str(&remaining[..pos]);
        remaining = &remaining[pos + 1..];

        if remaining.is_empty() {
            out.push('$');
            break;
        }

        if remaining.starts_with('{') {
            let after_brace = &remaining[1..];
            let nlen = var_name_len(after_brace);
            if nlen == 0 {
                out.push_str("${");
                remaining = after_brace;
                continue;
            }
            let name = &after_brace[..nlen];
            let after_name = &after_brace[nlen..];
            if let Some(after_close) = after_name.strip_prefix('}') {
                match env_lookup(name) {
                    Ok(val) => out.push_str(&val),
                    Err(_) => {
                        out.push_str("${");
                        out.push_str(name);
                        out.push('}');
                    }
                }
                remaining = after_close;
            } else {
                // Unclosed `${...`: literal.
                out.push_str("${");
                out.push_str(name);
                remaining = after_name;
            }
        } else {
            let nlen = var_name_len(remaining);
            if nlen == 0 {
                out.push('$');
                continue;
            }
            let name = &remaining[..nlen];
            match env_lookup(name) {
                Ok(val) => out.push_str(&val),
                Err(_) => {
                    out.push('$');
                    out.push_str(name);
                }
            }
            remaining = &remaining[nlen..];
        }
    }
    out.push_str(remaining);
}

/// Scan `s` for env-var references (Windows `%VAR%` syntax) and append the
/// expanded result to `out`.  Unknown variables are emitted literally.
#[cfg(windows)]
fn expand_env_vars(
    s: &str,
    env_lookup: &impl Fn(&str) -> Result<String, std::env::VarError>,
    out: &mut String,
) {
    let mut remaining = s;
    while let Some(pos) = remaining.find('%') {
        out.push_str(&remaining[..pos]);
        remaining = &remaining[pos + 1..]; // slice starts just after opening `%`

        let nlen = var_name_len(remaining);
        // Need a non-empty name AND a closing `%`.
        if nlen == 0 || !remaining[nlen..].starts_with('%') {
            out.push('%'); // lone or unclosed `%`: literal
            // `remaining` already past the opening `%`; keep scanning for next.
            continue;
        }
        let name = &remaining[..nlen];
        match env_lookup(name) {
            Ok(val) => out.push_str(&val),
            Err(_) => {
                out.push('%');
                out.push_str(name);
                out.push('%');
            }
        }
        remaining = &remaining[nlen + 1..]; // skip name + closing `%`
    }
    out.push_str(remaining);
}

/// Length in bytes of the leading `[A-Za-z_][A-Za-z0-9_]*` identifier in `s`.
/// Returns `0` if `s` does not start with a valid identifier character.
fn var_name_len(s: &str) -> usize {
    let mut end = 0;
    for (i, c) in s.char_indices() {
        if i == 0 && !(c.is_ascii_alphabetic() || c == '_') {
            return 0;
        }
        if c.is_ascii_alphanumeric() || c == '_' {
            end = i + c.len_utf8();
        } else {
            break;
        }
    }
    end
}

// ── Home shortening ───────────────────────────────────────────────────────────

/// Replace the user's home directory prefix with `~` for display.
///
/// `"/home/user/dev/hume"` → `"~/dev/hume"`.  Exact match returns `"~"`.
/// When `home_dir()` is unavailable or the path does not start with the home
/// directory, the full path is returned unchanged.
fn shorten_home_with(
    path: &std::path::Path,
    home_fn: impl FnOnce() -> Option<std::path::PathBuf>,
) -> String {
    if let Some(home) = home_fn() {
        match path.strip_prefix(&home) {
            Ok(suffix) if suffix.as_os_str().is_empty() => "~".to_string(),
            Ok(suffix) => format!("~{}{}", std::path::MAIN_SEPARATOR, suffix.display()),
            Err(_) => path.display().to_string(),
        }
    } else {
        path.display().to_string()
    }
}

/// Single display pipeline for absolute paths: strip the Windows `\\?\`
/// verbatim prefix, then collapse the home prefix to `~`. All user-facing
/// path strings (`Buffer::display_path`, cwd displays) are produced here.
///
/// Order matters: the home-prefix match is against the clean `C:\Users\...`
/// form, which a verbatim-prefixed string wouldn't match.
pub fn display_form(path: &std::path::Path) -> String {
    display_form_with(path, crate::dirs::home_dir)
}

fn display_form_with(
    path: &std::path::Path,
    home_fn: impl FnOnce() -> Option<std::path::PathBuf>,
) -> String {
    shorten_home_with(strip_unc_prefix_cow(path).as_ref(), home_fn)
}

/// `path` relative to `base`, or `None` when `path` isn't inside `base`.
pub fn relative_to(path: &AbsolutePath, base: &AbsolutePath) -> Option<PathBuf> {
    path.strip_prefix(base).ok().map(Path::to_path_buf)
}

/// Where `path` is mirrored under `base`: each of its components as a nested
/// directory, with `suffix` appended to the last name. A Windows drive
/// becomes its letter and a UNC share `UNC/<server>/<share>`, so distinct
/// paths never share a mirror. `None` for a root, a `.` or `..` component, or
/// any other prefix.
pub fn mirrored_under(base: &Path, path: &AbsolutePath, suffix: &str) -> Option<PathBuf> {
    let mut mirror = base.to_path_buf();
    for component in path.components() {
        match component {
            Component::Prefix(prefix) => push_prefix(&mut mirror, prefix.kind())?,
            Component::RootDir => {}
            Component::Normal(name) => mirror.push(name),
            Component::CurDir | Component::ParentDir => return None,
        }
    }
    let mut name = path.file_name()?.to_os_string();
    name.push(suffix);
    mirror.set_file_name(name);
    Some(mirror)
}

fn push_prefix(mirror: &mut PathBuf, prefix: std::path::Prefix<'_>) -> Option<()> {
    use std::path::Prefix;
    match prefix {
        Prefix::Disk(letter) | Prefix::VerbatimDisk(letter) => {
            mirror.push(char::from(letter.to_ascii_uppercase()).to_string());
        }
        Prefix::UNC(server, share) | Prefix::VerbatimUNC(server, share) => {
            if [server, share].iter().any(|s| *s == "." || *s == "..") {
                return None;
            }
            mirror.push("UNC");
            mirror.push(server);
            mirror.push(share);
        }
        Prefix::Verbatim(_) | Prefix::DeviceNS(_) => return None,
    }
    Some(())
}

// ── Separator utilities ───────────────────────────────────────────────────────

/// Returns `true` if `c` is a path-component separator on the current platform.
///
/// Always true for `/`.  Also true for `\` on Windows, where `\` cannot appear
/// in a filename and is therefore unambiguously a separator.  On Unix `\` is a
/// valid filename character and must **not** be treated as a separator.
pub fn is_path_sep(c: char) -> bool {
    c == '/' || (cfg!(windows) && c == '\\')
}

/// Split a path prefix at the last separator, returning `(dir, filename_prefix)`.
///
/// `dir` includes the trailing separator so it can be used directly as a
/// prefix when building completion replacements.  If there is no separator,
/// `dir` is `""` and `filename_prefix` is the whole string.
///
/// `split_path_at_sep("foo/bar")` → `("foo/", "bar")`;
/// `split_path_at_sep("/tmp/")` → `("/tmp/", "")`;
/// `split_path_at_sep("foo")` → `("", "foo")`.
pub fn split_path_at_sep(s: &str) -> (&str, &str) {
    match s.rfind(is_path_sep) {
        Some(i) => (&s[..=i], &s[i + 1..]),
        None => ("", s),
    }
}

// ── Directory entries for completion ─────────────────────────────────────────

/// Whether file name `name` starts with `prefix`, as the platform's file
/// system compares names: without regard to ASCII case on Windows.
fn name_starts_with(name: &str, prefix: &str) -> bool {
    if cfg!(windows) {
        name.get(..prefix.len())
            .is_some_and(|head| head.eq_ignore_ascii_case(prefix))
    } else {
        name.starts_with(prefix)
    }
}

/// The names in directory `dir` that start with `prefix`, sorted, each
/// directory with a trailing `/`: what a typed path completes to. A
/// symlink is listed as what it points at. Names match `prefix` as the
/// file system compares them: without regard to ASCII case on Windows.
/// Hidden entries (a leading `.`) are left out unless `prefix` starts with
/// `.`, and with `dirs_only` every non-directory is. An unreadable
/// directory lists nothing.
pub fn completion_entries(dir: &Path, prefix: &str, dirs_only: bool) -> Vec<String> {
    let include_hidden = prefix.starts_with('.');
    let Ok(entries) = std::fs::read_dir(dir) else {
        return Vec::new();
    };
    let mut names: Vec<String> = entries
        .flatten()
        .filter_map(|entry| {
            let name = entry.file_name().to_string_lossy().into_owned();
            if !name_starts_with(&name, prefix) || (!include_hidden && name.starts_with('.')) {
                return None;
            }
            // Only a symlink costs a `stat`; the listing gives every other
            // entry's type.
            let is_dir = entry
                .file_type()
                .is_ok_and(|ft| ft.is_dir() || (ft.is_symlink() && entry.path().is_dir()));
            if dirs_only && !is_dir {
                return None;
            }
            Some(if is_dir { name + "/" } else { name })
        })
        .collect();
    names.sort_unstable();
    names
}

// ── Windows UNC prefix ───────────────────────────────────────────────────────

/// If `p` carries the `\\?\` verbatim **drive** prefix, returns the plain
/// drive-letter form it strips down to (e.g. `C:\Users\…\hume`).  Verbatim
/// UNC paths (`\\?\UNC\…`) are left alone (`None`) since they are rare
/// and the `\\` prefix they'd collapse to is already a valid UNC path.
#[cfg(windows)]
pub fn strip_verbatim(p: &Path) -> Option<&str> {
    const VERBATIM: &str = r"\\?\";
    match p.to_str() {
        Some(s) if s.starts_with(VERBATIM) && !s[VERBATIM.len()..].starts_with("UNC\\") => {
            Some(&s[VERBATIM.len()..])
        }
        _ => None,
    }
}

/// Strip the `\\?\` extended-length prefix from a Windows path so that the
/// result is a plain drive-letter path (e.g. `C:\Users\…\hume`).
///
/// Plain drive paths accept forward slashes from Scheme's `string-append`;
/// `\\?\`-prefixed paths go through the NT object manager directly and are
/// strict about backslashes.  Scheme plugins build paths via `(path-join …)`
/// which uses the native separator, but the display form must be prefix-free
/// so that even old-style string concatenation doesn't produce malformed paths.
///
/// Only strips verbatim drive prefixes (`\\?\C:\…`).  Verbatim UNC paths
/// (`\\?\UNC\…`) are left unchanged; they are rare and the `\\` prefix they
/// collapse to is already a valid UNC path.
///
/// On non-Windows targets this is a no-op.
#[cfg(windows)]
pub fn strip_unc_prefix(p: PathBuf) -> PathBuf {
    match strip_verbatim(&p) {
        Some(s) => PathBuf::from(s),
        None => p,
    }
}

#[cfg(not(windows))]
#[inline]
pub fn strip_unc_prefix(p: PathBuf) -> PathBuf {
    p
}

/// Borrowing sibling of [`strip_unc_prefix`] for call sites that only read
/// the result (scanning many candidate paths against a needle, a `Command`'s
/// cwd). Avoids an allocation per candidate when no verbatim prefix is
/// present to strip, which off Windows is every call.
#[cfg(windows)]
pub fn strip_unc_prefix_cow(p: &Path) -> Cow<'_, Path> {
    match strip_verbatim(p) {
        Some(s) => Cow::Owned(PathBuf::from(s)),
        None => Cow::Borrowed(p),
    }
}

#[cfg(not(windows))]
#[inline]
pub fn strip_unc_prefix_cow(p: &Path) -> Cow<'_, Path> {
    Cow::Borrowed(p)
}

// ── Path safety helpers ───────────────────────────────────────────────────────

/// `typed` joined onto `cwd` when relative and made absolute the way the OS
/// resolves it: `.` and repeated or trailing separators collapse, and `..`
/// leaves the directory it follows, which after a symlink is the link
/// target's parent. Symlinks after the last `..` are kept. Windows resolves
/// `..` by name.
///
/// Fails with `InvalidInput` for a Windows drive-relative path (`D:foo`),
/// which joined onto `cwd` stays relative, and with the filesystem's error
/// when a `..` follows a directory that cannot be resolved.
pub fn absolute(typed: &Path, cwd: &Path) -> io::Result<PathBuf> {
    let joined = cwd.join(typed);
    if !joined.is_absolute() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("{}: not an absolute path", joined.display()),
        ));
    }
    let absolute = std::path::absolute(&joined)?;
    let components: Vec<Component> = absolute.components().collect();
    let Some(last_parent) = components.iter().rposition(|c| *c == Component::ParentDir) else {
        return Ok(components.iter().collect());
    };
    let (through_parent, rest) = components.split_at(last_parent + 1);
    let mut resolved = std::fs::canonicalize(through_parent.iter().collect::<PathBuf>())?;
    resolved.extend(rest);
    Ok(resolved)
}

/// Returns `true` if `s` is a valid, safe filesystem path segment.
///
/// A valid segment is:
/// - Non-empty
/// - Not `.` or `..`
/// - Contains no `/`, `\`, `"`, `:`, or NUL character
///
/// Dots elsewhere are permitted (e.g. `v1.2.3`).  The `\`, `"`, and `:`
/// rejections are cross-platform intentional: on Unix all three are
/// technically valid filename characters, but `\` is unsafe in portable
/// paths, `"` is invalid in Windows filenames (and unsafe to embed in quoted
/// contexts), and `:` after a single letter makes `PathBuf::push` treat the
/// segment as a drive-relative root on Windows, replacing the sandboxed base
/// path entirely instead of joining onto it (e.g. `c:evil` under
/// `data_dir/plugins/`).
///
/// Used to validate plugin-name components and path arguments before they are
/// joined onto sandboxed base directories.
pub fn is_safe_segment(s: &str) -> bool {
    !s.is_empty()
        && s != "."
        && s != ".."
        && s.chars()
            .all(|c| c != '/' && c != '\\' && c != '"' && c != '\0' && c != ':')
}

#[cfg(test)]
mod tests;

#[cfg(all(unix, any(test, feature = "test-util")))]
pub mod test_support;
