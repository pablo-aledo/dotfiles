//! Directory state for HUME's scripting layer: raw + display-form data/runtime
//! dirs (`data-dir`/`runtime-dir`), computed once and shared by every builtin
//! that needs them. There is no sandbox here; see `user-manual/docs/writing-plugins.md`'s
//! "Filesystem and processes".
//!
//! One [`ScriptDirs`] is built once by [`crate::ScriptingHost::new`] and
//! borrowed into every [`crate::context::SteelCtx`]: no thread-local, no
//! separate init call.

use std::path::PathBuf;

use hume_platform::dirs::Dirs;
use hume_platform::path::AbsolutePath;

// ── Directory state ──────────────────────────────────────────────────────────

pub(crate) struct ScriptDirs {
    /// `$XDG_DATA_HOME/hume/` (or platform equivalent), where PLUM installs
    /// user/third-party plugins. Raw, uncanonicalized.
    pub(crate) data_dir: Option<PathBuf>,
    /// Where core plugins, themes, and docs live. Raw, uncanonicalized.
    pub(crate) runtime_dir: Option<PathBuf>,
    /// `<data>/hume/` as a *display* (non-UNC) path: what `(data-dir)` returns
    /// to Scheme.  On Windows the canonical form carries a `\\?\` prefix that
    /// the NT object manager does not accept with forward slashes, so we expose
    /// the plain drive-letter form instead (e.g. `C:\Users\…\hume`).
    pub(crate) data_dir_display: Option<PathBuf>,
    /// `<runtime>/` as a display path (same UNC reasoning).
    pub(crate) runtime_dir_display: Option<AbsolutePath>,
    /// The directory holding the user's `init.scm`; a local plugin's
    /// `./file.scm` resolves against it. `None` until `eval_init` sets it, so
    /// it stays unset under `--no-config`.
    pub(crate) init_dir: Option<PathBuf>,
}

impl ScriptDirs {
    /// Compute all derived directory state from `dirs`. With no data or
    /// runtime dir it does no filesystem work at all.
    pub(crate) fn new(dirs: &Dirs) -> Self {
        let data_dir = dirs.data.clone();
        let runtime_dir = dirs.runtime.clone();
        // The display forms are canonical `AbsolutePath`s, free of a `\\?\`
        // prefix, so Scheme can concatenate `/`-separated segments on Windows.
        // A data dir that doesn't exist (e.g. sandboxed FS test environments)
        // displays as given.
        let data_dir_display = data_dir
            .clone()
            .map(|d| AbsolutePath::canonicalize(&d).map_or(d, |canonical| canonical.to_path_buf()));
        let runtime_dir_display = runtime_dir
            .as_deref()
            .and_then(|rt| AbsolutePath::canonicalize(rt).ok());

        Self {
            data_dir,
            runtime_dir,
            data_dir_display,
            runtime_dir_display,
            init_dir: None,
        }
    }
}
