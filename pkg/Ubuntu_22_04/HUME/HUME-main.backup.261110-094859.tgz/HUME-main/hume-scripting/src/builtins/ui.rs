//! Generic Steel-scriptable UI widget builtins.
//!
//! LSP is the first client of these widgets, not their owner: any plugin
//! can call `show-popup!`. `hume-editor`'s `EditorHostImpl` is the only
//! implementation that actually renders anything; other hosts (tests,
//! `MockHost`) have no `UiHost`, so `ctx.host.ui()` returns `None` and each
//! builtin surfaces `require_cap`'s "not supported by this host" instead.

use steel::rerrs::SteelErr;
use steel::rvals::SteelVal;

use hume_core::{NonEmpty, PopupLayout};
use hume_rope::spanned::SpannedText;

use crate::host::{
    DrawerItems, FocusedHandle, LivePickerOpts, PickerBinding, PickerCommonOpts, PickerFeedMode,
    PickerOpts, PickerSourceOpts, PickerStep, PopupKind, RowDisplay, RowSpanScopes,
};
use crate::{Callback, Rooted, SteelCtx};

use super::SteelResult;
use super::args::{
    END_CHAR, START_CHAR, bool_arg, callback_arg, cons_pair, cwd_arg, hash_entry, hash_list,
    int_arg, list_items, list_to_i32s, list_to_strings, optional_callback_arg, optional_string_arg,
    pair_fields, single_key, spanned_text, string_arg, symbol_enum_arg, token_arg, token_or_false,
    truncate_end_arg, usize_arg, write_item_label,
};
use super::errors::{generic_err, require_cap};

/// `(%show-popup! pane text anchor kind lang)`: the `show-popup!` Scheme
/// wrapper supplies `#:anchor`/`#:kind`/`#:lang`'s defaults. Returns a token
/// for `close-popup!`, or `#f` when the popup was dropped. `anchor` selects the
/// render layout: `'cursor` floats near the focused pane's cursor (default);
/// `'bottom` docks as a full-width band above the statusline, reserving pane
/// space like the drawer; `'fit` is either, by whether the text fits the
/// cursor box. `kind` selects the dismiss behavior; see
/// [`PopupKind`].
pub(crate) fn show_popup(
    ctx: &mut SteelCtx,
    pane: FocusedHandle,
    text: SteelVal,
    anchor: SteelVal,
    kind: SteelVal,
    lang: SteelVal,
) -> SteelResult {
    let text = string_arg(text, "text")?;
    let anchor = string_arg(anchor, "#:anchor")?;
    let layout = symbol_enum_arg(&anchor, "#:anchor", &PopupLayout::NAMED)?;
    let kind = string_arg(kind, "#:kind")?;
    let kind = symbol_enum_arg(&kind, "#:kind", &PopupKind::NAMED)?;
    let lang = optional_string_arg(lang, "#:lang")?;
    let token = require_cap(ctx.host.ui())?
        .show_popup(pane, text, kind, layout, lang)
        .map_err(generic_err)?;
    Ok(token_or_false(token))
}

/// `(close-popup! token)`. A `#f` token (the opener returned `#f`, or the
/// popup has since closed) is a no-op, same as any other stale token.
pub(crate) fn close_popup(ctx: &mut SteelCtx, token: SteelVal) -> SteelResult {
    let token = token_arg(token, "token")?;
    require_cap(ctx.host.ui())?
        .close_popup(token)
        .map(|()| SteelVal::Void)
        .map_err(generic_err)
}

/// `(show-menu! pane items on-select)`: no keyword defaults, so this
/// registers directly (no `%`-prefix wrapper needed). Returns a token for
/// `close-menu!`, or `#f` when the call was dropped as stale.
pub(crate) fn show_menu(
    ctx: &mut SteelCtx,
    pane: FocusedHandle,
    items: SteelVal,
    on_select: Callback,
) -> SteelResult {
    let items = non_empty(display_items(items, "items", row_display)?, "items")?;
    let token = require_cap(ctx.host.ui())?
        .show_menu(pane, items, on_select)
        .map_err(generic_err)?;
    Ok(token_or_false(token))
}

/// `(close-menu! token)`. A `#f` token is a no-op, same as `close-popup!`.
pub(crate) fn close_menu(ctx: &mut SteelCtx, token: SteelVal) -> SteelResult {
    let token = token_arg(token, "token")?;
    require_cap(ctx.host.ui())?
        .close_menu(token)
        .map(|()| SteelVal::Void)
        .map_err(generic_err)
}

/// `(%show-drawer-list! pane items on-select selected truncate render)`,
/// behind `show-drawer-list!`'s `#:selected`/`#:truncate`/`#:render` keyword
/// wrapper (see [`drawer_items`] for the rows and `render`). `selected` is
/// clamped into `items`; `truncate` is the end of an over-long row the
/// drawer cuts. A row whose spans don't fit its text raises.
/// Returns a token scoping
/// `close-drawer!`/`update-drawer-list!`/`drawer-selection` to this
/// drawer, same shape as `picker!`'s own return, or `#f` when the request
/// was dropped as stale (the stack moved before it could open; see
/// `UiHost::show_drawer_list`'s own doc), which callers must branch on
/// rather than treat as a live drawer's token.
pub(crate) fn show_drawer_list(
    ctx: &mut SteelCtx,
    pane: FocusedHandle,
    items: SteelVal,
    on_select: Callback,
    selected: SteelVal,
    truncate: SteelVal,
    render: SteelVal,
) -> SteelResult {
    let items = drawer_items(ctx, items, render)?;
    let selected = usize_arg(selected, "selected")?;
    let truncate = truncate_end_arg(truncate, "#:truncate")?;
    let token = require_cap(ctx.host.ui())?
        .show_drawer_list(pane, items, on_select, selected, truncate)
        .map_err(generic_err)?;
    Ok(token_or_false(token))
}

/// `(close-drawer! token)`. A `#f` token is a no-op, same as `close-popup!`.
pub(crate) fn close_drawer(ctx: &mut SteelCtx, token: SteelVal) -> SteelResult {
    let token = token_arg(token, "token")?;
    require_cap(ctx.host.ui())?
        .close_drawer(token)
        .map(|()| SteelVal::Void)
        .map_err(generic_err)
}

/// `(%update-drawer-list! token items on-select selected render)`, behind
/// `update-drawer-list!`'s `#:render` keyword wrapper (see [`drawer_items`]
/// for `render`). Replaces the open drawer's rows in place, keeping the
/// browse session and the `#:truncate` end it opened with; `selected` is
/// clamped into the new list. Returns whether the update applied: `#f` when no drawer is open
/// or `token` doesn't match the open drawer's own (an expected-normal race,
/// never an error, same contract as `picker-replace!`'s stale token). A row
/// whose spans don't fit its text raises, as in `show-drawer-list!`.
pub(crate) fn update_drawer_list(
    ctx: &mut SteelCtx,
    token: SteelVal,
    items: SteelVal,
    on_select: Callback,
    selected: SteelVal,
    render: SteelVal,
) -> SteelResult {
    let token = token_arg(token, "token")?;
    let items = drawer_items(ctx, items, render)?;
    let selected = usize_arg(selected, "selected")?;
    let applied = require_cap(ctx.host.ui())?.update_drawer_list(token, items, on_select, selected);
    Ok(SteelVal::BoolV(applied))
}

/// A drawer's `items`: `(display . payload)` pairs when `render` is `#f`,
/// each display decoded by [`row_display`], otherwise opaque keys
/// rendered on demand by the `render` proc, each its row's payload.
fn drawer_items(
    ctx: &SteelCtx,
    items: SteelVal,
    render: SteelVal,
) -> Result<DrawerItems, SteelErr> {
    Ok(match optional_callback_arg(ctx, render, 2, "#:render")? {
        None => DrawerItems::Rows(non_empty(
            display_items(items, "items", row_display)?,
            "items",
        )?),
        Some(render) => DrawerItems::Keys {
            keys: non_empty(
                list_items(items, "items")?
                    .into_iter()
                    .map(|key| row_payload(key, "items"))
                    .collect::<Result<_, _>>()?,
                "items",
            )?,
            render,
        },
    })
}

/// `items` as a [`NonEmpty`]: a menu or drawer with no row has no item for
/// its selection to name.
fn non_empty<T>(items: Vec<T>, ctx_name: &str) -> Result<NonEmpty<T>, SteelErr> {
    match NonEmpty::new(items) {
        Some(items) => Ok(items),
        None => steel::stop!(Generic => "{}: must not be empty", ctx_name),
    }
}

/// `(drawer-selection token)`: the open drawer's selected row as
/// `(item . index)`, or `#f` when no drawer is open, `token` doesn't match
/// its own, or `token` itself is `#f` (the opener that produced it returned
/// `#f`).
pub(crate) fn drawer_selection(ctx: &mut SteelCtx, token: SteelVal) -> SteelResult {
    let token = token_arg(token, "token")?;
    match require_cap(ctx.host.ui())?.drawer_selection(token) {
        Some((item, idx)) => cons_pair(item, SteelVal::IntV(idx as isize)),
        None => Ok(SteelVal::BoolV(false)),
    }
}

/// `(%prompt! label prefill on-confirm)`: the `prompt!` Scheme wrapper
/// supplies `#:prefill`'s default. `on-confirm` fires once, later
/// (queued, never inline), with the confirmed text, or `#f` on cancel.
pub(crate) fn prompt(
    ctx: &mut SteelCtx,
    pane: FocusedHandle,
    label: SteelVal,
    prefill: SteelVal,
    on_confirm: Callback,
) -> SteelResult {
    let label = string_arg(label, "label")?;
    let prefill = string_arg(prefill, "prefill")?;
    require_cap(ctx.host.ui())?
        .prompt(pane, label, prefill, on_confirm)
        .map(|()| SteelVal::Void)
        .map_err(generic_err)
}

/// `(on-next-char! callback)`: the next key typed calls `callback` with its
/// character (Enter and Tab as `#\newline` and `#\tab`), or with `#f` when
/// that key isn't a character or the wait ends any other way. Queued, never
/// inline, like every other Rust→Steel call. A callback that calls
/// `on-next-char!` again reads one more character. During `.` the callback
/// gets the character the repeated command read, at once, and the call
/// raises when the repeated command read fewer.
pub(crate) fn on_next_char(ctx: &mut SteelCtx, callback: Callback) -> SteelResult {
    require_cap(ctx.host.ui())?
        .on_next_char(callback)
        .map(|()| SteelVal::Void)
        .map_err(generic_err)
}

/// Decodes a picker, menu or drawer `items` list: each entry must be a `(display . payload)`
/// dotted pair; a proper list entry is rejected by `pair_fields`.
/// `display` decodes each display. `payload` stays an opaque `SteelVal`; Rust
/// never interprets it, except to reject `#f`: that value means no row (a
/// dismissed menu or drawer, a picker binding run with nothing matching),
/// so a `#f` payload would make a chosen row indistinguishable from none.
fn display_items<D>(
    items: SteelVal,
    ctx_name: &str,
    display: impl Fn(SteelVal, &str) -> Result<D, SteelErr>,
) -> Result<Vec<(D, Rooted)>, SteelErr> {
    let mut label = String::new();
    list_items(items, ctx_name)?
        .into_iter()
        .enumerate()
        .map(|(i, entry)| {
            write_item_label(&mut label, ctx_name, i);
            let (shown, payload) = pair_fields(entry, &label, "(display . payload)")?;
            Ok((display(shown, &label)?, row_payload(payload, &label)?))
        })
        .collect()
}

const ROW_DISPLAY_KEYS: &[&str] = &["text", "spans", "selected-scope"];
const ROW_SPAN_KEYS: &[&str] = &[START_CHAR, END_CHAR, "scope", "selected-scope"];

/// One list row's display (a drawer row, a menu row, a row a picker's
/// `#:render` returns): a string (or a symbol, read as its name), or
/// `(hash 'text t)` with optional `'spans spans` and `'selected-scope name`,
/// each span a `(hash 'start-char s 'end-char e 'scope name)` with an
/// optional `'selected-scope name`.
pub(crate) fn row_display(val: SteelVal, ctx_name: &str) -> Result<RowDisplay, SteelErr> {
    match val {
        SteelVal::HashMapV(_) => {
            let entry = hash_entry(val, ctx_name, ROW_DISPLAY_KEYS)?;
            let text = entry.string("text")?;
            let content = match entry.optional("spans") {
                Some(spans) => {
                    let spans_label = entry.label("spans");
                    let spans = hash_list(spans, &spans_label, ROW_SPAN_KEYS, |span| {
                        let (start, end) = span.char_range()?;
                        let scopes = RowSpanScopes {
                            scope: span.string("scope")?,
                            selected: span.optional_string("selected-scope")?,
                        };
                        Ok((start, end, scopes))
                    })?;
                    spanned_text(text, spans, &spans_label)?
                }
                None => SpannedText::plain(text),
            };
            Ok(RowDisplay {
                content,
                selected_scope: entry.optional_string("selected-scope")?,
            })
        }
        SteelVal::StringV(_) | SteelVal::SymbolV(_) => Ok(RowDisplay {
            content: SpannedText::plain(string_arg(val, ctx_name)?),
            selected_scope: None,
        }),
        _ => steel::stop!(TypeMismatch =>
            "{}: expected a string or (hash 'text t ...)", ctx_name),
    }
}

/// What a picker, menu or drawer row hands its callback: anything but `#f`,
/// which the callback gets for no row (a dismissed menu, a picker with
/// nothing matching).
fn row_payload(payload: SteelVal, ctx_name: &str) -> Result<Rooted, SteelErr> {
    // absent-decode-safe: #f here is the reserved no-row sentinel being rejected, not an absent optional
    if matches!(payload, SteelVal::BoolV(false)) {
        steel::stop!(Generic => "{}: item payload must not be #f (#f is reserved for no item)", ctx_name);
    }
    Ok(Rooted::new(payload))
}

/// Decodes `picker!`'s/`live-picker!`'s `keymap`: a hashmap from key spec
/// to a procedure of two arguments (the selected item and the picker's
/// token). Each spec must parse (via [`single_key`]) to one
/// `KeyEvent`: the picker dispatches one chord at a time, so a multi-key
/// spec like `"z f"` binding only its first key would be a trap. Two specs
/// naming the same key are caught by the editor, which owns key identity.
fn picker_keymap(
    ctx: &SteelCtx,
    keymap: SteelVal,
    ctx_name: &str,
) -> Result<Vec<PickerBinding>, SteelErr> {
    let SteelVal::HashMapV(map) = keymap else {
        steel::stop!(TypeMismatch => "{}: expected a hashmap from key spec to procedure", ctx_name);
    };
    map.iter()
        .map(|(spec, binding)| {
            let spec = string_arg(spec.clone(), ctx_name)?;
            Ok(PickerBinding {
                key: single_key(&spec, ctx_name)?,
                spec,
                binding: callback_arg(ctx, binding.clone(), 2, ctx_name)?,
            })
        })
        .collect()
}

/// `(%picker! items keymap prompt pending query truncate render on-close)`: the
/// `picker!` Scheme wrapper supplies the keyword defaults. Returns the new
/// session's token.
// Each param is a positional/keyword arg the `builtins!` table maps 1:1 from
// `picker!`'s own Steel signature. Bundling them into a struct would break
// that direct correspondence for no benefit, since every arg is already
// decoded and validated independently right below.
#[allow(clippy::too_many_arguments)]
pub(crate) fn picker(
    ctx: &mut SteelCtx,
    pane: FocusedHandle,
    items: SteelVal,
    keymap: SteelVal,
    prompt: SteelVal,
    pending: SteelVal,
    query: SteelVal,
    truncate: SteelVal,
    render: SteelVal,
    on_close: SteelVal,
) -> SteelResult {
    let items = display_items(items, "items", string_arg)?;
    let keymap = picker_keymap(ctx, keymap, "keymap")?;
    let pending = bool_arg(pending, "#:pending")?;
    let common = picker_common_opts(ctx, prompt, query, truncate, render, on_close)?;
    let opts = PickerOpts { common, pending };
    let token = require_cap(ctx.host.ui())?
        .open_picker(pane, items, keymap, opts)
        .map_err(generic_err)?;
    Ok(token_or_false(token))
}

/// `(%live-picker! keymap prompt query on-query-change truncate render on-close)`:
/// the `live-picker!` Scheme wrapper supplies the keyword defaults and
/// composes `on-query-change` itself (stop-then-debounce around the
/// caller's `#:source`); this layer only decodes it as a required
/// callable.
// Same shape as `picker`'s own allow, just above: each param is a
// positional/keyword arg the `builtins!` table maps 1:1 from `live-picker!`'s
// own Steel signature. Bundling them into a struct would break that direct
// correspondence for no benefit, since every arg is already decoded and
// validated independently right below.
#[allow(clippy::too_many_arguments)]
pub(crate) fn live_picker(
    ctx: &mut SteelCtx,
    pane: FocusedHandle,
    keymap: SteelVal,
    prompt: SteelVal,
    query: SteelVal,
    on_query_change: SteelVal,
    truncate: SteelVal,
    render: SteelVal,
    on_close: SteelVal,
) -> SteelResult {
    let keymap = picker_keymap(ctx, keymap, "keymap")?;
    let on_query_change = callback_arg(ctx, on_query_change, 2, "on-query-change")?;
    let common = picker_common_opts(ctx, prompt, query, truncate, render, on_close)?;
    let opts = LivePickerOpts {
        common,
        on_query_change,
    };
    let token = require_cap(ctx.host.ui())?
        .open_live_picker(pane, keymap, opts)
        .map_err(generic_err)?;
    Ok(token_or_false(token))
}

/// The keywords `picker!` and `live-picker!` share, decoded.
fn picker_common_opts(
    ctx: &SteelCtx,
    prompt: SteelVal,
    query: SteelVal,
    truncate: SteelVal,
    render: SteelVal,
    on_close: SteelVal,
) -> Result<PickerCommonOpts, SteelErr> {
    Ok(PickerCommonOpts {
        prompt: string_arg(prompt, "#:prompt")?,
        query: string_arg(query, "#:query")?,
        truncate: truncate_end_arg(truncate, "#:truncate")?,
        render: optional_callback_arg(ctx, render, 3, "#:render")?,
        on_close: optional_callback_arg(ctx, on_close, 0, "#:on-close")?,
    })
}

/// Shared body of `picker-push!`/`picker-replace!`: identical shape, differing
/// only in `name` (for error messages) and `mode` (the merge policy
/// `UiHost::picker_feed` applies; see its doc, `"One method for both"`).
fn picker_feed_builtin(
    ctx: &mut SteelCtx,
    token: SteelVal,
    items: SteelVal,
    mode: PickerFeedMode,
) -> SteelResult {
    let token = token_arg(token, "token")?;
    let items = display_items(items, "items", string_arg)?;
    let applied = require_cap(ctx.host.ui())?.picker_feed(token, items, mode);
    Ok(SteelVal::BoolV(applied))
}

/// `(picker-push! token items)`: no keyword defaults, so this registers
/// directly. Returns whether the push was applied (`#f` for a stale token
/// or no open picker; never an error, both are expected-normal races).
pub(crate) fn picker_push(ctx: &mut SteelCtx, token: SteelVal, items: SteelVal) -> SteelResult {
    picker_feed_builtin(ctx, token, items, PickerFeedMode::Append)
}

/// `(picker-replace! token items)`: no keyword defaults, so this registers
/// directly, same shape as `picker-push!` but replacing the item list
/// instead of appending to it. Returns whether the replace was applied.
pub(crate) fn picker_replace(ctx: &mut SteelCtx, token: SteelVal, items: SteelVal) -> SteelResult {
    picker_feed_builtin(ctx, token, items, PickerFeedMode::Replace)
}

/// `(%picker-source-spawn! token cmd args cwd nul ok-exit-codes)`: the
/// `picker-source-spawn!` Scheme wrapper supplies
/// `#:cwd`/`#:nul`/`#:ok-exit-codes`'s defaults. A stale token or no open
/// picker returns `#f` without spawning anything, the same
/// expected-normal-race contract as `picker-push!`; a genuine spawn failure
/// (missing binary, bad `#:cwd`) raises.
pub(crate) fn picker_source_spawn(
    ctx: &mut SteelCtx,
    token: SteelVal,
    cmd: SteelVal,
    args: SteelVal,
    cwd: SteelVal,
    nul: SteelVal,
    ok_exit_codes: SteelVal,
) -> SteelResult {
    let token = token_arg(token, "token")?;
    let cmd = string_arg(cmd, "cmd")?;
    if cmd.trim().is_empty() {
        steel::stop!(Generic => "cmd must not be empty");
    }
    let args = list_to_strings(args, "args")?;
    let cwd = cwd_arg(cwd, &ctx.host.buffers().cwd(), "#:cwd")?;
    let nul = bool_arg(nul, "#:nul")?;
    let ok_exit_codes = list_to_i32s(ok_exit_codes, "#:ok-exit-codes")?;
    let opts = PickerSourceOpts {
        cwd,
        nul,
        ok_exit_codes,
    };

    let applied = require_cap(ctx.host.ui())?
        .picker_source_spawn(token, &cmd, args, opts)
        .map_err(generic_err)?;
    Ok(SteelVal::BoolV(applied))
}

/// `(picker-source-stop! token)`: no keyword defaults, so this registers
/// directly, same shape as `picker-push!`/`picker-replace!`. Returns
/// whether `token` matched the open session (the same expected-normal-race
/// contract as `picker-push!`), regardless of whether a source was actually
/// attached.
pub(crate) fn picker_source_stop(ctx: &mut SteelCtx, token: SteelVal) -> SteelResult {
    let token = token_arg(token, "token")?;
    let applied = require_cap(ctx.host.ui())?.picker_source_stop(token);
    Ok(SteelVal::BoolV(applied))
}

/// `(picker-close! token)`: no keyword defaults, so this registers
/// directly, same shape as `picker-source-stop!`. A `#f` token is a no-op,
/// same as `close-popup!`.
pub(crate) fn picker_close(ctx: &mut SteelCtx, token: SteelVal) -> SteelResult {
    let token = token_arg(token, "token")?;
    require_cap(ctx.host.ui())?.picker_close(token);
    Ok(SteelVal::Void)
}

/// `(%picker-move! token count by)`: the `picker-move!` Scheme wrapper
/// supplies `#:by`'s default. A `#f` token is a no-op, as for
/// `picker-close!`.
pub(crate) fn picker_move(
    ctx: &mut SteelCtx,
    token: SteelVal,
    count: SteelVal,
    by: SteelVal,
) -> SteelResult {
    let token = token_arg(token, "token")?;
    let count = int_arg(count, "count")? as isize;
    let step = symbol_enum_arg(string_arg(by, "#:by")?.as_str(), "#:by", &PickerStep::NAMED)?;
    require_cap(ctx.host.ui())?.picker_move(token, count, step);
    Ok(SteelVal::Void)
}

#[cfg(test)]
mod tests;
