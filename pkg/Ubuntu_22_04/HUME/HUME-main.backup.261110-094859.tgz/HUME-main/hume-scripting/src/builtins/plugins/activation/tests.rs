use super::*;
use hume_platform::dirs::Dirs;
use std::io::Write as _;

use tempfile::TempDir;

use crate::ScriptingHost;
use crate::attribution::{EntryId, PluginId};
use crate::command_procs::CommandProc;
use crate::host::CommandHost as _;
use crate::lazy::PluginState;
use crate::null_host::{CommandStoreHost, NullHost};

/// Write a Steel source file into `dir` and return its path.
fn write_plugin(dir: &TempDir, name: &str, src: &str) -> std::path::PathBuf {
    let path = dir.path().join(name);
    let mut f = std::fs::File::create(&path).unwrap();
    f.write_all(src.as_bytes()).unwrap();
    path
}

fn plugin_id(name: &str) -> EntryId {
    EntryId::main(PluginId::parse(name).unwrap())
}

// ── Case 1: Declared → Loaded with a valid command body ──────────────────

#[test]
fn declared_to_loaded_registers_command() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "plugin.scm",
        r#"(define-command! "test-cmd" "A test command." (lambda () 0))"#,
    );
    let id = plugin_id("core:test");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let mut store = CommandStoreHost::default();
    host.activate_plugin_inline(&id, 10_000, &mut store)
        .unwrap();

    assert!(
        matches!(
            store.defined_command("test-cmd"),
            Some(CommandProc::Mappable(_))
        ),
        "command must be defined after activation"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loaded)
        ),
        "plugin must be in Loaded state after successful activation"
    );
}

// ── Case 2: Syntax error → Failed, Err returned ──────────────────────────

#[test]
fn syntax_error_transitions_to_failed() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(&dir, "bad.scm", "(((invalid syntax");
    let id = plugin_id("core:bad");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let result = host.activate_plugin_inline(&id, 10_000, &mut NullHost);

    assert!(
        result.is_ok(),
        "a failed plugin activation must be contained, not propagate; got: {result:?}"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "plugin must be in Failed state after syntax error"
    );
    let messages = host.peek_pending_messages();
    assert!(
        messages.iter().any(|(level, msg)| {
            matches!(level, hume_core::Severity::Error)
                && msg.contains("core:bad")
                && msg.contains("failed to load")
        }),
        "must log an Error naming the failed plugin; messages: {messages:?}"
    );
}

/// A failed plugin body's log message names the plugin and points at the
/// exact file, line, and column of the failing reference, not just
/// `init.scm`, the file that happened to `load-plugin!` it.
/// `describe_steel_error` resolves the error's span against the engine's own
/// `Sources`.
#[test]
fn failed_activation_message_names_plugin_and_location() {
    let dir = TempDir::new().unwrap();
    // Line 2, column 2 (1-based): right at "call-does-not-exist", after the
    // opening paren. Hand-computed from the source text for the location
    // assertion below.
    let path = write_plugin(&dir, "located.scm", "(define x 1)\n(call-does-not-exist)\n");
    let id = plugin_id("core:located");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let result = host.activate_plugin_inline(&id, 10_000, &mut NullHost);
    assert!(
        result.is_ok(),
        "must be contained, not propagate; got: {result:?}"
    );

    let messages = host.peek_pending_messages();
    assert_eq!(
        messages.len(),
        1,
        "exactly one failure message expected; got: {messages:?}"
    );
    let (level, msg) = &messages[0];
    assert!(
        matches!(level, hume_core::Severity::Error),
        "must be logged at Error; got: {level:?}"
    );
    assert!(
        msg.contains("core:located"),
        "must name the plugin; got: {msg}"
    );
    assert!(
        msg.contains("located.scm"),
        "must name the failing file, not just init.scm; got: {msg}"
    );
    assert!(
        msg.contains(":2:2"),
        "must point at line 2, column 2, where the bad identifier starts; got: {msg}"
    );
    assert!(
        msg.contains("call-does-not-exist"),
        "must name the bad identifier; got: {msg}"
    );
    assert!(
        !msg.contains("bootstrap.scm") && !msg.contains("meta-continuation"),
        "must not leak bootstrap.scm's own activation-plumbing frames; got: {msg}"
    );
}

// ── Case 3: Idempotent no-ops for non-Declared states ────────────────────

#[test]
fn already_loaded_is_noop() {
    let id = plugin_id("core:loaded");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loaded);

    host.activate_plugin_inline(&id, 10_000, &mut NullHost)
        .unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loaded)
        ),
        "state must remain Loaded"
    );
}

#[test]
fn already_failed_is_noop() {
    let id = plugin_id("core:failed");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Failed);

    host.activate_plugin_inline(&id, 10_000, &mut NullHost)
        .unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "state must remain Failed"
    );
}

#[test]
fn absent_plugin_is_noop() {
    let id = plugin_id("core:absent");
    let mut host = ScriptingHost::for_testing(&Dirs::none());

    host.activate_plugin_inline(&id, 10_000, &mut NullHost)
        .unwrap();

    assert!(
        !host
            .state
            .registries
            .lazy_registry
            .plugins
            .contains_key(&id),
        "absent plugin must not appear in registry after no-op"
    );
}

// ── Case 4: Loading re-entrancy guard → no-op ────────────────────────────

#[test]
fn loading_reentrancy_guard_is_noop() {
    let id = plugin_id("core:cycling");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loading);

    host.activate_plugin_inline(&id, 10_000, &mut NullHost)
        .unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loading)
        ),
        "state must remain Loading (re-entrancy guard must not overwrite)"
    );
}

// ── Case 5: Path containing '"' rejected before any eval ─────────────────

#[test]
fn path_with_quote_char_transitions_to_failed() {
    let id = plugin_id("core:quoted");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state.registries.lazy_registry.plugins.insert(
        id.clone(),
        PluginState::Declared {
            path: std::path::PathBuf::from("/some/path\"with/quote/plugin.scm"),
        },
    );

    let result = host.activate_plugin_inline(&id, 10_000, &mut NullHost);

    assert!(result.is_err(), "path with '\"' must be rejected");
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "plugin must be Failed after path-with-quote rejection"
    );
}

// ── Stage B: eval-string plumbing ─────────────────────────────────────────

/// A `define-command!` issued via `eval-string` inside an eval session
/// defines the command, proving that the nested eval-string
/// sees the same `ctx.registries` as the outer eval.
#[test]
fn eval_string_nested_defines_command() {
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    // Eval a snippet that eval-strings a define-command!. The outer eval is
    // in EvalMode::Init, which allows define-command!.
    let program = r#"
(hm.eval-string "(define-command! \"inner-cmd\" \"doc\" (lambda () 0))")
"#;
    let mut store = CommandStoreHost::default();
    host.eval_source(program, &mut store).unwrap();
    assert!(
        matches!(
            store.defined_command("inner-cmd"),
            Some(CommandProc::Mappable(_))
        ),
        "command defined via eval-string must be defined"
    );
}

/// `%begin-lazy-activation!` on a `Declared` plugin transitions to `Loading`,
/// pushes onto `attribution`, and returns the require-string.
#[test]
fn begin_lazy_activation_declared_returns_require_string() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "p.scm",
        r#"(define-command! "p-cmd" "doc" (lambda () 0))"#,
    );
    let id = plugin_id("core:p");
    let mut h = crate::test_support::SteelCtxTestHarness::new();
    h.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let result = begin_lazy_activation(
        &mut h.ctx(),
        "core:p".into(),
        SteelVal::StringV("plugin.scm".into()),
    );

    assert!(
        matches!(&result, Ok(SteelVal::StringV(program)) if program.starts_with("(require ")),
        "got {result:?}"
    );
    assert!(
        matches!(
            h.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loading)
        ),
        "Declared plugin must be Loading after %begin-lazy-activation!"
    );
    assert_eq!(h.state.attribution.len(), 1, "begin pushed the id");
}

/// `%begin-lazy-activation!` on a `Loading` plugin returns `#f` (cycle guard).
#[test]
fn begin_lazy_activation_loading_returns_false() {
    let id = plugin_id("core:cycling");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loading);

    // The result `#f` means the (when prog ...) in %activate-plugin-inline!
    // does nothing: activation is a no-op.
    let program = r#"
(define result (%begin-lazy-activation! "core:cycling" "plugin.scm"))
(when result (error "cycle guard must return #f!"))
"#;
    host.eval_source(program, &mut NullHost).unwrap();
    // State must remain Loading.
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loading)
        ),
        "state must remain Loading (cycle guard)"
    );
}

/// `%finish-lazy-activation!` with `error = #f` (no exception caught)
/// transitions to `Loaded`.
#[test]
fn finish_lazy_activation_success_transitions_to_loaded() {
    let id = plugin_id("core:finishing");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loading);
    // Seed the stack as begin_lazy_activation would have done.
    host.push_plugin_for_test(id.clone());

    let program = r#"(%finish-lazy-activation! #f)"#;
    host.eval_source(program, &mut NullHost).unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loaded)
        ),
        "plugin must be Loaded after successful finish"
    );
    assert_eq!(
        host.attribution_depth_for_test(),
        0,
        "attribution must be empty after finish"
    );
}

/// `%finish-lazy-activation!` finishes the innermost body on `attribution`:
/// with two nested activations, only the inner one moves to `Loaded`.
#[test]
fn finish_lazy_activation_finishes_the_innermost_entry() {
    let outer = plugin_id("core:outer");
    let inner = plugin_id("core:inner");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    for id in [&outer, &inner] {
        host.state
            .registries
            .lazy_registry
            .plugins
            .insert(id.clone(), PluginState::Loading);
        host.push_plugin_for_test(id.clone());
    }

    host.eval_source("(%finish-lazy-activation! #f)", &mut NullHost)
        .unwrap();

    assert!(matches!(
        host.state.registries.lazy_registry.plugins.get(&inner),
        Some(PluginState::Loaded)
    ));
    assert!(matches!(
        host.state.registries.lazy_registry.plugins.get(&outer),
        Some(PluginState::Loading)
    ));
    assert_eq!(host.attribution_depth_for_test(), 1);
}

/// `%finish-lazy-activation!` without a matching `%begin-lazy-activation!`
/// raises and changes no plugin's state.
#[test]
fn finish_lazy_activation_with_no_activation_in_progress_errors() {
    let id = plugin_id("core:idle");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loading);

    let result = host.eval_source("(%finish-lazy-activation! #f)", &mut NullHost);

    assert!(
        result.is_err(),
        "finish with an empty attribution must raise"
    );
    assert!(matches!(
        host.state.registries.lazy_registry.plugins.get(&id),
        Some(PluginState::Loading)
    ));
}

/// `%finish-lazy-activation!` with `error` bound to a caught exception value
/// transitions to `Failed`. `(with-handler (lambda (e) e) (error …))` is the
/// idiomatic way to get that exact value in hand outside an actual
/// `with-handler`-wrapped activation body. Steel hands the raised
/// `SteelErr`'s `into_steelval()` form to the handler lambda, which here
/// just returns it.
#[test]
fn finish_lazy_activation_failure_transitions_to_failed() {
    let id = plugin_id("core:failing");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loading);
    host.push_plugin_for_test(id.clone());

    let program = r#"
(define err-val (with-handler (lambda (e) e) (error "intentional")))
(%finish-lazy-activation! err-val)
"#;
    host.eval_source(program, &mut NullHost).unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "plugin must be Failed after failed finish"
    );
}

// ── Partial-define rollback ───────────────────────────────────────────────

/// A plugin body that defines one command and then errors: the plugin
/// transitions to `Failed` and `finish_lazy_activation` rolls back the
/// partial `define-command!`, removing its proc.  A `Failed` plugin must not
/// leave callable orphan commands.
#[test]
fn partial_define_before_failure_is_rolled_back() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "partial.scm",
        r#"(define-command! "partial-cmd" "doc" (lambda () 0))
               (error "intentional mid-body error")"#,
    );
    let id = plugin_id("core:partial");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let mut store = CommandStoreHost::default();
    let result = host.activate_plugin_inline(&id, 10_000, &mut store);

    assert!(
        result.is_ok(),
        "a failed plugin activation must be contained, not propagate; got: {result:?}"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "plugin must be Failed after mid-body error"
    );
    // The partial define must be rolled back: no callable orphan left behind.
    assert!(
        store.defined_command("partial-cmd").is_none(),
        "partial define-command! must be unregistered on failure"
    );
}

/// A plugin body that queues an LSP server registration and a language
/// registration and then errors: both must be rolled back from the
/// effect log, not left for some later unrelated drain to silently apply.
///
/// On failure, `SteelCtx::pop_effect_marks` drops every effect queued since
/// the activation's mark that no nested activation committed.
#[test]
fn queued_effects_before_failure_are_rolled_back() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "effects.scm",
        r#"(register-lsp-server! "rust" #:command "rust-analyzer")
               (%define-language! "foo" '() '() '())
               (error "intentional mid-body error")"#,
    );
    let id = plugin_id("core:effects");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let result = host.activate_plugin_inline(&id, 10_000, &mut NullHost);

    assert!(
        result.is_ok(),
        "a failed plugin activation must be contained, not propagate; got: {result:?}"
    );
    assert!(
        host.effects_for_test().is_empty(),
        "failed activation must not leave a queued LSP server op or language registration behind"
    );
}

// ── Committed-effects salvage across enclosing eval failure ──────────────

/// A command dispatched via `call_steel_cmd` `call!`s a lazy command owned
/// by plugin B; B activates inline mid-body and finishes successfully
/// (queuing `register-lsp-server!` and committing `Loaded`), then the
/// outer command errors afterward. B's committed effect must survive: B
/// stays `Loaded` and activation is one-shot, so a dropped effect is never
/// queued again and B's LSP server never registers. Effects the outer
/// command itself queued, before and after the nested activation, must
/// NOT survive.
///
/// `take_eval_effects`'s `Err` arm keeps the committed effects of the
/// discarded tail, so `e.effects` carries B's.
#[test]
fn committed_activation_effects_survive_failed_outer_command() {
    use crate::host::EditorHost;
    use crate::types::{Effect, PendingLspServerOp};

    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "b.scm",
        r#"(register-lsp-server! "b-lang" #:command "b-lsp")
               (define-command! "b-cmd" "doc" (lambda () 0))"#,
    );
    let id_b = plugin_id("core:b");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_b.clone(), PluginState::Declared { path });

    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id_b, &["b-cmd".into()], &[])
        .expect("stub claim must succeed on a fresh host");

    host.eval_source(
        r#"(define-command! "outer-a" "doc"
                 (lambda ()
                   (register-lsp-server! "before" #:command "x")
                   (call! "b-cmd")
                   (register-lsp-server! "after" #:command "y")
                   (error "intentional outer failure")))"#,
        &mut editor_host,
    )
    .expect("defining outer-a must not error");

    let result = host.call_steel_cmd_by_name("outer-a", vec![], &mut editor_host);

    let err = result.expect_err("outer-a's intentional error must propagate");
    assert!(
        err.message.contains("intentional outer failure"),
        "got: {}",
        err.message
    );
    assert_eq!(
        err.effects.len(),
        1,
        "only B's committed register-lsp-server! must survive; got: {:?}",
        err.effects
    );
    assert!(
        matches!(
            &err.effects[0],
            Effect::LspServerOp(PendingLspServerOp::Register(reg)) if reg.name.as_str() == "b-lang"
        ),
        "surviving effect must be B's 'b-lang' registration, not 'before'/'after'; got: {:?}",
        err.effects[0]
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_b),
            Some(PluginState::Loaded)
        ),
        "B must be Loaded: its activation succeeded before A's own failure"
    );
    assert!(
        host.effects_for_test().is_empty(),
        "the effect log must be fully drained after take_eval_effects"
    );
}

/// One level deeper: plugin C activates successfully inside plugin B's
/// body (via `call!` to a command C owns), and B then fails. C's
/// committed `register-lsp-server!` must survive B's own rollback. C is
/// `Loaded` and its effect is irreversible-by-omission, same reasoning as
/// the outer-command case above, but exercised through nested
/// `pop_effect_marks` calls instead of `take_eval_effects` alone. B's own
/// failure is contained (`activate_plugin_inline` returns `Ok`), so C's
/// effect surfaces through the success path, not a salvaged `EvalError`.
#[test]
fn nested_activation_commit_survives_enclosing_plugin_failure() {
    use crate::host::EditorHost;
    use crate::types::{Effect, PendingLspServerOp};

    let dir = TempDir::new().unwrap();
    let path_c = write_plugin(
        &dir,
        "c.scm",
        r#"(register-lsp-server! "c-lang" #:command "c-lsp")
               (define-command! "c-cmd" "doc" (lambda () 0))"#,
    );
    let path_b = write_plugin(
        &dir,
        "b.scm",
        r#"(register-lsp-server! "b-lang" #:command "b-lsp")
               (call! "c-cmd")
               (error "b fails")"#,
    );
    let id_b = plugin_id("core:b");
    let id_c = plugin_id("core:c");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_b.clone(), PluginState::Declared { path: path_b });
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_c.clone(), PluginState::Declared { path: path_c });

    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id_c, &["c-cmd".into()], &[])
        .expect("stub claim must succeed on a fresh host");

    let result = host.activate_plugin_inline(&id_b, 10_000, &mut editor_host);

    let effects = result.expect("B's failure must be contained, not propagate");
    assert_eq!(
        effects.len(),
        1,
        "only C's committed register-lsp-server! must survive; got: {effects:?}"
    );
    assert!(
        matches!(
            &effects[0],
            Effect::LspServerOp(PendingLspServerOp::Register(reg)) if reg.name.as_str() == "c-lang"
        ),
        "surviving effect must be C's 'c-lang' registration, not B's 'b-lang'; got: {:?}",
        effects[0]
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_b),
            Some(PluginState::Failed)
        ),
        "B must be Failed"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_c),
            Some(PluginState::Loaded)
        ),
        "C must be Loaded: its activation succeeded before B's own failure"
    );
    assert!(
        matches!(
            editor_host.defined_command("c-cmd"),
            Some(CommandProc::Mappable(_))
        ),
        "C's command must remain registered: C is Loaded, not rolled back"
    );
    assert!(
        host.effects_for_test().is_empty(),
        "the effect log must be fully drained after take_eval_effects"
    );
    let messages = host.peek_pending_messages();
    assert!(
        messages.iter().any(|(level, msg)| {
            matches!(level, hume_core::Severity::Error)
                && msg.contains("core:b")
                && msg.contains("b fails")
        }),
        "must log an Error naming B and its failure; messages: {messages:?}"
    );
}

// ── Hook rollback on activation failure ───────────────────────────────────

/// A plugin body that registers a hook and then errors: the hook must not
/// survive: a `Failed` plugin's hooks must stop firing.
///
/// `finish_lazy_activation` drops the hook through
/// `HookRegistry::remove_registered_in`.
#[test]
fn hook_registered_before_failure_is_rolled_back() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "hook_fail.scm",
        r#"(register-hook! 'on-buffer-save (lambda (bid) 0))
               (error "intentional mid-body error")"#,
    );
    let id = plugin_id("core:hookfail");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let result = host.activate_plugin_inline(&id, 10_000, &mut NullHost);

    assert!(
        result.is_ok(),
        "a failed plugin activation must be contained, not propagate; got: {result:?}"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "plugin must be Failed after mid-body error"
    );
    assert!(
        !host.has_hook_handlers("on-buffer-save", None, crate::Audience::Everyone),
        "a Failed plugin's hook must not survive rollback"
    );
}

/// One level deeper: plugin C registers a hook and activates successfully
/// inside plugin B's body, and B then fails afterward. C's hook must
/// survive B's rollback. Rollback is by the innermost body running at
/// registration, which is C's, so B's failure can never touch C's entries.
#[test]
fn nested_activation_hook_survives_enclosing_plugin_failure() {
    use crate::host::EditorHost;

    let dir = TempDir::new().unwrap();
    let path_c = write_plugin(
        &dir,
        "hook_c.scm",
        r#"(register-hook! 'on-buffer-save (lambda (bid) 0))
               (define-command! "hc-cmd" "doc" (lambda () 0))"#,
    );
    let path_b = write_plugin(
        &dir,
        "hook_b.scm",
        r#"(call! "hc-cmd")
               (error "b fails")"#,
    );
    let id_b = plugin_id("core:hb");
    let id_c = plugin_id("core:hc");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_b.clone(), PluginState::Declared { path: path_b });
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_c.clone(), PluginState::Declared { path: path_c });

    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id_c, &["hc-cmd".into()], &[])
        .expect("stub claim must succeed on a fresh host");

    let result = host.activate_plugin_inline(&id_b, 10_000, &mut editor_host);

    assert!(
        result.is_ok(),
        "a failed plugin activation must be contained, not propagate; got: {result:?}"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_b),
            Some(PluginState::Failed)
        ),
        "B must be Failed"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_c),
            Some(PluginState::Loaded)
        ),
        "C must be Loaded: its activation succeeded before B's own failure"
    );
    assert!(
        host.has_hook_handlers("on-buffer-save", None, crate::Audience::Everyone),
        "C's hook must survive B's failure: rollback is scoped to B's own id"
    );
}

/// Plugin A's command, `call!`ed from plugin B's body, registers a hook and
/// a command. Both run as A's code, yet were made while B's body ran, so
/// B's failure rolls them back with the rest of B's footprint.
#[test]
fn registrations_a_called_command_makes_in_a_failing_body_are_rolled_back() {
    use crate::host::EditorHost;

    let dir = TempDir::new().unwrap();
    let path_a = write_plugin(
        &dir,
        "setup_a.scm",
        r#"(define-command! "a-setup" "doc"
             (lambda ()
               (register-hook! 'on-buffer-save (lambda (bid) 0))
               (define-command! "a-made" "doc" (lambda () 0))))"#,
    );
    let path_b = write_plugin(
        &dir,
        "setup_b.scm",
        r#"(call! "a-setup")
           (error "b fails")"#,
    );
    let id_a = plugin_id("core:sa");
    let id_b = plugin_id("core:sb");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_a.clone(), PluginState::Declared { path: path_a });
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_b.clone(), PluginState::Declared { path: path_b });
    let mut editor_host = CommandStoreHost::default();
    host.activate_plugin_inline(&id_a, 10_000, &mut editor_host)
        .unwrap();

    host.activate_plugin_inline(&id_b, 10_000, &mut editor_host)
        .unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_b),
            Some(PluginState::Failed)
        ),
        "B must be Failed"
    );
    assert!(
        !host.has_hook_handlers("on-buffer-save", None, crate::Audience::Everyone),
        "the hook a-setup registered inside B's body must leave with B"
    );
    assert!(
        editor_host.commands().defined_command("a-made").is_none(),
        "the command a-setup defined inside B's body must leave with B"
    );
    assert!(
        editor_host.commands().defined_command("a-setup").is_some(),
        "A's own command stays: A is Loaded"
    );
}

/// A lazy plugin's activation command, defined by another plugin's command
/// that the lazy plugin's body `call!`s, is defined inside that body, so the
/// claim the lazy plugin holds on the name does not refuse it.
#[test]
fn a_called_command_may_define_the_running_bodys_activation_command() {
    use crate::host::EditorHost;

    let dir = TempDir::new().unwrap();
    let path_a = write_plugin(
        &dir,
        "definer_a.scm",
        r#"(define-command! "a-define-b" "doc"
             (lambda () (define-command! "b-act" "doc" (lambda () 0))))"#,
    );
    let path_b = write_plugin(&dir, "lazy_b.scm", r#"(call! "a-define-b")"#);
    let id_a = plugin_id("core:da");
    let id_b = plugin_id("core:db");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_a.clone(), PluginState::Declared { path: path_a });
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_b.clone(), PluginState::Declared { path: path_b });
    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id_b, &["b-act".into()], &[])
        .expect("stub claim must succeed on a fresh host");
    host.activate_plugin_inline(&id_a, 10_000, &mut editor_host)
        .unwrap();

    host.activate_plugin_inline(&id_b, 10_000, &mut editor_host)
        .unwrap();

    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_b),
            Some(PluginState::Loaded)
        ),
        "B must be Loaded; messages: {:?}",
        host.peek_pending_messages()
    );
    assert!(
        matches!(
            editor_host.commands().defined_command("b-act"),
            Some(CommandProc::Mappable(_))
        ),
        "b-act must be defined"
    );
}

/// A plugin body still open when the `call!` frame below it is left fails
/// that plugin, as a session's end does, and the stack returns to the
/// call's depth.
#[test]
fn leaving_a_call_with_a_body_open_above_it_fails_that_body() {
    let id = plugin_id("core:open");
    let mut h = crate::test_support::SteelCtxTestHarness::new();
    h.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Loading);
    let mut ctx = h.ctx();
    let depth = ctx
        .attribution
        .enter_call(std::rc::Rc::new(crate::attribution::Owner::User));
    ctx.attribution.push_body(id.clone());
    ctx.mark_effects();

    crate::builtins::commands::leave_command(&mut ctx, SteelVal::IntV(depth as isize)).unwrap();

    assert_eq!(ctx.attribution.len(), depth);
    let failed: Vec<&EntryId> = ctx.failed_activations.iter().map(|(id, _)| id).collect();
    assert_eq!(failed, [&id]);
    drop(ctx);
    assert!(matches!(
        h.state.registries.lazy_registry.plugins.get(&id),
        Some(PluginState::Failed)
    ));
}

// ── Self-ownership exemption ────────────────────────────────────────────────

/// A lazy plugin is allowed to call `define-command!` for its own activation
/// command inside its body, even though that name is still claimed as its
/// `Lazy` stub at the time (the stub is only removed by
/// `unregister_lazy_stubs_of` *after* the body completes in
/// `finish_lazy_activation`).
///
/// The `is_self` exemption in `define_command` allows this.
#[test]
fn lazy_plugin_can_define_its_own_activation_command() {
    use crate::host::EditorHost;

    let dir = TempDir::new().unwrap();
    let path = write_plugin(
        &dir,
        "self-act.scm",
        r#"(define-command! "self-act-cmd" "doc" (lambda () 0))"#,
    );
    let id = plugin_id("core:self-act");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    // Simulate declare-plugin! having claimed self-act-cmd as the
    // activation entry, now tracked in the editor's registry (here,
    // the stateful test host), not a scripting-crate map.
    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id, &["self-act-cmd".into()], &[])
        .expect("stub claim must succeed on a fresh host");

    let result = host.activate_plugin_inline(&id, 10_000, &mut editor_host);

    assert!(
        result.is_ok(),
        "plugin defining its own activation command must activate successfully; got: {result:?}"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loaded)
        ),
        "plugin must be Loaded after activation"
    );
    assert!(
        matches!(
            editor_host.defined_command("self-act-cmd"),
            Some(CommandProc::Mappable(_))
        ),
        "self-act-cmd must be defined after activation"
    );
}

// ── The budget stopping an activation ────────────────────────────────────

/// The budget stops a plugin body that loops past it: the activation is
/// failed as for any body error, nothing of it is left open for the next
/// session, and the plugin after it never loads.
#[test]
fn budget_stopping_a_body_fails_its_activation_and_closes_it() {
    let dir = TempDir::new().unwrap();
    let path_a = write_plugin(
        &dir,
        "a.scm",
        r#"(define-command! "a-cmd" "doc" (lambda () 0))
           (let loop ((n 0)) (if (< n 50000000) (loop (+ n 1)) n))"#,
    );
    let path_b = write_plugin(
        &dir,
        "b.scm",
        r#"(define-command! "b-cmd" "doc" (lambda () 0))"#,
    );
    let id_a = plugin_id("core:a");
    let id_b = plugin_id("core:b");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_a.clone(), PluginState::Declared { path: path_a });
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id_b.clone(), PluginState::Declared { path: path_b });
    let mut store = CommandStoreHost::default();

    let src = r##"(%activate-plugin-inline! "core:a" #f) (%activate-plugin-inline! "core:b" #f)"##;
    let result = host.eval_source_watchdog(src, std::time::Duration::from_millis(50), &mut store);

    assert!(
        result.is_err(),
        "the budget must stop the eval; got: {result:?}"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_a),
            Some(PluginState::Failed)
        ),
        "A's activation is failed"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id_b),
            Some(PluginState::Declared { .. })
        ),
        "B is never reached"
    );
    assert_eq!(
        host.state.attribution.len(),
        0,
        "no activation is left open"
    );
}

// ── `call!` of a command owned by a Failed plugin ──────────────────────────

/// A lazy plugin's command is `call!`ed (e.g. from another plugin's body);
/// activation runs inline, fails, and is contained. `%dispatch-command!`
/// must not then fall through to `%call-native!` and silently return `#f`
/// as if the name were simply unknown. The plugin failed, and the caller
/// needs to know that, not receive a value indistinguishable from success.
///
/// The `%lazy-command-owner` check after a failed inline activation is what
/// turns this into an error.
#[test]
fn call_of_command_owned_by_newly_failed_plugin_errors() {
    use crate::host::EditorHost;

    let dir = TempDir::new().unwrap();
    let path = write_plugin(&dir, "broken.scm", r#"(error "broken body")"#);
    let id = plugin_id("core:broken");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id, &["broken-cmd".into()], &[])
        .expect("stub claim must succeed on a fresh host");

    let err = host
        .eval_source(r#"(call! "broken-cmd")"#, &mut editor_host)
        .expect_err("call! of a command whose owner just failed to load must error");

    assert!(
        err.contains("core:broken") && err.contains("broken-cmd"),
        "error must name both the failed plugin and the command that couldn't be reached; got: {err}"
    );
}

// ── Manifest-declare rollback on a later error ─────────────────────────────

/// `manifest.scm` successfully declares itself with `#:commands` (a real,
/// direct `%declare-plugin!` call) and then a
/// later top-level form in the same file raises. The plugin must end up
/// `Failed` with no live command stub, not left half-`Declared` with a
/// callable stub for a plugin whose manifest never finished evaluating.
///
/// `finish_manifest_load`'s error branch performs that rollback to
/// `Failed`.
#[test]
fn manifest_declare_self_declared_then_failed_rolls_back_to_failed() {
    use crate::host::EditorHost;

    let dir = TempDir::new().unwrap();
    let plugin_dir = dir.path().join("plugins").join("user").join("selfdecl");
    std::fs::create_dir_all(&plugin_dir).unwrap();
    // `declare-plugin!` inside manifest.scm only
    // registers `Declared` state once `plugin.scm` resolves on disk (absent,
    // it soft-logs and no-ops), so the file exists for the plugin to be
    // declared before the rollback.
    std::fs::write(plugin_dir.join("plugin.scm"), b"").unwrap();
    std::fs::write(
        plugin_dir.join("manifest.scm"),
        br#"(declare-plugin! "user/selfdecl" #:commands '("selfdecl-cmd"))
            (error "manifest body fails after self-declare")"#,
    )
    .unwrap();

    let mut host = ScriptingHost::for_testing(&Dirs {
        data: Some(dir.path().to_path_buf()),
        ..Dirs::none()
    });
    let mut editor_host = CommandStoreHost::default();

    let result = host.eval_source(r#"(load-plugin! "user/selfdecl")"#, &mut editor_host);

    assert!(
        result.is_ok(),
        "a failed manifest resolution must be contained, not propagate; got: {result:?}"
    );

    let id = plugin_id("user/selfdecl");
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "the plugin's own self-declare must be rolled back to Failed, not left Declared; got: {:?}",
        host.state.registries.lazy_registry.plugins.get(&id)
    );
    assert!(
        editor_host
            .commands()
            .lazy_command_owner("selfdecl-cmd")
            .is_none(),
        "the self-declared command stub must not survive the manifest's own later failure"
    );
}

// ── `%finish-lazy-activation!` balances stack/marks even on a bad `error` ──

/// `(%finish-lazy-activation! garbage)` where `garbage` decodes as
/// neither `#f` nor a caught error value: the plugin stack and the
/// activation-effect marks must still be popped and balanced: a decode
/// failure must become the failure *reason*, not skip the bookkeeping that
/// every other failure path performs. `%begin-lazy-activation!` and a queued
/// `register-lsp-server!` run first in the same eval, since
/// `activation_effect_marks` is per-eval transient state (rebuilt fresh in
/// every `SteelCtx`), only observable by whether its own effect survives.
///
/// Decoding `error` must not short-circuit ahead of `attribution.pop_body()` and
/// `pop_effect_marks`.
#[test]
fn finish_lazy_activation_bad_error_value_still_balances_stack_and_marks() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(&dir, "badvalue.scm", "(define x 1)");
    let id = plugin_id("core:badvalue");
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });

    let program = r#"
        (%begin-lazy-activation! "core:badvalue" "plugin.scm")
        (register-lsp-server! "badvalue-lang" #:command "bv")
        (%finish-lazy-activation! 42)
    "#;
    host.eval_source(program, &mut NullHost)
        .expect("a bad error value must be folded into the failure, not raised");

    assert_eq!(
        host.attribution_depth_for_test(),
        0,
        "attribution must be popped even when the error value fails to decode"
    );
    assert!(
        host.effects_for_test().is_empty(),
        "the queued register-lsp-server! must be rolled back: the activation-effect \
         mark must be popped even when the error value fails to decode"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "an undecodable error value must still fail the plugin, not leave it Loading"
    );
}

// ── Activation depth cap ──────────────────────────────────────────────────

/// `%begin-lazy-activation!` refuses to start when the body depth on `attribution` is at
/// `MAX_ACTIVATION_DEPTH`, marks the plugin `Failed`, and returns a Steel error.
///
/// The cap turns an activation cycle into a hard error instead of a stack
/// overflow.
#[test]
fn begin_lazy_activation_at_depth_cap_errors_and_marks_failed() {
    use crate::{ScriptingHost, null_host::NullHost};
    use std::io::Write as _;
    use tempfile::TempDir;

    let dir = TempDir::new().unwrap();
    let path = dir.path().join("deep.scm");
    std::fs::File::create(&path)
        .unwrap()
        .write_all(b"(define x 1)")
        .unwrap();

    let id = EntryId::main(PluginId::parse("core:deep").unwrap());
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });
    // Simulate maximum nesting depth already reached by seeding the stack.
    let dummy = EntryId::main(PluginId::parse("core:dummy").unwrap());
    for _ in 0..MAX_ACTIVATION_DEPTH {
        host.push_plugin_for_test(dummy.clone());
    }

    let result = host.eval_source(
        r#"(%begin-lazy-activation! "core:deep" "plugin.scm")"#,
        &mut NullHost,
    );

    assert!(
        result.is_err(),
        "depth cap must raise a Steel error; got Ok"
    );
    assert!(
        matches!(
            host.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Failed)
        ),
        "plugin must be marked Failed when depth cap exceeded"
    );
}

/// `%begin-lazy-activation!` at depth cap − 1 succeeds (cap is exclusive).
///
/// Confirms the off-by-one is correct: depth 15 of 16 is still allowed.
#[test]
fn begin_lazy_activation_below_depth_cap_succeeds() {
    let dir = TempDir::new().unwrap();
    let path = write_plugin(&dir, "ok.scm", "(define x 1)");
    let id = plugin_id("core:ok");
    let mut h = crate::test_support::SteelCtxTestHarness::new();
    h.state
        .registries
        .lazy_registry
        .plugins
        .insert(id.clone(), PluginState::Declared { path });
    // One below the cap: must still be allowed.
    let dummy = plugin_id("core:dummy");
    for _ in 0..MAX_ACTIVATION_DEPTH - 1 {
        h.state.attribution.push_body(dummy.clone());
    }

    let result = begin_lazy_activation(
        &mut h.ctx(),
        "core:ok".into(),
        SteelVal::StringV("plugin.scm".into()),
    );

    assert!(
        result.is_ok(),
        "depth below cap must be allowed; got {result:?}"
    );
    assert!(
        matches!(
            h.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loading)
        ),
        "plugin must be Loading after successful %begin-lazy-activation!"
    );
}

/// `%begin-lazy-activation!` failing at the depth cap leaves the entry as
/// `%finish-lazy-activation!`'s failure branch does, even though the body
/// never ran and `%finish-lazy-activation!` never fires for it: `Failed`, so
/// neither its event nor its language activates it again, and without its
/// `Lazy` command stub.
#[test]
fn begin_lazy_activation_depth_cap_fails_the_entry_and_drops_its_stub() {
    use crate::ScriptingHost;
    use crate::host::EditorHost;
    use crate::null_host::CommandStoreHost;
    use std::io::Write as _;
    use tempfile::TempDir;

    let dir = TempDir::new().unwrap();
    let path = dir.path().join("deep.scm");
    std::fs::File::create(&path)
        .unwrap()
        .write_all(b"(define x 1)")
        .unwrap();

    let id = EntryId::main(PluginId::parse("core:deep").unwrap());
    let mut host = ScriptingHost::for_testing(&Dirs::none());
    host.state.registries.lazy_registry.declare(
        id.clone(),
        path,
        vec!["on-buffer-save".to_string()],
        vec!["rust".to_string()],
    );

    let mut editor_host = CommandStoreHost::default();
    editor_host
        .commands()
        .register_lazy_commands(&id, &["deep-cmd".into()], &[])
        .expect("stub claim must succeed on a fresh host");

    let dummy = EntryId::main(PluginId::parse("core:dummy").unwrap());
    for _ in 0..MAX_ACTIVATION_DEPTH {
        host.push_plugin_for_test(dummy.clone());
    }

    let result = host.eval_source(
        r#"(%begin-lazy-activation! "core:deep" "plugin.scm")"#,
        &mut editor_host,
    );
    assert!(result.is_err(), "depth cap must raise; got Ok");

    assert!(
        !host
            .state
            .registries
            .lazy_registry
            .event_plugins("on-buffer-save")
            .contains(&id),
        "a failed plugin must not activate on its event again"
    );
    assert!(
        !host
            .state
            .registries
            .lazy_registry
            .language_plugins("rust")
            .contains(&id),
        "a failed plugin must not activate on its language again"
    );
    assert!(
        editor_host
            .commands()
            .lazy_command_owner("deep-cmd")
            .is_none(),
        "Failed plugin's dead command stub must be unregistered, not leaked"
    );
}

// ── Windows path escaping ────────────────────────────────────────────────

/// `%begin-lazy-activation!` must escape backslashes in the plugin path so
/// a Windows-style path (e.g. `C:\Users\x\plugin.scm`) survives embedding
/// inside a Steel string literal without producing an invalid-escape error.
///
/// This test inserts a synthetic backslash-bearing path without creating a
/// real file; it checks only the returned require-string against the
/// hand-computed expected value.
#[test]
fn begin_lazy_activation_escapes_backslashes_in_path() {
    let id = plugin_id("core:winpath");
    let mut h = crate::test_support::SteelCtxTestHarness::new();
    h.state.registries.lazy_registry.plugins.insert(
        id.clone(),
        PluginState::Declared {
            path: std::path::PathBuf::from(r"C:\Users\x\plugin.scm"),
        },
    );

    let result = begin_lazy_activation(
        &mut h.ctx(),
        "core:winpath".into(),
        SteelVal::StringV("plugin.scm".into()),
    );

    assert!(
        matches!(&result, Ok(SteelVal::StringV(program))
            if program.as_str() == r#"(require "C:\\Users\\x\\plugin.scm")"#),
        "backslashes in path must be doubled for Steel string embedding; got {result:?}"
    );
    assert!(
        matches!(
            h.state.registries.lazy_registry.plugins.get(&id),
            Some(PluginState::Loading)
        ),
        "plugin must be Loading after %begin-lazy-activation!"
    );
}
