//! `(set-option! key value)` / `(get-option key)` / `(set-buffer-option! pane
//! key value)` / `(get-buffer-option pane key)` builtins.

use steel::rerrs::SteelErr;
use steel::rvals::SteelVal;

use hume_core::{
    BufferId, BufferIntrinsicOption, BufferOptionWrite, LanguageOptionText, OptionInput,
    OptionType, OptionValue, StatuslineSections,
};

use crate::SteelCtx;
use crate::host::option_value_to_steel;
use crate::types::{Effect, QueuedEffect};

use super::SteelResult;
use super::args::{hash_entry, list_items, string_list, symbol_hash};
use super::errors::{generic_err, message};

/// `value` as the editor's option layer takes it. Nothing is refused here: a
/// list or hash whose contents do not decode, and a value of no option type,
/// reach the editor as such, which refuses them once it knows the option. An
/// unknown option is then reported as unknown, and a list given to a
/// one-value option as the wrong type, whatever the list holds.
fn option_input(value: SteelVal) -> OptionInput {
    let decoded = |ty, value: Result<OptionValue, _>| match value {
        Ok(value) => OptionInput::Value(value),
        Err(e) => OptionInput::Unreadable {
            ty,
            error: message(&e),
        },
    };
    match value {
        SteelVal::BoolV(b) => OptionInput::Value(OptionValue::Bool(b)),
        SteelVal::IntV(n) => OptionInput::Value(OptionValue::Int(n as i64)),
        SteelVal::StringV(s) => OptionInput::Value(OptionValue::Str(s.to_string())),
        value @ SteelVal::ListV(_) => decoded(
            OptionType::List,
            option_strings(value, "list item").map(OptionValue::List),
        ),
        value @ SteelVal::HashMapV(_) => decoded(
            OptionType::Sections,
            decode_sections(value).map(OptionValue::Sections),
        ),
        value => OptionInput::Foreign(value_name(&value)),
    }
}

/// A script value of no option type, as an error names it.
fn value_name(value: &SteelVal) -> String {
    match value {
        SteelVal::SymbolV(s) => format!("the symbol '{s}"),
        value => value.to_string(),
    }
}

/// The list `value`'s items, each a string, `ctx_name` labelling an item an
/// error names. An option value has one spelling, so a symbol item is
/// refused as a symbol value is, unlike the builtins' other string lists.
fn option_strings(value: SteelVal, ctx_name: &str) -> Result<Vec<String>, SteelErr> {
    list_items(value, ctx_name)?
        .into_iter()
        .map(|item| match item {
            SteelVal::StringV(s) => Ok(s.to_string()),
            item => Err(generic_err(format!(
                "{ctx_name}: expected a string, got {}",
                value_name(&item)
            ))),
        })
        .collect()
}

/// The keys of the statusline's `(hash 'left 'center 'right)`, each a list of
/// element names.
const SECTION_KEYS: &[&str] = &["left", "center", "right"];

/// Decodes a statusline sections hash; every section is required.
fn decode_sections(value: SteelVal) -> Result<StatuslineSections, SteelErr> {
    let entry = hash_entry(value, "sections", SECTION_KEYS)?;
    let section = |key: &str| option_strings(entry.required(key)?, &entry.label(key));
    Ok(StatuslineSections {
        left: section("left")?,
        center: section("center")?,
        right: section("right")?,
    })
}

/// The statusline's sections as `get-option` reads them back:
/// [`decode_sections`]'s inverse.
pub(crate) fn sections_value(sections: StatuslineSections) -> SteelVal {
    symbol_hash([
        ("left", string_list(sections.left)),
        ("center", string_list(sections.center)),
        ("right", string_list(sections.right)),
    ])
}

/// `(set-option! key value)`
///
/// Sets the global setting `key` to `value`, in the type `get-option` reads
/// it back in: a boolean, an integer, a string, a list of strings for a
/// word-list setting (`shell`), or the statusline's sections hash. It is
/// forwarded to the editor's settings layer, which is the single validating chokepoint
/// (`editor::settings::ops::apply_global`) regardless of caller, so this is
/// callable from any context: `init.scm`, plugin load, plugin activation, or
/// a plain command/hook body. Use `:set buffer …` from the command line, or
/// `(set-buffer-option! pane key value)` from a script, to override a setting
/// for a specific buffer instead. A `BufferIntrinsicOption` (`language`,
/// `line-ending`) has no global value and raises, naming
/// `set-buffer-option!`.
pub(crate) fn set_option(ctx: &mut SteelCtx, key: String, value: SteelVal) -> SteelResult {
    let origin = ctx.registration_origin();
    ctx.host
        .settings()
        .set_global_option(&key, option_input(value), origin)
        .map_err(generic_err)?;
    Ok(SteelVal::Void)
}

/// `(set-buffer-option! pane key value)`
///
/// Sets `key`'s per-buffer override on `pane`'s buffer to `value`, in the
/// type `set-option!` takes it in. The override persists on the buffer until
/// overwritten, same as `:set buffer key=value`.
///
/// `"line-ending"` takes `"lf"` or `"crlf"` and sets the line ending a save writes; it errors on a read-only buffer.
///
/// `"language"` takes a string, `""` meaning no language. The host returns
/// the change, which is queued as `Effect::SetBufferLanguage` rather than
/// made here: it can activate plugins, which must not happen inside the
/// current eval.
///
/// A global-only option has no buffer value and raises, naming
/// `set-option!`.
///
/// Command/hook context only (`cmd` kind). The idiomatic caller is an
/// `on-language-set` hook handler, which receives a pane naming the target
/// buffer as an explicit argument rather than relying on `(focused-pane)` (a
/// live read that may differ from the buffer whose language just changed).
pub(crate) fn set_buffer_option(
    ctx: &mut SteelCtx,
    bid: BufferId,
    key: String,
    value: SteelVal,
) -> SteelResult {
    let origin = ctx.registration_origin();
    let written = ctx
        .host
        .settings()
        .set_buffer_option(&key, option_input(value), bid, origin)
        .map_err(generic_err)?;
    if let BufferOptionWrite::Language(language) = written {
        ctx.push_effect(Effect::SetBufferLanguage {
            buffer: bid,
            language,
            origin,
        });
    }
    Ok(SteelVal::Void)
}

/// `(get-option key)`: `key`'s global value, ignoring any buffer override
/// even if one exists (mirrors `set-option!`, `open` kind: callable from
/// any context, including `init.scm`). Use `(get-buffer-option pane key)`
/// for a specific buffer's effective value instead. A
/// `BufferIntrinsicOption` has no global value and raises, naming
/// `get-buffer-option`.
pub(crate) fn get_option(ctx: &mut SteelCtx, key: String) -> SteelResult {
    ctx.host
        .settings()
        .get_global_option(&key)
        .map(option_value_to_steel)
        .map_err(generic_err)
}

/// `(get-buffer-option pane key)`: the effective value of `key` for `pane`'s buffer:
/// its buffer override if one is set, else the global default. `"language"`
/// reads the buffer's language name (`""` for none), including a change
/// queued earlier in this same eval. `"line-ending"` reads `"lf"` or
/// `"crlf"`; it has no global default. A global-only option has no buffer
/// value and raises, naming `get-option`.
///
/// Command/hook context only (`cmd` kind). The idiomatic caller is an
/// `on-language-set` hook handler, which receives a pane naming the target
/// buffer as an explicit argument rather than relying on `(focused-pane)` (a
/// live read that may differ from the buffer whose language just changed), same
/// reasoning as `set-buffer-option!`.
pub(crate) fn get_buffer_option(ctx: &mut SteelCtx, bid: BufferId, key: String) -> SteelResult {
    // The language changes queued so far this eval live here, not on the
    // host, so this read ranks them onto the buffer's own.
    if key == BufferIntrinsicOption::Language.name() {
        let language = effective_language(ctx, bid);
        return Ok(SteelVal::StringV(
            LanguageOptionText::encode(language.as_deref()).into(),
        ));
    }
    ctx.host
        .settings()
        .get_buffer_option(&key, bid)
        .map(option_value_to_steel)
        .map_err(generic_err)
}

/// `bid`'s language as a script sees it: the buffer's stored language with
/// every `"language"` write queued so far this eval ranked onto it as the
/// editor will apply them, `None` for none.
fn effective_language(ctx: &mut SteelCtx, bid: BufferId) -> Option<String> {
    let mut language = ctx.host.buffers().buffer_stored_language(bid);
    for QueuedEffect { effect, .. } in ctx.effects.iter() {
        if let Effect::SetBufferLanguage {
            buffer,
            language: written,
            origin,
        } = effect
            && *buffer == bid
            && language.by.claim(*origin).is_applied()
        {
            language.name.clone_from(written);
        }
    }
    language.name
}

#[cfg(test)]
mod tests;
