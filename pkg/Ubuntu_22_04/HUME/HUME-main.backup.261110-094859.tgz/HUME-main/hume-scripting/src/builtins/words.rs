//! `(split-words line word-chars)`: native word tokenization for Steel
//! plugins. `(string-common-prefix strings)`: the grapheme-cluster common
//! prefix, for the same reason, below. `(string-width s)`: the terminal
//! cells a string takes, and `(string-fit s cells side)`: the string cut to
//! them.
//!
//! Reuses `hume-editing`'s `word_runs`, built on the same
//! grapheme-cluster/combining-mark-safe stepping and `WordChars::classify`
//! that `w`/`b` motions and text objects already use, rather than approximating classification in Steel, since Steel has no
//! Unicode character-category table, so a hand-rolled Steel classifier
//! either merges non-ASCII punctuation into words or has to special-case
//! every script by hand. A word this returns is what a `w` motion would
//! select. `word_chars` is threaded straight through, so tokenization is
//! settings-aware per call: `core:stdlib`'s `stdlib/split-words` passes the
//! calling buffer's own `word-chars` (`(get-buffer-option pane
//! "word-chars")`), which is how `core:buffer-words` tokenizes, so `foo-bar`
//! splits into two words by default but stays one wherever `word-chars`
//! includes `-` (a CSS buffer, say).

use hume_editing::text::BufferText;
use hume_editing::word::{WordChars, word_runs};
use steel::rvals::SteelVal;

use super::SteelResult;
use super::args::{list_to_strings, string_arg, string_list, truncate_end_arg, usize_arg};
use super::errors::generic_err;

/// `(split-words line word-chars)` -> list of word strings, in order.
///
/// Validates `word_chars` first. A caller may pass any string, not only an
/// already-validated `get-buffer-option` value, so this input is untrusted
/// Steel-side data, the same as `buffer-lines`' range args. A value
/// `WordChars::classify` couldn't handle correctly (e.g. a whitespace
/// character other than the four `classify_char` recognizes) raises here
/// instead of misclassifying.
pub(crate) fn split_words(line: SteelVal, word_chars: SteelVal) -> SteelResult {
    let line = string_arg(line, "line")?;
    let word_chars = string_arg(word_chars, "word-chars")?;
    WordChars::validate(&word_chars).map_err(|e| generic_err(format!("word-chars: {e}")))?;
    let text = BufferText::from(line.as_str());
    let chars = WordChars::new(&word_chars);
    let words = word_runs(&text, chars)
        .into_iter()
        .map(|range| text.slice(range.chars()).to_string());
    Ok(string_list(words))
}

/// `(string-common-prefix strings)` -> the longest run of whole grapheme
/// clusters every string in `strings` starts with, `""` for `'()`. Steel
/// strings index by char, so a Scheme loop would cut a combining sequence.
pub(crate) fn string_common_prefix(strings: SteelVal) -> SteelResult {
    let strings = list_to_strings(strings, "strings")?;
    let mut rest = strings.iter();
    let common = rest.next().map_or("", |first| {
        rest.fold(first.as_str(), |prefix, s| {
            hume_rope::grapheme::common_str_prefix(prefix, s)
        })
    });
    Ok(SteelVal::StringV(common.into()))
}

/// `(string-width s)` -> the terminal cells `s` takes as a list row shows
/// it, by the measurement the drawer, menus and pickers paint with. A
/// picker's `#:render` fits its rows to a budget with it.
pub(crate) fn string_width(s: SteelVal) -> SteelResult {
    let s = string_arg(s, "s")?;
    let width = hume_rope::width::chrome_width(&s);
    Ok(SteelVal::IntV(width as isize))
}

/// `(string-fit s cells side)` -> `s` cut to `cells` terminal cells at its
/// `side` end (`'head` or `'tail`) behind a `…`, or `s` itself when it fits:
/// the cut a picker's `#:truncate` makes, never splitting a cluster.
pub(crate) fn string_fit(s: SteelVal, cells: SteelVal, side: SteelVal) -> SteelResult {
    let s = string_arg(s, "s")?;
    let cells = usize_arg(cells, "cells")?;
    let side = truncate_end_arg(side, "side")?;
    let fitted = hume_rope::width::truncate_marked(&s, cells, side);
    Ok(SteelVal::StringV(fitted.as_ref().into()))
}

#[cfg(test)]
mod tests;
