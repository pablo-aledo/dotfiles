//! One marshalling vocabulary for builtins: plain `SteelVal` decoders,
//! `FromSteelVal` newtypes for pane params ([`pane`], plus `Usize` for a
//! pane-sibling argument that needs the same steel-core-driven,
//! ahead-of-the-closure-body decode; see `BuiltinArg`, the seam that runs
//! each closed-buffer check), and the shared list/hash decoders every
//! multi-field setter builds on.
//! Server wire values (positions, ranges, text edits) decode in `wire`.
//!
//! `#f`-means-absent is decoded only by this module's `optional_*` family.
//! Enforced by `cargo test
//! absent_marker_is_decoded_only_in_args_rs` (`arch-lints/tests/
//! absent_decode.rs`).

use std::path::{Path, PathBuf};

use steel::rerrs::{ErrorKind, SteelErr};
use steel::rvals::{FromSteelVal, SteelVal};
use termina::event::KeyEvent;

use hume_core::{BufferId, HostToken, TruncateEnd};
use hume_platform::path::AbsolutePath;
use hume_rope::spanned::SpannedText;

use crate::Rooted;
use crate::host::{JobHandle, SupersedeKey, TimerHandle, token_to_steel};
use crate::keys::parse_key_sequence;
use crate::types::Params;

use super::SteelResult;
use super::errors::generic_err;

pub(crate) mod pane;

pub(crate) use pane::{ArgPane, FocusedPane, LiveBuffer, PaneNeed, RequesterPane, ShownPane};

/// The shared "this bid names no open buffer" error: one wording for every
/// liveness check that raises on a stale `PaneHandle`'s buffer: each pane
/// argument type's resolve ([`pane`]), [`LspTargetArg::Buffer`](super::lsp::LspTargetArg::Buffer)'s, and every
/// `buffers.rs`/`diff.rs` builtin whose host call already does the liveness
/// lookup (so a second `buffer_exists` check would be redundant) but still
/// needs this message. `arg` names the argument that carried the pane.
pub(crate) fn not_live_err(arg: &str, bid: BufferId) -> SteelErr {
    generic_err(format!("{arg}: invalid buffer id {bid:?}"))
}

// ── Plain decoders ──────────────────────────────────────────────────────────
//
// Calling convention: `(val, ctx_name: &str)`, one Rust param per Steel arg
// (the convention `register_fn_with_ctx` builtins use, not a `&[SteelVal]`
// slice). `ctx_name` names the argument for the error message.

/// [`string_ref_arg`], owned.
pub(crate) fn string_arg(val: SteelVal, ctx_name: &str) -> Result<String, SteelErr> {
    string_ref_arg(&val, ctx_name).map(str::to_owned)
}

/// A string, borrowed from `val`. Accepts both strings and symbols, since
/// Scheme callers often pass unquoted symbol literals where a string is
/// semantically expected.
pub(crate) fn string_ref_arg<'a>(val: &'a SteelVal, ctx_name: &str) -> Result<&'a str, SteelErr> {
    match val {
        SteelVal::StringV(s) => Ok(s.as_str()),
        SteelVal::SymbolV(s) => Ok(s.as_str()),
        _ => steel::stop!(TypeMismatch => "{}: expected a string", ctx_name),
    }
}

/// [`single_key`] of a key-spec string argument.
pub(crate) fn single_key_arg(val: SteelVal, ctx_name: &str) -> Result<KeyEvent, SteelErr> {
    single_key(&string_arg(val, ctx_name)?, ctx_name)
}

/// A key spec (`bind-key!`'s own syntax, decoded via
/// [`parse_key_sequence`]) that must name exactly one chord, not a
/// sequence. Shared by `insert-key!` (one key, no destination for a
/// sequence) and `picker!`/`live-picker!`'s keymap (one chord
/// dispatched at a time).
pub(crate) fn single_key(spec: &str, ctx_name: &str) -> Result<KeyEvent, SteelErr> {
    let mut keys = parse_key_sequence(spec)
        .map_err(|e| generic_err(format!("{ctx_name}: invalid key spec '{spec}': {e}")))?;
    if keys.len() != 1 {
        steel::stop!(Generic => "{}: key spec '{}' must name exactly one key, not a sequence", ctx_name, spec);
    }
    Ok(keys.remove(0))
}

/// `None` for `#f`, otherwise `decode` of `val`: the one place the `#f`
/// check of an `optional_*` decoder lives.
fn optional<T>(
    val: SteelVal,
    ctx_name: &str,
    decode: impl FnOnce(SteelVal, &str) -> Result<T, SteelErr>,
) -> Result<Option<T>, SteelErr> {
    match val {
        SteelVal::BoolV(false) => Ok(None),
        other => decode(other, ctx_name).map(Some),
    }
}

/// A Steel list of strings that may be `#f` (absent).
pub(crate) fn optional_list_to_strings(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<Vec<String>>, SteelErr> {
    optional(val, ctx_name, list_to_strings)
}

/// A string argument that may be `#f` (absent).
pub(crate) fn optional_string_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<String>, SteelErr> {
    optional(val, ctx_name, string_arg)
}

/// A symbol argument that may be `#f` (absent). Unlike `optional_string_arg`,
/// it rejects a plain string: a caller wanting this shape is decoding a Scheme
/// keyword like `'error`, not free text, and `string_arg`'s string-or-symbol
/// leniency would silently widen what it accepts.
pub(crate) fn optional_symbol_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<String>, SteelErr> {
    match val {
        SteelVal::BoolV(false) => Ok(None),
        SteelVal::SymbolV(s) => Ok(Some(s.to_string())),
        _ => steel::stop!(TypeMismatch => "{}: expected a symbol or #f", ctx_name),
    }
}

/// A required symbol argument. `expected` names what the symbol stands for,
/// with an example (`"a mode symbol like 'normal"`), for the error.
pub(crate) fn symbol_arg<'a>(
    val: &'a SteelVal,
    ctx_name: &str,
    expected: &str,
) -> Result<&'a str, SteelErr> {
    match val {
        SteelVal::SymbolV(s) => Ok(s.as_str()),
        _ => steel::stop!(TypeMismatch => "{}: expected {}, got {:?}", ctx_name, expected, val),
    }
}

/// Maps an already-decoded keyword string to one of a fixed set of enum
/// values via a `(spelling, value)` table: the "must be 'a, 'b, or 'c, got
/// 'x" shape shared by every Steel enum-keyword decoder. Callers
/// extract the string themselves first (`string_arg` for a string-or-symbol
/// argument, a stricter symbol-only check where the wire contract insists on
/// a bare symbol). This helper is only about the mapping and the error
/// message, so those extraction strictness differences aren't flattened.
pub(crate) fn symbol_enum_arg<T: Copy>(
    s: &str,
    ctx_name: &str,
    variants: &[(&str, T)],
) -> Result<T, SteelErr> {
    for (name, value) in variants {
        if *name == s {
            return Ok(*value);
        }
    }
    let names: Vec<&str> = variants.iter().map(|(name, _)| *name).collect();
    steel::stop!(Generic => "{}: must be {}, got '{}'", ctx_name, format_symbol_choices(&names), s)
}

/// Renders `["a", "b", "c"]` as `"'a, 'b, or 'c"` (or `"'a or 'b"` for two,
/// `"'a"` for one): the quoted, Oxford-comma phrasing every enum-keyword
/// error message uses.
fn format_symbol_choices(names: &[&str]) -> String {
    match names {
        [] => String::new(),
        [a] => format!("'{a}"),
        [a, b] => format!("'{a} or '{b}"),
        [rest @ .., last] => {
            let rest: Vec<String> = rest.iter().map(|name| format!("'{name}")).collect();
            format!("{}, or '{last}", rest.join(", "))
        }
    }
}

/// A filesystem path, from a Steel string.
pub(crate) fn path_arg(val: SteelVal, ctx_name: &str) -> Result<PathBuf, SteelErr> {
    match val {
        SteelVal::StringV(s) => Ok(PathBuf::from(s.as_str())),
        _ => steel::stop!(TypeMismatch => "{}: expected a string path", ctx_name),
    }
}

/// A path argument that may be `#f` (absent).
pub(crate) fn optional_path_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<PathBuf>, SteelErr> {
    match val {
        SteelVal::BoolV(false) => Ok(None),
        SteelVal::StringV(s) => Ok(Some(PathBuf::from(s.as_str()))),
        _ => steel::stop!(TypeMismatch => "{}: expected a string path or #f", ctx_name),
    }
}

/// A `#:cwd` argument: `#f` is `editor_cwd`, a relative path resolves
/// against it as a [`ScriptPath`] does.
pub(crate) fn cwd_arg(
    val: SteelVal,
    editor_cwd: &AbsolutePath,
    ctx_name: &str,
) -> Result<PathBuf, SteelErr> {
    match optional_path_arg(val, ctx_name)? {
        Some(dir) => under_cwd(&dir, editor_cwd, ctx_name).map(|dir| dir.to_path_buf()),
        None => Ok(editor_cwd.to_path_buf()),
    }
}

/// A `#:relative` argument: `#f` is no base, a relative path resolves
/// against `editor_cwd` as a [`ScriptPath`] does. `editor_cwd` runs only
/// when a base is given.
pub(crate) fn relative_base_arg(
    val: SteelVal,
    editor_cwd: impl FnOnce() -> AbsolutePath,
) -> Result<Option<AbsolutePath>, SteelErr> {
    optional_path_arg(val, "#:relative")?
        .map(|base| under_cwd(&base, &editor_cwd(), "#:relative"))
        .transpose()
}

/// `path`, taken as written, made absolute against `cwd` as
/// [`AbsolutePath::from_path`] makes it, its error naming `ctx_name`.
pub(crate) fn under_cwd(
    path: &Path,
    cwd: &AbsolutePath,
    ctx_name: &str,
) -> Result<AbsolutePath, SteelErr> {
    AbsolutePath::from_path(path, cwd)
        .map_err(|e| generic_err(format!("{ctx_name}: {}: {e}", path.display())))
}

/// A non-negative integer, as `usize`. Callers needing `u64` (millisecond
/// durations) cast at the call site.
pub(crate) fn usize_arg(val: SteelVal, ctx_name: &str) -> Result<usize, SteelErr> {
    match val {
        SteelVal::IntV(n) if n >= 0 => Ok(n as usize),
        _ => steel::stop!(TypeMismatch => "{}: expected a non-negative integer", ctx_name),
    }
}

/// A [`TruncateEnd`] symbol, `'head` (drop the front) or `'tail` (drop the
/// back): a picker's or drawer's `#:truncate`, `string-fit`'s `side`. One
/// decoder, so every caller accepts the same spelling and raises the same
/// error.
pub(crate) fn truncate_end_arg(val: SteelVal, ctx_name: &str) -> Result<TruncateEnd, SteelErr> {
    symbol_enum_arg(
        string_arg(val, ctx_name)?.as_str(),
        ctx_name,
        &TruncateEnd::NAMED,
    )
}

/// A non-negative-integer argument that may be `#f` (absent).
pub(crate) fn optional_usize_arg(val: SteelVal, ctx_name: &str) -> Result<Option<usize>, SteelErr> {
    optional(val, ctx_name, usize_arg)
}

/// A widget opener's result: the new widget's token, or `#f` when the open
/// was dropped.
pub(crate) fn token_or_false(token: Option<HostToken>) -> SteelVal {
    token.map_or(SteelVal::BoolV(false), token_to_steel)
}

/// `token_or_false`'s inverse: decodes any token argument. `#f` is what a
/// dropped widget open returned, or what a script holds before it has a
/// token or once what the token named is gone. Each is the stale case, so
/// `#f` decodes to [`HostToken::NONE`], which the host treats as any other
/// stale token rather than raising.
pub(crate) fn token_arg(val: SteelVal, ctx_name: &str) -> Result<HostToken, SteelErr> {
    Ok(optional_usize_arg(val, ctx_name)?
        .map_or(HostToken::NONE, |n| HostToken::from_script(n as u64)))
}

/// A closure's parameter count and whether it also takes a rest parameter;
/// `None` for a callable whose shape can't be read (a builtin).
pub(crate) fn closure_shape(proc: &SteelVal) -> Option<(usize, bool)> {
    match proc {
        SteelVal::Closure(gc) => Some((gc.arity(), gc.is_multi_arity())),
        _ => None,
    }
}

/// Whether `proc` can be called with `args` arguments: a closure of exactly
/// that many parameters, or one with a rest parameter whose fixed ones fit.
/// A builtin's parameter count can't be read, so Steel checks it when it
/// runs.
pub(crate) fn takes_args(proc: &SteelVal, args: usize) -> bool {
    match closure_shape(proc) {
        Some((count, false)) => count == args,
        // A closure with a rest parameter counts it in its arity.
        Some((count, true)) => count <= args + 1,
        None => true,
    }
}

/// The error for a callback HUME calls with `args` arguments, when `proc`
/// can't take them.
fn arity_problem(proc: &SteelVal, args: usize) -> Option<String> {
    let noun = if args == 1 { "parameter" } else { "parameters" };
    (!takes_args(proc, args)).then(|| format!("expected a procedure of {args} {noun}"))
}

/// A command procedure's `(arity, is_variadic)`. A builtin's arity is not
/// introspectable, so it counts as 0-arg non-variadic: keymap injection then
/// passes no leading args rather than blindly injecting 2.
pub(crate) fn command_shape(proc: &SteelVal) -> (u16, bool) {
    closure_shape(proc).map_or((0, false), |(arity, rest)| (arity as u16, rest))
}

/// A server value, as hooks, `lsp-servers` and results hand it out.
pub(crate) fn server_arg(val: &SteelVal, ctx_name: &str) -> Result<crate::ServerRef, SteelErr> {
    crate::ServerRef::from_steel_val(val)
        .ok_or_else(|| generic_err(format!("{ctx_name}: expected a server value")))
}

/// A timer, as `after!` hands it out.
pub(crate) fn timer_arg(val: &SteelVal, ctx_name: &str) -> Result<TimerHandle, SteelErr> {
    super::ids::downcast(val)
        .ok_or_else(|| generic_err(format!("{ctx_name}: expected a timer (from after!)")))
}

/// A job, as `spawn-async!` and `path-programs` hand it out.
pub(crate) fn job_arg(val: &SteelVal, ctx_name: &str) -> Result<JobHandle, SteelErr> {
    super::ids::downcast(val).ok_or_else(|| {
        generic_err(format!(
            "{ctx_name}: expected a job (from spawn-async! or path-programs)"
        ))
    })
}

/// A `#:supersede` key that may be `#f` (absent), as `lsp-supersede-key`
/// hands it out.
pub(crate) fn optional_supersede_key_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<SupersedeKey>, SteelErr> {
    optional(val, ctx_name, |v, ctx| {
        super::ids::downcast(&v)
            .ok_or_else(|| generic_err(format!("{ctx}: expected a key from lsp-supersede-key")))
    })
}

/// A generation of `buffer` that may be `#f` (absent), as `buffer-generation`
/// hands it out.
pub(crate) fn optional_generation_arg(
    val: SteelVal,
    buffer: BufferId,
    ctx_name: &str,
) -> Result<Option<u64>, SteelErr> {
    optional(val, ctx_name, |v, ctx| {
        super::ids::BufferGeneration::of(&v, buffer, ctx).map_err(generic_err)
    })
}

/// A server value that may be `#f` (absent).
pub(crate) fn optional_server_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<crate::ServerRef>, SteelErr> {
    optional(val, ctx_name, |v, ctx| server_arg(&v, ctx))
}

/// An optional token argument: `None` for `#f`, the token otherwise.
pub(crate) fn optional_token_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<HostToken>, SteelErr> {
    Ok(optional_usize_arg(val, ctx_name)?.map(|n| HostToken::from_script(n as u64)))
}

pub(crate) fn int_arg(val: SteelVal, ctx_name: &str) -> Result<i64, SteelErr> {
    match val {
        SteelVal::IntV(n) => Ok(n as i64),
        _ => steel::stop!(TypeMismatch => "{}: expected an integer", ctx_name),
    }
}

pub(crate) fn bool_arg(val: SteelVal, ctx_name: &str) -> Result<bool, SteelErr> {
    match val {
        SteelVal::BoolV(b) => Ok(b),
        _ => steel::stop!(TypeMismatch => "{}: expected a bool", ctx_name),
    }
}

/// A Steel callable: `Closure`, `FuncV`, or `MutFunc`, the same three
/// variants `define-command!`'s own `proc` check accepts. Kept in one place
/// so a second "is this callable" decode (e.g. `live-picker!`'s
/// `#:source`) never drifts from that list.
fn is_callable_value(val: &SteelVal) -> bool {
    matches!(
        val,
        SteelVal::Closure(_) | SteelVal::FuncV(_) | SteelVal::MutFunc(_)
    )
}

/// A callable argument, rooted: every builtin that takes one keeps it past
/// the call.
pub(crate) fn callable_arg(val: SteelVal, ctx_name: &str) -> Result<Rooted, SteelErr> {
    if !is_callable_value(&val) {
        steel::stop!(TypeMismatch => "{}: expected a callable, got {:?}", ctx_name, val);
    }
    Ok(Rooted::new(val))
}

/// `(%callable? v args)`: whether `v` is a callable that can take `args`
/// arguments ([`takes_args`]). Backs the `#:source` check of `live-picker!`
/// and the `argv-for` check of `picker-command-source` (see `bootstrap.scm`).
/// `live-picker!` must validate its source in Scheme before composing the
/// debounced-requery wrapper around it: once wrapped, `%live-picker!`'s own
/// `callback_arg` check on `on_query_change` sees only the wrapper closure,
/// not the caller's value. Uses `callable_arg`'s own check, not
/// Steel's own `function?`/`procedure?`, which accept
/// `BoxedFunction`/`ContinuationFunction`/`BuiltIn` too, wider than the
/// three variants `callable_arg` (and `define-command!`'s `proc` check)
/// accept; a second, looser "is this callable" decode here would be exactly
/// the drift `is_callable_value`'s own doc comment says to avoid.
pub(crate) fn is_callable(val: SteelVal, args: SteelVal) -> SteelResult {
    let args = usize_arg(args, "args")?;
    Ok(SteelVal::BoolV(
        is_callable_value(&val) && takes_args(&val, args),
    ))
}

/// A Steel list, unpacked to a `Vec<SteelVal>`.
pub(crate) fn list_items(val: SteelVal, ctx_name: &str) -> Result<Vec<SteelVal>, SteelErr> {
    match val {
        SteelVal::ListV(list) => Ok(list.into_iter().collect()),
        _ => steel::stop!(TypeMismatch => "{}: expected a list", ctx_name),
    }
}

/// A Steel list that may be `#f` (absent).
pub(crate) fn optional_list_items(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<Vec<SteelVal>>, SteelErr> {
    optional(val, ctx_name, list_items)
}

/// A Steel list of strings, unpacked to a `Vec<String>`.
pub(crate) fn list_to_strings(val: SteelVal, ctx_name: &str) -> Result<Vec<String>, SteelErr> {
    list_items(val, ctx_name)?
        .into_iter()
        .map(|v| string_arg(v, ctx_name))
        .collect()
}

/// A string, as one value, or a Steel list of strings.
pub(crate) fn strings_arg(val: SteelVal, ctx_name: &str) -> Result<Vec<String>, SteelErr> {
    match val {
        SteelVal::ListV(_) => list_to_strings(val, ctx_name),
        SteelVal::StringV(_) | SteelVal::SymbolV(_) => Ok(vec![string_arg(val, ctx_name)?]),
        _ => steel::stop!(TypeMismatch => "{}: expected a string or a list of strings", ctx_name),
    }
}

/// The one character `s` holds, `None` for any other length.
pub(crate) fn single_char(s: &str) -> Option<char> {
    let mut chars = s.chars();
    match (chars.next(), chars.next()) {
        (Some(c), None) => Some(c),
        _ => None,
    }
}

/// A Steel list of integers, unpacked to `Vec<i32>`: `picker-source-spawn!`'s
/// `#:ok-exit-codes`, an exit-code allowlist. Rejects (rather than silently
/// truncating) a value outside `i32`'s range. Every other decoder in this
/// file rejects out-of-domain input the same way, and a wrapped value here
/// would silently allowlist the wrong exit code.
pub(crate) fn list_to_i32s(val: SteelVal, ctx_name: &str) -> Result<Vec<i32>, SteelErr> {
    list_items(val, ctx_name)?
        .into_iter()
        .map(|v| {
            let n = int_arg(v, ctx_name)?;
            match i32::try_from(n) {
                Ok(n) => Ok(n),
                Err(_) => steel::stop!(TypeMismatch => "{}: {} is out of i32 range", ctx_name, n),
            }
        })
        .collect()
}

/// The entry shape of an `#:env` list, for [`list_to_string_pairs`].
pub(crate) const ENV_PAIR_SHAPE: &str = "(\"KEY\" . \"VALUE\")";

/// A Steel list of dotted string pairs, unpacked to `Vec<(String, String)>`.
/// `shape` names an entry in the error for one that is not a pair.
pub(crate) fn list_to_string_pairs(
    val: SteelVal,
    ctx_name: &str,
    shape: &str,
) -> Result<Vec<(String, String)>, SteelErr> {
    list_items(val, ctx_name)?
        .into_iter()
        .map(|entry| {
            let (car, cdr) = pair_fields(entry, ctx_name, shape)?;
            Ok((string_arg(car, ctx_name)?, string_arg(cdr, ctx_name)?))
        })
        .collect()
}

/// [`list_to_string_pairs`] for a value that may be `#f` (absent).
pub(crate) fn optional_list_to_string_pairs(
    val: SteelVal,
    ctx_name: &str,
    shape: &str,
) -> Result<Option<Vec<(String, String)>>, SteelErr> {
    optional(val, ctx_name, |val, ctx_name| {
        list_to_string_pairs(val, ctx_name, shape)
    })
}

/// A Steel list of chars, unpacked to a `Vec<char>`.
pub(crate) fn chars_arg(val: SteelVal, ctx_name: &str) -> Result<Vec<char>, SteelErr> {
    list_items(val, ctx_name)?
        .into_iter()
        .map(|item| match item {
            SteelVal::CharV(c) => Ok(c),
            other => steel::stop!(TypeMismatch =>
                "{}: each entry must be a char, like #\\., got {}", ctx_name, other),
        })
        .collect()
}

/// The single entry point for a JSON-shaped argument that might already be
/// a [`JsonHandle`](crate::json::JsonHandle) (an `lsp-request!` response
/// threaded straight back in) or ordinary Steel data a plugin built by hand
/// (`(hash "line" 0 ...)`). An already-handle `val` returns it as-is, no
/// clone; anything else is converted once via [`json_params`] and wrapped
/// fresh. Delegating the non-handle path to `json_params` (rather than the
/// reverse) means the handle path here never pays for a conversion it
/// doesn't need. An argument whose positions are wire units goes through
/// [`super::wire::tagged_json_arg`] instead.
pub(crate) fn json_arg(val: SteelVal, ctx_name: &str) -> Result<crate::json::JsonHandle, SteelErr> {
    if let Some(handle) = crate::json::downcast_json_handle(&val) {
        return Ok(handle);
    }
    Ok(crate::json::JsonHandle::new(json_params(val, ctx_name)?))
}

/// Converts `val` to request params, so a malformed value raises at the
/// call rather than when the request is sent. Rejects a bool explicitly:
/// several callers pass through a value that is `#f` when absent, and
/// without this check that would reach a JSON consumer as `false` instead of
/// erroring at the boundary.
pub(crate) fn checked_params(val: SteelVal, ctx_name: &str) -> Result<Params, SteelErr> {
    if matches!(val, SteelVal::BoolV(_)) {
        steel::stop!(TypeMismatch => "{}: expected a hashmap or JSON handle, got a boolean", ctx_name);
    }
    crate::json::steel_to_params(&val).map_err(|e| generic_err(format!("{ctx_name}: {e}")))
}

/// Converts `val` to the wire-shaped JSON a request/notification `params`
/// (or an `#:init-options`/`#:settings` blob) expects: an owned `Value` for
/// a caller that has to build an outgoing message (the value must outlive
/// this call to reach the wire). A host-trait method that only *reads* the
/// JSON takes [`json_arg`]'s handle directly instead, borrowing rather than
/// cloning. An already-handle `val` costs one clone, which the wire message
/// needs.
pub(crate) fn json_params(val: SteelVal, ctx_name: &str) -> Result<serde_json::Value, SteelErr> {
    match checked_params(val, ctx_name)? {
        Params::Json(json) => Ok(json),
        _ => Err(generic_err(format!(
            "{ctx_name}: {}",
            crate::json::DOC_SPAN_NOT_JSON
        ))),
    }
}

/// A JSON-blob argument that may be `#f` (absent).
pub(crate) fn optional_json_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<serde_json::Value>, SteelErr> {
    optional(val, ctx_name, json_params)
}

/// A caught `with-handler` exception value that may be `#f` (no exception:
/// the activation succeeded). `#f` decodes as `None`; anything else decodes
/// as the `SteelErr` `with-handler` caught (`with-handler`'s lambda receives
/// the raised error's own `into_steelval()` form, so `SteelErr::from_steelval`
/// round-trips it with its span intact). Used only by
/// `%finish-lazy-activation!`/`%finish-manifest-load!`'s `error` argument;
/// see `bootstrap.scm`'s `%activate-plugin-inline!`/`declare-plugin!`.
pub(crate) fn optional_steel_error_arg(
    val: SteelVal,
    ctx_name: &str,
) -> Result<Option<SteelErr>, SteelErr> {
    match val {
        SteelVal::BoolV(false) => Ok(None),
        other => SteelErr::from_steelval(&other).map(Some).map_err(|_| {
            generic_err(format!(
                "{ctx_name}: expected #f or an error value, got {other:?}"
            ))
        }),
    }
}

// ── Symbol-keyed hash entries ────────────────────────────────────────────────

/// One symbol-keyed hashmap (a decoration setter's `(hash 'line …)`), its
/// keys already checked against the caller's own key set by [`hash_entry`]. Values sit in slots parallel to that key set, so a lookup
/// is a scan over a few short names rather than a hashmap probe.
pub(crate) struct HashEntry<'a> {
    keys: &'a [&'a str],
    // steel-val-transient: decoded and read within one builtin call.
    slots: Vec<Option<SteelVal>>,
    ctx_name: &'a str,
}

impl HashEntry<'_> {
    /// `"<ctx_name> '<key>"`, the label a decoder reports a bad `key` under.
    pub(crate) fn label(&self, key: &str) -> String {
        format!("{} '{key}", self.ctx_name)
    }

    /// `key` must be one of the keys handed to [`hash_entry`]: asking for any
    /// other is a bug in the caller, not bad user input.
    fn slot(&self, key: &str) -> &Option<SteelVal> {
        let i = self
            .keys
            .iter()
            .position(|k| *k == key)
            .expect("key is one of the keys passed to hash_entry");
        &self.slots[i]
    }

    pub(crate) fn optional(&self, key: &str) -> Option<SteelVal> {
        self.slot(key).clone()
    }

    pub(crate) fn required(&self, key: &str) -> Result<SteelVal, SteelErr> {
        self.optional(key)
            .ok_or_else(|| generic_err(format!("{}: missing '{key}", self.ctx_name)))
    }

    pub(crate) fn usize(&self, key: &str) -> Result<usize, SteelErr> {
        usize_arg(self.required(key)?, &self.label(key))
    }

    pub(crate) fn string(&self, key: &str) -> Result<String, SteelErr> {
        string_arg(self.required(key)?, &self.label(key))
    }

    pub(crate) fn optional_string(&self, key: &str) -> Result<Option<String>, SteelErr> {
        self.optional(key)
            .map(|v| string_arg(v, &self.label(key)))
            .transpose()
    }

    /// The `'start-char`/`'end-char` pair of an entry decoded with both keys
    /// in its key set, both required.
    pub(crate) fn char_range(&self) -> Result<(usize, usize), SteelErr> {
        Ok((self.usize(START_CHAR)?, self.usize(END_CHAR)?))
    }

    /// The `'start-char-col`/`'end-char-col` pair of an entry decoded with
    /// both keys in its key set, both required.
    pub(crate) fn char_col_range(&self) -> Result<(usize, usize), SteelErr> {
        Ok((self.usize(START_CHAR_COL)?, self.usize(END_CHAR_COL)?))
    }

    /// The `'line` of an entry decoded with `'line` and `'end-line` in its key
    /// set, and its `'end-line` when given.
    pub(crate) fn line_and_end_line(&self) -> Result<(usize, Option<usize>), SteelErr> {
        let line = self.usize("line")?;
        let end = self
            .optional(END_LINE)
            .map(|v| usize_arg(v, &self.label(END_LINE)))
            .transpose()?;
        Ok((line, end))
    }

    /// The `'start-line`/`'end-line` pair of an entry decoded with both keys
    /// in its key set, both required.
    pub(crate) fn line_range(&self) -> Result<(usize, usize), SteelErr> {
        Ok((self.usize(START_LINE)?, self.usize(END_LINE)?))
    }
}

// ── Position shapes ───────────────────────────────────────────────────────────

/// The keys a position hash names its unit with. A char range is
/// `(hash 'start-char s 'end-char e)`, char offsets into a whole text (the
/// buffer, or a text the script passed); a char-column range is `(hash
/// 'start-char-col s 'end-char-col e)`, char columns within one line; a
/// content-line range is `(hash 'start-line s 'end-line e)`. All are 0-based
/// and end-exclusive, and one char position is `'char-offset`.
pub(crate) const START_CHAR: &str = "start-char";
pub(crate) const END_CHAR: &str = "end-char";
pub(crate) const START_CHAR_COL: &str = "start-char-col";
pub(crate) const END_CHAR_COL: &str = "end-char-col";
pub(crate) const START_LINE: &str = "start-line";
pub(crate) const END_LINE: &str = "end-line";
pub(crate) const CHAR_OFFSET: &str = "char-offset";

pub(crate) const CHAR_RANGE_KEYS: &[&str] = &[START_CHAR, END_CHAR];
pub(crate) const LINE_RANGE_KEYS: &[&str] = &[START_LINE, END_LINE];

/// A char range as Steel sees it: `(hash 'start-char s 'end-char e)`.
pub(crate) fn char_range_value(start: usize, end: usize) -> SteelVal {
    symbol_hash([
        (START_CHAR, SteelVal::IntV(start as isize)),
        (END_CHAR, SteelVal::IntV(end as isize)),
    ])
}

/// A content-line range as Steel sees it: `(hash 'start-line s 'end-line e)`.
/// The one shape `viewport-range` returns, `buffer-lines` takes as `#:range`
/// and `on-viewport-change` passes.
pub fn line_range_value(
    range: hume_rope::offset::ExclusiveRange<hume_rope::line::ContentLine>,
) -> SteelVal {
    symbol_hash([
        (START_LINE, SteelVal::IntV(range.start.index() as isize)),
        (END_LINE, SteelVal::IntV(range.end.index() as isize)),
    ])
}

/// Decodes one symbol-keyed hashmap: the shared decode for a record a
/// builtin takes (a decoration entry, a goto target). The hashmap's keys must
/// all be symbols drawn from `keys`; an unknown or non-symbol key errors, so
/// a misspelled key is reported, not ignored. Which keys are required is the
/// caller's call, via [`HashEntry::required`].
pub(crate) fn hash_entry<'a>(
    val: SteelVal,
    ctx_name: &'a str,
    keys: &'a [&'a str],
) -> Result<HashEntry<'a>, SteelErr> {
    let expected = || {
        keys.iter()
            .map(|k| format!("'{k}"))
            .collect::<Vec<_>>()
            .join(" ")
    };
    let SteelVal::HashMapV(map) = val else {
        steel::stop!(TypeMismatch =>
            "{}: expected a hashmap with keys from {}", ctx_name, expected());
    };
    let mut slots = vec![None; keys.len()];
    for (key, value) in map.iter() {
        let SteelVal::SymbolV(name) = key else {
            steel::stop!(Generic =>
                "{}: hashmap key must be a symbol, got {:?}", ctx_name, key);
        };
        let Some(i) = keys.iter().position(|k| *k == name.as_str()) else {
            steel::stop!(Generic =>
                "{}: unknown key '{}, expected one of {}", ctx_name, name, expected());
        };
        slots[i] = Some(value.clone());
    }
    Ok(HashEntry {
        keys,
        slots,
        ctx_name,
    })
}

/// [`hash_entry`] for an argument that may be `#f` (absent): the
/// `optional_*`-family sibling, so the `#f` check lives in this file only.
pub(crate) fn optional_hash_entry<'a>(
    val: SteelVal,
    ctx_name: &'a str,
    keys: &'a [&'a str],
) -> Result<Option<HashEntry<'a>>, SteelErr> {
    match val {
        SteelVal::BoolV(false) => Ok(None),
        other => hash_entry(other, ctx_name, keys).map(Some),
    }
}

/// `"<ctx_name> <index>"`, the label an error names one element of the list
/// `ctx_name` labels by.
pub(crate) fn item_label(ctx_name: &str, index: usize) -> String {
    let mut label = String::new();
    write_item_label(&mut label, ctx_name, index);
    label
}

/// [`item_label`] written over `label`, so a decoder walking a list reuses
/// one buffer for every element's label.
pub(crate) fn write_item_label(label: &mut String, ctx_name: &str, index: usize) {
    use std::fmt::Write;

    label.clear();
    write!(label, "{ctx_name} {index}").expect("writing to a String cannot fail");
}

/// `text` with the payload `spans` decoded from the list `ctx_name` labels,
/// each a `(start, end, payload)` of char offsets into `text`. A span that
/// does not fit `text` is an error naming it by its place in that list.
pub(crate) fn spanned_text<T>(
    text: String,
    spans: Vec<(usize, usize, T)>,
    ctx_name: &str,
) -> Result<SpannedText<T>, SteelErr> {
    SpannedText::new(text, spans)
        .map_err(|e| generic_err(format!("{}: {}", item_label(ctx_name, e.index), e.kind)))
}

/// Decodes a Steel list of symbol-keyed hashmaps into `Vec<T>`: the shared
/// skeleton every decoration setter opens with, [`hash_entry`] per element,
/// each labelled by its [`item_label`].
pub(crate) fn hash_list<T>(
    val: SteelVal,
    ctx_name: &str,
    keys: &[&str],
    mut row: impl FnMut(&HashEntry) -> Result<T, SteelErr>,
) -> Result<Vec<T>, SteelErr> {
    let mut label = String::new();
    list_items(val, ctx_name)?
        .into_iter()
        .enumerate()
        .map(|(i, entry)| {
            write_item_label(&mut label, ctx_name, i);
            row(&hash_entry(entry, &label, keys)?)
        })
        .collect()
}

// ── List encoders ─────────────────────────────────────────────────────────────

/// Builds a proper Steel list from already-encoded `SteelVal`s: the shared
/// encode counterpart to `list_items`, for a builtin returning a list rather
/// than decoding one.
pub(crate) fn list_of(items: impl IntoIterator<Item = SteelVal>) -> SteelVal {
    SteelVal::ListV(items.into_iter().collect())
}

/// A Steel list of strings: `list_of`'s common case, for a builtin whose
/// result is itself a list of `String`s (a diff hunk's lines, a tokenizer's
/// words) rather than a mix of `SteelVal` shapes.
pub(crate) fn string_list(items: impl IntoIterator<Item = String>) -> SteelVal {
    list_of(items.into_iter().map(|s| SteelVal::StringV(s.into())))
}

/// Builds a symbol-keyed Steel hashmap: the encode counterpart to
/// `hash_list`'s decode. An absent optional value is the caller's to map to
/// the convention its key documents.
pub fn symbol_hash(pairs: impl IntoIterator<Item = (&'static str, SteelVal)>) -> SteelVal {
    keyed_hash(pairs, |key| SteelVal::SymbolV(key.into()))
}

/// [`symbol_hash`] with string keys: the shape of a JSON object built in
/// Rust for Steel to extend (an LSP params hash).
pub(crate) fn string_hash(pairs: impl IntoIterator<Item = (&'static str, SteelVal)>) -> SteelVal {
    keyed_hash(pairs, |key| SteelVal::StringV(key.into()))
}

fn keyed_hash(
    pairs: impl IntoIterator<Item = (&'static str, SteelVal)>,
    key: fn(&'static str) -> SteelVal,
) -> SteelVal {
    let map: steel::HashMap<SteelVal, SteelVal> = pairs
        .into_iter()
        .map(|(k, value)| (key(k), value))
        .collect();
    SteelVal::HashMapV(steel::gc::Gc::new(map).into())
}

// ── Dotted-pair decoders/encoders ────────────────────────────────────────────

/// Unpacks `val` as a dotted pair `(car . cdr)`: the shared decode for wire
/// shapes that are semantically a 2-tuple (a position, a range). Rejects a
/// proper 2-element list: the wire format is a pair, not a list.
pub(crate) fn pair_fields(
    val: SteelVal,
    ctx_name: &str,
    shape: &str,
) -> Result<(SteelVal, SteelVal), SteelErr> {
    match val {
        SteelVal::Pair(p) => Ok((p.car(), p.cdr())),
        _ => steel::stop!(Generic => "{}: each entry must be {}", ctx_name, shape),
    }
}

/// Builds a dotted pair `(a . b)`: the shared encode counterpart to
/// `pair_fields`, via steel-core's public `cons` primitive (the only public
/// pair-construction API; the `Pair` type itself is unnameable outside
/// steel-core).
///
/// A list `b` (including `'()`) makes a proper `ListV` rather than a
/// `Pair`: steel's `cons` returns one when `b` is itself list-shaped, and
/// `pair_fields` would then reject the round-trip. That is fine for a value
/// only a script reads, as `display_item`'s is, where `(cdr row)` is still
/// `b`.
pub(crate) fn cons_pair(mut a: SteelVal, mut b: SteelVal) -> Result<SteelVal, SteelErr> {
    steel::primitives::lists::cons(&mut a, &mut b)
}

// ── FromSteelVal newtypes ────────────────────────────────────────────────────
//
// Used as typed params in builtin signatures. The `builtins!` table decodes
// them inside `errors::named`, which puts the builtin's name in front of a
// failure, so these messages carry no `ctx_name` of their own.

/// One marshalling step every ctx-taking `builtins!` table entry (`cmd`,
/// `config`, `open`) runs each declared argument through, right after its
/// `FromSteelVal` decode and its eval-mode gate: the seam where the pane
/// argument types ([`pane`]) check that a pane value's buffer is open and
/// make the value a body hands the host, so no body checks either by hand.
/// Every other declared arg type is
/// `Self`-identity here: decode is already everything they need. `arg` is
/// the argument's name in the table, which a failure names.
pub(crate) trait BuiltinArg {
    /// What the type needs from a pane value, `None` for one that checks no
    /// pane.
    const PANE_NEED: Option<PaneNeed> = None;
    type Out;
    fn resolve(self, ctx: &mut crate::SteelCtx, arg: &'static str) -> Result<Self::Out, SteelErr>;
}

/// `BuiltinArg::resolve` for a type whose decode is already everything it
/// needs: `Self::Out = Self`, `resolve` a no-op `Ok(self)`. One list
/// instead of a hand-copied nine-line body per type.
macro_rules! identity_builtin_arg {
    ($($ty:ty),+ $(,)?) => {
        $(
            impl BuiltinArg for $ty {
                type Out = $ty;
                fn resolve(
                    self,
                    _ctx: &mut crate::SteelCtx,
                    _arg: &'static str,
                ) -> Result<Self::Out, SteelErr> {
                    Ok(self)
                }
            }
        )+
    };
}

identity_builtin_arg!(SteelVal, String, bool, ArgPane);

/// [`usize_arg`]'s `FromSteelVal` counterpart, for a pane-sibling argument
/// that must decode (the `builtins!` table decodes every argument, left to
/// right, ahead of every resolve) before the pane's buffer is checked, so a
/// malformed sibling argument isn't masked behind a closed-buffer error.
/// `usize_arg`'s plain-function form stays the one every other builtin
/// decodes its own integer arguments with; this exists only where the
/// ordering matters.
#[derive(Debug, Clone, Copy)]
pub(crate) struct Usize(pub(crate) usize);

impl FromSteelVal for Usize {
    fn from_steelval(val: &SteelVal) -> Result<Self, SteelErr> {
        match val {
            SteelVal::IntV(n) if *n >= 0 => Ok(Usize(*n as usize)),
            _ => Err(SteelErr::new(
                ErrorKind::TypeMismatch,
                "expected a non-negative integer".to_string(),
            )),
        }
    }
}

impl BuiltinArg for Usize {
    type Out = usize;
    fn resolve(self, _ctx: &mut crate::SteelCtx, _arg: &'static str) -> Result<usize, SteelErr> {
        Ok(self.0)
    }
}

/// The name of a decoration, trigger or completion source: a string or a
/// symbol, as [`string_arg`] takes, that is not empty or blank. A builtin
/// declares its source-name parameter as this type in the `builtins!`
/// table, so a blank name is refused before a pane sibling's closed-buffer
/// check can mask it. Decoding has no parameter name, so the error names
/// only the builtin.
#[derive(Debug, Clone)]
pub(crate) struct SourceName(String);

impl FromSteelVal for SourceName {
    fn from_steelval(val: &SteelVal) -> Result<Self, SteelErr> {
        let name = string_ref_arg(val, "source name")?;
        if name.trim().is_empty() {
            steel::stop!(Generic => "source name must not be empty");
        }
        Ok(SourceName(name.to_owned()))
    }
}

impl BuiltinArg for SourceName {
    type Out = String;
    fn resolve(self, _ctx: &mut crate::SteelCtx, _arg: &'static str) -> Result<String, SteelErr> {
        Ok(self.0)
    }
}

/// A path argument, taken as written and made absolute by [`under_cwd`]: a
/// relative one joins onto the editor's working directory, and `~` and
/// variables are not expanded. A builtin declares its positional path
/// parameters as this type in the `builtins!` table; a keyword or
/// structured path (`#:cwd`, `register-grammar!`, `goto-location!`) goes
/// through the same [`under_cwd`].
#[derive(Debug, Clone)]
pub(crate) struct ScriptPath(PathBuf);

impl FromSteelVal for ScriptPath {
    fn from_steelval(val: &SteelVal) -> Result<Self, SteelErr> {
        match val {
            SteelVal::StringV(s) => Ok(ScriptPath(PathBuf::from(s.as_str()))),
            _ => Err(SteelErr::new(
                ErrorKind::TypeMismatch,
                "expected a string path".to_string(),
            )),
        }
    }
}

impl BuiltinArg for ScriptPath {
    type Out = AbsolutePath;
    fn resolve(
        self,
        ctx: &mut crate::SteelCtx,
        arg: &'static str,
    ) -> Result<AbsolutePath, SteelErr> {
        under_cwd(&self.0, &ctx.host.buffers().cwd(), arg)
    }
}

/// A proc a script hands HUME to call later with `ARGS` arguments, made a
/// [`crate::Callback`] run as the code that handed it over. A builtin
/// declares its callback parameters as this type in the `builtins!` table,
/// spelling the count its call site passes. Decoding checks it is callable
/// and can take `ARGS` arguments ([`takes_args`]), as [`callback_arg`]
/// does, so a bad one raises at the call rather than when it is first run.
/// Decoding has no parameter name, so the error names only the builtin; a
/// builtin taking two callbacks decodes the second with [`callback_arg`].
#[derive(Debug, Clone)]
pub(crate) struct ScriptProc<const ARGS: usize>(Rooted);

impl<const ARGS: usize> FromSteelVal for ScriptProc<ARGS> {
    fn from_steelval(val: &SteelVal) -> Result<Self, SteelErr> {
        if !is_callable_value(val) {
            steel::stop!(TypeMismatch => "expected a callable, got {:?}", val);
        }
        if let Some(problem) = arity_problem(val, ARGS) {
            steel::stop!(TypeMismatch => "{}", problem);
        }
        Ok(ScriptProc(Rooted::new(val.clone())))
    }
}

impl<const ARGS: usize> BuiltinArg for ScriptProc<ARGS> {
    type Out = crate::Callback;
    fn resolve(
        self,
        ctx: &mut crate::SteelCtx,
        _arg: &'static str,
    ) -> Result<crate::Callback, SteelErr> {
        Ok(crate::Callback::capture(ctx, self.0))
    }
}

/// A callable argument HUME calls later with `args` arguments, made a
/// [`crate::Callback`] run as the code `ctx` is running. Raises unless it
/// can take them ([`takes_args`]).
pub(crate) fn callback_arg(
    ctx: &crate::SteelCtx,
    val: SteelVal,
    args: usize,
    ctx_name: &str,
) -> Result<crate::Callback, SteelErr> {
    let proc = callable_arg(val, ctx_name)?;
    if let Some(problem) = arity_problem(proc.value(), args) {
        steel::stop!(TypeMismatch => "{}: {}", ctx_name, problem);
    }
    Ok(crate::Callback::capture(ctx, proc))
}

/// A callable argument that may be `#f` (absent), as [`callback_arg`].
pub(crate) fn optional_callback_arg(
    ctx: &crate::SteelCtx,
    val: SteelVal,
    args: usize,
    ctx_name: &str,
) -> Result<Option<crate::Callback>, SteelErr> {
    optional(val, ctx_name, |val, ctx_name| {
        callback_arg(ctx, val, args, ctx_name)
    })
}

#[cfg(test)]
mod tests;
