//! [`ReadOnlyHost`]: the editor as seen by a Steel proc that may read it but
//! must not change it (a drawer's row renderer, run between `settle` and the
//! frame it renders into).

use std::cell::{Cell, RefCell};

use hume_core::{
    BufferId, BufferOptionWrite, HostToken, OnUnsaved, OptionInput, OptionValue, PaneHandle,
};
use hume_platform::path::AbsolutePath;
use hume_rope::line::ContentLine;
use hume_rope::offset::ExclusiveRange;

use crate::attribution::EntryId;
use crate::command_procs::CommandProc;
use crate::host::{
    BufferHost, CommandHolder, CommandHost, CursorHost, EditorHost, EventHost, EventShape,
    LanguageHost, SelectionInfo, SettingsHost, ShownHandle, StoredLanguage, UndoNode,
};
use crate::types::{GrammarReg, SteelCmdDef, SteelTypedCmdDef};

/// Passes every read of the six required capabilities through to the
/// wrapped host, refuses every write, and offers none of the optional
/// capabilities, so their builtins raise "not supported by this host".
///
/// A refused write returns `Err` where its signature allows. Either way it is
/// recorded, and [`Self::refused`] reports the first one, so a proc that
/// catches the error still fails. Most reads take `&self` while the wrapped
/// host's accessors take `&mut self`, hence the `RefCell`; reads never nest.
pub(crate) struct ReadOnlyHost<'h> {
    inner: RefCell<&'h mut dyn EditorHost>,
    refused: Cell<Option<&'static str>>,
}

impl<'h> ReadOnlyHost<'h> {
    pub(crate) fn new(inner: &'h mut dyn EditorHost) -> Self {
        Self {
            inner: RefCell::new(inner),
            refused: Cell::new(None),
        }
    }

    /// The first write the proc attempted, as an error message.
    pub(crate) fn refused(&self) -> Option<String> {
        self.refused.get().map(refusal)
    }

    fn refuse(&self, name: &'static str) -> String {
        if self.refused.get().is_none() {
            self.refused.set(Some(name));
        }
        refusal(name)
    }
}

fn refusal(name: &str) -> String {
    format!("{name}: the editor cannot be changed while rendering")
}

impl EditorHost for ReadOnlyHost<'_> {
    fn cursor(&mut self) -> &mut dyn CursorHost {
        self
    }
    fn commands(&mut self) -> &mut dyn CommandHost {
        self
    }
    fn language(&mut self) -> &mut dyn LanguageHost {
        self
    }
    fn settings(&mut self) -> &mut dyn SettingsHost {
        self
    }
    fn buffers(&mut self) -> &mut dyn BufferHost {
        self
    }
    fn events(&mut self) -> &mut dyn EventHost {
        self
    }
    // A plugin that renders a drawer is expected to have already activated
    // every other plugin its renderer depends on.
    fn permit_plugin_activation(&mut self, _plugin: &EntryId) -> Result<(), String> {
        Err(self.refuse("plugin activation"))
    }
}

impl CursorHost for ReadOnlyHost<'_> {
    fn buffer_cursor_line(&self, pane: ShownHandle) -> Result<ContentLine, String> {
        self.inner.borrow_mut().cursor().buffer_cursor_line(pane)
    }
    fn buffer_selections(&self, pane: ShownHandle) -> Result<Vec<SelectionInfo>, String> {
        self.inner.borrow_mut().cursor().buffer_selections(pane)
    }
    fn char_offset_to_line(&self, bid: BufferId, idx: usize) -> Result<ContentLine, String> {
        self.inner
            .borrow_mut()
            .cursor()
            .char_offset_to_line(bid, idx)
    }
    fn symbol_under_cursor(&self, pane: ShownHandle) -> Result<String, String> {
        self.inner.borrow_mut().cursor().symbol_under_cursor(pane)
    }
    fn selections_linewise(&self, pane: ShownHandle) -> Result<bool, String> {
        self.inner.borrow_mut().cursor().selections_linewise(pane)
    }
    fn selections_charwise(&self, pane: ShownHandle) -> Result<bool, String> {
        self.inner.borrow_mut().cursor().selections_charwise(pane)
    }
}

impl CommandHost for ReadOnlyHost<'_> {
    fn command_is_native(&self, name: &str) -> Result<bool, String> {
        self.inner.borrow_mut().commands().command_is_native(name)
    }
    fn run_command_sync(
        &mut self,
        _name: &str,
        _pane: PaneHandle,
        _call: crate::host::NativeCall,
    ) -> Result<bool, String> {
        Err(self.refuse("run_command_sync"))
    }
    fn open_dispatch_group(&mut self) {}
    fn close_dispatch_group(&mut self) {}
    fn register_command(&mut self, _def: SteelCmdDef) -> Result<(), String> {
        Err(self.refuse("register_command"))
    }
    fn register_typed_command(&mut self, _def: SteelTypedCmdDef) -> Result<(), String> {
        Err(self.refuse("register_typed_command"))
    }
    fn defined_command(&self, name: &str) -> Option<CommandProc> {
        self.inner.borrow_mut().commands().defined_command(name)
    }
    fn unregister_commands_registered_in(&mut self, _activation: &EntryId) {
        self.refuse("unregister_commands_registered_in");
    }
    fn is_valid_register_name(&self, ch: char) -> bool {
        self.inner
            .borrow_mut()
            .commands()
            .is_valid_register_name(ch)
    }
    fn command_holder(&self, name: &str) -> Option<CommandHolder> {
        self.inner.borrow_mut().commands().command_holder(name)
    }
    fn register_lazy_commands(
        &mut self,
        _plugin: &EntryId,
        _commands: &[String],
        _typed_commands: &[String],
    ) -> Result<(), String> {
        Err(self.refuse("register_lazy_commands"))
    }
    fn lazy_command_owner(&self, name: &str) -> Option<EntryId> {
        self.inner.borrow_mut().commands().lazy_command_owner(name)
    }
    fn lazy_mappable_command_owner(&self, name: &str) -> Option<EntryId> {
        self.inner
            .borrow_mut()
            .commands()
            .lazy_mappable_command_owner(name)
    }
    fn unregister_lazy_stubs_of(&mut self, _plugin: &EntryId) {
        self.refuse("unregister_lazy_stubs_of");
    }
}

impl LanguageHost for ReadOnlyHost<'_> {
    fn attach_grammar(&mut self, _reg: &GrammarReg) -> Result<bool, String> {
        Err(self.refuse("attach_grammar"))
    }
    fn check_grammar(&self, _name: &str, _source: &hume_core::GrammarSource) -> Result<(), String> {
        Err(self.refuse("check_grammar"))
    }
    fn has_grammar(&self, language: &str) -> bool {
        self.inner.borrow_mut().language().has_grammar(language)
    }
}

impl SettingsHost for ReadOnlyHost<'_> {
    fn set_global_option(
        &mut self,
        _key: &str,
        _value: OptionInput,
        _origin: hume_core::ConfigOrigin,
    ) -> Result<(), String> {
        Err(self.refuse("set_global_option"))
    }
    fn set_buffer_option(
        &mut self,
        _key: &str,
        _value: OptionInput,
        _bid: BufferId,
        _origin: hume_core::ConfigOrigin,
    ) -> Result<BufferOptionWrite, String> {
        Err(self.refuse("set_buffer_option"))
    }
    fn get_global_option(&self, key: &str) -> Result<OptionValue, String> {
        self.inner.borrow_mut().settings().get_global_option(key)
    }
    fn get_buffer_option(&self, key: &str, bid: BufferId) -> Result<OptionValue, String> {
        self.inner
            .borrow_mut()
            .settings()
            .get_buffer_option(key, bid)
    }
    fn steel_command_budget_ms(&self) -> u64 {
        self.inner.borrow_mut().settings().steel_command_budget_ms()
    }
}

impl BufferHost for ReadOnlyHost<'_> {
    fn buffer_ids(&self) -> Vec<BufferId> {
        self.inner.borrow_mut().buffers().buffer_ids()
    }
    fn panes(&self) -> Vec<PaneHandle> {
        self.inner.borrow_mut().buffers().panes()
    }
    fn focused_pane(&self) -> PaneHandle {
        self.inner.borrow_mut().buffers().focused_pane()
    }
    fn buffer_panes(&self, id: BufferId) -> Vec<PaneHandle> {
        self.inner.borrow_mut().buffers().buffer_panes(id)
    }
    fn pane_live(&self, pane: PaneHandle) -> bool {
        self.inner.borrow_mut().buffers().pane_live(pane)
    }
    fn buffer_exists(&self, id: BufferId) -> bool {
        self.inner.borrow_mut().buffers().buffer_exists(id)
    }
    fn buffer_path(&self, id: BufferId) -> Option<AbsolutePath> {
        self.inner.borrow_mut().buffers().buffer_path(id)
    }
    fn buffer_display_path(
        &self,
        id: BufferId,
        relative_to: Option<&AbsolutePath>,
    ) -> Option<String> {
        self.inner
            .borrow_mut()
            .buffers()
            .buffer_display_path(id, relative_to)
    }
    fn buffer_display_name(&self, id: BufferId) -> Option<String> {
        self.inner.borrow_mut().buffers().buffer_display_name(id)
    }
    fn buffer_is_dirty(&self, id: BufferId) -> Option<bool> {
        self.inner.borrow_mut().buffers().buffer_is_dirty(id)
    }
    fn buffer_stored_language(&self, id: BufferId) -> StoredLanguage {
        self.inner.borrow_mut().buffers().buffer_stored_language(id)
    }
    fn buffer_visible_to(&self, id: BufferId, visibility: &crate::BufferVisibility) -> bool {
        self.inner
            .borrow_mut()
            .buffers()
            .buffer_visible_to(id, visibility)
    }
    fn cwd(&self) -> AbsolutePath {
        self.inner.borrow_mut().buffers().cwd()
    }
    fn search_path(&self) -> Option<std::ffi::OsString> {
        self.inner.borrow_mut().buffers().search_path()
    }
    fn set_cwd(&mut self, _path: &AbsolutePath) -> Result<AbsolutePath, String> {
        Err(self.refuse("set_cwd"))
    }
    fn open_buffer(&mut self, _path: &AbsolutePath) -> Result<BufferId, String> {
        Err(self.refuse("open_buffer"))
    }
    fn close_buffer(&mut self, _id: BufferId, _on_unsaved: OnUnsaved) -> Result<(), String> {
        Err(self.refuse("close_buffer"))
    }
    fn switch_to_buffer(
        &mut self,
        _pane: ShownHandle,
        _target: BufferId,
    ) -> Result<PaneHandle, String> {
        Err(self.refuse("switch_to_buffer"))
    }
    fn show_read_only_buffer(
        &mut self,
        _pane: ShownHandle,
        _name: &str,
        _text: &str,
    ) -> Result<PaneHandle, String> {
        Err(self.refuse("show_read_only_buffer"))
    }
    fn buffer_generation(&self, id: BufferId) -> Option<u64> {
        self.inner.borrow_mut().buffers().buffer_generation(id)
    }
    fn buffer_search(
        &self,
        id: BufferId,
        pattern: &str,
    ) -> Option<Result<Option<std::ops::Range<usize>>, String>> {
        self.inner.borrow_mut().buffers().buffer_search(id, pattern)
    }
    fn word_search_pattern(&self, id: BufferId, word: &str) -> Option<String> {
        self.inner
            .borrow_mut()
            .buffers()
            .word_search_pattern(id, word)
    }
    fn buffer_undo_tree(&self, id: BufferId) -> Option<Vec<UndoNode>> {
        self.inner.borrow_mut().buffers().buffer_undo_tree(id)
    }
    fn buffer_text(
        &self,
        id: BufferId,
        range: Option<(usize, usize)>,
    ) -> Option<Result<String, String>> {
        self.inner.borrow_mut().buffers().buffer_text(id, range)
    }
    fn buffer_line_count(&self, id: BufferId) -> Option<usize> {
        self.inner.borrow_mut().buffers().buffer_line_count(id)
    }
    fn buffer_char_count(&self, id: BufferId) -> Option<usize> {
        self.inner.borrow_mut().buffers().buffer_char_count(id)
    }
    fn buffer_lines(
        &self,
        id: BufferId,
        range: ExclusiveRange<ContentLine>,
    ) -> Option<Vec<String>> {
        self.inner.borrow_mut().buffers().buffer_lines(id, range)
    }
    fn line_to_char_offset(&self, id: BufferId, line: ContentLine) -> Option<usize> {
        self.inner
            .borrow_mut()
            .buffers()
            .line_to_char_offset(id, line)
    }
    fn viewport_range(&mut self, pane: ShownHandle) -> Result<ExclusiveRange<ContentLine>, String> {
        self.inner.get_mut().buffers().viewport_range(pane)
    }
}

impl EventHost for ReadOnlyHost<'_> {
    fn known_event_names(&self) -> &'static [&'static str] {
        self.inner.borrow_mut().events().known_event_names()
    }
    fn event_shape(&self, name: &str) -> Option<EventShape> {
        self.inner.borrow_mut().events().event_shape(name)
    }
    fn finish_hold(&mut self, _hold: HostToken) {
        self.refuse("done");
    }
}
