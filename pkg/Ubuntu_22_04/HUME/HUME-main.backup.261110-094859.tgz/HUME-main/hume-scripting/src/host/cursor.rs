//! Live cursor/selection reads.

use hume_core::BufferId;
use hume_rope::line::ContentLine;

use super::ShownHandle;

/// One selection as a script reads it: raw 0-indexed char offsets.
///
/// `anchor` and `head` are the cluster starts the selection is drawn between,
/// direction preserved (`anchor > head` when backward). `start` is the first
/// covered char and `end` the exclusive end of the last covered cluster, so
/// `start..end` is what the selection covers, whatever the length of
/// its clusters.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SelectionInfo {
    pub anchor: usize,
    pub head: usize,
    pub start: usize,
    pub end: usize,
    pub primary: bool,
}

/// Live cursor/selection reads, accessed through [`EditorHost::cursor`](super::EditorHost::cursor).
pub trait CursorHost {
    /// `(buffer-cursor-line pane)`: 0-indexed content line of the primary
    /// cursor in `pane`'s pane.
    fn buffer_cursor_line(&self, pane: ShownHandle) -> Result<ContentLine, String>;

    /// `(buffer-selections pane)`: every selection in `pane`'s pane, as
    /// [`SelectionInfo`]s sorted by selection start, with exactly one flagged
    /// primary.
    fn buffer_selections(&self, pane: ShownHandle) -> Result<Vec<SelectionInfo>, String>;

    /// `(char-offset->line bid idx)`: 0-indexed content line containing the
    /// 0-indexed char offset `idx` in `bid`'s live text; `len_chars()`, the
    /// offset after the final line break, is on the last content line. Pure
    /// text math, not selection/pane state: `bid` need not be shown in any
    /// pane.
    ///
    /// `Err` when `idx` is past `len_chars()`: Scheme computed it for a live
    /// buffer, so a value out of range is a caller bug to raise, not a
    /// question to answer `#f` to. `bid`'s liveness is checked at
    /// argument-resolve time (`args::LiveBuffer`), so a stale `bid` never
    /// reaches here.
    fn char_offset_to_line(&self, bid: BufferId, idx: usize) -> Result<ContentLine, String>;

    /// `(symbol-under-cursor pane)`: the word at the primary cursor head in
    /// `pane`'s pane, `""` on whitespace/punctuation.
    fn symbol_under_cursor(&self, pane: ShownHandle) -> Result<String, String>;

    /// `(selections-linewise? pane)`: every *unambiguous* selection in
    /// `pane`'s pane is linewise (spans whole lines, anchor to trailing
    /// `\n`). A selection collapsed onto a single empty line is ambiguous
    /// (see `SelectionView::linewise_classification`) and carries
    /// no vote either way. `false` when every selection is ambiguous,
    /// matching an ordinary collapsed cursor's default.
    ///
    /// Paired with [`Self::selections_charwise`] to express `:format-source`'s
    /// three-way verdict (all linewise / none linewise / mixed) as two
    /// booleans rather than a symbol on `lsp-linewise-ranges-params`'s wire
    /// params. Every other `lsp-*-params` builtin returns a hash forwarded
    /// to `lsp-request!` verbatim or with a *protocol* key inserted, and a
    /// non-protocol verdict key would break that. `(false, false)` from the
    /// pair means *mixed*; an all-ambiguous set answers `(false, true)`,
    /// indistinguishable from all-charwise, which is the
    /// default it's meant to take.
    fn selections_linewise(&self, pane: ShownHandle) -> Result<bool, String>;

    /// `(selections-charwise? pane)`: no *unambiguous* selection in
    /// `pane`'s pane is linewise. `true` when every selection is
    /// ambiguous (the complementary default to [`Self::selections_linewise`]'s
    /// `false` in that same case). See [`Self::selections_linewise`] for why
    /// this is a second predicate rather than a verdict field elsewhere.
    fn selections_charwise(&self, pane: ShownHandle) -> Result<bool, String>;
}
