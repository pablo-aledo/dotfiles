use super::*;
use crate::test_support::SteelCtxTestHarness;
use hume_core::Severity;

// ── Mode discriminant ─────────────────────────────────────────────────────

/// `new_init` sets `session = EvalSession::Init`.
#[test]
fn new_init_has_init_session() {
    let mut h = SteelCtxTestHarness::new();
    let ctx = h.ctx_init();
    assert_eq!(
        ctx.session,
        EvalSession::Init,
        "new_init must set session = EvalSession::Init"
    );
}

/// `new_command` sets `session = EvalSession::Runtime`.
#[test]
fn new_command_has_runtime_session() {
    let mut h = SteelCtxTestHarness::new();
    let ctx = h.ctx();
    assert_eq!(
        ctx.session,
        EvalSession::Runtime,
        "new_command must set session = EvalSession::Runtime"
    );
}

/// `new_activation` sets `session = EvalSession::Runtime` (same as command mode).
///
/// Runtime-activated plugin bodies use `new_activation` so `(call! …)` is
/// allowed inside them.  With `EvalSession::Init`, plugin bodies would be
/// blocked from calling native commands.
#[test]
fn new_activation_has_runtime_session() {
    let mut h = SteelCtxTestHarness::new();
    let ctx = h.ctx_activation();
    assert_eq!(
        ctx.session,
        EvalSession::Runtime,
        "new_activation must set session = EvalSession::Runtime"
    );
}

/// `mode()` derives the correct `EvalMode` for all four `(session,
/// attribution)` states. The expected variants come from the truth table in
/// `EvalMode`'s doc.
#[test]
fn mode_derives_from_session_and_attribution() {
    use crate::attribution::PluginId;

    let mut h = SteelCtxTestHarness::new();
    assert_eq!(h.ctx_init().mode(), EvalMode::Init);
    assert_eq!(h.ctx().mode(), EvalMode::Command);

    h.state
        .attribution
        .push_body(EntryId::main(PluginId::parse("core:test-plugin").unwrap()));
    assert_eq!(h.ctx_init().mode(), EvalMode::PluginLoad);
    assert_eq!(h.ctx_activation().mode(), EvalMode::PluginActivation);
}

/// A registration ranks as the plugin's inside a plugin body, whoever made
/// the body run, and otherwise as made on the session's behalf, inside a
/// `call!`ed command too.
#[test]
fn registration_origin_follows_the_body_or_the_sessions_behalf() {
    use crate::attribution::{Owner, PluginId, Provenance};
    use hume_core::ConfigOrigin;

    let plugin = EntryId::main(PluginId::parse("core:test-plugin").unwrap());
    let plugin_owner = || Rc::new(Owner::Plugin(plugin.clone()));
    let mut h = SteelCtxTestHarness::new();

    assert_eq!(h.ctx_init().registration_origin(), ConfigOrigin::User);
    assert_eq!(
        h.ctx_as(Provenance::own(Owner::Core)).registration_origin(),
        ConfigOrigin::Bundled
    );
    assert_eq!(
        h.ctx_as(Provenance::own(Owner::Plugin(plugin.clone())))
            .registration_origin(),
        ConfigOrigin::Plugin
    );
    assert_eq!(
        h.ctx_as(Provenance::invoked_by_user(plugin_owner()))
            .registration_origin(),
        ConfigOrigin::User
    );

    h.state.attribution.enter_call(plugin_owner());
    assert_eq!(
        h.ctx_as(Provenance::invoked_by_user(plugin_owner()))
            .registration_origin(),
        ConfigOrigin::User
    );

    h.state.attribution.push_body(plugin.clone());
    h.state.attribution.enter_call(Rc::new(Owner::User));
    assert_eq!(
        h.ctx_as(Provenance::invoked_by_user(plugin_owner()))
            .registration_origin(),
        ConfigOrigin::Plugin
    );
}

// ── log helper ────────────────────────────────────────────────────────────

/// `ctx.log(…)` appends to `pending_messages`.
#[test]
fn log_pushes_to_pending_messages() {
    let mut h = SteelCtxTestHarness::new();
    {
        let mut ctx = h.ctx_init();
        ctx.log(Severity::Info, "hello".into());
        ctx.log(Severity::Warning, "world".into());
    }
    assert_eq!(h.state.pending_messages.len(), 2);
    assert_eq!(h.state.pending_messages[0].0, Severity::Info);
    assert_eq!(h.state.pending_messages[1].0, Severity::Warning);
}

// ── Effect commit/rollback ────────────────────────────────────────────────

/// `pop_effect_marks(true)` marks every entry pushed since the mark as
/// committed, and leaves anything pushed before the mark untouched.
///
/// Committing all of `effects` instead of only `[mark..]` would also commit
/// the pre-mark entry.
#[test]
fn pop_effect_marks_success_commits_marked_range() {
    let mut h = SteelCtxTestHarness::new();
    {
        let mut ctx = h.ctx();
        ctx.push_effect(Effect::GrammarSweep("before".into()));
        ctx.mark_effects();
        ctx.push_effect(Effect::GrammarSweep("after".into()));
        ctx.pop_effect_marks(true);
    }
    assert!(
        !h.state.effects[0].committed,
        "entry pushed before the mark must stay uncommitted"
    );
    assert!(
        h.state.effects[1].committed,
        "entry pushed after the mark must be committed on success"
    );
}

/// Nested marks: A1 (no mark), mark B, B1, mark C, C1/C2, pop(true) commits
/// C1/C2, B2, pop(false). B's own entries (B1, B2) are dropped but C1/C2
/// (already committed by the nested activation that finished inside B)
/// survive B's failure, in their original order, alongside untouched A1.
///
/// A plain `self.effects.truncate(mark)` in `pop_effect_marks`'s failure
/// branch would drop C1/C2 along with B1/B2, leaving only `["a1"]`.
#[test]
fn pop_effect_marks_failure_keeps_committed_entries_in_order() {
    let mut h = SteelCtxTestHarness::new();
    {
        let mut ctx = h.ctx();
        ctx.push_effect(Effect::GrammarSweep("a1".into()));
        ctx.mark_effects(); // B begins
        ctx.push_effect(Effect::GrammarSweep("b1".into()));
        ctx.mark_effects(); // C begins, nested inside B
        ctx.push_effect(Effect::GrammarSweep("c1".into()));
        ctx.push_effect(Effect::GrammarSweep("c2".into()));
        ctx.pop_effect_marks(true); // C succeeds: commits c1, c2
        ctx.push_effect(Effect::GrammarSweep("b2".into()));
        ctx.pop_effect_marks(false); // B fails: drops b1/b2, keeps c1/c2
    }
    let names: Vec<&str> = h
        .state
        .effects
        .iter()
        .map(|e| match &e.effect {
            Effect::GrammarSweep(name) => name.as_str(),
            other => panic!("expected GrammarSweep, got {other:?}"),
        })
        .collect();
    assert_eq!(
        names,
        vec!["a1", "c1", "c2"],
        "b1/b2 must be dropped, c1/c2 kept in original order, a1 untouched"
    );
    assert!(!h.state.effects[0].committed, "a1 was never inside a mark");
    assert!(
        h.state.effects[1].committed && h.state.effects[2].committed,
        "c1/c2 stay committed"
    );
}
