//! The editor interface exposed to scripting builtins, as a capability
//! directory (`EditorHost`) whose domain methods live one-per-file below,
//! one module per accessor. Each child is private and re-exported here so
//! every `hume_scripting::host::X` path a caller uses keeps resolving
//! unchanged, and no second public path (`host::ui::UiHost`) is minted
//! alongside it.

// ── Capability modules ────────────────────────────────────────────────────────
mod async_process;
mod buffers;
mod commands;
mod completion;
mod cursor;
mod decorations;
mod diff;
mod edits;
mod events;
mod language;
mod lsp;
mod output;
mod registers;
mod settings;
mod timers;
mod token;
mod ui;

pub use crate::builtins::args::pane::{FocusedHandle, ShownHandle};
pub(crate) use async_process::process_result;
pub use async_process::{AsyncProcessHost, JobHandle, async_callback_args, names_callback_args};
pub use buffers::{BufferHost, StoredLanguage, UndoNode};
pub(crate) use commands::check_name_free;
pub use commands::{CommandHolder, CommandHost, CommandKind, NativeCall, check_lazy_claim};
pub use completion::{
    CompletionHost, CompletionSourceTarget, EmittedWord, PendingCompletionSource, PendingTarget,
};
pub use cursor::{CursorHost, SelectionInfo};
pub use decorations::{
    DecorationHost, DiagnosticCounts, DiagnosticEntry, DiagnosticRange, MarkedLines, SetError,
    each_entry,
};
pub use diff::DiffHost;
pub use edits::{CharTextEdit, EditHost, WireTextEdit};
pub use events::{EventHost, EventShape, EventSubject};
pub use language::LanguageHost;
pub use lsp::{
    LocationPlace, LspHost, Place, PlaceCol, PositionParams, RangeParams, RangesParams,
    SupersedeKey, SupersedeKeys,
};
pub use output::{ClaimRefused, OutputHost};
pub use registers::RegisterHost;
pub use settings::{SettingsHost, option_value_to_steel};
pub use timers::{TimerHandle, TimerHost};
pub use token::{TrackedFate, TrackedHold, token_to_steel};
pub use ui::{
    DrawerItems, LivePickerOpts, PickerBinding, PickerCommonOpts, PickerFeedMode, PickerOpts,
    PickerSourceOpts, PickerStep, PopupKind, RowDisplay, RowSpanScopes, UiHost, display_item,
};

/// Which keymap a bind or unbind changes: the global one, or the keymap a
/// `#:keymap` name names.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum KeymapTarget {
    Global,
    Named(String),
}

/// The editor interface exposed to scripting builtins during a Steel eval.
///
/// A capability directory: domain methods live on the capability traits in
/// this module (`BufferHost`, `UiHost`, `LspHost`, ...), reached through this
/// trait's accessors. Implemented by `EditorHostImpl<'a>` in the editor crate
/// and by mocks in tests. The trait exists because `hume-editor` depends on
/// `hume-scripting`, so builtins can't reach `EditorState` directly.
///
/// All methods take and return only `'static` types, since `SteelCtx<'static>`
/// is the projection Steel's `with_mut_reference` requires. Focused
/// buffer/pane ids are passed to `call_steel_cmd`/`fire_hook` instead, so a
/// builtin sees the pre-command snapshot even after `switch-to-buffer!`.
///
/// Six accessors are required (`buffers`, `settings`, `language`, `commands`,
/// `cursor`, `events`); the rest return `None` when the host lacks the
/// capability. A mutating builtin maps `None` to the "not supported by this
/// host" error (`errors::require_cap`) rather than reporting a write that never
/// happened; only already-idempotent calls such as `cancel-timer!` no-op.
/// Command-mode-only and init-only builtins are gated per registration by
/// `errors::require_cmd` and `errors::require_config`.
pub trait EditorHost {
    // ── Optional capability accessors ────────────────────────────────────────
    /// Cursor-anchored popup / selection menu / bottom drawer / minibuffer
    /// prompt, or `None` for hosts with no UI surface to drive (test stubs).
    fn ui(&mut self) -> Option<&mut dyn UiHost> {
        None
    }
    /// LSP-driven text edits, workspace edits, and go-to-location, or `None`
    /// for hosts with no editable buffers/panes to route them to.
    fn edits(&mut self) -> Option<&mut dyn EditHost> {
        None
    }
    /// Completion session orchestration, or `None` for hosts with no
    /// completion popup to drive.
    fn completions(&mut self) -> Option<&mut dyn CompletionHost> {
        None
    }
    /// Inlay hints / signs / virtual lines / extra highlights / inline
    /// diagnostics / diagnostic pull, or `None` for hosts with no decoration
    /// stores to write into.
    fn decorations(&mut self) -> Option<&mut dyn DecorationHost> {
        None
    }
    /// LSP server introspection (capabilities, status, attachment,
    /// registration, position/range params), or `None` for hosts with no LSP
    /// bridge.
    fn lsp(&mut self) -> Option<&mut dyn LspHost> {
        None
    }
    /// Register content reads/writes (`read-register`/`write-register!`),
    /// or `None` for hosts with no register store (test stubs).
    fn registers(&mut self) -> Option<&mut dyn RegisterHost> {
        None
    }
    /// `(after! …)` / `(cancel-timer! …)` scheduling, or `None` for hosts with
    /// no timer wheel (test stubs).
    fn timers(&mut self) -> Option<&mut dyn TimerHost> {
        None
    }
    /// `(spawn-async! …)` / `(cancel-async! …)`, or `None` for hosts with no
    /// job registry to spawn onto (test stubs).
    fn async_process(&mut self) -> Option<&mut dyn AsyncProcessHost> {
        None
    }
    /// `(diff-buffer-lines …)` / `(buffer-revision-diff …)`, or `None` for
    /// hosts with no buffers to diff (test stubs).
    fn diff(&mut self) -> Option<&mut dyn DiffHost> {
        None
    }
    /// Terminal-safety state around `#:inline-output` commands, or `None` for
    /// hosts with no terminal state (test stubs). A script on such a host
    /// cannot claim the terminal.
    fn output(&mut self) -> Option<&mut dyn OutputHost> {
        None
    }
    /// Live cursor/selection reads for an explicit `bid`. Required: every
    /// host has some notion (even if only "nothing is shown anywhere") of a
    /// buffer's cursor.
    fn cursor(&mut self) -> &mut dyn CursorHost;
    /// Command registry queries, synchronous native dispatch, and
    /// registration. Required: every host has some notion of its command
    /// set, even if empty.
    fn commands(&mut self) -> &mut dyn CommandHost;
    /// Grammar attachment and trigger-char registration. Required: every
    /// host has some notion (even if empty) of its language/grammar set.
    fn language(&mut self) -> &mut dyn LanguageHost;
    /// Global settings, statusline config, and the Steel eval budget.
    /// Required: every host has some notion (even if minimal defaults) of
    /// its settings.
    fn settings(&mut self) -> &mut dyn SettingsHost;
    /// Buffer/pane enumeration, reads, lifecycle, and viewport geometry.
    /// Required: every host has some notion (even if empty) of open buffers.
    fn buffers(&mut self) -> &mut dyn BufferHost;
    /// Event-name introspection. Required: every host has some notion (even
    /// if empty) of which event names it can raise.
    fn events(&mut self) -> &mut dyn EventHost;
    /// Asked before `plugin` starts activating. Activation registers
    /// commands, hooks and keys in the editor, so a host that refuses editor
    /// writes refuses it here, before the plugin's state changes. Required,
    /// so a restricted host decides rather than inherits "allowed".
    fn permit_plugin_activation(
        &mut self,
        plugin: &crate::attribution::EntryId,
    ) -> Result<(), String>;
}
