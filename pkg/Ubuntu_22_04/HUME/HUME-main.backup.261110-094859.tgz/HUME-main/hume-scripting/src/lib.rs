//! Steel scripting integration for HUME.
//!
//! [`ScriptingHost`] owns the Steel [`Engine`] and runs on the main event-loop
//! thread: the Engine is `!Send`, and edit commands are synchronous hot-path
//! operations where an IPC round-trip per keystroke would cost more.
//!
//! ## Plugin loading
//! - `load-plugin!`: init.scm/`:reload-config` only. A plugin with a
//!   `manifest.scm` is lazy: the manifest's `declare-plugin!` calls record the
//!   entries. One without runs `plugin.scm` at once via
//!   `%activate-plugin-inline!`.
//! - `declare-plugin!`: records `Declared` plus activation entries in
//!   `LazyRegistry`, from a manifest or from init.scm (a `./file.scm` beside
//!   init.scm, or an installed plugin with custom triggers). The first entry
//!   exercised runs the body, marks it `Loaded`, and drops all of that
//!   entry's triggers.
//! - States: `Declared -> Loading -> Loaded | Failed`. `Loading` guards
//!   re-entrant cycles; `Failed` doesn't retry until `:reload-config`.
//! - `#:config` on `load-plugin!` is a symbol-keyed hash of per-plugin data,
//!   checked for that shape and read back via `(plugin-config)`. Both forms record an installed plugin's name in its
//!   plugin record up front for PLUM; a local file is not listed.

#![deny(rustdoc::broken_intra_doc_links)]
#![deny(rustdoc::private_intra_doc_links)]

// ── Public submodules ─────────────────────────────────────────────────────────
pub mod attribution;
pub(crate) mod builtins;
pub mod command_name;
pub(crate) mod hooks;
pub mod host;
pub mod json;
pub(crate) mod keys;
pub(crate) mod lazy;
mod log;
mod plugin_record;
// ── Private implementation details ────────────────────────────────────────────
mod command_procs;
mod context;
mod eval;
#[cfg(test)]
mod null_host;
#[cfg(any(test, feature = "test-util"))]
pub mod pane_probes;
mod read_only_host;
mod rooted;
#[cfg(any(test, feature = "test-util"))]
mod test_scm;
#[cfg(test)]
mod test_support;
#[cfg(any(test, feature = "test-util"))]
pub use test_scm::eager_load_scm;
mod types;
mod visibility;
pub use visibility::{Audience, BufferVisibility};
pub(crate) mod watchdog;

// ── Public API re-exports ─────────────────────────────────────────────────────
// Types the editor and editor tests use directly.
pub use builtins::args::line_range_value;
pub use builtins::args::symbol_hash;
pub use builtins::commands::count_to_steel;
pub use builtins::diff::hunk_list_value;
pub use builtins::ids::{DocPos, DocRange, DocUri, ServerRef, SteelPane};
pub use command_procs::{CommandProc, MappableProc, TypedProc};
pub use eval::HeldHandlers;
pub use host::{PendingCompletionSource, PendingTarget};
pub use keys::parse_key_stream;
pub use lazy::PluginStatus;
pub use rooted::{Callback, Rooted, SteelCall};
pub use types::{
    CapabilityQuery, DocSpan, Effect, EvalError, GrammarReg, LspErrKind, LspRoute,
    LspServerStatusEntry, LspServerTarget, Params, PendingLanguageReg, PendingLspNotify,
    PendingLspRequest, PendingLspServerOp, PendingLspServerReg, RequestMode, RequestParams,
    RouteSpec, SteelCmdBody, SteelCmdDef, SteelTypedCmdBody, SteelTypedCmdDef, TriggerScope,
    VirtualLineSpec, WhenUnavailable, lsp_err_value,
};
// Test-only external visibility: the editor's own test suite arms/cancels a
// real watchdog directly (hume-editor/tests/scripting.rs) rather than
// through a ScriptingHost eval entry point. Outside test/test-util builds,
// `EvalWatchdog` is still needed unqualified below (the `watchdog` field),
// just not re-exported past this crate.
#[cfg(any(test, feature = "test-util"))]
pub use watchdog::EvalWatchdog;
#[cfg(not(any(test, feature = "test-util")))]
use watchdog::EvalWatchdog;
// Test-only external visibility: every test crate that builds `.scm` source
// by interpolating a real filesystem path (`open-buffer!`, `picker!`, …)
// needs this same Windows-safe escaping. See `steel_path_literal`'s own doc
// comment for why it isn't hand-rolled per call site.
#[cfg(any(test, feature = "test-util"))]
pub use builtins::plugins::paths::steel_path_literal;

// ── Internal re-exports (within-crate use) ────────────────────────────────────
pub(crate) use context::SteelCtx;

/// Steel global name under which the live [`SteelCtx`] reference is visible to
/// builtins during an eval (injected by `run_steel_session`, reset to `#void`
/// after).
pub(crate) const HUME_CTX: &str = "*hume.ctx*";

// ── Internal imports ──────────────────────────────────────────────────────────

use std::path::Path;

use steel::steel_vm::engine::Engine;

use attribution::AttributionStack;
use hooks::HookRegistry;
use hume_core::Severity;
use lazy::{LazyRegistry, PluginState};

/// The persistent registry fields bundled as a unit so they can be
/// borrowed as a single `&mut ScriptingRegistries`, disjoint from the
/// Steel VM (`steel`) and the rest of `ScriptingHost`.
#[derive(Default)]
pub(crate) struct ScriptingRegistries {
    /// Persistent hook registry: handlers registered by `(register-hook! …)`.
    pub(crate) hooks: HookRegistry,
    /// Lazy plugin registry: populated by `%declare-plugin!` during init;
    /// activation maps consulted by command dispatch, event firing, and language-set.
    pub(crate) lazy_registry: LazyRegistry,
    /// Plugin-level state of every plugin named by `(load-plugin! …)` or
    /// `(declare-plugin! …)`, including plugins absent on disk.
    pub(crate) plugin_records: plugin_record::PluginRecords,
}

/// Borrows of [`HostState`] fields needed to populate [`SteelCtx`].
///
/// Built by [`HostState::split`] and passed to [`SteelCtx::new_init`],
/// [`SteelCtx::new_activation`] or [`SteelCtx::new_command`].
pub(crate) struct HostBundle<'a> {
    pub(crate) registries: &'a mut ScriptingRegistries,
    attribution: &'a mut AttributionStack,
    pending_messages: &'a mut Vec<(Severity, String)>,
    effects: &'a mut Vec<types::QueuedEffect>,
    dirs: &'a builtins::dirs::ScriptDirs,
    budget: watchdog::BudgetClock<'a>,
}

/// The scripting state that persists across evals, everything a
/// [`SteelCtx`] borrows. Owned by [`ScriptingHost`] beside the Steel engine,
/// and by the scripting crate's test harness beside its host.
pub(crate) struct HostState {
    /// The persistent registries borrowed as a unit into `SteelCtx`.
    pub(crate) registries: ScriptingRegistries,
    /// The frames of attributed code running: plugin bodies and `call!`ed
    /// commands. Empty between sessions.
    attribution: AttributionStack,
    /// Log messages accumulated by `(log! …)` since the last drain.
    /// Drained by the editor via `take_pending_messages()`.
    pending_messages: Vec<(Severity, String)>,
    /// Side effects queued by Steel builtins, in push order. Each eval entry
    /// point (`call_steel_cmd`, `fire_hook`, `run_steel_calls`, `eval_init`,
    /// `activate_plugin_inline`) drains exactly what it pushed back out on
    /// success (`Vec<Effect>`). On error it drains only the entries committed
    /// by a nested successful plugin activation (`QueuedEffect::committed`);
    /// see `take_eval_effects` and `types::EvalError`.
    effects: Vec<types::QueuedEffect>,
    /// Data/runtime directories (raw + display form), computed once at
    /// construction.
    dirs: builtins::dirs::ScriptDirs,
    /// Persistent budget-enforcement thread, re-armed around every eval.
    watchdog: EvalWatchdog,
}

impl HostState {
    fn new(dirs: builtins::dirs::ScriptDirs, watchdog: EvalWatchdog) -> Self {
        Self {
            registries: ScriptingRegistries::default(),
            attribution: AttributionStack::default(),
            pending_messages: Vec::new(),
            effects: Vec::new(),
            dirs,
            watchdog,
        }
    }

    /// Split `self` into the watchdog and the [`HostBundle`] of borrows a
    /// [`SteelCtx`] is built from. The borrows are disjoint fields, so the
    /// caller can hold the watchdog while the bundle is lent out.
    pub(crate) fn split(&mut self) -> (&EvalWatchdog, HostBundle<'_>) {
        let Self {
            registries,
            attribution,
            pending_messages,
            effects,
            dirs,
            watchdog,
        } = self;
        (
            watchdog,
            HostBundle {
                registries,
                attribution,
                pending_messages,
                effects,
                dirs: &*dirs,
                budget: watchdog.clock(),
            },
        )
    }
}

/// The embedded Steel scripting host.
///
/// Owns the Steel `Engine` and all persistent scripting state.  Each eval or
/// command call constructs a `SteelCtx` that borrows the persistent fields
/// directly.
///
/// Constructed once during `Editor::init_scripting()` and held for the
/// lifetime of the process.
pub struct ScriptingHost {
    /// The Scheme VM, always called `steel` (never bare "engine", which refers to the `engine/` crate).
    steel: Engine,
    /// Disjoint from `steel`, so the VM and the state a `SteelCtx` borrows
    /// can be borrowed at once (NLL field-split).
    state: HostState,
}

impl ScriptingHost {
    /// Create a new scripting host with the Steel standard library and all HUME
    /// builtins loaded.
    ///
    /// `dirs` supplies the data and runtime directories builtins expose, so no
    /// builtin reads environment variables on a call.
    ///
    /// `library_wait` is connected to this host's budget, so a grammar
    /// library opened through it does not count against a running script.
    pub fn new(dirs: &hume_platform::dirs::Dirs, library_wait: &hume_core::OsWait) -> Self {
        let dirs = builtins::dirs::ScriptDirs::new(dirs);
        let mut steel = Engine::new();
        builtins::register_all(&mut steel);
        let watchdog = EvalWatchdog::new();
        watchdog.connect(library_wait);
        Self {
            steel,
            state: HostState::new(dirs, watchdog),
        }
    }

    /// [`Self::new`] with a `library_wait` nothing else holds.
    #[cfg(any(test, feature = "test-util"))]
    pub fn for_testing(dirs: &hume_platform::dirs::Dirs) -> Self {
        Self::new(dirs, &hume_core::OsWait::default())
    }
}

/// `true` for a name plugin code never calls directly, so
/// [`ScriptingHost::host_global_names`] leaves it out of the generated
/// `steel-language-server` host-globals file:
/// - `%`-prefixed: HUME's private primitives, each wrapped by a public name
///   (`%register-lsp-server!` by `register-lsp-server!`).
/// - `*earmuffed*`: Scheme's convention for internal state (`*hume.ctx*`).
/// - `hm.`-prefixed: `steel/meta`, aliased by `bootstrap.scm` for HUME's glue.
/// - `#`-prefixed: steel-core's internal markers, including the
///   nondeterministically numbered `###ctx-funcN` builtin wrappers.
/// - `struct:NAME` and `___NAME-options___`: the type descriptor and the
///   options hash steel-core's `struct` macro binds beside every struct.
///   A plugin builds and reads a struct through its constructor, predicate
///   and accessors.
#[cfg(any(test, feature = "test-util"))]
fn is_internal_name(name: &str) -> bool {
    name.starts_with('%')
        || name.starts_with('#')
        || name.starts_with("hm.")
        || (name.starts_with('*') && name.ends_with('*'))
        || name.starts_with("struct:")
        || (name.starts_with("___") && name.ends_with("-options___"))
}

impl ScriptingHost {
    // ── Outward API (clean; no direct field access outside this module) ────────

    /// Pre-register native command names as callable Steel bindings.
    ///
    /// For each name, evaluates `(define name (lambda args (%dispatch-command!
    /// "name" args)))`. This makes bare `(move-left pane)` callable without
    /// `(call! "move-left" pane)`, and variadic, so `(move-down pane 3)` /
    /// `(move-down pane 0)` work too (count `0` = "no count typed", see
    /// `parse_native_args`). `pane` is always the first arg, same as
    /// `%call-native!`'s own contract: this binding is a thin wrapper over
    /// the same dispatcher, not a separate calling convention.
    ///
    /// Calls `%dispatch-command!` directly rather than the public `call!` macro
    /// (which desugars to exactly this): the variadic lambda's args are
    /// already the list `%dispatch-command!` expects, no intermediate
    /// `(list ...)` needed.
    ///
    /// Called from `Editor::init_scripting`, after `ScriptingHost::new` and
    /// before any `eval_init`, so init.scm/plugins can use bare command names
    /// without a `FreeIdentifier` compile error.
    pub fn register_command_names(&mut self, names: &[&str]) {
        use std::fmt::Write;

        if names.is_empty() {
            return;
        }
        // Build one compound source string: one define per command.
        let mut source = String::with_capacity(names.len() * 64);
        for &name in names {
            writeln!(
                source,
                "(define {name} (lambda args (%dispatch-command! \"{name}\" args)))"
            )
            .expect("writing to a String cannot fail");
        }
        self.steel
            .compile_and_run_raw_program(source)
            .expect("command name pre-registration failed: this is a bug");
    }

    /// Runtime directory for core plugins, themes, and docs.
    pub fn runtime_dir(&self) -> Option<&Path> {
        self.state.dirs.runtime_dir.as_deref()
    }

    /// Data directory for user/third-party plugins.
    pub fn data_dir(&self) -> Option<&Path> {
        self.state.dirs.data_dir.as_deref()
    }

    /// A new [`hume_core::OsWait`] connected to this host's budget.
    #[cfg(any(test, feature = "test-util"))]
    pub fn os_wait(&self) -> hume_core::OsWait {
        let wait = hume_core::OsWait::default();
        self.state.watchdog.connect(&wait);
        wait
    }

    /// Every top-level global and macro name HUME's own layers add on top of
    /// a pristine Steel engine, minus HUME's own internal-only names: the
    /// payload for the generated `steel-language-server` host-globals file
    /// (see `runtime/plugins/core/steel-server/lsp-home/hume-globals.scm`'s
    /// generator).
    ///
    /// Diffs against a fresh `Engine::new()` so upstream Steel stdlib names
    /// never appear in the output (the server already knows those from its
    /// own internal engine), then drops anything `is_internal_name` flags:
    /// HUME's own naming conventions for "never called by plugin code",
    /// checked against a full, real-world generated list to confirm no
    /// legitimate public name matches any of them.
    ///
    /// Sorted and deduped for a stable, reviewable diff in the checked-in
    /// generated file.
    ///
    /// Reads two guards on the same `RwLock` sequentially (never held
    /// simultaneously, since `parking_lot`'s `RwLock` is not reentrant): globals
    /// first, then macros, each collected into an owned `Vec` before the
    /// guard drops.
    #[cfg(any(test, feature = "test-util"))]
    pub fn host_global_names(&self) -> Vec<String> {
        let baseline = Engine::new();
        let baseline_globals: rustc_hash::FxHashSet<String> = baseline
            .globals()
            .iter()
            .map(|s| s.resolve().to_string())
            .collect();
        let baseline_macros: rustc_hash::FxHashSet<String> = baseline
            .in_scope_macros()
            .keys()
            .map(|s| s.resolve().to_string())
            .collect();

        let mut names: Vec<String> = {
            let globals = self.steel.globals();
            globals
                .iter()
                .map(|s| s.resolve().to_string())
                .filter(|n| !is_internal_name(n) && !baseline_globals.contains(n))
                .collect()
        };
        names.extend({
            let macros = self.steel.in_scope_macros();
            macros
                .keys()
                .map(|s| s.resolve().to_string())
                .filter(|n| !is_internal_name(n) && !baseline_macros.contains(n))
                .collect::<Vec<_>>()
        });
        names.sort_unstable();
        names.dedup();
        names
    }

    /// Drain all accumulated log messages since the last drain.
    pub fn take_pending_messages(&mut self) -> Vec<(Severity, String)> {
        std::mem::take(&mut self.state.pending_messages)
    }

    /// Returns `true` if at least one handler for `name` fires for an event
    /// carrying `key` delivered to `audience`: an unkeyed handler fires for
    /// every key, a keyed one only when `key` is among its keys.
    pub fn has_hook_handlers(&self, name: &str, key: Option<&str>, audience: Audience<'_>) -> bool {
        self.state.registries.hooks.has_match(name, key, audience)
    }

    /// Every entry declared with `#:languages`, with its list, in
    /// declaration order.
    pub fn entries_with_languages(&self) -> Vec<(attribution::EntryId, std::rc::Rc<[String]>)> {
        self.state.registries.lazy_registry.languages.clone()
    }

    /// Plugin ids that should be activated when the event named `name` fires:
    /// the `Declared` entries declared with it.
    pub fn activation_event_plugins(&self, name: &str) -> Vec<attribution::EntryId> {
        self.state.registries.lazy_registry.event_plugins(name)
    }

    /// Plugin ids that should be activated when `language` is set on a buffer:
    /// the `Declared` entries listing `language`, then those listing the
    /// wildcard `"*"`, each once.
    pub fn activation_language_plugins(&self, language: &str) -> Vec<attribution::EntryId> {
        self.state
            .registries
            .lazy_registry
            .language_plugins(language)
    }

    /// Status of a plugin in the lazy registry.
    pub fn plugin_status(&self, id: &attribution::EntryId) -> Option<PluginStatus> {
        self.state
            .registries
            .lazy_registry
            .plugins
            .get(id)
            .map(PluginState::status)
    }

    /// Returns `true` if any plugin in the registry has transitioned to `Loaded`.
    #[cfg(any(test, feature = "test-util"))]
    pub fn has_any_loaded_plugin(&self) -> bool {
        self.state
            .registries
            .lazy_registry
            .plugins
            .values()
            .any(|s| matches!(s, PluginState::Loaded))
    }

    /// All plugin names ever passed to `(load-plugin! …)` or `(declare-plugin! …)`.
    #[cfg(any(test, feature = "test-util"))]
    pub fn declared_plugins(&self) -> Vec<String> {
        self.state.registries.plugin_records.plum_names().collect()
    }

    /// Format a human-readable plugin status table for `:plugin-status`.
    ///
    /// `lazy_cmds` is the editor's current `Lazy`-stub list (`name`, owning
    /// plugin, `is_typed`). This crate doesn't track pending command
    /// activations itself, so the caller supplies its live registry snapshot.
    pub fn lazy_status_string(&self, lazy_cmds: &[(String, attribution::EntryId, bool)]) -> String {
        self.state.registries.lazy_registry.format_status(
            self.state.registries.plugin_records.entryless_rows(),
            lazy_cmds,
        )
    }

    /// Peek at pending messages without draining.  Only for test assertions.
    #[cfg(any(test, feature = "test-util"))]
    pub fn peek_pending_messages(&self) -> &[(Severity, String)] {
        &self.state.pending_messages
    }

    /// Peek at the effect log without draining.  Only for test assertions:
    /// production code always goes through an eval entry point's own
    /// atomic drain (`take_eval_effects`).
    #[cfg(any(test, feature = "test-util"))]
    pub fn effects_for_test(&self) -> Vec<&Effect> {
        self.state.effects.iter().map(|e| &e.effect).collect()
    }

    /// How many attribution frames are open: bodies and `call!` frames.
    #[cfg(test)]
    pub(crate) fn attribution_depth_for_test(&self) -> usize {
        self.state.attribution.len()
    }

    /// Push a fake plugin body onto the attribution stack.
    #[cfg(test)]
    pub(crate) fn push_plugin_for_test(&mut self, id: attribution::EntryId) {
        self.state.attribution.push_body(id);
    }
}

#[cfg(any(test, feature = "test-util"))]
impl ScriptingHost {
    /// Shared tail for [`eval_source`](Self::eval_source) and
    /// [`eval_source_watchdog`](Self::eval_source_watchdog): delegates to
    /// `eval_source_raw` as the user's, at the given budget.
    fn eval_source_with_budget(
        &mut self,
        source: &str,
        budget_ms: u64,
        host: &mut dyn host::EditorHost,
    ) -> Result<Vec<Effect>, String> {
        self.eval_source_raw(source.to_owned(), attribution::Owner::User, budget_ms, host)
            .map_err(|e| e.message)
    }

    /// Evaluate a Steel source string directly, without a file.
    ///
    /// Convenience wrapper for testing, at the default 10-second init budget
    /// (harmless for normal tests that complete quickly). Returns the
    /// effects the eval queued, in emission order, same contract as
    /// `eval_init`, so a test can assert on what a builtin marshalled across
    /// the boundary.
    pub fn eval_source(
        &mut self,
        source: &str,
        host: &mut dyn host::EditorHost,
    ) -> Result<Vec<Effect>, String> {
        self.eval_source_with_budget(source, 10_000, host)
    }

    /// Evaluates `source` and returns its last value, under
    /// `read_only_call`'s read-only rules.
    #[cfg(any(test, feature = "test-util"))]
    pub fn eval_source_for_value(
        &mut self,
        source: &str,
        host: &mut dyn host::EditorHost,
    ) -> Result<steel::rvals::SteelVal, String> {
        let source = source.to_owned();
        let base = attribution::Provenance::own(attribution::Owner::User);
        self.read_only_call(host, base, |steel| {
            steel
                .compile_and_run_raw_program(source)?
                .pop()
                .ok_or_else(|| builtins::errors::generic_err("the source produced no value"))
        })
    }

    /// Like [`eval_source`](Self::eval_source) but arms a real
    /// [`EvalWatchdog`] with the given budget, for tests that need the
    /// watchdog to fire.
    pub fn eval_source_watchdog(
        &mut self,
        source: &str,
        budget: std::time::Duration,
        host: &mut dyn host::EditorHost,
    ) -> Result<(), String> {
        self.eval_source_with_budget(source, budget.as_millis() as u64, host)
            .map(|_| ())
    }
}

/// Pins the assumption the full-trust plugin model rests on: Steel's
/// `steel/process`/`steel/filesystem`/`steel/ports` globals are reachable
/// from plugin code with no `require-builtin` (they ride in via `steel/base`,
/// required by the auto-loaded prelude). PLUM depends on this directly; a
/// steel-core upgrade that changes it must fail these tests before it
/// silently breaks every core plugin.
#[cfg(test)]
mod tests;
