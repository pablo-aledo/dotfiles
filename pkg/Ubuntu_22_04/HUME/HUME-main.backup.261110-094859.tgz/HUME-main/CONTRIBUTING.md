# Contributing to HUME

HUME is a curiosity-driven project. That shapes what contributions fit:

- **Bug reports are always welcome.** Open one with the [bug report form](https://github.com/cvlmtg/HUME/issues/new?template=bug_report.yml). Include your OS, terminal emulator, HUME version (`hume --version`), and a minimal config plus the shortest key sequence that reproduces the problem.
- **Small, focused fixes** can go straight to a pull request.
- **Plugins and configuration** are written in Steel, not Rust. If your idea can live in
  `runtime/scheme/`, that is the better place for it.
- **AI-assisted contributions are welcome.** HUME is itself built with AI agents, so a
  patch, pull request or bug report made with one is fine. It meets the same bar as any
  other: the invariants, tests and code standards below apply unchanged, and you answer
  for every line of it. Point your agent at `CLAUDE.md`, which holds the rules it needs.

Everyone taking part follows the [Code of Conduct](CODE_OF_CONDUCT.md). By contributing you agree that your work is licensed under the [MIT License](LICENSE).

## Getting set up

Prerequisites:

| Need | Why |
|---|---|
| Rust, current stable | The workspace is edition 2024 and uses let chains, so it needs 1.88 or newer. Install via [rustup](https://rustup.rs). |
| A C compiler | The tree-sitter library HUME links is C. On Windows, MSVC build tools. |
| Node + npm | Builds the manual and runs the theme editor's own tests. |
| Bash | The scripts in `scripts/` are bash. On Windows, use Git Bash or WSL. |

Build and run:

```sh
cargo build
cargo run -- README.md
```

Run from the workspace root — HUME finds its bundled `runtime/` relative to the current
directory in a dev build. From anywhere else, point `HUME_RUNTIME` at `runtime/`.

Orientation: `docs/CRATES.md` maps the workspace crates, what each owns, and the dependency edges between them. `docs/ROADMAP.md` tracks open questions. `docs/LEARNING.md` explains the concepts behind the editor.

## Where changes land

`main` is the trunk and the only long-lived branch — branch off it, open the pull request against it. Releases are annotated tags on `main`.

Maintenance branches for older release lines (`0.10.x`) are cut from a tag on demand; don't target one directly. A fix for a bug that also affects an older release still goes to `main` first, and gets cherry-picked back from there after it lands. The exception is a bug that only exists on the older line — where a refactor has already removed it from `main`, there is nothing to fix forward, and the fix is committed on the maintenance branch directly. Open an issue before assuming that is the case.

## Pull requests

- One logical change per pull request. A refactor bundled with a behaviour change is two pull requests.
- Rebase on `main` rather than merging it in. Pull requests are squash-merged, so the final history stays linear and a later cherry-pick is one commit.
- CI runs `cargo fmt --all -- --check` once, then build, the full test suite, doctests, and the theme editor's npm tests on Linux, macOS, and Windows, plus a Linux-only check that the theme editor's committed bundle matches a fresh build. All of it must be green.
- Draft pull requests are fine for work in progress; mark them ready when CI is green.

### Verification before you push

In this order, once:

```sh
cargo fmt
scripts/test-all.sh
```

`scripts/test-all.sh` is the whole gate — it reproduces the CI job exactly. It fetches
the tree-sitter grammar fixtures the suite requires before running the tests, so it
needs network access; a bare `cargo test` panics naming the fixture until this has
been run at least once. The first run downloads the grammars from the pinned
[treesitter.hume](https://github.com/cvlmtg/treesitter.hume) release into
`tests/fixtures/grammars/`; later runs reuse them. To work offline or on a platform
with no release, build the grammars with that repo's `hume-grammar-build build --out <dir>`
and run `scripts/fetch-test-grammars.sh <dir>`. The suite also
includes a handful of live network e2e tests (real grammar installs against GitHub),
so a full run always touches the network.

While iterating on one failure, narrow runs are the right tool:

```sh
cargo test -p hume-editor <filter>
```

## Commit messages

[Conventional Commits](https://www.conventionalcommits.org), imperative mood, no trailing period:

```
fix(motion): stop copy-selection from merging into itself on a multi-line selection
refactor(hume-rope): consolidate the display-width helpers
docs(manual): document the trigger-timing rule for keymap plugins
```

Types in use: `feat`, `fix`, `refactor`, `perf`, `docs`, `test`, `style`, `chore`. The scope is optional and is either a crate name (`hume-editor`, `hume-rope`) or a subsystem (`motion`, `decorations`, `lsp`, `scripting`, `runtime`, `render`, `user-manual`).

The subject says what changed; the body says **why**. If the change is not obvious from the diff, the body is not optional.

## Code standards

Read `CLAUDE.md` before your first non-trivial change. Its two invariant sections are the canonical architecture rules for this codebase, not agent-only advice — they cover the selection model, grapheme-cluster boundaries, the ropey-vs-content line-count domains, display-column math, and line/buffer columns. Getting one of them wrong produces bugs that are expensive to retrofit out.

Beyond those:

- **Idiomatic Rust.** Pattern matching, iterators, and the type system over runtime checks. `Result` and `Option` — no `.unwrap()` in non-test code (`clippy::unwrap_used` is denied in CI, tests exempt), and no `unsafe` except for FFI with no safe alternative (loading a tree-sitter grammar, Windows process control), each block with a `// SAFETY:` comment.
- **An invariant is enforced by the strongest tool that fits — types, then clippy, then a lint — tried in that order.**
  1. **Types, when the mistake can be made to not compile.** Raw grapheme stepping, raw line-count re-derivation, and untagged column arithmetic are compiler errors: `CharOffset`/`RopeyLine`/`ContentLine`/the column newtypes have private fields and no arithmetic trait impls, so `pos + 1` or `col - 1` doesn't type-check (see `CLAUDE.md`'s invariants). A type needs no opt-out and can't be worked around, so it wins whenever the domain admits one.
  2. **Clippy, when the mistake is a specific call that must go through our wrapper instead.** `Rope::len_lines()` and `UnicodeWidthStr::width()` are foreign APIs returning a bare `usize` with no domain of ours to attach a type to — but the wrapper we want in their place (`hume_rope::lines`, `hume_rope::width`) does bookkeeping the raw call skips. `clippy.toml`'s `disallowed-methods` bans the raw calls workspace-wide, enforced by `cargo clippy --workspace --all-targets -- -D clippy::disallowed_methods` in `scripts/test-all.sh`/CI (which also denies `clippy::unwrap_used`). This fits when the call has a nameable path and the real exceptions are few enough to mark individually with a local `#[allow(clippy::disallowed_methods)]`.
  3. **`arch-lints/`, when neither of the above can see the rule at all.** a plugin's `manifest.scm` command list drifting from its own `define-command!` calls, `runtime/init.scm.example` missing a newly added core plugin, a generated `runtime/scheme/*.scm` header hand-edited away from the template that regenerates it. There's no Rust item here to hang a type or a clippy path on, so a scanner is what's left.
- **Comments explain why, never what.** Well-named identifiers cover the what. Keep comments self-contained: no references to roadmap files, plan documents, task numbers, or "as discussed".
- **Keep it simple.** This is a learning project as much as a product. Clarity beats cleverness, and a direct solution beats a premature abstraction.
- **Cross-platform.** macOS is primary; Linux and Windows are supported. Platform-specific code lives behind `cfg` gates inside `hume-platform`, nowhere else.

## Tests

Every editing command, text object, and selection operation needs tests. No untested commands.

- **Core editing logic** uses state triples — initial buffer, operation, expected buffer — with cursor and selection markers inline in the text.
- **Appearance** (glyphs, spacing, rendered strings) is tested with [`insta`](https://insta.rs) snapshots: inline snapshots for short one-line elements, file snapshots for full-frame renders.
  Never assert a rendered string by hand in a unit test — unit tests assert data and semantics.

## Changelog

User-visible changes get an entry under `## Unreleased` in `CHANGELOG.md`, written for the person running the editor rather than the person reading the diff. An entry announces the change, fix or feature in a line or two; how it works, its options and its edge cases belong in the user manual. A breaking change goes under the release's `### Breaking changes` heading and says what to change.

## Documentation

Every piece of writing in this repository targets exactly one audience — do not mix them:

| Audience | Lives in |
|---|---|
| End users | `CHANGELOG.md`, `README.md`, `user-manual/docs/`, `runtime/tutor.rst`, `runtime/init.scm.example` |
| Learners | `docs/LEARNING.md`, `docs/learning/` |
| Contributors | Inline source comments, plus a per-directory `README.md` (`scripts/`, `runtime/scheme/`, each `runtime/plugins/core/*/`) |

Source comments target contributors only, and user-facing docs never mention Rust types, module paths, or internal function names.

To preview the manual:

```sh
cd user-manual
npm install
npm run dev
```

The published site has two channels: `nightly` rebuilds from `main` on every merge, and the release channel rebuilds from the newest `v*` tag.

## Security

Please do not open a public issue for a security problem. [SECURITY.md](SECURITY.md) explains how to report one privately.
