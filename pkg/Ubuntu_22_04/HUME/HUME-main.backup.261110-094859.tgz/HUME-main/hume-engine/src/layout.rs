use ropey::Rope;

use crate::pipeline::{ContentWidth, PaneSize};
use crate::providers::{GutterColumn, GutterInputs};

// Pane geometry: output of Stage 1

/// The output of the Layout stage: the pane geometry the Format/Render stages
/// should use.
///
/// Which *display lines* are visible is not decided here: `display_lines::DisplayLineMap` walks them
/// from the viewport's top address, so the walk is the layout and no estimate
/// of "how many lines fill the screen" is needed.
#[derive(Copy, Clone, Debug)]
pub struct PaneGeometry {
    /// Available columns in the content area (viewport width − gutter width).
    pub content_width: ContentWidth,
    /// Total gutter width in columns.
    pub gutter_width: u16,
    /// 0-based index of the last ropey line (`hume_rope::lines::last_ropey_line`),
    /// phantom trailing line included. This is the correct value to pass to
    /// `GutterColumn::width()`.
    pub last_line_idx: hume_rope::line::RopeyLine,
}

// Stage 1: compute_viewport

/// Per-lane widths of `gutter_columns` for the given `max_line` (0-based
/// last line index), one entry per column in order: the single computation
/// [`gutter_width_for_line`] sums and `pane_render`'s per-frame
/// `scratch.lane_widths` collects, so a lane's width can't drift between the
/// pane geometry pass and what `compose_gutter` actually paints.
///
/// Pass the last line index of the entire file so gutter width is stable
/// across scrolling.
///
/// Takes an iterator (rather than a slice) so callers can feed it
/// `ProviderSet::gutter_columns()` directly. `ProviderSet` stores
/// `(ProviderId, Box<dyn GutterColumn>)` pairs internally, which isn't a
/// shape this purely-arithmetic function needs to know about.
pub fn lane_widths<'a>(
    gutter_columns: impl Iterator<Item = &'a dyn GutterColumn> + 'a,
    max_line: hume_rope::line::RopeyLine,
    inputs: GutterInputs,
) -> impl Iterator<Item = u16> + 'a {
    // GutterColumn::width is a cell count, not display width.
    gutter_columns.map(move |c| c.width(max_line, inputs) as u16)
}

/// Sum of all gutter column widths for the given `max_line`; see
/// [`lane_widths`], which this sums.
pub fn gutter_width_for_line<'a>(
    gutter_columns: impl Iterator<Item = &'a dyn GutterColumn> + 'a,
    max_line: hume_rope::line::RopeyLine,
    inputs: GutterInputs,
) -> u16 {
    lane_widths(gutter_columns, max_line, inputs).sum()
}

/// Compute the `PaneGeometry` for a pane of `size` showing `rope`.
///
/// This is purely arithmetic, with no heap allocations.
pub fn compute_viewport<'a>(
    rope: &Rope,
    size: PaneSize,
    gutter_columns: impl Iterator<Item = &'a dyn GutterColumn> + 'a,
    inputs: GutterInputs,
) -> PaneGeometry {
    // 0-based index of the last line: the single source of truth for
    // GutterColumn::width(). Using the whole-file last line (not just what is
    // on screen) keeps gutter width stable as the user scrolls. It is
    // the phantom trailing line, not the last content line: the gutter is
    // sized one digit wider than content requires.
    let last_line_idx = hume_rope::lines::last_ropey_line(rope);
    let gutter_width = gutter_width_for_line(gutter_columns, last_line_idx, inputs);

    PaneGeometry {
        content_width: ContentWidth::of(size, gutter_width),
        gutter_width,
        last_line_idx,
    }
}

#[cfg(test)]
mod tests;
