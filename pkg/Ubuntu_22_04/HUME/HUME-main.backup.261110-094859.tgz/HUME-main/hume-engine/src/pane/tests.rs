use super::*;
use crate::test_support::{cursor_mirror, mirror, painted};

#[test]
fn viewport_defaults() {
    let vp = Viewport::default();
    assert_eq!(vp.top(), DisplayLinePos::default());
    assert_eq!(vp.horizontal_offset, DisplayLineCol::new(0));
}

fn nz(width: u16) -> NonZeroU16 {
    NonZeroU16::new(width).expect("test widths are non-zero")
}

#[test]
fn resolved_wrap_width() {
    assert_eq!(WrapMode::None.resolve(nz(100)).wrap_width(), None);
    assert_eq!(
        WrapMode::Soft { width: 80 }.resolve(nz(100)).wrap_width(),
        Some(80)
    );
    assert_eq!(
        WrapMode::Word { width: 40 }.resolve(nz(100)).wrap_width(),
        Some(40)
    );
    assert_eq!(
        WrapMode::Indent { width: 60 }.resolve(nz(100)).wrap_width(),
        Some(60)
    );
}

#[test]
fn wrap_mode_resolve() {
    // A zero width takes the content width.
    for mode in [
        WrapMode::Soft { width: 0 },
        WrapMode::Word { width: 0 },
        WrapMode::Indent { width: 0 },
    ] {
        assert_eq!(mode.resolve(nz(80)).wrap_width(), Some(80), "{mode:?}");
    }
    // The style survives resolution.
    assert!(!WrapMode::Soft { width: 0 }.resolve(nz(80)).breaks_at_word());
    assert!(WrapMode::Word { width: 0 }.resolve(nz(80)).breaks_at_word());
    assert!(
        !WrapMode::Word { width: 0 }
            .resolve(nz(80))
            .indents_continuations()
    );
    assert!(
        WrapMode::Indent { width: 0 }
            .resolve(nz(80))
            .indents_continuations()
    );
    // An explicit width and None pass through unchanged.
    assert_eq!(
        WrapMode::Soft { width: 40 }.resolve(nz(80)).wrap_width(),
        Some(40)
    );
    assert!(!WrapMode::None.resolve(nz(80)).is_wrapping());
}

#[test]
fn wrap_mode_is_wrapping() {
    assert!(!WrapMode::None.is_wrapping());
    assert!(WrapMode::Soft { width: 80 }.is_wrapping());
    assert!(WrapMode::Word { width: 80 }.is_wrapping());
    assert!(WrapMode::Indent { width: 80 }.is_wrapping());
    // Sentinel (width: 0 = terminal width) must still report is_wrapping()
    // = true; it must not be conflated with WrapMode::None.
    assert!(WrapMode::Indent { width: 0 }.is_wrapping());
    assert!(WrapMode::Soft { width: 0 }.is_wrapping());
}

// ── Pane::new / wrap-mode override seeding ───────────────────────────────

#[test]
fn pane_new_has_no_wrap_override_and_nothing_to_restore() {
    // A fresh pane inherits the buffer/global setting (no pane-level pin)
    // and has never been toggled off, so there is no `:wrap` restore target
    // yet; see `hume-editor`'s `pane_state::toggle_focused_wrap`.
    let pane = Pane::new(BufferId::default());
    let wrap = pane.wrap();
    assert_eq!(wrap.mode, None);
    assert_eq!(wrap.saved, None);
}

// ── show_buffer ─────────────────────────────────────────────────────────

#[test]
fn show_buffer_clamps_the_restored_top_line_to_the_buffers_current_last_content_line() {
    let [bid, other] = hume_core::fresh_ids();
    let mut pane = Pane::new(bid);

    // Scrolled deep into a buffer that was, at the time, tall.
    pane.viewport
        .seed_top_for_test(DisplayLinePos::new(ContentLine::new(100), 0));
    pane.show_buffer(other, ContentLine::new(0));

    // Back to the same buffer, which has since shrunk to a last content
    // line of 3 (e.g. edited by another pane in the meantime).
    pane.show_buffer(bid, ContentLine::new(3));

    assert_eq!(pane.viewport.top().line.index(), 3);
}

#[test]
fn show_buffer_restores_an_in_range_top_line_untouched() {
    let [bid, other] = hume_core::fresh_ids();
    let mut pane = Pane::new(bid);

    pane.viewport
        .seed_top_for_test(DisplayLinePos::new(ContentLine::new(4), 0));
    pane.show_buffer(other, ContentLine::new(0));
    pane.show_buffer(bid, ContentLine::new(100));

    assert_eq!(pane.viewport.top().line.index(), 4);
}

// ── resume_scroll ───────────────────────────────────────────────────────

#[test]
fn resume_scroll_on_the_shown_buffer_moves_its_viewport() {
    let [bid] = hume_core::fresh_ids();
    let mut pane = Pane::new(bid);
    let top = DisplayLinePos::new(ContentLine::new(7), 1);
    pane.resume_scroll(bid, top);
    assert_eq!(pane.viewport.top(), top);
}

#[test]
fn resume_scroll_on_a_hidden_buffer_is_where_showing_it_lands() {
    let [bid, other] = hume_core::fresh_ids();
    let mut pane = Pane::new(bid);
    let top = DisplayLinePos::new(ContentLine::new(7), 0);
    pane.resume_scroll(other, top);
    assert_eq!(pane.viewport.top(), DisplayLinePos::default());
    pane.show_buffer(other, ContentLine::new(100));
    assert_eq!(pane.viewport.top(), top);
}

#[test]
fn whitespace_config_defaults() {
    let wc = WhitespaceConfig::default();
    assert_eq!(wc.space, WhitespaceRender::None);
    assert_eq!(wc.tab, WhitespaceRender::None);
    assert!(!wc.newline);
    assert_eq!(wc.space_char, "·");
    assert_eq!(wc.tab_char, "→");
    assert_eq!(wc.newline_char, "⏎");
    assert_eq!(wc.nbsp_char, "⍽");
}

fn make_pane_at(rope: &ropey::Rope, head_char: usize) -> Pane {
    Pane {
        selections: Some(cursor_mirror(rope, head_char)),
        ..Pane::new(hume_core::BufferId::default())
    }
}

#[test]
fn primary_head_line_returns_head_line() {
    // "aaa\nbbb\nccc": line 0 is chars 0..3, line 1 is chars 4..7, line 2 is chars 8..11.
    // Char 8 (start of line 2) should resolve to line 2.
    let rope = ropey::Rope::from_str("aaa\nbbb\nccc");
    let pane = make_pane_at(&rope, 8); // first char of line 2
    let sels = pane.selections.as_ref().expect("a written mirror");
    assert_eq!(primary_head_line(sels, &rope).index(), 2);
}

#[test]
fn primary_head_line_follows_the_primary_index() {
    // "aaa\nbbb\nccc": char 0 = line 0, char 8 = line 2.
    let rope = ropey::Rope::from_str("aaa\nbbb\nccc");
    let sels = [(0, 0), (8, 8)];
    assert_eq!(
        primary_head_line(&mirror(&rope, &sels, 1), &rope).index(),
        2
    );
    assert_eq!(
        primary_head_line(&mirror(&rope, &sels, 0), &rope).index(),
        0
    );
}

#[test]
#[should_panic(expected = "a selection mirror holds at least one selection")]
fn a_selection_mirror_refuses_an_empty_list() {
    crate::types::PaintedSelections::new(Vec::new(), 0);
}

#[test]
#[should_panic(expected = "the primary index names a selection of the mirror")]
fn a_selection_mirror_refuses_a_primary_past_its_selections() {
    let rope = ropey::Rope::from_str("aaa\nbbb\n");
    crate::types::PaintedSelections::new(vec![painted(&rope, 0, 0), painted(&rope, 4, 4)], 2);
}

#[test]
#[should_panic(expected = "a selection mirror is in cursor order")]
fn a_selection_mirror_refuses_cursors_out_of_order() {
    let rope = ropey::Rope::from_str("aaa\nbbb\n");
    crate::types::PaintedSelections::new(vec![painted(&rope, 4, 4), painted(&rope, 0, 0)], 0);
}

#[test]
fn a_rewritten_selection_mirror_holds_the_new_selections_and_primary() {
    let rope = ropey::Rope::from_str("aaa\nbbb\n");
    let mut sels = cursor_mirror(&rope, 0);
    sels.rewrite([painted(&rope, 0, 2), painted(&rope, 4, 5)], 1);
    assert_eq!(sels, mirror(&rope, &[(0, 2), (4, 5)], 1));
}

#[test]
#[should_panic(expected = "a selection mirror holds at least one selection")]
fn a_selection_mirror_refuses_a_rewrite_to_an_empty_list() {
    let rope = ropey::Rope::from_str("aaa\nbbb\n");
    cursor_mirror(&rope, 0).rewrite([], 0);
}
