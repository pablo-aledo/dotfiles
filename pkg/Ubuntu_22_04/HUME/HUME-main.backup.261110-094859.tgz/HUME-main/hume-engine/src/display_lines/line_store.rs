//! What a [`DisplayLineMap`](super::DisplayLineMap) knows about the lines it is walking.
//!
//! One [`LineEntry`] per visited line: its block shape and laid-out virtual
//! lines from creation, and its [`LineFormat`] once something formats it.
//! Under `WrapMode::None` the content shape is known without formatting;
//! under wrapping the content format arrives with the shape.
//!
//! A [`PaneLineStore`] lives on its [`Pane`](crate::pane::Pane), so the scroll
//! pass, render pass and between-frame consumers (mouse, visual movement,
//! `z`-scroll) share entries. It is per pane because [`ResolvedFormatKey`] names no
//! pane: two panes on the same buffer and width resolve an identical key.
//!
//! A store drops its entries when its [`ResolvedFormatKey`] changes. The unwrapped
//! render's `h_window` is not in the key because it doesn't affect block
//! shape; it lives on [`LineFormat`], where
//! [`LineFormat::covers`](crate::format::LineFormat::covers) keeps windowed and
//! unwindowed formats apart.
//!
//! [`EngineView::begin_frame`](crate::pipeline::EngineView::begin_frame)
//! rewinds every store, and correctness depends on it: inlay-hint and EOL-text
//! mirrors are rebuilt per frame for the visible viewport without bumping the
//! decoration generation, so a line scrolling into view can change its wrap
//! count under an unchanged key.

use rustc_hash::FxHashMap;

use crate::format::{LineFormat, VirtualFormat};
use std::num::NonZeroU16;

use crate::pane::{ResolvedWrap, WhitespaceConfig, WrapMode};
use hume_rope::line::ContentLine;

/// The caller's identification of a buffer *state* (which buffer, at which
/// content generation, with which decorations) as the three numbers naming
/// it.
///
/// Compared as a unit and never interpreted, so which component is which is
/// this crate's business only insofar as the caller stays consistent about
/// it. Three numbers rather than one the caller hashed them into: the
/// comparison here is exact, and a fold would trade that for a probabilistic
/// one to buy nothing: a key this small is copied, not stored at scale.
pub type BufferTag = [u64; 3];

/// The formatting settings a pane views a buffer with, as the caller
/// builds them: wrap mode raw (a `width: 0` still means "the content
/// width"). [`DisplayLineMap::new`](super::DisplayLineMap::new) resolves it
/// against the pane's content width into the [`ResolvedFormatKey`] its
/// store is scoped by.
///
/// One value rather than four loose ones, built once by the caller
/// (`hume-editor`'s `EditorState::format_key`) and threaded unchanged through
/// `DisplayLineMap::new`: the frame's scroll pass and render pass each resolve this
/// from a different composition (`commands::pane_display_lines` vs.
/// `frame.rs::resolve_pane_settings`), and their sharing this pane's store
/// depends entirely on the two agreeing bit for bit. A single constructor is
/// what makes disagreement a compile-time impossibility rather than a
/// property four independently-resolved fields have to earn by convention.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct FormatKey {
    pub buffer_tag: BufferTag,
    pub wrap_mode: WrapMode,
    pub tab_width: u8,
    pub whitespace: WhitespaceConfig,
}

impl FormatKey {
    pub fn resolve(self, content_width: NonZeroU16) -> ResolvedFormatKey {
        ResolvedFormatKey {
            buffer_tag: self.buffer_tag,
            params: FormatParams {
                wrap: self.wrap_mode.resolve(content_width),
                tab_width: self.tab_width,
                whitespace: self.whitespace,
            },
        }
    }
}

/// Everything a line's block shape depends on besides the line's own text:
/// a [`FormatKey`] resolved against one content width.
///
/// Excludes the horizontal clip (`h_window`) a `WrapMode::None`
/// render applies: block shape doesn't depend on it, only the formatted
/// display lines do, so that lives on `LineFormat` instead (see the module
/// doc).
///
/// Also excludes the pane's content width, which reaches formatting through
/// the resolved wrap and nowhere else, so a width that matters is already in
/// this key, and one that doesn't (a resize under `WrapMode::None`, or under
/// a wrap mode with an explicit column) would only rewind a store whose
/// entries stayed valid.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct ResolvedFormatKey {
    pub buffer_tag: BufferTag,
    pub params: FormatParams,
}

/// The formatting settings in a [`ResolvedFormatKey`]: what
/// [`format_buffer_line`](crate::format::format_buffer_line) reads, without
/// the buffer identity only the store's scope check needs.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct FormatParams {
    pub wrap: ResolvedWrap,
    pub tab_width: u8,
    pub whitespace: WhitespaceConfig,
}

/// One line's block shape, and its formatted display lines once it has them.
pub struct LineEntry {
    /// The line this describes. Held so an entry index alone addresses a
    /// line: every caller working from one reads the line back here rather
    /// than carrying it alongside and risking the two disagreeing.
    pub line: ContentLine,
    /// This line's virtual display lines, laid out under the store's wrap
    /// mode.
    pub virtual_format: VirtualFormat,
    /// The line's content display lines. `format.extent` is `None` until
    /// something formats them.
    pub format: LineFormat,
}

impl LineEntry {
    fn new(line: ContentLine) -> Self {
        Self {
            line,
            virtual_format: VirtualFormat::new(),
            format: LineFormat::new(),
        }
    }

    /// Reuse this entry for `line`, keeping the allocations behind it.
    ///
    /// `format` and `virtual_format` need no resetting here: the only way an
    /// entry becomes a spare is through [`PaneLineStore::rewind`], which
    /// already reset (and, past its ceiling, shrank) both.
    fn rebind(&mut self, line: ContentLine) {
        self.line = line;
    }
}

/// The lines one [`DisplayLineMap`](super::DisplayLineMap) is working with.
///
/// `entries` is a free list: `PaneLineStore::rewind` drops what is live but
/// keeps each entry's allocation (bar one grown past
/// [`crate::format::LineFormat::reset_and_shrink`]'s ceiling), so a store
/// settles into reusing what it already has without one pathologically wide
/// line pinning its capacity for the pane's whole life. An entry only ever
/// holds buffers for a line something actually formatted; one walked for its
/// block shape alone carries none.
#[derive(Default)]
pub struct PaneLineStore {
    key: Option<ResolvedFormatKey>,
    entries: Vec<LineEntry>,
    /// `entries[..live]` describe lines; the rest are spares.
    live: usize,
    /// Buffer line -> index into `entries`.
    index: FxHashMap<ContentLine, usize>,
}

impl PaneLineStore {
    pub fn new() -> Self {
        Self::default()
    }

    /// Point this store at `key`, dropping what it holds if that differs from
    /// what its entries were built under.
    pub(super) fn scope(&mut self, key: ResolvedFormatKey) {
        if self.key.as_ref() != Some(&key) {
            self.key = Some(key);
            self.rewind();
        }
    }

    /// Drop what this store holds, keeping the allocations behind it, bar
    /// one grown past its ceiling, which is handed back here.
    ///
    /// Called once per frame via [`EngineView::begin_frame`](crate::pipeline::EngineView::begin_frame),
    /// and a correctness requirement rather than hygiene; see the module doc.
    ///
    /// The shrink belongs at this boundary rather than at
    /// [`LineEntry::rebind`], the other point an entry changes hands: a slot
    /// is rebound only by a later frame that walks at least as many lines as
    /// the frame that grew it, so a pane that shows one pathologically wide
    /// line and then a handful of short ones would otherwise pin that
    /// capacity for as long as the pane lives.
    pub(crate) fn rewind(&mut self) {
        for entry in &mut self.entries[..self.live] {
            entry.format.reset_and_shrink();
            entry.virtual_format.clear_and_shrink();
        }
        self.live = 0;
        self.index.clear();
    }

    /// The entry for `line`, if this store has one.
    pub(super) fn find(&self, line: ContentLine) -> Option<usize> {
        self.index.get(&line).copied()
    }

    /// Start an entry for `line`, reusing a spare's allocations. The caller
    /// fills in the block shape; the format arrives later, if at all.
    pub(super) fn insert(&mut self, line: ContentLine) -> usize {
        debug_assert!(
            self.find(line).is_none(),
            "line {} already has an entry; the caller must reuse it",
            line.index()
        );
        let idx = self.live;
        match self.entries.get_mut(idx) {
            Some(spare) => spare.rebind(line),
            None => self.entries.push(LineEntry::new(line)),
        }
        self.index.insert(line, idx);
        self.live += 1;
        idx
    }

    pub(super) fn entry(&self, idx: usize) -> &LineEntry {
        &self.entries[idx]
    }

    pub(super) fn entry_mut(&mut self, idx: usize) -> &mut LineEntry {
        &mut self.entries[idx]
    }
}
