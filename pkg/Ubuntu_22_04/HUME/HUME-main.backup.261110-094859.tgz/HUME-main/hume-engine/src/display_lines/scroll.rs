//! The viewport's scroll verbs, and [`carry`], the per-selection cursor walk a
//! view-scroll command (`commands::scroll_view` in `hume-editor`) runs
//! alongside [`Viewport::scroll_by`] with the same requested delta.
//!
//! These verbs are the only way [`Viewport::top`](crate::pane::Viewport::top)
//! changes from outside this crate, and [`Viewport::top_at`] is the only safe
//! way to read one. A [`ViewGeometry`] is resolved once per call and threaded
//! through, so no verb recomputes `margin`/`target` or sees a zero height.
//!
//! `carry` walks the requested delta itself rather than following how far
//! `scroll_by` moved. Near EOF `scroll_by`'s scroll-margin bound is tighter than
//! the document bound, and following it would stall the cursor short of the
//! last line once the viewport saturates. Farther from EOF the two agree.
//!
//! `carry` then clamps the landing into `[geo.margin, geo.target]` display
//! lines below the viewport's new top, so the head always ends inside the
//! scroll-margin band and [`Viewport::reveal`] is idle after `scroll_view`. An
//! in-band landing is unchanged, keeping the cursor's screen row.

use super::{DisplayLineMap, DisplayLinePos};
use crate::pane::{ViewGeometry, Viewport};
use hume_rope::column::DisplayLineCol;

impl Viewport {
    /// The viewport's top display-line address, resolved against `dlm`.
    ///
    /// Single self-heal chokepoint for staleness, and the only way to obtain a
    /// `top` that is safe to walk: nothing validates a `top` write against the
    /// block it addresses (`Pane::show_buffer` restores a saved offset
    /// verbatim; an LSP goto-definition jump moves `top` without re-deriving its
    /// slot; `Pane::inherit_view_state` clones one wholesale), and the block a
    /// stale address was valid for can shrink or vanish (wrap-width change, a
    /// virtual-line decoration source removed, a resize) between the write and
    /// the next read.
    ///
    /// Writes the resolved address back rather than returning a clamped copy, so
    /// the stored field converges on every read and `Viewport::top`'s own value
    /// is never a second, staler answer to the same question. Every read site
    /// that holds a `DisplayLineMap` goes through here; the three that hold none
    /// read [`Viewport::top`] and are documented there.
    pub fn top_at(&mut self, dlm: &mut DisplayLineMap<'_>) -> DisplayLinePos {
        self.top = dlm.clamp(self.top);
        self.top
    }

    /// Scroll `delta` display lines (positive = down, negative = up). `carry`
    /// walks the same requested `delta` independently, with its own bound,
    /// rather than tracking how far the view actually got. See this
    /// module's doc for why.
    ///
    /// Resolves `top` first (see [`Viewport::top_at`]), so a caller need not
    /// heal it separately before scrolling.
    ///
    /// A *downward* scroll is bounded by `DisplayLineMap::max_scroll_top`
    /// and additionally never moves `top` backwards past where it already
    /// sits: [`Viewport::align`] (`z z`/`z k`/`z j`) and an LSP
    /// goto-definition jump both leave `top` past
    /// `max_scroll_top` (see that function's own doc on not clamping at the
    /// bottom), so a plain `next.min(max_scroll_top)` would pick the
    /// *earlier* of the two (`DisplayLinePos: Ord` is document order),
    /// snapping a downward notch backwards. An *upward* scroll only
    /// saturates at the document's first display line.
    pub fn scroll_by(&mut self, dlm: &mut DisplayLineMap<'_>, geo: ViewGeometry, delta: isize) {
        let current = self.top_at(dlm);
        let next = dlm.advance_saturating(current, delta);
        if delta < 0 {
            self.top = next;
            return;
        }
        // `max_scroll_top` walks back from the document's very last display
        // line, formatting every line it crosses under wrap: worth skipping
        // when `next` is provably nowhere near EOF. Every buffer line
        // contributes at least one display line, so a `next` more than
        // `geo.height` *buffer* lines short of the document's last one (an
        // O(1) check) can't be within the bound's own `target` (<=
        // `geo.height`) *display* lines of it, and the bound can't bind.
        let lines_to_end = dlm.last_line().index().saturating_sub(next.line.index());
        if lines_to_end > geo.height {
            self.top = next;
            return;
        }
        let bound = dlm.max_scroll_top(geo);
        self.top = if next <= bound {
            next
        } else {
            bound.max(current)
        };
    }

    /// Adjust `top` so `cursor_pos` is visible with `geo.margin` display
    /// lines of look-ahead above and below it. Returns the cursor's
    /// resulting screen row: its distance below the (possibly just-moved)
    /// `top`.
    pub fn reveal(
        &mut self,
        dlm: &mut DisplayLineMap<'_>,
        geo: ViewGeometry,
        cursor_pos: DisplayLinePos,
    ) -> usize {
        let (top, row) = self.reveal_target(dlm, geo, cursor_pos);
        self.top = top;
        row
    }

    /// `reveal`'s decision, without writing it: the top `reveal` would
    /// settle on plus the cursor's resulting row, both resolved against the
    /// current (already-healed) `top`. [`Self::reveal`] and
    /// [`Self::settled_row`] are this one decision's two readers, so it
    /// exists to be identical between them rather than by convention.
    fn reveal_target(
        &mut self,
        dlm: &mut DisplayLineMap<'_>,
        geo: ViewGeometry,
        cursor_pos: DisplayLinePos,
    ) -> (DisplayLinePos, usize) {
        let top = self.top_at(dlm);
        if cursor_pos < top {
            return Self::scroll_back_target(dlm, cursor_pos, geo.margin);
        }
        // Capped at `geo.target` rather than `geo.height`: walking past
        // `geo.target` under wrap only pays for `format_buffer_line` calls
        // whose answer nothing inspects. `distance` never returns more than
        // its own cap, so a `Some` result here is always `<= geo.target`,
        // well inside the second arm below without needing its own
        // upper-bound check.
        match dlm.distance(top, cursor_pos, geo.target) {
            Some(display_lines_below_top) if display_lines_below_top < geo.margin => {
                Self::scroll_back_target(dlm, cursor_pos, geo.margin)
            }
            Some(display_lines_below_top) => (top, display_lines_below_top),
            None => Self::scroll_back_target(dlm, cursor_pos, geo.target),
        }
    }

    /// Whether `cursor_pos` already sits where [`Self::reveal`] would leave
    /// it, without moving `top`: the single definition of a pane being
    /// "parked" (its cursor outside the scroll-margin band, left behind by a
    /// wheel/`Ctrl-d` scroll `carry` couldn't fully follow). `Some(row)`
    /// when `top` is already `reveal`'s fixed point for `cursor_pos`, giving
    /// the cursor's row for free; `None` otherwise.
    pub fn settled_row(
        &mut self,
        dlm: &mut DisplayLineMap<'_>,
        geo: ViewGeometry,
        cursor_pos: DisplayLinePos,
    ) -> Option<usize> {
        let before = self.top_at(dlm);
        let (target, row) = self.reveal_target(dlm, geo, cursor_pos);
        (target == before).then_some(row)
    }

    /// Scroll so `cursor_pos` lands `display_lines_below_top` display lines
    /// below `top`, clamped to `[geo.margin, geo.target]`: the same
    /// scroll-margin range [`Viewport::reveal`] settles a too-close cursor into.
    /// Used by the `z z`/`z k`/`z j` view commands, which write no
    /// reveal-on-demand signal of their own, so the clamp is applied here
    /// rather than left to a follow-up `reveal` call.
    ///
    /// Top-of-buffer is clamped to the document's first display line;
    /// bottom-of-buffer is *not* clamped (vim/Helix semantics: empty
    /// display lines past EOF are allowed).
    pub fn align(
        &mut self,
        dlm: &mut DisplayLineMap<'_>,
        geo: ViewGeometry,
        cursor_pos: DisplayLinePos,
        display_lines_below_top: usize,
    ) {
        let display_lines_below_top = display_lines_below_top.clamp(geo.margin, geo.target);
        self.scroll_back_from(dlm, cursor_pos, display_lines_below_top);
    }

    /// Adjust `horizontal_offset` so `cursor_display_col` stays visible.
    /// Wrapping modes have no horizontal scroll, so the offset is forced to
    /// 0 there. The horizontal margin is fixed: scroll-margin governs only the
    /// vertical axis, so this takes no `ViewGeometry`.
    pub fn reveal_horizontal(
        &mut self,
        dlm: &mut DisplayLineMap<'_>,
        cursor_display_col: DisplayLineCol,
    ) {
        const H_MARGIN: usize = 5;

        if dlm.is_wrapping() {
            self.horizontal_offset = DisplayLineCol::new(0);
            return;
        }

        // The rest of this function mixes the column with plain margin/width
        // counts throughout, so it drops to `.get()`'s bare `u32` at the top
        // rather than threading `DisplayLineCol` arithmetic through.
        let cursor_display_col = cursor_display_col.get() as usize;
        // `locate`'s column is content-relative (the gutter isn't part of
        // it), so the margin must compare against the content width the map
        // itself was built with, not `Viewport::width`, which still
        // includes the gutter and so under-counts how many columns are
        // actually visible.
        let content_width = dlm.content_width() as usize;
        if content_width == 0 {
            return;
        }

        let margin = H_MARGIN.min(content_width / 2);
        let offset = self.horizontal_offset.get() as usize;

        if cursor_display_col < offset + margin {
            self.horizontal_offset =
                DisplayLineCol::new(cursor_display_col.saturating_sub(margin) as u32);
        } else if cursor_display_col >= offset + content_width - margin {
            self.horizontal_offset = DisplayLineCol::new(
                cursor_display_col.saturating_sub(content_width - margin - 1) as u32,
            );
        }
    }

    /// Put `top` `display_lines_above` display lines before `cursor_pos`,
    /// saturating at the document's first display line. Returns how many
    /// display lines it actually stepped back, which, `next`/`prev` being
    /// inverses, is the cursor's screen row under the new `top`.
    fn scroll_back_from(
        &mut self,
        dlm: &mut DisplayLineMap<'_>,
        cursor_pos: DisplayLinePos,
        display_lines_above: usize,
    ) -> usize {
        let (top, stepped) = Self::scroll_back_target(dlm, cursor_pos, display_lines_above);
        self.top = top;
        stepped
    }

    /// [`Self::scroll_back_from`]'s walk, without the write: the target top
    /// `display_lines_above` before `cursor_pos`, plus the cursor's row
    /// under it. Takes no `&self` at all, since the answer depends only on
    /// `dlm` and the two arguments.
    fn scroll_back_target(
        dlm: &mut DisplayLineMap<'_>,
        cursor_pos: DisplayLinePos,
        display_lines_above: usize,
    ) -> (DisplayLinePos, usize) {
        dlm.advance_counted_saturating(cursor_pos, -(display_lines_above as isize))
    }
}

impl<'a> DisplayLineMap<'a> {
    /// The furthest down the viewport top may scroll: `geo.target` display
    /// lines of look-ahead past the document's last display line (a
    /// trailing `After` virtual block included, exactly like any real buffer
    /// line), then no further. `geo` is [`PaneSize::geometry`](crate::pipeline::PaneSize::geometry), the same
    /// geometry [`Viewport::reveal`] resolves, so the two agree on
    /// `margin`/`target`.
    ///
    /// The two bounds' *anchors* do not agree: this one
    /// measures back from the document's last display line, while `reveal`
    /// measures from the cursor's own display line, which can never be a
    /// virtual one, since the cursor only ever occupies content display
    /// lines. That gap is what lets a scroll carry the viewport into a
    /// trailing virtual block at all; without it, the cursor being unable to
    /// follow would cap the scroll at the block's near edge. The two anchors
    /// coincide, and so land on the same top, only when the cursor sits on
    /// the document's last display line: the case a plain `Ctrl-d`/wheel
    /// scroll to EOF followed by an ordinary cursor motion exercises.
    /// Saturates at the document's first display line, so a document that
    /// fits on screen (plus its margin) cannot be scrolled at all.
    ///
    /// Takes a [`ViewGeometry`] rather than a raw height precisely so a
    /// zero-height viewport never reaches here at all. `PaneSize::geometry`
    /// returns `None` for one, so every caller already branched away before
    /// constructing the `geo` this needs. `advance_saturating(last, -0)`
    /// would otherwise return the document's *last* display line (the
    /// opposite of "saturates at the first") for the degenerate `target ==
    /// 0` a zero height produces.
    pub(crate) fn max_scroll_top(&mut self, geo: ViewGeometry) -> DisplayLinePos {
        let last_line = self.last_line();
        let last = DisplayLinePos::new(last_line, self.block(last_line).total().saturating_sub(1));
        self.advance_saturating(last, -(geo.target as isize))
    }
}

/// Where a head's display line goes after a view scroll of `delta` display
/// lines (the same signed delta passed to `Viewport::scroll_by`), band-
/// clamped against `top` (the viewport's top *after* that `scroll_by` call),
/// so a `Some` result always already satisfies [`Viewport::reveal`]'s own
/// contract. See this module's doc for why the walk itself still uses the
/// *requested* `delta`, not the amount the view actually moved, and for what
/// the band clamp adds on top of that.
///
/// Two passes: `walk_by_delta` finds where a plain `delta`-display-line
/// walk from `head` would land (`None` if it never reaches a content
/// line: `head` already sat at the document's edge in the direction of
/// travel, `delta == 0`, or a virtual-line block past the band swallowed the
/// walk whole); `place_in_band` then clamps how many display lines below
/// `top` that landing sits into `[geo.margin, geo.target]`, if it isn't
/// there already. Either pass returning `None` is not an error: it is the same
/// "cursor can't follow" state a pure view scroll into a trailing
/// virtual-line block always could produce, and it leaves the selection
/// untouched rather than collapsing it.
pub fn carry(
    dlm: &mut DisplayLineMap<'_>,
    geo: ViewGeometry,
    top: DisplayLinePos,
    head: DisplayLinePos,
    delta: isize,
) -> Option<DisplayLinePos> {
    let candidate = walk_by_delta(dlm, geo, top, head, delta)?;
    place_in_band(dlm, geo, top, candidate)
}

/// `carry`'s first pass: walk `delta` display lines from `head` in the
/// requested direction, landing on the last content display line reached.
/// Overshoots `delta` when a virtual-line block swallows the whole budget: a
/// cursor stranded at a block's near edge would make the next ordinary
/// motion jump the view backwards across the whole block to reach it, so
/// this keeps walking past the block to the first content display line
/// beyond it, but only while doing so could still land inside the
/// scroll-margin band (`geo.target` display lines past `top`); a block bigger
/// than that has no legal landing spot at all, so the walk gives up instead
/// of continuing arbitrarily far through it. The document's own edge still
/// breaks the walk before either bound is satisfied.
fn walk_by_delta(
    dlm: &mut DisplayLineMap<'_>,
    geo: ViewGeometry,
    top: DisplayLinePos,
    head: DisplayLinePos,
    delta: isize,
) -> Option<DisplayLinePos> {
    if delta == 0 {
        return None;
    }
    let down = delta > 0;
    let mut pos = head;
    let mut last_content = None;
    let mut remaining = delta.unsigned_abs();
    while remaining > 0 || last_content.is_none() {
        if remaining == 0 {
            match dlm.distance(top, pos, geo.target) {
                Some(display_lines_below_top) if display_lines_below_top < geo.target => {}
                _ => break,
            }
        }
        let Some(next) = (if down { dlm.next(pos) } else { dlm.prev(pos) }) else {
            break;
        };
        pos = next;
        if dlm.slot(pos).is_content() {
            last_content = Some(pos);
        }
        remaining = remaining.saturating_sub(1);
    }
    last_content
}

/// `carry`'s second pass: clamp how many display lines below `top`
/// `candidate` sits into `[geo.margin, geo.target]`, walking forward from
/// `top` to the band's near or far edge via [`walk_from_top`] if it isn't
/// there already. A landing already in-band (the common case) passes
/// through unchanged, so "the cursor keeps its screen row" still holds
/// exactly for it.
///
/// A landing short of `margin` is also left unchanged when `top` itself has
/// no room to retreat any further: walking `candidate` back by `margin`
/// lands on `top` again either way (saturating there), so
/// [`Viewport::reveal`] would be idle on `candidate` exactly as it is; only
/// when `top` still has document above it to scroll into would `reveal`
/// actually move it on the very next frame, which is what the clamp exists
/// to preempt. Without this exception the clamp would permanently override
/// `scroll-margin` at the buffer's own start, since `top` can never retreat far
/// enough there to satisfy a bare `< geo.margin` check.
fn place_in_band(
    dlm: &mut DisplayLineMap<'_>,
    geo: ViewGeometry,
    top: DisplayLinePos,
    candidate: DisplayLinePos,
) -> Option<DisplayLinePos> {
    match dlm.distance(top, candidate, geo.height) {
        Some(display_lines_below_top)
            if (geo.margin..=geo.target).contains(&display_lines_below_top) =>
        {
            Some(candidate)
        }
        Some(display_lines_below_top) if display_lines_below_top > geo.target => {
            walk_from_top(dlm, geo, top, geo.target)
        }
        Some(_) if dlm.advance_saturating(candidate, -(geo.margin as isize)) == top => {
            Some(candidate)
        }
        // Short of `margin` with room for `top` to retreat further, or
        // `candidate` sits before `top` (or too far past `geo.height` to
        // tell). Either way, not in band.
        _ => walk_from_top(dlm, geo, top, geo.margin),
    }
}

/// Walk forward (`next`) from `top` by `display_lines_below_top` display
/// lines, landing on the last content display line reached and continuing
/// past a virtual landing exactly like [`walk_by_delta`]'s own overshoot,
/// capped at `geo.target` total steps so this can never itself land past the
/// band. `top` counts as a landing in its own right when it's already
/// content and `display_lines_below_top == 0` (the `geo.margin == 0` case a
/// very short viewport clamps to).
fn walk_from_top(
    dlm: &mut DisplayLineMap<'_>,
    geo: ViewGeometry,
    top: DisplayLinePos,
    display_lines_below_top: usize,
) -> Option<DisplayLinePos> {
    let mut pos = top;
    let mut last_content = dlm.slot(top).is_content().then_some(top);
    let mut steps = 0usize;
    while steps < display_lines_below_top || last_content.is_none() {
        if steps >= geo.target {
            break;
        }
        let Some(next) = dlm.next(pos) else { break };
        pos = next;
        steps += 1;
        if dlm.slot(pos).is_content() {
            last_content = Some(pos);
        }
    }
    last_content
}

#[cfg(test)]
mod tests;
