use super::*;
use crate::providers::{GutterInputs, ProviderId};
use crate::test_support::{fg, render_display_line, theme_with};
use crate::theme::{ScopeRegistry, Theme};
use crate::types::EditorMode;
use crate::types::ResolvedStyle;
use hume_grid::{Grid, Rect, Rgb};
use hume_rope::column::DisplayLineCol;
use hume_rope::line::{ContentLine, RopeyLine};

/// Gutter inputs giving the sign column `sign_width` cells.
fn inputs(sign_width: u8) -> GutterInputs {
    GutterInputs {
        sign_width,
        ..GutterInputs::default()
    }
}

fn ctx(rope: &ropey::Rope, sign_width: u8) -> GutterCtx<'_> {
    GutterCtx {
        mode: EditorMode::Normal,
        primary_head_line: ContentLine::new(0),
        rope,
        inputs: inputs(sign_width),
    }
}

/// One line's worth of signs from a single source. Production has exactly
/// one `SignSource` per pane (`SharedSignSource`), whose one map entry can
/// already hold several resolved-slot `Sign`s for a line
/// (`Editor::update_sign_providers`), so a multi-sign line is one
/// `signs_for_line` call returning several entries, not several sources.
struct FixedSign {
    line: ContentLine,
    signs: Vec<Sign>,
}

impl SignSource for FixedSign {
    fn signs_for_line(&self, line_idx: ContentLine, _ctx: &GutterCtx) -> Vec<Sign> {
        if line_idx == self.line {
            self.signs.clone()
        } else {
            Vec::new()
        }
    }
}

#[test]
fn sign_renders_in_its_own_resolved_slot() {
    let mut registry = ScopeRegistry::new();
    let diag_scope = registry.intern("diagnostic");
    let blank_scope = registry.intern("ui.linenr");

    let source = FixedSign {
        line: ContentLine::new(3),
        signs: vec![Sign {
            text: "!".into(),
            scope: diag_scope,
            slot: 1,
        }],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope); // 2 sign slots

    let rope = ropey::Rope::new();
    let cells = lane.render_cells(
        DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(3),
        },
        &ctx(&rope, 3),
    );
    assert_eq!(cells[0].as_str(), " ", "slot 0 unclaimed, stays blank");
    assert_eq!(
        cells[1].as_str(),
        "!",
        "sign lands in its own resolved slot 1"
    );
    assert_eq!(cells[1].scope, diag_scope);
}

#[test]
fn no_sign_fires_renders_blank() {
    let mut registry = ScopeRegistry::new();
    let blank_scope = registry.intern("ui.linenr");
    let lane = SignColumn::new(Box::new(()), blank_scope);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(0),
            },
            &ctx(&rope, 2),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), " ");
}

#[test]
fn sign_absent_on_wrap_virtual_and_filler_display_lines() {
    let mut registry = ScopeRegistry::new();
    let scope = registry.intern("diagnostic");
    let blank_scope = registry.intern("ui.linenr");
    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![Sign {
            text: "!".into(),
            scope,
            slot: 0,
        }],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope);
    let rope = ropey::Rope::new();

    for kind in [
        DisplayLineKind::Wrap {
            line_idx: RopeyLine::new(0),
            wrap_index: 1,
        },
        DisplayLineKind::Virtual {
            provider_id: 0,
            anchor_line: RopeyLine::new(0),
        },
        DisplayLineKind::Filler,
    ] {
        let cell = lane
            .render_cells(kind, &ctx(&rope, 2))
            .into_iter()
            .next()
            .unwrap();
        assert_eq!(cell.as_str(), " ", "{kind:?} must not show a sign");
    }
}

#[test]
fn width_is_the_inputs_sign_width_whatever_the_file_size() {
    let mut registry = ScopeRegistry::new();
    let blank_scope = registry.intern("ui.linenr");
    let lane = SignColumn::new(Box::new(()), blank_scope);
    assert_eq!(lane.width(RopeyLine::new(0), inputs(3)), 3);
    assert_eq!(lane.width(RopeyLine::new(999_999), inputs(3)), 3);
    assert_eq!(
        lane.width(RopeyLine::new(0), inputs(0)),
        0,
        "collapsed when the inputs collapse it"
    );
}

#[test]
fn sign_text_truncates_to_column_width_end_to_end() {
    // Full compose path (not just SignColumn::render_display_line in isolation):
    // a 3-glyph sign in a width-2 column must come out clipped by
    // `render::compose_gutter`'s gutter clipping, same as every
    // other gutter column. SignColumn adds no truncation of its own.
    let mut registry = ScopeRegistry::new();
    let scope = registry.intern("diagnostic");
    let blank_scope = registry.intern("ui.linenr");
    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![Sign {
            text: "▶▶▶".into(),
            scope,
            slot: 0,
        }],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope); // usable = 1 cell

    let graphemes = vec![crate::types::Grapheme {
        byte_range: crate::test_support::byte_range(0, 1),
        pos: None,
        display_col: DisplayLineCol::new(0),
        width: 1,
        content: crate::types::CellContent::Grapheme,
        indent_depth: 0,
        scope: None,
    }];
    let dls = [crate::types::DisplayLine {
        kind: DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(0),
        },
        graphemes: 0..1,
    }];
    let styles = vec![crate::types::ResolvedStyle::default()];
    let gutter_columns: Vec<(ProviderId, Box<dyn GutterColumn>)> = vec![(0, Box::new(lane))];
    let visible = crate::layout::PaneGeometry {
        content_width: crate::pipeline::ContentWidth::for_test(6),
        gutter_width: 2,
        last_line_idx: RopeyLine::new(0),
    };
    let pane_rect = Rect {
        x: 0,
        y: 0,
        width: 8,
        height: 1,
    };
    let mut buf = Grid::new(pane_rect.width, pane_rect.height);
    let mut theme = Theme::default();
    theme.bake(&registry);
    let rope = ropey::Rope::from_str("x\n");
    let lane_widths = vec![2u16];
    let compose_ctx = crate::render::ComposeCtx {
        gutter_columns: &gutter_columns,
        visible: &visible,
        horizontal_offset: DisplayLineCol::new(0),
        mode: EditorMode::Normal,
        primary_head_line: ContentLine::new(0),
        tab_width: 4,
        tilde_style: ResolvedStyle::default(),
        indent_guide_style: ResolvedStyle::default(),
        indent_guides: true,
        pane_rect,
        theme: &theme,
        rope: &rope,
        default_gutter_scope: blank_scope,
        gutter: inputs(2),
    };
    let mut canvas = crate::render::Canvas::new(&mut buf, theme.ui.invisible, None);
    crate::render::compose_display_line(
        &render_display_line(&dls[0], &graphemes, "x", ""),
        &styles,
        0,
        &lane_widths,
        &compose_ctx,
        &mut canvas,
        None,
    );

    let sym = |x: u16| buf.cell(x, 0).unwrap().text().to_string();
    assert_eq!(sym(0), "▶", "only the first glyph of the sign fits");
    assert_eq!(sym(1), " ", "separator cell, not a straggler glyph");
    // Content area starts at x=2 (gutter_width) and must show the real
    // grapheme 'x', never a spillover from the sign text.
    assert_eq!(sym(2), "x");
}

/// A width-0 `SignColumn` (the `auto` collapse when no sign is in view)
/// must render as if it weren't registered at all: the gutter composer
/// still iterates it, but must not shift or corrupt whatever renders in the
/// next column.
#[test]
fn zero_width_sign_column_leaves_the_next_column_untouched() {
    let mut registry = ScopeRegistry::new();
    let blank_scope = registry.intern("ui.linenr");
    let selected_scope = registry.intern("ui.linenr.selected");
    let empty_lane = SignColumn::new(Box::new(()), blank_scope);
    let content_lane =
        crate::builtins::line_number::LineNumberColumn::new(blank_scope, selected_scope);

    let graphemes = vec![crate::types::Grapheme {
        byte_range: crate::test_support::byte_range(0, 1),
        pos: None,
        display_col: DisplayLineCol::new(0),
        width: 1,
        content: crate::types::CellContent::Grapheme,
        indent_depth: 0,
        scope: None,
    }];
    let dls = [crate::types::DisplayLine {
        kind: DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(0),
        },
        graphemes: 0..1,
    }];
    let styles = vec![crate::types::ResolvedStyle::default()];
    let gutter_columns: Vec<(ProviderId, Box<dyn GutterColumn>)> =
        vec![(0, Box::new(empty_lane)), (1, Box::new(content_lane))];
    let visible = crate::layout::PaneGeometry {
        content_width: crate::pipeline::ContentWidth::for_test(6),
        gutter_width: 2, // 0 (empty_lane) + 2 (the line numbers)
        last_line_idx: RopeyLine::new(0),
    };
    let pane_rect = Rect {
        x: 0,
        y: 0,
        width: 8,
        height: 1,
    };
    let mut buf = Grid::new(pane_rect.width, pane_rect.height);
    let mut theme = Theme::default();
    theme.bake(&registry);
    let rope = ropey::Rope::from_str("x\n");
    let lane_widths = vec![0u16, 2u16];
    let compose_ctx = crate::render::ComposeCtx {
        gutter_columns: &gutter_columns,
        visible: &visible,
        horizontal_offset: DisplayLineCol::new(0),
        mode: EditorMode::Normal,
        primary_head_line: ContentLine::new(0),
        tab_width: 4,
        tilde_style: ResolvedStyle::default(),
        indent_guide_style: ResolvedStyle::default(),
        indent_guides: true,
        pane_rect,
        theme: &theme,
        rope: &rope,
        default_gutter_scope: blank_scope,
        gutter: inputs(0),
    };
    let mut canvas = crate::render::Canvas::new(&mut buf, theme.ui.invisible, None);
    crate::render::compose_display_line(
        &render_display_line(&dls[0], &graphemes, "x", ""),
        &styles,
        0,
        &lane_widths,
        &compose_ctx,
        &mut canvas,
        None,
    );

    let sym = |x: u16| buf.cell(x, 0).unwrap().text().to_string();
    assert_eq!(
        sym(0),
        "1",
        "the line number starts right at x=0, unaffected by the width-0 column ahead of it"
    );
    assert_eq!(sym(1), " ", "separator cell");
    assert_eq!(sym(2), "x", "content starts exactly at gutter_width=2");
}

#[test]
fn sign_scope_resolves_via_baked_theme() {
    let mut registry = ScopeRegistry::new();
    let scope_id = registry.intern("diagnostic.error");
    let blank_scope = registry.intern("ui.linenr");
    let mut theme = theme_with([("diagnostic.error", fg(Rgb(255, 0, 0)))]);
    theme.bake(&registry);

    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![Sign {
            text: "!".into(),
            scope: scope_id,
            slot: 0,
        }],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(0),
            },
            &ctx(&rope, 2),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(theme.resolve(cell.scope).fg, Some(Rgb(255, 0, 0)));
}

#[test]
fn multi_slot_column_places_each_sign_in_its_own_slot() {
    let mut registry = ScopeRegistry::new();
    let a = registry.intern("a");
    let b = registry.intern("b");
    let c = registry.intern("c");
    let blank_scope = registry.intern("ui.linenr");

    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![
            Sign {
                text: "!".into(),
                scope: a,
                slot: 0,
            },
            Sign {
                text: "+".into(),
                scope: b,
                slot: 1,
            },
            // Ranked below the column's 2 configured slots, so silently dropped.
            Sign {
                text: "~".into(),
                scope: c,
                slot: 2,
            },
        ],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope); // 2 sign slots

    let rope = ropey::Rope::new();
    let cells = lane.render_cells(
        DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(0),
        },
        &ctx(&rope, 3),
    );
    assert_eq!(cells.len(), 2, "width-3 column = 2 sign slots");
    assert_eq!(cells[0].as_str(), "!", "slot 0");
    assert_eq!(cells[1].as_str(), "+", "slot 1");
}

#[test]
fn multi_slot_column_pads_with_blank_when_fewer_signs_than_slots() {
    let mut registry = ScopeRegistry::new();
    let a = registry.intern("a");
    let blank_scope = registry.intern("ui.linenr");

    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![Sign {
            text: "!".into(),
            scope: a,
            slot: 0,
        }],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope); // 2 sign slots

    let rope = ropey::Rope::new();
    let cells = lane.render_cells(
        DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(0),
        },
        &ctx(&rope, 3),
    );
    assert_eq!(cells.len(), 2, "still 2 cells, padded to slot count");
    assert_eq!(cells[0].as_str(), "!");
    assert_eq!(cells[1].as_str(), " ", "unclaimed slot is blank");
}

#[test]
fn width_one_column_keeps_no_signs() {
    let mut registry = ScopeRegistry::new();
    let a = registry.intern("a");
    let blank_scope = registry.intern("ui.linenr");

    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![Sign {
            text: "!".into(),
            scope: a,
            slot: 0,
        }],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope); // 0 sign slots

    let rope = ropey::Rope::new();
    let cells = lane.render_cells(
        DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(0),
        },
        &ctx(&rope, 1),
    );
    assert!(cells.is_empty(), "width-1 column has 0 sign slots");
}

/// Multi-slot sign columns must render through the full `compose_gutter`
/// path, not just `render_cells` in isolation. This test catches the
/// bug where the `usable_per_cell` formula was wrong, causing all signs
/// to be truncated to empty.
#[test]
fn multi_slot_column_renders_through_compose_gutter() {
    let mut registry = ScopeRegistry::new();
    let a = registry.intern("a");
    let b = registry.intern("b");
    let blank_scope = registry.intern("ui.linenr");

    let source = FixedSign {
        line: ContentLine::new(0),
        signs: vec![
            Sign {
                text: "!".into(),
                scope: a,
                slot: 0,
            },
            Sign {
                text: "+".into(),
                scope: b,
                slot: 1,
            },
        ],
    };
    let lane = SignColumn::new(Box::new(source), blank_scope); // 2 sign slots

    let graphemes = vec![crate::types::Grapheme {
        byte_range: crate::test_support::byte_range(0, 1),
        pos: None,
        display_col: DisplayLineCol::new(0),
        width: 1,
        content: crate::types::CellContent::Grapheme,
        indent_depth: 0,
        scope: None,
    }];
    let dls = [crate::types::DisplayLine {
        kind: DisplayLineKind::LineStart {
            line_idx: RopeyLine::new(0),
        },
        graphemes: 0..1,
    }];
    let styles = vec![crate::types::ResolvedStyle::default()];
    let gutter_columns: Vec<(ProviderId, Box<dyn GutterColumn>)> = vec![(0, Box::new(lane))];
    let visible = crate::layout::PaneGeometry {
        content_width: crate::pipeline::ContentWidth::for_test(5),
        gutter_width: 3,
        last_line_idx: RopeyLine::new(0),
    };
    let pane_rect = Rect {
        x: 0,
        y: 0,
        width: 8,
        height: 1,
    };
    let mut buf = Grid::new(pane_rect.width, pane_rect.height);
    let mut theme = Theme::default();
    theme.bake(&registry);
    let rope = ropey::Rope::from_str("x\n");
    let lane_widths = vec![3u16];
    let compose_ctx = crate::render::ComposeCtx {
        gutter_columns: &gutter_columns,
        visible: &visible,
        horizontal_offset: DisplayLineCol::new(0),
        mode: EditorMode::Normal,
        primary_head_line: ContentLine::new(0),
        tab_width: 4,
        tilde_style: ResolvedStyle::default(),
        indent_guide_style: ResolvedStyle::default(),
        indent_guides: true,
        pane_rect,
        theme: &theme,
        rope: &rope,
        default_gutter_scope: blank_scope,
        gutter: inputs(3),
    };
    let mut canvas = crate::render::Canvas::new(&mut buf, theme.ui.invisible, None);
    crate::render::compose_display_line(
        &render_display_line(&dls[0], &graphemes, "x", ""),
        &styles,
        0,
        &lane_widths,
        &compose_ctx,
        &mut canvas,
        None,
    );

    let sym = |x: u16| buf.cell(x, 0).unwrap().text().to_string();
    assert_eq!(sym(0), "!", "first sign slot renders");
    assert_eq!(sym(1), "+", "second sign slot renders");
    assert_eq!(sym(2), " ", "column right padding");
    assert_eq!(sym(3), "x", "content starts at gutter_width");
}
