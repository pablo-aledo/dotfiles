use crate::providers::{GutterCell, GutterCellContent, GutterColumn, GutterInputs};
use crate::types::{DisplayLineKind, ScopeId};

// Line number style

/// How line numbers are displayed in the gutter.
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq)]
pub enum LineNumberStyle {
    /// 1-based absolute line numbers.
    Absolute,
    /// Distance from the cursor line (0 at the cursor, counting outward).
    Relative,
    /// Absolute number on the cursor line, relative everywhere else.
    #[default]
    Hybrid,
}

// LineNumberColumn

/// Built-in gutter column that renders line numbers, in the style
/// [`GutterInputs::line_numbers`](crate::providers::GutterInputs) names.
///
/// Width is computed dynamically: `floor(log10(total_lines)) + 1` digits plus
/// one space of padding on the right.
pub struct LineNumberColumn {
    /// Interned `"ui.linenr"`: every display line but the primary head line.
    default_scope: ScopeId,
    /// Interned `"ui.linenr.selected"`: the primary selection's head line.
    selected_scope: ScopeId,
}

impl LineNumberColumn {
    /// `default_scope`/`selected_scope` are interned by the caller (once, at
    /// pane construction), the same intern-at-construction contract as every
    /// other provider (`DecorationSource`, `SignSource`).
    pub fn new(default_scope: ScopeId, selected_scope: ScopeId) -> Self {
        Self {
            default_scope,
            selected_scope,
        }
    }
}

/// Number of base-10 digits needed to write `n`, with `0` counting as one
/// digit. The single source of truth for how wide a line number renders,
/// shared by this gutter column and the statusline's `line:col` element:
/// both size a field around the largest line number they can show, and a
/// change to that sizing (a minimum width, a different numbering base)
/// has to reach both or they disagree on screen.
pub fn digit_count(n: usize) -> u8 {
    if n == 0 { 1 } else { n.ilog10() as u8 + 1 }
}

impl GutterColumn for LineNumberColumn {
    fn width(&self, last_line_idx: hume_rope::line::RopeyLine, _inputs: GutterInputs) -> u8 {
        // Digits needed to display the 1-based line number, plus 1 space of
        // right-padding. `last_line_idx` is the phantom-inclusive
        // `hume_rope::lines::last_ropey_line` (see `layout::compute_viewport`),
        // so this sizes for `content_line_count() + 1` digits, one
        // wider than content strictly needs. The statusline's own line-digit
        // field (`hume-editor/src/statusline/elements/position.rs`) instead sizes for
        // `content_line_count()`: an accidental, shipped divergence, not a
        // bug to fix here.
        digit_count(last_line_idx.index() + 1).saturating_add(1)
    }

    fn render_cells(
        &self,
        kind: DisplayLineKind,
        ctx: &crate::providers::GutterCtx,
    ) -> Vec<GutterCell> {
        // Widened from the content domain: `DisplayLineKind::LineStart`'s own field is
        // ropey domain (see its doc), so the comparison needs both sides in
        // the same one. The widening is a no-op in practice: a real render
        // walk (`DisplayLineMap`) never emits a `LineStart` for the phantom line.
        let primary_head_line: hume_rope::line::RopeyLine = ctx.primary_head_line.into();
        let cell = match kind {
            DisplayLineKind::Filler
            | DisplayLineKind::Virtual { .. }
            | DisplayLineKind::Wrap { .. } => GutterCell::blank(self.default_scope),
            DisplayLineKind::LineStart { line_idx } => {
                let scope = if line_idx == primary_head_line {
                    self.selected_scope
                } else {
                    self.default_scope
                };

                // `+ 1`, not `.number()`: that method belongs to `ContentLine`
                // only, since a ropey-domain line has no meaningful 1-based
                // display number to begin with (the phantom line has no
                // number a user would ever see), and this plain escape-hatch
                // arithmetic mirrors `width()`'s own `last_line_idx.index() + 1`.
                let display_num = match ctx.inputs.line_numbers {
                    LineNumberStyle::Absolute => line_idx.index() + 1,
                    LineNumberStyle::Relative => (line_idx.index() as isize
                        - primary_head_line.index() as isize)
                        .unsigned_abs(),
                    LineNumberStyle::Hybrid => {
                        if line_idx == primary_head_line {
                            line_idx.index() + 1 // absolute on the primary selection head line
                        } else {
                            (line_idx.index() as isize - primary_head_line.index() as isize)
                                .unsigned_abs()
                        }
                    }
                };

                GutterCell {
                    content: GutterCellContent::from_number(display_num),
                    scope,
                }
            }
        };
        vec![cell]
    }
}

#[cfg(test)]
mod tests;
