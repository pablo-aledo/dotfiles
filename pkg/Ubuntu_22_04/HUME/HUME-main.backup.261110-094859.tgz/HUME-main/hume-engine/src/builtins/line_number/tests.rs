use super::*;
use crate::providers::{GutterCtx, GutterInputs};
use crate::types::{DisplayLineKind, EditorMode, ScopeId};
use hume_rope::line::{ContentLine, RopeyLine};

const DEFAULT_SCOPE: ScopeId = ScopeId(0);
const SELECTED_SCOPE: ScopeId = ScopeId(1);

/// `LineNumberColumn` never reads `rope`, so an empty rope is fine
/// for every test here; only `primary_head_line` and the style vary.
fn ctx(rope: &ropey::Rope, primary_head_line: usize, style: LineNumberStyle) -> GutterCtx<'_> {
    GutterCtx {
        mode: EditorMode::Normal,
        primary_head_line: ContentLine::new(primary_head_line),
        rope,
        inputs: GutterInputs {
            line_numbers: style,
            ..GutterInputs::default()
        },
    }
}

#[test]
fn width_grows_with_line_count() {
    // width(max_line) must fit the 1-based line number max_line+1.
    // digit_count(n+1) + 1 pad.
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    assert_eq!(lane.width(RopeyLine::new(0), GutterInputs::default()), 2); // max line "1" → 1 digit + 1 pad
    assert_eq!(lane.width(RopeyLine::new(8), GutterInputs::default()), 2); // max line "9" → 1 digit + 1 pad
    assert_eq!(lane.width(RopeyLine::new(9), GutterInputs::default()), 3); // max line "10" → 2 digits + 1 pad
    assert_eq!(lane.width(RopeyLine::new(10), GutterInputs::default()), 3); // max line "11" → 2 digits + 1 pad
    assert_eq!(lane.width(RopeyLine::new(98), GutterInputs::default()), 3); // max line "99" → 2 digits + 1 pad
    assert_eq!(lane.width(RopeyLine::new(99), GutterInputs::default()), 4); // max line "100" → 3 digits + 1 pad
    assert_eq!(lane.width(RopeyLine::new(100), GutterInputs::default()), 4); // max line "101" → 3 digits + 1 pad
}

#[test]
fn absolute_line_numbers() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(4),
            },
            &ctx(&rope, 0, LineNumberStyle::Absolute),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "5"); // 1-based
}

#[test]
fn hybrid_head_line_shows_absolute() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    // Cursor is on line 2 (0-based).
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(2),
            },
            &ctx(&rope, 2, LineNumberStyle::Hybrid),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "3"); // absolute
    assert_eq!(cell.scope, SELECTED_SCOPE);
}

#[test]
fn hybrid_non_head_line_shows_relative() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(5),
            },
            &ctx(&rope, 2, LineNumberStyle::Hybrid),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "3"); // |5-2| = 3
}

#[test]
fn wrap_display_lines_are_blank() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::Wrap {
                line_idx: RopeyLine::new(3),
                wrap_index: 1,
            },
            &ctx(&rope, 0, LineNumberStyle::Hybrid),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), " "); // blank
}

#[test]
fn virtual_display_lines_are_blank() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::Virtual {
                provider_id: 0,
                anchor_line: RopeyLine::new(0),
            },
            &ctx(&rope, 0, LineNumberStyle::Hybrid),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), " ");
}

#[test]
fn relative_line_numbers() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    // Cursor at line 5 (0-based). Line 3 is distance 2, line 8 is distance 3.
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(3),
            },
            &ctx(&rope, 5, LineNumberStyle::Relative),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "2");
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(8),
            },
            &ctx(&rope, 5, LineNumberStyle::Relative),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "3");
}

#[test]
fn relative_head_line_shows_zero() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(5),
            },
            &ctx(&rope, 5, LineNumberStyle::Relative),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "0");
}

#[test]
fn hybrid_line_below_head_shows_relative() {
    // Cursor at line 5, render line 2 (below in the file, higher index than cursor).
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(2),
            },
            &ctx(&rope, 5, LineNumberStyle::Hybrid),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "3"); // |2-5| = 3
}

#[test]
fn digit_count_zero_is_one() {
    assert_eq!(super::digit_count(0), 1);
}

#[test]
fn large_line_number_renders_correctly() {
    let lane = LineNumberColumn::new(DEFAULT_SCOPE, SELECTED_SCOPE);
    let rope = ropey::Rope::new();
    // line_idx = 9_999_998 → display = 9_999_999 (1-based)
    let cell = lane
        .render_cells(
            DisplayLineKind::LineStart {
                line_idx: RopeyLine::new(9_999_998),
            },
            &ctx(&rope, 0, LineNumberStyle::Absolute),
        )
        .into_iter()
        .next()
        .unwrap();
    assert_eq!(cell.as_str(), "9999999");
}
