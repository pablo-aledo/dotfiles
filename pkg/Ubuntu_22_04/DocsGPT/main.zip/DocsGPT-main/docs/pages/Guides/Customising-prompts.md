## To customize a main prompt, navigate to `/application/prompt/combine_prompt.txt`

You can try editing it to see how the model responses.

