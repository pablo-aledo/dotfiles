export { DocsGPTWidget } from "./DocsGPTWidget";
