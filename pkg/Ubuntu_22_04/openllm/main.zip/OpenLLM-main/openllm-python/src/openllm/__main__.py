if __name__ == '__main__':
  from openllm_cli.entrypoint import cli

  cli()
