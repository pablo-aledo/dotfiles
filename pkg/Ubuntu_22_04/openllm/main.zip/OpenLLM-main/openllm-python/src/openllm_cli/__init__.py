"""OpenLLM CLI.

For more information see ``openllm -h``.
"""
