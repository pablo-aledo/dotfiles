> [!IMPORTANT]
> The files in this directory are generated during the build process. **Do not edit it directly.**
>
> For more information, see the `openllm.build` namespace, as well as it's reference in the `shadow-cljs.edn` file. The documentation can be found [here](https://shadow-cljs.github.io/docs/UsersGuide.html#build-hooks) and [here](https://shadow-cljs.github.io/docs/UsersGuide.html#compile-stages).
