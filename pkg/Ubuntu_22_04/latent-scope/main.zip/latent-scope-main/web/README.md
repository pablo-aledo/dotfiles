# Web UI

```bash
npm install
npm run dev
```