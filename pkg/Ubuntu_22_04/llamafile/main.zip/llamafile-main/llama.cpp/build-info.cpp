int LLAMA_BUILD_NUMBER = 1500;
char const *LLAMA_COMMIT = "a30b324";
char const *LLAMA_COMPILER = "cosmocc (GCC) 11.2.0";
char const *LLAMA_BUILD_TARGET = "x86_64-linux-cosmo";
