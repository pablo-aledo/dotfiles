#pragma once
// stub imports to keep mkdeps/cuda/metal happy and avoid -iquote flags
#include "llamafile/llamafile.h"
