# Store listing — Nederlands (Nederland) (nl-nl)

<!-- Format: see en-us.md. -->

## Title

LYNX SHARE

## Short description

Gratis, opensource DAW met drie werkwijzen in één programma: patterns in FL Studio-stijl (Channel Rack, Piano Roll, Playlist, Mixer), clips starten in Ableton Live-stijl en een eenvoudige modus met één venster in de stijl van BandLab en FL Studio Mobile. Opent .flp-, .als- en .flm-projecten.

## Description

LYNX SHARE is een gratis, opensource digital audio workstation om beats en nummers te maken. Hij heeft drie werkwijzen
in één programma, en je kunt er op elk moment tussen wisselen zonder het project te veranderen:

• Patterns in FL Studio-stijl (de standaard): een Channel Rack met stepsequencer, patterns, een Piano Roll, een Playlist
met arrangementen en een Mixer met inserts, sends en sidechain.
• Clips starten in de stijl van Ableton Live: een raster met clips en scènes, een sessiemixer en de clip- en apparaatweergave.
• Een Eenvoudige werkwijze die de toegankelijke stijl met één venster van BandLab samenbrengt met de werkwijze van FL
Studio Mobile: tracks en een tijdlijn, loops, pads en snel opnemen, met een begeleid eerste nummer.

Hij is gebouwd om licht en snel te blijven op elke pc.

• Licht: een lock-free audio-engine die kanalen en mixertracks over je processorkernen verdeelt, inactieve kanalen overslaat en lange audiobestanden rechtstreeks van schijf streamt.
• Compleet: meer dan 100 ingebouwde instrumenten en effecten — synths, drumcomputers, samplers, EQ's, compressors, limiters, reverbs, delays, toonhoogtecorrectie, visualizers en meer.
• Je eigen plugins: host VST3-, CLAP- en VST2-instrumenten en -effecten, elk optioneel in een eigen sandboxproces, zodat een crashende plugin je sessie niet onderuit haalt.
• Je projecten: opent FL Studio-projecten (.flp) met patterns, noten, mixer, automatisering en samples; opent en
bewaart Ableton Live 11/12-sets (.als), inclusief Session-clips; exporteert .flp terug naar FL Studio; importeert FL
Studio Mobile-projecten (.flm, gedeeltelijk) en MIDI-bestanden.
• Lage latency: ASIO (inclusief de eigen ASIO-driver van LYNX SHARE voor elk apparaat), WASAPI in gedeelde en exclusieve modus.
• Neem audio en MIDI op, bewerk audio, automatiseer alles en exporteer naar WAV, FLAC, MP3, OGG of stems.
• Interface in 15 talen, waaronder Nederlands, Engels, Portugees, Spaans, Frans, Duits, Italiaans, Pools, Russisch, Turks, Japans, Koreaans en Chinees.

Geen account, geen abonnement, geen advertenties en geen telemetrie. LYNX SHARE is vrije software (GNU AGPL-3.0); de broncode staat op GitHub.

LYNX SHARE is een onafhankelijk project, niet verbonden aan of goedgekeurd door Image-Line of Ableton. FL Studio en FL
Studio Mobile zijn handelsmerken van Image-Line Software; Ableton en Live zijn handelsmerken van Ableton AG. Andere
productnamen zijn handelsmerken van hun respectieve eigenaars.

LYNX SHARE is in alfa: verwacht nog wat ruwe randjes en meld problemen alsjeblieft op GitHub.

## What's new

LYNX SHARE 0.1.28: sneller en lichter, met het venster in ongeveer een seconde klaar, grote projecten die sneller
openen en minder geheugen gebruiken, soepeler afspelen, stems die in één keer worden geëxporteerd en vooruit renderen
voor zware projecten bij kleine buffers; Ableton Link; Freeze en Bounce in de Clipstart-werkwijze; clip-envelopes;
samples die op plugins worden gesleept; meer eigen devices van Ableton Live die uit .als-sets worden geopend;
fabrieksgeluiden van FL Studio Mobile uit je eigen kopie van de app; een Sampler met 16 pads in de Eenvoudige
werkwijze; Preset opslaan voor de ingebouwde instrumenten; een experimentele Remote Control API; Playlist-tracks die
aan hun rand van grootte veranderen, Ctrl+klik om meerdere tracks te selecteren, en Playlist-tracks gekoppeld aan
mixertracks; en veel fixes.

## Features

1. Drie werkwijzen in één programma: patterns in FL Studio-stijl als standaard, clips starten in Ableton Live-stijl, of een Eenvoudige werkwijze in de stijl van BandLab en FL Studio Mobile
2. Opent FL Studio- (.flp), Ableton Live- (.als) en FL Studio Mobile-projecten (.flm) en MIDI-bestanden; bewaart .als en .flp
3. Meer dan 100 ingebouwde instrumenten en effecten
4. Host VST3-, CLAP- en VST2-plugins, optioneel gesandboxt in een eigen proces
5. Audio met lage latency: ASIO, WASAPI gedeeld en exclusief
6. Multicore-engine die ook op oudere pc's licht blijft
7. Audio- en MIDI-opname, audio-editor, automatiseringsclips
8. Exporteer naar WAV, FLAC, MP3, OGG en stems
9. Interface in 15 talen, waaronder het Nederlands
10. Gratis en open source (AGPL-3.0): geen account, geen advertenties, geen telemetrie

## Search terms

- DAW
- muziekproductie
- beats maken
- muziekstudio
- audio-editor
- MIDI-sequencer
- VST-host

## Screenshot captions

- 01-workspace.png — De LYNX-werkruimte: browser, Playlist, Piano Roll, Channel Rack en Mixer
- 02-playlist.png — Arrangeer patronen, audio en automatisering in de Playlist
- 03-piano-roll.png — Schrijf melodieën en akkoorden in de Piano Roll
- 04-mixer.png — Mix met inserts, sends, sidechain en ingebouwde effecten
- 05-instruments-effects.png — Stepsequencer, ingebouwde synths en de parametrische EQ
