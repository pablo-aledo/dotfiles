# Store listing — Deutsch (de-de)

<!-- Format: see en-us.md. -->

## Title

LYNX SHARE

## Short description

Kostenlose, quelloffene DAW mit drei Arbeitsabläufen in einem Programm: Patterns im Stil von FL Studio (Channel Rack, Piano Roll, Playlist, Mixer), Clip-Start im Stil von Ableton Live und ein einfacher Ein-Fenster-Modus im Stil von BandLab und FL Studio Mobile. Öffnet .flp-, .als- und .flm-Projekte.

## Description

LYNX SHARE ist eine kostenlose, quelloffene Digital Audio Workstation für Beats und Songs. Sie hat drei Arbeitsabläufe
in einem Programm, und du kannst jederzeit zwischen ihnen wechseln, ohne das Projekt zu ändern:

• Patterns im Stil von FL Studio (der Standard): ein Channel Rack mit Step-Sequencer, Patterns, eine Piano Roll, eine
Playlist mit Arrangements und ein Mixer mit Inserts, Sends und Sidechain.
• Clips starten im Stil von Ableton Live: ein Raster aus Clips und Szenen, ein Session-Mixer sowie Clip- und Geräteansicht.
• Ein Einfacher Arbeitsablauf, der den zugänglichen Ein-Fenster-Stil von BandLab mit der Arbeitsweise von FL Studio
Mobile verbindet: Spuren und Zeitleiste, Loops, Pads und schnelle Aufnahme, mit einem geführten ersten Song.

Sie ist darauf gebaut, auf jedem PC schlank und schnell zu bleiben.

• Schlank: eine Lock-free-Audio-Engine, die Kanäle und Mixer-Spuren auf deine CPU-Kerne verteilt, inaktive Kanäle überspringt und lange Audiodateien direkt von der Festplatte streamt.
• Komplett: über 100 integrierte Instrumente und Effekte – Synthesizer, Drum Machines, Sampler, EQs, Kompressoren, Limiter, Reverbs, Delays, Tonhöhenkorrektur, Visualizer und mehr.
• Deine Plugins: lädt VST3-, CLAP- und VST2-Instrumente und -Effekte, auf Wunsch jeweils in einem eigenen Sandbox-Prozess, damit ein abstürzendes Plugin nicht deine ganze Session mitreißt.
• Deine Projekte: öffnet FL-Studio-Projekte (.flp) mit Patterns, Noten, Mixer, Automation und Samples; öffnet und
speichert Sets aus Ableton Live 11/12 (.als), samt Session-Clips; exportiert .flp zurück nach FL Studio; importiert
Projekte aus FL Studio Mobile (.flm, teilweise) und MIDI-Dateien.
• Niedrige Latenz: ASIO (einschließlich des eigenen ASIO-Treibers von LYNX SHARE für jedes Gerät), WASAPI im Shared- und Exclusive-Modus.
• Audio und MIDI aufnehmen, Audio bearbeiten, alles automatisieren, als WAV, FLAC, MP3, OGG oder Stems rendern.
• Oberfläche in 15 Sprachen, darunter Deutsch, Englisch, Französisch, Spanisch, Italienisch, Niederländisch, Polnisch, Russisch, Türkisch, Japanisch, Koreanisch und Chinesisch.

Kein Konto, kein Abo, keine Werbung und keine Telemetrie. LYNX SHARE ist freie Software (GNU AGPL-3.0); der Quellcode liegt auf GitHub.

LYNX SHARE ist ein unabhängiges Projekt, weder mit Image-Line oder Ableton verbunden noch von ihnen unterstützt. FL
Studio und FL Studio Mobile sind Marken von Image-Line Software; Ableton und Live sind Marken der Ableton AG. Andere
Produktnamen sind Marken ihrer jeweiligen Inhaber.

LYNX SHARE befindet sich im Alpha-Stadium: Rechne mit Ecken und Kanten und melde Probleme bitte auf GitHub.

## What's new

LYNX SHARE 0.1.28: schneller und leichter, mit einem Fenster, das nach etwa einer Sekunde bereit ist, großen
Projekten, die schneller öffnen und weniger Speicher brauchen, flüssigerer Wiedergabe, Stems in einem Durchgang
exportiert und Vorausberechnen für schwere Projekte bei kleinen Puffern; Ableton Link; Freeze und Bounce im
Clip-Start-Arbeitsablauf; Clip-Hüllkurven; auf Plugins gezogene Samples; mehr eigene Devices von Ableton Live, die aus
.als-Sets geöffnet werden; Werkssounds von FL Studio Mobile aus deiner eigenen Kopie der App; ein Sampler mit 16 Pads
im Einfachen Arbeitsablauf; Preset speichern für die eingebauten Instrumente; eine experimentelle Remote-Control-API;
Playlist-Spuren, die sich am Rand in der Größe ändern lassen, Strg+Klick zum Auswählen mehrerer Spuren und mit
Mixer-Spuren verknüpfte Playlist-Spuren; und viele Korrekturen.

## Features

1. Drei Arbeitsabläufe in einem Programm: Patterns im Stil von FL Studio als Standard, Clip-Start im Stil von Ableton Live oder ein Einfacher Arbeitsablauf im Stil von BandLab und FL Studio Mobile
2. Öffnet Projekte aus FL Studio (.flp), Ableton Live (.als) und FL Studio Mobile (.flm) sowie MIDI-Dateien; speichert .als und .flp
3. Über 100 integrierte Instrumente und Effekte
4. Lädt VST3-, CLAP- und VST2-Plugins, auf Wunsch isoliert im eigenen Prozess
5. Audio mit niedriger Latenz: ASIO, WASAPI Shared und Exclusive
6. Multicore-Engine, die auch auf älteren PCs schlank bleibt
7. Audio- und MIDI-Aufnahme, Audio-Editor, Automation-Clips
8. Export als WAV, FLAC, MP3, OGG und Stems
9. Oberfläche in 15 Sprachen, darunter Deutsch
10. Kostenlos und Open Source (AGPL-3.0): kein Konto, keine Werbung, keine Telemetrie

## Search terms

- DAW
- Musikproduktion
- Beats machen
- Musikstudio
- Audio-Editor
- MIDI-Sequencer
- VST-Host

## Screenshot captions

- 01-workspace.png — Der LYNX-Arbeitsbereich: Browser, Playlist, Piano Roll, Channel Rack und Mixer
- 02-playlist.png — Patterns, Audio und Automation in der Playlist arrangieren
- 03-piano-roll.png — Melodien und Akkorde in der Piano Roll schreiben
- 04-mixer.png — Mischen mit Inserts, Sends, Sidechain und integrierten Effekten
- 05-instruments-effects.png — Step-Sequencer, integrierte Synthesizer und der parametrische EQ
