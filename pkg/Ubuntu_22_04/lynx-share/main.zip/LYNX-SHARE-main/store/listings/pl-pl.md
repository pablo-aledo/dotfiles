# Store listing — Polski (pl-pl)

<!-- Format: see en-us.md. -->

## Title

LYNX SHARE

## Short description

Darmowy DAW o otwartym kodzie z trzema sposobami pracy w jednym programie: patterny w stylu FL Studio (Channel Rack, Piano Roll, Playlist, Mixer), uruchamianie klipów w stylu Ableton Live i prosty tryb w jednym oknie w stylu BandLab i FL Studio Mobile. Otwiera projekty .flp, .als i .flm.

## Description

LYNX SHARE to darmowa cyfrowa stacja robocza audio o otwartym kodzie do tworzenia bitów i utworów. Ma trzy sposoby pracy
w jednym programie i możesz przełączać się między nimi w dowolnej chwili, bez zmiany projektu:

• Patterny w stylu FL Studio (domyślnie): Channel Rack z sekwencerem krokowym, patterny, Piano Roll, Playlist z
aranżacjami i Mixer z insertami, sendami i sidechainem.
• Uruchamianie klipów w stylu Ableton Live: siatka klipów i scen, mikser sesji oraz widok klipu i urządzeń.
• Prosty sposób pracy, który łączy przystępny, jednookienkowy styl BandLab ze sposobem pracy FL Studio Mobile: ścieżki
i oś czasu, pętle, pady i szybkie nagrywanie, z prowadzonym pierwszym utworem.

Został zbudowany tak, by pozostać lekki i szybki na każdym PC.

• Lekki: silnik audio bez blokad (lock-free), który rozkłada kanały i ścieżki miksera na rdzenie procesora, pomija nieaktywne kanały i strumieniuje długie pliki audio prosto z dysku.
• Kompletny: ponad 100 wbudowanych instrumentów i efektów – syntezatory, automaty perkusyjne, samplery, korektory EQ, kompresory, limitery, pogłosy, delaye, korekcja wysokości dźwięku, wizualizery i wiele więcej.
• Twoje wtyczki: obsługuje instrumenty i efekty VST3, CLAP i VST2, opcjonalnie każdy we własnym procesie (sandbox), więc crash wtyczki nie położy całej sesji.
• Twoje projekty: otwiera projekty FL Studio (.flp) z patternami, nutami, mikserem, automatyką i samplami; otwiera i
zapisuje sety Ableton Live 11/12 (.als) razem z klipami z Session; eksportuje .flp z powrotem do FL Studio; importuje
projekty FL Studio Mobile (.flm, częściowo) i pliki MIDI.
• Niskie opóźnienia: ASIO (w tym własny sterownik ASIO LYNX SHARE dla dowolnego urządzenia), WASAPI w trybie współdzielonym i wyłącznym.
• Nagrywaj audio i MIDI, edytuj audio, automatyzuj wszystko, renderuj do WAV, FLAC, MP3, OGG lub stemów.
• Interfejs w 15 językach, w tym po polsku, angielsku, portugalsku, hiszpańsku, francusku, niemiecku, włosku, niderlandzku, rosyjsku, turecku, japońsku, koreańsku i chińsku.

Bez konta, bez subskrypcji, bez reklam i bez telemetrii. LYNX SHARE to wolne oprogramowanie (GNU AGPL-3.0); kod źródłowy jest dostępny na GitHubie.

LYNX SHARE to niezależny projekt, niepowiązany z Image-Line ani Ableton i przez nie niepopierany. FL Studio i FL
Studio Mobile to znaki towarowe Image-Line Software; Ableton i Live to znaki towarowe Ableton AG. Inne nazwy produktów
są znakami towarowymi ich właścicieli.

LYNX SHARE jest w fazie alfa: możesz trafić na niedoróbki – zgłaszaj problemy na GitHubie.

## What's new

LYNX SHARE 0.1.28: szybciej i lżej, z oknem gotowym po około sekundzie, dużymi projektami, które otwierają się
szybciej i zajmują mniej pamięci, płynniejszym odtwarzaniem, stemami eksportowanymi w jednym przebiegu i renderowaniem
z wyprzedzeniem dla ciężkich projektów przy małych buforach; Ableton Link; Freeze i Bounce w Pracy z uruchamianiem
klipów; obwiednie klipów; sample przeciągane na pluginy; więcej własnych urządzeń Ableton Live otwieranych z setów
.als; fabryczne brzmienia FL Studio Mobile z własnej kopii aplikacji; 16-padowy Sampler w Prostym sposobie pracy;
Zapisz preset dla wbudowanych instrumentów; eksperymentalne Remote Control API; ścieżki Playlisty zmieniające rozmiar
za krawędź, Ctrl+klik do zaznaczania kilku ścieżek i ścieżki Playlisty połączone ze ścieżkami miksera; oraz wiele
poprawek.

## Features

1. Trzy sposoby pracy w jednym programie: domyślnie patterny w stylu FL Studio, uruchamianie klipów w stylu Ableton Live albo Prosty sposób pracy w stylu BandLab i FL Studio Mobile
2. Otwiera projekty FL Studio (.flp), Ableton Live (.als) i FL Studio Mobile (.flm) oraz pliki MIDI; zapisuje .als i .flp
3. Ponad 100 wbudowanych instrumentów i efektów
4. Obsługuje wtyczki VST3, CLAP i VST2, opcjonalnie izolowane we własnym procesie
5. Audio o niskich opóźnieniach: ASIO, WASAPI współdzielony i wyłączny
6. Wielordzeniowy silnik, który pozostaje lekki nawet na starszych PC
7. Nagrywanie audio i MIDI, edytor audio, klipy automatyki
8. Eksport do WAV, FLAC, MP3, OGG i stemów
9. Interfejs w 15 językach, w tym po polsku
10. Darmowy i open source (AGPL-3.0): bez konta, bez reklam, bez telemetrii

## Search terms

- DAW
- produkcja muzyczna
- tworzenie bitów
- studio muzyczne
- edytor audio
- sekwencer MIDI
- host VST

## Screenshot captions

- 01-workspace.png — Obszar roboczy LYNX SHARE: przeglądarka, Playlist, Piano Roll, Channel Rack i Mixer
- 02-playlist.png — Aranżuj patterny, audio i automatykę w Playlist
- 03-piano-roll.png — Pisz melodie i akordy w Piano Roll
- 04-mixer.png — Miksuj z insertami, sendami, sidechainem i wbudowanymi efektami
- 05-instruments-effects.png — Sekwencer krokowy, wbudowane syntezatory i parametryczny korektor EQ
