# Store listing — Italiano (Italia) (it-it)

<!-- Format: see en-us.md. -->

## Title

LYNX SHARE

## Short description

DAW gratuita e open source con tre workflow in un solo programma: pattern in stile FL Studio (Channel Rack, Piano Roll, Playlist, Mixer), lancio di clip in stile Ableton Live e una modalità semplice a finestra unica in stile BandLab e FL Studio Mobile. Apre i progetti .flp, .als e .flm.

## Description

LYNX SHARE è una workstation audio digitale gratuita e open source per creare beat e brani. Ha tre workflow in un solo
programma, e puoi passare dall'uno all'altro in qualsiasi momento senza cambiare il progetto:

• Pattern in stile FL Studio (il predefinito): un Channel Rack con step sequencer, pattern, un Piano Roll, una Playlist
con arrangiamenti e un Mixer con insert, mandate e sidechain.
• Lancio di clip in stile Ableton Live: una griglia di clip e scene, un mixer della sessione e le viste clip e
dispositivo.
• Un Flusso semplice che unisce lo stile accessibile a finestra unica di BandLab al modo di lavorare di FL Studio
Mobile: tracce e timeline, loop, pad e registrazione rapida, con un primo brano guidato.

È pensata per restare leggera e veloce su qualsiasi PC.

• Leggera: un motore audio lock-free che distribuisce canali e tracce del mixer sui core della CPU, salta i canali inattivi e legge l'audio lungo direttamente dal disco.
• Completa: oltre 100 strumenti ed effetti integrati — sintetizzatori, drum machine, sampler, EQ, compressori, limiter, riverberi, delay, correzione dell'intonazione, visualizzatori e molto altro.
• I tuoi plugin: carica strumenti ed effetti VST3, CLAP e VST2, ognuno opzionalmente in un proprio processo isolato (sandbox), così un plugin che va in crash non fa cadere la tua sessione.
• I tuoi progetti: apre i progetti di FL Studio (.flp) con pattern, note, mixer, automazioni e sample; apre e salva i
set di Ableton Live 11/12 (.als), clip della Session comprese; esporta .flp verso FL Studio; importa i progetti di FL
Studio Mobile (.flm, in parte) e i file MIDI.
• Bassa latenza: ASIO (compreso il driver ASIO di LYNX SHARE, per qualsiasi dispositivo), WASAPI in modalità condivisa ed esclusiva.
• Registra audio e MIDI, modifica l'audio, automatizza qualsiasi parametro ed esporta in WAV, FLAC, MP3, OGG o stem.
• Interfaccia in 15 lingue, tra cui italiano, inglese, portoghese, spagnolo, francese, tedesco, olandese, polacco, russo, turco, giapponese, coreano e cinese.

Nessun account, nessun abbonamento, nessuna pubblicità e nessuna telemetria. LYNX SHARE è software libero (GNU AGPL-3.0); il codice sorgente è su GitHub.

LYNX SHARE è un progetto indipendente, non affiliato né approvato da Image-Line o Ableton. FL Studio e FL Studio
Mobile sono marchi di Image-Line Software; Ableton e Live sono marchi di Ableton AG. Gli altri nomi di prodotti sono
marchi dei rispettivi proprietari.

LYNX SHARE è in fase alpha: aspettati qualche imperfezione e segnala eventuali problemi su GitHub.

## What's new

LYNX SHARE 0.1.28: più veloce e leggero, con la finestra pronta in circa un secondo, grandi progetti che si aprono più
in fretta e usano meno memoria, riproduzione più fluida, stem esportati in un solo passaggio ed elaborazione in
anticipo per i progetti pesanti con buffer piccoli; Ableton Link; Freeze e Bounce nel Flusso a lancio di clip;
inviluppi delle clip; sample trascinati sui plugin; più dispositivi propri di Ableton Live aperti dai set .als; i
suoni di fabbrica di FL Studio Mobile dalla tua copia dell'app; un Sampler a 16 pad nel Flusso semplice; Salva preset
per gli strumenti integrati; una Remote Control API sperimentale; tracce della Playlist che si ridimensionano dal
bordo, Ctrl+clic per selezionare più tracce e tracce della Playlist collegate alle tracce del mixer; e molte
correzioni.

## Features

1. Tre workflow in un solo programma: pattern in stile FL Studio come predefinito, lancio di clip in stile Ableton Live o un Flusso semplice in stile BandLab e FL Studio Mobile
2. Apre i progetti di FL Studio (.flp), Ableton Live (.als) e FL Studio Mobile (.flm) e i file MIDI; salva .als e .flp
3. Oltre 100 strumenti ed effetti integrati
4. Carica plugin VST3, CLAP e VST2, opzionalmente isolati in un proprio processo
5. Audio a bassa latenza: ASIO, WASAPI condiviso ed esclusivo
6. Motore multi-core che resta leggero anche sui PC meno recenti
7. Registrazione audio e MIDI, editor audio, clip di automazione
8. Esportazione in WAV, FLAC, MP3, OGG e stem
9. Interfaccia in 15 lingue, incluso l'italiano
10. Gratuito e open source (AGPL-3.0): nessun account, nessuna pubblicità, nessuna telemetria

## Search terms

- DAW
- produzione musicale
- creare beat
- studio musicale
- editor audio
- sequencer MIDI
- host VST

## Screenshot captions

- 01-workspace.png — L'area di lavoro di LYNX SHARE: browser, Playlist, Piano Roll, Channel Rack e Mixer
- 02-playlist.png — Disponi pattern, audio e automazioni nella Playlist
- 03-piano-roll.png — Scrivi melodie e accordi nel Piano Roll
- 04-mixer.png — Mixa con insert, send, sidechain ed effetti integrati
- 05-instruments-effects.png — Step sequencer, sintetizzatori integrati ed EQ parametrico
