# Store listing — 日本語 (ja-jp)

<!-- Format: see en-us.md. -->

## Title

LYNX SHARE

## Short description

1つのプログラムに3つのワークフローを備えた無料・オープンソースのDAW。FL Studio風のパターン (Channel Rack、Piano Roll、Playlist、Mixer)、Ableton Live風のクリップ起動、BandLabとFL Studio Mobileのスタイルのシンプルな1ウィンドウモード。.flp、.als、.flmのプロジェクトを開けます。

## Description

LYNX SHAREは、ビートや曲を作るための無料・オープンソースのデジタルオーディオワークステーションです。1つのプログラムに3つのワークフローがあり、プロジェクトを変えずにいつでも切り替えられます。

• FL Studio風のパターン (既定): ステップシーケンサー付きChannel Rack、パターン、Piano Roll、アレンジ対応のPlaylist、インサート・センド・サイドチェーン付きのMixer。
• Ableton Live風のクリップ起動: クリップとシーンのグリッド、セッションミキサー、クリップビューとデバイスビュー。
• シンプルワークフロー: BandLabの親しみやすい1ウィンドウのスタイルにFL Studio Mobileの作り方を組み合わせ、トラックとタイムライン、ループ、パッド、すばやい録音、ガイド付きの最初の1曲を用意しています。

どんなPCでも軽快に動くよう作られています。

• 軽快：ロックフリーのオーディオエンジンがチャンネルとミキサートラックをCPUの各コアに分散。鳴っていないチャンネルは処理をスキップし、長いオーディオはディスクからストリーミング再生します。
• 充実：シンセ、ドラムマシン、サンプラー、EQ、コンプレッサー、リミッター、リバーブ、ディレイ、ピッチ補正、ビジュアライザーなど、100種類以上の内蔵インストゥルメントとエフェクト。
• お気に入りのプラグインも：VST3、CLAP、VST2のインストゥルメントとエフェクトをホスト。各プラグインを個別のサンドボックスプロセスで動かすこともでき、プラグインがクラッシュしてもセッションは落ちません。
• あなたのプロジェクト: FL Studioのプロジェクト (.flp) をパターン、ノート、ミキサー、オートメーション、サンプルごと開けます。Ableton Live 11/12のセット (.als) をSessionのクリップも含めて開いて保存でき、.flpとしてFL Studioへ書き出せ、FL Studio Mobileのプロジェクト (.flm、一部) とMIDIファイルもインポートできます。
• 低レイテンシー：ASIO（どのデバイスでも使えるLYNX SHARE独自のASIOドライバーを含む）、WASAPIの共有モードと排他モードに対応。
• オーディオとMIDIのレコーディング、オーディオ編集、あらゆるパラメーターのオートメーション、WAV・FLAC・MP3・OGG・ステムへの書き出し。
• インターフェース：日本語、英語、ポルトガル語、スペイン語、フランス語、ドイツ語、中国語、韓国語など15言語に対応。

アカウント登録、サブスクリプション、広告、テレメトリーは一切ありません。LYNX SHAREはフリーソフトウェア（GNU AGPL-3.0）で、ソースコードはGitHubで公開しています。

LYNX SHAREは独立したプロジェクトであり、Image-LineやAbletonとは提携しておらず、承認も受けていません。FL StudioとFL Studio MobileはImage-Line Softwareの、AbletonとLiveはAbleton AGの商標です。その他の製品名は各所有者の商標です。

LYNX SHAREはアルファ版です。粗削りな部分もありますので、問題を見つけたらGitHubでご報告ください。

## What's new

LYNX SHARE 0.1.28: より軽く、より速く。ウィンドウは約1秒で準備でき、大きなプロジェクトはより速く開いてメモリも節約し、再生はなめらかになり、ステムは1回で書き出され、小さいバッファーの重いプロジェクトにはrender-aheadが働きます。Ableton Link。クリップ起動ワークフローのFreezeとBounce。クリップエンベロープ。プラグインへのサンプルのドラッグ。.alsセットから開けるAbleton Live独自のデバイスの追加。お手持ちのアプリからのFL Studio Mobileのファクトリーサウンド。シンプルワークフローの16パッドのサンプラー。内蔵インストゥルメントのプリセット保存。試験的なRemote Control API。端をドラッグしてサイズを変えられるプレイリストのトラック、Ctrl+クリックによる複数トラックの選択、ミキサートラックにリンクしたプレイリストのトラック。そして多数の修正。

## Features

1. 1つのプログラムに3つのワークフロー: 既定はFL Studio風のパターン、Ableton Live風のクリップ起動、またはBandLabとFL Studio Mobileのスタイルのシンプルワークフロー
2. FL Studio (.flp)、Ableton Live (.als)、FL Studio Mobile (.flm) のプロジェクトとMIDIファイルを開き、.alsと.flpで保存
3. 100種類以上の内蔵インストゥルメントとエフェクト
4. VST3、CLAP、VST2プラグインをホスト。個別プロセスでのサンドボックス実行も可能
5. 低レイテンシーのオーディオ：ASIO、WASAPI共有モード・排他モード
6. 古いPCでも軽快に動くマルチコア対応エンジン
7. オーディオとMIDIのレコーディング、オーディオエディター、オートメーションクリップ
8. WAV、FLAC、MP3、OGG、ステムへの書き出し
9. 日本語を含む15言語のインターフェース
10. 無料のオープンソース（AGPL-3.0）：アカウント不要、広告なし、テレメトリーなし

## Search terms

- DAW
- DTM
- 作曲ソフト
- 音楽制作
- ビートメイク
- MIDIシーケンサー
- VSTホスト

## Screenshot captions

- 01-workspace.png — LYNX SHAREのワークスペース：ブラウザー、Playlist、Piano Roll、Channel Rack、Mixer
- 02-playlist.png — Playlistでパターン、オーディオ、オートメーションを並べてアレンジ
- 03-piano-roll.png — Piano Rollでメロディーやコードを打ち込み
- 04-mixer.png — インサート、センド、サイドチェイン、内蔵エフェクトでミックス
- 05-instruments-effects.png — ステップシーケンサー、内蔵シンセ、パラメトリックEQ
