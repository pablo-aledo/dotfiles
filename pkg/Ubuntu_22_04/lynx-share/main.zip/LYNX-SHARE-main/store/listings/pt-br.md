# Store listing — Português (Brasil) (pt-br)

<!-- Format: see en-us.md. -->

## Title

LYNX SHARE

## Short description

DAW grátis e de código aberto com três workflows em um só programa: patterns no estilo do FL Studio (Channel Rack, Piano Roll, Playlist, Mixer), disparo de clipes no estilo do Ableton Live e um modo simples de janela única no estilo do BandLab e do FL Studio Mobile. Abre projetos .flp, .als e .flm.

## Description

LYNX SHARE é uma estação de trabalho de áudio digital grátis e de código aberto para fazer beats e músicas. Ela tem três
workflows em um só programa, e você pode alternar entre eles a qualquer momento sem mudar o projeto:

• Patterns no estilo do FL Studio (o padrão): um Channel Rack com step sequencer, patterns, um Piano Roll, uma Playlist
com arranjos e um Mixer com inserts, sends e sidechain.
• Disparo de clipes no estilo do Ableton Live: uma grade de clipes e cenas, um mixer da sessão e as visões de clipe e
de dispositivo.
• Um Fluxo simples que mistura o estilo acessível de janela única do BandLab com o jeito de trabalhar do FL Studio
Mobile: faixas e linha do tempo, loops, pads e gravação rápida, com uma primeira música guiada.

É feita para continuar leve e rápida em qualquer PC.

• Leve: motor de áudio sem travas que distribui canais e faixas do mixer pelos núcleos do processador, ignora canais
parados e lê áudios longos direto do disco.
• Completo: mais de 100 instrumentos e efeitos embutidos — sintetizadores, baterias eletrônicas, samplers, EQs,
compressores, limitadores, reverbs, delays, afinação de voz, visualizadores e mais.
• Seus plugins: carrega instrumentos e efeitos VST3, CLAP e VST2, cada um opcionalmente em um processo separado
(sandbox), para que um plugin que trave não derrube sua sessão.
• Seus projetos: abre projetos do FL Studio (.flp) com patterns, notas, mixer, automação e samples; abre e salva sets
do Ableton Live 11/12 (.als), com os clipes da Session; exporta .flp de volta para o FL Studio; importa projetos do FL
Studio Mobile (.flm, parcial) e arquivos MIDI.
• Baixa latência: ASIO (inclusive o driver ASIO do próprio LYNX SHARE, para qualquer dispositivo), WASAPI compartilhado e
exclusivo.
• Grave áudio e MIDI, edite áudio, automatize qualquer parâmetro, exporte em WAV, FLAC, MP3, OGG ou stems.
• Interface em 15 idiomas: português do Brasil, inglês, espanhol, francês, alemão, italiano, holandês, polonês, russo, turco, indonésio, japonês, coreano e chinês (simplificado e tradicional).

Sem conta, sem assinatura, sem anúncios e sem telemetria. O LYNX SHARE é software livre (GNU AGPL-3.0); o código-fonte
está no GitHub.

LYNX SHARE é um projeto independente, sem afiliação ou endosso da Image-Line ou da Ableton. FL Studio e FL Studio
Mobile são marcas da Image-Line Software; Ableton e Live são marcas da Ableton AG. Outros nomes de produtos são marcas
de seus respectivos donos.

O LYNX SHARE está em fase alfa: pode ter arestas; por favor, relate problemas no GitHub.

## What's new

LYNX SHARE 0.1.28: mais leve e mais rápido, com a janela pronta em cerca de um segundo, projetos grandes que abrem
mais rápido e usam menos memória, reprodução mais fluida, stems exportados em uma passada e render-ahead para projetos
pesados com buffers pequenos; Ableton Link; Congelar e Bounce no Fluxo por disparo de clipes; envelopes de clipe;
samples arrastados para plugins; mais dispositivos do Ableton Live abertos a partir de sets .als; sons de fábrica do
FL Studio Mobile a partir da sua própria cópia do app; um Sampler de 16 pads no Fluxo simples; Salvar preset para os
instrumentos embutidos; uma Remote Control API experimental; faixas da Playlist que se redimensionam pela borda,
Ctrl+clique para selecionar várias faixas e faixas da Playlist vinculadas às faixas do mixer; e muitas correções.

## Features

1. Três workflows em um só programa: patterns no estilo do FL Studio por padrão, disparo de clipes no estilo do Ableton Live ou um Fluxo simples no estilo do BandLab e do FL Studio Mobile
2. Abre projetos do FL Studio (.flp), do Ableton Live (.als) e do FL Studio Mobile (.flm) e arquivos MIDI; salva .als e .flp
3. Mais de 100 instrumentos e efeitos embutidos
4. Carrega plugins VST3, CLAP e VST2, opcionalmente isolados em processo próprio
5. Áudio com baixa latência: ASIO, WASAPI compartilhado e exclusivo
6. Motor multinúcleo que continua leve em PCs mais antigos
7. Gravação de áudio e MIDI, editor de áudio, clipes de automação
8. Exporta WAV, FLAC, MP3, OGG e stems
9. Interface em 15 idiomas, incluindo português do Brasil
10. Gratuito e de código aberto (AGPL-3.0): sem conta, sem anúncios, sem telemetria

## Search terms

- DAW
- produção musical
- fazer beats
- estúdio de música
- editor de áudio
- sequenciador MIDI
- host VST

## Screenshot captions

- 01-workspace.png — A área de trabalho do LYNX SHARE: navegador, Playlist, Piano Roll, Channel Rack e Mixer
- 02-playlist.png — Organize padrões, áudio e automação na Playlist
- 03-piano-roll.png — Escreva melodias e acordes no Piano Roll
- 04-mixer.png — Mixe com inserts, sends, sidechain e efeitos embutidos
- 05-instruments-effects.png — Sequenciador de passos, sintetizadores embutidos e o EQ paramétrico
