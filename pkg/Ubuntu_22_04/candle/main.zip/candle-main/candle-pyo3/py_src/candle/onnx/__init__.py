# Generated content DO NOT EDIT
from .. import onnx

ONNXModel = onnx.ONNXModel
ONNXTensorDescription = onnx.ONNXTensorDescription
