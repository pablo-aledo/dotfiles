# candle-metal-kernels

This crate contains Metal kernels used from candle.