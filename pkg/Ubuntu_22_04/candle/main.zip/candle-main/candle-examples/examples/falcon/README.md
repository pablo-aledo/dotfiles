# candle-falcon

Falcon is a general large language model.
