# Running a model


In order to run an existing model, you will need to download and use existing weights.
Most models are already available on https://huggingface.co/ in [`safetensors`](https://github.com/huggingface/safetensors) format.

Let's get started by running an old model : `bert-base-uncased`.
