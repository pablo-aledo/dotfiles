## What's this?

See: https://glicol.js.org

## Feedback

There are many todos for this package. Please let me know your thoughts and suggestions here:

https://github.com/chaosprint/glicol

`Issues` or `Discussion` are both fine.

## Dev note (not for users)
```
sudo pnpm link --dir /usr/local/lib/ glicol
```