#!/usr/bin/env node

const yargs = require('yargs')

console.log(yargs.argv)

