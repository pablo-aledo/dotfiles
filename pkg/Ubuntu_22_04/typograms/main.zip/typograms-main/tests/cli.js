const create = require("./../src/typograms.js");

describe("cli", () => {
  it.skip("main", () => {
    console.log("hi");
    console.log(create);
    create("o->hi");
  });
});
