# frozen_string_literal: true

require 'coltrane'
require 'coreaudio'

module ColtraneSynth
  autoload :Base,  'coltrane_synth/base'
  autoload :Synth, 'coltrane_synth/synth'
end
