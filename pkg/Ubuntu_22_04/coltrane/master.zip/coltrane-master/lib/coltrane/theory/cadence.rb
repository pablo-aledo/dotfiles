# frozen_string_literal: true

module Coltrane
  module Theory
    # Not done yet
    class Cadence
    end
  end
end
