module Coltrane
  module Theory
    class ScaleSearchResult
    end
  end
end