# frozen_string_literal: true

module Changes
  def coltrane_changes; end

  def bird_changes; end
end
