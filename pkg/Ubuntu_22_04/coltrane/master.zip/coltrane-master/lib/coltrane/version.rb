# frozen_string_literal: true

module Coltrane
  VERSION = '4.1.2'
end
