Timeline
========

A brief timeline of the project.

The idea is to later make this into a timeline similar to the one for `ActivityWatch <https://activitywatch.net/timeline/>`_, including releases, features, etc.

2024
----

October

- `First viral tweet <https://x.com/rohanpaul_ai/status/1841999030999470326>`_

August

- `Show HN <https://news.ycombinator.com/item?id=41204256>`__

2023
----

September

- `Reddit announcement <https://www.reddit.com/r/LocalLLaMA/comments/16atlia/gptme_a_fancy_cli_to_interact_with_llms_gpt_or/>`_
- `Twitter announcement <https://x.com/ErikBjare/status/1699097896451289115>`_

August

- `Show HN <https://news.ycombinator.com/item?id=37394845>`__

March

- `Initial commit <https://github.com/ErikBjare/gptme/commit/d00e9aae68cbd6b89bbc474ed7721d08798f96dc>`_
