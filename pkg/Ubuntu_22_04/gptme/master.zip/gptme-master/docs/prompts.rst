Prompts
=======

Here you can read examples of the system prompts currently used by gptme.

.. automodule:: gptme.prompts
   :members:
