Microsoft Visual Studio project files.

See vs/ugrep/README.txt for detailed instructions.
