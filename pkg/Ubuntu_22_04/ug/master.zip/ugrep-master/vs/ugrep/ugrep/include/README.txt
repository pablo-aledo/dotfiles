RE/flex source code available from https://github.com/Genivia/RE-flex
