RE/flex library source code https://github.com/Genivia/RE-flex
