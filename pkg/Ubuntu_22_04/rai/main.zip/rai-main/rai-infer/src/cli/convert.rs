//! `rai convert` — HuggingFace checkpoint to `.raimodel`, without Python.
//!
//! The conversion itself lives in [`crate::convert`]; this is only the
//! command-line shape around it.

use std::path::PathBuf;

use anyhow::Result;

use crate::cli::format_bytes;
use crate::convert::{convert, ConvertOptions, FOLLOW_MODEL_CONTEXT};

/// The tuning knobs, shared with the deprecated `rai-convert` binary.
#[derive(clap::Args, Debug, Clone)]
pub struct ConvertTuning {
    /// Output file; defaults to <model-dir-name>-q4.raimodel
    #[arg(short = 'o', long, value_name = "FILE")]
    pub output: Option<PathBuf>,
    /// Columns per quantization group for the 4-bit linears. Smaller is more
    /// accurate and slightly larger: each group stores one f16 scale and one
    /// f16 zero, so 64 costs 0.25 bits per weight over 128, and 32 costs 0.75.
    #[arg(long, default_value_t = 128, value_name = "N")]
    pub group_size: u32,
    /// Columns per quantization group for the 8-bit embedding
    #[arg(long, default_value_t = 64, value_name = "N")]
    pub embed_group_size: u32,
    /// Context length the model is built for (sizes the RoPE table);
    /// defaults to the model's own max_position_embeddings
    #[arg(long, value_name = "TOKENS")]
    pub max_context: Option<u32>,
    /// Where to copy tokenizer.json; defaults to next to the output file
    #[arg(long, value_name = "FILE")]
    pub tokenizer_out: Option<PathBuf>,
    /// Suppress progress output
    #[arg(long, default_value_t = false)]
    pub quiet: bool,
    /// Calibrate against this text file instead of quantizing the weights on
    /// their own. Slower, and produces a measurably more accurate model.
    #[arg(long, value_name = "FILE")]
    pub calibration_text: Option<PathBuf>,
    /// Calibration sequences to read from the text
    #[arg(long, default_value_t = 16, value_name = "N")]
    pub calibration_sequences: usize,
    /// Tokens per calibration sequence
    #[arg(long, default_value_t = 512, value_name = "N")]
    pub calibration_seq_len: usize,
}

#[derive(clap::Args, Debug, Clone)]
pub struct ConvertArgs {
    /// HuggingFace checkpoint directory (config.json + .safetensors + tokenizer.json)
    #[arg(value_name = "MODEL_DIR")]
    pub model_dir: PathBuf,
    #[command(flatten)]
    pub tuning: ConvertTuning,
}

impl ConvertArgs {
    fn options(&self) -> ConvertOptions {
        ConvertOptions {
            model_dir: self.model_dir.clone(),
            output: self.tuning.output.clone(),
            calibration_text: self.tuning.calibration_text.clone(),
            calibration_sequences: self.tuning.calibration_sequences,
            calibration_seq_len: self.tuning.calibration_seq_len,
            group_size: self.tuning.group_size,
            embed_group_size: self.tuning.embed_group_size,
            // No flag means the model's own context, not a constant: see
            // `convert::FOLLOW_MODEL_CONTEXT`.
            max_context: self.tuning.max_context.unwrap_or(FOLLOW_MODEL_CONTEXT),
            tokenizer_out: self.tuning.tokenizer_out.clone(),
            quiet: self.tuning.quiet,
        }
    }
}

pub fn run(args: &ConvertArgs) -> Result<()> {
    // `convert` already narrates its own progress and final byte count; the
    // only thing missing at the end of a conversion is what to do next.
    let summary = convert(&args.options())?;
    if !args.tuning.quiet {
        println!(
            "\n{} is ready ({}). Run it with:\n  rai run {} --prompt \"...\"",
            summary.output_path.display(),
            format_bytes(summary.bytes_written),
            summary.output_path.display()
        );
    }
    Ok(())
}
