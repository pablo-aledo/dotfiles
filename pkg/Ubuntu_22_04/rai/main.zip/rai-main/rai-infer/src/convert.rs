//! Rust-native HuggingFace -> `.raimodel` converter (round-to-nearest 4-bit).
//!
//! This is the Rust port of `scripts/export_rtn.py` + `scripts/raimodel.py`.
//! It exists because the Python path contradicts the product's own claim of
//! "no GPU, no Python runtime": converting a model used to require torch and
//! transformers (~2.5 GB of wheels), and the exporter materialized the whole
//! model in RAM, so a 7B checkpoint could not be converted on a 16 GB machine
//! at all.
//!
//! Two properties are load-bearing:
//!
//! * **Byte-identical output.** For the same checkpoint and the same options,
//!   this writes exactly the bytes `export_rtn.py` writes. Everything that
//!   affects a byte is mirrored deliberately: the f64 group statistics, the
//!   f16 round-trip of scale/zero *before* codes are derived, round-half-to-
//!   even code rounding (numpy's `np.round`, not Rust's `f64::round`), the
//!   `MIN_F16_SCALE` floor, low-nibble-first packing, and the cast of every
//!   weight through f16 on load (see `safetensors::decode_into`).
//! * **Bounded memory.** Sections have analytically known sizes, so the file
//!   is written in place: for each matrix the code seeks past the group-param
//!   block, streams row blocks of codes, then seeks back and fills the params
//!   in. Peak memory is one row block plus one matrix's group params, not one
//!   layer and never the model.
//!
//! Binary layout is documented in `format.rs` (the reader) and in the
//! `raimodel.py` module docstring.

use anyhow::{bail, ensure, Context, Result};
use half::f16;
use rayon::prelude::*;
use std::cell::Cell;
use std::fs::File;
use std::io::{Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

// The container's capacity limits are defined once, by the reader that
// enforces them (`format.rs`) and by the kernels they protect (`gemm.rs`,
// `layers.rs`). The writer imports them so a converted file is, by
// construction, a file this build can load.
use crate::format::{
    MAX_CONTEXT, MAX_HEADS, MAX_HIDDEN_SIZE, MAX_INTERMEDIATE_SIZE, MAX_LAYERS, MAX_VOCAB_SIZE,
    PROJECTION_NAMES,
};
use crate::gemm::MAX_GROUPS as MAX_GEMM_GROUPS;
use crate::layers::{Activation, RopeScaling, MAX_ROPE_TABLE_BYTES};
use crate::safetensors::SafeTensorsSet;

/// Smallest positive (subnormal) f16; scales are clamped to at least this so a
/// stored scale is always strictly positive. Matches
/// `float(np.nextafter(np.float16(0), np.float16(1)))`.
const MIN_F16_SCALE: f64 = 5.960464477539063e-8;

/// Candidate clipping ranges tried per group during a calibrated conversion.
///
/// Eight steps walk the group's span down to half of itself. The objective is
/// flat enough between neighbouring steps that a finer grid buys nothing
/// measurable, and each extra step costs one more pass over every weight in the
/// model.
const CALIBRATION_SHRINK_STEPS: usize = 8;

const HEADER_SIZE_V1: u64 = 64;
const HEADER_SIZE_V2: u64 = 128;
const SECTION_ENTRY_SIZE: u64 = 16;

/// Weights read per streaming block, in elements (~8 MB as f32).
const BLOCK_ELEMENTS: usize = 2 << 20;

/// The seven quantized projections in every layer, in section order.
///
/// Taken from the reader so the writer cannot drift from the layout the reader
/// parses — this is also the bit order of the v2 header's `bias_mask`.
const LAYER_LINEAR_NAMES: [&str; 7] = PROJECTION_NAMES;

/// Architectures whose maths this container cannot express even though their
/// tensor names look Llama-shaped.
///
/// `gemma` came off this list in container v2: GeGLU is a stored activation
/// code, and Gemma's other differences are folded at conversion time (see
/// `GemmaFolds`). `gemma2` came off it once the header gained the two softcaps
/// and the layer section gained the sandwich norms.
///
/// `gemma3` was the last entry off: its blocker was the two rotary bases
/// (`rope_local_base_freq` for the sliding layers, `rope_theta` for the global
/// ones), and the header now carries `rope_local_theta` plus
/// `global_layer_stride` so the runtime builds both tables. The list is empty
/// today; it stays here because the refusal machinery and its message are the
/// contract for whatever architecture shows up next.
const UNSUPPORTED_MODEL_TYPES: [(&str, &str); 0] = [];

/// Model families that need the container's Gemma-specific conversion folds:
/// the `1 + w` RMSNorm and the `sqrt(hidden_size)` embedding scale. Gemma2 uses
/// both, on all four of its norms.
const GEMMA_MODEL_TYPES: [&str; 4] = ["gemma", "gemma2", "gemma3", "gemma3_text"];

/// Families that use Gemma2's sandwich normalization, i.e. carry
/// `pre_feedforward_layernorm` and `post_feedforward_layernorm` per layer.
const SANDWICH_NORM_MODEL_TYPES: [&str; 3] = ["gemma2", "gemma3", "gemma3_text"];

/// [`ConvertOptions::max_context`] value meaning "store the context the model
/// itself declares".
///
/// The stored context is a permanent ceiling: it sizes the RoPE table written
/// into the file, and `rai run` / `rai serve` can never allocate a KV cache
/// past it. A constant default therefore capped every model at that constant
/// forever — a Qwen3-0.6B whose config says `max_position_embeddings=40960`
/// was stored at 2048 and could not be persuaded otherwise without a
/// re-conversion. The default is now this sentinel, resolved per checkpoint by
/// [`resolve_max_context`].
///
/// Zero, rather than `Option<u32>`, because it is not a legal context (the
/// reader requires `1..=MAX_CONTEXT`) so it cannot collide with a real
/// request, and because every existing construction of [`ConvertOptions`] —
/// including the ones in `cli::serve` — keeps compiling unchanged.
pub const FOLLOW_MODEL_CONTEXT: u32 = 0;

/// Conversion inputs. Defaults match `export_rtn.py`.
#[derive(Debug, Clone)]
pub struct ConvertOptions {
    /// HuggingFace checkpoint directory.
    pub model_dir: PathBuf,
    /// Output path; defaults to `<dirname>-q4.raimodel` in the
    /// working directory.
    pub output: Option<PathBuf>,
    pub group_size: u32,
    pub embed_group_size: u32,
    /// Context to store, or [`FOLLOW_MODEL_CONTEXT`] to take the model's own.
    pub max_context: u32,
    /// Where `tokenizer.json` is copied; defaults to next to the output.
    pub tokenizer_out: Option<PathBuf>,
    /// Suppress progress output.
    pub quiet: bool,
    /// Text to calibrate against. `None` is the round-to-nearest path.
    ///
    /// Calibration runs this text through the checkpoint and uses what each
    /// projection actually sees to choose that projection's quantization
    /// parameters. It costs a forward pass and buys accuracy that looking at
    /// the weights alone cannot.
    pub calibration_text: Option<PathBuf>,
    /// Sequences to calibrate on.
    pub calibration_sequences: usize,
    /// Tokens per calibration sequence.
    pub calibration_seq_len: usize,
}

impl Default for ConvertOptions {
    fn default() -> Self {
        Self {
            model_dir: PathBuf::new(),
            output: None,
            group_size: 128,
            embed_group_size: 64,
            max_context: FOLLOW_MODEL_CONTEXT,
            tokenizer_out: None,
            quiet: false,
            calibration_text: None,
            calibration_sequences: 16,
            calibration_seq_len: 512,
        }
    }
}

/// Where the context a conversion stores came from.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ContextSource {
    /// `--max-context` was given explicitly.
    Requested,
    /// The model's own `max_position_embeddings`.
    ModelConfig,
    /// The model's `sliding_window`, which is smaller than the position limit
    /// and is the largest span the container's full causal attention matches.
    SlidingWindow,
}

impl ContextSource {
    /// A stable tag for JSON, so a UI does not have to parse prose.
    pub fn as_str(self) -> &'static str {
        match self {
            ContextSource::Requested => "requested",
            ContextSource::ModelConfig => "model-config",
            ContextSource::SlidingWindow => "sliding-window",
        }
    }

    /// How the choice is narrated in the conversion log.
    fn describe(self) -> &'static str {
        match self {
            ContextSource::Requested => "requested with --max-context",
            ContextSource::ModelConfig => "the model's own max_position_embeddings",
            ContextSource::SlidingWindow => "the model's sliding_window",
        }
    }
}

/// The context a conversion will store, and why.
#[derive(Debug, Clone, Copy)]
pub struct ResolvedContext {
    pub tokens: u32,
    pub source: ContextSource,
}

/// A progress event, emitted once per line the converter would print.
///
/// `rai convert` narrates itself on stdout, which is useless to a UI that is
/// not a terminal. Every one of those lines also arrives here, tagged with the
/// phase it belongs to and how much of the model has been written, so a caller
/// can drive a per-layer progress bar without parsing log text.
#[derive(Debug, Clone, Copy)]
pub struct ConvertProgress<'a> {
    /// Coarse phase: `planning`, `embedding`, `layers`, `final-norm`,
    /// `lm_head`, `tokenizer`, `done`.
    pub stage: &'a str,
    /// Sections written so far, as a percentage of the sections planned.
    /// Monotonic, `0.0..=100.0`.
    pub percent: f32,
    /// The human-readable line, byte for byte what the CLI prints.
    pub message: &'a str,
    /// `(layer_index, num_layers)` while quantizing layers, else `None`.
    pub layer: Option<(u32, u32)>,
}

/// What a conversion produced.
#[derive(Debug, Clone)]
pub struct ConvertSummary {
    pub output_path: PathBuf,
    pub bytes_written: u64,
    pub num_sections: usize,
    pub tokenizer_path: PathBuf,
    /// False when an identical `tokenizer.json` was already in place.
    pub tokenizer_copied: bool,
    pub elapsed: Duration,
    /// On-disk bytes of the `.safetensors` shards this conversion read.
    ///
    /// The shards themselves ([`SafeTensorsSet::shard_paths`]), not the
    /// checkpoint directory: a folder usually also holds `tokenizer.json`, a
    /// `.cache` subtree and sometimes a second copy of the weights, and
    /// counting those would overstate what was compressed.
    pub source_bytes: u64,
    /// How many shard files that was.
    pub source_files: usize,
    /// Parameters implied by the config, in elements.
    pub parameters: u64,
    /// Context stored in the header, and where the number came from.
    pub context: ResolvedContext,
    /// KV cache the runtime allocates if the full stored context is used.
    pub kv_cache_bytes: u64,
}

impl ConvertSummary {
    /// Source bytes per output byte, e.g. `2.43` for 2.43x smaller.
    pub fn compression_ratio(&self) -> f64 {
        if self.bytes_written == 0 {
            return 0.0;
        }
        self.source_bytes as f64 / self.bytes_written as f64
    }

    /// Stored bits per parameter — the number a quantization scheme is judged
    /// by. Above 4 for a 4-bit model: group scales, zero points, the 8-bit
    /// embedding and the f32 norms are all in the file too.
    pub fn bits_per_parameter(&self) -> f64 {
        if self.parameters == 0 {
            return 0.0;
        }
        self.bytes_written as f64 * 8.0 / self.parameters as f64
    }
}

/// The header fields, i.e. everything the reader validates before touching a
/// section.
#[derive(Debug, Clone)]
struct RaiConfig {
    hidden_size: u32,
    num_layers: u32,
    num_heads: u32,
    num_kv_heads: u32,
    head_dim: u32,
    intermediate_size: u32,
    vocab_size: u32,
    max_context: u32,
    rope_theta: f32,
    norm_eps: f32,
    bits: u8,
    group_size: u8,
    embed_bits: u8,
    embed_group_size: u8,
    activation: Activation,
    rope_scaling: RopeScaling,
    /// Bit *i*: projection *i* of [`PROJECTION_NAMES`] carries a bias.
    bias_mask: u8,
    embed_scale: f32,
    /// Per-head `q_norm`/`k_norm` vectors are stored in every layer section.
    has_qk_norm: bool,
    /// Gemma2's two extra per-layer norms are stored in every layer section.
    has_sandwich_norm: bool,
    /// `q_norm`/`k_norm` span the whole projection rather than one head
    /// (OLMo2). Never set together with `has_qk_norm`.
    has_full_qk_norm: bool,
    /// The two tail norms apply to block outputs, not to the residual stream
    /// before each block (OLMo2). Never set together with `has_sandwich_norm`.
    post_norm: bool,
    /// `cap` for `cap * tanh(x/cap)` on attention logits; 0.0 = disabled.
    attn_logit_softcap: f32,
    /// The same on output logits; 0.0 = disabled.
    final_logit_softcap: f32,
    /// Explicit query-key scale; 0.0 = the default `1/sqrt(head_dim)`.
    attn_scale: f32,
    /// RoPE base for non-global layers; 0.0 = one base for every layer.
    rope_local_theta: f32,
    /// Layer *i* is global when `(i + 1) % stride == 0`; 0 = unused.
    global_layer_stride: u8,
    /// Experts per layer; 0 = a dense MLP.
    num_experts: u16,
    /// Experts each token is routed to.
    experts_per_token: u8,
    /// Rescale the selected experts' weights to sum to one.
    norm_topk_prob: bool,
}

impl RaiConfig {
    /// The lowest container version that can express this model.
    ///
    /// v1 stays the answer whenever nothing new is used, so every checkpoint
    /// that converted before this change still produces the same bytes it
    /// always did — that is what `convert_matches_python` pins.
    fn version(&self) -> u32 {
        if self.activation == Activation::Silu
            && self.rope_scaling == RopeScaling::None
            && self.bias_mask == 0
            && self.embed_scale == 1.0
            && !self.has_qk_norm
            && !self.has_sandwich_norm
            && !self.has_full_qk_norm
            && !self.post_norm
            && self.attn_logit_softcap == 0.0
            && self.final_logit_softcap == 0.0
            && self.attn_scale == 0.0
            && self.global_layer_stride == 0
            && self.num_experts == 0
        {
            1
        } else {
            2
        }
    }

    /// The `flags` byte the header will carry.
    fn flags(&self) -> u8 {
        let mut flags = 0u8;
        if self.bias_mask != 0 {
            flags |= crate::format::FLAG_HAS_BIASES;
        }
        if self.has_qk_norm {
            flags |= crate::format::FLAG_HAS_QK_NORM;
        }
        if self.has_sandwich_norm {
            flags |= crate::format::FLAG_HAS_SANDWICH_NORM;
        }
        if self.has_full_qk_norm {
            flags |= crate::format::FLAG_HAS_FULL_QK_NORM;
        }
        if self.post_norm {
            flags |= crate::format::FLAG_POST_NORM;
        }
        flags
    }

    fn header_size(&self) -> u64 {
        if self.version() >= 2 {
            HEADER_SIZE_V2
        } else {
            HEADER_SIZE_V1
        }
    }

    fn attention_dim(&self) -> usize {
        self.num_heads as usize * self.head_dim as usize
    }

    fn kv_dim(&self) -> usize {
        self.num_kv_heads as usize * self.head_dim as usize
    }

    fn has_bias(&self, index: usize) -> bool {
        self.bias_mask & (1 << index) != 0
    }

    /// `(rows, cols)` of the seven layer projections, in section order.
    /// Must agree with `format::ModelConfig::projection_dims`.
    fn projection_dims(&self) -> [(usize, usize); 7] {
        let hidden = self.hidden_size as usize;
        let inter = self.intermediate_size as usize;
        let q_dim = self.attention_dim();
        let kv_dim = self.kv_dim();
        [
            (q_dim, hidden),
            (kv_dim, hidden),
            (kv_dim, hidden),
            (hidden, q_dim),
            (inter, hidden),
            (inter, hidden),
            (hidden, inter),
        ]
    }
}

/// The two Gemma differences that are folded into stored weights rather than
/// given a runtime code path.
///
/// * **RMSNorm.** Gemma computes `x/rms * (1 + w)`; the shipped kernel computes
///   `x/rms * w` (`layers.rs::rms_norm`, verified). Storing `w' = 1 + w` makes
///   the existing kernel exactly right, so no reader change and no flag.
/// * **Embedding scale.** Gemma multiplies the *input* embedding by
///   `sqrt(hidden_size)`. This one is deliberately **not** folded, despite
///   looking like the same kind of trick: Gemma ties `lm_head` to the embedding
///   table, and the tied output projection uses the unscaled weights. A folded
///   table would inflate every logit by ~45x. It is carried in the v2 header's
///   `embed_scale` and applied at lookup time instead.
#[derive(Debug, Clone, Copy, Default)]
struct GemmaFolds {
    /// Add 1.0 to every RMSNorm weight before writing it.
    norm_plus_one: bool,
}

/// Deletes the `.partial` conversion output on drop unless the write finished
/// and the file was renamed into place (`keep` flipped to true). Covers early
/// `?` returns and panics on the conversion thread alike.
struct PartialOutput<'a> {
    path: &'a Path,
    keep: bool,
}

impl Drop for PartialOutput<'_> {
    fn drop(&mut self) {
        if !self.keep {
            let _ = std::fs::remove_file(self.path);
        }
    }
}

/// Convert a HuggingFace checkpoint directory to `.raimodel`.
pub fn convert(options: &ConvertOptions) -> Result<ConvertSummary> {
    convert_with_progress(options, &|_| {})
}

/// [`convert`], with every narration line also delivered to `progress`.
///
/// Split out rather than added to [`ConvertOptions`] so that no existing
/// caller's construction of that struct has to change.
pub fn convert_with_progress(
    options: &ConvertOptions,
    progress: &dyn Fn(ConvertProgress<'_>),
) -> Result<ConvertSummary> {
    let started = Instant::now();
    validate_options(options)?;

    let config_path = options.model_dir.join("config.json");
    let raw_config = std::fs::read(&config_path)
        .with_context(|| format!("reading {}", config_path.display()))?;
    let hf: serde_json::Value = serde_json::from_slice(&raw_config)
        .with_context(|| format!("parsing {}", config_path.display()))?;

    let hidden_size = required_u32(&hf, "hidden_size")?;
    let num_layers = required_u32(&hf, "num_hidden_layers")?;
    let num_heads = required_u32(&hf, "num_attention_heads")?;
    let num_kv_heads = optional_u32(&hf, "num_key_value_heads")?.unwrap_or(num_heads);
    let head_dim = resolve_head_dim(optional_u32(&hf, "head_dim")?, hidden_size, num_heads)?;
    let intermediate_size = required_u32(&hf, "intermediate_size")?;
    let vocab_size = required_u32(&hf, "vocab_size")?;
    let rope_theta = optional_f64(&hf, "rope_theta")?.unwrap_or(10_000.0) as f32;
    let norm_eps = optional_f64(&hf, "rms_norm_eps")?.unwrap_or(1e-5) as f32;
    let tied = hf
        .get("tie_word_embeddings")
        .and_then(|v| v.as_bool())
        .unwrap_or(true);
    let model_type = hf.get("model_type").and_then(|v| v.as_str()).unwrap_or("?");

    // Settled before anything is planned: the stored context sizes the RoPE
    // table, is echoed in the header, and is the ceiling every later run is
    // held to.
    let context = resolve_max_context(&hf, head_dim, options.max_context)?;
    let shape = ModelShape {
        hidden_size,
        num_layers,
        num_heads,
        num_kv_heads,
        head_dim,
        intermediate_size,
        vocab_size,
        tied_embeddings: tied,
    };

    let is_gemma = GEMMA_MODEL_TYPES.contains(&model_type);
    let has_sandwich_norm = SANDWICH_NORM_MODEL_TYPES.contains(&model_type);
    let activation = resolve_activation(&hf, is_gemma)?;
    let rope_scaling = resolve_rope_scaling(&hf)?;
    let attn_logit_softcap = resolve_softcap(&hf, "attn_logit_softcapping")?;
    let final_logit_softcap = resolve_softcap(&hf, "final_logit_softcapping")?;
    let attn_scale = resolve_attn_scale(&hf, head_dim)?;
    let per_layer_rope = resolve_per_layer_rope(&hf, num_layers)?;
    let experts = resolve_experts(&hf, intermediate_size)?;
    let folds = GemmaFolds {
        norm_plus_one: is_gemma,
    };
    // sqrt(hidden_size), computed in f64 and rounded once, so the value in the
    // header is the nearest f32 to the true normalizer.
    let embed_scale = if is_gemma {
        (hidden_size as f64).sqrt() as f32
    } else {
        1.0
    };

    let mut config = RaiConfig {
        hidden_size,
        num_layers,
        num_heads,
        num_kv_heads,
        head_dim,
        intermediate_size,
        vocab_size,
        max_context: context.tokens,
        rope_theta,
        norm_eps,
        bits: 4,
        group_size: options.group_size as u8,
        embed_bits: 8,
        embed_group_size: options.embed_group_size as u8,
        activation,
        rope_scaling,
        bias_mask: 0,
        embed_scale,
        // Settled once the tensor namespace is open, below.
        has_qk_norm: false,
        has_sandwich_norm,
        has_full_qk_norm: false,
        post_norm: false,
        rope_local_theta: per_layer_rope.0,
        global_layer_stride: per_layer_rope.1,
        num_experts: experts.0,
        experts_per_token: experts.1,
        norm_topk_prob: experts.2,
        attn_logit_softcap,
        final_logit_softcap,
        attn_scale,
    };

    let output_path = match &options.output {
        Some(path) => path.clone(),
        None => PathBuf::from(default_output_name(&options.model_dir)?),
    };
    let tokenizer_src = options.model_dir.join("tokenizer.json");
    if !tokenizer_src.is_file() {
        bail!(
            "{} has no tokenizer.json; the runtime needs it next to the model, so there is \
             nothing to convert into a usable model",
            options.model_dir.display()
        );
    }
    let tokenizer_dst = match &options.tokenizer_out {
        Some(path) => path.clone(),
        None => output_path
            .parent()
            .unwrap_or_else(|| Path::new("."))
            .join("tokenizer.json"),
    };

    // Progress accounting: one unit per section (the embedding, each layer,
    // the final norm, and `lm_head` when untied), so `percent` advances once
    // per layer — the only granularity that means anything on a 7B model.
    let total_units = (num_layers + 2 + u32::from(!tied)) as f32;
    let done_units = Cell::new(0u32);
    let stage = Cell::new("planning");
    let layer_of = Cell::new(None::<(u32, u32)>);
    let enter = |name: &'static str, done: u32, layer: Option<(u32, u32)>| {
        stage.set(name);
        done_units.set(done);
        layer_of.set(layer);
    };

    let log = |line: &str| {
        if !options.quiet {
            println!("{line}");
            let _ = std::io::stdout().flush();
        }
        progress(ConvertProgress {
            stage: stage.get(),
            percent: 100.0 * done_units.get() as f32 / total_units,
            message: line,
            layer: layer_of.get(),
        });
    };

    log(&format!("Output: {}", output_path.display()));
    log(&format!("Reading {}...", options.model_dir.display()));
    let mut store = SafeTensorsSet::open(&options.model_dir)?;
    assert_exportable_architecture(&hf, Some(&store), context.tokens, num_layers)?;
    let (source_bytes, source_files) = checkpoint_source_bytes(&store)?;
    let parameters = shape.parameter_count();

    // Which projections carry biases is a property of the checkpoint, not the
    // config, so it can only be settled once the tensor namespace is open.
    config.bias_mask = resolve_bias_mask(&store, num_layers)?;
    let qk_norm = resolve_qk_norm(
        &store,
        num_layers,
        head_dim,
        config.attention_dim(),
        config.kv_dim(),
    )?;
    config.has_qk_norm = qk_norm == QkNormKind::PerHead;
    config.has_full_qk_norm = qk_norm == QkNormKind::FullWidth;
    config.post_norm = resolve_post_norm(&store, num_layers)?;
    if config.post_norm && config.has_sandwich_norm {
        bail!(
            "checkpoint has no input_layernorm but its model_type is sandwich-normed; those \
             describe incompatible layer shapes and the converter cannot tell which is meant."
        );
    }
    validate_model_config(&config)?;

    let hidden = hidden_size as usize;
    let vocab = vocab_size as usize;
    let group_size = options.group_size as usize;
    let embed_group_size = options.embed_group_size as usize;
    let linear_dims = config.projection_dims();

    // Confirm every tensor exists with the shape the reader will demand, before
    // a single byte is written.
    let layout = ProjectionLayout::detect(&store, num_layers)?;
    layout.check_fused_tensors(&store, num_layers, &linear_dims)?;
    let expert_layout = if config.num_experts > 0 {
        let experts = ExpertLayout::detect(&store)?;
        if config.bias_mask != 0 {
            bail!(
                "checkpoint declares experts and projection biases; the bias mask addresses the                  seven dense projections and has no slot for a per-expert bias."
            );
        }
        // Every expert of every layer, checked before a byte is written: a
        // checkpoint missing expert 47 of layer 12 must fail now, not after
        // twenty minutes of quantization.
        for layer in 0..num_layers {
            check_vector(
                &store,
                &experts.router(layer),
                config.num_experts as usize * hidden,
            )
            .or_else(|_| {
                check_tensor(
                    &store,
                    &experts.router(layer),
                    config.num_experts as usize,
                    hidden,
                )
            })?;
            for expert in 0..config.num_experts as usize {
                for (name, (rows, cols)) in experts
                    .expert(layer, expert)
                    .into_iter()
                    .zip(&linear_dims[4..])
                {
                    check_tensor(&store, &name, *rows, *cols)?;
                }
            }
        }
        Some(experts)
    } else {
        None
    };
    check_tensor(&store, "model.embed_tokens.weight", vocab, hidden)?;
    for layer in 0..num_layers {
        for (index, (name, (rows, cols))) in LAYER_LINEAR_NAMES.iter().zip(linear_dims).enumerate()
        {
            // A fused projection was already checked as a whole, above; its
            // parts have no tensor of their own to check.
            let source = match (expert_layout, index) {
                // A sparse layer has no `mlp.gate_proj`: its first expert is
                // the layer's MLP, which is what keeps a dense file unchanged.
                (Some(experts), 4..=6) => ProjectionSource {
                    tensor: experts.expert(layer, 0)[index - 4].clone(),
                    row_offset: 0,
                },
                _ => layout.source(layer, index, &linear_dims),
            };
            if source.row_offset == 0 && source.tensor == layer_linear_name(layer, name) {
                check_tensor(&store, &source.tensor, rows, cols)?;
            }
            if config.has_bias(index) {
                check_vector(&store, &layer_bias_name(layer, name), rows)?;
            }
        }
        for name in tail_norm_names(layer, config.has_sandwich_norm, config.post_norm) {
            check_vector(&store, &name, hidden)?;
        }
        if config.has_qk_norm {
            for name in qk_norm_names(layer) {
                check_vector(&store, &name, head_dim as usize)?;
            }
        }
    }
    if config.has_sandwich_norm {
        check_sandwich_norms(&store, num_layers, hidden)?;
    }
    check_vector(&store, "model.norm.weight", hidden)?;
    if !tied {
        check_tensor(&store, "lm_head.weight", vocab, hidden)?;
    }

    log(&format!(
        "{model_type}: {num_layers}L h={hidden_size} inter={intermediate_size} \
         heads={num_heads}/{num_kv_heads} head_dim={head_dim} vocab={vocab_size}"
    ));
    log(&format!(
        "Source: {} in {source_files} safetensors file{}, {} parameters",
        crate::cli::format_bytes(source_bytes),
        if source_files == 1 { "" } else { "s" },
        parameters,
    ));
    // The stored context is a permanent property of the file and the thing
    // that decides how much memory a later run *can* be asked for, so it is
    // stated with its price rather than left to be discovered at load.
    let kv_bytes = kv_cache_bytes(num_layers, num_kv_heads, head_dim, context.tokens);
    log(&format!(
        "Context: {} tokens ({})",
        context.tokens,
        context.source.describe()
    ));
    log(&format!(
        "  KV cache at {} tokens: {} ({} bytes) = 2 x {num_layers} layers x {num_kv_heads} kv \
         heads x {} pos x {head_dim} head_dim x 4 B",
        context.tokens,
        crate::cli::format_bytes(kv_bytes),
        kv_bytes,
        context.tokens,
    ));
    log(
        "  That is the ceiling, not the cost of every run: `rai run`/`rai serve` allocate for \
         their own --max-context, capped at this stored value.",
    );
    log(&format!(
        "container v{}: activation={:?} rope={:?} bias_mask={:#04x} embed_scale={} \
         flags={:#04x} (qk_norm={} sandwich_norm={}) softcap=attn:{} final:{} attn_scale={}",
        config.version(),
        config.activation,
        config.rope_scaling,
        config.bias_mask,
        config.embed_scale,
        config.flags(),
        config.has_qk_norm,
        config.has_sandwich_norm,
        config.attn_logit_softcap,
        config.final_logit_softcap,
        config.attn_scale,
    ));

    // ---- Plan the container ------------------------------------------------
    // Every section size follows from the config, so offsets can be written
    // before the data exists and each section can be streamed straight out.
    let (section_sizes, planned_total) = plan_sections(&config, tied)?;

    let num_sections = section_sizes.len();
    let data_start = config.header_size() + num_sections as u64 * SECTION_ENTRY_SIZE;
    let mut offsets = Vec::with_capacity(num_sections);
    let mut cursor = data_start;
    for size in &section_sizes {
        offsets.push(cursor);
        cursor += size;
    }
    let total_size = cursor;
    debug_assert_eq!(total_size, planned_total);

    if let Some(parent) = output_path.parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent)
                .with_context(|| format!("creating {}", parent.display()))?;
        }
    }
    // The exact output size is known before a byte is written, so running out
    // of disk should be a sentence up front rather than an OS error minutes
    // in, after the work is done and a truncated file is on disk.
    check_output_space(&output_path, total_size)?;
    // Quantization takes minutes and the target name may already hold the
    // previous good model, so the bytes go to a sibling temp file that is
    // renamed over the target only after the size check and fsync. A failure
    // part-way leaves the old model untouched, and the guard removes the
    // partial so it cannot be mistaken for a model later. (A hard kill —
    // Ctrl+C included, which does not unwind on Windows — can still leave a
    // stale .partial behind; the next conversion truncates it.)
    let tmp_path = {
        let mut name = output_path.clone().into_os_string();
        name.push(".partial");
        PathBuf::from(name)
    };
    let mut tmp_guard = PartialOutput {
        path: &tmp_path,
        keep: false,
    };
    let mut file =
        File::create(&tmp_path).with_context(|| format!("creating {}", tmp_path.display()))?;
    write_header(&mut file, &config, num_sections as u32)?;
    for (offset, size) in offsets.iter().zip(&section_sizes) {
        file.write_all(&offset.to_le_bytes())?;
        file.write_all(&size.to_le_bytes())?;
    }

    // ---- Calibration -------------------------------------------------------
    //
    // Runs before anything is written. It reads the original weights, so it is
    // independent of the quantization that follows and the streaming writer
    // below is unchanged by its presence.
    #[cfg(feature = "cli")]
    let calibration = match options.calibration_text.as_ref() {
        None => None,
        Some(path) => {
            let text = std::fs::read_to_string(path)
                .with_context(|| format!("reading calibration text {}", path.display()))?;
            let tokenizer_path = options.model_dir.join("tokenizer.json");
            let tokens = calibration_tokens(
                &tokenizer_path,
                &text,
                options.calibration_sequences,
                options.calibration_seq_len,
            )?;
            log(&format!(
                "\n=== CALIBRATION ===\n  {} sequences of {} tokens from {}",
                options.calibration_sequences,
                options.calibration_seq_len,
                path.display()
            ));
            let started = Instant::now();
            let energy = collect_calibration_energy(
                &mut store,
                &config,
                &layout,
                &linear_dims,
                expert_layout.as_ref(),
                &tokens,
                options.calibration_seq_len,
                &log,
            )?;
            log(&format!(
                "  calibration finished in {:.1}s",
                started.elapsed().as_secs_f64()
            ));
            Some(energy)
        }
    };
    #[cfg(not(feature = "cli"))]
    let calibration: Option<()> = None;

    // Calibration is the better path and cannot be the automatic one: it needs
    // representative text, and a converter that shipped a corpus inside the
    // binary or fetched one over the network would be trading away two things
    // this product is defined by. Naming the cost is the honest substitute for
    // choosing it silently.
    if options.calibration_text.is_none() {
        log(
            "\nQuantizing by round-to-nearest. On SmolLM2-1.7B this costs 30.3% perplexity \
             against the fp16 checkpoint where --calibration-text costs 16.6%, for a file of \
             exactly the same size. Pass --calibration-text <file> with a few thousand tokens \
             of representative text to use it.",
        );
    }

    let quant_started = Instant::now();

    // ---- Section 0: embedding (8-bit) --------------------------------------
    enter("embedding", 0, None);
    log("\n=== EMBEDDING 8-BIT ===");
    let t0 = Instant::now();
    let mse = write_matrix(
        &mut file,
        &mut store,
        &MatrixJob {
            tensor: "model.embed_tokens.weight",
            source_row_offset: 0,
            label: "embedding",
            rows: vocab,
            cols: hidden,
            group_size: embed_group_size,
            bits: 8,
            emit_dims: false,
            channel_energy: None,
        },
    )?;
    log(&format!(
        "  Embedding [{vocab}x{hidden}] mse={}: {:.1}s",
        fmt_sci(mse),
        t0.elapsed().as_secs_f64()
    ));

    // ---- Sections 1..=L: layers --------------------------------------------
    enter("layers", 1, None);
    log("\n=== RTN-4BIT QUANTIZATION ===");
    for layer in 0..num_layers {
        let t0 = Instant::now();
        enter("layers", 1 + layer, Some((layer, num_layers)));
        for (index, (name, (rows, cols))) in LAYER_LINEAR_NAMES.iter().zip(linear_dims).enumerate()
        {
            let label = format!("L{layer}.{name}");
            #[cfg(feature = "cli")]
            let channel_energy = calibration
                .as_ref()
                .and_then(|e| e.for_projection(layer as usize, index));
            #[cfg(not(feature = "cli"))]
            let channel_energy: Option<&[f64]> = None;
            let source = match (expert_layout, index) {
                // A sparse layer has no `mlp.gate_proj`: its first expert is
                // the layer's MLP, which is what keeps a dense file unchanged.
                (Some(experts), 4..=6) => ProjectionSource {
                    tensor: experts.expert(layer, 0)[index - 4].clone(),
                    row_offset: 0,
                },
                _ => layout.source(layer, index, &linear_dims),
            };
            let mse = write_matrix(
                &mut file,
                &mut store,
                &MatrixJob {
                    tensor: &source.tensor,
                    source_row_offset: source.row_offset,
                    label: &label,
                    rows,
                    cols,
                    group_size,
                    bits: 4,
                    emit_dims: true,
                    channel_energy,
                },
            )?;
            if *name == "q_proj" || *name == "down_proj" {
                log(&format!(
                    "  L{layer}.{name}: [{rows}x{cols}] mse={}",
                    fmt_sci(mse)
                ));
            }
        }
        // Bias block, in projection order, immediately after the seven linears.
        for (index, name) in LAYER_LINEAR_NAMES.iter().enumerate() {
            if !config.has_bias(index) {
                continue;
            }
            write_f32_vector(
                &mut file,
                &mut store,
                &layer_bias_name(layer, name),
                linear_dims[index].0,
                false,
            )?;
        }
        // QK-norm block, then the sandwich block, then the two layer norms —
        // exactly the order `format::RaiModelFile::layer` reads them in.
        if config.has_qk_norm || config.has_full_qk_norm {
            let (q_len, k_len) = if config.has_full_qk_norm {
                (config.attention_dim(), config.kv_dim())
            } else {
                (head_dim as usize, head_dim as usize)
            };
            for (name, len) in qk_norm_names(layer).into_iter().zip([q_len, k_len]) {
                write_f32_vector(&mut file, &mut store, &name, len, folds.norm_plus_one)?;
            }
        }
        if config.has_sandwich_norm {
            for name in sandwich_norm_names(layer) {
                write_f32_vector(&mut file, &mut store, &name, hidden, folds.norm_plus_one)?;
            }
        }
        if let Some(experts) = expert_layout {
            // Router first, then experts 1.., matching the reader. Expert 0's
            // three projections were already written above as the layer's MLP.
            write_f32_vector(
                &mut file,
                &mut store,
                &experts.router(layer),
                config.num_experts as usize * hidden,
                false,
            )?;
            for expert in 1..config.num_experts as usize {
                for (name, (rows, cols)) in experts
                    .expert(layer, expert)
                    .into_iter()
                    .zip(&linear_dims[4..])
                {
                    write_matrix(
                        &mut file,
                        &mut store,
                        &MatrixJob {
                            tensor: &name,
                            source_row_offset: 0,
                            label: &format!("L{layer}.e{expert}"),
                            rows: *rows,
                            cols: *cols,
                            group_size,
                            bits: 4,
                            emit_dims: true,
                            channel_energy: None,
                        },
                    )?;
                }
            }
        }
        for name in tail_norm_names(layer, config.has_sandwich_norm, config.post_norm) {
            write_f32_vector(&mut file, &mut store, &name, hidden, folds.norm_plus_one)?;
        }
        enter("layers", 2 + layer, Some((layer, num_layers)));
        log(&format!(
            "  Layer {layer}/{num_layers}: {:.1}s",
            t0.elapsed().as_secs_f64()
        ));
    }

    // ---- Section L+1: final norm -------------------------------------------
    enter("final-norm", 1 + num_layers, None);
    write_f32_vector(
        &mut file,
        &mut store,
        "model.norm.weight",
        hidden,
        folds.norm_plus_one,
    )?;

    // ---- Section L+2 (untied only): lm_head --------------------------------
    enter("lm_head", 2 + num_layers, None);
    if tied {
        log("\n  lm_head: tied to embedding");
    } else {
        log("\n=== LM_HEAD 4-BIT (untied) ===");
        let t0 = Instant::now();
        let mse = write_matrix(
            &mut file,
            &mut store,
            &MatrixJob {
                tensor: "lm_head.weight",
                source_row_offset: 0,
                label: "lm_head",
                rows: vocab,
                cols: hidden,
                group_size,
                bits: 4,
                emit_dims: true,
                channel_energy: None,
            },
        )?;
        log(&format!(
            "  lm_head [{vocab}x{hidden}] mse={}: {:.1}s",
            fmt_sci(mse),
            t0.elapsed().as_secs_f64()
        ));
    }

    let written = file.stream_position()?;
    if written != total_size {
        bail!("internal error: wrote {written} bytes, planned {total_size}");
    }
    file.sync_all()?;
    drop(file);
    // Disarmed before the rename, not after: from here the temp file holds a
    // complete, fsynced model, and if the rename fails — the target held open
    // by a scanner, or marked read-only — deleting minutes of finished work
    // would be worse than leaving a .partial the error can point at.
    tmp_guard.keep = true;
    std::fs::rename(&tmp_path, &output_path).with_context(|| {
        format!(
            "moving {} into place as {}; the finished conversion is intact at the \
             first path — move or rename it by hand",
            tmp_path.display(),
            output_path.display()
        )
    })?;

    enter("tokenizer", total_units as u32, None);
    let quant_elapsed = quant_started.elapsed().as_secs_f64();
    log(&format!(
        "\nQuantization: {quant_elapsed:.1}s ({:.1} min)",
        quant_elapsed / 60.0
    ));
    log(&format!(
        "\nWrote: {} ({:.1} MB, {num_sections} sections)",
        output_path.display(),
        total_size as f64 / 1e6
    ));

    let tokenizer_copied = copy_tokenizer_json(&tokenizer_src, &tokenizer_dst)?;
    if tokenizer_copied {
        log(&format!("Tokenizer: {}", tokenizer_dst.display()));
    } else {
        log(&format!(
            "Tokenizer already present (identical): {}",
            tokenizer_dst.display()
        ));
    }

    let elapsed = started.elapsed();
    enter("done", total_units as u32, None);
    let summary = ConvertSummary {
        output_path,
        bytes_written: total_size,
        num_sections,
        tokenizer_path: tokenizer_dst,
        tokenizer_copied,
        elapsed,
        source_bytes,
        source_files,
        parameters,
        context,
        kv_cache_bytes: kv_bytes,
    };
    log(&format!(
        "Compression: {} -> {} ({:.2}x smaller), {:.2} bits per parameter over {parameters} \
         parameters",
        crate::cli::format_bytes(summary.source_bytes),
        crate::cli::format_bytes(summary.bytes_written),
        summary.compression_ratio(),
        summary.bits_per_parameter(),
    ));
    log(&format!(
        "\n=== DONE in {:.1}s ({:.1} min) ===",
        elapsed.as_secs_f64(),
        elapsed.as_secs_f64() / 60.0
    ));

    Ok(summary)
}

// =============================================================================
// Validation
// =============================================================================

fn validate_options(options: &ConvertOptions) -> Result<()> {
    for (flag, value) in [
        ("--group-size", options.group_size),
        ("--embed-group-size", options.embed_group_size),
    ] {
        if !(2..=254).contains(&value) || !value.is_multiple_of(2) {
            bail!("{flag} must be an even integer in 2..=254, got {value}");
        }
    }
    // Zero is `FOLLOW_MODEL_CONTEXT`, not a context: `resolve_max_context`
    // turns it into the model's own and enforces the same ceiling on that.
    if options.max_context > MAX_CONTEXT {
        bail!(
            "--max-context must be in 1..={MAX_CONTEXT}, got {}",
            options.max_context
        );
    }
    if !options.model_dir.is_dir() {
        bail!("{} is not a directory", options.model_dir.display());
    }
    Ok(())
}

/// Mirror of `raimodel.validate_model_config` / the reader's `validate_config`.
fn validate_model_config(config: &RaiConfig) -> Result<()> {
    let bounded = [
        ("hidden_size", config.hidden_size, MAX_HIDDEN_SIZE),
        ("num_layers", config.num_layers, MAX_LAYERS),
        ("num_heads", config.num_heads, MAX_HEADS),
        ("num_kv_heads", config.num_kv_heads, MAX_HEADS),
        ("head_dim", config.head_dim, MAX_HIDDEN_SIZE),
        (
            "intermediate_size",
            config.intermediate_size,
            MAX_INTERMEDIATE_SIZE,
        ),
        ("vocab_size", config.vocab_size, MAX_VOCAB_SIZE),
        ("max_context", config.max_context, MAX_CONTEXT),
    ];
    for (name, value, maximum) in bounded {
        if value == 0 || value > maximum {
            bail!("invalid {name}: {value}; the .raimodel reader requires 1..={maximum}");
        }
    }
    if !config.hidden_size.is_multiple_of(2) || !config.intermediate_size.is_multiple_of(2) {
        bail!("hidden and intermediate dimensions must be even for packed 4-bit kernels");
    }
    if !config.head_dim.is_multiple_of(8) {
        bail!(
            "head_dim must be a multiple of 8 for SIMD attention kernels, got {}",
            config.head_dim
        );
    }
    if !config.num_heads.is_multiple_of(config.num_kv_heads) {
        bail!(
            "num_heads ({}) must be divisible by num_kv_heads ({})",
            config.num_heads,
            config.num_kv_heads
        );
    }
    // `num_heads * head_dim` may differ from `hidden_size` (Gemma). Mirror of
    // the reader's `validate_config`.
    let attention_dim = config.num_heads as u64 * config.head_dim as u64;
    if attention_dim > MAX_INTERMEDIATE_SIZE as u64 {
        bail!(
            "num_heads * head_dim is {attention_dim}; the reader's maximum is \
             {MAX_INTERMEDIATE_SIZE}"
        );
    }
    if !attention_dim.is_multiple_of(2) {
        bail!("num_heads * head_dim must be even for packed 4-bit kernels, got {attention_dim}");
    }

    let group_size = config.group_size as usize;
    let max_linear_groups = (config.hidden_size as usize)
        .div_ceil(group_size)
        .max((config.intermediate_size as usize).div_ceil(group_size))
        .max((attention_dim as usize).div_ceil(group_size));
    if max_linear_groups > MAX_GEMM_GROUPS {
        bail!(
            "group_size {group_size} needs {max_linear_groups} quantization groups for \
             hidden={}/intermediate={}; the reader's kernel maximum is {MAX_GEMM_GROUPS}. \
             Use a larger --group-size.",
            config.hidden_size,
            config.intermediate_size
        );
    }
    let embedding_groups = (config.hidden_size as usize).div_ceil(config.embed_group_size as usize);
    if embedding_groups > MAX_GEMM_GROUPS {
        bail!(
            "embed_group_size {} needs {embedding_groups} embedding groups for hidden={}; \
             the reader's kernel maximum is {MAX_GEMM_GROUPS}. Use a larger \
             --embed-group-size.",
            config.embed_group_size,
            config.hidden_size
        );
    }

    for (name, value) in [
        ("rope_theta", config.rope_theta),
        ("norm_eps", config.norm_eps),
    ] {
        if !value.is_finite() || value <= 0.0 {
            bail!("{name} must be finite and positive, got {value}");
        }
    }

    let rope_bytes = rope_table_bytes(config.head_dim, config.max_context);
    // Widening only: `usize` is at least 32 bits everywhere this builds, and
    // the constant is 512 MiB.
    if rope_bytes > MAX_ROPE_TABLE_BYTES as u64 {
        bail!(
            "RoPE table would need {rope_bytes} bytes (max_context={}, head_dim={}); the \
             reader's maximum is {MAX_ROPE_TABLE_BYTES}. Lower --max-context.",
            config.max_context,
            config.head_dim
        );
    }
    Ok(())
}

// =============================================================================
// Context and size arithmetic
// =============================================================================

/// Bytes the reader's RoPE table needs for `max_context`.
///
/// Mirrors `layers::RoPETable::with_scaling`, which allocates `cos` and `sin`
/// of `max_ctx * (head_dim / 2)` f32 each.
fn rope_table_bytes(head_dim: u32, max_context: u32) -> u64 {
    max_context as u64 * (head_dim as u64 / 2) * 2 * 4
}

/// Largest context whose RoPE table still fits [`MAX_ROPE_TABLE_BYTES`].
fn rope_table_context_limit(head_dim: u32) -> u32 {
    let per_position = (head_dim as u64 / 2) * 2 * 4;
    if per_position == 0 {
        // head_dim < 2 is rejected by `validate_model_config` on its own terms;
        // no context is the binding constraint here.
        return MAX_CONTEXT;
    }
    u32::try_from(MAX_ROPE_TABLE_BYTES as u64 / per_position).unwrap_or(u32::MAX)
}

/// KV-cache bytes the runtime allocates for `max_context`.
///
/// Mirrors `RaiModel::kv_cache_bytes` in `model.rs`, which describes the
/// allocation `KVCache::new` actually makes: a K and a V buffer, f32, of
/// `num_kv_heads * max_ctx * head_dim` elements, per layer. Saturating for the
/// same reason it is there — a config may legally describe a cache larger than
/// the address space, and reporting `u64::MAX` bytes beats wrapping to a small
/// number that looks affordable.
fn kv_cache_bytes(num_layers: u32, num_kv_heads: u32, head_dim: u32, max_context: u32) -> u64 {
    2u64.saturating_mul(num_layers as u64)
        .saturating_mul(num_kv_heads as u64)
        .saturating_mul(max_context as u64)
        .saturating_mul(head_dim as u64)
        .saturating_mul(std::mem::size_of::<f32>() as u64)
}

/// The sliding-window span that constrains an export, or `None`.
///
/// A window only constrains when the model actually uses it: Qwen2.5 ships
/// `sliding_window` alongside `use_sliding_window: false`, and honouring the
/// number there would cap a 32k model at 4k for no reason.
fn sliding_window_limit(hf: &serde_json::Value) -> Option<u64> {
    let window = hf.get("sliding_window").and_then(|v| v.as_u64())?;
    let used = hf
        .get("use_sliding_window")
        .and_then(|v| v.as_bool())
        .unwrap_or(true);
    (window > 0 && used).then_some(window)
}

/// The shape numbers a parameter count depends on.
#[derive(Debug, Clone, Copy)]
struct ModelShape {
    hidden_size: u32,
    num_layers: u32,
    num_heads: u32,
    num_kv_heads: u32,
    head_dim: u32,
    intermediate_size: u32,
    vocab_size: u32,
    tied_embeddings: bool,
}

impl ModelShape {
    /// Parameters implied by the config, in elements: embedding + per-layer
    /// projections + norms + an untied head.
    ///
    /// One implementation, called by both [`preflight`] (which reports it) and
    /// [`convert_with_progress`] (which divides the output size by it): two
    /// counts that disagreed would make the bits-per-parameter figure a
    /// different number depending on which screen the user read it from.
    fn parameter_count(self) -> u64 {
        let attention_dim = self.num_heads as u64 * self.head_dim as u64;
        let kv_dim = self.num_kv_heads as u64 * self.head_dim as u64;
        let hidden = self.hidden_size as u64;
        let inter = self.intermediate_size as u64;
        let per_layer =
            hidden * attention_dim * 2 + hidden * kv_dim * 2 + hidden * inter * 3 + hidden * 2;
        self.vocab_size as u64 * hidden
            + self.num_layers as u64 * per_layer
            + hidden
            + if self.tied_embeddings {
                0
            } else {
                self.vocab_size as u64 * hidden
            }
    }
}

/// Settle the context this conversion will store.
///
/// With `requested` set, that is the answer and the existing checks apply to
/// it unchanged. With [`FOLLOW_MODEL_CONTEXT`] the model's own
/// `max_position_embeddings` is taken instead, lowered only by limits that are
/// real:
///
/// * `sliding_window`, when the model uses one — the container's attention is
///   always full causal, so beyond the window the export would diverge from
///   the reference model. Following the window keeps the existing refusal rule
///   satisfied rather than weakening it, and the choice is narrated.
/// * [`MAX_ROPE_TABLE_BYTES`] and the [`MAX_CONTEXT`] hard cap — these are
///   refusals, not clamps: a silently shortened context is exactly the failure
///   this change exists to remove, so the limit is named and the
///   `--max-context` that would fit is spelled out.
///
/// A config with no `max_position_embeddings` has no context to follow, and
/// substituting a constant would reintroduce the bug, so it is an error that
/// names the flag.
fn resolve_max_context(
    hf: &serde_json::Value,
    head_dim: u32,
    requested: u32,
) -> Result<ResolvedContext> {
    if requested != FOLLOW_MODEL_CONTEXT {
        return Ok(ResolvedContext {
            tokens: requested,
            source: ContextSource::Requested,
        });
    }

    let declared = optional_u32(hf, "max_position_embeddings")
        .context(
            "config.json declares a max_position_embeddings this converter cannot read, so there \
             is no model context to follow. Pass --max-context <TOKENS> to say what this model \
             should be built for.",
        )?
        .filter(|value| *value > 0)
        .context(
            "config.json declares no max_position_embeddings, so there is no model context to \
             follow. Pass --max-context <TOKENS> to say what this model should be built for.",
        )?;

    let (tokens, source) = match sliding_window_limit(hf) {
        Some(window) if u64::from(declared) > window => (
            u32::try_from(window).unwrap_or(u32::MAX),
            ContextSource::SlidingWindow,
        ),
        _ => (declared, ContextSource::ModelConfig),
    };

    let rope_limit = rope_table_context_limit(head_dim);
    let ceiling = rope_limit.min(MAX_CONTEXT);
    if tokens > ceiling {
        let limit = if rope_limit <= MAX_CONTEXT {
            format!(
                "the {} MiB RoPE table budget (MAX_ROPE_TABLE_BYTES) at head_dim {head_dim}",
                MAX_ROPE_TABLE_BYTES >> 20
            )
        } else {
            format!("the container's {MAX_CONTEXT}-token maximum (MAX_CONTEXT)")
        };
        bail!(
            "{} is {tokens} tokens, which exceeds {limit}. Nothing was clamped: re-run with \
             --max-context {ceiling} (or lower) to say what this model should be built for.",
            source.describe(),
        );
    }

    Ok(ResolvedContext { tokens, source })
}

/// On-disk bytes of the shards a checkpoint is actually read from.
fn checkpoint_source_bytes(store: &SafeTensorsSet) -> Result<(u64, usize)> {
    let mut total = 0u64;
    for path in store.shard_paths() {
        let metadata =
            std::fs::metadata(path).with_context(|| format!("measuring {}", path.display()))?;
        total = total.saturating_add(metadata.len());
    }
    Ok((total, store.shard_paths().len()))
}

/// Resolve `head_dim`, honouring an explicit config value.
///
/// A decoupled `head_dim` (`num_heads * head_dim != hidden_size`, as Gemma
/// uses) is no longer refused: `q_proj` is stored `[num_heads*head_dim, hidden]`
/// and `o_proj` `[hidden, num_heads*head_dim]`, so the attention block still
/// reads and writes hidden-sized vectors and only its interior changes width.
/// When the config omits `head_dim` the derived value must divide exactly —
/// silently truncating would misdescribe the model.
fn resolve_head_dim(config_head_dim: Option<u32>, hidden_size: u32, num_heads: u32) -> Result<u32> {
    if num_heads == 0 {
        bail!("num_attention_heads must be greater than zero");
    }
    match config_head_dim {
        Some(head_dim) if head_dim != 0 => Ok(head_dim),
        _ => {
            if !hidden_size.is_multiple_of(num_heads) {
                bail!(
                    "model config omits head_dim and hidden_size {hidden_size} is not divisible \
                     by num_attention_heads {num_heads}"
                );
            }
            Ok(hidden_size / num_heads)
        }
    }
}

/// Pick the gated-MLP activation from the config.
///
/// Gemma trains against `gelu_pytorch_tanh` and, in older checkpoints, leaves
/// `hidden_activation` null with a misleading `hidden_act: "gelu"` — the
/// reference model resolves that to `gelu_pytorch_tanh`, so this does too.
/// Anything else is refused by name rather than run as SiLU.
fn resolve_activation(hf: &serde_json::Value, is_gemma: bool) -> Result<Activation> {
    let declared = hf
        .get("hidden_activation")
        .and_then(|v| v.as_str())
        .or_else(|| hf.get("hidden_act").and_then(|v| v.as_str()));
    match (is_gemma, declared) {
        // Gemma with hidden_activation unset: transformers warns and uses
        // gelu_pytorch_tanh, ignoring hidden_act.
        (true, None) => Ok(Activation::GeluTanh),
        (true, Some("gelu")) if hf.get("hidden_activation").is_none_or(|v| v.is_null()) => {
            Ok(Activation::GeluTanh)
        }
        (_, Some("gelu_pytorch_tanh")) => Ok(Activation::GeluTanh),
        (false, None | Some("silu") | Some("swish")) => Ok(Activation::Silu),
        (_, Some(other)) => bail!(
            "config declares hidden activation '{other}'; the container stores SiLU/SwiGLU and \
             GeLU-tanh/GeGLU only, and running the wrong one would silently produce a different \
             model."
        ),
    }
}

/// Read `rope_scaling` into the container's representation.
///
/// transformers >= 5 normalizes plain RoPE into `{"rope_type": "default"}`, so
/// the field's presence means nothing on its own. Anything other than absent,
/// null, "default" or "llama3" is refused: the reader would otherwise build a
/// table for the wrong positions.
fn resolve_rope_scaling(hf: &serde_json::Value) -> Result<RopeScaling> {
    let Some(scaling) = hf.get("rope_scaling") else {
        return Ok(RopeScaling::None);
    };
    if scaling.is_null() {
        return Ok(RopeScaling::None);
    }
    let Some(object) = scaling.as_object() else {
        bail!("config field rope_scaling is not an object: {scaling}");
    };
    let rope_type = object
        .get("rope_type")
        .or_else(|| object.get("type"))
        .and_then(|v| v.as_str());
    match rope_type {
        None | Some("default") => Ok(RopeScaling::None),
        Some("llama3") => {
            let number = |key: &str| -> Result<f64> {
                object
                    .get(key)
                    .and_then(serde_json::Value::as_f64)
                    .with_context(|| {
                        format!("rope_scaling declares rope_type 'llama3' but has no numeric {key}")
                    })
            };
            let factor = number("factor")?;
            let low_freq_factor = number("low_freq_factor")?;
            let high_freq_factor = number("high_freq_factor")?;
            let original = object
                .get("original_max_position_embeddings")
                .and_then(serde_json::Value::as_u64)
                .or_else(|| hf.get("max_position_embeddings").and_then(|v| v.as_u64()))
                .context(
                    "rope_scaling declares rope_type 'llama3' but neither it nor the config \
                     provides original_max_position_embeddings",
                )?;
            for (name, value) in [
                ("factor", factor),
                ("low_freq_factor", low_freq_factor),
                ("high_freq_factor", high_freq_factor),
            ] {
                if !value.is_finite() || value <= 0.0 {
                    bail!("rope_scaling {name} must be finite and positive, got {value}");
                }
            }
            if (high_freq_factor - low_freq_factor).abs() == 0.0 {
                bail!("rope_scaling high_freq_factor must differ from low_freq_factor");
            }
            let original = u32::try_from(original)
                .context("rope_scaling original_max_position_embeddings does not fit in a u32")?;
            if original == 0 || original > MAX_CONTEXT {
                bail!(
                    "rope_scaling original_max_position_embeddings must be in 1..={MAX_CONTEXT}, \
                     got {original}"
                );
            }
            Ok(RopeScaling::Llama3 {
                factor: factor as f32,
                low_freq_factor: low_freq_factor as f32,
                high_freq_factor: high_freq_factor as f32,
                original_max_position: original,
            })
        }
        Some(other) => bail!(
            "config declares rope_scaling type '{other}'; the container stores plain RoPE and \
             the llama3 scheme only, so positions would be wrong."
        ),
    }
}

/// Work out which projections carry biases, and insist every layer agrees.
///
/// A checkpoint where only some layers are biased is not a model this (or any)
/// exporter should guess at: the container stores one mask for the whole file,
/// so a partial set would mean silently dropping real parameters.
fn resolve_bias_mask(store: &SafeTensorsSet, num_layers: u32) -> Result<u8> {
    if num_layers == 0 {
        return Ok(0);
    }
    let mask_for = |layer: u32| -> u8 {
        let mut mask = 0u8;
        for (index, name) in LAYER_LINEAR_NAMES.iter().enumerate() {
            if store.info(&layer_bias_name(layer, name)).is_some() {
                mask |= 1 << index;
            }
        }
        mask
    };
    let mask = mask_for(0);
    for layer in 1..num_layers {
        let other = mask_for(layer);
        if other != mask {
            bail!(
                "checkpoint is inconsistent: layer 0 has projection biases {mask:#04x} but layer \
                 {layer} has {other:#04x}. The container stores one bias mask for the whole \
                 model, so exporting this would drop real parameters."
            );
        }
    }
    Ok(mask)
}

/// The tensor names of a layer's per-head QK norms.
fn qk_norm_names(layer: u32) -> [String; 2] {
    [
        format!("model.layers.{layer}.self_attn.q_norm.weight"),
        format!("model.layers.{layer}.self_attn.k_norm.weight"),
    ]
}

/// How many experts a layer has, how many each token uses, and whether the
/// selected weights are renormalized.
///
/// Returns `(0, 0, false)` for a dense model. The expert *tensors* are found
/// by name in [`ExpertLayout`]; this reads only the config, so a config-only
/// inspection reports the same verdict a conversion would.
fn resolve_experts(hf: &serde_json::Value, intermediate_size: u32) -> Result<(u16, u8, bool)> {
    let count = ["num_experts", "num_local_experts"]
        .iter()
        .filter_map(|key| optional_u32(hf, key).transpose())
        .next()
        .transpose()?
        .unwrap_or(0);
    if count == 0 {
        return Ok((0, 0, false));
    }
    let count = u16::try_from(count)
        .map_err(|_| anyhow::anyhow!("num_experts {count} does not fit in the header's u16"))?;
    if count < 2 {
        bail!("config declares {count} expert; a dense model must not declare experts at all");
    }
    let per_token = optional_u32(hf, "num_experts_per_tok")?
        .context("config declares experts but no num_experts_per_tok")?;
    let per_token = u8::try_from(per_token)
        .ok()
        .filter(|value| *value as u16 <= count && *value > 0)
        .with_context(|| format!("num_experts_per_tok {per_token} is not in 1..={count}"))?;
    // A shared expert runs for *every* token in addition to the routed ones.
    // The container has no slot for one, and dropping it would remove a whole
    // pathway from the model rather than degrade it.
    for key in ["shared_expert_intermediate_size", "n_shared_experts"] {
        if let Some(value) = optional_u32(hf, key)? {
            if value > 0 {
                bail!(
                    "config declares {key}={value}; this model runs a shared expert for every                      token alongside the routed ones, and the container stores routed experts                      only. Use a model without a shared expert."
                );
            }
        }
    }
    if let Some(moe_intermediate) = optional_u32(hf, "moe_intermediate_size")? {
        if moe_intermediate != intermediate_size {
            bail!(
                "config declares moe_intermediate_size={moe_intermediate} but                  intermediate_size={intermediate_size}; the container stores one MLP width."
            );
        }
    }
    let norm_topk = hf
        .get("norm_topk_prob")
        .and_then(|value| value.as_bool())
        .unwrap_or(true);
    Ok((count, per_token, norm_topk))
}

/// Where a sparse checkpoint keeps its router and expert tensors.
///
/// The two published spellings differ only in prefix and projection names, so
/// the layout is detected from the tensors present rather than from
/// `model_type` - the same rule the fused-projection detection follows.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ExpertLayout {
    /// `mlp.gate` + `mlp.experts.{e}.{gate,up,down}_proj` (OLMoE, Qwen3-MoE).
    MlpExperts,
    /// `block_sparse_moe.gate` + `block_sparse_moe.experts.{e}.w1/w3/w2`
    /// (Mixtral). `w1` is the gate, `w3` the up, `w2` the down.
    BlockSparseMoe,
}

impl ExpertLayout {
    fn detect(store: &SafeTensorsSet) -> Result<Self> {
        if store.info("model.layers.0.mlp.gate.weight").is_some() {
            return Ok(Self::MlpExperts);
        }
        if store
            .info("model.layers.0.block_sparse_moe.gate.weight")
            .is_some()
        {
            return Ok(Self::BlockSparseMoe);
        }
        bail!(
            "config declares experts but the checkpoint has neither              model.layers.0.mlp.gate.weight nor model.layers.0.block_sparse_moe.gate.weight,              so the router cannot be located."
        )
    }

    fn router(self, layer: u32) -> String {
        match self {
            Self::MlpExperts => format!("model.layers.{layer}.mlp.gate.weight"),
            Self::BlockSparseMoe => {
                format!("model.layers.{layer}.block_sparse_moe.gate.weight")
            }
        }
    }

    /// The gate, up and down tensors of one expert, in stored order.
    fn expert(self, layer: u32, expert: usize) -> [String; 3] {
        match self {
            Self::MlpExperts => ["gate_proj", "up_proj", "down_proj"]
                .map(|name| format!("model.layers.{layer}.mlp.experts.{expert}.{name}.weight")),
            Self::BlockSparseMoe => ["w1", "w3", "w2"].map(|name| {
                format!("model.layers.{layer}.block_sparse_moe.experts.{expert}.{name}.weight")
            }),
        }
    }
}

/// Read the second RoPE base and the layer stride, for a model whose layers do
/// not all rotate at the same frequency.
///
/// Returns `(0.0, 0)` for the overwhelming majority of checkpoints, which have
/// one base. Gemma3 is the family this exists for: its sliding layers use
/// `rope_local_base_freq` and its global layers `rope_theta`, and
/// `Gemma3Config` derives which is which as
/// `"sliding_attention" if (i + 1) % sliding_window_pattern else "full_attention"`.
///
/// An explicit `layer_types` list is honoured only when it *is* that pattern.
/// The container stores a stride, and silently rounding an irregular list to
/// the nearest stride would rotate some layers at the wrong base — a model
/// that loads, runs, and is quietly worse.
fn resolve_per_layer_rope(hf: &serde_json::Value, num_layers: u32) -> Result<(f32, u8)> {
    let local = resolve_softcap(hf, "rope_local_base_freq").unwrap_or(0.0);
    if local <= 0.0 {
        return Ok((0.0, 0));
    }
    let stride = optional_u32(hf, "sliding_window_pattern")?.unwrap_or(6);
    if stride < 2 {
        bail!(
            "sliding_window_pattern is {stride}; the container stores a stride of 2 or more,              and a stride below that describes no alternation at all."
        );
    }
    let stride = u8::try_from(stride).map_err(|_| {
        anyhow::anyhow!("sliding_window_pattern {stride} does not fit in the header's one byte")
    })?;

    if let Some(types) = hf.get("layer_types").and_then(|value| value.as_array()) {
        if types.len() != num_layers as usize {
            bail!(
                "layer_types lists {} entries but the model has {num_layers} layers",
                types.len()
            );
        }
        for (index, entry) in types.iter().enumerate() {
            let name = entry.as_str().unwrap_or_default();
            let is_global = (index + 1).is_multiple_of(stride as usize);
            let expected = if is_global {
                "full_attention"
            } else {
                "sliding_attention"
            };
            if name != expected {
                bail!(
                    "layer_types[{index}] is '{name}' but a stride of {stride} implies                      '{expected}'. The container stores the stride, not a per-layer list, so an                      irregular pattern cannot be represented and would rotate some layers at the                      wrong RoPE base."
                );
            }
        }
    }
    Ok((local, stride))
}

/// The tensor names of a layer's two sandwich norms, in stored order.
fn sandwich_norm_names(layer: u32) -> [String; 2] {
    [
        format!("model.layers.{layer}.post_attention_layernorm.weight"),
        format!("model.layers.{layer}.post_feedforward_layernorm.weight"),
    ]
}

/// The tensors supplying a layer's two tail norms, in stored order.
///
/// For a pre-norm model these are the norms applied to the residual stream
/// before the attention and MLP blocks. For a post-norm model (OLMo2) the same
/// two slots hold the norms applied to those blocks' *outputs* — there is no
/// pre-block norm to store, so the slots are reused rather than left empty and
/// two more added.
fn tail_norm_names(layer: u32, sandwich: bool, post_norm: bool) -> [String; 2] {
    if post_norm {
        return sandwich_norm_names(layer);
    }
    [
        format!("model.layers.{layer}.input_layernorm.weight"),
        pre_mlp_norm_name(layer, sandwich),
    ]
}

/// Decide whether this checkpoint is post-normed, from the tensors present.
///
/// A post-norm model has no `input_layernorm` anywhere and does have both
/// output norms. Anything in between — some layers pre-normed, an output norm
/// missing — is refused rather than guessed, because the flag covers the whole
/// file and the wrong answer changes every layer's arithmetic.
fn resolve_post_norm(store: &SafeTensorsSet, num_layers: u32) -> Result<bool> {
    if num_layers == 0 {
        return Ok(false);
    }
    let has_input_norm = |layer: u32| {
        store
            .info(&format!("model.layers.{layer}.input_layernorm.weight"))
            .is_some()
    };
    if has_input_norm(0) {
        return Ok(false);
    }
    for layer in 1..num_layers {
        if has_input_norm(layer) {
            bail!(
                "checkpoint is inconsistent: layer 0 has no input_layernorm but layer {layer} \
                 does. The container stores one norm placement for the whole model."
            );
        }
    }
    for layer in 0..num_layers {
        for name in sandwich_norm_names(layer) {
            if store.info(&name).is_none() {
                bail!(
                    "layer {layer} has no input_layernorm and no '{name}' either, so there is \
                     no norm to apply to the block. This converter implements pre-norm models \
                     and OLMo2-style post-norm models, which carry post_attention_layernorm \
                     and post_feedforward_layernorm."
                );
            }
        }
    }
    Ok(true)
}

/// The tensor supplying the norm applied to the residual stream before the MLP.
///
/// For a sandwich-normed model that is `pre_feedforward_layernorm`; for
/// everything else it is `post_attention_layernorm`, which for Gemma2 means
/// something else entirely (see `format.rs`'s layer-section documentation).
fn pre_mlp_norm_name(layer: u32, sandwich: bool) -> String {
    if sandwich {
        format!("model.layers.{layer}.pre_feedforward_layernorm.weight")
    } else {
        format!("model.layers.{layer}.post_attention_layernorm.weight")
    }
}

/// Decide whether this checkpoint carries per-head QK norms, insisting that
/// every layer agrees and that both halves of every pair are present.
///
/// Like `resolve_bias_mask`, a partial set is refused rather than guessed at:
/// the container stores one flag for the whole file, so exporting a checkpoint
/// where only some layers were normed would silently change the maths of the
/// rest.
fn resolve_qk_norm(
    store: &SafeTensorsSet,
    num_layers: u32,
    head_dim: u32,
    attention_dim: usize,
    kv_dim: usize,
) -> Result<QkNormKind> {
    if num_layers == 0 {
        return Ok(QkNormKind::None);
    }
    let present = |layer: u32| -> (bool, bool) {
        let [q, k] = qk_norm_names(layer);
        (store.info(&q).is_some(), store.info(&k).is_some())
    };
    let (q0, k0) = present(0);
    if q0 != k0 {
        bail!(
            "layer 0 carries only one of self_attn.q_norm / self_attn.k_norm; the container \
             stores the pair or neither, and normalizing one side alone would change the \
             attention scores."
        );
    }
    for layer in 1..num_layers {
        let (q, k) = present(layer);
        if (q, k) != (q0, k0) {
            bail!(
                "checkpoint is inconsistent: layer 0 {} per-head QK norms but layer {layer} \
                 {}. The container stores one flag for the whole model.",
                if q0 { "has" } else { "has no" },
                if q { "does" } else { "does not" }
            );
        }
    }
    if !q0 {
        return Ok(QkNormKind::None);
    }

    // Same tensor names, two different operations. The width is what tells
    // them apart, so it is read rather than inferred from `model_type`: a
    // fine-tune that renames itself still has to store one shape or the other.
    let head_dim = head_dim as usize;
    let [q_name, _] = qk_norm_names(0);
    let q_values: usize = store.require(&q_name)?.shape.iter().product();
    let kind = if q_values == head_dim {
        QkNormKind::PerHead
    } else if q_values == attention_dim {
        QkNormKind::FullWidth
    } else {
        bail!(
            "tensor '{q_name}' holds {q_values} values, which is neither head_dim ({head_dim}, \
             a per-head norm as Qwen3 uses) nor num_heads*head_dim ({attention_dim}, a \
             projection-wide norm as OLMo2 uses); the container implements those two shapes."
        );
    };
    // `head_dim == attention_dim` only when there is one head, in which case
    // the two shapes coincide and either reading is correct.
    let (q_expected, k_expected) = match kind {
        QkNormKind::PerHead => (head_dim, head_dim),
        QkNormKind::FullWidth => (attention_dim, kv_dim),
        QkNormKind::None => unreachable!("returned above"),
    };
    for layer in 0..num_layers {
        let [q, k] = qk_norm_names(layer);
        check_vector(store, &q, q_expected)?;
        check_vector(store, &k, k_expected)?;
    }
    Ok(kind)
}

/// Which of the two QK-norm shapes a checkpoint carries.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum QkNormKind {
    None,
    /// One `head_dim` vector applied inside each head, before RoPE (Qwen3).
    PerHead,
    /// Vectors spanning the whole Q and K projections, applied before the
    /// tensor is split into heads (OLMo2). Under grouped-query attention the
    /// two are different lengths.
    FullWidth,
}

/// Confirm a sandwich-normed family really carries all four norms per layer.
fn check_sandwich_norms(store: &SafeTensorsSet, num_layers: u32, hidden: usize) -> Result<()> {
    for layer in 0..num_layers {
        check_vector(store, &pre_mlp_norm_name(layer, true), hidden)?;
        for name in sandwich_norm_names(layer) {
            check_vector(store, &name, hidden)?;
        }
    }
    Ok(())
}

/// Read a logit softcap out of the config. Absent or null means disabled.
fn resolve_softcap(hf: &serde_json::Value, key: &str) -> Result<f32> {
    let Some(value) = hf.get(key) else {
        return Ok(0.0);
    };
    if value.is_null() {
        return Ok(0.0);
    }
    let cap = value
        .as_f64()
        .with_context(|| format!("config field {key} is not a number: {value}"))?;
    if !cap.is_finite() || cap <= 0.0 {
        bail!("config field {key} must be finite and positive, got {cap}");
    }
    Ok(cap as f32)
}

/// The query-key multiplier, stored only when it differs from the default.
///
/// Gemma2 sets `query_pre_attn_scalar` and attends with
/// `query_pre_attn_scalar ** -0.5` (`models/gemma2/modeling_gemma2.py:229`).
/// For gemma-2-2b that is 256 against a `head_dim` of 256, i.e. exactly the
/// default, so nothing is stored and the file stays as small as it can be. For
/// gemma-2-27b it is 144 against a `head_dim` of 128, which is a genuinely
/// different scale — and one whose absence produces plausible-looking but worse
/// output rather than an error, which is why it is checked rather than assumed.
fn resolve_attn_scale(hf: &serde_json::Value, head_dim: u32) -> Result<f32> {
    let Some(value) = hf.get("query_pre_attn_scalar") else {
        return Ok(0.0);
    };
    if value.is_null() {
        return Ok(0.0);
    }
    let scalar = value
        .as_f64()
        .context("config field query_pre_attn_scalar is not a number")?;
    if !scalar.is_finite() || scalar <= 0.0 {
        bail!("config field query_pre_attn_scalar must be finite and positive, got {scalar}");
    }
    let scale = scalar.powf(-0.5) as f32;
    let default = 1.0 / (head_dim as f32).sqrt();
    Ok(if scale == default { 0.0 } else { scale })
}

/// Mirror of `raimodel.assert_exportable_architecture`, driven by the config
/// and the checkpoint's tensor names instead of a live torch module tree.
///
/// `store` is `None` when only a `config.json` is in hand (see [`preflight`]),
/// in which case the three tensor-level rules cannot be evaluated and every
/// config-level rule still is. Conversion itself always passes `Some`.
fn assert_exportable_architecture(
    hf: &serde_json::Value,
    store: Option<&SafeTensorsSet>,
    max_context: u32,
    num_layers: u32,
) -> Result<()> {
    let mut problems: Vec<String> = Vec::new();

    let model_type = hf.get("model_type").and_then(|v| v.as_str());
    if let Some(model_type) = model_type {
        if let Some((_, reason)) = UNSUPPORTED_MODEL_TYPES
            .iter()
            .find(|(name, _)| *name == model_type)
        {
            problems.push(format!(
                "model_type '{model_type}' is not supported: {reason}, which this format does \
                 not store."
            ));
        }
    }

    if let Some(store) = store {
        // Either a separate q_proj or a fused qkv_proj (Phi-3) is enough; both
        // absent means the module tree is not one this converter can walk.
        let has_attention_weights = ["q_proj", "qkv_proj"].iter().any(|name| {
            store
                .info(&format!("model.layers.0.self_attn.{name}.weight"))
                .is_some()
        });
        if !has_attention_weights && num_layers > 0 {
            bail!(
                "this checkpoint does not expose model.layers.0.self_attn.q_proj.weight or \
                 model.layers.0.self_attn.qkv_proj.weight; the converter supports Llama-style \
                 causal LMs (LlamaForCausalLM, MistralForCausalLM, Phi3ForCausalLM, and \
                 architecturally identical models)."
            );
        }

        // Per-layer projection biases (Qwen2/Qwen2.5) are a v2 capability now;
        // see `resolve_bias_mask`, which is where an inconsistent set is
        // caught. The *output* projection is a different matter: `bias_mask`
        // covers the seven layer projections only, so an lm_head bias has
        // nowhere to go and would be dropped in silence.
        if store.info("lm_head.bias").is_some() {
            problems.push(
                "checkpoint carries lm_head.bias; the container stores biases for the seven \
                 layer projections only, so this would be silently dropped."
                    .to_string(),
            );
        }

        // Per-head QK norms (Qwen3, Gemma3) are a v2 capability now; see
        // `resolve_qk_norm`, which is where an inconsistent or wrongly-shaped
        // set is caught by name.
    }

    // `rope_scaling` is handled by `resolve_rope_scaling`, which accepts
    // default and llama3 and refuses every other scheme by name.

    // Mixture-of-experts is a v2 capability now; `resolve_experts` reads the
    // counts and refuses a routing scheme the container cannot express.

    // `attn_logit_softcapping` and `final_logit_softcapping` are v2 header
    // fields now; `resolve_softcap` refuses a non-numeric or non-positive one.

    if let Some(sliding_window) = sliding_window_limit(hf) {
        if max_context as u64 > sliding_window {
            problems.push(format!(
                "config declares sliding_window={sliding_window} but --max-context is \
                 {max_context}; the reader always uses full causal attention, so exports beyond \
                 the window would diverge. Re-run with --max-context {sliding_window} or lower."
            ));
        }
    }

    if !problems.is_empty() {
        bail!(
            "this checkpoint cannot be represented by the .raimodel format:\n  - {}",
            problems.join("\n  - ")
        );
    }
    Ok(())
}

/// What the container would store for a checkpoint the converter accepts.
#[derive(Debug, Clone)]
pub struct PreflightContainer {
    /// Lowest container version that can express the model (1 or 2).
    pub version: u32,
    pub activation: Activation,
    pub rope_scaling: RopeScaling,
    /// Which of [`PROJECTION_NAMES`] carry biases. Always 0 when the weights
    /// were not available to look at.
    pub bias_mask: u8,
    pub embed_scale: f32,
    pub tied_embeddings: bool,
    /// Exact size of the `.raimodel` this conversion would write.
    pub output_bytes: u64,
    pub num_sections: usize,
    /// Per-head `q_norm`/`k_norm` vectors would be stored (Qwen3-shaped).
    pub has_qk_norm: bool,
    /// Gemma2's two extra per-layer norms would be stored.
    pub has_sandwich_norm: bool,
    /// QK norms span the whole projection rather than one head (OLMo2).
    pub has_full_qk_norm: bool,
    /// The two tail norms apply to block outputs, not the residual stream
    /// before them (OLMo2).
    pub post_norm: bool,
    /// Second RoPE base for non-global layers; 0.0 when the model has one.
    pub rope_local_theta: f32,
    /// Layer *i* is global when `(i + 1) % stride == 0`; 0 when unused.
    pub global_layer_stride: u8,
    /// Experts per layer; 0 for a dense MLP.
    pub num_experts: u16,
    /// Experts each token is routed to.
    pub experts_per_token: u8,
    /// Attention-logit softcap; 0.0 when the model does not cap.
    pub attn_logit_softcap: f32,
    /// Output-logit softcap; 0.0 when the model does not cap.
    pub final_logit_softcap: f32,
    /// Explicit query-key scale; 0.0 means `1/sqrt(head_dim)`.
    pub attn_scale: f32,
}

/// The result of [`preflight`]: can this checkpoint be converted, and if so
/// into what.
#[derive(Debug, Clone)]
pub struct PreflightReport {
    pub model_type: String,
    pub architectures: Vec<String>,
    pub hidden_size: u32,
    pub num_layers: u32,
    pub num_heads: u32,
    pub num_kv_heads: u32,
    pub head_dim: u32,
    pub intermediate_size: u32,
    pub vocab_size: u32,
    pub max_position_embeddings: Option<u32>,
    pub sliding_window: Option<u64>,
    pub rope_theta: f32,
    pub norm_eps: f32,
    pub tied_embeddings: bool,
    /// Parameter count implied by the config, in elements.
    pub parameters: u64,
    /// Context a conversion would store, after
    /// [`FOLLOW_MODEL_CONTEXT`] resolution. `None` when no context could be
    /// settled, in which case `reason` says why.
    pub max_context: Option<u32>,
    /// Where that context came from.
    pub context_source: Option<ContextSource>,
    /// KV cache the runtime allocates if the full stored context is used.
    /// This is the memory a later `rai run` can be asked for, and the reason
    /// a large stored context is worth seeing before conversion rather than
    /// at load.
    pub kv_cache_bytes: Option<u64>,
    /// True when `rai convert` would accept this checkpoint.
    pub supported: bool,
    /// Why it would be accepted, or every reason it would not.
    pub reason: String,
    /// `None` when unsupported.
    pub container: Option<PreflightContainer>,
    /// False when only a `config.json` was available, so the three
    /// tensor-level rules (`lm_head.bias`, per-head QK norms, per-layer bias
    /// consistency) went unevaluated and a later conversion could still fail.
    pub weights_checked: bool,
}

/// Answer "would `rai convert` accept this?" without downloading or writing
/// weights.
///
/// This is the converter's own preflight, not a second implementation of it:
/// [`resolve_head_dim`], [`resolve_activation`], [`resolve_rope_scaling`],
/// [`assert_exportable_architecture`], [`resolve_bias_mask`] and
/// [`validate_model_config`] are called in the order `convert` calls them, and
/// the accept/reject answer is theirs. It exists so a user learns a 14 GB
/// checkpoint is unsupported before downloading it, which is why `model_dir`
/// is optional: with no weights on disk, the config-level rules still run.
///
/// `Err` means the config is not a transformer config at all (missing or
/// malformed required fields). An unsupported *architecture* is a successful
/// call with `supported: false`.
///
/// `max_context` accepts [`FOLLOW_MODEL_CONTEXT`] and resolves it exactly as a
/// conversion would, so the report describes the file the user would actually
/// get rather than one built for a number the CLI no longer uses.
pub fn preflight(
    hf: &serde_json::Value,
    model_dir: Option<&Path>,
    group_size: u32,
    embed_group_size: u32,
    max_context: u32,
) -> Result<PreflightReport> {
    let hidden_size = required_u32(hf, "hidden_size")?;
    let num_layers = required_u32(hf, "num_hidden_layers")?;
    let num_heads = required_u32(hf, "num_attention_heads")?;
    let num_kv_heads = optional_u32(hf, "num_key_value_heads")?.unwrap_or(num_heads);
    let head_dim = resolve_head_dim(optional_u32(hf, "head_dim")?, hidden_size, num_heads)?;
    let intermediate_size = required_u32(hf, "intermediate_size")?;
    let vocab_size = required_u32(hf, "vocab_size")?;
    let rope_theta = optional_f64(hf, "rope_theta")?.unwrap_or(10_000.0) as f32;
    let norm_eps = optional_f64(hf, "rms_norm_eps")?.unwrap_or(1e-5) as f32;
    let tied = hf
        .get("tie_word_embeddings")
        .and_then(|v| v.as_bool())
        .unwrap_or(true);
    let model_type = hf
        .get("model_type")
        .and_then(|v| v.as_str())
        .unwrap_or("?")
        .to_string();
    let architectures = hf
        .get("architectures")
        .and_then(|v| v.as_array())
        .map(|list| {
            list.iter()
                .filter_map(|v| v.as_str().map(str::to_owned))
                .collect()
        })
        .unwrap_or_default();

    let shape = ModelShape {
        hidden_size,
        num_layers,
        num_heads,
        num_kv_heads,
        head_dim,
        intermediate_size,
        vocab_size,
        tied_embeddings: tied,
    };
    let parameters = shape.parameter_count();

    // Resolved here rather than inside the verdict below so the answer — and
    // the KV cache it implies — is reported even for a checkpoint that turns
    // out to be unsupported for some other reason.
    let context = resolve_max_context(hf, head_dim, max_context);

    let mut report = PreflightReport {
        model_type: model_type.clone(),
        architectures,
        hidden_size,
        num_layers,
        num_heads,
        num_kv_heads,
        head_dim,
        intermediate_size,
        vocab_size,
        max_position_embeddings: optional_u32(hf, "max_position_embeddings").ok().flatten(),
        sliding_window: hf.get("sliding_window").and_then(|v| v.as_u64()),
        rope_theta,
        norm_eps,
        tied_embeddings: tied,
        parameters,
        max_context: context.as_ref().ok().map(|context| context.tokens),
        context_source: context.as_ref().ok().map(|context| context.source),
        kv_cache_bytes: context
            .as_ref()
            .ok()
            .map(|context| kv_cache_bytes(num_layers, num_kv_heads, head_dim, context.tokens)),
        supported: false,
        reason: String::new(),
        container: None,
        weights_checked: false,
    };

    let is_gemma = GEMMA_MODEL_TYPES.contains(&model_type.as_str());
    let store = match model_dir {
        Some(dir) => Some(SafeTensorsSet::open(dir)?),
        None => None,
    };
    report.weights_checked = store.is_some();

    let verdict = (|| -> Result<PreflightContainer> {
        // A context that cannot be resolved is a refusal like any other: the
        // shape is still reported, `supported` is false, and the reason names
        // the flag that settles it.
        let context = *context
            .as_ref()
            .map_err(|error| anyhow::anyhow!("{error:#}"))?;
        let activation = resolve_activation(hf, is_gemma)?;
        let rope_scaling = resolve_rope_scaling(hf)?;
        assert_exportable_architecture(hf, store.as_ref(), context.tokens, num_layers)?;
        let bias_mask = match store.as_ref() {
            Some(store) => resolve_bias_mask(store, num_layers)?,
            None => 0,
        };
        let attention_dim = num_heads as usize * head_dim as usize;
        let kv_dim = num_kv_heads as usize * head_dim as usize;
        let qk_norm = match store.as_ref() {
            Some(store) => resolve_qk_norm(store, num_layers, head_dim, attention_dim, kv_dim)?,
            None => QkNormKind::None,
        };
        let has_qk_norm = qk_norm == QkNormKind::PerHead;
        let has_full_qk_norm = qk_norm == QkNormKind::FullWidth;
        let post_norm = match store.as_ref() {
            Some(store) => resolve_post_norm(store, num_layers)?,
            None => false,
        };
        let has_sandwich_norm =
            SANDWICH_NORM_MODEL_TYPES.contains(&model_type.as_str()) && !post_norm;
        let per_layer_rope = resolve_per_layer_rope(hf, num_layers)?;
        let experts = resolve_experts(hf, intermediate_size)?;
        if has_sandwich_norm {
            if let Some(store) = store.as_ref() {
                check_sandwich_norms(store, num_layers, hidden_size as usize)?;
            }
        }
        let config = RaiConfig {
            hidden_size,
            num_layers,
            num_heads,
            num_kv_heads,
            head_dim,
            intermediate_size,
            vocab_size,
            max_context: context.tokens,
            rope_theta,
            norm_eps,
            bits: 4,
            group_size: u8::try_from(group_size).map_err(|_| {
                anyhow::anyhow!("--group-size must be in 2..=254, got {group_size}")
            })?,
            embed_bits: 8,
            embed_group_size: u8::try_from(embed_group_size).map_err(|_| {
                anyhow::anyhow!("--embed-group-size must be in 2..=254, got {embed_group_size}")
            })?,
            activation,
            rope_scaling,
            bias_mask,
            embed_scale: if is_gemma {
                (hidden_size as f64).sqrt() as f32
            } else {
                1.0
            },
            has_qk_norm,
            has_sandwich_norm,
            has_full_qk_norm,
            post_norm,
            rope_local_theta: per_layer_rope.0,
            global_layer_stride: per_layer_rope.1,
            num_experts: experts.0,
            experts_per_token: experts.1,
            norm_topk_prob: experts.2,
            attn_logit_softcap: resolve_softcap(hf, "attn_logit_softcapping")?,
            final_logit_softcap: resolve_softcap(hf, "final_logit_softcapping")?,
            attn_scale: resolve_attn_scale(hf, head_dim)?,
        };
        validate_model_config(&config)?;
        // Studio's Check and `rai convert` are documented as running the same
        // preflight, so the fused-projection widths are settled here too: a
        // report saying "supported" that then failed at layer 0 on a shape
        // would be worse than no report.
        if let Some(store) = store.as_ref() {
            let layout = ProjectionLayout::detect(store, num_layers)?;
            layout.check_fused_tensors(store, num_layers, &config.projection_dims())?;
        }
        let (section_sizes, output_bytes) = plan_sections(&config, tied)?;
        Ok(PreflightContainer {
            version: config.version(),
            activation,
            rope_scaling,
            bias_mask,
            embed_scale: config.embed_scale,
            tied_embeddings: tied,
            output_bytes,
            num_sections: section_sizes.len(),
            has_qk_norm,
            has_sandwich_norm,
            has_full_qk_norm,
            post_norm,
            rope_local_theta: per_layer_rope.0,
            global_layer_stride: per_layer_rope.1,
            num_experts: experts.0,
            experts_per_token: experts.1,
            attn_logit_softcap: config.attn_logit_softcap,
            final_logit_softcap: config.final_logit_softcap,
            attn_scale: config.attn_scale,
        })
    })();

    match verdict {
        Ok(container) => {
            report.reason = format!(
                "`rai convert` accepts this checkpoint: model_type '{model_type}' converts to a \
                 container v{} file of {} bytes ({} sections, activation {:?}, rope {:?}, \
                 bias_mask {:#04x}, qk_norm {}, sandwich_norm {}, softcap attn {} / final {}, \
                 {} lm_head).{}",
                container.version,
                container.output_bytes,
                container.num_sections,
                container.activation,
                container.rope_scaling,
                container.bias_mask,
                container.has_qk_norm,
                container.has_sandwich_norm,
                container.attn_logit_softcap,
                container.final_logit_softcap,
                if tied { "tied" } else { "untied" },
                if report.weights_checked {
                    ""
                } else {
                    " Config-level rules only: no weights were available, so per-tensor rules \
                      (lm_head bias, per-head QK norm shape and consistency, sandwich norms, \
                      per-layer bias consistency) are still unchecked."
                }
            );
            report.supported = true;
            report.container = Some(container);
        }
        Err(error) => {
            report.reason = format!("{error:#}");
            report.supported = false;
        }
    }
    Ok(report)
}

/// Refuse a conversion the destination cannot hold, before anything is written.
///
/// The check is advisory in one direction only: when free space cannot be
/// measured it says nothing and lets the write proceed, because refusing a
/// conversion that would have succeeded is worse than the error this prevents.
fn check_output_space(output: &Path, needed: u64) -> Result<()> {
    let directory = output.parent().filter(|p| !p.as_os_str().is_empty());
    let Some(free) = free_disk_bytes(directory.unwrap_or_else(|| Path::new("."))) else {
        return Ok(());
    };
    // A margin: the tokenizer is copied beside the model, and a filesystem at
    // exactly zero free bytes is its own kind of broken.
    let margin = 64 * 1024 * 1024;
    if free < needed.saturating_add(margin) {
        bail!(
            "this conversion writes {} but {} has only {} free. Free up space or pass              --output to a different drive.",
            crate::cli::format_bytes(needed),
            directory.unwrap_or_else(|| Path::new(".")).display(),
            crate::cli::format_bytes(free),
        );
    }
    Ok(())
}

#[cfg(test)]
mod space_tests {
    use super::*;

    /// The point of the preflight: a conversion that cannot fit is refused
    /// with the two numbers, before any bytes are written, instead of dying
    /// partway through with an OS error and leaving a truncated file.
    #[test]
    fn a_conversion_larger_than_the_disk_is_refused_with_both_numbers() {
        let directory = std::env::temp_dir();
        let Some(free) = free_disk_bytes(&directory) else {
            // Unmeasurable here; the advisory path is covered below.
            return;
        };
        let output = directory.join("rai-space-check.raimodel");
        let error = check_output_space(&output, free.saturating_add(1 << 40))
            .expect_err("a conversion larger than the disk must be refused");
        let message = format!("{error:#}");
        assert!(message.contains("free"), "{message}");
        assert!(
            message.contains("--output"),
            "the refusal must say what to do: {message}"
        );
        assert!(
            !output.exists(),
            "the preflight must not create the output file"
        );
    }

    /// A conversion that plainly fits is not refused.
    #[test]
    fn a_small_conversion_is_allowed() {
        let output = std::env::temp_dir().join("rai-space-ok.raimodel");
        check_output_space(&output, 1024).expect("a 1 KB write must not be refused");
    }
}

/// Free bytes on the filesystem holding `directory`, or `None` when this
/// platform will not say.
#[cfg(windows)]
fn free_disk_bytes(directory: &Path) -> Option<u64> {
    use std::os::windows::ffi::OsStrExt;
    #[link(name = "kernel32")]
    extern "system" {
        fn GetDiskFreeSpaceExW(
            directory: *const u16,
            free_to_caller: *mut u64,
            total: *mut u64,
            total_free: *mut u64,
        ) -> i32;
    }
    let mut wide: Vec<u16> = directory.as_os_str().encode_wide().collect();
    wide.push(0);
    let mut free_to_caller = 0u64;
    let mut total = 0u64;
    let mut total_free = 0u64;
    // SAFETY: `wide` is a NUL-terminated UTF-16 path and the three outputs are
    // valid initialized u64s for the duration of the call.
    let ok = unsafe {
        GetDiskFreeSpaceExW(
            wide.as_ptr(),
            &mut free_to_caller,
            &mut total,
            &mut total_free,
        )
    };
    (ok != 0).then_some(free_to_caller)
}

#[cfg(unix)]
fn free_disk_bytes(directory: &Path) -> Option<u64> {
    use std::os::unix::ffi::OsStrExt;
    let mut path: Vec<u8> = directory.as_os_str().as_bytes().to_vec();
    path.push(0);
    // SAFETY: `path` is NUL-terminated and `stat` is a valid output buffer for
    // the duration of the call.
    let mut stat: libc::statvfs = unsafe { std::mem::zeroed() };
    let ok = unsafe { libc::statvfs(path.as_ptr() as *const libc::c_char, &mut stat) };
    if ok != 0 {
        return None;
    }
    // f_bavail is what a non-root process may actually use, which is the
    // number that matters here; f_bfree includes the reserved blocks.
    Some((stat.f_bavail as u64).saturating_mul(stat.f_frsize as u64))
}

#[cfg(not(any(windows, unix)))]
fn free_disk_bytes(_directory: &Path) -> Option<u64> {
    None
}

fn check_tensor(store: &SafeTensorsSet, name: &str, rows: usize, cols: usize) -> Result<()> {
    let info = store.require(name)?;
    let (actual_rows, actual_cols) = info.dims_2d(name)?;
    if (actual_rows, actual_cols) != (rows, cols) {
        bail!(
            "tensor '{name}' has shape [{actual_rows}, {actual_cols}] but the config implies \
             [{rows}, {cols}]; the .raimodel reader would reject this model"
        );
    }
    Ok(())
}

fn check_vector(store: &SafeTensorsSet, name: &str, len: usize) -> Result<()> {
    let info = store.require(name)?;
    if info.shape.as_slice() != [len] {
        bail!(
            "tensor '{name}' has shape {:?} but the config implies [{len}]",
            info.shape
        );
    }
    Ok(())
}

// =============================================================================
// Quantization
// =============================================================================

struct MatrixJob<'a> {
    tensor: &'a str,
    /// First row of `tensor` to read. Non-zero only when the projection is a
    /// slice of a fused tensor; see [`ProjectionLayout`].
    source_row_offset: usize,
    label: &'a str,
    rows: usize,
    cols: usize,
    group_size: usize,
    bits: u32,
    /// Linears carry an `[u32 rows][u32 cols]` sub-header; the embedding does not.
    emit_dims: bool,
    /// Per-input-channel activation energy from calibration, if this
    /// conversion is calibrated.
    ///
    /// `None` is the uncalibrated path and reproduces `export_rtn.py` byte for
    /// byte. `Some` selects group parameters that minimise the error the layer
    /// actually makes rather than the error its weights suggest — the same
    /// quantity, weighted by how much each input channel is used.
    channel_energy: Option<&'a [f64]>,
}

/// Read one projection's weights as f32, honouring a fused-tensor row offset.
#[cfg(feature = "cli")]
fn read_projection_f32(
    store: &mut SafeTensorsSet,
    source: &ProjectionSource,
    rows: usize,
    out: &mut Vec<f32>,
) -> Result<()> {
    store.read_rows(&source.tensor, source.row_offset, rows, out)
}

/// Read a projection's bias when the config says it has one.
#[cfg(feature = "cli")]
fn read_projection_bias(
    store: &mut SafeTensorsSet,
    config: &RaiConfig,
    layer: u32,
    index: usize,
    rows: usize,
) -> Result<Option<Vec<f32>>> {
    if !config.has_bias(index) {
        return Ok(None);
    }
    let name = layer_bias_name(layer, LAYER_LINEAR_NAMES[index]);
    // A bias is 1-D, like the norms.
    let mut buffer = store.read_all(&name, rows)?;
    ensure!(
        buffer.len() >= rows,
        "bias '{name}' has {} values but the projection has {rows} rows",
        buffer.len()
    );
    buffer.truncate(rows);
    Ok(Some(buffer))
}

/// Per-projection input energy for one model, indexed by layer.
///
/// Four vectors per layer, one for each group of projections that shares an
/// input: `q`/`k`/`v` see the attention norm's output, `o` sees the attention
/// output, `gate`/`up` see the MLP norm's output, and `down` sees the
/// activation product.
#[cfg(feature = "cli")]
pub(crate) struct CalibrationEnergy {
    qkv: Vec<Vec<f64>>,
    o: Vec<Vec<f64>>,
    gate_up: Vec<Vec<f64>>,
    down: Vec<Vec<f64>>,
}

#[cfg(feature = "cli")]
impl CalibrationEnergy {
    /// The energy vector for one projection index within a layer, in
    /// [`PROJECTION_NAMES`] order.
    pub(crate) fn for_projection(&self, layer: usize, index: usize) -> Option<&[f64]> {
        match index {
            0..=2 => self.qkv.get(layer).map(Vec::as_slice),
            3 => self.o.get(layer).map(Vec::as_slice),
            4 | 5 => self.gate_up.get(layer).map(Vec::as_slice),
            6 => self.down.get(layer).map(Vec::as_slice),
            _ => None,
        }
    }
}

/// Tokenize the calibration text and trim it to whole sequences.
#[cfg(feature = "cli")]
fn calibration_tokens(
    tokenizer_path: &std::path::Path,
    text: &str,
    sequences: usize,
    seq_len: usize,
) -> Result<Vec<u32>> {
    let tokenizer = tokenizers::Tokenizer::from_file(tokenizer_path)
        .map_err(|error| anyhow::anyhow!("could not read {}: {error}", tokenizer_path.display()))?;
    // No special tokens: the corpus is continuous prose, and a BOS inserted at
    // every sequence boundary would be a position the text does not contain.
    let encoding = tokenizer
        .encode(text, false)
        .map_err(|error| anyhow::anyhow!("could not tokenize the calibration text: {error}"))?;
    let ids = encoding.get_ids();

    let wanted = sequences
        .checked_mul(seq_len)
        .context("calibration size overflows")?;
    ensure!(
        ids.len() >= wanted,
        "the calibration text tokenizes to {} tokens but {sequences} sequences of {seq_len}          need {wanted}. Use a longer text, or lower --calibration-sequences.",
        ids.len()
    );
    Ok(ids[..wanted].to_vec())
}

/// Run the checkpoint over the calibration tokens, collecting per-projection
/// input energy.
///
/// Refuses rather than approximates: every capability the config declares must
/// be one this pass reproduces, or the statistics describe a different model.
#[cfg(feature = "cli")]
#[allow(clippy::too_many_arguments)]
fn collect_calibration_energy(
    store: &mut SafeTensorsSet,
    config: &RaiConfig,
    layout: &ProjectionLayout,
    linear_dims: &[(usize, usize); 7],
    expert_layout: Option<&ExpertLayout>,
    tokens: &[u32],
    seq_len: usize,
    log: &dyn Fn(&str),
) -> Result<CalibrationEnergy> {
    use crate::calibrate::{accumulate_channel_energy, apply_rope, causal_attention, matmul_t};

    ensure!(
        expert_layout.is_none(),
        "calibrated conversion does not support mixture-of-experts checkpoints yet: which          expert sees which token is a routing decision this pass would have to reproduce          exactly, and approximating it would quantize the model against activations it never          sees. Convert without --calibrate."
    );
    ensure!(
        !config.has_sandwich_norm && !config.post_norm,
        "calibrated conversion does not support sandwich-normed or post-norm checkpoints yet.          Convert without --calibrate."
    );

    let hidden = config.hidden_size as usize;
    let heads = config.num_heads as usize;
    let kv_heads = config.num_kv_heads as usize;
    let head_dim = config.head_dim as usize;
    let inter = config.intermediate_size as usize;
    let layers = config.num_layers as usize;
    let attn_dim = heads * head_dim;
    let kv_dim = kv_heads * head_dim;
    let sequences = tokens.len() / seq_len;

    let mut energy = CalibrationEnergy {
        qkv: vec![vec![0.0; hidden]; layers],
        o: vec![vec![0.0; attn_dim]; layers],
        gate_up: vec![vec![0.0; hidden]; layers],
        down: vec![vec![0.0; inter]; layers],
    };

    // The residual stream for every calibration token at once.
    let mut hidden_state = vec![0.0f32; tokens.len() * hidden];
    let embed_name = "model.embed_tokens.weight";
    let mut row = Vec::new();
    for (index, &token) in tokens.iter().enumerate() {
        store.read_rows(embed_name, token as usize, 1, &mut row)?;
        let dst = &mut hidden_state[index * hidden..(index + 1) * hidden];
        dst.copy_from_slice(&row[..hidden]);
        if config.embed_scale != 1.0 {
            for value in dst.iter_mut() {
                *value *= config.embed_scale;
            }
        }
    }

    let rope = crate::layers::RoPETable::with_scaling(
        head_dim,
        seq_len,
        config.rope_theta,
        config.rope_scaling,
    )?;
    let half = head_dim / 2;
    let scale = 1.0f32 / (head_dim as f32).sqrt();

    let mut normed = vec![0.0f32; tokens.len() * hidden];
    let mut q = vec![0.0f32; tokens.len() * attn_dim];
    let mut k = vec![0.0f32; tokens.len() * kv_dim];
    let mut v = vec![0.0f32; tokens.len() * kv_dim];
    let mut attn = vec![0.0f32; tokens.len() * attn_dim];
    let mut gate = vec![0.0f32; tokens.len() * inter];
    let mut up = vec![0.0f32; tokens.len() * inter];
    let mut projected = vec![0.0f32; tokens.len() * hidden];
    let mut weights = Vec::new();

    for layer in 0..layers {
        log(&format!("  calibrating layer {}/{layers}", layer + 1));

        // ---- attention input ------------------------------------------------
        let [attn_norm_name, mlp_norm_name] =
            tail_norm_names(layer as u32, config.has_sandwich_norm, config.post_norm);
        // Norms are 1-D vectors, so they need `read_all`; `read_rows` demands a
        // 2-D matrix and refuses a `[hidden]` tensor outright.
        let attn_norm = store.read_all(&attn_norm_name, hidden)?;
        for t in 0..tokens.len() {
            crate::layers::rms_norm(
                &mut normed[t * hidden..(t + 1) * hidden],
                &hidden_state[t * hidden..(t + 1) * hidden],
                &attn_norm,
                config.norm_eps,
            );
        }
        accumulate_channel_energy(&mut energy.qkv[layer], &normed, tokens.len(), hidden);

        // ---- q, k, v --------------------------------------------------------
        for (index, out) in [(0usize, &mut q), (1, &mut k), (2, &mut v)] {
            let (rows, cols) = linear_dims[index];
            let source = layout.source(layer as u32, index, linear_dims);
            read_projection_f32(store, &source, rows, &mut weights)?;
            let bias = read_projection_bias(store, config, layer as u32, index, rows)?;
            matmul_t(
                out,
                &normed,
                &weights,
                bias.as_deref(),
                tokens.len(),
                rows,
                cols,
            )?;
        }

        if config.has_qk_norm || config.has_full_qk_norm {
            bail!(
                "calibrated conversion does not support per-head QK norms yet (Qwen3, Gemma3).                  Convert without --calibrate."
            );
        }

        // ---- rotary position embedding, per sequence ------------------------
        for s in 0..sequences {
            let q_span = &mut q[s * seq_len * attn_dim..(s + 1) * seq_len * attn_dim];
            apply_rope(
                q_span,
                &rope.cos[..seq_len * half],
                &rope.sin[..seq_len * half],
                seq_len,
                heads,
                head_dim,
            )?;
            let k_span = &mut k[s * seq_len * kv_dim..(s + 1) * seq_len * kv_dim];
            apply_rope(
                k_span,
                &rope.cos[..seq_len * half],
                &rope.sin[..seq_len * half],
                seq_len,
                kv_heads,
                head_dim,
            )?;
        }

        // ---- attention, per sequence ---------------------------------------
        for s in 0..sequences {
            causal_attention(
                &mut attn[s * seq_len * attn_dim..(s + 1) * seq_len * attn_dim],
                &q[s * seq_len * attn_dim..(s + 1) * seq_len * attn_dim],
                &k[s * seq_len * kv_dim..(s + 1) * seq_len * kv_dim],
                &v[s * seq_len * kv_dim..(s + 1) * seq_len * kv_dim],
                seq_len,
                heads,
                kv_heads,
                head_dim,
                scale,
            )?;
        }
        accumulate_channel_energy(&mut energy.o[layer], &attn, tokens.len(), attn_dim);

        // ---- output projection and residual ---------------------------------
        let (rows, cols) = linear_dims[3];
        let source = layout.source(layer as u32, 3, linear_dims);
        read_projection_f32(store, &source, rows, &mut weights)?;
        let bias = read_projection_bias(store, config, layer as u32, 3, rows)?;
        matmul_t(
            &mut projected,
            &attn,
            &weights,
            bias.as_deref(),
            tokens.len(),
            rows,
            cols,
        )?;
        for (h, p) in hidden_state.iter_mut().zip(projected.iter()) {
            *h += *p;
        }

        // ---- MLP input ------------------------------------------------------
        let mlp_norm = store.read_all(&mlp_norm_name, hidden)?;
        for t in 0..tokens.len() {
            crate::layers::rms_norm(
                &mut normed[t * hidden..(t + 1) * hidden],
                &hidden_state[t * hidden..(t + 1) * hidden],
                &mlp_norm,
                config.norm_eps,
            );
        }
        accumulate_channel_energy(&mut energy.gate_up[layer], &normed, tokens.len(), hidden);

        // ---- gate, up, activation -------------------------------------------
        for (index, out) in [(4usize, &mut gate), (5, &mut up)] {
            let (rows, cols) = linear_dims[index];
            let source = layout.source(layer as u32, index, linear_dims);
            read_projection_f32(store, &source, rows, &mut weights)?;
            let bias = read_projection_bias(store, config, layer as u32, index, rows)?;
            matmul_t(
                out,
                &normed,
                &weights,
                bias.as_deref(),
                tokens.len(),
                rows,
                cols,
            )?;
        }
        for t in 0..tokens.len() {
            crate::layers::glu_mul_inplace(
                config.activation,
                &mut gate[t * inter..(t + 1) * inter],
                &up[t * inter..(t + 1) * inter],
                inter,
            );
        }
        accumulate_channel_energy(&mut energy.down[layer], &gate, tokens.len(), inter);

        // ---- down projection and residual ------------------------------------
        let (rows, cols) = linear_dims[6];
        let source = layout.source(layer as u32, 6, linear_dims);
        read_projection_f32(store, &source, rows, &mut weights)?;
        let bias = read_projection_bias(store, config, layer as u32, 6, rows)?;
        matmul_t(
            &mut projected,
            &gate,
            &weights,
            bias.as_deref(),
            tokens.len(),
            rows,
            cols,
        )?;
        for (h, p) in hidden_state.iter_mut().zip(projected.iter()) {
            *h += *p;
        }
    }

    // The Hessian diagonal is a mean, not a sum, so the shrink search behaves
    // the same whatever calibration size was chosen.
    let n = tokens.len() as f64;
    for group in [
        &mut energy.qkv,
        &mut energy.o,
        &mut energy.gate_up,
        &mut energy.down,
    ] {
        for vector in group.iter_mut() {
            for value in vector.iter_mut() {
                *value /= n;
            }
        }
    }
    Ok(energy)
}

/// Quantize one matrix straight into the output file and return its MSE.
///
/// The group-param block precedes the codes in the section but is only known
/// once every row has been seen, so the codes are streamed into their final
/// position first and the params are written afterwards with one seek back.
fn write_matrix(file: &mut File, store: &mut SafeTensorsSet, job: &MatrixJob<'_>) -> Result<f64> {
    let (rows, cols, group_size, bits) = (job.rows, job.cols, job.group_size, job.bits);
    if bits == 4 && !cols.is_multiple_of(2) {
        bail!(
            "{}: cannot pack nibbles, column count must be even, got {cols}",
            job.label
        );
    }
    let n_levels = 1u32 << bits;
    let num_groups = cols.div_ceil(group_size);
    let row_param_bytes = num_groups * 4;
    let row_code_bytes = if bits == 4 { cols / 2 } else { cols };

    if job.emit_dims {
        file.write_all(&(rows as u32).to_le_bytes())?;
        file.write_all(&(cols as u32).to_le_bytes())?;
    }

    let params_pos = file.stream_position()?;
    let params_len = (rows * row_param_bytes) as u64;
    let mut params = vec![0u8; rows * row_param_bytes];
    file.seek(SeekFrom::Start(params_pos + params_len))?;

    let rows_per_block = (BLOCK_ELEMENTS / cols.max(1)).clamp(1, rows.max(1));
    let mut weights: Vec<f32> = Vec::new();
    let mut codes: Vec<u8> = Vec::new();
    let mut squared_error = 0.0f64;

    let mut row_start = 0usize;
    while row_start < rows {
        let block_rows = rows_per_block.min(rows - row_start);
        store.read_rows(
            job.tensor,
            job.source_row_offset + row_start,
            block_rows,
            &mut weights,
        )?;
        codes.clear();
        codes.resize(block_rows * row_code_bytes, 0);
        let block_params =
            &mut params[row_start * row_param_bytes..(row_start + block_rows) * row_param_bytes];

        let errors: Vec<f64> = weights
            .par_chunks(cols)
            .zip(codes.par_chunks_mut(row_code_bytes))
            .zip(block_params.par_chunks_mut(row_param_bytes))
            .enumerate()
            .map(|(index, ((row, row_codes), row_params))| {
                quantize_row(
                    row,
                    group_size,
                    n_levels,
                    bits == 4,
                    row_params,
                    row_codes,
                    job.label,
                    row_start + index,
                    job.channel_energy,
                )
            })
            .collect::<Result<Vec<f64>>>()?;
        // Summed sequentially so the reported MSE does not depend on how rayon
        // happened to split the block.
        for error in errors {
            squared_error += error;
        }

        file.write_all(&codes)?;
        row_start += block_rows;
    }

    let end = file.stream_position()?;
    file.seek(SeekFrom::Start(params_pos))?;
    file.write_all(&params)?;
    file.seek(SeekFrom::Start(end))?;

    Ok(squared_error / (rows as f64 * cols as f64))
}

/// Round-to-nearest quantization of a single row.
///
/// Mirrors `raimodel.compute_group_params` + `raimodel.rtn_quantize`: group
/// statistics in f64, scale and zero rounded to f16 *before* any code is
/// derived (so the reader's `code * scale + zero` reproduces exactly what was
/// quantized against), and codes rounded half-to-even like `np.round`.
#[allow(clippy::too_many_arguments)]
fn quantize_row(
    row: &[f32],
    group_size: usize,
    n_levels: u32,
    packed: bool,
    params_out: &mut [u8],
    codes_out: &mut [u8],
    label: &str,
    row_index: usize,
    channel_energy: Option<&[f64]>,
) -> Result<f64> {
    let cols = row.len();
    let max_code = (n_levels - 1) as f64;
    let mut squared_error = 0.0f64;

    for (group_index, group_start) in (0..cols).step_by(group_size).enumerate() {
        let group_end = (group_start + group_size).min(cols);
        let group = &row[group_start..group_end];

        let mut min = f64::INFINITY;
        let mut max = f64::NEG_INFINITY;
        for &value in group {
            let value = value as f64;
            if !value.is_finite() {
                bail!(
                    "{label} row {row_index} group {group_index} contains a non-finite weight; \
                     refusing to write a corrupt model"
                );
            }
            // numpy's reduction, not `f64::min`/`f64::max`: `np.minimum` is
            // `(a < b) ? a : b`, so a tie keeps the *later* value. That is
            // invisible except for signed zeros, where it decides whether the
            // stored zero-point is 0.0 or -0.0 — a one-bit difference in the
            // file for every all-zero group (unused vocabulary rows have
            // thousands of them). Rust's `min`/`max` may return either operand
            // for ±0.0, which is exactly how a byte-identical export breaks.
            if value <= min {
                min = value;
            }
            if value >= max {
                max = value;
            }
        }

        // Calibrated conversions replace the range fit with a weighted one.
        // The uncalibrated expression above is left exactly as it was: it is
        // held byte-identical to the Python exporter by a test, and the
        // signed-zero tie-breaking in the min/max loop is part of that.
        let (scale, zero) = match channel_energy {
            None => (((max - min) / max_code).max(MIN_F16_SCALE), min),
            Some(energy) => {
                let values: Vec<f64> = group.iter().map(|&v| v as f64).collect();
                let (scale, zero) = crate::calibrate::group_params_weighted(
                    &values,
                    &energy[group_start..group_end],
                    n_levels.trailing_zeros() as u8,
                    CALIBRATION_SHRINK_STEPS,
                );
                (scale.max(MIN_F16_SCALE), zero)
            }
        };
        let scale_f16 = f16::from_f64(scale);
        let zero_f16 = f16::from_f64(zero);
        if !scale_f16.is_finite() || scale_f16 <= f16::ZERO || !zero_f16.is_finite() {
            bail!(
                "{label} row {row_index} group {group_index} produced non-finite or non-positive \
                 FP16 quantization parameters"
            );
        }
        let param_offset = group_index * 4;
        params_out[param_offset..param_offset + 2].copy_from_slice(&scale_f16.to_le_bytes());
        params_out[param_offset + 2..param_offset + 4].copy_from_slice(&zero_f16.to_le_bytes());

        let scale64 = scale_f16.to_f64();
        let zero64 = zero_f16.to_f64();
        for (offset, &value) in group.iter().enumerate() {
            let column = group_start + offset;
            let value = value as f64;
            let code = (((value - zero64) / scale64).round_ties_even()).clamp(0.0, max_code);
            let error = value - (code * scale64 + zero64);
            squared_error += error * error;

            let code = code as u8;
            if packed {
                // Low nibble = even column, high nibble = odd column.
                let byte = &mut codes_out[column / 2];
                if column.is_multiple_of(2) {
                    *byte = (*byte & 0xF0) | (code & 0x0F);
                } else {
                    *byte = (*byte & 0x0F) | ((code & 0x0F) << 4);
                }
            } else {
                codes_out[column] = code;
            }
        }
    }
    Ok(squared_error)
}

/// Write one unquantized vector (an RMSNorm weight or a projection bias) as
/// little-endian f32.
///
/// `plus_one` implements the Gemma RMSNorm fold: Gemma's norm is
/// `x/rms * (1 + w)` while `layers.rs::rms_norm` computes `x/rms * w`, so
/// storing `1 + w` makes the shipped kernel exactly right and costs the format
/// nothing. The addition happens in f32 after the checkpoint's f16 cast, which
/// is the same order `(1.0 + weight.float())` uses in the reference model.
fn write_f32_vector(
    file: &mut File,
    store: &mut SafeTensorsSet,
    tensor: &str,
    len: usize,
    plus_one: bool,
) -> Result<()> {
    let weights = store.read_all(tensor, len)?;
    if weights.len() != len {
        bail!(
            "tensor '{tensor}' has {} values, expected {len}",
            weights.len()
        );
    }
    let mut bytes = Vec::with_capacity(len * 4);
    for (index, value) in weights.iter().enumerate() {
        if !value.is_finite() {
            bail!("{tensor} weight {index} is non-finite");
        }
        let value = if plus_one { 1.0 + *value } else { *value };
        bytes.extend_from_slice(&value.to_le_bytes());
    }
    file.write_all(&bytes)?;
    Ok(())
}

// =============================================================================
// Container layout
// =============================================================================

fn embedding_section_len(vocab: usize, hidden: usize, group_size: usize) -> Result<u64> {
    let groups = hidden.div_ceil(group_size);
    let params = (vocab as u64)
        .checked_mul(groups as u64)
        .and_then(|v| v.checked_mul(4))
        .context("embedding parameter bytes overflow")?;
    let codes = (vocab as u64)
        .checked_mul(hidden as u64)
        .context("embedding code bytes overflow")?;
    Ok(params + codes)
}

fn linear_section_len(rows: usize, cols: usize, group_size: usize) -> Result<u64> {
    let groups = cols.div_ceil(group_size);
    let params = (rows as u64)
        .checked_mul(groups as u64)
        .and_then(|v| v.checked_mul(4))
        .context("linear parameter bytes overflow")?;
    let codes = (rows as u64)
        .checked_mul(cols as u64)
        .context("linear code bytes overflow")?
        / 2;
    Ok(8 + params + codes)
}

/// Section sizes and the resulting file size, derived from the config alone.
///
/// Shared with [`preflight`] so a caller can be told how large the output will
/// be before a byte is written, without a second copy of the layout rules.
fn plan_sections(config: &RaiConfig, tied: bool) -> Result<(Vec<u64>, u64)> {
    let hidden = config.hidden_size as usize;
    let vocab = config.vocab_size as usize;
    let group_size = config.group_size as usize;
    let embed_group_size = config.embed_group_size as usize;
    let linear_dims = config.projection_dims();

    let mut section_sizes: Vec<u64> = Vec::with_capacity(config.num_layers as usize + 3);
    section_sizes.push(embedding_section_len(vocab, hidden, embed_group_size)?);
    let layer_len = layer_section_len(&linear_dims, hidden, group_size, config)?;
    for _ in 0..config.num_layers {
        section_sizes.push(layer_len);
    }
    section_sizes.push(hidden as u64 * 4);
    if !tied {
        section_sizes.push(linear_section_len(vocab, hidden, group_size)?);
    }

    let total = config.header_size()
        + section_sizes.len() as u64 * SECTION_ENTRY_SIZE
        + section_sizes.iter().sum::<u64>();
    Ok((section_sizes, total))
}

/// The exact byte length of one layer section, block by block, in the order
/// `format::RaiModelFile::layer` parses them. The reader checks this size
/// exactly, so any disagreement here fails the export rather than corrupting it.
fn layer_section_len(
    linear_dims: &[(usize, usize); 7],
    hidden: usize,
    group_size: usize,
    config: &RaiConfig,
) -> Result<u64> {
    let mut total = 0u64;
    for &(rows, cols) in linear_dims {
        total += linear_section_len(rows, cols, group_size)?;
    }
    // Bias block: one f32 per output row, for each declared projection.
    for (index, &(rows, _)) in linear_dims.iter().enumerate() {
        if config.bias_mask & (1 << index) != 0 {
            total += rows as u64 * 4;
        }
    }
    // QK-norm block: q_norm + k_norm. Per-head is head_dim f32 each;
    // full-width is the two projection widths, which differ under GQA.
    if config.has_qk_norm {
        total += 2 * config.head_dim as u64 * 4;
    } else if config.has_full_qk_norm {
        total += (config.attention_dim() + config.kv_dim()) as u64 * 4;
    }
    // Sandwich block: attention-output + MLP-output norms, hidden f32 each.
    if config.has_sandwich_norm {
        total += 2 * hidden as u64 * 4;
    }
    // Router (f32) and the experts after the first. A dense model declares no
    // experts and adds nothing, which is why its sections are unchanged.
    if config.num_experts > 0 {
        let experts = config.num_experts as u64;
        total += experts * hidden as u64 * 4;
        let per_expert: u64 = linear_dims[4..]
            .iter()
            .map(|&(rows, cols)| linear_bytes(rows, cols, config.group_size as usize))
            .sum();
        total += (experts - 1) * per_expert;
    }
    // The two hidden-sized layer norms that every version carries.
    Ok(total + 2 * hidden as u64 * 4)
}

/// Bytes one quantized linear occupies: `[u32 rows][u32 cols]` then the group
/// parameters then the packed nibbles.
fn linear_bytes(rows: usize, cols: usize, group_size: usize) -> u64 {
    let groups = cols.div_ceil(group_size);
    8 + (rows * groups * 4) as u64 + (rows * cols).div_ceil(2) as u64
}

fn write_header(file: &mut File, config: &RaiConfig, num_sections: u32) -> Result<()> {
    let version = config.version();
    let mut header = vec![0u8; config.header_size() as usize];
    header[0..4].copy_from_slice(b"RAIM");
    header[4..8].copy_from_slice(&version.to_le_bytes());
    header[8..12].copy_from_slice(&config.hidden_size.to_le_bytes());
    header[12..16].copy_from_slice(&config.num_layers.to_le_bytes());
    header[16..20].copy_from_slice(&config.num_heads.to_le_bytes());
    header[20..24].copy_from_slice(&config.num_kv_heads.to_le_bytes());
    header[24..28].copy_from_slice(&config.head_dim.to_le_bytes());
    header[28..32].copy_from_slice(&config.intermediate_size.to_le_bytes());
    header[32..36].copy_from_slice(&config.vocab_size.to_le_bytes());
    header[36..40].copy_from_slice(&config.max_context.to_le_bytes());
    header[40..44].copy_from_slice(&config.rope_theta.to_le_bytes());
    header[44..48].copy_from_slice(&config.norm_eps.to_le_bytes());
    header[48] = config.bits;
    header[49] = config.group_size;
    header[50] = config.embed_bits;
    header[51] = config.embed_group_size;
    header[52..56].copy_from_slice(&num_sections.to_le_bytes());
    // 56..64 stays zero in both versions: it is the v1 header's reserved tail
    // and the v2 reader rejects a non-zero value there.
    if version >= 2 {
        header[64] = config.activation.code();
        header[65] = config.flags();
        header[66] = config.rope_scaling.code();
        header[67] = config.bias_mask;
        if let RopeScaling::Llama3 {
            factor,
            low_freq_factor,
            high_freq_factor,
            original_max_position,
        } = config.rope_scaling
        {
            header[68..72].copy_from_slice(&factor.to_le_bytes());
            header[72..76].copy_from_slice(&low_freq_factor.to_le_bytes());
            header[76..80].copy_from_slice(&high_freq_factor.to_le_bytes());
            header[80..84].copy_from_slice(&original_max_position.to_le_bytes());
        }
        header[84..88].copy_from_slice(&config.embed_scale.to_le_bytes());
        header[88..92].copy_from_slice(&config.attn_logit_softcap.to_le_bytes());
        header[92..96].copy_from_slice(&config.final_logit_softcap.to_le_bytes());
        header[96..100].copy_from_slice(&config.attn_scale.to_le_bytes());
        header[100..104].copy_from_slice(&config.rope_local_theta.to_le_bytes());
        header[104] = config.global_layer_stride;
        header[105..107].copy_from_slice(&config.num_experts.to_le_bytes());
        header[107] = config.experts_per_token;
        header[108] = u8::from(config.num_experts > 0 && config.norm_topk_prob);
        // 109..128 stays zero: the reader rejects a non-zero value there.
    }
    file.write_all(&header)?;
    Ok(())
}

// =============================================================================
// Helpers
// =============================================================================

/// How a checkpoint lays out the seven projections a layer stores.
///
/// Most families give each projection its own tensor. Phi-3 concatenates Q, K
/// and V into one `qkv_proj` and gate/up into one `gate_up_proj`, so the same
/// seven matrices are row ranges of two larger ones. Nothing about the
/// container changes: the quantizer already reads a tensor by row range, so a
/// fused checkpoint is split during conversion and the resulting file is
/// indistinguishable from one written from separate tensors.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ProjectionLayout {
    /// `q_proj`, `k_proj`, `v_proj`, `gate_proj`, `up_proj` each stand alone.
    Separate,
    /// `qkv_proj` holds Q then K then V; `gate_up_proj` holds gate then up.
    FusedQkvGateUp,
}

/// Which tensor a projection lives in, and the row it starts at.
struct ProjectionSource {
    tensor: String,
    row_offset: usize,
}

impl ProjectionLayout {
    /// Decide the layout from the tensors that are actually present.
    ///
    /// Detection is by tensor, not by `model_type`: a fine-tune that renames
    /// itself still has to say where its weights are, and a family we have
    /// never seen that happens to fuse the same way converts for free.
    fn detect(store: &SafeTensorsSet, num_layers: u32) -> Result<Self> {
        let fused = |layer: u32| {
            store
                .info(&format!("model.layers.{layer}.self_attn.qkv_proj.weight"))
                .is_some()
        };
        if num_layers == 0 || !fused(0) {
            return Ok(Self::Separate);
        }
        // A checkpoint that fuses only some layers would convert the rest from
        // tensors that are not there; say so here rather than at layer 12.
        for layer in 1..num_layers {
            if !fused(layer) {
                bail!(
                    "checkpoint is inconsistent: layer 0 fuses Q/K/V into qkv_proj but layer \
                     {layer} does not. Every layer must use the same projection layout."
                );
            }
        }
        Ok(Self::FusedQkvGateUp)
    }

    /// Where projection `index` of `layer` is read from.
    ///
    /// `index` is a position in [`LAYER_LINEAR_NAMES`]: q, k, v, o, gate, up,
    /// down. The row offsets follow `Phi3Attention.forward`, which slices the
    /// fused output as Q, then K, then V, and `Phi3MLP.forward`, which splits
    /// the fused MLP output into gate then up.
    fn source(self, layer: u32, index: usize, dims: &[(usize, usize); 7]) -> ProjectionSource {
        let attn = |offset: usize| ProjectionSource {
            tensor: format!("model.layers.{layer}.self_attn.qkv_proj.weight"),
            row_offset: offset,
        };
        let mlp = |offset: usize| ProjectionSource {
            tensor: format!("model.layers.{layer}.mlp.gate_up_proj.weight"),
            row_offset: offset,
        };
        let separate = || ProjectionSource {
            tensor: layer_linear_name(layer, LAYER_LINEAR_NAMES[index]),
            row_offset: 0,
        };
        match (self, index) {
            (Self::Separate, _) => separate(),
            (Self::FusedQkvGateUp, 0) => attn(0),
            (Self::FusedQkvGateUp, 1) => attn(dims[0].0),
            (Self::FusedQkvGateUp, 2) => attn(dims[0].0 + dims[1].0),
            (Self::FusedQkvGateUp, 4) => mlp(0),
            (Self::FusedQkvGateUp, 5) => mlp(dims[4].0),
            // `o_proj` and `down_proj` are never fused: they project back down,
            // so there is nothing to concatenate them with.
            (Self::FusedQkvGateUp, _) => separate(),
        }
    }

    /// Confirm the fused tensors are exactly as wide as the parts they hold.
    ///
    /// Without this a config that disagrees with the checkpoint would silently
    /// read V's rows as K's — a file that loads cleanly and generates nonsense,
    /// which is the failure this converter exists to prevent.
    fn check_fused_tensors(
        self,
        store: &SafeTensorsSet,
        num_layers: u32,
        dims: &[(usize, usize); 7],
    ) -> Result<()> {
        if self != Self::FusedQkvGateUp {
            return Ok(());
        }
        let hidden = dims[0].1;
        let qkv_rows = dims[0].0 + dims[1].0 + dims[2].0;
        let gate_up_rows = dims[4].0 + dims[5].0;
        for layer in 0..num_layers {
            let qkv = format!("model.layers.{layer}.self_attn.qkv_proj.weight");
            let gate_up = format!("model.layers.{layer}.mlp.gate_up_proj.weight");
            check_tensor(store, &qkv, qkv_rows, hidden)?;
            check_tensor(store, &gate_up, gate_up_rows, hidden)?;
            // The bias mask names the seven projections, so a bias on a fused
            // tensor has no slot and would be dropped without a word.
            for name in [&qkv, &gate_up] {
                let bias = name.replace(".weight", ".bias");
                if store.info(&bias).is_some() {
                    bail!(
                        "checkpoint carries '{bias}'; biases are stored per projection and a \
                         fused tensor has no slot for one, so it would be silently dropped."
                    );
                }
            }
        }
        Ok(())
    }
}

fn layer_linear_name(layer: u32, projection: &str) -> String {
    format!(
        "model.layers.{layer}.{}.{projection}.weight",
        projection_block(projection)
    )
}

fn layer_bias_name(layer: u32, projection: &str) -> String {
    format!(
        "model.layers.{layer}.{}.{projection}.bias",
        projection_block(projection)
    )
}

fn projection_block(projection: &str) -> &'static str {
    match projection {
        "gate_proj" | "up_proj" | "down_proj" => "mlp",
        _ => "self_attn",
    }
}

/// `<checkpoint-dir-name>-q4.raimodel`, in the checkpoint's own case.
///
/// The case is preserved deliberately. This used to lowercase the directory
/// name, which is harmless on Windows and macOS — where the filesystem matches
/// case-insensitively — and a trap on Linux: converting `Qwen2.5-0.5B-Instruct`
/// wrote `qwen2.5-0.5b-instruct-q4.raimodel`, so the obvious next command,
/// naming the model after the directory it came from, failed with "no such
/// file" on exactly the platform where the user could not see why.
///
/// `to_string_lossy` is still the fallback for a non-UTF-8 directory name,
/// which Linux permits: replacement characters in a filename the user can see
/// and retype beat refusing to convert at all, and `--output` overrides it.
fn default_output_name(model_dir: &Path) -> Result<String> {
    let name = model_dir
        .canonicalize()
        .unwrap_or_else(|_| model_dir.to_path_buf())
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .filter(|n| !n.is_empty())
        .with_context(|| {
            format!(
                "cannot derive an output name from {}; pass --output",
                model_dir.display()
            )
        })?;
    Ok(format!("{name}-q4.raimodel"))
}

/// Mirror of `raimodel.copy_tokenizer_json`: never clobber a *different*
/// tokenizer, because a model silently paired with the wrong one produces
/// fluent nonsense.
fn copy_tokenizer_json(src: &Path, dst: &Path) -> Result<bool> {
    let source = std::fs::read(src).with_context(|| format!("reading {}", src.display()))?;
    if dst.exists() {
        let existing = std::fs::read(dst).with_context(|| format!("reading {}", dst.display()))?;
        if existing == source {
            return Ok(false);
        }
        bail!(
            "refusing to overwrite {}: it differs from this model's tokenizer.json. Another \
             model's tokenizer already lives there — export into a separate output directory \
             (--output <dir>/<name>.raimodel).",
            dst.display()
        );
    }
    if let Some(parent) = dst.parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent)
                .with_context(|| format!("creating {}", parent.display()))?;
        }
    }
    std::fs::write(dst, &source).with_context(|| format!("writing {}", dst.display()))?;
    Ok(true)
}

fn required_u32(config: &serde_json::Value, key: &str) -> Result<u32> {
    optional_u32(config, key)?.with_context(|| format!("config.json is missing '{key}'"))
}

fn optional_u32(config: &serde_json::Value, key: &str) -> Result<Option<u32>> {
    match config.get(key) {
        None | Some(serde_json::Value::Null) => Ok(None),
        Some(value) => {
            let number = value
                .as_u64()
                .with_context(|| format!("config.json field '{key}' is not a positive integer"))?;
            let number = u32::try_from(number)
                .with_context(|| format!("config.json field '{key}' is out of range: {number}"))?;
            Ok(Some(number))
        }
    }
}

fn optional_f64(config: &serde_json::Value, key: &str) -> Result<Option<f64>> {
    match config.get(key) {
        None | Some(serde_json::Value::Null) => Ok(None),
        Some(value) => {
            Ok(Some(value.as_f64().with_context(|| {
                format!("config.json field '{key}' is not a number")
            })?))
        }
    }
}

/// Format like Python's `%.2e` (two-digit, signed exponent) so the progress
/// output matches the reference exporter's.
fn fmt_sci(value: f64) -> String {
    let text = format!("{value:.2e}");
    match text.split_once('e') {
        Some((mantissa, exponent)) => {
            let (sign, digits) = match exponent.strip_prefix('-') {
                Some(digits) => ('-', digits),
                None => ('+', exponent),
            };
            format!("{mantissa}e{sign}{digits:0>2}")
        }
        None => text,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scientific_formatting_matches_python() {
        assert_eq!(fmt_sci(1.234e-5), "1.23e-05");
        assert_eq!(fmt_sci(0.0), "0.00e+00");
        assert_eq!(fmt_sci(1.5e12), "1.50e+12");
    }

    #[test]
    fn codes_round_half_to_even_like_numpy() {
        // 0.5 -> 0 and 1.5 -> 2 is numpy's behaviour; Rust's f64::round would
        // give 1 and 2, shifting every tie by one level.
        assert_eq!(0.5f64.round_ties_even(), 0.0);
        assert_eq!(1.5f64.round_ties_even(), 2.0);
        assert_eq!(2.5f64.round_ties_even(), 2.0);
    }

    #[test]
    fn min_f16_scale_is_the_smallest_positive_f16() {
        assert_eq!(f16::from_f64(MIN_F16_SCALE).to_bits(), 1);
        assert_eq!(f16::from_f64(MIN_F16_SCALE).to_f64(), MIN_F16_SCALE);
    }

    #[test]
    fn head_dim_is_taken_from_the_config_when_declared() {
        assert_eq!(resolve_head_dim(None, 64, 4).unwrap(), 16);
        assert_eq!(resolve_head_dim(Some(16), 64, 4).unwrap(), 16);
        // Decoupled: 4 * 32 = 128 against a 64-wide hidden state. Gemma does
        // this, and the container now stores it.
        assert_eq!(resolve_head_dim(Some(32), 64, 4).unwrap(), 32);
        // Without an explicit head_dim the division must be exact.
        let error = resolve_head_dim(None, 66, 4).unwrap_err().to_string();
        assert!(error.contains("not divisible"), "{error}");
    }

    #[test]
    fn activation_is_resolved_per_family() {
        let gemma = serde_json::json!({
            "model_type": "gemma", "hidden_act": "gelu", "hidden_activation": null
        });
        assert_eq!(
            resolve_activation(&gemma, true).unwrap(),
            Activation::GeluTanh
        );
        let gemma_explicit = serde_json::json!({ "hidden_activation": "gelu_pytorch_tanh" });
        assert_eq!(
            resolve_activation(&gemma_explicit, true).unwrap(),
            Activation::GeluTanh
        );
        let llama = serde_json::json!({ "hidden_act": "silu" });
        assert_eq!(resolve_activation(&llama, false).unwrap(), Activation::Silu);
        assert_eq!(
            resolve_activation(&serde_json::json!({}), false).unwrap(),
            Activation::Silu
        );
        // An exact-erf GeLU is a different function and must not be run as the
        // tanh approximation.
        let exact = serde_json::json!({ "hidden_activation": "gelu" });
        let error = resolve_activation(&exact, true).unwrap_err().to_string();
        assert!(error.contains("hidden activation 'gelu'"), "{error}");
    }

    #[test]
    fn rope_scaling_is_resolved_or_refused_by_name() {
        assert_eq!(
            resolve_rope_scaling(&serde_json::json!({})).unwrap(),
            RopeScaling::None
        );
        assert_eq!(
            resolve_rope_scaling(&serde_json::json!({ "rope_scaling": null })).unwrap(),
            RopeScaling::None
        );
        assert_eq!(
            resolve_rope_scaling(
                &serde_json::json!({ "rope_scaling": { "rope_type": "default" } })
            )
            .unwrap(),
            RopeScaling::None
        );
        let llama3 = serde_json::json!({ "rope_scaling": {
            "rope_type": "llama3", "factor": 32.0, "low_freq_factor": 1.0,
            "high_freq_factor": 4.0, "original_max_position_embeddings": 8192
        }});
        assert_eq!(
            resolve_rope_scaling(&llama3).unwrap(),
            RopeScaling::Llama3 {
                factor: 32.0,
                low_freq_factor: 1.0,
                high_freq_factor: 4.0,
                original_max_position: 8_192,
            }
        );
        let yarn = serde_json::json!({ "rope_scaling": { "rope_type": "yarn", "factor": 4.0 } });
        let error = resolve_rope_scaling(&yarn).unwrap_err().to_string();
        assert!(error.contains("rope_scaling type 'yarn'"), "{error}");
    }

    #[test]
    fn container_version_is_the_lowest_that_fits() {
        let mut config = RaiConfig {
            hidden_size: 64,
            num_layers: 2,
            num_heads: 4,
            num_kv_heads: 2,
            head_dim: 16,
            intermediate_size: 128,
            vocab_size: 96,
            max_context: 512,
            rope_theta: 10_000.0,
            norm_eps: 1e-5,
            bits: 4,
            group_size: 64,
            embed_bits: 8,
            embed_group_size: 64,
            activation: Activation::Silu,
            rope_scaling: RopeScaling::None,
            bias_mask: 0,
            embed_scale: 1.0,
            has_qk_norm: false,
            has_sandwich_norm: false,
            has_full_qk_norm: false,
            post_norm: false,
            rope_local_theta: 0.0,
            global_layer_stride: 0,
            num_experts: 0,
            experts_per_token: 0,
            norm_topk_prob: false,
            attn_logit_softcap: 0.0,
            final_logit_softcap: 0.0,
            attn_scale: 0.0,
        };
        assert_eq!(config.version(), 1, "a plain Llama model must stay v1");
        assert_eq!(config.header_size(), HEADER_SIZE_V1);

        for mutate in [
            (|c: &mut RaiConfig| c.activation = Activation::GeluTanh) as fn(&mut RaiConfig),
            |c: &mut RaiConfig| c.bias_mask = 0b111,
            |c: &mut RaiConfig| c.embed_scale = 45.25,
            |c: &mut RaiConfig| c.has_qk_norm = true,
            |c: &mut RaiConfig| c.has_sandwich_norm = true,
            |c: &mut RaiConfig| c.attn_logit_softcap = 50.0,
            |c: &mut RaiConfig| c.final_logit_softcap = 30.0,
            |c: &mut RaiConfig| c.attn_scale = 0.083_333_336,
            |c: &mut RaiConfig| {
                c.rope_scaling = RopeScaling::Llama3 {
                    factor: 32.0,
                    low_freq_factor: 1.0,
                    high_freq_factor: 4.0,
                    original_max_position: 8_192,
                }
            },
        ] {
            let mut probe = config.clone();
            mutate(&mut probe);
            assert_eq!(probe.version(), 2);
            assert_eq!(probe.header_size(), HEADER_SIZE_V2);
        }
        config.bias_mask = 0b111;
        assert_eq!(config.version(), 2);
    }

    #[test]
    fn optional_block_sizing_matches_the_reader() {
        let dims: [(usize, usize); 7] = [
            (64, 64),
            (32, 64),
            (32, 64),
            (64, 64),
            (128, 64),
            (128, 64),
            (64, 128),
        ];
        let base = RaiConfig {
            hidden_size: 64,
            num_layers: 2,
            num_heads: 4,
            num_kv_heads: 2,
            head_dim: 16,
            intermediate_size: 128,
            vocab_size: 96,
            max_context: 512,
            rope_theta: 10_000.0,
            norm_eps: 1e-5,
            bits: 4,
            group_size: 64,
            embed_bits: 8,
            embed_group_size: 64,
            activation: Activation::Silu,
            rope_scaling: RopeScaling::None,
            bias_mask: 0,
            embed_scale: 1.0,
            has_qk_norm: false,
            has_sandwich_norm: false,
            has_full_qk_norm: false,
            post_norm: false,
            rope_local_theta: 0.0,
            global_layer_stride: 0,
            num_experts: 0,
            experts_per_token: 0,
            norm_topk_prob: false,
            attn_logit_softcap: 0.0,
            final_logit_softcap: 0.0,
            attn_scale: 0.0,
        };
        let with = |mutate: fn(&mut RaiConfig)| {
            let mut config = base.clone();
            mutate(&mut config);
            layer_section_len(&dims, 64, 64, &config).unwrap()
        };
        let plain = with(|_| {});
        // q, k, v biases: (64 + 32 + 32) * 4 bytes.
        assert_eq!(with(|c| c.bias_mask = 0b111) - plain, (64 + 32 + 32) * 4);
        // QK norm: two head_dim vectors.
        assert_eq!(with(|c| c.has_qk_norm = true) - plain, 2 * 16 * 4);
        // Sandwich norm: two hidden vectors.
        assert_eq!(with(|c| c.has_sandwich_norm = true) - plain, 2 * 64 * 4);
    }

    #[test]
    fn softcaps_are_read_or_refused_by_name() {
        let none = serde_json::json!({});
        assert_eq!(
            resolve_softcap(&none, "attn_logit_softcapping").unwrap(),
            0.0
        );
        let null = serde_json::json!({ "final_logit_softcapping": serde_json::Value::Null });
        assert_eq!(
            resolve_softcap(&null, "final_logit_softcapping").unwrap(),
            0.0
        );
        let gemma2 = serde_json::json!({
            "attn_logit_softcapping": 50.0,
            "final_logit_softcapping": 30.0,
        });
        assert_eq!(
            resolve_softcap(&gemma2, "attn_logit_softcapping").unwrap(),
            50.0
        );
        assert_eq!(
            resolve_softcap(&gemma2, "final_logit_softcapping").unwrap(),
            30.0
        );
        let bad = serde_json::json!({ "attn_logit_softcapping": -1.0 });
        let error = resolve_softcap(&bad, "attn_logit_softcapping")
            .unwrap_err()
            .to_string();
        assert!(error.contains("must be finite and positive"), "{error}");
    }

    #[test]
    fn the_attention_scale_is_stored_only_when_it_differs() {
        // gemma-2-2b: query_pre_attn_scalar 256 against head_dim 256 is exactly
        // the default, so nothing is stored and the file stays smaller.
        let same = serde_json::json!({ "query_pre_attn_scalar": 256 });
        assert_eq!(resolve_attn_scale(&same, 256).unwrap(), 0.0);
        // gemma-2-27b: 144 against head_dim 128 is a genuinely different scale.
        let differs = serde_json::json!({ "query_pre_attn_scalar": 144 });
        let scale = resolve_attn_scale(&differs, 128).unwrap();
        assert_eq!(scale, (144.0f64).powf(-0.5) as f32);
        assert_ne!(scale, 1.0 / (128.0f32).sqrt());
        // Absent means the default.
        assert_eq!(
            resolve_attn_scale(&serde_json::json!({}), 128).unwrap(),
            0.0
        );
    }

    #[test]
    fn layer_tensor_names_follow_the_hf_convention() {
        assert_eq!(
            layer_linear_name(3, "q_proj"),
            "model.layers.3.self_attn.q_proj.weight"
        );
        assert_eq!(
            layer_linear_name(3, "down_proj"),
            "model.layers.3.mlp.down_proj.weight"
        );
    }

    /// The default output name keeps the checkpoint directory's own case.
    ///
    /// Lowercasing it is invisible on Windows and macOS and breaks on Linux,
    /// where `Qwen2.5-0.5B-Instruct-q4.raimodel` and
    /// `qwen2.5-0.5b-instruct-q4.raimodel` are two different files and only one
    /// of them exists. The directory here is never created, so `canonicalize`
    /// fails and the un-canonicalized path is used — which is also the branch a
    /// relative `--model` argument takes.
    #[test]
    fn the_default_output_name_preserves_the_checkpoint_case() {
        assert_eq!(
            default_output_name(Path::new("models/Qwen2.5-0.5B-Instruct")).unwrap(),
            "Qwen2.5-0.5B-Instruct-q4.raimodel"
        );
        assert_eq!(
            default_output_name(Path::new("TinyLlama-1.1B-Chat-v1.0")).unwrap(),
            "TinyLlama-1.1B-Chat-v1.0-q4.raimodel"
        );
    }

    #[test]
    fn a_nameless_model_dir_asks_for_an_explicit_output() {
        // A bare root has no final component to name the output after.
        let error = default_output_name(Path::new("/")).unwrap_err().to_string();
        assert!(error.contains("--output"), "{error}");
    }

    /// The regression this exists to prevent: a default that is a number.
    ///
    /// `--max-context` used to default to 2048, so a Qwen3-0.6B declaring
    /// `max_position_embeddings=40960` was stored at 2048 and every later run
    /// was capped there, permanently, with nothing in the output saying so.
    /// Two configs that declare different contexts must resolve to *their own*
    /// numbers: any constant default fails this, including one that happens to
    /// equal either model's context.
    #[test]
    fn the_default_context_follows_each_model_rather_than_a_constant() {
        assert_eq!(
            ConvertOptions::default().max_context,
            FOLLOW_MODEL_CONTEXT,
            "the default must be 'follow the model', not a number"
        );

        for declared in [2_048u32, 4_096, 40_960] {
            let hf = serde_json::json!({ "max_position_embeddings": declared });
            let resolved = resolve_max_context(&hf, 128, FOLLOW_MODEL_CONTEXT).unwrap();
            assert_eq!(resolved.tokens, declared);
            assert_eq!(resolved.source, ContextSource::ModelConfig);
        }

        // An explicit request still wins, and is labelled as the user's.
        let hf = serde_json::json!({ "max_position_embeddings": 40_960 });
        let resolved = resolve_max_context(&hf, 128, 512).unwrap();
        assert_eq!(resolved.tokens, 512);
        assert_eq!(resolved.source, ContextSource::Requested);
    }

    /// No declared context means there is nothing to follow. Substituting a
    /// number here is how the original bug would come back, so it is an error
    /// that names the flag instead.
    #[test]
    fn a_model_that_declares_no_context_asks_for_the_flag() {
        let hf = serde_json::json!({ "hidden_size": 1024 });
        let error = resolve_max_context(&hf, 128, FOLLOW_MODEL_CONTEXT)
            .unwrap_err()
            .to_string();
        assert!(error.contains("max_position_embeddings"), "{error}");
        assert!(error.contains("--max-context"), "{error}");
        // With the flag given there is no error at all.
        assert_eq!(resolve_max_context(&hf, 128, 4_096).unwrap().tokens, 4_096);
    }

    /// The sliding-window rule is a real constraint — the container's
    /// attention is full causal, so an export past the window diverges from
    /// the reference model. Following the model means following the window,
    /// which keeps `assert_exportable_architecture`'s refusal satisfied rather
    /// than weakening it.
    #[test]
    fn a_followed_context_stops_at_the_sliding_window() {
        let windowed = serde_json::json!({
            "max_position_embeddings": 32_768,
            "sliding_window": 4_096,
        });
        let resolved = resolve_max_context(&windowed, 128, FOLLOW_MODEL_CONTEXT).unwrap();
        assert_eq!(resolved.tokens, 4_096);
        assert_eq!(resolved.source, ContextSource::SlidingWindow);
        // And the rule it exists to satisfy agrees with it.
        assert_exportable_architecture(&windowed, None, resolved.tokens, 2).unwrap();
        let refused = assert_exportable_architecture(&windowed, None, 32_768, 2)
            .unwrap_err()
            .to_string();
        assert!(refused.contains("sliding_window=4096"), "{refused}");

        // Qwen2.5 ships the field with the feature switched off; capping there
        // would shorten a 32k model for no reason.
        let unused = serde_json::json!({
            "max_position_embeddings": 32_768,
            "sliding_window": 4_096,
            "use_sliding_window": false,
        });
        let resolved = resolve_max_context(&unused, 128, FOLLOW_MODEL_CONTEXT).unwrap();
        assert_eq!(resolved.tokens, 32_768);
        assert_eq!(resolved.source, ContextSource::ModelConfig);
    }

    /// The two ceilings that are genuinely enforced by the reader name
    /// themselves and say what to pass. Neither silently shortens the model.
    #[test]
    fn a_context_over_a_real_limit_is_refused_by_name() {
        // head_dim 1024: 4 KiB of RoPE table per position, so 512 MiB buys
        // 131072 positions and the table budget binds first.
        let huge = serde_json::json!({ "max_position_embeddings": 200_000 });
        let error = resolve_max_context(&huge, 1024, FOLLOW_MODEL_CONTEXT)
            .unwrap_err()
            .to_string();
        assert!(error.contains("MAX_ROPE_TABLE_BYTES"), "{error}");
        assert!(error.contains("--max-context 131072"), "{error}");
        assert_eq!(rope_table_context_limit(1024), 131_072);
        assert!(rope_table_bytes(1024, 131_072) <= MAX_ROPE_TABLE_BYTES as u64);
        assert!(rope_table_bytes(1024, 131_073) > MAX_ROPE_TABLE_BYTES as u64);

        // head_dim 128: the table would allow 1048576 positions, so the
        // container's own hard cap is the binding limit instead.
        let vast = serde_json::json!({ "max_position_embeddings": 2_000_000 });
        let error = resolve_max_context(&vast, 128, FOLLOW_MODEL_CONTEXT)
            .unwrap_err()
            .to_string();
        assert!(error.contains("MAX_CONTEXT"), "{error}");
        assert!(
            error.contains(&format!("--max-context {MAX_CONTEXT}")),
            "{error}"
        );
    }

    /// Mirrors `RaiModel::kv_cache_bytes`, which describes the allocation
    /// `KVCache::new` makes: K and V, f32, per layer / KV head / position /
    /// head-dimension element. `convert_reports_the_kv_cache_the_runtime_
    /// allocates` in `tests/convert_matches_python.rs` pins the two together
    /// against a real model file.
    #[test]
    fn the_kv_cache_estimate_is_the_runtime_formula() {
        // Qwen3-0.6B at its own context: 28 layers, 8 KV heads, head_dim 128.
        assert_eq!(
            kv_cache_bytes(28, 8, 128, 40_960),
            2 * 28 * 8 * 40_960 * 128 * 4
        );
        assert_eq!(kv_cache_bytes(28, 8, 128, 40_960), 9_395_240_960);
        // Every bound this converter enforces still fits comfortably.
        assert!(kv_cache_bytes(MAX_LAYERS, MAX_HEADS, MAX_HIDDEN_SIZE, MAX_CONTEXT) < u64::MAX);
        // A hostile config cannot make it wrap to a number that looks
        // affordable; it saturates.
        assert_eq!(
            kv_cache_bytes(u32::MAX, u32::MAX, u32::MAX, u32::MAX),
            u64::MAX
        );
    }

    /// One parameter count, so the preflight report and the bits-per-parameter
    /// figure printed after a conversion can never disagree.
    #[test]
    fn the_parameter_count_is_the_configs_own_arithmetic() {
        // The synthetic checkpoint from tests/convert_matches_python.rs.
        let shape = ModelShape {
            hidden_size: 64,
            num_layers: 2,
            num_heads: 4,
            num_kv_heads: 2,
            head_dim: 16,
            intermediate_size: 128,
            vocab_size: 96,
            tied_embeddings: true,
        };
        // 96*64 embedding + 2 * (64*64*2 + 64*32*2 + 64*128*3 + 64*2) + 64.
        assert_eq!(shape.parameter_count(), 80_192);
        // An untied head is a second vocab-sized matrix.
        let untied = ModelShape {
            tied_embeddings: false,
            ..shape
        };
        assert_eq!(untied.parameter_count(), 80_192 + 96 * 64);

        // And it is the number `preflight` reports, from the same config.
        let hf = serde_json::json!({
            "model_type": "llama",
            "hidden_size": 64,
            "num_hidden_layers": 2,
            "num_attention_heads": 4,
            "num_key_value_heads": 2,
            "head_dim": 16,
            "intermediate_size": 128,
            "vocab_size": 96,
            "max_position_embeddings": 4_096,
        });
        let report = preflight(&hf, None, 64, 64, FOLLOW_MODEL_CONTEXT).unwrap();
        assert_eq!(report.parameters, 80_192);
        assert_eq!(report.max_context, Some(4_096));
        assert_eq!(report.context_source, Some(ContextSource::ModelConfig));
        assert_eq!(report.kv_cache_bytes, Some(kv_cache_bytes(2, 2, 16, 4_096)));
    }

    /// A preflight that cannot settle a context is a "no" with a reason, not a
    /// crash and not a guess — the shape is still reported so the user can see
    /// what they are holding.
    #[test]
    fn a_preflight_without_a_context_reports_why() {
        let hf = serde_json::json!({
            "model_type": "llama",
            "hidden_size": 64,
            "num_hidden_layers": 2,
            "num_attention_heads": 4,
            "num_key_value_heads": 2,
            "head_dim": 16,
            "intermediate_size": 128,
            "vocab_size": 96,
        });
        let report = preflight(&hf, None, 64, 64, FOLLOW_MODEL_CONTEXT).unwrap();
        assert!(!report.supported);
        assert!(report.max_context.is_none());
        assert!(report.kv_cache_bytes.is_none());
        assert!(report.reason.contains("--max-context"), "{}", report.reason);
        assert_eq!(report.num_layers, 2);

        // The same config with a context given is supported.
        let report = preflight(&hf, None, 64, 64, 2_048).unwrap();
        assert!(report.supported, "{}", report.reason);
        assert_eq!(report.max_context, Some(2_048));
        assert_eq!(report.context_source, Some(ContextSource::Requested));
    }
}
