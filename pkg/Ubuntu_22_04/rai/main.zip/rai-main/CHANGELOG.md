# Changelog

All notable changes to RAI are documented here. The project follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and uses semantic
versioning for its pre-1.0 releases.

## [Unreleased]

## [0.2.5] - 2026-09-08

### Fixed
- `.raimodel` validation now checks the Mixture-of-Experts router and every
  expert's quantization scales for finiteness, not only the base projections,
  so a malformed or hostile file is refused at load instead of producing NaN or
  garbage output at inference.
- Cosine similarity in `rem-nra` is scale-invariant, so very small-magnitude
  vectors retrieve the correct nearest neighbour instead of scoring as zero.
- The AVX2 attention-softmax and SiLU scalar tails use the same fast-exp
  approximation as their SIMD bodies, so a single activation buffer never mixes
  two exp curves.
- Scalar int8 activation quantization rounds half-to-even, matching the AVX2
  path and the converter, so the output no longer differs by one code between
  AVX2 and non-AVX2 machines.
- Greedy decoding breaks exact logit ties toward the first token, matching
  NumPy / PyTorch / Hugging Face `argmax`.
- Documentation: the fp16-versus-4-bit perplexity gap is described as the
  end-to-end cost of the 4-bit engine (weights, int8 activations, and the
  approximate fast-exp kernels); the sequential-versus-batched logits are
  documented as agreeing within 2e-3 rather than exactly zero; and the README
  quickstart's converter output name matches the run/serve commands.

### Added
- **`rai perplexity`.** Measures what quantization cost a model, using
  `llama-perplexity`'s method — non-overlapping chunks of `--context` tokens,
  the second half of each scored — so a RAI number and a llama.cpp number are
  a comparison rather than two numbers. `--dump-topk` additionally records the
  top-K next-token distribution at every scored position;
  `scripts/reference_ppl.py` writes the same record for an unquantized
  checkpoint and `scripts/compare_topk.py` reduces the two to top-1 agreement,
  top-K overlap, and the exact change in the correct token's log-probability.
  Both report the **standard error** of the mean NLL alongside the perplexity:
  a perplexity is a sample mean, and one quoted to four decimals from ten
  thousand tokens is mostly decoration. On a 40-chunk run the error is about
  2.5%, which is the difference between a number a reader can compare and one
  they cannot.
  BENCHMARKS.md previously had to state that no perplexity sweep had been run
  and that no perplexity claim was therefore made. It now carries the sweep:
  on wikitext-2, `rai convert`'s round-to-nearest 4-bit costs **+13% to +30%**
  perplexity against the fp16 checkpoint across Qwen2.5-0.5B/1.5B/3B and
  SmolLM2-1.7B, and the 4-bit model emits a different greedy token than fp16
  **between one time in four and one time in five**. llama.cpp's Q4_K_M costs
  3% to 8% on the same corpus — though `llama-quantize`'s log shows that on
  Qwen2.5-0.5B its "Q4_K_M" is 145 of 169 tensors in the legacy 5- and 8-bit
  formats, because K-quants need rows divisible by 256 and that model's hidden
  size is 896, so that particular row compares 4 bits against 6.35 rather than
  one quantizer against another. None of that is flattering; it is in the file
  because a quantizer whose quality is unmeasured is a quantizer nobody should
  trust, including us.

  The same tool then measured the **calibrated GPTQ exporter end to end** for
  the first time. Until now its quality was reported only as a per-layer
  Hessian-weighted output error — a proxy. On SmolLM2-1.7B, the one advertised
  checkpoint both export paths accept, the calibrated path costs **+11.2%**
  perplexity against fp16 where round-to-nearest costs **+30.3%**, and agrees
  with fp16's greedy token 83.3% of the time against 75.4%. Both files are
  962,996,000 bytes in the same container version on the same decode path, so
  that gain costs nothing at run time.

  The two perplexities each carry ±2.5%, which would leave them arguably
  indistinguishable — except that both engines scored the same 10,200 tokens in
  the same order, so the comparison is paired. Recomputed from the raw top-K
  records and resampled with a block bootstrap over the 40 scoring blocks
  (tokens inside a block share a context; resampling tokens would report an
  interval several times too narrow), round-to-nearest is worse on **all 40
  blocks**, and GPTQ removes **59.8% of the quantization loss**, 95% CI
  55.8%–63.5%.

  This is a finding about the product, not only about the quantizer: the better
  path is unreachable for most users. `rai convert` — the shipped binary and
  the only path that needs no Python — has no GPTQ mode, and the Python path
  that does writes container v1, which refuses Qwen2/2.5, Qwen3, Gemma, OLMo2
  and Phi-3. Of the 22.6 percentage points between round-to-nearest and
  llama.cpp's Q4_K_M on this checkpoint, 19.1 close with code that is already in
  this repository, at the same file size, with no format change; the 3.5 that
  remain are the mixed-precision question.
- **Third-party attribution that ships with the binaries.** `THIRD-PARTY-NOTICES.md`
  is generated by `cargo-about` from the dependency graph of the crate the
  release archives are actually built from, travels in every archive, and CI
  fails if the committed copy has drifted from the graph. `NOTICE` used to
  point at `Cargo.lock`, which records versions and no license text at all,
  while the archives shipped every one of those crates statically linked.
- **A license, advisory and source policy.** `deny.toml` plus a `cargo deny`
  gate in CI. `cargo audit` covered advisories; nothing checked what a
  dependency's license permitted. `docs/RELEASE.md`'s gate list carries both
  new checks and the Python test suite, so the checklist a human runs by hand is
  the same set CI runs — a release gate that CI enforces and the procedure omits
  is a gate that gets discovered during a release.

### Changed
- **`--group-size` is usable on the models it matters for, and is now the
  accuracy dial rather than a workaround.** The kernels accept any group size
  and always have, but `MAX_GROUPS` capped the group count per row at 128 — so
  on a 7B, whose MLP is 14336 wide, the shipped default of 128 was the *only*
  setting that converted at all. Group size 64 needs 224 groups and 32 needs
  448; both were refused. The cap is now 1024, which covers every advertised
  architecture at every offered group size, including Qwen3-32B at 32.

  Raising the constant on its own would have been a regression rather than a
  fix. It sized fixed-length stack arrays in three kernels, and in
  `matvec_chunk_i8` and `lm_head_chunk_i8` the array was declared *inside the
  row loop* — at 1024 that is a 4 KB memset per row, paid on every decode step
  regardless of the group size the model was actually quantized at. It also
  sized `Vec<[f32; MAX_GROUPS]>` in the batch path, putting a fixed 4 KB stride
  between consecutive tokens' group data, so a kernel reading four tokens'
  worth of one group touched four cache lines 4 KB apart to read 16 bytes.

  So the constant stopped being a size and became what it should always have
  been: a validation bound. Group data travels as slices of the model's real
  `num_groups`; the per-row scratch is allocated once per rayon worker with
  `for_each_init` and reused across that worker's chunks; the batch path keeps
  per-token scales and sums in one flat buffer strided by `num_groups`. Cost
  now scales with the group size the user asked for instead of with the largest
  one anyone could ask for, and a model converted at 128 pays exactly what it
  paid before.

  Two tests hold it down, and neither existed before because no group size but
  128 was reachable: the batch kernel and the single-token kernel must agree at
  six group sizes including ones that leave a short final group, and the fused
  QKV and gate/up paths must agree with running each projection separately.
  These compare independent implementations of the same arithmetic rather than
  a function against itself.

  The limit exists in two places on purpose — the Rust reader enforces it at
  load time, and `scripts/raimodel.py` mirrors it so the Python exporters fail
  fast rather than after an hour of calibration — and
  `tests/limits_are_single_sourced.rs` holds them equal. It earned its keep
  immediately: raising the Rust constant without the mirror left the calibrated
  exporter refusing `--group-size 64` on any 7B, which is precisely the export
  the measurements depend on. The test caught it before the run did.

  **Compatibility:** a model converted at a group size other than 128 needs
  this release to load. Older builds refuse it with `model requires N
  quantization groups; kernel maximum is 128` — a clean refusal, not a misread.

- **RAI is the inference engine, and the archives now say so.** The
  memory/reasoning crates were declared "not part of the RAI product" on
  2026-08-13 and marked `publish = false`, but the release archives kept
  shipping `rai-server` — and with it the only reqwest/rustls/ring dependency
  tree in the workspace — inside a product whose claim is that nothing leaves
  the machine. Releases now build `--package classeve-rai-infer` alone, and a
  release-time gate fails the build if the staged binary set is not exactly
  the product allowlist or if any shipped binary contains a TLS or HTTP stack.
  `THIRD-PARTY-NOTICES.md`, generated independently from the dependency graph
  of that one package, corroborates it from the other direction: 98 crates
  attributed, and `rustls`, `reqwest` and `quinn` appear in none of them.
  `INSTALL.md` opened with "RAI is two command-line programs" and listed
  `rai-server` as one of them; it, `README.md` and `docs/` now agree with the
  decision.
- **`docker build .` builds the product.** The default target was the memory
  service, so the artifact produced by the obvious command was not the thing
  this repository ships. The CLI is now the default stage and CI asserts it;
  the memory service is `--target server`.

### Added
- **Calibrated conversion, in `rai convert`.** `--calibration-text <file>` runs
  the checkpoint over real text, records what each projection actually receives,
  and chooses every group's scale and zero point to minimise the error weighted
  by that — instead of by the range the weights happen to span.

  On SmolLM2-1.7B that is **9.22 perplexity against 10.30**, a 10.5%
  improvement at a byte-for-byte identical file size, recovering 72% of the
  distance to `scripts/export_raimodel.py`'s GPU-only GPTQ (8.80). The
  generations show the same thing: the round-to-nearest build restarts its own
  sentences and answers "Tokyo, Osaka, and Nagoya"; the calibrated build does
  neither and answers "Tokyo, Yokohama and Osaka", which is right.

  It needs no Python, no GPU and no change to the container, and it reaches
  checkpoints the Python exporter refuses — Qwen2/2.5's projection biases among
  them. Conversion goes from seconds to minutes, and peak memory grows with the
  calibration size rather than staying flat, because the residual stream for
  every calibration token is held at once.

  It deliberately stops short of full GPTQ. Propagating each column's error into
  the columns not yet quantized needs the Cholesky factor of the inverse
  Hessian, which for a 7B MLP is a 14336×14336 factorization — hours of CPU and
  1.6 GB per projection. The activation energy is that Hessian's *diagonal*, one
  pass over the activations, which is the difference between a thing a converter
  can do and a thing a GPU has to be found for.

  And it refuses rather than approximating: mixture-of-experts routing,
  sandwich-normed and post-norm checkpoints, and per-head QK norms each produce
  a named error. Collecting statistics for a model that does not exist would
  produce a file that loads cleanly and is quantized against nothing.
- **A throughput benchmark for the kernels, `cargo bench --bench gemm`.** There
  was no way to ask "did that change cost throughput?" except to time `rai run`
  on a real model, and that measurement cannot answer it: it includes loading,
  tokenization, sampling and the page cache, its samples ramp for the first
  several seconds on a shared machine, and a seven-sample comparison of it
  carries a 95% confidence interval about 40 percentage points wide. A change
  worth 5% is invisible to it and a run of bad luck reads as a 9% regression.

  This times the kernels directly, on fixed data, across every shape and group
  size a real model uses, and prints the interquartile spread next to every
  median — so a machine too noisy to settle the question says so instead of
  producing a confident wrong number. `--json` emits the same figures for
  diffing two builds. No new dependencies: it is a plain `main` with
  `harness = false`, because putting a benchmark framework and its dependency
  tree into the license and advisory gates of a product whose claim is that it
  carries almost nothing would be its own kind of regression.

### Fixed
- **The Python exporters silently wrote the wrong RoPE base on transformers 5.**
  `export_rtn.py`, `export_fast.py`, `export_raimodel.py` (the calibrated GPTQ
  path) and `train_draft.py` all read the value as
  `getattr(cfg, "rope_theta", 10000.0)`. transformers 5 moved it into
  `cfg.rope_parameters`, so the fallback won and every export carried the Llama
  constant instead of the checkpoint's own base — SmolLM2-1.7B exported as
  10000 where it declares 130000. The file passes validation, `rai run` loads
  it, and it generates with the wrong positional encoding; nothing anywhere
  reports an error. Mistral v0.2+ (1000000) and Llama-3 (500000) are affected
  the same way, while models that happen to use 10000 were accidentally
  correct, which is why it survived. `requirements-lock.txt` pins
  transformers 5.15.0 and `requirements.txt` had no upper bound, so this was
  the default install.

  Found by comparing `rai convert` against `export_rtn.py` on a real
  checkpoint: byte-identical output except three bytes, all inside
  `rope_theta`. The repository's own byte-identity test passes because its
  fixture uses a rope_theta of exactly 10000 — the value the broken fallback
  produces — and because no test loaded a HuggingFace config at all.

  The cost was measured rather than asserted. Because the two files differ in
  only those four bytes, patching them in the correct model reproduces the
  corrupted one exactly — same weights, same quantization, one float apart. On
  SmolLM2-1.7B over wikitext-2 that is **10.30 perplexity correct against 11.36
  corrupted, +10.3%** (±2.7% standard error), which lifts the model's total
  loss against fp16 from +30.3% to +43.7%. That figure is a **lower bound**: it
  was taken at a 512-token context, and a wrong RoPE base grows worse with
  sequence length — a 130000 base exists to serve long contexts in the first
  place.

  All four call sites now go through `raimodel.read_rope_theta`, which reads
  both layouts and **raises** rather than defaulting: a wrong RoPE base cannot
  be detected by the reader or by the user, so guessing is worse than
  refusing. Its regression test is checked to fail against the old
  implementation, and `rai convert` and `export_rtn.py` now produce
  byte-identical output on a real 1.7B checkpoint.

  **If you exported a model with any of those four scripts, re-export it.** No
  released artifact is affected — the release archives contain binaries only,
  and this project has never published a `.raimodel` — so the blast radius is
  files users made themselves. To check one without re-exporting, read bytes
  40..44 of its header as a little-endian f32 and compare against the
  checkpoint's own `rope_theta`; a file that reads 10000 for a checkpoint that
  declares anything else was written by the broken path. Models whose
  checkpoint declares 10000 (TinyLlama, Phi-3, Gemma, SmolLM-135M) are
  unaffected, and anything produced by `rai convert` was always correct — the
  Rust converter reads `config.json` directly and never had the fallback.
- **A refusal that told the user nothing about the alternative.** When
  `export_raimodel.py` meets a checkpoint container v1 cannot hold — Qwen2/2.5
  with its q/k/v biases, Qwen3 with per-head QK norms — it correctly refuses
  rather than dropping the state silently. It then stopped, without naming
  `rai convert` as the path that does handle it or saying what taking that path
  costs. It now names both: round-to-nearest against calibrated GPTQ is +30.3%
  perplexity against +11.2% on the one checkpoint both paths accept, which is
  the difference between a formality and a decision.
- **CI's RustSec gate was failing on a yanked crate.** `chacha20 0.10.1` was
  yanked from crates.io after this lock was written, and `cargo audit --deny
  warnings` — which is exactly what CI runs — exited 1 on it. `cargo update -p
  chacha20` moves it to 0.10.2 and the audit passes; the change is two lines of
  `Cargo.lock`, a version and a checksum.

  It reaches the workspace through `rai-core` → `reqwest` → `quinn` →
  `quinn-proto 0.11.16` → `rand 0.10.2`, so it was never in the shipped engine:
  `classeve-rai-infer` pins `rand = "0.8"`, and
  `cargo tree -p classeve-rai-infer --features cli` contains no `chacha20` at
  all. The release archives build that package alone. It is fixed by updating
  rather than by an entry in `.cargo/audit.toml`, because a yanked dependency
  with a published successor is not a policy question.
- **The third-party notices gate could fail for a reason that was not in the
  repository.** `cargo about` asks `api.clearlydefined.io` for the license text
  of any crate whose own files do not settle it. When that request fails it
  emits a warning and carries on, and the file it writes then groups a dozen
  crates under different license texts and drops whole license sections. CI
  diffed that against the committed copy and reported
  "THIRD-PARTY-NOTICES.md is stale — regenerate it", sending the author to
  regenerate a file that was already correct. Observed on three of four attempts
  while verifying this release, from a host whose `curl` reached that same
  endpoint in 0.7 s.

  The step now retries the generation up to five times and, only if every
  attempt fails, reports the network failure rather than blaming the file. It
  retries rather than merely reporting because a gate that tells a human to
  re-run it is still a gate that needs a human. `--offline` would drop the
  dependency on that service outright and was rejected: its own documentation
  says it falls back to a default license file, "missing eg. copyright
  information", and reproducing exactly that information is the point of this
  file.
- **The generated notices carried Windows line endings, and `.gitattributes`
  was taught to preserve them.** The file was first generated from an
  `about.hbs` written on Windows, so 265 of its lines ended CRLF. Rather than
  fix the template, an earlier commit in this release added
  `THIRD-PARTY-NOTICES.md -text` so git would store those bytes verbatim — on
  the stated grounds that several upstream license texts ship with CRLF. That
  premise was wrong: regenerating from an LF template produces a file with
  **zero** CRLF lines. The exception is removed, the template is LF, and the
  `\n` that had been sitting literally in the middle of the file's own
  "regenerate it with" command — making the one command it publishes fail when
  pasted — is a real line continuation again.
- **A conversion job could wedge the server's only conversion slot forever.**
  `run_job` recorded the terminal phase only under `if let Ok(..)`, so a
  poisoned mutex silently skipped it — and nothing else moved a job out of
  `Running`. Because `MAX_RUNNING_JOBS` is 1 and a running job is never
  evicted from the history, one such job refused every later conversion for
  the life of the process. The terminal transition is now unconditional (an
  RAII guard that also runs while unwinding), a panic inside a conversion is
  caught and reported as that job's error, the running-slot check and the
  registration happen under one lock instead of being a check-then-act, and a
  failed thread spawn releases the slot it had already taken.
- **The container's capacity limits existed three times.** `format.rs`,
  `convert.rs` and `scripts/raimodel.py` each declared their own copy of the
  same eight bounds with nothing holding them equal, against the repository's
  own stated rule that a limit is defined once at the point that enforces it.
  The reader now owns them, the writer imports them, and
  `tests/limits_are_single_sourced.rs` reads the Python exporter and fails on
  any disagreement.
- **`rai-core` documented an embedding provider that does not exist.** The
  comment offered "OpenAI, local, mock"; only the first two are implemented,
  and the mock carries no semantics — so there is no configuration in which
  that service does semantic retrieval without sending text to an external
  endpoint. The crate, its bridge, and `rai-server --help` now say so.

## [0.2.4] - 2026-08-18

### Added
- **Multi-turn chat.** `POST /api/chat` and `/api/chat/stream` accept a
  `messages` array carrying the whole conversation; every chat template
  renders history the way its reference template does, and a one-message
  thread produces byte-identical prompts to the old single-`message` form,
  which is still accepted. Studio now replays the visible thread on every
  request — until now it *showed* a conversation but sent each message alone,
  so the model never saw what it had already been asked.
- **`rai-server` memories can be deleted, and the capacity is configurable.**
  `POST /v1/forget` and the mutation-gated `rai_forget` MCP tool remove a
  memory by its exact stored text; `RAI_CAPACITY` raises the 512-item default
  (up to 100,000), including over a snapshot written at the old ceiling. The
  capacity-exhausted error now names two remedies that exist.

### Fixed
- **The 0.2.2 decode-dispatch fix missed the two fused entry points.** The
  packed-size gate was wired into `w4a8_matvec` only, while decode reaches QKV
  through `w4a8_fused_qkv` and the MLP through `w4a8_fused_gate_up`, so small
  models kept paying the rayon fan-out on two of the four decode GEMMs per
  layer. The gate now applies to the combined fused matrix.
- **A failed re-conversion destroyed the previous good model.** Conversion
  wrote its minutes-long output straight into the target file through a
  truncating create, so a Ctrl+C, crash, or disk error mid-write left nothing.
  The bytes now go to a sibling `.partial` file that is fsynced and renamed
  over the target only after the size check passes; a failure leaves the old
  model untouched and removes the partial.
- **`rai serve` dropped Gemma's `<bos>`.** The serve path encoded prompts
  without the beginning-of-sequence token that `rai run` adds for Gemma, so
  the same model produced different prompts depending on which front end ran
  it.
- **The interference report could never fire.** Storing a fact can only bring
  an existing memory's nearest neighbour closer — a score *drop* — but the
  detector reported score *rises*, a direction a store cannot produce, and its
  critical tier sat above the ceiling of the score scale. `/v1/contradict`,
  `rai_contradict`, and the store-time report now flag the memories a
  candidate would crowd, and a coincident duplicate reaches the critical tier.
- The 0.2.2 changelog's TinyLlama figures (2.0 and 10.9 tok/s) sat
  unreconciled against the README's quiet-machine 21.8. Re-measured on this
  release at the shipped `x86-64-v2` baseline: 22.1-23.0 tok/s quiet,
  2-17 tok/s under background load — the 0.2.2 numbers were loaded-machine
  measurements. BENCHMARKS.md carries the run record.
- Release builds are now executed before they are packaged: every shipped
  binary must answer `--version` with the release's version on the runner that
  built it. The Docker build compiles with the pinned 1.95.0 toolchain instead
  of a newer image default no other build used.
- Stale documentation that contradicted the code: INSTALL and MODELS said
  Qwen3, Gemma2/3, OLMo2, and mixture-of-experts checkpoints are refused (they
  convert and run, and MODELS.md's own support table said so); ARCHITECTURE
  described header bytes 100..128 as reserved (they carry the Gemma3 and MoE
  fields); the chat-template lists omitted `phi3` and `gemma`; `--max-context`
  documented a 2048 default the code does not have; the macOS floor claim
  ignored the Apple Silicon archive; RELEASE.md described a three-target
  matrix and a `cargo package` gate that cannot pass. The pondering
  strategies' "significant quality improvement" claims are demoted to what
  they are — unmeasured — in the module doc, the CLI help, and the README.

## [0.2.3] - 2026-08-17

### Added
- **A native Apple Silicon archive**, `rai-<version>-aarch64-apple-darwin.tar.gz`.
  Until now the only macOS build was Intel, which on an M-series Mac runs under
  Rosetta — and Rosetta emulates no AVX2, so it landed on the scalar kernels
  *and* paid translation on top. The native build takes the same scalar path
  (there is still no NEON implementation) without the translation, and CI has
  been building and testing this target since 0.2.0, so nothing about it is new
  except that it is now downloadable. It is slower than the x86-64 archives on
  comparable hardware; that is measured nowhere yet and no ARM throughput is
  claimed.

### Fixed
- The release workflow pinned `-C target-cpu=x86-64-v2` for every target from
  one global environment variable, which an aarch64 build refuses outright. The
  floor is now per-target: x86-64 keeps the portable baseline and asserts it,
  aarch64 builds at the toolchain default and asserts *that*, and
  `target-cpu=native` is still refused everywhere.

## [0.2.2] - 2026-08-17

### Fixed
- **Decode ran up to 5x slower than it should have**, because single-token
  matrix-vector products were being handed to rayon regardless of how small
  they were. A 576x576 projection is 165 KB of packed nibbles, which one thread
  streams in about 17 microseconds; a rayon dispatch costs 20-27 microseconds
  before any work starts, so the fan-out was pure loss on every small layer of
  every model. `bw-bench` had been measuring this the whole time — its parallel
  read of that matrix comes back 10-20x slower than its serial one. Decode now
  parallelizes on packed size as well as row count and walks small matrices on
  one thread. Measured on a consumer laptop CPU: SmolLM2-135M 7.4 -> 37.5 tok/s,
  TinyLlama-1.1B 2.0 -> 10.9 tok/s. Prefill is unchanged by the gate and gains
  as well, because decode no longer thrashes the pool it shares.
- **A model paired with another model's tokenizer generated fluent nonsense and
  exited zero.** Conversion has always refused to overwrite a tokenizer that
  differs from the one it is writing, but nothing checked the pairing at load,
  and `rai run` takes whatever `tokenizer.json` sits beside the model. Only ids
  past the end of the vocabulary were caught, so the mismatch was invisible
  whenever the stray tokenizer was the smaller of the two. Both are now
  compared at load and a mismatch is refused by name. Embedding padding is
  still accepted: checkpoints routinely round the vocabulary up by a few
  hundred entries.
- **Studio could be made to run script from text typed into its own Source
  box.** The HTML escaper covered `&`, `<` and `>` but not quotes, while four
  call sites interpolated into quoted attributes, so a value carrying a double
  quote could close the attribute and open an event handler — which the page's
  own CSP allows, since a single-file app needs `script-src 'unsafe-inline'`.
  Quotes are escaped now.
- Two startup messages carried their own source indentation into the terminal,
  printing a run of blank space mid-sentence.

## [0.2.1] - 2026-08-14

### Fixed
- **Studio could not hold a conversation on a context of 4096 tokens or
  fewer**, which is every model converted with Studio's own default context of
  2048: the first message came back as an error, "Try again" failed the same
  way, and it never recovered. Studio was sending the whole context window as
  its per-reply `max_tokens`, but the room for a reply is the window *minus the
  prompt*, so the request was guaranteed to be refused. It was supposed to
  correct itself by reading the limit out of the server's refusal, except that
  it was still matching the wording of an older server that enforced one fixed
  ceiling; against this server, which computes the ceiling per request, the
  pattern matched nothing and no limit was ever learned. Studio now reads the
  room out of the refusal this server actually sends, repeats the send once so
  the reader gets their reply instead of a dead end, and — after any completed
  reply — sets the ceiling to the window minus what that prompt cost, so the
  Tuning control shows a number the server would accept. The wording of that
  refusal is now pinned by a test on both sides, so changing it on one side
  alone fails the build rather than silently disabling the recovery again.
  Contexts of 8192 and above were never affected.

## [0.2.0] - 2026-08-14

### Added
- **One `rai` binary with four verbs — `rai convert`, `rai run`, `rai serve`,
  `rai models`** — replacing the four separate commands. `rai run` and
  `rai serve` take the model as a positional argument and default `--tokenizer`
  to the `tokenizer.json` beside it. `rai models` lists a directory's
  `.raimodel` files from their headers alone. `rai-convert`, `rai-generate`,
  and `rai-chat` remain as deprecated wrappers over the same entry points and
  will be removed in a future release.
- **A Rust-native streaming converter** behind `rai convert`. It reads
  `.safetensors` directly, needs no Python or torch, and writes each section in
  place, so peak memory is one row block rather than the whole model — a 7B
  checkpoint converts on a 16 GB machine. Output is byte-identical to
  `export_rtn.py` for the same checkpoint and options, pinned by
  `tests/convert_matches_python.rs`.
- **Container format v2**, adding Qwen2/Qwen2.5, Llama-3.1/3.2, and Gemma
  support. The header grows to 128 bytes and gains an activation code (GeGLU
  alongside SwiGLU), the `llama3` RoPE rescaling parameters, a per-projection
  bias mask, and an embedding scale; layer sections gain optional f32 bias
  vectors. Gemma's `(1 + w)` RMSNorm folds into the stored norm weights at
  conversion. A converter emits v1 whenever none of the new fields is needed,
  so pre-v2 checkpoints still produce identical bytes. Decoupled `head_dim` is
  now accepted. The Python exporters remain v1-only and still refuse all three
  families.
- **Prompt-lookup speculative decoding** (`--lookup-k`, `--lookup-ngram`,
  `--lookup-min-ngram`): the draft is copied from the context, so there is no
  draft model and no draft forward pass. Off by default — it is a gain on
  context-quoting workloads and a loss on original prose, both measured in
  BENCHMARKS.md.
- Converter preflight that refuses checkpoints the `.raimodel` format cannot
  represent, with the blocker named. Per-head and full-width QK norms (Qwen3,
  OLMo2), Gemma2's softcapping and sandwich norms, Gemma3's per-layer RoPE
  bases, Phi-3's fused tree, and routed mixture-of-experts (Mixtral,
  Qwen3-MoE) all gained container fields inside this release and convert; what
  the preflight still refuses is a shared expert, `rope_type` values other
  than `default` and `llama3`, an `lm_head` bias, unsupported activations, and
  non-Llama module trees. These previously exported "successfully" and
  generated nonsense.
- Chat templates `chatml` (`<|im_start|>`) and `zephyr` (`<|user|>`), with
  auto-detection for ChatML. Zephyr-style models (TinyLlama-Chat) need the
  template passed explicitly because their markers are plain text, not
  vocabulary tokens.
- `rai-infer/scripts/requirements-lock.txt`: exact dependency versions verified
  to convert a real model end to end.
- `rai run` explains itself when a model emits end-of-sequence immediately
  instead of printing nothing at all.
- Double-click launchers in `launchers/` that start the local chat UI without a
  terminal on Windows, macOS, and Linux.
- rai-infer test coverage: parallel-path GEMM reference tests (fused QKV,
  fused gate/up, and the tied LM head against dequantized references above the
  rayon threshold), chat-template unit tests with an in-memory tokenizer stub,
  and a seeded speculative-decoding statistical smoke test
  (`tests/speculative_equivalence.rs`, tied fixture drafting for the untied
  fixture).
- `# Safety` documentation on every unsafe AVX2 kernel and `# Panics`
  documentation on rai-infer's asserting public APIs.
- rai-server request timeout: any REST request still running after 30 seconds is
  abandoned with HTTP 503 and a JSON error, releasing its concurrency permit.
- rai-server graceful shutdown on Ctrl-C, so in-flight durable stores finish
  before the process exits.
- `rai-server --help`/`-h` and `--version`/`-V`.
- A portless loopback `Host` header (`Host: localhost`) is accepted, and a
  rejected `Host` now names the required form instead of returning a bare 403.
- `#![forbid(unsafe_code)]` in rem-nra, plus crate-level documentation for
  rem-nra and rai-core.

### Security

- Hardened REST and MCP request boundaries, resource limits, authentication,
  persistence, and error handling.
- Made MCP persistence mutations an explicit opt-in and bounded stdio frames.
- Added stricter `.raimodel` validation and allocation/shape checks.
- Pinned CI actions, Rust toolchain, and container base-image digests.

### Changed

- **`.cargo/config.toml` now builds the portable `x86-64-v2` baseline instead
  of `target-cpu=native`, and scopes it to x86-64.** A fresh clone's
  `cargo build --release` used to produce a binary tuned to the machine that
  built it, which dies with SIGILL on any older CPU it is copied to — the
  wrong default for a public repository, where the first thing a stranger does
  is clone and build. The AVX2/FMA/F16C kernels are selected at runtime, so the
  portable floor costs nothing measurable. `RUSTFLAGS="-C target-cpu=native"`
  is still there for a local benchmark. Scoping matters separately: the old
  setting applied to every target, including aarch64, where an x86 processor
  name is meaningless.
- **CI now builds and tests on Apple Silicon (`macos-15`).** The matrix covered
  `macos-15-intel` only, so the most common Mac was untested. It is also the
  only runner without AVX2, and therefore the only place the scalar fallback
  kernels — which every reference test claims equivalence against — actually
  execute.
- `rai convert`'s default output name keeps the checkpoint directory's case:
  `Qwen2.5-0.5B-Instruct` now yields `Qwen2.5-0.5B-Instruct-q4.raimodel`, not
  `qwen2.5-0.5b-instruct-q4.raimodel`. The lowercasing was invisible on Windows
  and macOS and a trap on Linux, where the name derived from the source
  directory then names a file that does not exist. The Python exporters derive
  the same name through one shared helper, and split on both path separators
  rather than `/` alone.
- The container applies its `x86-64-v3` baseline only when the image being
  built is x86-64. `docker build .` on an Apple Silicon Mac builds linux/arm64,
  where the flag produced a wall of LLVM warnings and was ignored.
- Narrowed runtime dependency features and removed the default native
  Oniguruma/C++ features from the tokenizer dependency.
- Added locked cross-platform CI, RustSec, crate-package, Python syntax, and
  container smoke gates.
- Qualified historical benchmark and experimental compression claims.
- Renamed rai-infer's GEMM entry points from `w4a32_*` to `w4a8_*`
  (`w4a8_matvec`, `w4a8_fused_qkv`, `w4a8_fused_gate_up`, `w4a8_matmul`): the
  kernels quantize activations to int8, so the old names claimed a precision
  the hot path does not use.
- Made the rai-infer library lean: `clap`, `tokenizers`, `tiny_http`, `serde`,
  `serde_json`, and `memmap2` now sit behind a default-on `cli` feature (all
  binaries require it); `--no-default-features` builds the inference library
  with only `half`, `rayon`, `anyhow`, and `rand`. The tokenizer-aware
  `ChatTemplate::auto_detect`/`from_str_arg` helpers are gated accordingly.
- Speculative and self-speculative `step()` no longer take a
  generation-history argument: config validation requires
  `repetition_penalty == 1.0` for exact verification, so the in-loop penalty
  application (and its per-token O(context) clones) was dead by construction
  and has been removed.
- The `profile-fwd` and `bw-bench` dev tools take `--model <path>` instead of
  a hardcoded repo-relative model path (`bw-bench` skips its mmap section when
  no model is given), and their remaining `unwrap()`s on file access became
  contextual errors.
- Deduplicated coupled constants: `format.rs` now imports `gemm::MAX_GROUPS`
  and `layers::MAX_ROPE_TABLE_BYTES` instead of redefining them, keeping
  `.raimodel` validation the single gate for kernel capacity.
- **Breaking (rai-compress):** the encoding entry points no longer panic on
  caller input — `compress`, `compress_uniform_4bit`, `compare`,
  `hrc_compress`, `sac_compress`, `full_compare`, `quantize_uniform`,
  `choose_bits`, and `BitPacker::pack` now return `Result` with the crate's
  error types, matching the decoders.
- **Breaking (rai-compress):** the seven hand-rolled error enums are now
  `thiserror` derives with `#[from]`/`source` chaining; `CompressionError`
  wraps every stage error (including `GptqError` and `BitPackError`) and
  gained an `InvalidInput` variant; `BitPackError` gained `ValueOutOfRange`.
- **Breaking (rai-compress):** renamed `HRCStats::psnr_db` and
  `SACStats::psnr_db` to `snr_db` — the computed metric is a mean-signal-power
  SNR, not a peak-based PSNR — and `SACStats::original_bytes`/`ratio` now use
  the same FP64 baseline as the RC/HRC stats (previously FP16).
- rai-compress sparse outlier extraction uses an inclusive threshold so
  magnitude ties at the cutoff are extracted and the configured `fraction` is
  honored exactly; `hessian_weighted_mse` computes the same trace through
  nalgebra matrix products instead of a scalar triple loop; the HRC/SAC decode
  paths share one validated helper; the crate forbids `unsafe`, documents its
  research status (RC/HRC/SAC do not produce `.raimodel` files), and
  re-exports all types reachable through public fields.
- rai-compress tests and benches now use seeded RNGs (`StdRng`) and smaller
  matrices with verified assertion margins: the crate's test suite runs in
  about 3 seconds instead of about 8 minutes.
- **Breaking (rai-core):** `Compositor::intersect` and
  `Projection::project`/`project_normalized` return `Result` instead of
  panicking on empty, ragged, or wrongly-sized input, and
  `EmbeddingBridge::nearest_text` returns `Result<Option<String>, RaiError>`
  after validating its input like every other bridge method.
- **Breaking (rem-nra):** `NonlinearResonanceMemory::from_snapshot` replaces
  `from_params`, and `ResidualEquilibriumMemory::new`/`from_snapshot` lost their
  now-meaningless parameters. Both validate untrusted persisted state, and the
  cosine helpers treat a ragged vector as zero similarity instead of panicking.
- **Breaking (rai-core):** `HealthReport::rem_residual_norm` is renamed
  `mean_residual_norm`.
- **Breaking (rai-core):** a full store returns the new
  `RaiError::CapacityExhausted { limit }` instead of a generic memory error;
  rai-server maps it to HTTP 409 (was 500) and to a named MCP tool error.
- **Breaking (snapshot schema):** `rem_encoder`, `rem_decoder`,
  `rem_memory_state`, `rem_last_loss`, and `nra_params.value_basis` are no
  longer written, and the strict validator no longer checks their shapes. The
  schema version stays at 1 and existing version-0 and version-1 snapshots still
  load — the retired keys are ignored. Files written by this release cannot be
  read by 0.1.0.
- **Breaking (rai-server):** one text limit for the whole memory stack —
  16 KiB measured in *bytes*, shared by the REST handlers, the MCP server, and
  the library. The MCP transport previously counted 16,384 *characters*, which
  allowed up to 64 KiB. The snapshot validator still tolerates the larger
  historical bound so older files load.
- `/v1/contradict`, `rai_contradict`, and the interference report returned by
  `/v1/store` are documented for what they measure: address-space crowding. A
  store can only bring neighbours closer, so they cannot detect a semantic
  contradiction, and an empty report is not evidence of consistency. Doc
  comments and tool descriptions no longer use ODE, attractor, or basin
  language.

### Fixed
- **rai-infer compiles warning-clean on aarch64.** `cargo clippy --all-targets
  -- -D warnings` — the gate CONTRIBUTING.md asks every contributor to run —
  failed with 20 errors on Apple Silicon and ARM Linux, because the rayon
  import, the send-safe pointer wrappers, the parallel chunk-sizing constants,
  and several helpers exist only to serve the AVX2 dispatch path and are dead
  code without it. They are now behind `cfg(target_arch = "x86_64")`.
- The `launchers/` shell scripts are shipped executable. `cp` and `tar`
  preserve the checkout's mode, so a launcher committed without the executable
  bit reached Linux and macOS users as a file that cannot be double-clicked and
  answers `./rai-studio.sh` with "Permission denied" — on the two platforms
  where those scripts are the entire point. The release job now sets the bit
  and asserts it, `.gitattributes` pins `*.sh`/`*.command` to LF, and
  `INSTALL.md` says how to restore it.
- GPTQ calibration no longer dies on `datasets` 5.x: the hardcoded bare
  `wikitext` repo id is rejected by the namespaced-id rule, so calibration is
  now `Salesforce/wikitext` and overridable with `--calibration-dataset` /
  `--calibration-config`.
- The export scripts no longer require the optional `accelerate` package: they
  load weights on CPU without `device_map`, and pass the dtype keyword under the
  name the installed transformers expects (`dtype` from 5.0, `torch_dtype`
  before it). A clean environment previously failed at the first step.

- Corrected JSON-RPC notification handling and MCP tool annotations.
- Made durable memory mutations atomic at the application boundary.
- Non-Unicode environment variables fail rai-server startup instead of being
  silently ignored. A mangled `RAI_API_TOKEN` previously started the REST API
  with authentication disabled.
- The memory manager's six inner mutexes and its global mutation lock collapsed
  into one `RwLock`: reads now run concurrently instead of serializing behind
  the writer lock. The staged-commit durable-store transaction is unchanged —
  stage, write to disk, publish only on success.
- Recall no longer re-projects every stored embedding inside the lock. Each
  entry's value projection is cached at insert time and rebuilt on load, turning
  an O(n·d²) scan inside a comparator into a cosine scan over cached vectors.

### Removed

- Roughly 1,000 lines of dead rai-infer code: three compiled-out AVX2 kernel
  blocks in `gemm.rs`, the unused `w4a32_matmul_preq`/`QuantizedBatchInput`
  batched API, `silu_inplace`/`rms_norm_inplace`, unreachable
  zero-draft/bounds branches and no-op repetition-penalty plumbing in the
  speculative decoders, the drifted duplicate examples (`bench_gemm`,
  `profile_forward`), and an uncontended mutex in the deliberately
  single-threaded chat server.
- rai-compress dead dependencies: `serde` and `rand_distr` are gone, `rand`
  moved to dev-dependencies, and nalgebra's `serde-serialize` feature was
  dropped.
- **Breaking:** `POST /v1/train` and its single-flight training lock. No build
  has an optimizer, and a permanent HTTP 501 was worse than no endpoint.
  `RaiError::TrainingError`, `MemoryManager::train_nra`/`train_nra_and_save`/
  `train_rem`/`train_rem_and_save`, the whole `memory::training` module
  (`TrainingOrchestrator`), `NonlinearResonanceMemory::train_two_phase`,
  `ResidualEquilibriumMemory::train`, and `MemoryError::TrainingUnavailable` go
  with it. No MCP training tool existed.
- **Breaking:** response fields `RetrievalResult::steps`,
  `RetrievalResult::grad_norm`, and
  `ConfidenceExplanation::grad_norm`/`num_attractors`/`basin_spread`. They
  reported ODE-integration diagnostics no integrator produced. `energy` stays —
  it is a real leave-one-out crowding score.
- **Breaking:** `HealthReport::needs_training`, `nra_mse`, and `rem_mse`. The
  two "MSE" figures were the same formula over the same vectors — mean value
  magnitude, not error — and were always equal. The `mse`/`last_loss`
  accessors that computed them are gone too.
- **Breaking:** the `ConfidenceLevel::Ambiguous` tier and the `BasinAnalyzer`
  perturbation diagnostic that was its only producer. `NoMatch` now means what
  it says: no stored memory scored above zero cosine similarity.
- **Breaking:** `ConfidenceGate::with_ode_tol`/`ode_tol`/`no_match_grad_factor`
  and `NRAConfig::ode_tol`. With the gradient diagnostic gone there is no ODE
  tolerance to configure; `classify` and `explain` take only the retrieval score.
- **Breaking:** `NRAConfig::train_epochs`, `REMConfig::train_epochs`,
  `NRAParams::value_basis`, `rem_nra::nra::find_attractor`,
  `rem_nra::nra::energy`, `AttractorResult`, `MemoryError::Empty`, and
  `ResidualEquilibriumMemory`'s encoder/decoder biases and rolling
  `memory_state` — none of which fed a live computation.
- Dead code: `MemoryManager::new` (unvalidated, zero callers, enabled a
  dimension-mismatch panic), `MemoryEntry`, `TextIndex::find_nearest`/
  `get_by_id`, `EmbeddingBridge::text_to_key`/`text_to_value`/`embed_text`,
  `Compositor::weighted_intersect`/`difference`/`analogy`, and the never-read
  `next_id` counter.
- Dead dependencies: `log` from rai-core and `tower-http` from rai-server.

## [0.1.0] - 2026-06-14

- First public GitHub release. The five `classeve-rai-*` crates were initially
  published to crates.io on 2026-06-11.
