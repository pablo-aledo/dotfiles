---
name: Discussion
about: Begin a discussion
title: ''
labels: discussion
assignees: ''

---

**Topic**
A clear and concise description of what you want to discuss

**Your thoughts**
What you have to say about the topic
