The JSON files in this directory are machine-generated; please do not edit.

Translating lazygit happens at https://crowdin.com/project/lazygit/.
