This directory contains stuff for recording lazygit demos.

