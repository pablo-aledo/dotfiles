package ansi

import "syscall"

const ioctlReadTermios = syscall.TIOCGETA
