from bot.bot_model_manager import BotModelManager
from bot.config import load_config

config = load_config()
models = BotModelManager()
