from .pipeline import OnnxStableDiffusion
