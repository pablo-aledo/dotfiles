#!/bin/bash
python3 main.py --log-level=${LOG_LEVEL} --host