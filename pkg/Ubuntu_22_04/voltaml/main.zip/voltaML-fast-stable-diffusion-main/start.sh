#!/bin/bash
venv/bin/python main.py