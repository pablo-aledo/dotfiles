# TODO

## Might deserve their own page

- prompt expansion
- rewrite lora docs
- extra sampler settings
- Samplers (+ Kdiffusion samplers)
- SAG
- Hi-res
- Add examples to Img2img
- Upscaling and how to add another upscaler
- Taggers
- ONNX (if it even works)
- VAE
- Attention processors
- Stable-Fast
- Torch compile
- Offload
- Update docs with bfloat16
- SGM noise multiplier
- Quantization in k-samplers
- CLIP skip
- TomeSD
- Huggingface style prompting

## Probably bundle together

- Attention slicing
- Channels last
- Hypertile
- Reduced Precision
- Cudnn benchmark
- VAE Slicing + VAE Tiling
- Dont merge latents
- Continuous generation
- Sending logs to UI
