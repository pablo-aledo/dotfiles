# Troubleshooting Docker

## no configuration file provided: not found

You probably just cloned the repo but forgot to do `cd voltaML-fast-stable-diffusion`
