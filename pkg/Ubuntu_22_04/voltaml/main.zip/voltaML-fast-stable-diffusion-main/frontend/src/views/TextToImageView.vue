<template>
  <TextToImage />
</template>

<script setup lang="ts">
import { TextToImage } from "@/components";
</script>
