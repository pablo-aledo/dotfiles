export { default as ESRGAN } from "./ESRGAN.vue";
