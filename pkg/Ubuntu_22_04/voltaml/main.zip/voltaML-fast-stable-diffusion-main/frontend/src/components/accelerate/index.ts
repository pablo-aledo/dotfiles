export { default as AITemplateDynamicAccelerate } from "./AITemplateDynamicAccelerate.vue";
export { default as ONNXAccelerate } from "./ONNXAccelerate.vue";
