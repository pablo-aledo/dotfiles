<template>Dependency manager</template>

<script lang="ts" setup></script>
