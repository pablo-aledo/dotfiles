export type SigmaType =
  | "automatic"
  | "karras"
  | "exponential"
  | "polyexponential"
  | "vp";
