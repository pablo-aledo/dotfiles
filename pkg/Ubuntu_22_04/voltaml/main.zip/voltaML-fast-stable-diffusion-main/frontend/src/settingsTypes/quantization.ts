export interface IQuantDict {
  vae_decoder: boolean | null;
  vae_encoder: boolean | null;
  unet: boolean | null;
  text_encoder: boolean | null;
}
