export interface ISDXLSettings {
  original_size: {
    width: number;
    height: number;
  };
}
