export interface IAITemplateSettings {
  num_threads: number;
}
