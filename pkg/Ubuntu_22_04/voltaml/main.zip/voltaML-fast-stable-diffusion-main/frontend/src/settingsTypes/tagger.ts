export interface ITaggerSettings {
  image: string;
  model: string;
  threshold: number;
}
