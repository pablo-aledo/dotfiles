from .websockets.manager import WebSocketManager

websocket_manager = WebSocketManager()

__all__ = ["websocket_manager"]
