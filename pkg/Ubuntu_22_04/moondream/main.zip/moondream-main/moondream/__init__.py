from .util import detect_device, LATEST_REVISION
from .moondream import Moondream
