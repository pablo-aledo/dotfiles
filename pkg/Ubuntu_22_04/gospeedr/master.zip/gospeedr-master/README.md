**Migrated to https://codeberg.org/anaseto/gospeedr because of new 2FA requirement**

A simple [speed reading](https://en.wikipedia.org/wiki/Speed_reading) program.
Note that there is little scientific evidence of any actual usefulness.  This
program is just for fun and provided as an example of small but complete
application using [gruid](https://github.com/anaseto/gruid). 

Install with `go get github.com/anaseto/gospeedr`. Use `--help` for options.

You may add `--tags sdl` to build an SDL version, instead of the terminal one.
