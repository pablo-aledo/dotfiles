# Fixtures for integration tests
