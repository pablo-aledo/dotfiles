---
name: Enhancement suggestion
about: Enhance existing designs
title: ''
labels: enhancement
assignees: ''

---

**The part you want to Enhancement**
Please briefly describe the part you want to strengthen

**Why it is necessary to enhancement**
Please explain why it needs to be enhancement, what are the flaws in the existing design, etc.

**Additional context**
Add any other context or screenshots about the feature request here.
