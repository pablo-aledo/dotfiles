#!/usr/bin/env bash

rm -r "$HOME/.config/superfile"
rm -r "$HOME/.local/state/superfile"
rm -r "$HOME/.local/share/superfile"