#!/usr/bin/env bash

# build the app
CGO_ENABLED=0 go build -o ./bin/spf
