---
title: Plugin list
description: superfile plugin list
head:
  - tag: title
    content: Plugin list | superfile
---

## Metadata
description: Show more detailed metadata

Requirements: `exiftool`

name in config.toml: `metadata`