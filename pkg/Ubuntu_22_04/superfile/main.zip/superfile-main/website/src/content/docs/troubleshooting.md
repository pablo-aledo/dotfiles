---
title: Troubleshooting
description: Have you encountered any problems? Come here and take a look.
head:
  - tag: title
    content: Troubleshooting | superfile
---

## My superfile icon doesn't display correctly

Try these things below:

- Make sure you already install [nerdfont](https://www.nerdfonts.com/font-downloads) (You can choose whatever font you like!)
- Apply this font to your terminal,This may require different settings depending on the terminal.You can check how to set it up!

## Help! My superfile's rendering is all messed up!

Try these things below:

- Set your locale to utf-8  
- chcp 65001 ( If that's an option for your shell )  
- Set environment variable RUNEWIDTH_EASTASIAN to 0 (`RUNEWIDTH_EASTASIAN=0`)