package ui

import (
	"fmt"

	"signls/core/common"
	"signls/filesystem"
	"signls/ui/param"
	"signls/ui/util"

	"charm.land/lipgloss/v2"
)

const (
	maxGrids     = 32
	gridsPerLine = 16
)

var (
	pagesArrows = [][]string{
		{
			"",
			"\u23F7",
		},
		{
			"\u23F6",
			"\u23F7",
		},
		{
			"\u23F6",
			"",
		},
	}
	controlStyle = lipgloss.NewStyle().
			MarginTop(1).
			MarginLeft(2)
	cellStyle = lipgloss.NewStyle().
			MarginRight(2)
	activeCellStyle = cellStyle.
			Foreground(lipgloss.Color("190"))
	bankStyle = lipgloss.NewStyle().
			MarginRight(1).
			Background(lipgloss.Color("79")).
			Foreground(lipgloss.Color("0"))
	bankStyleOdd = lipgloss.NewStyle().
			MarginRight(1).
			Background(lipgloss.Color("85")).
			Foreground(lipgloss.Color("0"))
	activeBankStyle = lipgloss.NewStyle().
			MarginRight(1).
			Background(lipgloss.Color("15")).
			Foreground(lipgloss.Color("0"))
)

func (m mainModel) renderControl() string {
	if m.mode == BANK {
		return controlStyle.Render(m.bankSelection())
	}

	var pane string
	if m.mode == EDIT && m.input.Focused() {
		pane = fmt.Sprintf(
			"%s %s",
			m.activeParam().Name(),
			m.input.View(),
		)
	} else if m.mode == EDIT || m.mode == CONFIG {
		pane = m.paramEdit()
	} else {
		pane = m.gridInfo()
	}

	return controlStyle.Render(
		lipgloss.JoinHorizontal(
			lipgloss.Left,
			lipgloss.JoinVertical(
				lipgloss.Left,
				cellStyle.Width(9).Render(m.selectedNodeName()),
				cellStyle.Render(m.modeName()),
			),
			pane,
		),
	)
}

func (m mainModel) bankSelection() string {
	grids := m.bank.AllGrids()
	active := m.bank.ActiveIndex()
	banks := make([]string, maxGrids)
	for i, g := range grids[:maxGrids] {
		label := bankGridLabel(i, g)
		if i == m.selectedGrid {
			banks[i] = cursorStyle.MarginRight(1).Render(label)
		} else if i == active {
			banks[i] = activeBankStyle.Render(label)
		} else if (i < gridsPerLine && i%2 == 0) || (i >= gridsPerLine && i%2 == 1) {
			banks[i] = bankStyle.Render(label)
		} else {
			banks[i] = bankStyleOdd.Render(label)
		}

	}
	pane := lipgloss.JoinVertical(
		lipgloss.Left,
		lipgloss.JoinHorizontal(
			lipgloss.Left,
			banks[:gridsPerLine]...,
		),
		lipgloss.JoinHorizontal(
			lipgloss.Left,
			banks[gridsPerLine:maxGrids]...,
		),
	)

	return lipgloss.JoinHorizontal(
		lipgloss.Left,
		lipgloss.JoinVertical(
			lipgloss.Left,
			activeBankStyle.MarginRight(9).Render(bankGridLabel(active, m.bank.ActiveGrid())),
			cellStyle.Render(m.modeName()),
		),
		pane,
	)
}

func (m mainModel) gridInfo() string {
	root := param.Get("root", m.gridParams)
	scale := param.Get("scale", m.gridParams)
	return lipgloss.JoinHorizontal(
		lipgloss.Left,
		lipgloss.JoinVertical(
			lipgloss.Left,
			cellStyle.Render(fmt.Sprintf("%d,%d", m.cursorX, m.cursorY)),
			cellStyle.Render(fmt.Sprintf("%d,%d", m.grid.Width-1, m.grid.Height-1)),
		),
		lipgloss.JoinVertical(
			lipgloss.Left,
			cellStyle.Render(fmt.Sprintf("%.f %s", m.grid.Tempo(), m.tempoSymbol())),
			cellStyle.Render(fmt.Sprintf("%s %d", m.transportSymbol(), m.grid.Pulse())),
		),
		lipgloss.JoinVertical(
			lipgloss.Left,
			cellStyle.Render(root.Display()),
			cellStyle.Render(scale.Display()),
		),
		lipgloss.JoinVertical(
			lipgloss.Left,
			fmt.Sprintf(
				"%s%s",
				activeBankStyle.Render(bankGridLabel(m.bank.ActiveIndex(), m.bank.ActiveGrid())),
				m.bank.Filename(),
			),
		),
	)
}

func (m mainModel) paramEdit() string {
	var params []string

	if len(m.params) > 1 {
		params = []string{
			cellStyle.Render(
				lipgloss.JoinVertical(
					lipgloss.Left,
					pagesArrows[m.paramPage]...,
				),
			),
		}
	}

	for k, p := range m.activeParamPage() {
		style := cellStyle
		if k == m.param {
			style = activeCellStyle
		}
		params = append(
			params,
			lipgloss.JoinVertical(
				lipgloss.Left,
				style.Render(p.Display()),
				style.Render(p.Name()),
			),
		)
	}
	return lipgloss.JoinHorizontal(
		lipgloss.Left,
		params...,
	)
}

func (m mainModel) tempoSymbol() string {
	if m.grid.QuarterNote() {
		return "●"
	}
	return " "
}

func (m mainModel) transportSymbol() string {
	if m.grid.Playing {
		return "▶"
	}
	return "■"
}

func (m mainModel) modeName() string {
	switch m.mode {
	case BANK:
		return "bank"
	case EDIT:
		return "edit"
	case CONFIG:
		return "config"
	default:
		return "move"
	}
}

func (m mainModel) selectedEmitters() []common.Node {
	nodes := []common.Node{}
	for y := m.cursorY; y <= m.selectionY; y++ {
		for x := m.cursorX; x <= m.selectionX; x++ {
			if m.grid.Nodes()[y][x] == nil {
				continue
			} else if _, ok := m.grid.Nodes()[y][x].(common.Movable); ok {
				continue
			}
			nodes = append(nodes, m.grid.Nodes()[y][x])
		}
	}
	return nodes
}

func (m mainModel) selectedNodeName() string {
	nodes := m.selectedEmitters()
	if len(nodes) == 0 {
		return "empty"
	} else if len(nodes) > 1 {
		return fmt.Sprintf("%d nodes", len(nodes))
	}
	return lipgloss.JoinHorizontal(
		lipgloss.Left,
		emitterStyle.
			MarginRight(1).
			Background(lipgloss.Color(nodes[0].Color())).
			Render(util.Normalize(nodes[0].Symbol())),
		nodes[0].Name(),
	)
}

func bankGridLabel(nb int, g filesystem.Grid) string {
	label := fmt.Sprintf("%2d", nb+1)
	if !g.IsEmpty() {
		label = util.Normalize(fmt.Sprintf("%2d\u0320", nb+1))
	}
	return label
}
