package param

import (
	"signls/core/field"
	"signls/core/theory"
)

const (
	maxKey int = 127
)

type Root struct {
	grid *field.Grid
}

func (r Root) Name() string {
	return "root"
}

func (r Root) Help() string {
	return ""
}

func (r Root) Display() string {
	return r.grid.Key.Name()
}

func (r Root) Value() int {
	return int(r.grid.Key)
}

func (r Root) AltValue() int {
	return 0
}

func (r Root) Up() {
	r.grid.ShiftKey(1)
}

func (r Root) Down() {
	r.grid.ShiftKey(-1)
}

func (r Root) Left() {}

func (r Root) Right() {}

func (r Root) AltUp() {}

func (r Root) AltDown() {}

func (r Root) AltLeft() {}

func (r Root) AltRight() {}

func (r Root) Set(value int) {
	if value < 0 || value > maxKey {
		return
	}
	r.grid.SetKey(theory.Key(value))
}

func (r Root) SetAlt(value int) {}

func (r Root) SetEditValue(input string) {}
