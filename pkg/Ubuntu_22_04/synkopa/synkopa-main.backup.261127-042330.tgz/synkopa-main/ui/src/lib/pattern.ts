// Channels, step sequencer and piano roll: pure logic shared by the pattern editor, the
// optimistic store, and the in-browser mock (which must behave like crates/engine/src/ops.rs).
//
// Units: pattern `len` in beats; note `step`/`len` in 16ths ("steps"); `p` MIDI key
// (absent = the channel's root); `v` velocity 0..1 (absent = 1).
import { t, type TranslationKey } from './i18n';
import { migrateSatParams } from './saturator';
import { keysRange } from './keysKnobs';
import { keysInstrument } from './keysCatalog';
import { KEYS_DEFAULT_INSTRUMENT, KEYS_RELEASE, SAMPLE_ROOT, SAMPLER, samplerDefault, TOTAL_BEATS, type Channel, type Id, type Note, type Op, type Pattern, type Project, type SamplerState } from '../api/types';
import { addStarterKit } from './factory';
import { SYNTH_CATALOG } from '../api/synthCatalog';
import { synthError } from './synth';

/** Beats per bar (4/4). */
export const BAR = 4;
const EPS = 1e-3;

/** Why sampler settings cannot be used, or null (model.rs `SamplerState::check`). */
export function samplerError(s: SamplerState | undefined): string | null {
  if (!s) return null; // absent = the defaults
  const within = (v: number, lo: number, hi: number) => Number.isFinite(v) && v >= lo && v <= hi;
  if (!(within(s.start, 0, 1) && within(s.end, 0, 1) && s.end - s.start >= SAMPLER.minSpan - 1e-6)) return 'sampler start and end are fractions 0..1 of the file, start before end';
  if (!(Number.isInteger(s.semi) && within(s.semi, SAMPLER.semi.min, SAMPLER.semi.max) && within(s.fine, SAMPLER.fine.min, SAMPLER.fine.max))) return 'sampler pitch is -24..24 semitones and -100..100 cents';
  if (!(within(s.delay, SAMPLER.delay.min, SAMPLER.delay.max) && within(s.attack, SAMPLER.attack.min, SAMPLER.attack.max) && within(s.hold, SAMPLER.hold.min, SAMPLER.hold.max)
    && within(s.decay, SAMPLER.decay.min, SAMPLER.decay.max) && within(s.sustain, 0, 1) && within(s.release, SAMPLER.release.min, SAMPLER.release.max)))
    return 'sampler envelope: delay 0..5000 ms, attack 0..2000 ms, hold 0..5000 ms, decay 0..5000 ms, sustain 0..1, release 1..5000 ms';
  if (![s.attackTension, s.decayTension, s.releaseTension].every(k => within(k, -1, 1))) return 'sampler envelope tensions are -1..1';
  if (!(within(s.fadeInMs ?? 0, 0, SAMPLER.fadeMaxMs) && within(s.fadeOutMs ?? 0, 0, SAMPLER.fadeMaxMs))) return 'sampler fades must be 0..5000 ms';
  if (!(Number.isInteger(s.cut) && within(s.cut, 0, SAMPLER.cutGroups))) return 'sampler cut group is 0 (none) or 1..8';
  return null;
}
export const keyOf = (n: Note, c: Channel | undefined) => n.p ?? c?.root ?? SAMPLE_ROOT;
export const velOf = (n: Note) => n.v ?? 1;
/** A note's own pan, -1 (left) .. 1 (right); 0 when it has none. */
export const panOf = (n: Note) => n.pan ?? 0;
/** Number of 16ths in the pattern. */
export const stepsOf = (p: Pattern) => Math.max(1, Math.round(p.len * 4));
/** A channel loop may not expand into more scheduled notes than this (model.rs `MAX_LOOP_NOTES`). */
export const MAX_LOOP_NOTES = 65_536;
/** A channel's loop length in steps in this pattern (FL 20.1's channel looping), 0 = none. */
export const loopStepsOf = (p: Pattern, ch: Id) => p.channelLoops?.[String(ch)] ?? 0;
/** The steps of the pattern a channel's own grid occupies: its loop length when looped, else the whole pattern. */
export const channelStepsOf = (p: Pattern, ch: Id) => { const l = loopStepsOf(p, ch); return l > 0 ? l : stepsOf(p); };
/** The cell step a looped channel plays at absolute step `s` (its content repeats to fill the pattern). */
export const cellStep = (p: Pattern, ch: Id, s: number) => { const l = loopStepsOf(p, ch); return l > 0 ? s % l : s; };
/** Sets the channel's loop to `loop` steps (FL 20.1's channel looping), 0 clears it. A set keeps
 * only the notes below the loop (what plays), so nothing is ever hidden; a clear keeps the cell. */
export function setChannelLoop(p: Pattern, ch: Id, loop: number): Pattern {
  const loops: Record<string, number> = { ...(p.channelLoops ?? {}) };
  if (loop > 0) loops[String(ch)] = loop; else delete loops[String(ch)];
  const notes = loop > 0 ? p.notes.filter(n => !(n.ch === ch && n.step >= loop)) : p.notes;
  // the length the pattern had becomes the minimum only when the trim would otherwise
  // shorten it: if the remaining notes still reach that length, minLen stays the user's
  // (deleting the late note that holds it shrinks the pattern again)
  const holds = loop > 0 && contentLen(notes) < p.len;
  return { ...p, notes, channelLoops: Object.keys(loops).length ? loops : undefined, ...(holds ? { minLen: Math.max(p.minLen ?? BAR, p.len) } : {}) };
}
/** The channel's loop materialized: every repeat becomes a real step, the loop goes (FL's
 * "Burn to pattern"). Notes already past the old loop are cleared first (they never played). */
export function burnChannelLoop(p: Pattern, ch: Id): Pattern {
  const l = loopStepsOf(p, ch);
  if (!(l > 0)) return p;
  const steps = stepsOf(p);
  const cell = p.notes.filter(n => n.ch === ch && n.step < l);
  const notes = p.notes.filter(n => n.ch !== ch || n.step < l);
  for (let k = 1; k * l < steps; k++) for (const n of cell) {
    const s = n.step + k * l;
    if (s < steps) notes.push({ ...n, step: s, len: Math.min(n.len, steps - s) });
  }
  const loops: Record<string, number> = { ...(p.channelLoops ?? {}) };
  delete loops[String(ch)];
  return { ...p, notes, channelLoops: Object.keys(loops).length ? loops : undefined };
}
/** Channel Rack step grid: extra px between groups of four steps (beats), like FL's. */
export const BEAT_GAP = 5;
/** Left edge (px) of a step in the Channel Rack grid, `cw` px per step; fractional steps interpolate inside their cell. */
export const stepX = (step: number, cw: number) => step * cw + Math.floor(step / 4 + 1e-6) * BEAT_GAP;
/** Width (px) of `steps` steps including the beat gaps between them. */
export const gridW = (steps: number, cw: number) => steps * cw + Math.max(0, Math.ceil(steps / 4) - 1) * BEAT_GAP;
/** The step under grid x (px); a point in a beat gap belongs to the step on its left. */
export function stepAt(x: number, cw: number): number {
  const gw = 4 * cw + BEAT_GAP, b = Math.floor(x / gw);
  return b * 4 + Math.min(3, Math.floor((x - b * gw) / cw));
}
/** Widest cell (px) at which `steps` steps and their beat gaps fit into `w` px. */
export const fitCw = (w: number, steps: number) => Math.floor((w - (Math.ceil(steps / 4) - 1) * BEAT_GAP) / steps);
/** Beats the notes need: the end of the last one rounded up to a bar, ≥ 1 bar, ≤ the song (model.rs `content_len`). */
export function contentLen(notes: readonly Note[]): number {
  let end = 0;
  for (const n of notes) end = Math.max(end, (n.step + n.len) / 4);
  return Math.min(TOTAL_BEATS, Math.max(1, Math.ceil(end / BAR - 1e-6)) * BAR);
}
/** The pattern's `minLen` in whole bars (beats), ≥ 1 bar. */
export const minLenOf = (p: Pick<Pattern, 'minLen'>) => Math.min(TOTAL_BEATS, Math.max(1, Math.ceil((p.minLen ?? BAR) / BAR - 1e-6)) * BAR);
/** Sets `len` (and normalises `minLen`) like the engine's `Pattern::fit_len`. */
export function fitLen(p: Pattern): Pattern {
  p.minLen = minLenOf(p);
  p.len = Math.max(contentLen(p.notes), p.minLen);
  return p;
}

/** Swing in steps added to a note on an odd 16th (crates/engine/src/model.rs `swing_offset`). */
export function swingOffset(step: number, swing: number): number {
  const r = Math.round(step);
  if (swing <= 0 || Math.abs(step - r) > EPS || ((r % 2) + 2) % 2 !== 1) return 0;
  return 0.5 * Math.min(1, swing);
}

// ---------------------------------------------------------------- engine mirror

export class PatternOpError extends Error {}

const bump = (p: Project, id: Id) => { if (id >= p.nextId) p.nextId = id + 1; };

/** Drops the fields the engine's serde omits on write: swing only when non-zero, a note's
 * `v` only when it is not exactly 1, channel loops only when the map is non-empty
 * (`skip_serializing_if`). */
export function stripPatternDefaults(pt: Pattern): void {
  if (!pt.swing) delete pt.swing;
  for (const n of pt.notes) if (n.v === 1) delete n.v;
  if (pt.channelLoops && !Object.keys(pt.channelLoops).length) delete pt.channelLoops;
}

/** Project.migrate: derived pattern lengths, the starter kit when the Channel Rack is empty. */
/**
 * A sampler saved before the volume-envelope switch (engine `migrate_sampler_envelopes`): it had a `gate` mode
 * and always applied attack, decay and sustain, so a gated or shaped one opens with its envelope on.
 */
export function migrateSamplerEnvelope(s: SamplerState & { gate?: boolean }) {
  if (typeof s.env !== 'boolean') s.env = !!s.gate || (s.attack ?? 0) > 0 || (s.sustain ?? 1) < 1;
  delete s.gate;
  const d = samplerDefault();
  for (const k of ['delay', 'hold', 'attackTension', 'decayTension', 'releaseTension'] as const) s[k] ??= d[k];
}

export function migrateProject(p: Project) {
  for (const pt of p.patterns) fitLen(pt);
  if (!p.channels?.length) addStarterKit(p);
  for (const c of p.channels ?? []) if (c.kind === 'sample' && c.sampler) migrateSamplerEnvelope(c.sampler);
  // saturator parameters from before the character saturator
  for (const ins of p.inserts) for (const fx of ins.fx) if (fx.type === 'sat' && migrateSatParams(fx.params)) fx.preset = null;
}

/**
 * A pattern's length changed: its clips follow without overlapping another clip or looping the
 * pattern (the engine's `follow_pattern_length`, ops.rs). Grown: whole-pass clips (offset 0, old
 * length) take the new length but stop at the next clip on their track. Shrunk: clips whose window
 * lay within the old pattern are cut back to its new end; clips already past the old end keep theirs.
 */
export function followPatternLength(p: Project, id: Id, oldLen: number, len: number) {
  const EPS = 1e-6;
  for (const c of p.clips) {
    if (c.kind !== 'pat' || c.ref !== id) continue;
    let to: number;
    if (len > oldLen) {
      if (Math.abs(c.offset) >= 1e-9 || Math.abs(c.len - oldLen) >= EPS) continue;
      let next = Infinity;
      for (const o of p.clips) if (o.id !== c.id && o.track === c.track && o.start > c.start + EPS && o.start < next) next = o.start;
      to = Math.max(c.len, Math.min(len, next - c.start));
    } else {
      const end = c.offset + c.len;
      if (end > oldLen + EPS || end <= len + EPS || c.offset >= len - EPS) continue;
      to = len - c.offset;
    }
    c.len = Math.max(1 / 16, Math.min(to, TOTAL_BEATS - c.start));
  }
}

/** The engine's `check_channel_loops` (throws when `strict`): each entry names a channel, sits
 * inside the pattern, and the repeats of all entries together stay bounded. */
export function checkChannelLoops(p: Project, pt: Pattern, strict: boolean): void {
  const fail = (m: string) => { if (strict) throw new PatternOpError(m); };
  const steps = Math.round(pt.len * 4);
  let extra = 0;
  for (const [k, l] of Object.entries(pt.channelLoops ?? {})) {
    const ch = Number(k);
    if (strict && !(p.channels ?? []).some(c => c.id === ch)) fail(`no channel with id ${ch}`);
    if (!(l >= 1 && l <= steps && Number.isInteger(l))) fail(`pattern ${pt.id}: a channel loop must be 1..=${steps} steps`);
    const cell = pt.notes.filter(n => n.ch === ch).length;
    const reps = Math.max(0, Math.ceil(steps / l) - 1);
    extra += reps * cell;
  }
  if (pt.notes.length + extra > MAX_LOOP_NOTES) fail(`pattern ${pt.id}: the channel loops may not repeat into more than ${MAX_LOOP_NOTES} notes`);
}

/** What a pattern-length change did to the clips that show it (`followChanges`). */
export interface FollowReport {
  /** The pattern, its new length in beats. */
  pattern: Id; len: number;
  /** Clips that took the new length. */
  followed: Id[];
  /** Clips that grew, but stopped at the next clip on their track (they show part of the pattern). */
  stopped: Id[];
}

/**
 * Compares the pattern clips' lengths before an edit (`before`: clip id → length, of the patterns in
 * `lens`: pattern id → length before) with `p` after it. One report per pattern whose clips changed.
 */
export function followChanges(lens: ReadonlyMap<Id, number>, before: ReadonlyMap<Id, number>, p: Project): FollowReport[] {
  const out: FollowReport[] = [];
  for (const [pid, was] of lens) {
    const pt = p.patterns.find(x => x.id === pid);
    if (!pt || Math.abs(pt.len - was) < 1e-9) continue;
    const r: FollowReport = { pattern: pid, len: pt.len, followed: [], stopped: [] };
    for (const c of p.clips) {
      if (c.kind !== 'pat' || c.ref !== pid) continue;
      const b = before.get(c.id);
      if (b == null || Math.abs(b - c.len) < 1e-9) continue;
      const full = Math.min(pt.len - c.offset, TOTAL_BEATS - c.start);
      (c.len > b && c.len < full - 1e-6 ? r.stopped : r.followed).push(c.id);
    }
    if (r.followed.length || r.stopped.length) out.push(r);
  }
  return out;
}

/**
 * Applies a pattern/channel op in place (`putPattern`, `putChannel`, `removeChannel`, and the
 * channel side of `removeSource`). `strict` validates like the engine and throws; the
 * optimistic store applies without checks. Returns false for ops it does not handle.
 * `copy` makes the pattern's private copy put in the project (the store applies every edit twice,
 * see state/store.ts, and passes a faster one than `structuredClone` for a pattern's flat notes).
 */
export function applyPatternOp(p: Project, op: Op, strict: boolean, copy: (pt: Pattern) => Pattern = structuredClone): boolean {
  const fail = (m: string) => { if (strict) throw new PatternOpError(m); };
  switch (op.op) {
    case 'putPattern': {
      const pt: Pattern = copy(op.pattern);
      if (!((pt.swing ?? 0) >= 0 && (pt.swing ?? 0) <= 1)) fail('swing must be 0..1');
      for (const n of pt.notes) {
        if (!(n.step >= 0 && n.len > 0 && isFinite(n.step) && isFinite(n.len))) fail(`pattern ${pt.id}: a note has an invalid step/len`);
        if ((n.step + n.len) > TOTAL_BEATS * 4) fail(`pattern ${pt.id}: notes must end within ${TOTAL_BEATS} beats`);
        if (n.v != null && !(n.v >= 0 && n.v <= 1)) fail('note velocity `v` must be 0..1');
        if (n.p != null && !(n.p >= 0 && n.p <= 127)) fail('note key `p` must be 0..127');
        if (n.trig != null && typeof n.trig !== 'boolean') fail('note `trig` must be a boolean');
        if (!n.ch) fail('every note needs `ch`');
      }
      if (strict) { const bad = pt.notes.find(n => !(p.channels ?? []).some(c => c.id === n.ch)); if (bad) fail(`no channel with id ${bad.ch}`); }
      stripPatternDefaults(pt);
      fitLen(pt);
      checkChannelLoops(p, pt, strict);
      bump(p, pt.id);
      const i = p.patterns.findIndex(x => x.id === pt.id);
      if (i >= 0) {
        const old = p.patterns[i].len;
        p.patterns[i] = pt;
        if (Math.abs(old - pt.len) > 1e-9) followPatternLength(p, pt.id, old, pt.len);
      } else p.patterns.push(pt);
      return true;
    }
    case 'putChannel': {
      const c = structuredClone(op.channel);
      if (!(c.vol >= 0 && c.vol <= 1)) fail('channel vol is a fader position 0..1');
      if (!(c.pan >= -1 && c.pan <= 1)) fail('channel pan must be -1..1');
      if (c.root > 127) fail('channel root must be 0..127');
      if (c.group != null && (!c.group.trim() || [...c.group].length > 40)) fail('channel group: 1..40 characters (absent = unsorted)');
      if (c.kind === 'sample') {
        if (!p.sources.some(s => s.id === c.source)) fail(`no source with id ${c.source}`);
        const e = samplerError(c.sampler); if (e) fail(e);
      }
      if (c.kind === 'synth') { const e = synthError(SYNTH_CATALOG, c.synth ?? { preset: null, params: {} }); if (e) fail(e); }
      if (c.kind === 'keys') {
        const r = c.keys?.release;
        if (r != null && !(r >= KEYS_RELEASE.min && r <= KEYS_RELEASE.max)) fail(`keys release must be ${KEYS_RELEASE.min}..${KEYS_RELEASE.max} ms`);
        if (!(c.keys.dynamics >= 0 && c.keys.dynamics <= 100)) fail('keys dynamics must be 0..100 %');
        for (const [name, k, unit] of [['attack', 'attack', 'ms'], ['tone', 'tone', ''], ['width', 'width', '%'], ['tune', 'tune', 'cents'], ['noise', 'noise', '%']] as const) {
          const v = c.keys[k], r = keysRange(k);
          if (v != null && !(v >= r.min && v <= r.max)) fail(`keys ${name} must be ${r.min}..${r.max} ${unit}`.trimEnd());
        }
        const inst = keysInstrument(c.keys.instrument ?? KEYS_DEFAULT_INSTRUMENT);
        if (!inst) fail(`Synkopa Instruments has no instrument \`${c.keys.instrument}\``);
        else if (c.keys.articulation != null && !inst.articulations.some(a => a.key === c.keys.articulation)) fail(`${inst.id} has no articulation on key ${c.keys.articulation}`);
      }
      if (c.kind === 'plugin') {
        if (c.plugin?.format !== 'vst3') fail(`${c.plugin?.format === 'lv2' ? 'LV2' : 'these'} instruments are not supported (VST3 only)`);
        if (!c.plugin.cid?.trim() || !c.plugin.path?.trim()) fail("a plugin instrument needs the plugin's path and class id");
      }
      if (c.insert != null && !p.inserts.some(m => m.id === c.insert)) fail(`no insert with id ${c.insert}`);
      const chans = p.channels ?? (p.channels = []);
      bump(p, c.id);
      const i = chans.findIndex(x => x.id === c.id);
      if (i >= 0) {
        chans[i] = c;
        if (op.index != null) { const [x] = chans.splice(i, 1); chans.splice(Math.min(op.index, chans.length), 0, x); }
      } else chans.splice(Math.min(op.index ?? chans.length, chans.length), 0, c);
      return true;
    }
    case 'removeChannel': {
      const chans = p.channels ?? [];
      if (!chans.some(c => c.id === op.id)) { fail(`no channel with id ${op.id}`); return true; }
      p.channels = chans.filter(c => c.id !== op.id);
      for (const pt of p.patterns) {
        pt.notes = pt.notes.filter(n => n.ch !== op.id);
        if (pt.channelLoops) { delete pt.channelLoops[op.id]; if (!Object.keys(pt.channelLoops).length) delete pt.channelLoops; }
      }
      return true;
    }
    case 'removeSource': {
      // sampler channels playing it go, with their notes (the caller removes the source)
      const gone = new Set((p.channels ?? []).filter(c => c.kind === 'sample' && c.source === op.id).map(c => c.id));
      if (gone.size) {
        p.channels = (p.channels ?? []).filter(c => !gone.has(c.id));
        for (const pt of p.patterns) pt.notes = pt.notes.filter(n => !gone.has(n.ch));
      }
      return false;
    }
  }
  return false;
}

// ---------------------------------------------------------------- step sequencer

/** A note of channel `ch` starting in cell [s, s+1): on the step, or off the grid inside it (a triplet). */
const onStep = (n: Note, ch: Id, s: number) => n.ch === ch && n.step >= s - EPS && n.step < s + 1 - EPS;
export const isStepOn = (notes: readonly Note[], ch: Id, s: number) => notes.some(n => onStep(n, ch, s));

/** Notes with step `s` of channel `ch` set on (a trigger at the root) or off (every note starting in its cell). */
export function setStep(notes: readonly Note[], ch: Id, s: number, on: boolean): Note[] {
  const has = isStepOn(notes, ch, s);
  if (on === has) return notes as Note[];
  return on ? [...notes, { ch, step: s, len: 1, trig: true }] : notes.filter(n => !onStep(n, ch, s));
}

/** Every grid cell the pointer passes going from (r0, s0) to (r1, s1), both ends included, in order. */
export function cellsBetween(r0: number, s0: number, r1: number, s1: number): [number, number][] {
  const n = Math.max(Math.abs(r1 - r0), Math.abs(s1 - s0));
  const out: [number, number][] = [];
  for (let k = 0; k <= n; k++) {
    const t = n ? k / n : 0;
    const c: [number, number] = [Math.round(r0 + (r1 - r0) * t), Math.round(s0 + (s1 - s0) * t)];
    const last = out[out.length - 1];
    if (!last || last[0] !== c[0] || last[1] !== c[1]) out.push(c);
  }
  return out;
}

/** "Fill each N steps": the channel's steps become 0, N, 2N … up to `steps` (its other notes go). */
export function fillEvery(notes: readonly Note[], ch: Id, steps: number, n: number): Note[] {
  const keep = notes.filter(x => x.ch !== ch);
  for (let s = 0; s < steps; s += n) keep.push({ ch, step: s, len: 1, trig: true });
  return keep;
}

/** Shift the channel's notes by `d` steps, wrapping around the pattern length. */
export function rotate(notes: readonly Note[], ch: Id, steps: number, d: number): Note[] {
  return notes.map(n => n.ch === ch ? { ...n, step: ((((n.step + d) % steps) + steps) % steps) } : n);
}

export const clearChannel = (notes: readonly Note[], ch: Id) => notes.filter(n => n.ch !== ch);

/** Copies of `from`'s notes for channel `to`. */
export const cloneNotes = (notes: readonly Note[], from: Id, to: Id): Note[] => [...notes, ...notes.filter(n => n.ch === from).map(n => ({ ...n, ch: to }))];

/** A channel's notes without their channel: what the Channel Rack's clipboard holds (Ctrl+C / X). */
export type ChannelClip = Omit<Note, 'ch'>[];
export const copyChannelNotes = (notes: readonly Note[], ch: Id): ChannelClip =>
  notes.filter(n => n.ch === ch).map(({ ch: _ch, ...n }) => ({ ...n })).sort((a, b) => a.step - b.step);
/**
 * Ctrl+V in the Channel Rack: the channel's notes in this pattern become the clipboard's (its
 * other notes go, every other channel keeps its own). The pattern's length follows the notes.
 * Notes that would end past the song are dropped.
 */
export function pasteChannelNotes(notes: readonly Note[], ch: Id, clip: ChannelClip): Note[] {
  return [...notes.filter(n => n.ch !== ch), ...clip.filter(n => n.step + n.len <= TOTAL_BEATS * 4 + EPS).map(n => ({ ...n, ch }))];
}

/**
 * A row with held notes or chords needs the mini piano roll. Triggers off the 16th grid (a
 * triplet written in the Piano roll) stay steps, drawn at their place inside the cell.
 * Legacy rows (no `trig` flag) keep their previous layout: off the grid, they are a roll.
 */
export function isRollRow(notes: readonly Note[], c: Channel): boolean {
  const seen = new Set<number>();
  for (const n of notes) {
    if (n.ch !== c.id) continue;
    const isStep = n.trig ?? Math.abs(n.len - 1) <= EPS;
    const onGrid = Math.abs(n.step - Math.round(n.step)) <= EPS;
    const at = Math.round(n.step * 1000);
    if (!isStep || (!onGrid && n.trig !== true) || seen.has(at)) return true;
    seen.add(at);
  }
  return false;
}

/**
 * How wide each of a step row's triggers is drawn, in steps: its whole cell, or less when the
 * row's next trigger comes sooner (a 16th triplet puts two in one cell).
 */
export function stepSpans(notes: readonly Note[]): number[] {
  const starts = notes.map(n => n.step).sort((a, b) => a - b);
  return notes.map(n => {
    // the first start after this one (binary search; starts within EPS are the same time)
    let lo = 0, hi = starts.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (starts[m] <= n.step + EPS) lo = m + 1; else hi = m; }
    return lo < starts.length ? Math.min(1, starts[lo] - n.step) : 1;
  });
}

/** Set the key of the channel's notes that start in cell [s, s+1) (`root` = no key of its own). */
export function setKeyAt(notes: readonly Note[], c: Channel, s: number, key: number): Note[] {
  const k = Math.round(Math.min(127, Math.max(0, key)));
  return notes.map(n => {
    if (n.ch !== c.id || n.step < s - EPS || n.step >= s + 1 - EPS) return n;
    const { p: _p, ...rest } = n;
    return k === c.root ? rest : { ...rest, p: k };
  });
}

/** Set the velocity of the channel's notes that start in cell [s, s+1). */
export function setVelAt(notes: readonly Note[], ch: Id, s: number, v: number): Note[] {
  const vv = Math.round(Math.min(1, Math.max(0, v)) * 100) / 100;
  return notes.map(n => n.ch === ch && n.step >= s - EPS && n.step < s + 1 - EPS ? { ...n, v: vv } : n);
}

/** The latest a step may be shifted inside its cell (FL's graph editor Shift), in steps. */
export const MAX_SHIFT = 0.9;
/** How far into its cell a note starts (0 = on the grid), in steps. */
export const shiftOf = (n: Note) => Math.max(0, n.step - Math.floor(n.step + EPS));

/** Set the pan (−1 left … 1 right) of the channel's notes that start in cell [s, s+1); centre clears it. */
export function setPanAt(notes: readonly Note[], ch: Id, s: number, pan: number): Note[] {
  const p = Math.round(Math.min(1, Math.max(-1, pan)) * 100) / 100;
  return notes.map(n => {
    if (n.ch !== ch || n.step < s - EPS || n.step >= s + 1 - EPS) return n;
    const { pan: _p, ...rest } = n;
    return Math.abs(p) < 0.03 ? rest : { ...rest, pan: p };
  });
}

/** Shift the channel's notes in cell [s, s+1) to start `shift` steps (0 … MAX_SHIFT) after the cell's start. */
export function setShiftAt(notes: readonly Note[], ch: Id, s: number, shift: number): Note[] {
  const d = Math.round(Math.min(MAX_SHIFT, Math.max(0, shift)) * 100) / 100;
  // an old step without the trigger flag becomes an explicit trigger: off the grid, a plain note
  // would turn the row into a Piano roll row (`isRollRow`)
  // the note keeps its end (a step's end is its cell's end), so shifting the last step does not
  // make the pattern a bar longer; a note that ended earlier stays inside its cell
  return notes.map(n => {
    if (n.ch !== ch || n.step < s - EPS || n.step >= s + 1 - EPS) return n;
    const start = s + d, end = n.step + n.len;
    const len = Math.round(Math.max(end - start, Math.min(n.len, s + 1 - start)) * 1000) / 1000;
    return { ...n, step: start, len, ...(d > 0 && n.trig == null ? { trig: true } : {}) };
  });
}

// ---------------------------------------------------------------- piano roll

/**
 * Piano-roll snap choices, in steps (16ths), named as fractions of a whole note. The triplet
 * grids split a straight value in three where it splits in two: 1/6 = a quarter-note triplet
 * (three in the time of two quarters), 1/12 = eighth triplet, 1/24 = 16th triplet, 1/48 = 32nd.
 */
export const ROLL_SNAPS: [string, number][] = [
  ['1/1', 16], ['1/2', 8], ['1/4', 4], ['1/8', 2], ['1/16', 1], ['1/32', 0.5], ['1/64', 0.25],
];
export const ROLL_SNAPS_TRIPLET: [string, number][] = [['1/6', 8 / 3], ['1/12', 4 / 3], ['1/24', 2 / 3], ['1/48', 1 / 3]];
/** The grid's name ('1/16', '1/12'), or undefined when `steps` is not one of the snap choices. */
export const rollSnapName = (steps: number) => [...ROLL_SNAPS, ...ROLL_SNAPS_TRIPLET].find(x => Math.abs(x[1] - steps) < 1e-4)?.[0];
/** The "auto" grid, in steps: the finest of 1/64 … 1/1 whose cell is at least 24 px wide at `pps` px a step. */
export const autoRollSnap = (pps: number) => [0.25, 0.5, 1, 2, 4, 8, 16].find(u => u * pps >= 24) ?? 16;
/** Round (or floor) `x` steps to the grid; `unit` 0 = free (1/128 resolution). */
export function snapStep(x: number, unit: number, floor = false): number {
  if (!unit) return Math.round(x * 32) / 32;
  // rounded to 1e-6: a triplet grid (2/3 step) would otherwise leave float noise in the step
  return Math.round((floor ? Math.floor(x / unit + 1e-6) : Math.round(x / unit)) * unit * 1e6) / 1e6;
}

/**
 * Moves notes `idx` by `dStep` steps and `dKey` semitones from their `orig` positions. The move
 * itself is snapped, in whole grid units (FL): a note off the grid keeps its offset, so a drag
 * straight up or down never shifts its timing. Clamped at 0; keys stay within 0..127.
 */
export function moveNotes(orig: readonly Note[], idx: readonly number[], dStep: number, dKey: number, unit: number, chan: Channel | undefined): Note[] {
  const sel = idx.map(i => orig[i]);
  const first = Math.min(...sel.map(n => n.step));
  let d = snapStep(dStep, unit);
  d = Math.max(d, -first);
  const keys = sel.map(n => keyOf(n, chan));
  const dk = Math.max(-Math.min(...keys), Math.min(127 - Math.max(...keys), dKey));
  const out = orig.slice();
  for (const i of idx) { const n = orig[i]; out[i] = { ...n, step: n.step + d, p: keyOf(n, chan) + dk }; }
  return out;
}

/** Resizes notes `idx` by `dLen` steps (end snapped to the grid); never shorter than one grid unit (1/32 free). */
export function resizeNotes(orig: readonly Note[], idx: readonly number[], dLen: number, unit: number): Note[] {
  const out = orig.slice();
  const min = unit || 0.25;
  for (const i of idx) {
    const n = orig[i];
    const end = snapStep(n.step + (n.trig ? 0 : n.len) + dLen, unit);
    out[i] = { ...n, len: Math.max(min, end - n.step), trig: false };
  }
  return out;
}

/**
 * Ctrl+B: copies of the selection right after it. The offset is the selection's extent
 * rounded up to whole beats (4 steps), so a one-bar phrase repeats on the next bar.
 * Returns the notes and the indices of the copies (the new selection).
 */
export function duplicateRight(notes: readonly Note[], idx: readonly number[]): { notes: Note[]; idx: number[] } {
  if (!idx.length) return { notes: notes as Note[], idx: [] };
  const sel = idx.map(i => notes[i]);
  const a = Math.min(...sel.map(n => n.step)), b = Math.max(...sel.map(n => n.step + n.len));
  const span = Math.max(4, Math.ceil((b - a) / 4 - 1e-9) * 4);
  const copies = sel.map(n => ({ ...n, step: n.step + span }));
  return { notes: [...notes, ...copies], idx: copies.map((_, k) => notes.length + k) };
}

/** Transpose notes `idx` by `semis` (blocked at 0..127 as a group). */
export function transpose(notes: readonly Note[], idx: readonly number[], semis: number, chan: Channel | undefined): Note[] {
  if (!idx.length) return notes as Note[];
  const keys = idx.map(i => keyOf(notes[i], chan));
  const d = Math.max(-Math.min(...keys), Math.min(127 - Math.max(...keys), semis));
  const out = notes.slice();
  for (const i of idx) out[i] = { ...notes[i], p: keyOf(notes[i], chan) + d };
  return out;
}

/** Width of a note in the Piano Roll, including a grab area for a zero-length trigger. */
export const noteWidth = (n: Note, pps: number) => n.trig ? 7 : Math.max(3, n.len * pps - 1);

/** Index of the channel's note under (step, key), the topmost (latest) first. */
export function noteAt(notes: readonly Note[], ch: Id, chan: Channel | undefined, step: number, key: number, pps?: number): number {
  for (let i = notes.length - 1; i >= 0; i--) {
    const n = notes[i];
    const width = pps ? noteWidth(n, pps) / pps : n.len;
    if (n.ch === ch && keyOf(n, chan) === key && step >= n.step - EPS && step < n.step + width) return i;
  }
  return -1;
}

/** Scale masks (bit k = k semitones above the root) keyed by the engine's scale id — the
 * same id space as pitch::scale_mask, the Pitch Correct panel and setKey ops. */
export const SCALES: [TranslationKey, number, number][] = [
  ['b.sc.major', 1, 0b101010110101],
  ['b.sc.minor', 2, 0b010110101101],
  ['b.sc.pentatonicMaj', 3, 0b001010010101],
  ['b.sc.pentatonicMin', 4, 0b010010101001],
  ['b.sc.chromatic', 0, 0xfff],
];
/** Mask for an engine scale id (0 = chromatic, 1 = major, 2 = natural minor, 3/4 = pentatonics). */
export const scaleMask = (id: number): number => SCALES.find(s => s[1] === id)?.[2] ?? 0xfff;
/** "3 bars" in the current language. */
export const barsText = (n: number): string => t(n === 1 ? 'b.pat.bar1' : n < 5 ? 'b.pat.bar2' : 'b.pat.bar5', { n });
/** "3 notes" in the current language. */
export const notesText = (n: number): string => t(n === 1 ? 'b.pat.note1' : 'b.pat.noteN', { n });
export const inScale = (key: number, root: number, mask: number) => (mask & (1 << ((((key - root) % 12) + 12) % 12))) !== 0;
