import { describe, expect, it } from 'vitest';
import { samplerDefault, TOTAL_BEATS, type Channel, type Note, type Pattern, type Project, type SamplerState } from '../api/types';
import { applyAll } from './applyOps';
import {
  followChanges, migrateSamplerEnvelope,
  BEAT_GAP, burnChannelLoop, cellStep, channelStepsOf, cellsBetween, fitCw, fitLen, gridW, stepAt, stepX, contentLen, duplicateRight, fillEvery, isRollRow, isStepOn, migrateProject, moveNotes, noteAt, resizeNotes,
  rotate, samplerError, setChannelLoop, setKeyAt, setPanAt, setShiftAt, shiftOf, MAX_SHIFT, setStep, setVelAt, snapStep, stepSpans, swingOffset, transpose,
} from './pattern';

const KICK = 1000, BASS = 1003;
const bass: Channel = { id: BASS, name: 'Bass', color: '#7c8cf8', kind: 'sample', source: 1, sampler: samplerDefault(), vol: 0.7937, pan: 0, mute: false, solo: false, insert: null, root: 36 };
const steps = (notes: Note[], ch: number) => notes.filter(n => n.ch === ch).map(n => n.step).sort((a, b) => a - b);

describe('step sequencer', () => {
  it('keeps a trigger when copied and converts it only when resized', () => {
    const [step] = setStep([], KICK, 4, true);
    const duplicate = duplicateRight([step], [0]);
    expect(duplicate.notes[1]).toMatchObject({ step: 8, len: 1, trig: true });
    expect(resizeNotes([step], [0], 1, 1)[0]).toMatchObject({ step: 4, len: 1, trig: false });
    expect(step.trig).toBe(true);
  });
  it('toggles steps without duplicates', () => {
    let n: Note[] = [];
    n = setStep(n, KICK, 4, true);
    n = setStep(n, KICK, 4, true);
    expect(n).toEqual([{ ch: KICK, step: 4, len: 1, trig: true }]);
    expect(isStepOn(n, KICK, 4)).toBe(true);
    n = setStep(n, KICK, 4, false);
    expect(n).toEqual([]);
  });
  it('paint-drag visits every cell between pointer samples, in order', () => {
    expect(cellsBetween(0, 2, 0, 6)).toEqual([[0, 2], [0, 3], [0, 4], [0, 5], [0, 6]]);
    expect(cellsBetween(0, 6, 0, 3)).toEqual([[0, 6], [0, 5], [0, 4], [0, 3]]);
    expect(cellsBetween(1, 1, 1, 1)).toEqual([[1, 1]]);
    // diagonal across rows: no cell skipped on the longer axis
    const d = cellsBetween(0, 0, 2, 8);
    expect(d.length).toBe(9);
    expect(d[0]).toEqual([0, 0]); expect(d[8]).toEqual([2, 8]);
    // a drag painting "on" from the first cell's opposite state
    let n: Note[] = [{ ch: KICK, step: 3, len: 1 }];
    for (const [, s] of cellsBetween(0, 0, 0, 5)) n = setStep(n, KICK, s, true);
    expect(steps(n, KICK)).toEqual([0, 1, 2, 3, 4, 5]);
  });
  it('fills every N steps, replacing the channel and keeping the others', () => {
    const n: Note[] = [{ ch: KICK, step: 3, len: 1 }, { ch: BASS, step: 0, len: 4, p: 36 }, { ch: KICK, step: 20, len: 1 }];
    const f = fillEvery(n, KICK, 16, 4);
    expect(steps(f, KICK)).toEqual([0, 4, 8, 12]);
    expect(f.filter(x => x.ch === BASS)).toHaveLength(1);
    expect(steps(fillEvery([], KICK, 32, 8), KICK)).toEqual([0, 8, 16, 24]);
  });
  it('rotates with wrap-around', () => {
    const n: Note[] = [{ ch: KICK, step: 0, len: 1 }, { ch: KICK, step: 15, len: 1 }, { ch: BASS, step: 15, len: 1 }];
    expect(steps(rotate(n, KICK, 16, 1), KICK)).toEqual([0, 1]);
    expect(steps(rotate(n, KICK, 16, -1), KICK)).toEqual([14, 15]);
    expect(rotate(n, KICK, 16, 1).find(x => x.ch === BASS)!.step).toBe(15);
  });
  it('sets velocity per cell and tells plain steps from melodic rows', () => {
    const n = setVelAt([{ ch: KICK, step: 2, len: 1 }, { ch: KICK, step: 3, len: 1 }], KICK, 2, 0.456);
    expect(n.map(x => x.v)).toEqual([0.46, undefined]);
    expect(isRollRow([{ ch: BASS, step: 0, len: 1 }], bass)).toBe(false);
    expect(isRollRow([{ ch: BASS, step: 0, len: 1, trig: true }], bass)).toBe(false);
    expect(isRollRow([{ ch: BASS, step: 0, len: 1, trig: false }], bass)).toBe(true);
    expect(isRollRow([{ ch: BASS, step: 0, len: 1, p: 36 }], bass)).toBe(false);
    expect(isRollRow([{ ch: BASS, step: 0, len: 3, p: 36 }], bass)).toBe(true);
    // a step with its own key (graph editor) is still a step; a chord or an off-grid note is not
    expect(isRollRow([{ ch: BASS, step: 0, len: 1, p: 40 }], bass)).toBe(false);
    expect(isRollRow([{ ch: BASS, step: 0, len: 1, p: 40 }, { ch: BASS, step: 0, len: 1, p: 43 }], bass)).toBe(true);
    expect(isRollRow([{ ch: BASS, step: 0.5, len: 1 }], bass)).toBe(true);
  });
  it('the graph editor pans and shifts a step; a shifted step stays a step', () => {
    const row: Note[] = [{ ch: KICK, step: 2, len: 1, trig: true }, { ch: KICK, step: 3, len: 1 }, { ch: BASS, step: 2, len: 1, trig: true }];
    const panned = setPanAt(row, KICK, 2, -0.5);
    expect(panned.map(x => x.pan)).toEqual([-0.5, undefined, undefined]);
    expect('pan' in setPanAt(panned, KICK, 2, 0.01)[0]).toBe(false); // centre clears it
    const shifted = setShiftAt(setShiftAt(row, KICK, 2, 0.25), KICK, 3, 5);
    expect(shifted.map(x => x.step)).toEqual([2.25, 3 + MAX_SHIFT, 2]);
    expect(shiftOf(shifted[0])).toBeCloseTo(0.25);
    expect(shifted[1].trig).toBe(true); // an old unflagged step becomes a trigger
    expect(isRollRow(shifted, { ...bass, id: KICK })).toBe(false);
    // shifting again or back works from the cell, not from where the note sits now
    expect(setShiftAt(shifted, KICK, 2, 0)[0].step).toBe(2);
    expect(setShiftAt(shifted, KICK, 3, 0.5)[1].step).toBe(3.5);
  });
  it('a shifted step keeps its end, so shifting the last step does not lengthen the pattern', () => {
    const last: Note[] = [{ ch: KICK, step: 15, len: 1, trig: true }];
    const shifted = setShiftAt(last, KICK, 15, 0.5);
    expect(shifted[0]).toMatchObject({ step: 15.5, len: 0.5 });
    expect(contentLen(shifted)).toBe(4);
    // and back to the grid: the full step again
    expect(setShiftAt(shifted, KICK, 15, 0)[0]).toMatchObject({ step: 15, len: 1 });
    // a note shorter than its cell stays inside it
    const short = setShiftAt([{ ch: KICK, step: 15, len: 0.25, trig: true }], KICK, 15, MAX_SHIFT)[0];
    expect(short.step + short.len).toBeLessThanOrEqual(16 + 1e-9);
  });
  it('keeps a step row with triplet triggers written in the Piano roll as steps', () => {
    const trip = [12, 12 + 2 / 3, 12 + 4 / 3].map(step => ({ ch: BASS, step, len: 2 / 3, trig: true }));
    const row = [{ ch: BASS, step: 0, len: 1, trig: true }, ...trip];
    expect(isRollRow(row, bass)).toBe(false);
    // two triggers at the same time are a chord: the roll
    expect(isRollRow([...row, { ch: BASS, step: 12, len: 1, trig: true }], bass)).toBe(true);
    // a held note among them still makes it a melody
    expect(isRollRow([...row, { ch: BASS, step: 4, len: 1, trig: false }], bass)).toBe(true);
    // drawn widths: a full cell, or the gap to the next trigger
    expect(stepSpans(row).map(x => +x.toFixed(3))).toEqual([1, 0.667, 0.667, 1]);
    // a click on a cell with off-grid triggers clears them; another click sets the step again
    expect(isStepOn(row, BASS, 13)).toBe(true);
    const cleared = setStep(row, BASS, 13, false);
    expect(cleared.map(n => +n.step.toFixed(3))).toEqual([0, 12, 12.667]);
    expect(setStep(cleared, BASS, 13, true).at(-1)).toEqual({ ch: BASS, step: 13, len: 1, trig: true });
  });
  it('sets a step key from the graph editor (the root clears it)', () => {
    const n: Note[] = [{ ch: BASS, step: 2, len: 1 }, { ch: BASS, step: 3, len: 1, p: 40 }];
    expect(setKeyAt(n, bass, 2, 43)[0]).toEqual({ ch: BASS, step: 2, len: 1, p: 43 });
    expect(setKeyAt(n, bass, 3, bass.root)[1]).toEqual({ ch: BASS, step: 3, len: 1 });
    expect(setKeyAt(n, bass, 3, 200)[1].p).toBe(127);
  });
  it('a pattern is as long as its notes: the last end rounded up to a bar, at least one', () => {
    expect(contentLen([])).toBe(4);
    expect(contentLen([{ ch: KICK, step: 15, len: 1 }])).toBe(4);
    expect(contentLen([{ ch: KICK, step: 15, len: 1.5 }])).toBe(8);
    expect(contentLen([{ ch: KICK, step: 40, len: 4 }])).toBe(12);
  });
  it('swing moves only odd 16ths, half a step at 100 %', () => {
    expect([0, 1, 2, 3, 4, 5].map(s => swingOffset(s, 1))).toEqual([0, 0.5, 0, 0.5, 0, 0.5]);
    expect(swingOffset(3, 0.5)).toBe(0.25);
    expect(swingOffset(3.25, 1)).toBe(0);
  });
});

describe('step grid geometry (beat gaps)', () => {
  it('puts a gap before every fourth step and none before the first', () => {
    expect(stepX(0, 20)).toBe(0);
    expect(stepX(3, 20)).toBe(60);
    expect(stepX(4, 20)).toBe(80 + BEAT_GAP);
    expect(stepX(16, 20)).toBe(320 + 4 * BEAT_GAP);
  });
  it('maps every pixel of a cell back to its step, a gap to the step on its left', () => {
    for (let s = 0; s < 40; s++) {
      expect(stepAt(stepX(s, 17), 17)).toBe(s);
      expect(stepAt(stepX(s, 17) + 16.9, 17)).toBe(s);
    }
    expect(stepAt(4 * 17 + BEAT_GAP - 1, 17)).toBe(3);
    expect(stepAt(-1, 17)).toBeLessThan(0);
  });
  it('measures the grid without a trailing gap and fits cells into a width', () => {
    expect(gridW(16, 20)).toBe(320 + 3 * BEAT_GAP);
    expect(gridW(17, 20)).toBe(340 + 4 * BEAT_GAP);
    const cw = fitCw(500, 32);
    expect(gridW(32, cw)).toBeLessThanOrEqual(500);
    expect(gridW(32, cw + 1)).toBeGreaterThan(500);
  });
});

describe('piano roll math', () => {
  const line: Note[] = [{ ch: BASS, step: 0, len: 3, p: 33 }, { ch: BASS, step: 4, len: 2, p: 40 }, { ch: KICK, step: 0, len: 1 }];
  it('snaps to the grid (floor for new notes, free with unit 0)', () => {
    expect(snapStep(5.4, 1)).toBe(5);
    expect(snapStep(5.6, 2)).toBe(6);
    expect(snapStep(7.9, 4, true)).toBe(4);
    expect(snapStep(3.3, 0)).toBeCloseTo(3.3125);
  });
  it('moves a selection keeping relative positions, snapped and clamped', () => {
    const m = moveNotes(line, [0, 1], 2.4, 3, 1, bass);
    expect(m[0]).toMatchObject({ step: 2, p: 36 }); expect(m[1]).toMatchObject({ step: 6, p: 43 });
    expect(m[2]).toBe(line[2]);
    expect(moveNotes(line, [1], -10, 0, 1, bass)[1].step).toBe(0);
    expect(moveNotes(line, [0], 0, 200, 1, bass)[0].p).toBe(127);
    // free (Alt): no rounding
    expect(moveNotes(line, [1], 0.3, 0, 0, bass)[1].step).toBeCloseTo(4.3125);
  });
  it('resizes with a snapped end and a minimum of one grid unit', () => {
    expect(resizeNotes(line, [0], 1.6, 1)[0].len).toBe(5);
    expect(resizeNotes(line, [0], -10, 2)[0].len).toBe(2);
    expect(resizeNotes(line, [0], -10, 0)[0].len).toBe(0.25);
    expect(resizeNotes(line, [0, 1], 2, 2).slice(0, 2).map(n => n.len)).toEqual([6, 4]);
  });
  it('duplicates the selection right after it, rounded up to beats', () => {
    const d = duplicateRight(line, [0, 1]);
    expect(d.idx).toEqual([3, 4]);
    expect(d.notes.slice(3).map(n => n.step)).toEqual([8, 12]);
    const one = duplicateRight(line, [0]);
    expect(one.notes[3].step).toBe(4);
    expect(duplicateRight(line, []).notes).toBe(line);
  });
  it('transposes as a group within 0..127 and finds notes under the pointer', () => {
    expect(transpose(line, [0, 1], 12, bass).slice(0, 2).map(n => n.p)).toEqual([45, 52]);
    expect(transpose(line, [0, 1], 100, bass).slice(0, 2).map(n => n.p)).toEqual([120, 127]);
    expect(noteAt(line, BASS, bass, 1.5, 33)).toBe(0);
    expect(noteAt(line, BASS, bass, 3.5, 33)).toBe(-1);
    expect(noteAt(line, BASS, bass, 5, 40)).toBe(1);
  });
});

describe('mock engine ops (mirror of ops.rs)', () => {
  const base = (): Project => {
    const p: Project = { version: 2, bpm: 128, tracks: [{ id: 1, name: 'T', color: '#fff', muted: false, solo: false, arm: false, vol: 0.79, h: 56, insert: 1 }],
      inserts: [{ id: 0, name: 'M', color: '#fff', vol: 0.79, pan: 0, muted: false, solo: false, fx: [] }, { id: 1, name: 'I', color: '#fff', vol: 0.79, pan: 0, muted: false, solo: false, fx: [] }],
      patterns: [], sources: [], clips: [], loop: null, nextId: 1000 };
    migrateProject(p);
    return p;
  };
  // the starter kit: a source and its sampler channel per file, ids in that order (model.rs `add_starter_kit`)
  const K = 1001, C = 1003;
  it('transformNotes keeps keys in 0..127 and refuses a result outside it, like the engine', () => {
    let p = base();
    p = applyAll(p, [{ op: 'putPattern', pattern: { id: 5, name: 'x', color: '#fff', len: 4, notes: [{ ch: K, step: 0, len: 1, p: 127 }] } }, { op: 'setKey', key: 1, scale: 3 }]);
    // C# major pentatonic: 127 would snap up to 128; the in-range answer is 125
    p = applyAll(p, [{ op: 'transformNotes', pattern: 5, verb: { kind: 'quantize', grid: 1, amount: 1, scaleAware: true } }]);
    expect(p.patterns[0].notes[0].p).toBe(125);
    // a note whose key is already out of range (not reachable through putPattern) fails the op
    const bad = structuredClone(p);
    bad.patterns[0].notes[0].p = 128;
    expect(() => applyAll(bad, [{ op: 'transformNotes', pattern: 5, verb: { kind: 'humanize', timing: 0, velocity: 0 } }])).toThrow(/0\.\.127/);
  });

  it('gives a project without channels the starter kit and refuses notes of unknown channels', () => {
    const p = base();
    expect(p.channels!.map(c => c.name)).toEqual(['Kick', 'Clap', 'Hat', 'Snare']);
    expect(p.channels!.map(c => c.id).slice(0, 2)).toEqual([K, C]);
    expect(p.channels!.every(c => c.kind === 'sample' && p.sources.some(s => s.id === c.source && s.path.startsWith('lib:Standard/')))).toBe(true);
    expect(p.nextId).toBe(1008);
    const again = structuredClone(p); migrateProject(again);
    expect(again).toEqual(p);
    expect(() => applyAll(p, [{ op: 'putPattern', pattern: { id: 5, name: 'x', color: '#fff', len: 4, notes: [{ ch: 77, step: 0, len: 1 }] } }])).toThrow();
  });
  it('opens samplers from before the envelope switch like the engine', () => {
    const old = (patch: object) => { const s = { ...samplerDefault(), ...patch } as SamplerState & { gate?: boolean }; delete (s as Partial<SamplerState>).env; migrateSamplerEnvelope(s); return s; };
    // gated, or one-shot with a shape it always played: on; an untouched one-shot: off
    expect(old({ gate: true }).env).toBe(true);
    expect(old({ gate: false, attack: 30 }).env).toBe(true);
    expect(old({ decay: 100, sustain: 0.2 }).env).toBe(true);
    expect(old({ gate: false, decay: 100 })).toEqual({ ...samplerDefault(), decay: 100 });
    // a sampler that has the switch keeps it, and the new stages get their defaults
    const now = { ...samplerDefault(), attack: 30 } as Partial<SamplerState>;
    delete now.hold; migrateSamplerEnvelope(now as SamplerState);
    expect(now).toEqual({ ...samplerDefault(), attack: 30 });
  });
  it('checks sampler settings like the engine', () => {
    const p = base(), kick = p.channels![0];
    const put = (patch: Partial<ReturnType<typeof samplerDefault>>) => applyAll(p, [{ op: 'putChannel', channel: { ...kick, sampler: { ...samplerDefault(), ...patch } } as Channel }]);
    expect(samplerError(samplerDefault())).toBeNull();
    const ok = put({ start: 0.25, end: 0.75, reverse: true, semi: -12, fine: 50, env: true, delay: 10, attack: 5, hold: 30, decay: 200, sustain: 0.5, release: 300, attackTension: 0.5, decayTension: -1, releaseTension: 1, cut: 8 });
    expect(ok.channels![0]).toMatchObject({ kind: 'sample', sampler: { start: 0.25, cut: 8 } });
    for (const bad of [{ start: 0.5, end: 0.5 }, { end: 1.2 }, { start: NaN }, { semi: 25 }, { semi: 1.5 }, { fine: -101 }, { attack: -1 }, { decay: 5001 }, { sustain: 1.1 }, { release: 0 }, { delay: 5001 }, { hold: -1 }, { attackTension: 1.01 }, { releaseTension: NaN }, { cut: 9 }, { cut: -1 }])
      expect(() => put(bad), JSON.stringify(bad)).toThrow();
    // a sampler needs its source
    expect(() => applyAll(p, [{ op: 'putChannel', channel: { ...kick, source: 4242 } as Channel }])).toThrow();
    // removing the source removes its sampler channels
    const src = kick.kind === 'sample' ? kick.source : -1;
    expect(applyAll(p, [{ op: 'removeSource', id: src }]).channels!.map(c => c.name)).toEqual(['Clap', 'Hat', 'Snare']);
  });
  it('length follows the notes and minLen; whole-pattern clips follow it; removing a channel removes its notes', () => {
    let p = base();
    p = applyAll(p, [{ op: 'putPattern', pattern: { id: 5, name: 'x', color: '#fff', len: 99, notes: [{ ch: K, step: 0, len: 1 }, { ch: C, step: 4, len: 1 }] } },
      { op: 'putClips', clips: [
        { id: 1, track: 0, start: 0, len: 4, offset: 0, kind: 'pat', ref: 5, muted: false, gain: 0, fadeIn: 0, fadeOut: 0, pan: 0, norm: false, rev: false },
        { id: 2, track: 0, start: 8, len: 16, offset: 0, kind: 'pat', ref: 5, muted: false, gain: 0, fadeIn: 0, fadeOut: 0, pan: 0, norm: false, rev: false }] }]);
    expect([p.patterns[0].len, p.patterns[0].minLen]).toEqual([4, 4]); // a sent len is ignored
    // a note in bar 2 grows it; the clip that shows one whole pass follows
    p = applyAll(p, [{ op: 'putPattern', pattern: { ...p.patterns[0], notes: [...p.patterns[0].notes, { ch: K, step: 20, len: 1 }] } }]);
    expect(p.patterns[0].len).toBe(8);
    expect(p.clips.map(c => c.len)).toEqual([8, 16]);
    // removed again: back to one bar — unless an empty bar is kept on purpose (minLen)
    const two = { ...p.patterns[0], notes: p.patterns[0].notes.slice(0, 2) };
    expect(applyAll(p, [{ op: 'putPattern', pattern: two }]).patterns[0].len).toBe(4);
    p = applyAll(p, [{ op: 'putPattern', pattern: { ...two, minLen: 8 } }]);
    expect([p.patterns[0].len, p.clips[0].len]).toEqual([8, 8]);
    expect(() => applyAll(p, [{ op: 'putPattern', pattern: { ...two, notes: [{ ch: K, step: TOTAL_BEATS * 4 - 1, len: 2 }] } }])).toThrow();
    // removePattern takes its clips with it
    expect(applyAll(p, [{ op: 'removePattern', id: 5 }]).clips).toEqual([]);
    p = applyAll(p, [{ op: 'removeChannel', id: K }]);
    expect(p.patterns[0].notes).toEqual([{ ch: C, step: 4, len: 1 }]);
    expect(p.channels!.some(c => c.id === K)).toBe(false);
  });
});

describe('pattern clips follow the pattern without overlapping (#245)', () => {
  const pc = (id: number, track: number, start: number, len: number, offset = 0) =>
    ({ id, track, start, len, offset, kind: 'pat' as const, ref: 5, muted: false, gain: 0, fadeIn: 0, fadeOut: 0, pan: 0, norm: false, rev: false });
  const K = 1001; // the starter kit's kick
  const grow = (p: Project, notes: Note[]) => applyAll(p, [{ op: 'putPattern', pattern: { ...p.patterns[0], notes } }]);
  const start = (): Project => {
    const p: Project = { version: 2, bpm: 128, tracks: [1, 2, 3, 4].map(id => ({ id, name: 'T' + id, color: '#fff', muted: false, solo: false, arm: false, vol: 0.79, h: 56, insert: 0 })),
      inserts: [{ id: 0, name: 'M', color: '#fff', vol: 0.79, pan: 0, muted: false, solo: false, fx: [] }],
      patterns: [], sources: [], clips: [], loop: null, nextId: 1000 };
    migrateProject(p);
    return applyAll(p, [{ op: 'putPattern', pattern: { id: 5, name: 'Beat', color: '#fff', len: 4, notes: [{ ch: K, step: 0, len: 1 }] } },
      { op: 'putClips', clips: [pc(1, 0, 0, 4), pc(2, 0, 6, 4), pc(3, 1, 0, 4), pc(4, 1, 2, 2), pc(5, 2, 0, 16), pc(6, 3, 0, 2, 2)] }]);
  };
  it('grows whole-pass clips up to the next clip on their track, and reports which stopped', () => {
    const p0 = start();
    const before = new Map(p0.clips.map(c => [c.id, c.len]));
    const p = grow(p0, [{ ch: K, step: 0, len: 1 }, { ch: K, step: 16, len: 1 }]);
    expect(p.patterns[0].len).toBe(8);
    expect(p.clips.map(c => [c.id, c.len])).toEqual([[1, 6], [2, 8], [3, 4], [4, 2], [5, 16], [6, 2]]);
    expect(followChanges(new Map([[5, 4]]), before, p)).toEqual([{ pattern: 5, len: 8, followed: [2], stopped: [1] }]);
    // nothing changed: no report
    expect(followChanges(new Map([[5, 8]]), new Map(p.clips.map(c => [c.id, c.len])), p)).toEqual([]);
  });
  it('shrinking cuts back clips within the old pattern, never an older loop', () => {
    const p = grow(start(), [{ ch: K, step: 0, len: 1 }, { ch: K, step: 16, len: 1 }]);
    const back = grow(p, [{ ch: K, step: 0, len: 1 }]);
    expect(back.clips.map(c => [c.id, c.len])).toEqual([[1, 4], [2, 4], [3, 4], [4, 2], [5, 16], [6, 2]]);
  });
});

describe('triplet snap grids', () => {
  it('snaps to thirds of a beat without float noise', async () => {
    const { snapStep, rollSnapName, ROLL_SNAPS_TRIPLET } = await import('./pattern');
    const u = ROLL_SNAPS_TRIPLET.find(x => x[0] === '1/24')![1]; // 16th triplet = 2/3 step
    expect(snapStep(1.9, u)).toBe(2);
    expect(snapStep(2.6, u)).toBe(2.666667);
    expect(snapStep(1.3, u, true)).toBe(0.666667);
    expect(rollSnapName(4 / 3)).toBe('1/12');
    expect(rollSnapName(Math.fround(8 / 3))).toBe('1/6'); // as the engine (f32) returns it
    expect(rollSnapName(3)).toBeUndefined();
  });
});

describe('autoRollSnap', () => {
  it('picks the finest grid whose cell is at least 24 px wide', async () => {
    const { autoRollSnap } = await import('./pattern');
    expect(autoRollSnap(46)).toBe(1);
    expect(autoRollSnap(48)).toBe(0.5);
    expect(autoRollSnap(100)).toBe(0.25);
    expect(autoRollSnap(6)).toBe(4);
    expect(autoRollSnap(0.5)).toBe(16);
  });
});

describe('channel loops (FL 20.1 channel looping)', () => {
  const mkPt = (notes: Note[], loops?: Record<string, number>, len = 4) =>
    ({ id: 2, name: 'P', color: '#fff', len, minLen: 4, notes, channelLoops: loops } as Pattern);
  const hat = (step: number, v = 1): Note => ({ ch: BASS, step, len: 1, trig: true, ...(v === 1 ? {} : { v }) });

  it('setChannelLoop keeps the cell and trims the rest; clear keeps the cell', () => {
    const p1 = setChannelLoop(mkPt([hat(0), hat(1), hat(5)]), BASS, 3);
    expect(steps(p1.notes, BASS)).toEqual([0, 1]);
    expect(p1.channelLoops).toEqual({ [String(BASS)]: 3 });
    const p2 = setChannelLoop(p1, BASS, 0);
    expect(steps(p2.notes, BASS)).toEqual([0, 1]);
    expect(p2.channelLoops).toBeUndefined();
    // setting on a channel with no notes is fine (an empty cell loops as silence)
    const p3 = setChannelLoop(mkPt([]), BASS, 4);
    expect(p3.channelLoops).toEqual({ [String(BASS)]: 4 });
  });

  it('setChannelLoop raises minLen only when the trim would shorten the pattern', () => {
    // another channel's late note holds the length: setting a loop on BASS trims nothing
    // that matters, so minLen stays the user's — and a later deletion of that late note
    // shrinks the pattern again
    const other: Note = { ch: 999, step: 24, len: 1, trig: false };
    const p1 = setChannelLoop({ ...mkPt([hat(0), other]), len: 8 }, BASS, 3);
    expect(steps(p1.notes, BASS)).toEqual([0]);
    expect(p1.minLen).toBe(4);
    expect(fitLen(structuredClone(p1)).len).toBe(8);
    const later = { ...p1, notes: p1.notes.filter(n => n.ch !== 999) };
    expect(fitLen(structuredClone(later)).len).toBe(4);
    // a trim that WOULD shorten holds the length the pattern had as the minimum
    const p3 = setChannelLoop({ ...mkPt([hat(0), hat(24)]), len: 8 }, BASS, 3);
    expect(p3.minLen).toBe(8);
    expect(fitLen(structuredClone(p3)).len).toBe(8);
  });

  it('burnChannelLoop writes every repeat as a real step and removes the loop', () => {
    const p1 = setChannelLoop(mkPt([hat(0), hat(1)]), BASS, 3);
    const burned = burnChannelLoop(p1, BASS);
    expect(steps(burned.notes, BASS)).toEqual([0, 1, 3, 4, 6, 7, 9, 10, 12, 13, 15]);
    expect(burned.channelLoops).toBeUndefined();
    // a repeat that would ring past the pattern end is capped there: burning must never
    // grow the pattern (fit_len counts note ends) or re-target its clips
    const held: Note = { ch: BASS, step: 2, len: 3, trig: false };
    const b3 = burnChannelLoop(setChannelLoop({ ...mkPt([held]), len: 4 }, BASS, 3), BASS);
    const last = b3.notes.filter(n => n.ch === BASS).sort((a, b) => a.step - b.step).at(-1)!;
    expect(last.step).toBe(14);
    expect(last.len).toBe(2);
    // a pattern still carrying notes past the loop (a script could): they never played, they go
    const p2 = { ...mkPt([hat(0), hat(7)]), channelLoops: { [String(BASS)]: 3 } };
    const b2 = burnChannelLoop(p2, BASS);
    expect(steps(b2.notes, BASS)).toEqual([0, 3, 6, 9, 12, 15]);
  });

  it('Fill and Shift work inside the loop cell when the channel has one', () => {
    const pt = mkPt([hat(0)], { [String(BASS)]: 3 }, 4); // 16-step pattern, 3-step loop
    const span = channelStepsOf(pt, BASS);
    expect(span).toBe(3);
    const filled = fillEvery(pt.notes, BASS, span, 2);
    expect(filled.every(n => n.ch !== BASS || n.step < 3)).toBe(true);
    const rotated = rotate(filled, BASS, span, 1);
    expect(rotated.every(n => n.ch !== BASS || n.step < 3)).toBe(true);
  });

  it('cellStep wraps the playhead into the cell', () => {
    const p = mkPt([], { [String(BASS)]: 3 });
    expect(cellStep(p, BASS, 0)).toBe(0);
    expect(cellStep(p, BASS, 4)).toBe(1);
    expect(cellStep(p, BASS, 3)).toBe(0);
    expect(cellStep(p, BASS, 7)).toBe(1);
    // an unlooped channel passes the step through
    expect(cellStep(mkPt([]), BASS, 7)).toBe(7);
  });

  it('putPattern validates loops like the engine', () => {
    const mk = () => ({ channels: [bass], patterns: [], clips: [], inserts: [], tracks: [], sources: [], nextId: 5 } as unknown as Project);
    // a loop longer than the pattern refuses
    expect(() => applyAll(mk(), [{ op: 'putPattern', pattern: { id: 1, name: 'P', color: '#fff', len: 4, notes: [], channelLoops: { [String(BASS)]: 20 } } }]))
      .toThrow('a channel loop must be 1..=16 steps');
    // an unknown channel refuses
    expect(() => applyAll(mk(), [{ op: 'putPattern', pattern: { id: 1, name: 'P', color: '#fff', len: 4, notes: [], channelLoops: { '999': 3 } } }]))
      .toThrow('no channel with id 999');
    // a valid loop is stored; an empty map is dropped
    let out = applyAll(mk(), [{ op: 'putPattern', pattern: { id: 1, name: 'P', color: '#fff', len: 4, notes: [], channelLoops: {} } }]);
    expect(out.patterns.find(x => x.id === 1)!.channelLoops).toBeUndefined();
    out = applyAll(mk(), [{ op: 'putPattern', pattern: { id: 1, name: 'P', color: '#fff', len: 4, notes: [hat(0)], channelLoops: { [String(BASS)]: 3 } } }]);
    expect(out.patterns.find(x => x.id === 1)!.channelLoops).toEqual({ [String(BASS)]: 3 });
    // the repeats' total stays bounded (the engine checks the sum across entries)
    const many: Note[] = [];
    for (let i = 0; i < 200; i++) many.push(hat(i % 4));
    expect(() => applyAll(mk(), [{ op: 'putPattern', pattern: { id: 1, name: 'P', color: '#fff', len: 2048, minLen: 2048, notes: many, channelLoops: { [String(BASS)]: 4 } } }]))
      .toThrow('may not repeat into more than 65536 notes');
  });

  it('removeChannel removes its loop entries', () => {
    const p = { channels: [bass], patterns: [{ id: 1, name: 'P', color: '#fff', len: 4, notes: [], channelLoops: { [String(BASS)]: 3 } }], clips: [], inserts: [], tracks: [], sources: [], nextId: 5 } as unknown as Project;
    const out = applyAll(p, [{ op: 'removeChannel', id: BASS }]);
    expect(out.patterns[0].channelLoops).toBeUndefined();
  });
});
