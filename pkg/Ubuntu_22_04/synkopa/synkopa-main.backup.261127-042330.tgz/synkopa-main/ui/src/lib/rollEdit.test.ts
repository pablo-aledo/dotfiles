import { describe, expect, it } from 'vitest';
import type { Channel, Note } from '../api/types';
import {
  applyProps, fitRange, fmtLen, fmtStart, followPage, invertSelection, legato, MAX_STEP, notesOfKey, nudgeNotes, nudgeVelocity, pasteStart,
  parseKey, parseLen, parseStart, panLine, quantizeStarts, readProps, velocityLine, wheelNotches,
} from './rollEdit';

const CH = { id: 1, root: 60 } as Channel;
const N: Note[] = [
  { ch: 1, step: 0.3, len: 2, p: 60 },
  { ch: 1, step: 3.6, len: 1, p: 64, v: 0.5 },
  { ch: 2, step: 5.2, len: 4, p: 67 },
  { ch: 1, step: 8, len: 3 },
];

describe('quantizeStarts', () => {
  it('rounds starts to the unit, keeps lengths, leaves other notes alone', () => {
    const r = quantizeStarts(N, [0, 1, 3], 1);
    expect(r.notes.map(n => n.step)).toEqual([0, 4, 5.2, 8]);
    expect(r.notes.map(n => n.len)).toEqual([2, 1, 4, 3]);
    expect(r.moved).toBe(2);
    expect(r.notes[3]).toBe(N[3]); // untouched notes are the same objects
  });
  it('uses coarser units and never goes below 0', () => {
    expect(quantizeStarts(N, [0, 1], 4).notes.slice(0, 2).map(n => n.step)).toEqual([0, 4]);
    expect(quantizeStarts([{ ch: 1, step: 0.2, len: 1 }], [0], 0.5).notes[0].step).toBe(0);
  });
  it('keeps a note that would end past the song inside it', () => {
    const r = quantizeStarts([{ ch: 1, step: MAX_STEP - 2.2, len: 2.2 }], [0], 4);
    expect(r.notes[0].step + r.notes[0].len).toBeLessThanOrEqual(MAX_STEP);
    expect(r.notes[0].step % 4).toBe(0);
  });
  it('reports nothing moved on the grid already', () => {
    expect(quantizeStarts(N, [3], 1).moved).toBe(0);
  });
});

describe('legato', () => {
  it('extends each note to the next later start; chords together; the last keep their length', () => {
    const ns: Note[] = [
      { ch: 1, step: 0, len: 1, p: 60 }, { ch: 1, step: 0, len: 2, p: 64 }, // chord
      { ch: 1, step: 6, len: 1, p: 62 },
      { ch: 1, step: 12, len: 1, p: 60 }, { ch: 1, step: 12.0005, len: 3, p: 67 }, // last chord (off by < EPS)
    ];
    const r = legato(ns, [0, 1, 2, 3, 4]);
    expect(r.notes.map(n => n.len)).toEqual([6, 6, 6, 1, 3]);
    expect(r.changed).toBe(3);
  });
  it('shortens overlapping notes and only looks at the given notes', () => {
    const ns: Note[] = [{ ch: 1, step: 0, len: 8 }, { ch: 1, step: 2, len: 1 }, { ch: 1, step: 4, len: 1 }];
    expect(legato(ns, [0, 2]).notes.map(n => n.len)).toEqual([4, 1, 1]);
  });
  it('a single note does not change', () => {
    expect(legato(N, [0]).changed).toBe(0);
  });
});

describe('selection helpers', () => {
  it('inverts within the channel', () => {
    expect([...invertSelection([0, 1, 3], new Set([1]))]).toEqual([0, 3]);
    expect([...invertSelection([0, 1], new Set([0, 1]))]).toEqual([]);
  });
  it('finds the notes of one key (the root for notes without p)', () => {
    expect(notesOfKey(N, 1, CH, 60)).toEqual([0, 3]);
    expect(notesOfKey(N, 1, CH, 67)).toEqual([]); // another channel's
  });
});

describe('velocity wheel', () => {
  it('nudges and clamps', () => {
    const r = nudgeVelocity(N, [0, 1], 0.05);
    expect(r[0].v).toBe(1);
    expect(r[1].v).toBe(0.55);
    expect(nudgeVelocity(N, [1], -0.6)[1].v).toBe(0);
    expect(nudgeVelocity(N, [1], -0.01)[1].v).toBe(0.49);
  });
  it('counts mouse notches per event and adds up touchpad deltas', () => {
    expect(wheelNotches(0, -100, false).n).toBe(1);
    expect(wheelNotches(0, 120, false).n).toBe(-1);
    expect(wheelNotches(0, 3, true).n).toBe(-1);
    let a = 0, n = 0;
    for (let k = 0; k < 10; k++) { const r = wheelNotches(a, -15, false); a = r.acc; n += r.n; }
    expect(n).toBe(1);
  });
});

describe('view navigation', () => {
  const lim = { total: 128, minLen: 4, maxLen: 64 };
  it('fits a range, centred when the limits keep it wider', () => {
    expect(fitRange(16, 48, lim)).toEqual({ pos: 16, len: 32 });
    expect(fitRange(10, 11, lim)).toEqual({ pos: 8.5, len: 4 });
    expect(fitRange(0, 128, lim)).toEqual({ pos: 32, len: 64 });
    expect(fitRange(120, 127, lim).pos + fitRange(120, 127, lim).len).toBeLessThanOrEqual(128);
  });
  it('follows page-wise', () => {
    expect(followPage(10, { pos: 0, len: 32 }, 2)).toBeNull();
    expect(followPage(32, { pos: 0, len: 32 }, 2)).toBe(30);
    expect(followPage(1, { pos: 30, len: 32 }, 2)).toBe(0); // the loop came round
  });
});

describe('note properties', () => {
  it('formats and parses starts as bar:beat:16th', () => {
    expect(fmtStart(0)).toBe('1:1:1');
    expect(fmtStart(21)).toBe('2:2:2');
    expect(fmtStart(4.5)).toBe('1:2:1.5');
    expect(parseStart('2:2:2')).toBe(21);
    expect(parseStart('2:02:02')).toBe(21);
    expect(parseStart('2.2.2')).toBe(21);
    expect(parseStart('3.2')).toBe(36);
    expect(parseStart('1:2:1.5')).toBe(4.5);
    expect(parseStart('3')).toBe(32);
    expect(parseStart('3:2')).toBe(36);
    expect(parseStart(fmtStart(3.99999))).toBe(3.99999);
    expect(parseStart(fmtStart(4 / 3))).toBe(1.333333);
    for (const bad of ['', '0:1:1', '1:5:1', '1:1:5', 'x', '1:1:1:1', '1.5:1']) expect(parseStart(bad)).toBeNull();
  });
  it('parses lengths, keys and velocities', () => {
    expect(parseLen('2')).toBe(2);
    expect(parseLen('1/8')).toBe(2);
    expect(fmtLen(2)).toBe('1/8');
    expect(fmtLen(4 / 3)).toBe('1/12');
    // custom lengths are note values too, reduced: the Snap menu's and the toolbar's notation
    expect(fmtLen(3)).toBe('3/16');
    expect(fmtLen(6)).toBe('3/8');
    expect(fmtLen(20)).toBe('5/4');
    expect(fmtLen(32)).toBe('2/1');
    expect(fmtLen(2.5)).toBe('2.5/16');
    for (const l of [3, 6, 20, 32, 2.5, 12]) expect(parseLen(fmtLen(l))).toBe(l);
    expect(parseLen(fmtLen(4 / 3))).toBe(1.333333);
    expect(parseLen(fmtLen(2.001))).toBe(2.001);
    expect(parseLen('3/16')).toBe(3);
    expect(parseLen('.5')).toBe(0.5);
    for (const bad of ['0', '-1', 'a', '1/0']) expect(parseLen(bad)).toBeNull();
    expect(parseKey('C4')).toBe(60);
    expect(parseKey('c#4')).toBe(61);
    expect(parseKey('Db4')).toBe(61);
    expect(parseKey('A-1')).toBe(9);
    expect(parseKey('64')).toBe(64);
    for (const bad of ['H4', '128', 'G9x', 'C10']) expect(parseKey(bad)).toBeNull();
  });
  it('reads one note and a mixed selection', () => {
    expect(readProps(N, [1], CH)).toEqual({ vel: 50, len: 1, start: 3.6, key: 64 });
    expect(readProps(N, [0, 1], CH)).toEqual({ vel: null, len: null, start: 0.3, key: 60 });
  });
  it('sets velocity and length on all, moves start and key as a group', () => {
    const r = applyProps(N, [0, 1], CH, { vel: 70, len: 2, start: 4.3, key: 62 })!;
    expect(r[0]).toEqual({ ch: 1, step: 4.3, len: 2, p: 62, v: 0.7, trig: false });
    expect(r[1]).toEqual({ ch: 1, step: 7.6, len: 2, p: 66, v: 0.7, trig: false });
    expect(r[2]).toBe(N[2]);
    // a note without its own key keeps it when the key is not changed
    expect(applyProps(N, [3], CH, { vel: 20 })![3]).toEqual({ ch: 1, step: 8, len: 3, v: 0.2 });
  });
  it('refuses to leave the song or the keys', () => {
    expect(applyProps(N, [0, 1], CH, { key: 125 })).toBeNull();
    expect(applyProps(N, [3], CH, { start: MAX_STEP - 1 })).toBeNull();
  });
});

describe('paste and nudge (FL)', () => {
  it('pastes at the step the notes were copied from while that is in view', () => {
    expect(pasteStart(0, 0, 64)).toBe(0);
    expect(pasteStart(20, 16, 64)).toBe(20);
  });
  it('moves the block by whole bars onto the first bar shown when its place is out of view', () => {
    // copied from bar 1 beat 2, the view starts at bar 5: bar 5 beat 2
    expect(pasteStart(4, 64, 64)).toBe(68);
    // copied from bar 9, the view shows bars 1-4: bar 1, same place in the bar
    expect(pasteStart(134, 0, 64)).toBe(6);
    // a view starting mid-bar: the first place in the bar at or after it
    expect(pasteStart(2, 20, 64)).toBe(34);
  });
  it('nudges the block by a grid step and stops at the start', () => {
    const notes: Note[] = [{ ch: 1, step: 1, len: 1, p: 60 }, { ch: 1, step: 4.5, len: 2, p: 62 }, { ch: 2, step: 0, len: 1, p: 60 }];
    expect(nudgeNotes(notes, [0, 1], 1).map(n => n.step)).toEqual([2, 5.5, 0]);
    // the earliest note stops at 0, and the others keep their distance to it
    expect(nudgeNotes(notes, [0, 1], -4).map(n => n.step)).toEqual([0, 3.5, 0]);
    expect(nudgeNotes(notes, [], 1)).toEqual(notes);
  });
});

describe('velocity lane strokes', () => {
  const hats: Note[] = [0, 1, 2, 3, 4, 5, 6, 7].map(s => ({ ch: 1, step: s, len: 1, p: 60 }));
  const none = new Set<number>();
  it('a fast drag sets every note it passed, not only those under the samples', () => {
    const out = velocityLine(hats, 1, none, { step: 0, v: 0.5 }, { step: 6, v: 0.5 }, 0.25);
    expect(out.map(n => n.v)).toEqual([0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, undefined]);
  });
  it('a ramp gives each note the line\'s value at its start, in either direction', () => {
    const up = velocityLine(hats, 1, none, { step: 0, v: 0.2 }, { step: 4, v: 1 }, 0.25);
    expect(up.slice(0, 5).map(n => n.v)).toEqual([0.2, 0.4, 0.6, 0.8, 1]);
    const back = velocityLine(hats, 1, none, { step: 4, v: 1 }, { step: 0, v: 0.2 }, 0.25);
    expect(back.slice(0, 5).map(n => n.v)).toEqual([0.2, 0.4, 0.6, 0.8, 1]);
  });
  it('a press without a move sets the note under it', () => {
    expect(velocityLine(hats, 1, none, { step: 3.1, v: 0.3 }, { step: 3.1, v: 0.3 }, 0.25).map(n => n.v)).toEqual([undefined, undefined, undefined, 0.3, undefined, undefined, undefined, undefined]);
  });
  it('leaves other channels and, with a selection, unselected notes alone', () => {
    const mixed: Note[] = [...hats.slice(0, 3), { ch: 2, step: 1, len: 1, p: 60 }];
    const out = velocityLine(mixed, 1, new Set([0, 2]), { step: 0, v: 0.4 }, { step: 2, v: 0.4 }, 0.25);
    expect(out.map(n => n.v)).toEqual([0.4, undefined, 0.4, undefined]);
  });
});

describe('panLine', () => {
  const hats: Note[] = [0, 2, 4].map(step => ({ ch: 1, step, len: 1 }));
  it('sets the notes own pan from the lane height and snaps the middle to centre', () => {
    const right = panLine(hats, 1, new Set(), { step: 0, v: 1 }, { step: 4, v: 1 }, 0.25);
    expect(right.map(n => n.pan)).toEqual([1, 1, 1]);
    const ramp = panLine(hats, 1, new Set(), { step: 0, v: 0 }, { step: 4, v: 1 }, 0.25);
    expect(ramp.map(n => n.pan)).toEqual([-1, undefined, 1]);
    // back to the middle: the field goes away (a centred note stores no pan)
    expect('pan' in panLine(right, 1, new Set(), { step: 0, v: 0.5 }, { step: 4, v: 0.5 }, 0.25)[0]).toBe(false);
  });
  it('leaves other channels and unselected notes alone', () => {
    const mixed: Note[] = [{ ch: 1, step: 0, len: 1 }, { ch: 2, step: 0, len: 1 }, { ch: 1, step: 1, len: 1 }];
    const out = panLine(mixed, 1, new Set([0]), { step: 0, v: 0 }, { step: 2, v: 0 }, 0.25);
    expect(out.map(n => n.pan)).toEqual([-1, undefined, undefined]);
  });
});

describe('note pan through the properties', () => {
  it('sets and clears the pan of the edited notes only', () => {
    const notes = [{ ch: 1, step: 0, len: 1 }, { ch: 1, step: 2, len: 1, pan: 0.4 }];
    const out = applyProps(notes, [0], undefined, { pan: -0.5 })!;
    expect(out[0].pan).toBe(-0.5); expect(out[1].pan).toBe(0.4);
    expect('pan' in applyProps(notes, [1], undefined, { pan: 0 })![1]).toBe(false);
  });
});
