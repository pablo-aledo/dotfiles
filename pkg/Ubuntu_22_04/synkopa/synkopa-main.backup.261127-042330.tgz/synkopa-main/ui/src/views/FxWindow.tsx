import { createMemo, For, Show, untrack } from 'solid-js';
import type { JSX } from '@solidjs/web';
import { captureOn, createSignal, effect, onCleanup, onMount } from '../lib/reactive';
import { be } from '../api/backend';
import { PLUGIN_FORMAT_LABEL, unsafeReason, type Fx, type FxKind, type Id, type Op, type ParamDef, type PluginParam, type PluginRef } from '../api/types';
import { sliderStep } from '../lib/pluginParam';
import { clamp } from '../lib/format';
import { lang, t, tName, type TranslationKey } from '../lib/i18n';
import { NOTE_NAMES } from '../lib/pitch';
import { knobVal, paramDefs, pFmt, pNorm, presetInfo, presetList } from '../lib/presets';
import { noteName, stepBeats } from '../lib/beatDiv';
import * as A from '../state/actions';
import { autoDisplay, autoTweak, autoWheel, captureArmed, controlMenu, isAutomated, isOverridden, noteManualTweak, paramMenu, type Tweak } from '../state/automation';
import { setsLatency } from '../lib/automation';
import type { AutoTarget } from '../api/types';
import { commit, Gesture } from '../state/edit';
import { findFx, insName, plain, S } from '../state/store';
import { onFxFrame, tele } from '../state/telemetry';
import { openMenu, say, U, type PlugWin } from '../state/ui';
import { keyMenu } from '../state/sidechain';
import { closeEditor, editorOpen, isNoEditor, knownWithoutEditor, openEditor } from '../state/pluginWindows';
import { dblCheck, moveWindow, track } from '../ui/drag';
import { addFrameTask, fitCanvas, fonts } from '../ui/frameLoop';
import { FXMETA, FxTile } from '../ui/icons';
import { Knob, MiniKnob, Segmented, type KnobSize } from '../ui/Knob';
import { PanelBoundary } from '../ui/PanelBoundary';
import { theme } from '../ui/theme';
import type { Viz } from './fx/common';
import { deessDb, DeessViz, deessFx, deessGeom, deessXf, deessY } from './fx/deess';
import { DenoiseViz } from './fx/denoise';
import { DynViz } from './fx/dyn';
import { EqViz } from './fx/eq';
import { EqStrips } from './fx/eqStrips';
import { EqPanel, eqHover, eqLeave, eqPointerDown, eqWheel } from './fx/eqEdit';
import { fetModes, FetViz } from './fx/fet';
import { ReverbViz, verbDrag, verbHit, verbLayout, type VerbHandle } from './fx/reverb';
import { SatViz } from './fx/satDelay';
import { DelayViz } from './fx/delay';
import { TuneViz } from './fx/tune';
import { RiderViz } from './fx/rider';
import { halfHit, HalfViz, halfXf } from './fx/half';
import { ChorusViz, PhaserViz } from './fx/modulation';
import { GateViz } from './fx/gate';
import { FilterViz } from './fx/filter';
import { warpDown, warpHover, WarpViz } from './fx/warp';
import { onVoicePad, padParams, padToVoice, VoiceViz } from './fx/voice';
import { StereoViz } from './fx/stereo';
import { AnalyzerViz } from './fx/analyzer';
import { dbOf, fOf, mbGeom, mbHit, MultibandViz } from './fx/multiband';
import { MasterViz, msBalDb, msFreq, msGeom, msHit, msLvlDb } from './fx/master';
import { MasterHeader } from './fx/MasterHeader';


function makeViz(f: Fx): Viz | null {
  switch (f.type) {
    case 'eq': return new EqViz();
    case 'comp': case 'limit': return new DynViz();
    case 'sat': return new SatViz();
    case 'delay': return new DelayViz();
    case 'reverb': return new ReverbViz();
    case 'tune': return new TuneViz();
    case 'fet': return new FetViz(f.id);
    case 'deess': return new DeessViz();
    case 'denoise': return new DenoiseViz();
    case 'voice': return new VoiceViz();
    case 'rider': return new RiderViz();
    case 'half': return new HalfViz();
    case 'warp': return new WarpViz();
    case 'chorus': return new ChorusViz();
    case 'phaser': return new PhaserViz();
    case 'gate': return new GateViz();
    case 'filter': return new FilterViz();
    case 'stereo': return new StereoViz();
    case 'analyzer': return new AnalyzerViz();
    case 'multiband': return new MultibandViz();
    case 'master': return new MasterViz();
    default: return null;
  }
}
const VIZ_H: Partial<Record<Fx['type'], number>> = { eq: 300, reverb: 300, tune: 280, fet: 250, sat: 240, deess: 230, denoise: 240, voice: 250, rider: 220, half: 250, delay: 230, warp: 360, chorus: 170, phaser: 220, gate: 210, filter: 220, stereo: 250, analyzer: 360, multiband: 270, master: 340 };

const HINTS: Partial<Record<Fx['type'], TranslationKey>> = {
  eq: 'c.fx.hint.eq',
  reverb: 'c.fx.hint.reverb',
  deess: 'c.fx.hint.deess',
  fet: 'c.fx.hint.fet',
  denoise: 'c.fx.hint.denoise',
  tune: 'c.fx.hint.tune',
  half: 'c.fx.hint.half',
  delay: 'c.fx.hint.delay',
  warp: 'c.fx.hint.warp',
  voice: 'c.fx.hint.voice',
  chorus: 'c.fx.hint.chorus',
  phaser: 'c.fx.hint.phaser',
  gate: 'c.fx.hint.gate',
  filter: 'c.fx.hint.filter',
  stereo: 'c.fx.hint.stereo',
  analyzer: 'c.fx.hint.analyzer',
  multiband: 'c.fx.hint.multiband',
  master: 'c.fx.hint.master',
};

export { moveWindow };

export function FxWindow(props: { pw: PlugWin; z: number }) {
  const ff = () => findFx(props.pw.fxId);
  const setPos = (x: number, y: number) => A.movePlug(props.pw.fxId, x, y);
  return (
    <Show when={ff()}>
      {got => {
        const fx = () => got().f, m = () => got().m;
        const isVst = () => fx().type === 'plugin';
        const info = () => presetInfo(S.catalog, fx(), S.project.bpm);
        return (
          <div class="win fxwin" style={{ left: props.pw.x + 'px', top: props.pw.y + 'px', width: props.pw.w + 'px', 'z-index': props.z }} data-fxwin={props.pw.fxId}
            ref={captureOn('pointerdown', () => A.plugFront(props.pw.fxId))}>
            <div class="winhd" onPointerDown={e => moveWindow(e, () => props.pw, setPos)}>
              <button class={['pwr', { off: fx().bypass }]} title={fx().bypass ? t('c.fx.bypassOn') : t('c.fx.bypassOff')}
                onPointerDown={e => { e.stopPropagation(); A.toggleBypass(fx().id); }} />
              <FxTile type={fx().type} size={20} icon={13} />
              <span class="title">{A.fxName(fx())}</span>
              <Show when={fx().type === 'comp' || fx().type === 'fet'}>
                <Segmented options={[t('c.fx.compClean'), 'FET']} small value={() => (fx().type === 'fet' ? 1 : 0)} color={FXMETA[fx().type].color}
                  pick={i => A.swapFxType(fx().id, i ? 'fet' : 'comp')} title={t('c.fx.compTypeTip')} />
              </Show>
              <span style={{ width: '6px', height: '6px', flex: 'none', 'border-radius': '2px', background: m().color }} />
              <span class="sub">{insName(m())}</span>
              <Show when={fx().bypass}><span class="bypasstag">BYPASS</span></Show>
              <div style={{ flex: 1 }} />
              <HintIcon fx={fx()} />
              {/* effects with their own wet/dry knob don't need a second one in the header */}
              <Show when={!OWN_MIX.has(fx().type) || (fx().mix ?? 1) !== 1}><MixControl fx={fx()} /></Show>
              <Show when={!isVst() && presetList(S.catalog, fx().type).length}>
                <div class="presetbar">
                  <button class="arrow" title={t('c.fx.presetPrev')} onClick={() => A.stepPreset(fx().id, -1)}>‹</button>
                  <button class={['name', { mod: info().mod }]} title={t('c.fx.presets')} data-preset-name
                    onClick={e => { const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); openPresetMenu(fx().id, r.left, r.bottom + 4); }}>
                    <span class="ell" style={{ flex: 1, 'min-width': 0 }}>{tName(info().name)}{info().mod ? ' *' : ''}</span>
                    <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style={{ flex: 'none' }}><path d="M6 9l6 6 6-6" /></svg>
                  </button>
                  <button class="arrow" title={t('c.fx.presetNext')} onClick={() => A.stepPreset(fx().id, 1)}>›</button>
                </div>
              </Show>
              <button class="closebtn" title={t('c.fx.close')} onClick={() => A.closePlug(fx().id)}>×</button>
            </div>
            {/* the body behind an error boundary: a failure shows in the window, whose title bar still moves and closes it */}
            <PanelBoundary name={t('d.ui.pn.fx')}>
              <Show when={!isVst()} fallback={<PluginBody id={fx().id} plugin={fx().plugin} />}>
                <Show when={fx().type === 'eq'} fallback={<VizCanvas fxId={props.pw.fxId} pw={props.pw} height={VIZ_H[fx().type] ?? 190} />}>
                  {/* EQ: band bank beside the graph, like FL Parametric EQ 2 */}
                  <div class="eqmain">
                    <div class="eqgraph"><VizCanvas fxId={props.pw.fxId} pw={props.pw} height={VIZ_H.eq!} /></div>
                    <EqStrips fx={fx()} />
                  </div>
                </Show>
                <Body fx={fx()} />
              </Show>
            </PanelBoundary>
          </div>
        );
      }}
    </Show>
  );
}

/** Dry/wet of the effect (fx.mix), automatable. */
const OWN_MIX = new Set<string>(['reverb', 'delay', 'sat', 'fet', 'half', 'warp', 'chorus', 'phaser', 'stereo', 'analyzer', 'multiband', 'master']);
function MixControl(props: { fx: Fx }) {
  const target = () => ({ kind: 'mix' as const, fxId: props.fx.id });
  const val = () => autoDisplay(target()) ?? props.fx.mix ?? 1;
  let g: Tweak | null = null;
  const op = (v: number): Op[] => [A.fxOp({ ...plain(findFx(props.fx.id)!.f), mix: Math.round(clamp(v, 0, 1) * 1000) / 1000 })];
  return (
    <div class="mixctl" title={t('c.fx.mixTip')}>
      <span class="lab">MIX</span>
      <MiniKnob key={'mix' + props.fx.id} title={t('c.fx.mixKnobTip')} t={val} automated={() => isAutomated(target())} overridden={() => isOverridden(target())}
        onStart={() => { g = autoTweak(target(), 'Mix', op); }} onChange={t => { g?.move(t); say(A.fxName(props.fx) + ' · Mix ' + Math.round(t * 100) + '%'); }}
        onEnd={() => { g?.end(); g = null; }} onReset={() => commit(op(1), 'Mix')}
        onWheel={t => autoWheel(target(), 'mix' + props.fx.id, 'Mix', t, op)}
        onMenu={(x, y) => paramMenu(x, y, target(), () => commit(op(1), 'Mix'), FXMETA[props.fx.type].color)} />
      <span class="v">{Math.round(val() * 100)}%</span>
    </div>
  );
}

function openPresetMenu(fxId: Id, x: number, y: number) {
  const ff = findFx(fxId); if (!ff || !S.catalog) return;
  const info = presetInfo(S.catalog, ff.f, S.project.bpm), list = presetList(S.catalog, ff.f.type);
  openMenu(x, y, [{ t: 'title', label: t('c.fx.presetsOf', { name: A.fxName(ff.f) }) },
    ...list.map((pr, i) => ({ t: 'item' as const, label: tName(pr.name), kbd: i === info.idx ? (info.mod ? t('c.fx.modified') : '●') : '', act: () => A.loadPreset(fxId, i) }))], 40 + list.length * 26);
}

// ---- parameter controls ----
function setParam(fxId: Id, id: string, v: number) {
  const f = findFx(fxId)?.f; if (!f) return null;
  return A.fxOp({ ...plain(f), params: { ...plain(f.params), [id]: v } });
}
const defOf = (fx: Fx, id: string) => paramDefs(S.catalog, fx.type).find(p => p.id === id);

/** The value for the status line: a synced time also names its note value and length at the tempo. */
function fmtLong(p: ParamDef, v: number): string {
  if (p.unit !== 'beat') return pFmt(p, v);
  const n = noteName(v);
  return pFmt(p, v) + (n ? ' (' + n + ')' : '') + ' · ' + Math.round(v * 60000 / Math.max(1, S.project.bpm)) + ' ms';
}

function ParamKnob(props: { fxId: Id; p: ParamDef; ends?: [string, string]; color?: string; size?: KnobSize }) {
  const fx = () => findFx(props.fxId)?.f;
  const target = () => ({ kind: 'fx' as const, fxId: props.fxId, param: props.p.id });
  const val = () => autoDisplay(target()) ?? fx()?.params[props.p.id] ?? props.p.def;
  const p = props.p;
  let g: Tweak | null = null;
  const reset = () => { const op = setParam(props.fxId, p.id, p.def); if (op) commit([op], tName(p.label)); };
  const staticOps = (t: number) => { const op = setParam(props.fxId, p.id, knobVal(p, t)); return op ? [op] : null; };
  // armed automation recording leaves the latency parameters alone (see fxParamMenu)
  const recordable = () => (fx() && setsLatency(fx()!.type, p.id) ? null : target());
  return (
    <Knob key={props.fxId + p.id} label={tName(p.label)} t={() => clamp(pNorm(p, val()), 0, 1)} ends={props.ends} color={props.color} size={props.size}
      automated={() => isAutomated(target())}
      overridden={() => isOverridden(target())}
      zero={() => (p.min < 0 && p.max > 0 && !p.log ? pNorm(p, 0) : 0)} text={() => pFmt(p, val())}
      onStart={() => { g = autoTweak(recordable(), tName(p.label), staticOps, { color: props.color }); }}
      onChange={t => { const v = knobVal(p, t); g?.move(t); say(A.fxName(fx()!) + ' · ' + tName(p.label) + ' ' + fmtLong(p, v)); }}
      onEnd={() => { g?.end(); g = null; }}
      onReset={reset}
      onMenu={(x, y) => fxParamMenu(x, y, fx(), p, target(), reset, props.color)}
      onWheel={t => {
        // a synced time steps one note value per notch (snapping alone would undo a small move)
        const v = p.unit === 'beat' ? stepBeats(val(), t - pNorm(p, val())) : knobVal(p, t);
        const n = clamp(pNorm(p, v), 0, 1);
        autoWheel(recordable(), 'fx' + props.fxId + p.id, tName(p.label), n, t2 => { const op = setParam(props.fxId, p.id, p.unit === 'beat' ? stepBeats(val(), t2 - pNorm(p, val())) : knobVal(p, t2)); return op ? [op] : null; });
        say(A.fxName(fx()!) + ' · ' + tName(p.label) + ' ' + fmtLong(p, v));
      }} />
  );
}

/** A choice parameter as segmented buttons (one click = one undo step). */
function ParamChoice(props: { fxId: Id; p: ParamDef; danger?: number; color?: string; labels?: string[]; small?: boolean; hideLabel?: boolean }) {
  const fx = () => findFx(props.fxId)?.f;
  const target = () => ({ kind: 'fx' as const, fxId: props.fxId, param: props.p.id });
  const val = () => autoDisplay(target()) ?? fx()?.params[props.p.id] ?? props.p.def;
  const pick = (i: number) => {
    if (Math.round(val()) === i) return;
    const op = setParam(props.fxId, props.p.id, i); if (!op) return;
    commit([op], tName(props.p.label));
    say(A.fxName(fx()!) + ' · ' + tName(props.p.label) + ': ' + tName(props.p.options![i]));
  };
  return <Segmented label={props.hideLabel ? undefined : tName(props.p.label)} options={props.labels ?? props.p.options!.map(tName)} value={val} pick={pick} danger={props.danger} color={props.color} small={props.small}
    onMenu={(x, y) => fxParamMenu(x, y, fx(), props.p, target(), () => pick(props.p.def), props.color)} />;
}

/** A parameter's right-click menu; one that moves the effect's latency cannot be automated, and says why. */
function fxParamMenu(x: number, y: number, fx: Fx | undefined, p: ParamDef, target: AutoTarget, reset: () => void, color?: string) {
  if (fx && setsLatency(fx.type, p.id)) controlMenu(x, y, tName(p.label), reset, t('c.fx.latNoAuto'));
  else paramMenu(x, y, target, reset, color);
}

/** One catalog parameter, as a knob (size tier) or segmented buttons — tinted with the effect's colour. */
function Ctl(props: { fx: Fx; id: string; ends?: [string, string]; danger?: number; labels?: string[]; small?: boolean; hideLabel?: boolean; size?: KnobSize }) {
  const d = () => defOf(props.fx, props.id);
  const color = () => FXMETA[props.fx.type].color;
  return (
    <Show when={d()}>
      {p => p().options
        ? <ParamChoice fxId={props.fx.id} p={p()} danger={props.danger} color={color()} labels={props.labels} small={props.small} hideLabel={props.hideLabel} />
        : <ParamKnob fxId={props.fx.id} p={p()} ends={props.ends} size={props.size} color={props.size === 'lg' ? color() : undefined} />}
    </Show>
  );
}

/** How to use the window, behind a "?" in the header (hover or focus): there when wanted, never taking room. */
function HintIcon(props: { fx: Fx }) {
  return <Show when={HINTS[props.fx.type]}>{k => <span class="fxhint" tabindex={0} role="note" aria-label={t(k())} data-tip={t(k())}>?</span>}</Show>;
}
/** Layout entries starting with `c.` are translation keys, anything else ("C3", "2×") is shown as is. */
const L = (s: string) => (s.startsWith('c.') ? t(s as TranslationKey) : s);

// ---- shared layout system: every built-in effect is described as titled sections of controls.
// Size tiers: `lg` for the one or two controls that define the effect, `md` standard, `sm` trims.
// Choices render as segmented buttons; `stack` puts items in a column; `x` is a custom widget.
/** `when`: the control is shown only while it applies (e.g. the delay's Offset vs Pan per model). */
type Item = { id: string; size?: KnobSize; ends?: [string, string] | ((fx: Fx) => [string, string] | undefined); labels?: string[]; danger?: number; small?: boolean; when?: (fx: Fx) => boolean }
  | { stack: Item[] } | { x: 'fetMeter' | 'key' };
/** Titles, labels and ends: keys starting with `c.` (see `L`). `adv`: shown only after the window's "Advanced" toggle (keeps the first view simple). */
type Section = { title: string; items: Item[]; adv?: boolean };
const [advOpen, setAdvOpen] = createSignal<Record<number, boolean>>({});
const LAYOUT: Partial<Record<FxKind, Section[]>> = {
  comp: [
    { title: 'c.fx.sec.compression', items: [{ id: 'thr', size: 'lg' }, { id: 'ratio', size: 'lg' }] },
    { title: 'c.fx.sec.time', items: [{ id: 'att' }, { id: 'rel' }] },
    { title: 'c.fx.sec.output', items: [{ id: 'gain' }] },
    { title: 'c.sc.title', items: [{ x: 'key' }] },
  ],
  fet: [
    { title: 'c.fx.sec.input', items: [{ id: 'input', size: 'lg' }] },
    { title: 'c.fx.sec.character', items: [{ stack: [{ id: 'ratio', danger: 4 }, { x: 'fetMeter' }] }] },
    { title: 'c.fx.sec.time', items: [{ id: 'attack' }, { id: 'release' }] },
    { title: 'c.fx.sec.output', items: [{ id: 'output', size: 'lg' }, { id: 'mix', size: 'sm' }] },
  ],
  limit: [
    { title: 'c.fx.sec.volume', items: [{ id: 'gain', size: 'lg' }] },
    { title: 'c.fx.sec.ceiling', items: [{ id: 'ceil' }] },
    { title: 'c.fx.sec.time', adv: true, items: [{ id: 'rel' }, { stack: [{ id: 'auto', small: true }] }, { id: 'look', size: 'sm' }] },
    { title: 'c.fx.sec.output', adv: true, items: [{ id: 'link', size: 'sm' }, { id: 'out', size: 'sm' }] },
  ],
  sat: [
    { title: 'c.fx.sec.character', items: [{ stack: [{ id: 'style', small: true }] }] },
    { title: 'c.fx.sec.drive', items: [{ id: 'drive', size: 'lg' }, { stack: [{ id: 'punish', labels: ['c.fx.lab.normal', 'Punish +20'], small: true, danger: 1 }] }] },
    { title: 'c.fx.sec.tone', items: [{ id: 'lowcut' }, { id: 'thump', size: 'sm' }, { id: 'tone', ends: ['c.fx.end.dark', 'c.fx.end.bright'] }, { id: 'highcut' }, { stack: [{ id: 'steep', labels: ['c.fx.lab.gentle', 'c.fx.lab.steep'], small: true }] }] },
    { title: 'c.fx.sec.output', items: [{ stack: [{ id: 'auto', labels: ['c.fx.lab.manual', 'Auto'], small: true }] }, { id: 'mix' }, { id: 'out' }] },
    { title: 'c.fx.sec.quality', adv: true, items: [{ stack: [{ id: 'hq', labels: ['2×', '4× HQ'], small: true }] }] },
  ],
  // first view: the four things you reach for (time, repeats, stereo, level); the loop's
  // character (filter detail, drive, lo-fi, diffusion, modulation) is under "Advanced"
  delay: [
    { title: 'c.fx.sec.echo', items: [
      { stack: [{ id: 'sync', small: true }] },
      { id: 'beats', size: 'lg', when: fx => (fx.params.sync ?? 0) < 0.5 }, { id: 'time', size: 'lg', when: fx => (fx.params.sync ?? 0) >= 0.5 },
      { id: 'fb', size: 'lg' },
    ] },
    { title: 'c.fx.sec.model', items: [{ stack: [{ id: 'model', small: true }] }] },
    { title: 'c.fx.sec.tone', items: [{ id: 'cutoff', when: fx => (fx.params.ftype ?? 1) >= 0.5 }] },
    // Ducking sits with the levels: it is a level move on the wet (same knob as the reverb's)
    { title: 'c.fx.sec.output', items: [{ id: 'mix' }, { id: 'dry' }, { id: 'duck', size: 'sm' }] },
    { title: 'c.fx.sec.time', adv: true, items: [
      { stack: [{ id: 'keep', labels: ['c.fx.lab.repitch', 'c.fx.lab.keepPitch'], small: true }] },
      { id: 'smooth', size: 'sm', when: fx => (fx.params.keep ?? 0) < 0.5 },
      { id: 'offset', size: 'sm', ends: ['L', 'R'], when: fx => dlyModel(fx) <= 1 }, { id: 'pan', size: 'sm', ends: ['L', 'R'], when: fx => dlyModel(fx) === 2 },
      { id: 'spread', size: 'sm', ends: ['c.fx.end.mono', 'c.fx.end.stereo'] }, { id: 'input', size: 'sm' },
    ] },
    { title: 'c.fx.sec.feedback', adv: true, items: [{ stack: [{ id: 'ftype', small: true }] }, { id: 'res', size: 'sm', when: fx => (fx.params.ftype ?? 1) >= 0.5 }, { id: 'tone', size: 'sm', ends: ['LP', 'HP'] }] },
    { title: 'c.fx.sec.loopDrive', adv: true, items: [
      { stack: [{ id: 'dist', small: true }] }, { id: 'level', size: 'sm' },
      { id: 'knee', size: 'sm', ends: ['c.fx.end.solid', 'c.fx.end.valve'], when: fx => (fx.params.dist ?? 1) >= 0.5 }, { id: 'sym', size: 'sm', when: fx => (fx.params.dist ?? 1) >= 0.5 },
    ] },
    { title: 'c.fx.sec.lofi', adv: true, items: [{ id: 'srate', size: 'sm' }, { id: 'bits', size: 'sm' }] },
    { title: 'c.fx.sec.diffusion', adv: true, items: [{ id: 'diff', size: 'sm' }, { id: 'dspread', size: 'sm' }] },
    { title: 'c.fx.sec.modulation', adv: true, items: [{ id: 'rate', size: 'sm' }, { id: 'mtime', size: 'sm' }, { id: 'mcut', size: 'sm' }] },
  ],
  reverb: [
    { title: 'c.fx.sec.space', items: [{ stack: [{ id: 'space', small: true }] }, { id: 'size', size: 'lg' }, { id: 'pre' }] },
    { title: 'c.fx.sec.tone', items: [{ id: 'tone', ends: ['c.fx.end.dark', 'c.fx.end.bright'] }] },
    { title: 'c.fx.sec.amount', items: [{ id: 'mix', size: 'lg' }] },
    { title: 'c.fx.sec.filters', adv: true, items: [{ id: 'lo', size: 'sm' }, { id: 'hi', size: 'sm' }, { id: 'bass', size: 'sm' }] },
    { title: 'c.fx.sec.character', adv: true, items: [{ id: 'early', size: 'sm' }, { id: 'width', size: 'sm' }, { id: 'mod', size: 'sm' }, { id: 'duck', size: 'sm' }] },
  ],
  rider: [
    { title: 'c.fx.sec.leveling', items: [{ id: 'amount', size: 'lg' }, { id: 'phrase' }, { stack: [{ id: 'speed', labels: ['c.fx.lab.sung', 'Rap'], small: true }] }] },
    { title: 'c.fx.sec.range', items: [{ id: 'up' }, { id: 'down' }] },
    { title: 'c.fx.sec.lookahead', items: [{ stack: [{ id: 'look', labels: ['c.fx.lab.lookShort', 'c.fx.lab.lookLong', 'c.fx.lab.live'], small: true }] }] },
    { title: 'c.fx.sec.target', adv: true, items: [{ stack: [{ id: 'auto', labels: ['c.fx.lab.manualAlt', 'Auto'], small: true }] }, { id: 'target', size: 'sm' }, { id: 'floor', size: 'sm' }, { id: 'gate', size: 'sm' }] },
    { title: 'c.fx.sec.output', adv: true, items: [{ id: 'out', size: 'sm' }] },
  ],
  deess: [
    { title: 'c.fx.sec.detection', items: [{ id: 'thr', size: 'lg' }, { id: 'freq' }, { stack: [{ id: 'mode', small: true }] }] },
    { title: 'c.fx.sec.reduction', items: [{ id: 'range' }, { id: 'look', size: 'sm' }] },
    { title: 'c.fx.sec.listen', items: [{ stack: [{ id: 'listen', labels: ['Off', 'c.fx.lab.onlyS'], small: true }] }] },
  ],
  denoise: [
    { title: 'c.fx.sec.reduction', items: [{ id: 'reduction', size: 'lg' }, { id: 'sens' }, { id: 'smooth' }] },
    { title: 'c.fx.sec.noiseProfile', items: [{ stack: [{ id: 'learn', small: true }, { id: 'listen', small: true }] }] },
  ],
  voice: [
    { title: 'c.fx.sec.mode', items: [{ stack: [{ id: 'mode', small: true }, { id: 'link', small: true }] }] },
    { title: 'c.fx.sec.voice', items: [{ id: 'pitch', size: 'lg', ends: fx => (fx.params.mode === 2 ? ['C3', 'C5'] : undefined) }, { id: 'formant', size: 'lg', ends: ['c.fx.end.deeper', 'c.fx.end.brighter'] }] },
    { title: 'c.fx.sec.output', items: [{ id: 'drive' }, { id: 'out' }] },
  ],
  tune: [
    { title: 'c.fx.sec.correction', items: [{ id: 'retune', size: 'lg', ends: ['robot', 'natural'] }, { id: 'humanize' }, { id: 'flex' }, { id: 'vibrato' }] },
    { title: 'c.fx.sec.shift', items: [{ id: 'transpose', size: 'sm' }, { id: 'formant', size: 'sm' }] },
  ],
  eq: [{ title: 'c.fx.sec.output', items: [{ id: 'out', size: 'sm' }] }],
  warp: [
    { title: 'c.fx.sec.trigger', items: [{ stack: [{ id: 'trig', small: true }, { id: 'pos', small: true }] }, { stack: [{ id: 'oneshot', small: true }, { id: 'hold', small: true, danger: 1 }] }] },
    { title: 'c.fx.sec.mix', items: [{ id: 'tmix' }, { id: 'vmix' }] },
    { title: 'c.fx.sec.volEnv', items: [{ id: 'att', size: 'sm' }, { id: 'rel', size: 'sm' }, { id: 'tns', size: 'sm' }] },
    { title: 'c.fx.sec.cleanup', adv: true, items: [{ stack: [{ id: 'click', small: true }, { id: 'attack', small: true }] }, { stack: [{ id: 'dc', small: true }] }] },
  ],
  chorus: [
    { title: 'c.fx.sec.mode', items: [{ stack: [{ id: 'mode', small: true }] }] },
    { title: 'c.fx.sec.motion', items: [
      { stack: [{ id: 'sync', small: true }, { id: 'div', small: true, when: synced }] },
      { id: 'rate', size: 'lg', when: fx => !synced(fx) }, { id: 'depth', size: 'lg' },
    ] },
    { title: 'c.fx.sec.voices', items: [{ id: 'delay', when: fx => Math.round(fx.params.mode ?? 0) !== 2 }, { id: 'fb', when: fx => Math.round(fx.params.mode ?? 0) !== 2 }] },
    { title: 'c.fx.sec.stereoTone', items: [{ id: 'width', ends: ['c.fx.end.mono', 'c.fx.end.wide'] }, { id: 'hp', size: 'sm' }, { id: 'tone', size: 'sm', ends: ['c.fx.end.dark', 'c.fx.end.bright'] }] },
    { title: 'c.fx.sec.output', items: [{ id: 'mix' }] },
  ],
  phaser: [
    { title: 'c.fx.sec.stages', items: [{ stack: [{ id: 'stages', small: true }] }] },
    { title: 'c.fx.sec.sweep', items: [{ id: 'center', size: 'lg' }, { id: 'depth', size: 'lg' }] },
    { title: 'c.fx.sec.motion', items: [
      { stack: [{ id: 'sync', small: true }, { id: 'div', small: true, when: synced }] },
      { id: 'rate', when: fx => !synced(fx) }, { id: 'stereo', size: 'sm' },
    ] },
    { title: 'c.fx.sec.feedback', items: [{ id: 'fb', ends: ['c.fx.end.hollow', 'c.fx.end.resonant'] }] },
    { title: 'c.fx.sec.output', items: [{ id: 'mix' }] },
  ],
  // first view: how wide, is the bass mono, level and balance; polarity and swap are repair tools
  stereo: [
    { title: 'c.fx.sec.stereo', items: [{ id: 'width', size: 'lg', ends: ['c.fx.end.mono', 'c.fx.end.wide'] }, { id: 'spread' }] },
    { title: 'c.fx.sec.bass', items: [{ stack: [{ id: 'bass', labels: ['c.fx.lab.bassStereo', 'Mono'], small: true }] }, { id: 'bassf', when: fx => (fx.params.bass ?? 0) >= 0.5 }] },
    { title: 'c.fx.sec.output', items: [{ id: 'gain' }, { id: 'pan', ends: ['L', 'R'] }] },
    { title: 'c.fx.sec.channels', adv: true, items: [{ stack: [{ id: 'invl', labels: ['L', 'Ø L'], small: true }, { id: 'invr', labels: ['R', 'Ø R'], small: true }] }, { stack: [{ id: 'swap', labels: ['L | R', 'R | L'], small: true }] }] },
  ],
  analyzer: [
    { title: 'c.fx.sec.target', items: [{ stack: [{ id: 'target', labels: ['Off', 'Streaming −14', 'c.fx.lab.loud9', 'Broadcast −23'], small: true }] }] },
    { title: 'c.fx.sec.spectrum', adv: true, items: [{ stack: [{ id: 'slope', small: true }] }] },
  ],
  // the four OTT controls first; the band levels and crossovers are under "Advanced", the
  // thresholds are dragged in the display
  multiband: [
    { title: 'c.fx.sec.amount', items: [{ id: 'depth', size: 'lg' }, { id: 'time' }] },
    { title: 'c.fx.sec.compression', items: [{ id: 'up', ends: ['0', '200%'] }, { id: 'down', ends: ['0', '200%'] }] },
    { title: 'c.fx.sec.gain', items: [{ id: 'in' }, { id: 'out' }] },
    { title: 'c.fx.sec.bands', adv: true, items: [{ id: 'gl', size: 'sm' }, { id: 'gm', size: 'sm' }, { id: 'gh', size: 'sm' }] },
    { title: 'c.fx.sec.crossovers', adv: true, items: [{ id: 'xlo', size: 'sm' }, { id: 'xhi', size: 'sm' }] },
  ],
  // first view: the target and how loud, the tone the listen chose, glue and the clipper, stereo,
  // the comparison; the band thresholds and crossovers the listen sets are under "Advanced"
  master: [
    // less is more: the first view is how loud, how much tone and glue, how wide per band and the
    // comparison; everything the listen sets in detail (and the display drags) is under Advanced
    { title: 'c.fx.sec.loudness', items: [{ stack: [{ id: 'target', small: true }] }, { id: 'drive', size: 'lg' }, { id: 'ceil' }] },
    { title: 'c.fx.sec.tone', items: [{ id: 'tone' }] },
    { title: 'c.fx.sec.glue', items: [{ id: 'ratio' }] },
    { title: 'c.fx.sec.width', items: [{ id: 'wl', size: 'sm' }, { id: 'wm', size: 'sm' }, { id: 'wh', size: 'sm' }] },
    { title: 'c.fx.sec.compare', items: [{ stack: [{ id: 'match', small: true }] }] },
    { title: 'c.fx.sec.toneBands', adv: true, items: [{ id: 'sub', size: 'sm' }, { id: 'low', size: 'sm' }, { id: 'mid', size: 'sm' }, { id: 'pres', size: 'sm' }, { id: 'air', size: 'sm' }] },
    { title: 'c.fx.sec.bandLevels', adv: true, items: [{ id: 'gl', size: 'sm' }, { id: 'gm', size: 'sm' }, { id: 'gh', size: 'sm' }] },
    { title: 'c.fx.sec.thresholds', adv: true, items: [{ id: 'tl', size: 'sm' }, { id: 'tm', size: 'sm' }, { id: 'th', size: 'sm' }, { id: 'gt', size: 'sm' }] },
    { title: 'c.fx.sec.crossovers', adv: true, items: [{ id: 'xlo', size: 'sm' }, { id: 'xhi', size: 'sm' }] },
    { title: 'c.fx.sec.clipper', adv: true, items: [{ id: 'clip', size: 'sm' }] },
  ],
  // first view: when it opens and how deep it closes, its times, Gate/Duck and look-ahead, and
  // what it listens to; the side-chain band and the detector are under "Advanced"
  gate: [
    { title: 'c.fx.sec.gate', items: [{ id: 'thr', size: 'lg' }, { id: 'ratio', ends: ['c.fx.end.gentle', 'c.fx.end.gate'] }, { id: 'hyst', size: 'sm' }, { id: 'floor' }] },
    { title: 'c.fx.sec.time', items: [{ id: 'att' }, { id: 'hold' }, { id: 'rel' }] },
    { title: 'c.fx.sec.mode', items: [{ stack: [{ id: 'mode', small: true }, { id: 'look', small: true }] }] },
    { title: 'c.sc.title', items: [{ stack: [{ x: 'key' }, { id: 'listen', labels: ['c.fx.lab.listenOff', 'c.fx.lab.listenOn'], small: true }] }] },
    { title: 'c.fx.sec.sidechain', adv: true, items: [{ id: 'schp', size: 'sm' }, { id: 'sclp', size: 'sm' }] },
    { title: 'c.fx.sec.detection', adv: true, items: [{ stack: [{ id: 'det', small: true }] }] },
  ],
  filter: [
    { title: 'c.fx.sec.filter', items: [
      { stack: [{ id: 'type', small: true }, { id: 'slope', small: true, when: fx => Math.round(fx.params.type ?? 1) !== 1 }] },
      { id: 'cutoff', size: 'lg', when: fx => Math.round(fx.params.type ?? 1) !== 5 },
      { id: 'dj', size: 'lg', ends: ['LP', 'HP'], when: fx => Math.round(fx.params.type ?? 1) === 5 },
      { id: 'res', size: 'lg' }, { id: 'drive' },
    ] },
    { title: 'c.fx.sec.lfo', items: [
      { stack: [{ id: 'sync', small: true }, { id: 'div', small: true, when: synced }, { id: 'shape', small: true, labels: ['Sin', 'Tri', 'Saw ↑', 'Saw ↓', 'Sqr', 'S&H'] }] },
      { id: 'rate', when: fx => !synced(fx) }, { id: 'lfo' }, { id: 'stereo', size: 'sm' },
    ] },
    { title: 'c.fx.sec.envelope', items: [{ id: 'env' }, { id: 'eatt', size: 'sm' }, { id: 'erel', size: 'sm' }, { x: 'key' }] },
    { title: 'c.fx.sec.output', adv: true, items: [{ stack: [{ id: 'clip', small: true }] }] },
  ],
  half: [
    { title: 'c.fx.sec.slowdown', items: [{ stack: [{ id: 'speed', labels: ['c.fx.lab.halfFifth', 'c.fx.lab.halfOctave', 'c.fx.lab.halfTwoOct'], small: true }, { id: 'loop', small: true }] }] },
    { title: 'c.fx.sec.transitions', items: [{ id: 'smooth', size: 'lg', ends: ['c.fx.end.percussive', 'c.fx.end.swell'] }] },
    { title: 'c.fx.sec.band', items: [{ id: 'lo', size: 'sm' }, { id: 'hi', size: 'sm' }, { stack: [{ id: 'solo', labels: ['c.fx.lab.fullBand', 'c.fx.lab.bandSolo'], small: true }] }] },
    { title: 'c.fx.sec.output', items: [{ id: 'mix' }] },
  ],
};

/** The Multiband's thresholds: dragged in its display, not knobs. */
const MB_THRESHOLDS = ['dl', 'dm', 'dh', 'ul', 'um', 'uh'];
/** Chorus / Phaser: the LFO follows the tempo. */
function synced(fx: Fx) { return (fx.params.sync ?? 0) >= 0.5; }
/** The delay's model index (0 mono, 1 stereo, 2 ping-pong, 3 off). */
const dlyModel = (fx: Fx) => Math.round(fx.params.model ?? 1);

function LayoutItem(props: { fx: Fx; it: Item }) {
  const it = props.it;
  if ('stack' in it) return <div class="stack">{it.stack.map(x => <LayoutItem fx={props.fx} it={x} />)}</div>;
  if ('x' in it && it.x === 'key') return <KeyPicker fx={props.fx} />;
  if ('x' in it) {
    const mode = () => fetModes.get(props.fx.id);
    return <Segmented label={t('c.fx.meter')} small options={['GR', 'OUT']} value={() => (mode() === 'gr' ? 0 : 1)} pick={i => fetModes.set(props.fx.id, i ? 'out' : 'gr')} title={t('c.fx.meterTip')} />;
  }
  const ends = () => { const e = typeof it.ends === 'function' ? it.ends(props.fx) : it.ends; return e ? [L(e[0]), L(e[1])] as [string, string] : undefined; };
  return <Ctl fx={props.fx} id={it.id} size={it.size} ends={ends()} labels={it.labels?.map(L)} danger={it.danger} small={it.small} />;
}

/** What a keyed source does to each effect that takes one (the hint under the picker, the tooltip). */
function keyText(fx: Fx): { tip: TranslationKey; on: TranslationKey } {
  if (fx.type === 'gate') return { tip: 'c.sc.tipGate', on: (fx.params.mode ?? 0) >= 0.5 ? 'c.sc.duckOn' : 'c.sc.gateOn' };
  if (fx.type === 'filter') return { tip: 'c.sc.tipFilter', on: 'c.sc.filterOn' };
  if (fx.type === 'eq') return { tip: 'c.sc.tipEq', on: (fx.bands ?? []).some(b => b.on && b.dynamic) ? 'c.sc.eqOn' : 'c.sc.eqIdle' };
  return { tip: 'c.sc.tip', on: 'c.sc.ducks' };
}

/** A sidechain picker (Compressor, Gate, Filter, EQ): what its detector hears (its own input, or another insert's sound). */
function KeyPicker(props: { fx: Fx }) {
  const src = () => (props.fx.key == null ? undefined : S.project.inserts.find(m => m.id === props.fx.key));
  return (
    <div class="scpick">
      <button class={['smallbtn', { on: !!src() }]} data-sidechain title={t(keyText(props.fx).tip)}
        onClick={e => { const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); openMenu(r.left, r.bottom + 4, keyMenu(props.fx.id), 260); }}>
        <Show when={src()} fallback={<span class="ell">{t('c.sc.own')}</span>}>
          {m => <><span class="scdot" style={{ background: m().color }} /><span class="ell">{insName(m())}</span></>}
        </Show>
        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style={{ flex: 'none' }}><path d="M6 9l6 6 6-6" /></svg>
      </button>
      <span class="sclab">{src() ? t(keyText(props.fx).on) : t('c.sc.ownHint')}</span>
    </div>
  );
}

/** Sections of an effect's controls; params the layout doesn't place go to an "Other" section. */
function Sections(props: { fx: Fx }) {
  const secs = () => {
    const lay = LAYOUT[props.fx.type];
    const defs = paramDefs(S.catalog, props.fx.type);
    if (!lay) return [{ title: 'c.fx.sec.params', items: defs.map(p => ({ id: p.id })) }] as Section[];
    const placed = new Set<string>();
    const walk = (xs: Item[]) => xs.forEach(x => ('stack' in x ? walk(x.stack) : 'id' in x ? placed.add(x.id) : null));
    lay.forEach(s => walk(s.items));
    const known = new Set(defs.map(p => p.id));
    // the tuner's key/scale/voice have their own row; Warp's slots are picked on its slot strip
    const rest = defs.filter(p => !placed.has(p.id) && !(props.fx.type === 'tune' && ['key', 'scale', 'voice'].includes(p.id)) && !(props.fx.type === 'warp' && ['tslot', 'vslot'].includes(p.id))
      && !(props.fx.type === 'multiband' && MB_THRESHOLDS.includes(p.id)));
    // drop layout items the engine does not define (older catalog), then sections left empty
    const keep = (xs: Item[]): Item[] => xs.flatMap((x): Item[] => {
      if ('stack' in x) { const k = keep(x.stack); return k.length ? [{ stack: k }] : []; }
      return 'id' in x && (!known.has(x.id) || (x.when && !x.when(props.fx))) ? [] : [x];
    });
    const all = lay.map(s => ({ ...s, items: keep(s.items) })).filter(s => s.items.length);
    return rest.length ? [...all, { title: 'c.fx.sec.other', adv: true, items: rest.map(p => ({ id: p.id })) }] : all;
  };
  const hasAdv = () => secs().some(s => s.adv);
  const adv = () => !!advOpen()[props.fx.id];
  const shown = () => secs().filter(s => !s.adv || adv());
  return (
    <div class="fxsecs" style={{ '--fxc': FXMETA[props.fx.type].color }}>
      <For each={shown()}>
        {(sec, i) => (
          <>
            <div class={['fxsec', { adv: !!sec.adv }]}>
              <div class="fxsec-h">{L(sec.title)}</div>
              <div class="fxsec-b"><For each={sec.items}>{it => <LayoutItem fx={props.fx} it={it} />}</For></div>
            </div>
          </>
        )}
      </For>
      <div style={{ flex: 1 }} />
      <Show when={hasAdv()}>
        <button class={['smallbtn advbtn', { on: adv() }]} title={t('c.fx.advTip')}
          onClick={() => setAdvOpen(m => ({ ...m, [props.fx.id]: !adv() }))}>{adv() ? t('c.fx.less') : t('c.fx.advanced')}</button>
      </Show>
    </div>
  );
}

function Body(props: { fx: Fx }): JSX.Element {
  const kind = () => props.fx.type;
  return (
    <>
      <Show when={kind() === 'eq'}><EqPanel fx={props.fx} /></Show>
      {/* an EQ's sidechain drives its dynamic bands: offered once there is one (or a key to undo) */}
      <Show when={kind() === 'eq' && (props.fx.key != null || (props.fx.bands ?? []).some(b => b.dynamic))}>
        <div class="ctlrow"><div class="segp"><span class="lab">{t('c.sc.title').toUpperCase()}</span><KeyPicker fx={props.fx} /></div></div>
      </Show>
      <Show when={kind() === 'tune'}><TuneHeader fx={props.fx} /></Show>
      <Show when={kind() === 'master'}><MasterHeader fx={props.fx} /></Show>
      <Show when={kind() !== 'eq'}><Sections fx={props.fx} /></Show>
    </>
  );
}

/** Pitch Correct: key / scale / voice / auto-key row above the knobs. */
function TuneHeader(props: { fx: Fx }) {
  const color = FXMETA.tune.color;
  return (
    <div class="ctlrow">
      <Show when={defOf(props.fx, 'key')}>{p => <ParamChoice fxId={props.fx.id} p={p()} color={color} labels={NOTE_NAMES} small />}</Show>
      <Show when={defOf(props.fx, 'scale')}>{p => <ParamChoice fxId={props.fx.id} p={p()} color={color} small />}</Show>
      <Show when={defOf(props.fx, 'voice')}>{p => <ParamChoice fxId={props.fx.id} p={p()} color={color} labels={[t('c.fx.voice.auto'), t('c.fx.voice.bass'), t('c.fx.voice.male'), t('c.fx.voice.female'), t('c.fx.voice.soprano')]} small />}</Show>
      <div class="segp">
        <span class="lab">AUTO-KEY</span>
        <button class="smallbtn" style={{ height: '24px', padding: '0 10px' }} data-detect-key
          title={t('c.fx.detectKeyTip')}
          onClick={() => A.openMusicAnalysis({ fxId: props.fx.id })}>
          {t('c.fx.detectKey')}
        </button>
      </div>
    </div>
  );
}

/** The window's canvas: one Viz drawn from the shared frame loop, only when something changed. */
function VizCanvas(props: { fxId: Id; pw: PlugWin; height: number }) {
  let cv!: HTMLCanvasElement;
  const ff = () => findFx(props.fxId);
  const viz = makeViz(ff()!.f);
  const height = createMemo(() => props.height);
  const pw = createMemo(() => props.pw);
  let version = 0, drawnVersion = -1, lastW = 0, fontEpoch = -1, themeEpoch = -1;
  effect(() => { // anything param-ish changes → redraw
    const f = ff()?.f; if (!f) return;
    f.bypass; f.mix; for (const k in f.params) void f.params[k];
    f.bands?.forEach(b => { b.on; b.type; b.f; b.g; b.q; b.slope; b.place; b.dynamic?.range; b.dynamic?.thr; });
    f.bands?.length;
    for (const b of [f.maps?.time, f.maps?.vol]) b?.forEach(sl => { sl.name; sl.points.forEach(q => { q.t; q.v; q.tension; q.shape; }); sl.points.length; });
    U.eqSel[props.fxId]; U.fetMode[props.fxId]; S.project.bpm; lang();
    version++;
  });
  onMount(() => {
    const off = viz?.ingest ? onFxFrame(props.fxId, (a, at) => viz.ingest!(a, at)) : null;
    onCleanup(() => off?.());
    const stop = addFrameTask(now => {
      const f = ff()?.f; if (!f || !viz) return;
      const w = pw();
      if (w.x > window.innerWidth || w.y > window.innerHeight || w.x + w.w < 0 || document.hidden) return;
      const raw = tele.fx.get(props.fxId) ?? null;
      const a = raw && tele.frame.seq - raw.seq < 30 ? raw : null;
      const changed = viz.update(f, a, now);
      const W = cv.clientWidth, H = height();
      if (!W) return;
      if (!changed && version === drawnVersion && W === lastW && fontEpoch === fonts.epoch && themeEpoch === theme.epoch) return;
      drawnVersion = version; lastW = W; fontEpoch = fonts.epoch; themeEpoch = theme.epoch;
      fitCanvas(cv, W, H);
      const g = cv.getContext('2d')!;
      const dpr = window.devicePixelRatio || 1;
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      viz.draw(g, W, H, f, a, { selBand: U.eqSel[props.fxId] ?? null, fxId: props.fxId, now });
    });
    onCleanup(stop);
  });

  const rel = (e: PointerEvent | WheelEvent) => { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top, W: r.width, H: r.height }; };
  const down = (e: PointerEvent) => {
    const got = ff(); if (!got || !viz) return;
    if (got.f.type === 'eq') eqPointerDown(e, cv, props.fxId, viz as EqViz);
    else if (got.f.type === 'reverb') verbDown(e, got.f);
    else if (got.f.type === 'deess') deessDown(e, got.f);
    else if (got.f.type === 'voice') voiceDown(e);
    else if (got.f.type === 'half') halfDown(e, got.f);
    else if (got.f.type === 'multiband') mbDown(e, got.f);
    else if (got.f.type === 'master') msDown(e, got.f);
    else if (got.f.type === 'warp') warpDown(e, cv, props.fxId, viz as WarpViz, () => version++);
    else if (got.f.type === 'fet' && e.button === 0) {
      const m = fetModes.get(props.fxId) === 'out' ? 'gr' : 'out';
      fetModes.set(props.fxId, m); version++; say(m === 'gr' ? t('c.fx.meterGr') : t('c.fx.meterOut'));
    }
  };
  const move = (e: PointerEvent) => {
    const got = ff(); if (!got || !viz || e.buttons) return;
    if (got.f.type === 'eq') eqHover(e, cv, props.fxId, viz as EqViz);
    else if (got.f.type === 'deess') {
      const d = viz as DeessViz, { x, y, W, H } = rel(e), G = deessGeom(W, H);
      const onThr = x < G.hx + G.hw && Math.abs(y - deessY(got.f.params.thr ?? -32, H)) < 6;
      const onF = x >= G.sx && Math.abs(x - deessFx(got.f.params.freq ?? 6000, W, H)) < 8;
      if (onThr !== d.hoverThr || onF !== d.hoverFreq) { d.hoverThr = onThr; d.hoverFreq = onF; version++; }
      cv.style.cursor = onThr ? 'ns-resize' : onF ? 'ew-resize' : 'default';
    } else if (got.f.type === 'reverb') {
      const v = viz as ReverbViz, { x, y, W, H } = rel(e), on = verbHit(got.f, x, y, W, H);
      if (on !== v.hover) { v.hover = on; version++; }
      cv.style.cursor = on ? VERB_CURSOR[on] : 'default';
    } else if (got.f.type === 'warp') {
      if (warpHover(e, cv, props.fxId, viz as WarpViz)) version++;
    } else if (got.f.type === 'half') {
      const v = viz as HalfViz, { x, y, W, H } = rel(e), on = halfHit(got.f, x, y, W, H);
      if (on !== v.hover) { v.hover = on; version++; }
      cv.style.cursor = on ? 'ew-resize' : 'default';
    } else if (got.f.type === 'analyzer') {
      const { x, y } = rel(e);
      (viz as AnalyzerViz).hover = { x, y }; version++;
    } else if (got.f.type === 'multiband') {
      const v = viz as MultibandViz, { x, y, W, H } = rel(e), on = mbHit(got.f, x, y, W, H);
      if (on !== v.hover) { v.hover = on; version++; }
      cv.style.cursor = on ? (on[0] === 'x' ? 'ew-resize' : 'ns-resize') : 'default';
    } else if (got.f.type === 'master') {
      const v = viz as MasterViz, { x, y, W, H } = rel(e), on = msHit(got.f, x, y, W, H);
      v.hover = on; v.mouse = { x, y }; version++;
      cv.style.cursor = on ? (on === 'xlo' || on === 'xhi' ? 'ew-resize' : 'ns-resize') : 'default';
    } else if (got.f.type === 'voice') {
      const v = viz as VoiceViz, { x, y, W, H } = rel(e), on = onVoicePad(x, y, W, H);
      if (on !== v.hover) { v.hover = on; version++; }
      cv.style.cursor = on ? 'crosshair' : 'default';
    }
  };
  const leave = () => {
    const got = ff(); if (!got || !viz) return;
    if (got.f.type === 'eq') eqLeave(viz as EqViz);
    if (got.f.type === 'deess') { const d = viz as DeessViz; d.hoverThr = d.hoverFreq = false; version++; }
    if (got.f.type === 'voice') { (viz as VoiceViz).hover = false; version++; }
    if (got.f.type === 'half') { (viz as HalfViz).hover = null; version++; }
    if (got.f.type === 'reverb') { (viz as ReverbViz).hover = null; version++; }
    if (got.f.type === 'analyzer') { (viz as AnalyzerViz).hover = null; version++; }
    if (got.f.type === 'multiband') { (viz as MultibandViz).hover = null; version++; }
    if (got.f.type === 'master') { const v = viz as MasterViz; v.hover = null; v.mouse = null; version++; }
    if (got.f.type === 'warp') { const w = viz as WarpViz; w.hover = null; w.hoverX = null; version++; }
  };
  /** Pad: click / drag sets Pitch and Formant together (one undo step), double click resets both. */
  const voiceDown = (e: PointerEvent) => {
    if (e.button !== 0) return;
    const { x, y, W, H } = rel(e);
    if (!onVoicePad(x, y, W, H)) return;
    e.preventDefault();
    const put = (pitch: number, formant: number) => {
      const f = findFx(props.fxId)?.f; if (!f) return null;
      return A.fxOp({ ...plain(f), params: { ...plain(f.params), pitch, formant } });
    };
    const tell = () => { const p = findFx(props.fxId)?.f.params; if (p) say('Voice · Pitch ' + (p.pitch ?? 0).toFixed(1) + ' st · Formant ' + (p.formant ?? 0).toFixed(1) + ' st'); };
    if (e.altKey || dblCheck('voice' + props.fxId)) { const op = put(0, 0); if (op) commit([op], 'Pitch / Formant'); tell(); return; }
    const g = new Gesture('Pitch / Formant');
    const r = cv.getBoundingClientRect();
    const at = (cx: number, cy: number) => {
      const f = findFx(props.fxId)?.f; if (!f) return;
      const v = padToVoice(cx - r.left, cy - r.top, r.width, r.height), q = padParams(f, v.pitch, v.formant);
      const op = put(q.pitch, q.formant); if (op) g.update([op]);
      tell();
    };
    at(e.clientX, e.clientY);
    track(ev => at(ev.clientX, ev.clientY), () => g.end(), 'grabbing');
  };
  /** Half-Speed band strip: drag an edge (double-click = that edge back to off). */
  const halfDown = (e: PointerEvent, f: Fx) => {
    if (e.button !== 0) return;
    const { x, y, W, H } = rel(e), which = halfHit(f, x, y, W, H); if (!which) return;
    const pd = defOf(f, which); if (!pd) return;
    e.preventDefault();
    const name = t(which === 'lo' ? 'c.fx.half.edgeLo' : 'c.fx.half.edgeHi');
    if (e.altKey || dblCheck('half' + which + props.fxId)) { const op = setParam(props.fxId, which, pd.def); if (op) commit([op], name); return; }
    const g = new Gesture(name);
    const r = cv.getBoundingClientRect();
    const at = (cx: number) => {
      const cur = findFx(props.fxId)?.f; if (!cur) return;
      let v = halfXf(cx - r.left, r.width);
      // keep the edges apart (≥ 1/6 octave)
      if (which === 'lo') v = Math.min(v, (cur.params.hi ?? 20000) / 1.12); else v = Math.max(v, (cur.params.lo ?? 20) * 1.12);
      const op = setParam(props.fxId, which, Math.round(clamp(v, pd.min, pd.max))); if (op) g.update([op]);
      const nv = findFx(props.fxId)?.f.params[which] ?? v;
      say(name + ': ' + (nv >= 1000 ? (nv / 1000).toFixed(2) + ' kHz' : Math.round(nv) + ' Hz'));
    };
    at(e.clientX);
    track(ev => at(ev.clientX), () => g.end(), 'ew-resize');
  };
  /** Multiband: drag a crossover sideways or a threshold up and down (one undo step); double-click = default. */
  const mbDown = (e: PointerEvent, f: Fx) => {
    if (e.button !== 0) return;
    const { x, y, W, H } = rel(e), id = mbHit(f, x, y, W, H); if (!id) return;
    const pd = defOf(f, id); if (!pd) return;
    e.preventDefault();
    const name = tName(pd.label);
    if (e.altKey || dblCheck('mb' + id + props.fxId)) { const op = setParam(props.fxId, id, pd.def); if (op) commit([op], name); return; }
    const g = new Gesture(name), v = viz as MultibandViz, r = cv.getBoundingClientRect(), G = mbGeom(r.width, r.height);
    v.drag = id; version++;
    track(ev => {
      const cur = findFx(props.fxId)?.f; if (!cur) return;
      let val: number;
      if (id[0] === 'x') {
        val = fOf(ev.clientX - r.left, G);
        // the crossovers stay an octave apart
        if (id === 'xlo') val = Math.min(val, (cur.params.xhi ?? 2500) / 2); else val = Math.max(val, (cur.params.xlo ?? 88.3) * 2);
        val = Math.round(clamp(val, pd.min, pd.max) * 10) / 10;
      } else val = Math.round(clamp(dbOf(ev.clientY - r.top, G), pd.min, pd.max) * 10) / 10;
      const op = setParam(props.fxId, id, val); if (op) g.update([op]);
      say(name + ': ' + fmtLong(pd, findFx(props.fxId)?.f.params[id] ?? val));
    }, () => { g.end(); v.drag = null; version++; }, id[0] === 'x' ? 'ew-resize' : 'ns-resize');
  };
  /** Master display: drag a tone handle up / down, a crossover sideways or a band threshold up /
   *  down (one undo step each); double-click = back to its default (a tone band to 0 dB, a
   *  threshold to off). Dragging a threshold to the top switches that band's glue off. */
  const msDown = (e: PointerEvent, f: Fx) => {
    if (e.button !== 0) return;
    const { x, y, W, H } = rel(e), id = msHit(f, x, y, W, H); if (!id) return;
    const pd = defOf(f, id); if (!pd) return;
    e.preventDefault();
    const name = tName(pd.label);
    if (e.altKey || dblCheck('ms' + id + props.fxId)) { const op = setParam(props.fxId, id, pd.def); if (op) commit([op], name); return; }
    const g = new Gesture(name), v = viz as MasterViz, r = cv.getBoundingClientRect(), G = msGeom(r.width, r.height);
    const isTone = ['sub', 'low', 'mid', 'pres', 'air'].includes(id), isThr = ['tl', 'tm', 'th'].includes(id);
    const start = f.params[id] ?? pd.def, y0 = msBalDb(y, G);
    v.drag = id; version++;
    track(ev => {
      const cur = findFx(props.fxId)?.f; if (!cur) return;
      const params = { ...plain(cur.params) };
      if (id === 'xlo' || id === 'xhi') {
        let val = msFreq(ev.clientX - r.left, G);
        // as the effect keeps them: the upper crossover two octaves over the lower, ≥ 1 kHz
        if (id === 'xlo') val = Math.min(val, (cur.params.xhi ?? 2800) / 4); else val = Math.max(val, (cur.params.xlo ?? 120) * 4, 1000);
        params[id] = Math.round(clamp(val, pd.min, pd.max));
      } else if (isThr) {
        const val = msLvlDb(ev.clientY - r.top, G);
        params[id] = val > -0.6 ? 0 : Math.round(clamp(val, pd.min, pd.max) * 10) / 10;
      } else if (isTone) {
        // the handle follows the pointer; with Tone at 0 % the drag brings Tone back to 100 %
        if ((cur.params.tone ?? 100) < 5) params.tone = 100;
        const scale = clamp((params.tone ?? 100) / 100, 0.05, 1);
        params[id] = Math.round(clamp(start + (msBalDb(ev.clientY - r.top, G) - y0) / scale, pd.min, pd.max) * 10) / 10;
      }
      g.update([A.fxOp({ ...plain(cur), params })]);
      const nv = findFx(props.fxId)?.f.params[id] ?? params[id];
      say(name + ': ' + (isThr && nv >= -0.05 ? t('c.ms.off') : fmtLong(pd, nv)));
    }, () => { g.end(); v.drag = null; version++; }, id === 'xlo' || id === 'xhi' ? 'ew-resize' : 'ns-resize');
  };
  const deessDown = (e: PointerEvent, f: Fx) => {
    if (e.button !== 0) return;
    const { x, y, W, H } = rel(e), G = deessGeom(W, H);
    const thrP = defOf(f, 'thr'), frP = defOf(f, 'freq'); if (!thrP || !frP) return;
    const onThr = x < G.hx + G.hw && Math.abs(y - deessY(f.params.thr ?? -32, H)) < 6;
    const onF = x >= G.sx - 4;
    if (!onThr && !onF) return;
    e.preventDefault();
    if (onThr && (e.altKey || dblCheck('thr' + props.fxId))) { const op = setParam(props.fxId, 'thr', thrP.def); if (op) commit([op], t('c.fx.thr')); return; }
    const g = new Gesture(onThr ? t('c.fx.thr') : t('c.fx.freq'));
    const r = cv.getBoundingClientRect();
    track(ev => {
      const op = onThr
        ? setParam(props.fxId, 'thr', Math.round(clamp(deessDb(ev.clientY - r.top, H), thrP.min, thrP.max)))
        : setParam(props.fxId, 'freq', Math.round(clamp(deessXf(ev.clientX - r.left, W, H), frP.min, frP.max)));
      if (op) g.update([op]);
      const nf = findFx(props.fxId)?.f;
      say(onThr ? t('c.fx.sayThr', { v: Math.round(nf?.params.thr ?? 0) }) : t('c.fx.sayBand', { v: Math.round(nf?.params.freq ?? 0) }));
    }, () => g.end(), onThr ? 'ns-resize' : 'ew-resize');
    if (onF && !onThr) { const op = setParam(props.fxId, 'freq', Math.round(clamp(deessXf(x, W, H), frP.min, frP.max))); if (op) g.update([op]); }
  };
  /** Reverb display: drag a decay dot (bass, decay, treble) up and down, a cut line or PRE sideways; one undo step, double-click = default. */
  const verbDown = (e: PointerEvent, f: Fx) => {
    if (e.button !== 0) return;
    const { x, y, W, H } = rel(e), which = verbHit(f, x, y, W, H); if (!which) return;
    e.preventDefault();
    const L0 = verbLayout(W, H, f);
    const id = verbDrag(which, L0, x, y, f.params).id, pd = defOf(f, id); if (!pd) return;
    const name = tName(pd.label);
    if (e.altKey || dblCheck('verb' + which + props.fxId)) { const op = setParam(props.fxId, id, pd.def); if (op) commit([op], name); return; }
    const g = new Gesture(name), v = viz as ReverbViz, r = cv.getBoundingClientRect();
    v.drag = which; version++;
    // map through the layout the user saw at the start of the drag: the axes would rescale under the pointer
    track(ev => {
      const cur = findFx(props.fxId)?.f; if (!cur) return;
      const nv = verbDrag(which, L0, ev.clientX - r.left, ev.clientY - r.top, cur.params);
      const op = setParam(props.fxId, nv.id, clamp(nv.value, pd.min, pd.max)); if (op) g.update([op]);
      say(name + ': ' + pFmt(pd, findFx(props.fxId)?.f.params[nv.id] ?? nv.value));
    }, () => { g.end(); v.drag = null; version++; }, VERB_CURSOR[which]);
  };
  const wheel = (e: WheelEvent) => {
    const got = ff(); if (!got || !viz) return;
    if (got.f.type === 'eq') eqWheel(e, props.fxId, viz as EqViz);
  };
  return <canvas ref={cv} class="vizcv" data-viz={props.fxId} style={{ height: props.height + 'px', cursor: viz?.cursor ?? 'default' }}
    onPointerDown={down} onPointerMove={move} onPointerLeave={leave} onWheel={wheel} onContextMenu={e => e.preventDefault()} />;
}

const VERB_CURSOR: Record<VerbHandle, string> = { pre: 'ew-resize', lo: 'ew-resize', hi: 'ew-resize', size: 'ns-resize', bass: 'ns-resize', tone: 'ns-resize' };

/** The option of an enumeration parameter its normalized value selects. */
const nearestOption = (p: PluginParam) =>
  (p.options ?? []).reduce((best, o, i, all) => (Math.abs(o.value - p.value) < Math.abs(all[best].value - p.value) ? i : best), 0);
/** A parameter's tooltip: its name, and for an LV2 port its range and unit. */
const paramTitle = (p: PluginParam) =>
  p.min != null && p.max != null && !p.toggle && !p.options?.length ? `${p.name} (${+p.min.toPrecision(6)} … ${+p.max.toPrecision(6)}${p.unit ? ' ' + p.unit : ''})` : p.name;

/**
 * A hosted plugin's controls in Synkopa's window: the button for its own window and the generic parameter list
 * (every format). `id` is the effect's id, or with `instrument` a plugin-instrument channel's (its parameters cannot
 * be automated yet, and a plugin that did not load leaves the channel silent rather than passing audio through).
 */
export function PluginBody(props: { id: Id; plugin?: PluginRef; instrument?: boolean }) {
  const [params, setParams] = createSignal<PluginParam[]>([]);
  const [err, setErr] = createSignal<string | null>(null);
  const [guiErr, setGuiErr] = createSignal<string | null>(null);
  const [noEd, setNoEd] = createSignal(knownWithoutEditor(props.plugin));
  const toggleGui = () => {
    setGuiErr(null);
    if (editorOpen(props.id)) return void closeEditor(props.id);
    openEditor(props.id).catch(e => {
      if (isNoEditor(e)) return setNoEd(true);
      setGuiErr(t('c.fx.guiFail', { e: String(e).replace(/^Error:\s*/, '') }));
    });
  };
  // whether this session can show plugin windows at all (no X11 display on Linux: the list is the plugin's UI)
  const [editors, setEditors] = createSignal(true);
  const [editorsWhy, setEditorsWhy] = createSignal<string | null>(null);
  const [q, setQ] = createSignal('');
  let refresh = 0;
  /** Parameters a capture drag is recording (id → the dragged value): the engine is not sent the
   * value, so a refresh would put the slider back under the pointer; the drag's value is kept. */
  const held = new Map<number, number>();
  const load = () => be().pluginParams(props.id).then(p => { setParams(held.size ? p.map(x => (held.has(x.id) ? { ...x, value: held.get(x.id)! } : x)) : p); setErr(null); }).catch(e => setErr(String(e)));
  /** Why the engine could not load the plugin (not installed, refused): shown instead of a parameter error. */
  const loadErr = () => S.fxErrors[props.id];
  const [trusting, setTrusting] = createSignal(false);
  onMount(() => { load(); be().appInfo().then(i => { setEditors(i.pluginEditors); setEditorsWhy(i.pluginEditorsWhy ?? null); }).catch(() => {}); });
  // a window opened with the slot is asked before the engine has the instance: ask again once it does
  effect(() => { void S.revision; if (err() && !loadErr()) load(); });
  // knobs turned in the plugin's own window: the list follows while both are open
  effect(() => {
    if (!editorOpen(props.id)) return;
    const iv = window.setInterval(load, 1000);
    onCleanup(() => clearInterval(iv));
  });
  // closing Synkopa's window leaves the plugin's own window open (FL): its header's gear brings this back
  onCleanup(() => clearTimeout(refresh));
  const label = () => PLUGIN_FORMAT_LABEL[props.plugin?.format ?? 'vst3'];
  const set = (id: number, v: number) => {
    setParams(ps => ps.map(p => p.id === id ? { ...p, value: v } : p));
    void be().pluginSetParam(props.id, id, v).catch(e => say(label() + ': ' + String(e)));
    clearTimeout(refresh); refresh = window.setTimeout(load, 200);
  };
  const shown = () => { const s = q().toLowerCase(); return params().filter(p => !s || p.name.toLowerCase().includes(s) || (p.symbol ?? '').toLowerCase().includes(s)); };
  return (
    <div style={{ padding: '12px 14px', display: 'flex', 'flex-direction': 'column', gap: '10px' }}>
      <div class="row" style={{ gap: '8px' }}>
        {/* a plugin that is not loaded has no window to show: the reason is below */}
        <Show when={editors() && !loadErr()} fallback={<Show when={!loadErr()}><span class="note" style={{ flex: 'none' }} title={editorsWhy() ?? t('c.fx.guiNone')}>{t('c.fx.guiNoneShort')}</span></Show>}>
          <Show when={!noEd()} fallback={<span class="note" style={{ flex: 'none' }} title={t('c.fx.guiNoWindowTip')}>{t('c.fx.guiNoWindow')}</span>}>
            <button class="smallbtn primary" style={{ height: '26px', padding: '0 12px' }} onClick={toggleGui}>{editorOpen(props.id) ? t('c.fx.guiClose') : t('c.fx.guiOpen')}</button>
          </Show>
        </Show>
        <span class="fxp-badge" style={{ flex: 'none' }}>{label()}</span>
        <span class="note ell" style={{ flex: 1 }} title={props.plugin?.cid}>{[props.plugin?.vendor, props.plugin?.path || props.plugin?.cid].filter(Boolean).join(' · ')}</span>
      </div>
      <input class="textin" placeholder={t('c.fx.searchParam')} value={q()} onInput={e => setQ(e.currentTarget.value)} onKeyDown={e => e.stopPropagation()} />
      <Show when={guiErr()}>{e => <span class="note err">{e()}</span>}</Show>
      <Show when={unsafeReason(loadErr())} fallback={
        <Show when={loadErr() ?? err()}>{e => <span class="note err">{loadErr() ? t(props.instrument ? 'c.fx.instNotLoaded' : 'c.fx.pluginNotLoaded', { e: e() }) : e()}</span>}</Show>
      }>
        {why => (
          <div class="unsafe">
            <span class="note err">{t(props.instrument ? 'c.fx.unsafeInst' : 'c.fx.unsafeFx', { e: why() })}</span>
            <button class="smallbtn" disabled={trusting()} title={t('c.fx.loadAnywayTip')}
              onClick={() => { setTrusting(true); be().pluginLoadAnyway(props.id).then(() => load(), e => say(String(e))).finally(() => setTrusting(false)); }}>
              {t('c.fx.loadAnyway')}
            </button>
          </div>
        )}
      </Show>
      <div style={{ 'max-height': '320px', overflow: 'auto', 'padding-right': '4px' }}>
        {/* rows keyed by the parameter's id: a value change (a new object per parameter, here and on
            every refresh) updates the row in place, so the slider being dragged stays in the page */}
        <For each={shown()} keyed={p => p.id} fallback={<span class="note">{t('c.fx.noParams')}</span>}>
          {p => {
            const id = untrack(() => p().id); // the row's key: the same for the row's whole life
            const target: AutoTarget = { kind: 'plugin', fxId: props.id, paramId: id };
            let cap: Tweak | null = null;
            const done = () => { cap?.end(); cap = null; held.delete(id); };
            // a row removed mid-drag (the search narrowed, the plugin reloaded) loses its
            // pointer-up handler: the capture closes here instead of leaking the gesture
            onCleanup(done);
            return (
              <div class="vparam" onContextMenu={e => { e.preventDefault(); e.stopPropagation();
                if (!props.instrument) paramMenu(e.clientX, e.clientY, target, () => set(id, p().def), undefined, { current: p().value, paramLabel: p().name });
                else controlMenu(e.clientX, e.clientY, p().name, () => set(id, p().def), t('c.fx.instNoAuto'));
              }}>
                <span class="ell" style={{ font: '12px var(--sans)', color: 'var(--fg)' }} title={paramTitle(p())}>{p().name}</span>
                <Show when={p().options?.length} fallback={
                  <Show when={p().toggle} fallback={
                    <input type="range" min="0" max="1" step={sliderStep(p())} value={p().value}
                      onInput={e => {
                        const v = +e.currentTarget.value;
                        if (!cap) return set(id, v);
                        // capturing: the envelope gets the value, the row shows it (`held` keeps it over a refresh)
                        held.set(id, v); setParams(ps => ps.map(q => (q.id === id ? { ...q, value: v } : q)));
                        cap.move(v);
                      }}
                      onDblClick={() => set(id, p().def)} aria-label={p().name}
                      onPointerDown={e => {
                        if (e.altKey && e.button === 0) { e.preventDefault(); set(id, p().def); }
                        else if (!props.instrument && captureArmed()) cap = autoTweak(target, p().name, () => null, { current: p().value, paramLabel: p().name });
                        else if (e.button === 0 && !props.instrument) noteManualTweak(target); // the tweak wins over the envelope (Ableton's override)
                      }}
                      onPointerUp={done} onPointerCancel={done} />
                  }>
                    <input type="checkbox" style={{ 'justify-self': 'start' }} checked={p().value >= 0.5} onChange={e => set(id, e.currentTarget.checked ? 1 : 0)} aria-label={p().name} />
                  </Show>
                }>
                  <select class="textin" style={{ height: '22px', padding: '0 4px' }} aria-label={p().name}
                    value={String(nearestOption(p()))} onChange={e => set(id, p().options![+e.currentTarget.value].value)} onKeyDown={e => e.stopPropagation()}>
                    <For each={p().options} keyed={false}>{(o, oi) => <option value={String(oi)}>{o().label}</option>}</For>
                  </select>
                </Show>
                <span class="mono ell" style={{ 'font-size': '10px', color: 'var(--fg2)', 'text-align': 'right' }} title={!props.instrument && isAutomated(target) ? t('d.ui.knob.auto') : p().display}>
                  <Show when={!props.instrument && isAutomated(target)}>● </Show>{p().display}
                </span>
              </div>
            );
          }}
        </For>
      </div>
    </div>
  );
}
