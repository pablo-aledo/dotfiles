// The Channel Rack (F6), as in FL Studio: one row per channel of the project — mute LED, pan,
// volume, mixer insert, name — and the current pattern's steps for it. A channel whose notes are
// more than steps (lengths, chords, off-grid) shows a mini piano roll; a click opens the Piano
// roll. The graph editor (G) edits the selected channel's per-step velocity and key.
// It floats in the effect-window layer, or is docked left of the Playlist (`U.rackDock`); every
// edit is an op and one undo step.
import { createMemo, For, Show, untrack } from 'solid-js';
import { createSignal, effect, onCleanup, onMount } from '../lib/reactive';
import { t } from '../lib/i18n';
import { TOTAL_BEATS, VOL_UNITY, type Channel } from '../api/types';
import { clamp, panText, volText } from '../lib/format';
import { barsText, cellsBetween, channelStepsOf, clearChannel, copyChannelNotes, gridW, pasteChannelNotes, stepAt, isRollRow, keyOf, loopStepsOf, notesText, rotate, setKeyAt, setPanAt, setShiftAt, setStep, setVelAt, shiftOf, MAX_SHIFT, stepsOf, type ChannelClip } from '../lib/pattern';
import { moveIndex, rackMoveIndex } from '../lib/rack';
import { noteName } from '../lib/pitch';
import { autoDisplay, autoTweak, autoWheel, isAutomated, isOverridden, paramMenu, type Tweak } from '../state/automation';
import { commit, Gesture } from '../state/edit';
import {
  addBar, RACK_MIN_W, stepPad, stepW, audition, chanById, chanKindLabel, chanOp, channels, closeRack, curPat, openRoll, patOp, playStep, putNotes, RACK_LEFT, RACK_ROW,
  rackFront, rackPlaceFor, removeBar, selChan, selectChannel, selectChannelRange, toggleChannelSelected, isChannelSelected, scrollPattern, toggleChanMute, toggleChanSolo,
  rackChannels, rackFilter, setRackFilter,
} from '../state/pattern';
import { arrVersion, rawOf, S } from '../state/store';
import { ensurePluginScan } from '../state/pluginScan';
import { openMenu, openRename, say, setU, U, type MenuItem } from '../state/ui';
import { edgeScroller, track } from '../ui/drag';
import { WindowBoundary } from '../ui/PanelBoundary';
import { addFrameTask, fitCanvas, fonts, Layer } from '../ui/frameLoop';
import { Icon } from '../ui/icons';
import { cleanGroup, fullIndexFor, rackGroups } from '../lib/rackGroups';
import { LANE_ICONS, LaneSwitch } from '../ui/LaneSwitch';
import { T } from '../ui/theme';
import { channelIcon, InstIcon } from '../ui/instIcons';
import { MiniKnob, NumField, parseNum } from '../ui/Knob';
import { PanelFrame, WinControls } from './PanelFrame';
import { paneDock } from '../state/docking';
import { findPane, PANE_MIN } from '../lib/dock';
import { prefs } from '../state/prefs';
import { insertBoxClick, wheelInsert } from '../ui/InsertPicker';
import { toggleChannelWindow } from './ChannelWindow';
import { drawKeyGraph, drawLane, drawRack, drawRackHead, type RackGeo, laneColor } from './patternDraw';
import { addChannelMenu, chanMenu, chanInsertChoice, insertMenu, insLabel, insTitle, patGeom, PatternChip, useDataVersion, useSize } from './patternShared';

const GRAPH_H = 92;
const RACK_ICON = 'M4 5h4v4H4z M10 5h4v4h-4z M16 5h4v4h-4z M4 15h4v4H4z M10 15h4v4h-4z M16 15h4v4h-4z';
const GRAPH_ICON = 'M4 20V10 M9 20V4 M14 20v-7 M19 20V8';
/** Key graph range around the channel's root (FL's note pitch graph: ± one octave). */
const KEY_SPAN = 12;
/** The rack's clipboard (Ctrl+C / X / V): one channel's notes, kept apart from the playlist's clips. */
let rackClip: ChannelClip | null = null;

/** The Channel Rack window (shown while `U.rackWin` is set and the project has a pattern). `docked`: laid out left of the Playlist. */
export function ChannelRack(props: { z: number; docked?: boolean }) {
  // a failure of the window itself (its title bar, its body) keeps a frame that moves and closes
  return (
    <Show when={U.rackWin && curPat()}>
      <WindowBoundary name={t('a.mn.rack')} class="patwin rackwin" docked={props.docked} z={props.z} front={rackFront} close={closeRack}
        closeTip={t(props.docked ? 'b.dk.closeRack' : 'b.pe.close')} geom={() => U.rackWin} move={(x, y) => patGeom('rackWin').setGeom({ x, y })}>
        <Rack z={props.z} docked={props.docked} />
      </WindowBoundary>
    </Show>
  );
}

function Rack(props: { z: number; docked?: boolean }) {
  let gridWrap!: HTMLDivElement, cv!: HTMLCanvasElement, head!: HTMLCanvasElement, graphCv!: HTMLCanvasElement, graphWrap!: HTMLDivElement;
  const ptM = createMemo(() => curPat()!);
  const pt = () => ptM();
  /** The rows the rack shows: every channel, or the group the filter picks. */
  const chans = () => rackChannels();
  const selCh = () => selChan();
  const size = useSize(() => gridWrap);
  const graphSize = useSize(() => graphWrap);
  const data = useDataVersion();
  const [scroll, setScroll] = createSignal({ x: 0, y: 0 });
  const [moveSlot, setMoveSlot] = createSignal<number | null>(null);
  const layer = new Layer();
  // the pattern plus one greyed bar (FL): a step clicked there makes the pattern a bar longer
  // While steps are being painted the grid keeps its step width and count: the first step in the
  // greyed bar makes the pattern a bar longer, and a grid that refitted at once would slide under
  // the pointer (the rest of the run landed in the wrong columns). It refits on release.
  const [hold, setHold] = createSignal<{ cw: number; pad: number; steps: number } | null>(null);
  const geo = (): RackGeo => {
    const end = stepsOf(pt()), h = hold(), steps = h ? h.steps : Math.min(TOTAL_BEATS * 4, end + 16);
    const cw = h ? h.cw : stepW(), pad = h ? h.pad : stepPad();
    return { cw, pad, sx: scroll().x, sy: scroll().y, rh: RACK_ROW, steps, end, rows: chans().length };
  };
  // the grid's own height: the add-channel row below the channels scrolls with them
  const contentH = () => (chans().length + 1) * RACK_ROW;
  const maxScroll = () => { const G = geo(); return { x: Math.max(0, gridW(G.steps, G.cw) - size().w), y: Math.max(0, contentH() - size().h) }; };
  effect(() => { const m = maxScroll(), s = scroll(); if (s.x > m.x || s.y > m.y) setScroll({ x: Math.min(s.x, m.x), y: Math.min(s.y, m.y) }); });
  const rollRowsM = createMemo(() => { arrVersion(); const notes = rawOf(pt()).notes; return new Set(rawOf(chans()).filter(c => isRollRow(notes, c)).map(c => c.id)); });
  const rollRows = () => rollRowsM();
  const graph = () => U.rackGraph;

  effect(() => {
    data(); const G = geo(), { w, h } = size(); void fonts.epoch;
    if (!w || !h || U.mixView) return; // repainted on the way back from the Mix view
    fitCanvas(cv, w, h); fitCanvas(head, w, h);
    const g = cv.getContext('2d')!, dpr = window.devicePixelRatio || 1;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawRack(g, w, h, G, layer, rawOf(pt()), rawOf(chans()), selCh()?.id ?? null, rollRows(), chans().some(c => c.solo));
    lastHead = -2;
  });
  effect(() => {
    const mode = graph(); if (!mode || U.mixView) return;
    data(); const G = geo(), { w, h } = graphSize(), c = selCh();
    if (!w || !h) return;
    fitCanvas(graphCv, w, h);
    const g = graphCv.getContext('2d')!, dpr = window.devicePixelRatio || 1;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const p = rawOf(pt()), notes = c ? p.notes.map((n, i) => ({ n, i })).filter(x => x.n.ch === c.id) : [];
    const roll = !!c && rollRows().has(c.id);
    if (mode === 'vel') drawLane(g, w, h, { x0: 0, cw: G.cw, sx: G.sx, steps: G.steps, notes, color: laneColor('vel'), cells: !roll, beatGap: true, muted: !!c?.mute });
    else if (mode === 'pan') drawLane(g, w, h, { x0: 0, cw: G.cw, sx: G.sx, steps: G.steps, notes, color: laneColor('pan'), cells: !roll, beatGap: true, muted: !!c?.mute || !panPlays(), value: n => ((n.pan ?? 0) + 1) / 2, bipolar: true });
    else if (mode === 'shift') drawLane(g, w, h, { x0: 0, cw: G.cw, sx: G.sx, steps: G.steps, notes, color: T.amber, cells: true, beatGap: true, muted: !!c?.mute || roll, value: n => shiftOf(n) / MAX_SHIFT });
    else drawKeyGraph(g, w, h, { cw: G.cw, sx: G.sx, steps: G.steps, notes, color: c?.color ?? '#4f8ef7', root: c?.root ?? 60, span: KEY_SPAN, off: roll });
  });
  // playhead column: only when the step changes
  let lastHead = -2;
  // the cached plugin list (opens no plugin), so "+" lists the VST3 instruments at once
  onMount(ensurePluginScan);
  onMount(() => onCleanup(addFrameTask(() => {
    const p = curPat(); if (!p || !head || U.mixView) return;
    const s = playStep(p);
    if (s === lastHead) return;
    lastHead = s;
    const { w, h } = size(); if (!w) return;
    const loops = rawOf(pt()).channelLoops ?? {};
    const loopRows = chans().map((c, i) => ({ row: i, loop: loops[String(c.id)] ?? 0 })).filter(x => x.loop > 0);
    const g = head.getContext('2d')!, dpr = window.devicePixelRatio || 1;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawRackHead(g, w, h, geo(), s, loopRows);
  })));

  const cellAt = (e: PointerEvent | MouseEvent) => {
    const r = cv.getBoundingClientRect(), G = geo();
    return { row: Math.floor((e.clientY - r.top + G.sy) / RACK_ROW), step: stepAt(e.clientX - r.left + G.sx, G.cw) };
  };
  const gridDown = (e: PointerEvent) => {
    if (e.button !== 0 && e.button !== 2) return;
    e.preventDefault();
    const G = geo(), { row, step } = cellAt(e), c = chans()[row];
    if (!c || step < 0 || step >= G.steps) return;
    selectChannel(c.id);
    if (rollRows().has(c.id) && step < G.end) {
      // a melodic line (lengths / chords): the steps cannot show it — the piano roll does (FL: click the mini roll)
      // stop here: the rack's own pointerdown would bring the rack back over the roll
      if (e.button === 0) { e.stopPropagation(); openRoll(c.id); }
      return;
    }
    // a looped row is editable only inside its cell: the rest does not play (FL's looping
    // channel), and the honest answer is the say, not a silent no-op
    const loop = loopStepsOf(rawOf(pt()), c.id);
    if (loop > 0 && step >= loop) {
      if (e.button === 0) say(t('b.rk.loopGridTip', { n: loop }));
      return;
    }
    // FL: the left button lights steps, the right one clears them. A left press on a lit step keeps it
    // (and a drag from it paints, never erases a run you only meant to extend)
    const on = e.button === 0;
    const g = new Gesture(on ? t('b.pe.gestSteps') : t('b.pe.gestDelSteps'));
    // freeze the grid (and the window's width) before the first step can make the pattern longer
    setHold({ cw: G.cw, pad: G.pad, steps: G.steps });
    let notes = setStep(rawOf(pt()).notes, c.id, step, on);
    g.update([putNotes(pt(), notes)]);
    if (on) audition(c.id, undefined, 0.8);
    let last = { row, step };
    track(ev => {
      const q = cellAt(ev);
      const r = clamp(q.row, 0, chans().length - 1), s = clamp(q.step, 0, G.steps - 1);
      if (r === last.row && s === last.step) return;
      for (const [rr, ss] of cellsBetween(last.row, last.step, r, s)) {
        const cc = chans()[rr];
        const l = cc ? loopStepsOf(rawOf(pt()), cc.id) : 0;
        if (!cc || (l > 0 && ss >= l)) continue;
        if (!rollRows().has(cc.id) || ss >= G.end) notes = setStep(notes, cc.id, ss, on);
      }
      last = { row: r, step: s };
      g.update([putNotes(pt(), notes)]);
    }, () => { g.end(); setHold(null); }, on ? 'copy' : 'not-allowed');
  };
  const wheel = (e: WheelEvent) => {
    const m = maxScroll(); if (!m.x && !m.y) return;
    e.preventDefault();
    const horiz = e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY) || !m.y;
    const d = (e.deltaY || e.deltaX);
    setScroll(s => horiz ? { ...s, x: clamp(s.x + d, 0, m.x) } : { ...s, y: clamp(s.y + d * 0.6, 0, m.y) });
  };
  /** The selected channel plays a note's own pan (plugin instruments do not). */
  const panPlays = () => selCh()?.kind !== 'plugin';
  // graph editor: drag across the steps to draw values; Alt+click resets a step (FL)
  const graphDown = (e: PointerEvent) => {
    const c = selCh(), mode = graph(); if (!c || !mode || e.button !== 0) return;
    e.preventDefault();
    const roll = rollRows().has(c.id);
    if (mode === 'key' && roll) { say(t('b.rk.keyRoll', { name: c.name })); return; }
    if (mode === 'shift' && roll) { say(t('b.rk.shiftRoll', { name: c.name })); return; }
    if (mode === 'pan' && !panPlays()) { say(t('b.rk.panPlugin', { name: c.name })); return; }
    if (e.altKey && mode !== 'key') {
      const G0 = geo(), r0 = graphCv.getBoundingClientRect(), s = stepAt(e.clientX - r0.left + G0.sx, G0.cw), ns = rawOf(pt()).notes;
      const out = mode === 'vel' ? setVelAt(ns, c.id, s, 1) : mode === 'pan' ? setPanAt(ns, c.id, s, 0) : setShiftAt(ns, c.id, s, 0);
      commit([putNotes(pt(), out)], t('b.rk.resetStep'));
      say(t('b.rk.resetStepDone', { name: c.name, n: s + 1 }));
      return;
    }
    const G = geo(), r = graphCv.getBoundingClientRect();
    const at = (ev: PointerEvent) => ({ s: stepAt(ev.clientX - r.left + G.sx, G.cw), f: clamp(1 - (ev.clientY - r.top - 6) / (r.height - 9), 0, 1) });
    const g = new Gesture(mode === 'vel' ? 'Velocity' : mode === 'pan' ? t('b.rk.panGest') : mode === 'shift' ? t('b.rk.shiftGest') : t('b.rk.keyGest'));
    let notes = rawOf(pt()).notes, last = at(e);
    const keyFor = (f: number) => clamp(Math.round(c.root - KEY_SPAN + f * 2 * KEY_SPAN), 0, 127);
    const apply = (s: number, f: number) => {
      if (mode === 'key') { notes = setKeyAt(notes, c, s, keyFor(f)); return; }
      if (mode === 'pan') { notes = setPanAt(notes, c.id, s, f * 2 - 1); return; }
      if (mode === 'shift') { notes = setShiftAt(notes, c.id, s, f * MAX_SHIFT); return; }
      notes = roll ? notes.map(n => n.ch === c.id && Math.floor(n.step + 1e-3) === s ? { ...n, v: Math.round(f * 100) / 100 } : n) : setVelAt(notes, c.id, s, f);
    };
    const tell = (f: number) => say(c.name + ' · ' + (mode === 'vel' ? 'velocity ' + Math.round(f * 100) + '%'
      : mode === 'pan' ? 'pan ' + panText(Math.abs(f * 2 - 1) < 0.03 ? 0 : f * 2 - 1)
      : mode === 'shift' ? t('b.rk.shiftSay', { pct: Math.round(f * MAX_SHIFT * 100) }) : noteName(keyFor(f))));
    apply(last.s, last.f);
    g.update([putNotes(pt(), notes)]);
    tell(last.f);
    if (mode === 'key') { const n = notes.find(x => x.ch === c.id && Math.floor(x.step + 1e-3) === last.s); if (n) audition(c.id, keyOf(n, c), 0.8); }
    let lastKey = keyFor(last.f);
    track(ev => {
      const q = at(ev);
      const n = Math.abs(q.s - last.s);
      for (let k = 0; k <= n; k++) { const tt = n ? k / n : 1; apply(Math.round(last.s + (q.s - last.s) * tt), last.f + (q.f - last.f) * tt); }
      last = q;
      g.update([putNotes(pt(), notes)]);
      tell(q.f);
      if (mode === 'key' && keyFor(q.f) !== lastKey) { lastKey = keyFor(q.f); if (notes.some(x => x.ch === c.id && Math.floor(x.step + 1e-3) === q.s)) audition(c.id, lastKey, 0.8); }
    }, () => g.end(), 'ns-resize');
  };
  const hbar = () => { const m = maxScroll(), w = size().w, G = geo(); if (!m.x) return null; const total = gridW(G.steps, G.cw); return { left: scroll().x / total * w, width: Math.max(24, w / total * w) }; };
  const hbarDown = (e: PointerEvent) => {
    e.preventDefault(); e.stopPropagation();
    const sx = e.clientX, x0 = scroll().x, G = geo(), k = gridW(G.steps, G.cw) / size().w;
    track(ev => setScroll(s => ({ ...s, x: clamp(x0 + (ev.clientX - sx) * k, 0, maxScroll().x) })), null, 'grabbing');
  };
  const swingG: { g: Gesture | null } = { g: null };
  const applySwing = (v: number, mode: 'begin' | 'move' | 'end' | 'set' | 'wheel') => {
    const op = patOp(pt(), { swing: Math.round(clamp(v, 0, 100)) / 100 });
    if (mode === 'begin') { swingG.g = new Gesture('Swing'); swingG.g.update([op]); }
    else if (mode === 'move') swingG.g?.update([op]);
    else if (mode === 'end') { swingG.g?.end(); swingG.g = null; }
    else commit([op], 'Swing');
    say(pt().name + ' · swing ' + Math.round(clamp(v, 0, 100)) + '%');
  };
  /** The graph editor adds its own height to the floating window instead of squeezing the channel rows; docked, it shares the panel's height (the rows scroll). */
  const toggleGraph = () => {
    const on = !graph(), w = U.rackWin;
    setU('rackGraph', on ? 'vel' : null);
    if (w && !props.docked) setU('rackWin', 'h', clamp(w.h + (on ? GRAPH_H : -GRAPH_H), 200, window.innerHeight - w.y - 10));
  };
  // FL's Auto resize → Minimum height: the rack is as tall as its rows (and the add-channel row)
  // need, up to the room there is, refitted both ways when the rows shown change (a channel added,
  // removed, a group filter) or the graph editor opens. Floating: the window's height; docked: the
  // height of a bottom strip it has to itself (on a side edge, or sharing a strip, the strip
  // decides). The chrome (title bar, graph lane, status line) is measured, not assumed. A height
  // set by hand stays until the rows change, as in FL; the title bar's menu turns it off.
  let fitRaf = 0;
  onCleanup(() => cancelAnimationFrame(fitRaf));
  const fitHeight = () => {
    fitRaf = 0;
    const frame = gridWrap?.closest<HTMLElement>('.patwin');
    if (!frame || !gridWrap.isConnected || !prefs().rackAutoH || hold() || U.mixView) return;
    const want = frame.offsetHeight - gridWrap.clientHeight + contentH();
    if (!props.docked) {
      const w = U.rackWin; if (!w) return;
      const h = Math.round(clamp(want, 200, Math.max(200, window.innerHeight - w.y - 20)));
      if (Math.abs(h - w.h) > 1) setU('rackWin', 'h', h);
      return;
    }
    const at = findPane(U.dock, 'rack');
    if (!at || at.edge !== 'bottom' || U.dock.bottom[at.strip].length !== 1) return;
    // the strip's splitter clamps it against the Playlist (fitStrips): the wish is stored as is
    const h = Math.round(Math.max(PANE_MIN.rack.h, want));
    if (Math.abs(h - U.paneSize.rack.h) > 1) setU('paneSize', 'rack', 'h', h);
  };
  effect(() => {
    void chans().length; void graph(); void prefs().rackAutoH; void props.docked;
    if (!fitRaf) fitRaf = requestAnimationFrame(fitHeight);
  });
  // The window's width follows the pattern's length: the pattern and its greyed bar at the
  // comfortable step width, up to the screen's edge (beyond that the grid scrolls). Switching to
  // another pattern only ever widens it (FL keeps the rack's size as you browse patterns: a
  // shorter one shows empty room instead of the window jumping); + / − bar and undo on the same
  // pattern refit both ways. Only a change refits, so a width set by hand stays until then; never
  // while steps are painted (`hold`): on release. Docked, the panel keeps the width the user gave
  // it and the grid scrolls.
  let fitted = stepsOf(pt()), fittedId = pt().id;
  effect(() => {
    const steps = stepsOf(pt()), id = pt().id;
    if (hold() || (steps === fitted && id === fittedId)) return;
    const other = id !== fittedId;
    fitted = steps; fittedId = id;
    untrack(() => {
      const w = U.rackWin; if (!w || props.docked) return;
      const pl = rackPlaceFor(steps, w.x);
      if (other && pl.w <= w.w) return;
      setU('rackWin', v => v && { ...v, x: pl.x, w: pl.w });
    });
  });
  /** Ctrl+C / X / V: copy, cut, paste the selected channel's notes in the current pattern (FL). */
  const editClipboard = (c: Channel, k: 'c' | 'x' | 'v') => {
    const p = pt();
    const notes = rawOf(p).notes;
    if (k === 'v') {
      if (!rackClip) { say(t('b.rk.clipEmpty')); return; }
      commit([putNotes(p, pasteChannelNotes(notes, c.id, rackClip))], t('b.rk.gestPaste'));
      say(t('b.rk.pasted', { notes: notesText(rackClip.length), name: c.name, pat: p.name }));
      return;
    }
    const clip = copyChannelNotes(notes, c.id);
    if (!clip.length) { say(t('b.rk.noNotes', { name: c.name, pat: p.name })); return; }
    rackClip = clip;
    if (k === 'x') commit([putNotes(p, clearChannel(notes, c.id))], t('b.rk.gestCut'));
    say(t(k === 'x' ? 'b.rk.cut' : 'b.rk.copied', { notes: notesText(clip.length), name: c.name, pat: p.name }));
  };
  const openChannelMenu = (c: Channel, e: MouseEvent) => {
    e.preventDefault();
    selectChannel(c.id);
    chanMenu(c, e.clientX, e.clientY, [
      { t: 'item', label: t('b.rk.copyNotes'), kbd: 'Ctrl+C', disabled: !pt().notes.some(n => n.ch === c.id), act: () => editClipboard(c, 'c') },
      { t: 'item', label: t('b.rk.gestPaste'), kbd: 'Ctrl+V', disabled: rackClip == null, act: () => editClipboard(c, 'v') },
    ]);
  };
  const moveChannelTo = (c: Channel, to: number) => {
    // `to` is a row of the shown rack; filtered, it lands next to the shown channel it now sits by
    const full = fullIndexFor(channels().map(x => x.id), chans().map(x => x.id), c.id, to);
    commit([chanOp(c, {}, full)], t('b.rk.gestMove'));
    say(t('b.rk.moved', { name: c.name, n: to + 1, of: chans().length }));
    const top = to * RACK_ROW, h = size().h;
    if (top < scroll().y) setScroll(s => ({ ...s, y: top }));
    else if (top + RACK_ROW > scroll().y + h) setScroll(s => ({ ...s, y: Math.min(maxScroll().y, top + RACK_ROW - h) }));
  };
  /** Alt+↑ / ↓: move the selected channel one row (FL); the row stays in view. */
  const moveChannel = (d: number) => {
    const c = selCh(); if (!c) return;
    const list = chans(), to = moveIndex(list.findIndex(x => x.id === c.id), list.length, d);
    if (to == null) { say(t(d < 0 ? 'b.rk.moveTop' : 'b.rk.moveBottom', { name: c.name })); return; }
    moveChannelTo(c, to);
  };
  const startChannelMove = (c: Channel, e: PointerEvent) => {
    if (e.button !== 0 || !e.isPrimary) return;
    e.preventDefault();
    const body = gridWrap.parentElement;
    const slotAt = (ev: PointerEvent) => {
      if (!gridWrap.isConnected || document.elementFromPoint(ev.clientX, ev.clientY)?.closest('.rackbody') !== body) return null;
      const y = ev.clientY - gridWrap.getBoundingClientRect().top + scroll().y;
      return clamp(Math.round(y / RACK_ROW), 0, chans().length);
    };
    // Row indices can change while dragging. Resolve the channel again at drop time.
    const destination = (slot: number) => rackMoveIndex(chans().findIndex(row => row.id === c.id), slot);
    const showSlot = (ev: PointerEvent) => {
      const slot = slotAt(ev);
      setMoveSlot(slot != null && destination(slot) != null ? slot : null);
      return slot;
    };
    const scroller = edgeScroller(() => gridWrap.getBoundingClientRect(), (_dx, dy) => {
      const y = clamp(scroll().y + dy, 0, maxScroll().y);
      if (y === scroll().y) return false;
      setScroll(s => ({ ...s, y }));
      return true;
    }, showSlot, { y: true });
    let dragging = false;
    track(ev => {
      if (ev.pointerId !== e.pointerId) return;
      dragging ||= Math.hypot(ev.clientX - e.clientX, ev.clientY - e.clientY) > 4;
      if (!dragging) return;
      if (showSlot(ev) == null) scroller.stop();
      else scroller.move(ev);
    }, ev => {
      scroller.stop();
      setMoveSlot(null);
      if (!dragging || ev.type !== 'pointerup' || ev.pointerId !== e.pointerId) return;
      const slot = slotAt(ev), channel = chanById(c.id);
      const to = slot == null ? null : destination(slot);
      if (channel && to != null) moveChannelTo(channel, to);
    }, 'grabbing');
  };
  const onKey = (e: KeyboardEvent) => {
    const tg = (e.target as HTMLElement).tagName;
    if (tg === 'INPUT' || tg === 'SELECT') return;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (k === 'c' || k === 'x' || k === 'v')) {
      e.preventDefault(); e.stopPropagation();
      const c = selCh();
      if (c) editClipboard(c, k);
      return;
    }
    const shiftSteps = (d: number) => {
      const c = selCh(); if (!c) return;
      commit([putNotes(pt(), rotate(rawOf(pt()).notes, c.id, channelStepsOf(rawOf(pt()), c.id), d))], t('b.pe.shiftSteps'));
      say(c.name + ' · ' + t(d < 0 ? 'b.pe.shiftL' : 'b.pe.shiftR'));
    };
    // FL: Shift+Ctrl+← / → shifts the selected channel's steps by one, wrapping around its cell or pattern
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && !e.altKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
      e.preventDefault(); e.stopPropagation();
      shiftSteps(e.key === 'ArrowLeft' ? -1 : 1);
      return;
    }
    if (e.ctrlKey || e.metaKey) return;
    // FL: ↑ / ↓ select the channel above / below
    if (!e.altKey && !e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
      e.preventDefault(); e.stopPropagation();
      const cs = chans(); if (!cs.length) return;
      const cur = cs.findIndex(c => c.id === selCh()?.id);
      const to = clamp(cur < 0 ? 0 : cur + (e.key === 'ArrowUp' ? -1 : 1), 0, cs.length - 1);
      selectChannel(cs[to].id);
      const top = to * RACK_ROW, h = size().h;
      if (top < scroll().y) setScroll(s => ({ ...s, y: top }));
      else if (top + RACK_ROW > scroll().y + h) setScroll(s => ({ ...s, y: Math.min(maxScroll().y, top + RACK_ROW - h) }));
      return;
    }
    if (e.altKey && !e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
      e.preventDefault(); e.stopPropagation();
      moveChannel(e.key === 'ArrowUp' ? -1 : 1);
      return;
    }
    // the earlier binding of the same thing, kept for those used to it
    if (e.altKey && e.shiftKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
      e.preventDefault(); e.stopPropagation();
      shiftSteps(e.key === 'ArrowLeft' ? -1 : 1);
      return;
    }
    if (e.altKey) return;
    if (e.key.toLowerCase() === 'g') { e.preventDefault(); e.stopPropagation(); toggleGraph(); }
  };
  /** FL's filter-group menu: All, each group, the unsorted channels; rename or ungroup the shown group. */
  const groupFilterMenu = (x: number, y: number) => {
    const all = channels(), groups = rackGroups(all), f = rackFilter(), unsorted = all.filter(c => !c.group).length;
    const items: MenuItem[] = [
      { t: 'item', label: t('b.rk.groupAllN', { n: all.length }), checked: f == null, act: () => setRackFilter(null) },
      ...groups.map((g): MenuItem => ({ t: 'item', label: `${g.name} (${g.n})`, checked: f === g.name, act: () => setRackFilter(g.name) })),
    ];
    if (groups.length) items.push({ t: 'item', label: t('b.rk.groupNoneN', { n: unsorted }), checked: f === '', disabled: !unsorted, act: () => setRackFilter('') });
    else items.push({ t: 'sec', label: t('b.rk.groupHint') });
    if (f) {
      const members = all.filter(c => c.group === f);
      items.push({ t: 'sep' },
        { t: 'item', label: t('b.rk.groupRename', { name: f }), act: () => openRename(x, y, f, v => {
          const g = cleanGroup(v); if (!g || g === f) return;
          commit(members.map(c => chanOp(c, { group: g })), t('b.rk.groupRenameGest'));
          setRackFilter(g); say(t('b.rk.groupRenamed', { from: f, to: g }));
        }) },
        { t: 'item', label: t('b.rk.groupUngroup', { name: f }), title: t('b.rk.groupUngroupTip'), act: () => {
          commit(members.map(c => chanOp(c, { group: undefined })), t('b.rk.groupUngroupGest'));
          setRackFilter(null); say(t('b.rk.groupUngrouped', { name: f, n: members.length }));
        } });
    }
    openMenu(x, y, items);
  };
  const notesCount = createMemo(() => { arrVersion(); return rawOf(pt()).notes.length; });
  // Shift+wheel over the title bar: previous / next pattern (FL). A plain wheel does nothing here, so
  // scrolling the channel list and drifting onto the title bar no longer switches the pattern
  let headAcc = 0;
  const headWheel = (e: WheelEvent) => {
    if (e.defaultPrevented) return; // the swing field turns its own value
    if (!e.shiftKey) return;
    e.preventDefault();
    headAcc += e.deltaY || e.deltaX;
    if (Math.abs(headAcc) < 40) return;
    scrollPattern(headAcc > 0 ? 1 : -1); headAcc = 0;
  };
  return (
    <PanelFrame name={t('a.mn.rack')} {...patGeom('rackWin')} z={props.z} class="rackwin" minW={RACK_MIN_W} minH={200} compactH={230} docked={props.docked} dockId="rack" front={rackFront} onKey={onKey} onHeadWheel={headWheel}
      controls={<WinControls dock={paneDock('rack')} close={{ tip: t(props.docked ? 'b.dk.closeRack' : 'b.pe.close'), act: closeRack }} />}
      head={<>
        <span class="tile" style={{ width: '20px', height: '20px', background: pt().color + '2e', color: pt().color }}><Icon d={RACK_ICON} size={12} /></span>
        <span class="wintitle">Channel rack</span>
        <PatternChip pat={pt()} />
        <button class={['chip groupchip', { on: rackFilter() != null }]} title={t('b.rk.groupTip')} aria-haspopup="menu"
          onClick={e => { const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); groupFilterMenu(r.left, r.bottom + 4); }}>
          <Icon d="M3 5h18l-7 8v6l-4 2v-8z" size={11} />
          <span>{rackFilter() == null ? t('b.rk.groupAll') : rackFilter() === '' ? t('b.rk.groupNone') : rackFilter()}</span>
          <svg width="8" height="8" viewBox="0 0 8 8"><path d="M1 2.5l3 3 3-3" fill="none" stroke="currentColor" stroke-width="1.3" /></svg>
        </button>
        <div class="bars" title={t('b.rk.barsTitle')}>
          <button disabled={pt().len <= 4} onClick={() => removeBar(pt())} title={t('b.pm.removeBarTitle')}>−</button>
          <span class="mono">{barsText(pt().len / 4)}</span>
          <button onClick={() => addBar(pt())} title={t('b.pm.addBarTitle')}>+</button>
        </div>
        <div>
          <NumField label="SWING" width={58} value={() => Math.round((pt().swing ?? 0) * 100)} text={v => Math.round(v) + '%'} parse={parseNum}
            drag={(v, d) => clamp(Math.round(v + d * 0.5), 0, 100)} apply={applySwing} title={t('b.pe.swingTitle')} />
        </div>
        <button class={['iconbtn', { on: !!graph() }]} title={t('b.rk.graphTitle')} onClick={toggleGraph}><Icon d={GRAPH_ICON} size={13} /></button>
      </>}>
      <div class="rack">
        <div class="rackbody" onWheel={wheel}>
          <div class="rackleft" style={{ width: RACK_LEFT + 'px' }}>
            <div style={{ transform: `translateY(${-scroll().y}px)` }}>
              <For each={chans()}>{c => <ChanRow c={c} onMenu={openChannelMenu} onMove={startChannelMove} />}</For>
              <div class="crow addrow" style={{ height: RACK_ROW + 'px' }}>
                <button class="smallbtn addch" title={t('b.pe.addChTitle')}
                  onClick={e => { const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); addChannelMenu(r.left, r.bottom + 4); }}>
                  <Icon d="M12 5v14 M5 12h14" size={11} />{t('b.pe.addCh')}
                </button>
              </div>
            </div>
          </div>
          <div ref={gridWrap} class="rackgrid">
            <canvas ref={cv} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', 'touch-action': 'none', cursor: 'pointer' }}
              onPointerDown={gridDown} onContextMenu={e => e.preventDefault()} />
            <canvas ref={head} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', 'pointer-events': 'none' }} />
            <Show when={!chans().length}><div class="pstate">{t('b.pe.noChannels')}</div></Show>
            <Show when={hbar()}>{b => <div class="hbar"><div style={{ left: b().left + 'px', width: b().width + 'px' }} onPointerDown={hbarDown} /></div>}</Show>
          </div>
          <Show when={moveSlot() != null}>
            <div class="rack-move-line" style={{ transform: `translateY(${moveSlot()! * RACK_ROW - scroll().y}px)` }} />
          </Show>
        </div>
        {/* always mounted (hidden when off) so its size is observed from the start */}
        <div class="lanerow" style={{ height: GRAPH_H + 'px', display: graph() ? 'flex' : 'none' }}>
            <div class="lanelab" style={{ width: RACK_LEFT + 'px' }}>
              <LaneSwitch row label={t('b.rk.graphTitle')} value={graph() ?? 'vel'} onPick={id => setU('rackGraph', id)} items={[
                { id: 'vel', cls: 'vel', label: t('b.pr.laneVel'), icon: LANE_ICONS.vel, tip: t('b.rk.velTip') },
                { id: 'key', cls: 'key', label: t('b.rk.key'), icon: LANE_ICONS.key, tip: t('b.rk.keyTip') },
                { id: 'pan', cls: 'pan', label: t('b.rk.pan'), icon: LANE_ICONS.pan, tip: panPlays() ? t('b.rk.panTip') : t('b.rk.panPlugin', { name: selCh()?.name ?? '' }), disabled: !panPlays() },
                { id: 'shift', cls: 'shift', label: t('b.rk.shift'), icon: LANE_ICONS.shift, tip: t('b.rk.shiftTip') },
              ]} />
              <div class="lanetitle"><span class="ell" style={{ color: selCh()?.color ?? 'var(--fg3)' }}>{selCh()?.name ?? '—'}</span></div>
            </div>
            <div ref={graphWrap} class="lanecv">
              <canvas ref={graphCv} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', 'touch-action': 'none', cursor: 'ns-resize' }}
                onPointerDown={graphDown} onContextMenu={e => e.preventDefault()} />
            </div>
          </div>
        <div class="pstatus mono">
          <span>{t('b.rk.status', { ch: chans().length, notes: notesText(notesCount()), bars: barsText(pt().len / 4) })}</span>
          <span class="hintshort">{t('b.rk.hintShort')}</span>
          <button class="hintlink" onClick={() => setU('help', true)}>{t('a.mn.shortcuts')}</button>
        </div>
      </div>
    </PanelFrame>
  );
}

function ChanRow(props: { c: Channel; onMenu: (c: Channel, e: MouseEvent) => void; onMove: (c: Channel, e: PointerEvent) => void }) {
  const c = () => props.c;
  const sel = () => isChannelSelected(c().id);
  const anySolo = () => channels().some(x => x.solo);
  let vg: Tweak | null = null, pg: Tweak | null = null;
  const live = () => chanById(c().id) ?? c();
  // one click opens the insert menu; a double-click gives a channel without its own insert a free
  // one (FL, named and coloured after it), else goes to that insert in the mixer
  const insClick = insertBoxClick(() => chanInsertChoice(live()), r => insertMenu(c(), r.left, r.bottom + 2));
  const volOp = (v: number) => chanOp(live(), { vol: Math.round(clamp(v, 0, 1) * 10000) / 10000 });
  const volT = () => ({ kind: 'chanVol' as const, id: c().id }), panT = () => ({ kind: 'chanPan' as const, id: c().id });
  const panOp = (v: number) => chanOp(live(), { pan: Math.round(clamp(v * 2 - 1, -1, 1) * 100) / 100 });
  const nameDown = (e: PointerEvent) => {
    if (e.button === 2) { e.stopPropagation(); props.onMenu(c(), e); return; }
    if (e.button !== 0) return;
    // Shift+click: a range of channels, Shift+Ctrl+click: one more or one less (to route them to the mixer, Ctrl+L)
    if (e.shiftKey) { e.stopPropagation(); return (e.ctrlKey || e.metaKey) ? toggleChannelSelected(c().id) : selectChannelRange(c().id); }
    selectChannel(c().id);
    if (e.ctrlKey || e.metaKey) { audition(c().id, undefined, 0.8, true); return; }
    // FL: every click opens / closes the channel's window; the Piano roll is F7, the mini roll or the menu
    toggleChannelWindow(c().id);
  };
  return (
    <div class={['crow', { sel: sel(), muted: c().mute || (anySolo() && !c().solo) }]} data-ch={c().id} style={{ height: RACK_ROW + 'px' }}
      onPointerDown={e => { if (e.button === 0 && !e.shiftKey) selectChannel(c().id); }}
      onContextMenu={e => props.onMenu(c(), e)}>
      <span class="cstrip" style={{ color: c().color }} title={t('b.rk.dragChannel')} onPointerDown={e => props.onMove(c(), e)} />
      <button class={['mini m rkm', { on: c().mute, solo: c().solo && !c().mute, quiet: anySolo() && !c().solo && !c().mute }]}
        title={t('b.pe.ledTitle', { state: t(c().mute ? 'b.pe.ledMuted' : c().solo ? 'b.pe.ledSolo' : 'b.pe.ledActive') })}
        onPointerDown={e => {
          e.stopPropagation(); e.preventDefault();
          // FL: click = mute, Ctrl+click (or right-click) = solo
          if (e.button === 2 || (e.button === 0 && (e.ctrlKey || e.metaKey))) toggleChanSolo(c()); else if (e.button === 0) toggleChanMute(c());
        }}
        onContextMenu={e => { e.preventDefault(); e.stopPropagation(); }}>{c().solo && !c().mute ? 'S' : 'M'}</button>
      <MiniKnob key={'cp' + c().id} color="var(--pan)" t={() => ((autoDisplay(panT()) ?? c().pan) + 1) / 2} title={t('b.pe.panTitle', { v: panText(autoDisplay(panT()) ?? c().pan) })}
        automated={() => isAutomated(panT())} overridden={() => isOverridden(panT())} onMenu={(x, y) => paramMenu(x, y, panT(), () => commit([panOp(0.5)], t('b.cw.panCh')), c().color)}
        onStart={() => { pg = autoTweak(panT(), t('b.cw.panCh'), v => [panOp(v)]); }} onChange={v => { pg?.move(v); say(c().name + ' · pan ' + panText(v * 2 - 1)); }}
        onEnd={() => { pg?.end(); pg = null; }} onReset={() => commit([panOp(0.5)], t('b.cw.panCh'))}
        onWheel={v => autoWheel(panT(), 'cp' + c().id, t('b.cw.panCh'), v, vv => [panOp(vv)])} />
      <MiniKnob key={'cv' + c().id} t={() => autoDisplay(volT()) ?? c().vol} title={t('b.pe.volTitle', { v: volText(autoDisplay(volT()) ?? c().vol) })}
        automated={() => isAutomated(volT())} overridden={() => isOverridden(volT())} onMenu={(x, y) => paramMenu(x, y, volT(), () => commit([volOp(VOL_UNITY)], t('b.cw.volCh')), c().color)}
        onStart={() => { vg = autoTweak(volT(), t('b.cw.volCh'), v => [volOp(v)]); }} onChange={v => { vg?.move(v); say(c().name + ' · ' + volText(v)); }}
        onEnd={() => { vg?.end(); vg = null; }} onReset={() => commit([volOp(VOL_UNITY)], t('b.cw.volCh'))}
        onWheel={v => autoWheel(volT(), 'cv' + c().id, t('b.cw.volCh'), v, vv => [volOp(vv)])} />
      <button class={['cins', { auto: c().insert == null }]} title={insTitle(c())}
        onPointerDown={e => e.stopPropagation()} onClick={insClick}
        onWheel={e => wheelInsert(chanInsertChoice(c()), e)}>{insLabel(c())}</button>
      <button class={['cname', { sel: sel() }]}
        title={t(c().kind === 'plugin' ? 'b.pe.cnameTitlePlugin' : 'b.pe.cnameTitle', { name: c().name, kind: chanKindLabel(c()) }) + (S.fxErrors[c().id] ? '\n' + t('c.fx.instNotLoaded', { e: S.fxErrors[c().id] }) : '')}
        onPointerDown={nameDown}>
        <span class="cicon" style={{ color: c().color }}><InstIcon id={channelIcon(c(), (id: number) => S.project.sources.find(s => s.id === id))} size={11} /></span>
        <span class="ell">{c().name}</span>
        <Show when={c().kind === 'keys'}><span class="ckind">INST</span></Show>
        <Show when={c().kind === 'musicbox'}><span class="ckind">MBOX</span></Show>
        <Show when={c().kind === 'plugin'}><span class={['ckind', { err: !!S.fxErrors[c().id] }]}>{S.fxErrors[c().id] ? '! VST3' : 'VST3'}</span></Show>
      </button>
    </div>
  );
}
