// Canvas rendering of the pattern windows: the Channel Rack step grid and graph editor, the
// velocity lane and the piano roll. Static parts (cell backgrounds, key rows, grid lines, the keyboard) are cached
// offscreen in `Layer`s keyed by geometry and theme; notes are drawn on top on change only.
import { shadeBands, shadeUnit } from '../lib/gridShade';
import type { Channel, Id, Note, Pattern } from '../api/types';
import { t } from '../lib/i18n';
import { mix } from '../lib/color';
import { BEAT_GAP, gridW, inScale, keyOf, loopStepsOf, noteWidth, stepAt, stepSpans, stepX, panOf, velOf } from '../lib/pattern';
import { isBlack, noteName } from '../lib/pitch';
import type { Layer } from '../ui/frameLoop';
import { rgba, T, theme } from '../ui/theme';

const MONO8 = '600 8px "Geist Mono Variable", "Geist Mono", monospace';
const MONO9 = '500 9px "Geist Mono Variable", "Geist Mono", monospace';
const SANS10 = '500 10px "Geist Variable", Geist, system-ui, sans-serif';

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}

/**
 * Step-grid geometry: cell width, scroll offsets (px), row height, rows, `end` = the pattern's
 * steps and `steps` = the steps shown (the pattern plus one greyed bar: a click there extends it).
 */
export interface RackGeo { cw: number; sx: number; sy: number; rh: number; steps: number; end: number; rows: number; /** a step button's inset in its cell (half the gap between buttons) */ pad: number }

const STEP_VPAD = 5, STEP_R = 3;
/** Unlit step colours: alternating groups of four (beats), like FL's. */
function stepOff(s: number) {
  return mix(T.fg5, Math.floor(s / 4) % 2 ? (theme.light ? 14 : 9) : (theme.light ? 34 : 30), T.bg2);
}
/** A lit step: one neutral colour for every channel (the channel colour is the row's strip); velocity = brightness. */
function stepOn(v: number, dim: boolean) {
  const c = mix(theme.light ? T.fg2 : T.fgHi, Math.round(45 + 50 * v), T.bg7);
  return dim ? mix(c, 45, T.bg7) : c;
}

/** Cell backgrounds, bar lines, the greyed extra bar. Cached: depends only on geometry and theme. */
function rackBg(g: CanvasRenderingContext2D, W: number, H: number, G: RackGeo) {
  const s0 = Math.max(0, stepAt(G.sx, G.cw)), s1 = Math.min(G.steps - 1, stepAt(G.sx + W, G.cw));
  const r0 = Math.max(0, Math.floor(G.sy / G.rh)), r1 = Math.min(G.rows - 1, Math.ceil((G.sy + H) / G.rh));
  for (let r = r0; r <= r1; r++) {
    const y = r * G.rh - G.sy;
    for (let s = s0; s <= s1; s++) {
      const x = stepX(s, G.cw) - G.sx;
      g.globalAlpha = s >= G.end ? 0.35 : 1;
      g.fillStyle = stepOff(s);
      g.beginPath(); rr(g, x + G.pad, y + STEP_VPAD, G.cw - 2 * G.pad, G.rh - 2 * STEP_VPAD, STEP_R); g.fill();
    }
  }
  g.globalAlpha = 1;
  // bar lines; the pattern's end a little stronger
  const h = Math.min(H, G.rows * G.rh - G.sy);
  for (let s = Math.ceil(s0 / 16) * 16; s <= s1 + 1; s += 16) {
    if (s <= 0 || s >= G.steps) continue;
    g.fillStyle = s === G.end ? T.line3 : T.line2;
    g.fillRect(Math.round(stepX(s, G.cw) - G.sx - BEAT_GAP / 2) - 0.5, 0, 1, h);
  }
}

export function drawRack(g: CanvasRenderingContext2D, W: number, H: number, G: RackGeo, layer: Layer, pt: Pattern, chans: Channel[], selCh: Id | null, roll: Set<Id>, anySolo: boolean) {
  g.clearRect(0, 0, W, H);
  const bg = layer.get(W, H, ['rack', G.cw, G.pad, G.sx, G.sy, G.rh, G.steps, G.end, G.rows].join('|'), (gg, w, h) => rackBg(gg, w, h, G));
  g.drawImage(bg, 0, 0, W, H);
  const vpad = STEP_VPAD;
  const r0 = Math.max(0, Math.floor(G.sy / G.rh)), r1 = Math.min(chans.length - 1, Math.ceil((G.sy + H) / G.rh));
  for (let r = r0; r <= r1; r++) {
    const c = chans[r], y = r * G.rh - G.sy;
    const dim = c.mute || (anySolo && !c.solo);
    if (c.id === selCh) { g.fillStyle = rgba(T.blue, theme.light ? 0.07 : 0.06); g.fillRect(0, y, W, G.rh); }
    // FL 20.1's channel looping: the tail dims and a line in the channel's colour marks the
    // loop's end, on every kind of row — steps, a mini roll, or an empty looped channel
    const loop = loopStepsOf(pt, c.id);
    if (loop > 0) {
      g.fillStyle = rgba('#000000', theme.light ? 0.07 : 0.14);
      g.fillRect(stepX(loop, G.cw) - G.sx, y, W, G.rh);
      g.fillStyle = rgba(c.color, 0.85);
      g.fillRect(stepX(loop, G.cw) - G.sx - 1, y + 2, 2, G.rh - 4);
    }
    const notes = pt.notes.filter(n => n.ch === c.id);
    if (!notes.length) continue;
    if (roll.has(c.id)) {
      // more than steps (lengths, chords): a mini piano roll over the pattern; a click opens the Piano roll
      const keys = notes.map(n => keyOf(n, c)), lo = Math.min(...keys), hi = Math.max(...keys);
      // the key range always fits the row: a wide range squeezes the keys, never spills into the next channel
      const span = hi - lo + 1, ih = G.rh - 2 * vpad, nh = Math.min(4, ih / span);
      const top = y + vpad + (ih - nh * span) / 2;
      g.fillStyle = T.bg2; g.beginPath(); rr(g, -G.sx, y + vpad - 1, gridW(G.end, G.cw), G.rh - 2 * vpad + 2, 2); g.fill();
      // the mini roll's background painted over the row's early boundary: redraw the tail
      // dim and the loop line above it
      if (loop > 0) {
        g.fillStyle = rgba('#000000', theme.light ? 0.07 : 0.14);
        g.fillRect(stepX(loop, G.cw) - G.sx, y, W, G.rh);
        g.fillStyle = rgba(c.color, 0.85);
        g.fillRect(stepX(loop, G.cw) - G.sx - 1, y + 2, 2, G.rh - 4);
      }
      g.save(); g.beginPath(); g.rect(0, y + vpad, W, ih); g.clip();
      for (const n of notes) {
        const x = stepX(n.step, G.cw) - G.sx, w = Math.max(2, stepX(n.step + n.len, G.cw) - G.sx - x - 1);
        if (x > W || x + w < 0) continue;
        g.fillStyle = stepOn(velOf(n), dim);
        g.fillRect(x, top + (hi - keyOf(n, c)) * nh, w, Math.max(1.5, nh - 0.5));
      }
      // the loop's repeats, faint like the step rows show them
      if (loop > 0) {
        const cell = notes.filter(n => n.step < loop);
        for (let k = 1; ; k++) {
          const s0 = k * loop;
          if (s0 >= G.end) break;
          if (stepX(s0, G.cw) - G.sx > W) break;
          for (const n of cell) {
            if (n.step + s0 >= G.end) continue;
            const x = stepX(n.step + s0, G.cw) - G.sx, w = Math.max(2, stepX(n.step + n.len + s0, G.cw) - G.sx - x - 1);
            if (x > W || x + w < 0) continue;
            g.globalAlpha = 0.38;
            g.fillStyle = stepOn(velOf(n), dim);
            g.fillRect(x, top + (hi - keyOf(n, c)) * nh, w, Math.max(1.5, nh - 0.5));
            g.globalAlpha = 1;
          }
        }
      }
      g.restore();
      continue;
    }
    // a trigger off the grid (a triplet) sits at its place inside the cell, as wide as the gap to the next one
    const spans = stepSpans(notes);
    const spanOf = new Map(notes.map((n, i) => [n, spans[i]]));
    const drawStepAt = (n: Note, step: number, alpha = 1) => {
      const x = stepX(step, G.cw) - G.sx, cw = G.cw * (spanOf.get(n) ?? 1);
      if (x > W || x + cw < 0) return;
      g.globalAlpha = alpha;
      g.fillStyle = stepOn(velOf(n), dim);
      g.beginPath(); rr(g, x + G.pad, y + vpad, Math.max(3, cw - 2 * G.pad), G.rh - 2 * vpad, Math.min(STEP_R, cw / 4)); g.fill();
      // a step with its own key (graph editor): its note name, or a tick when the cell is narrow
      if (n.p != null && n.p !== c.root) {
        g.fillStyle = T.onFill;
        if (cw >= 18) { g.font = MONO8; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(noteName(n.p), x + cw / 2, y + G.rh / 2 + 1); }
        else g.fillRect(x + cw / 2 - 1, y + G.rh - vpad - 4, 2, 2);
      }
      g.globalAlpha = 1;
    };
    notes.forEach((n, k) => drawStepAt(n, n.step));
    // FL 20.1's channel looping: the cell repeats as faint ghost steps — exactly what the
    // engine plays (repeats land inside the pattern only; the boundary and the dim are
    // drawn above, on every kind of row)
    if (loop > 0) {
      const cellSteps = notes.filter(n => n.step < loop);
      for (let k = 1; ; k++) {
        const s0 = k * loop;
        if (s0 >= G.end) break;
        if (stepX(s0, G.cw) - G.sx > W) break;
        for (const n of cellSteps) if (n.step + s0 < G.end) drawStepAt(n, n.step + s0, 0.38);
      }
    }
  }
}

/** The playhead column of the step grid (separate overlay canvas, redrawn only when the step changes).
 * `loopRows`: the looped channels' row indices and loop lengths — those rows show their cell position. */
export function drawRackHead(g: CanvasRenderingContext2D, W: number, H: number, G: RackGeo, step: number, loopRows: { row: number; loop: number }[] = []) {
  g.clearRect(0, 0, W, H);
  if (step < 0) return;
  const x = stepX(step, G.cw) - G.sx, h = Math.min(H, G.rows * G.rh - G.sy);
  g.fillStyle = rgba(T.playhead, theme.light ? 0.10 : 0.09);
  g.fillRect(x, 0, G.cw, h);
  g.fillStyle = rgba(T.playhead, 0.55);
  g.fillRect(x + 1, 0, G.cw - 2, 2);
  // a looped row plays its cell, not the pattern: its playhead is the wrapped position
  for (const { row, loop } of loopRows) {
    const y = row * G.rh - G.sy;
    if (y + G.rh < 0 || y > H) continue;
    g.clearRect(0, y, W, G.rh);
    const cx = stepX(step % loop, G.cw) - G.sx;
    g.fillStyle = rgba(T.playhead, theme.light ? 0.10 : 0.09);
    g.fillRect(cx, y + 1, G.cw, G.rh - 2);
    g.fillStyle = rgba(T.playhead, 0.55);
    g.fillRect(cx + 1, y + 1, G.cw - 2, 2);
  }
}

/** One velocity bar per note of the selected channel. `x0`: where step 0 is (px), `cw` px per step. */
export function drawLane(g: CanvasRenderingContext2D, W: number, H: number, o: {
  x0: number; cw: number; sx: number; steps: number; notes: { n: Note; i: number }[]; color: string; sel?: Set<number>; cells: boolean; muted: boolean; beatGap?: boolean;
  /** What a bar shows, 0..1 (default: the velocity); `bipolar` bars grow from the centre line (pan). */
  value?: (n: Note) => number; bipolar?: boolean;
}) {
  g.clearRect(0, 0, W, H);
  const top = 6, bh = H - top - 3;
  const valueOf = o.value ?? velOf, mid = top + bh / 2;
  const px = (s: number) => (o.beatGap ? stepX(s, o.cw) : s * o.cw);
  const endX = Math.min(W, o.x0 + (o.beatGap ? gridW(o.steps, o.cw) : o.steps * o.cw) - o.sx);
  g.fillStyle = T.vizPanel; g.fillRect(0, 0, W, H);
  g.fillStyle = T.viz; g.fillRect(o.x0, 0, endX - o.x0, H);
  g.fillStyle = T.vizGrid2;
  for (const f of [0.25, 0.5, 0.75]) g.fillRect(o.x0, Math.round(top + bh * (1 - f)) + 0.5, endX - o.x0, 1);
  g.fillStyle = T.vizAxis; g.fillRect(o.x0, top, endX - o.x0, 1);
  if (o.bipolar) {
    g.fillRect(o.x0, Math.round(mid) + 0.5, endX - o.x0, 1);
  }
  const spans = o.cells ? stepSpans(o.notes.map(x => x.n)) : [];
  o.notes.forEach(({ n, i }, k) => {
    const v = valueOf(n);
    // in cells a bar stays in its step's column, wherever in the cell the note starts (its shift)
    const x = o.x0 + px(o.cells ? Math.floor(n.step + 1e-3) : n.step) - o.sx, cw = o.cw * (spans[k] ?? 1);
    const w = o.cells ? Math.max(2, cw - 6) : Math.max(3, Math.min(8, n.len * o.cw - 2));
    const bx = o.cells ? x + (cw - w) / 2 : x;
    if (bx > W || bx + w < o.x0 - 4) return;
    const sel = !!o.sel?.has(i);
    const y = top + bh * (1 - v), base = o.bipolar ? mid : top + bh;
    g.fillStyle = rgba(o.color, (o.muted ? 0.35 : 0.75) * (sel ? 1.25 : 1));
    g.fillRect(bx, Math.min(y, base), w, Math.max(1, Math.abs(base - y)));
    g.fillStyle = sel ? T.fgHi : mix(o.color, 60, T.fgHi);
    g.fillRect(bx, y - 1, w, 2);
  });
  // which way is which, over the bars (the first step's bar sits right under the labels)
  if (o.bipolar) {
    g.fillStyle = T.fgHi; g.font = MONO8; g.textAlign = 'right'; g.textBaseline = 'middle';
    g.fillText('R', endX - 4, top + 7); g.fillText('L', endX - 4, top + bh - 6);
  }
}

/** The colour of the Piano roll lane's handles: one per target, so the lane says what it edits. */
export const laneColor = (mode: 'vel' | 'pan') => (mode === 'pan' ? T.pan : T.blue);

/**
 * The Piano roll's lane (FL's event editor): one handle per note of the channel — a stem from the
 * base line to the value, a head, and a flag as long as the note. Velocity grows from the floor, pan
 * from the centre line (up = right). Notes that start together (a chord) share a stem position; their
 * flags differ by length, and with a selection the other notes fade and the selected ones are drawn
 * last, in white: those are the ones a stroke changes.
 */
export function drawRollLane(g: CanvasRenderingContext2D, W: number, H: number, o: {
  x0: number; pps: number; sx: number; steps: number; notes: { n: Note; i: number }[]; sel: Set<number>; muted: boolean; mode: 'vel' | 'pan';
}) {
  g.clearRect(0, 0, W, H);
  const top = 7, bh = H - top - 5, pan = o.mode === 'pan';
  const endX = Math.min(W, o.x0 + o.steps * o.pps - o.sx);
  g.fillStyle = T.vizPanel; g.fillRect(0, 0, W, H);
  g.fillStyle = T.viz; g.fillRect(o.x0, 0, endX - o.x0, H);
  g.fillStyle = T.vizGrid2;
  for (const f of [0.25, 0.5, 0.75]) if (!(pan && f === 0.5)) g.fillRect(o.x0, Math.round(top + bh * (1 - f)) + 0.5, endX - o.x0, 1);
  g.fillStyle = T.vizAxis; g.fillRect(o.x0, top, endX - o.x0, 1);
  const base = pan ? Math.round(top + bh / 2) + 0.5 : top + bh;
  g.fillRect(o.x0, base, endX - o.x0, 1);
  if (pan) {
    g.fillStyle = T.fg6; g.font = MONO8; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText('R', o.x0 + 4, top + 7); g.fillText('L', o.x0 + 4, top + bh - 6);
  }
  const col = laneColor(o.mode), some = o.sel.size > 0;
  const one = ({ n, i }: { n: Note; i: number }) => {
    const x = Math.round(o.x0 + n.step * o.pps - o.sx), fw = Math.max(5, n.len * o.pps - 2);
    if (x > W || x + fw < o.x0 - 4) return;
    const sel = o.sel.has(i), y = pan ? base - (bh / 2) * panOf(n) : top + bh * (1 - velOf(n));
    const a = (o.muted ? 0.45 : 1) * (some && !sel ? 0.5 : 1), c = sel ? T.fgHi : col;
    g.fillStyle = rgba(c, 0.3 * a); g.fillRect(x, y - 1, fw, 2); // the flag: the note's length
    g.fillStyle = rgba(c, 0.85 * a); g.fillRect(x, Math.min(y, base), 2, Math.abs(y - base)); // the stem
    g.fillStyle = rgba(c, a); g.beginPath(); g.arc(x + 1, y, 3.2, 0, Math.PI * 2); g.fill(); // the head
  };
  for (const x of o.notes) if (!o.sel.has(x.i)) one(x);
  for (const x of o.notes) if (o.sel.has(x.i)) one(x);
}

/**
 * The graph editor's key lane: one bar per step of the selected channel, its height the key
 * relative to the channel's root (the middle line), ± `span` semitones. `off`: the channel is a
 * melodic line (edit it in the piano roll) — the lane says so instead.
 */
export function drawKeyGraph(g: CanvasRenderingContext2D, W: number, H: number, o: {
  cw: number; sx: number; steps: number; notes: { n: Note; i: number }[]; color: string; root: number; span: number; off: boolean;
}) {
  g.clearRect(0, 0, W, H);
  const top = 6, bh = H - top - 3, endX = Math.min(W, gridW(o.steps, o.cw) - o.sx);
  g.fillStyle = T.vizPanel; g.fillRect(0, 0, W, H);
  g.fillStyle = T.viz; g.fillRect(0, 0, endX, H);
  const yOf = (k: number) => top + bh * (1 - (k - o.root + o.span) / (2 * o.span));
  g.fillStyle = T.vizGrid2;
  for (const d of [-12, -7, -5, 5, 7, 12]) if (Math.abs(d) <= o.span) g.fillRect(0, Math.round(yOf(o.root + d)) + 0.5, endX, 1);
  g.fillStyle = T.vizAxis; g.fillRect(0, Math.round(yOf(o.root)) + 0.5, endX, 1);
  if (o.off) {
    g.fillStyle = T.fg5; g.font = SANS10; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText(t('b.rk.keyOff'), 10, H / 2);
    return;
  }
  g.font = MONO8; g.textAlign = 'center'; g.textBaseline = 'bottom';
  const spans = stepSpans(o.notes.map(x => x.n));
  for (const [j, { n }] of o.notes.entries()) {
    const k = n.p ?? o.root, cw = o.cw * spans[j];
    const x = stepX(n.step, o.cw) - o.sx, w = Math.max(2, cw - 6), bx = x + (cw - w) / 2;
    if (bx > W || bx + w < 0) continue;
    const y0 = yOf(o.root), y = yOf(Math.max(o.root - o.span, Math.min(o.root + o.span, k)));
    g.fillStyle = rgba(o.color, 0.75);
    g.fillRect(bx, Math.min(y, y0), w, Math.max(2, Math.abs(y - y0)));
    g.fillStyle = mix(o.color, 60, T.fgHi); g.fillRect(bx, y - 1, w, 2);
    if (k !== o.root && cw >= 22) { g.fillStyle = T.fg3; g.fillText(noteName(k), x + cw / 2, Math.min(y, y0) - 1); }
  }
}

/** Piano-roll geometry: px per step, scroll (px), row height, keyboard width, steps. */
export interface RollGeo { pps: number; sx: number; sy: number; rowH: number; kw: number; steps: number }
export const rollY = (G: RollGeo, key: number) => (127 - key) * G.rowH - G.sy;
export const rollX = (G: RollGeo, step: number) => G.kw + step * G.pps - G.sx;

/**
 * The note grid's colours, from the theme's tokens. Pitch is read by tone, time by lines:
 * black-key rows are a step darker than white-key rows (FL, Bitwig: a band, not a border), every
 * row has a faint seam (two white keys meet at E/F and B/C) and the octave seam under each C is
 * the strongest horizontal line. Vertically the snap grid's lines are barely there, beats are
 * clear and bars clearer, so the eye finds the bar first and the 16th only when it looks for it.
 */
export function rollPalette() {
  const L = theme.light;
  const ink = T.fgHi;
  return {
    white: L ? T.viz : mix(T.viz, 35, T.bg5),
    black: L ? mix(T.bg5, 90, T.viz) : mix(T.viz, 70, T.bg0),
    // out of the song's key: a veil over the row, so black and white keep their order beneath it
    outKey: L ? rgba(T.fg, 0.02) : rgba('#000000', 0.1),
    root: rgba(T.blue, L ? 0.12 : 0.13),
    seam: L ? rgba(ink, 0.05) : rgba('#000000', 0.55),
    octave: rgba(ink, L ? 0.2 : 0.13),
    sub: rgba(ink, L ? 0.045 : 0.035),
    beat: rgba(ink, L ? 0.11 : 0.08),
    bar: rgba(ink, L ? 0.26 : 0.2),
  };
}

function rollBg(g: CanvasRenderingContext2D, W: number, H: number, G: RollGeo, root: number, mask: number, grid: number) {
  const k0 = Math.max(0, Math.floor(127 - (G.sy + H) / G.rowH)), k1 = Math.min(127, Math.ceil(127 - G.sy / G.rowH));
  const P = rollPalette(), scaled = mask !== 0xfff;
  g.fillStyle = P.white; g.fillRect(0, 0, W, H);
  for (let k = k0; k <= k1; k++) {
    const y = rollY(G, k);
    if (isBlack(k)) { g.fillStyle = P.black; g.fillRect(G.kw, y, W - G.kw, G.rowH); }
    const isRoot = (((k - root) % 12) + 12) % 12 === 0;
    if (isRoot) { g.fillStyle = P.root; g.fillRect(G.kw, y, W - G.kw, G.rowH); }
    else if (scaled && !inScale(k, root, mask)) { g.fillStyle = P.outKey; g.fillRect(G.kw, y, W - G.kw, G.rowH); }
  }
  // vertical lines: the snap grid's own lines (16ths, triplets, ... when there is room), then
  // beats and bars over them. A grid of a beat or longer shows 16ths, like 1/16.
  const s0 = Math.max(0, Math.floor(G.sx / G.pps)), s1 = Math.ceil((G.sx + W - G.kw) / G.pps);
  // every other beat (bar when zoomed out) a shade lighter, over the key rows and under the lines (4 steps = a beat)
  g.fillStyle = T.gridShade;
  for (const [b, n] of shadeBands(s0 / 4, s1 / 4, shadeUnit(G.pps * 4))) {
    const xa = Math.max(G.kw, Math.round(rollX(G, b * 4))), xb = Math.round(rollX(G, (b + n) * 4));
    if (xb > xa) g.fillRect(xa, 0, xb - xa, H);
  }
  // a seam under every row (the octave's is drawn last, stronger)
  for (let k = k0; k <= k1; k++) {
    if (k % 12 === 0) continue;
    g.fillStyle = P.seam; g.fillRect(G.kw, Math.round(rollY(G, k) + G.rowH) - 1, W - G.kw, 1);
  }
  const u = grid > 0 && grid < 4 ? grid : 1;
  if (u * G.pps >= 7) {
    g.fillStyle = P.sub;
    for (let i = Math.floor(s0 / u); i * u <= s1; i++) {
      const s = i * u;
      if (Math.abs(s / 4 - Math.round(s / 4)) < 1e-6) continue;
      g.fillRect(Math.round(rollX(G, s)), 0, 1, H);
    }
  }
  for (let s = Math.ceil(s0 / 4) * 4; s <= s1; s += 4) {
    g.fillStyle = s % 16 === 0 ? P.bar : P.beat;
    g.fillRect(Math.round(rollX(G, s)), 0, 1, H);
  }
  // the octave seam (B under C) over the time lines, so octaves read as one block each
  g.fillStyle = P.octave;
  for (let k = Math.ceil(k0 / 12) * 12; k <= k1; k += 12) g.fillRect(G.kw, Math.round(rollY(G, k) + G.rowH) - 1, W - G.kw, 1);
  // past the pattern end: drawing there makes the pattern longer
  const endX = rollX(G, G.steps);
  if (endX < W) { g.fillStyle = T.shade; g.fillRect(Math.max(G.kw, endX), 0, W - Math.max(G.kw, endX), H); }
  // keyboard
  g.fillStyle = T.vizPanel; g.fillRect(0, 0, G.kw, H);
  for (let k = k0; k <= k1; k++) {
    const y = rollY(G, k), b = isBlack(k);
    g.fillStyle = b ? T.keyB : T.keyW;
    g.fillRect(0, y + 0.5, b ? G.kw * 0.62 : G.kw - 1, G.rowH - 1);
    if (k % 12 === 0 && G.rowH >= 9) {
      g.fillStyle = T.keyWText; g.font = MONO9; g.textBaseline = 'middle'; g.textAlign = 'right';
      g.fillText(noteName(k), G.kw - 4, y + G.rowH / 2 + 0.5);
    } else if (G.rowH >= 11 && inScale(k, root, mask)) {
      // the other notes of the song's key, by letter only (the octave is on the C): where the scale is on the keyboard
      g.fillStyle = b ? rgba(T.keyBText, 0.55) : rgba(T.keyWText, 0.5); g.font = MONO8; g.textBaseline = 'middle'; g.textAlign = 'right';
      g.fillText(noteName(k).replace(/-?\d+$/, ''), b ? G.kw * 0.62 - 4 : G.kw - 4, y + G.rowH / 2 + 0.5);
    }
  }
  g.fillStyle = T.line2; g.fillRect(G.kw - 1, 0, 1, H);
}

export function drawRoll(g: CanvasRenderingContext2D, W: number, H: number, G: RollGeo, layer: Layer, o: {
  pt: Pattern; ch: Channel; chans: Map<Id, Channel>; sel: Set<number>; root: number; mask: number;
  /** Snap grid in steps: its lines are drawn (triplet grids get triplet lines). */
  grid: number; hoverKey: number | null; lit?: number[]; marquee: { x0: number; y0: number; x1: number; y1: number } | null;
  /** Ctrl+right-drag: the box the view will zoom to (dashed, no fill: it selects nothing). */
  zoomBox?: { x0: number; y0: number; x1: number; y1: number } | null;
  /** Chord-stamp tool: what a click at this cell would write (ghosted, dashed outline). */
  stampGhost?: { s: number; len: number; pitches: number[] } | null;
}) {
  g.clearRect(0, 0, W, H);
  const bg = layer.get(W, H, ['roll', G.pps, G.sx, G.sy, G.rowH, G.kw, G.steps, o.root, o.mask, o.grid].join('|'), (gg, w, h) => rollBg(gg, w, h, G, o.root, o.mask, o.grid));
  g.drawImage(bg, 0, 0, W, H);
  g.save();
  g.beginPath(); g.rect(G.kw, 0, W - G.kw, H); g.clip();
  // ghost notes: the pattern's other channels, faint (double right-click one to edit its channel)
  for (const n of o.pt.notes) {
    if (n.ch === o.ch.id) continue;
    const c = o.chans.get(n.ch); if (!c) continue;
    const x = rollX(G, n.step), y = rollY(G, keyOf(n, c)), w = noteWidth(n, G.pps);
    if (x > W || x + w < G.kw || y > H || y + G.rowH < 0) continue;
    g.fillStyle = rgba(c.color, 0.16); g.fillRect(x, y + 1, w, G.rowH - 2);
  }
  // this channel's loop (FL 20.1's channel looping): its cell repeats, faint like the
  // other ghosts — what actually sounds past the step you are editing
  const loop = loopStepsOf(o.pt, o.ch.id);
  if (loop > 0) {
    const end = Math.round(o.pt.len * 4);
    for (const n of o.pt.notes) {
      if (n.ch !== o.ch.id || n.step >= loop) continue;
      const y = rollY(G, keyOf(n, o.ch)), w = noteWidth(n, G.pps);
      for (let k = 1; ; k++) {
        const s = n.step + k * loop;
        if (s >= end) break;
        const x = rollX(G, s);
        if (x > W) break;
        if (x + w < G.kw) continue;
        g.fillStyle = rgba(o.ch.color, 0.16);
        g.fillRect(x, y + 1, w, G.rowH - 2);
      }
    }
  }
  g.font = SANS10; g.textBaseline = 'middle'; g.textAlign = 'left';
  o.pt.notes.forEach((n, i) => {
    if (n.ch !== o.ch.id) return;
    const k = keyOf(n, o.ch), x = rollX(G, n.step), y = rollY(G, k), w = noteWidth(n, G.pps);
    if (x > W || x + w < G.kw || y > H || y + G.rowH < 0) return;
    const sel = o.sel.has(i), v = velOf(n);
    if (n.slide) {
      // FL's slide note: a note like the others, darker (it has no sound of its own), with a ramp
      // triangle at its start (the slide icon)
      g.fillStyle = sel ? mix(o.ch.color, 40, theme.light ? '#000000' : '#ffffff') : mix(o.ch.color, 38, T.viz);
      g.beginPath(); rr(g, x, y + 0.5, w, G.rowH - 1, 2.5); g.fill();
      g.strokeStyle = sel ? T.fgHi : o.ch.color; g.lineWidth = 1;
      g.beginPath(); rr(g, x + 0.5, y + 1, w - 1, G.rowH - 2, 2.5); g.stroke();
      const th = G.rowH - 5, tw = Math.min(w - 3, Math.max(5, th * 1.3));
      g.fillStyle = sel ? T.fgHi : mix(o.ch.color, 70, '#ffffff');
      g.beginPath(); g.moveTo(x + 2, y + G.rowH - 2.5); g.lineTo(x + 2 + tw, y + G.rowH - 2.5); g.lineTo(x + 2 + tw, y + G.rowH - 2.5 - th); g.closePath(); g.fill();
      if (w > tw + 26 && G.rowH >= 11) { g.fillStyle = sel ? rgba(T.onFill, 0.9) : T.fgHi; g.fillText(noteName(k), x + 5 + tw, y + G.rowH / 2 + 0.5); }
      return;
    }
    g.fillStyle = sel ? mix(o.ch.color, 55, theme.light ? '#000000' : '#ffffff') : mix(o.ch.color, Math.round(45 + 55 * v), T.viz);
    g.beginPath(); rr(g, x, y + 0.5, w, G.rowH - 1, 2.5); g.fill();
    g.strokeStyle = sel ? T.fgHi : rgba('#000000', theme.light ? 0.25 : 0.45); g.lineWidth = 1;
    g.beginPath(); rr(g, x + 0.5, y + 1, w - 1, G.rowH - 2, 2.5); g.stroke();
    // resize grip
    if (n.trig || w > 10) { g.fillStyle = rgba(T.onFill, 0.35); g.fillRect(x + w - 3, y + 3, 1, G.rowH - 6); }
    if (w > 26 && G.rowH >= 11) { g.fillStyle = rgba(T.onFill, 0.85); g.fillText(noteName(k), x + 4, y + G.rowH / 2 + 0.5); }
  });
  if (o.stampGhost) {
    const gh = o.stampGhost, w = Math.max(3, gh.len * G.pps - 1), x = rollX(G, gh.s);
    for (const k of gh.pitches) {
      const y = rollY(G, k);
      g.fillStyle = rgba(o.ch.color, 0.32);
      g.beginPath(); rr(g, x, y + 0.5, w, G.rowH - 1, 2.5); g.fill();
      g.strokeStyle = rgba(o.ch.color, 0.95); g.lineWidth = 1; g.setLineDash([3, 2]);
      g.beginPath(); rr(g, x + 0.5, y + 1, w - 1, G.rowH - 2, 2.5); g.stroke();
      g.setLineDash([]);
    }
  }
  if (o.marquee) {
    const m = o.marquee, x = Math.min(m.x0, m.x1), y = Math.min(m.y0, m.y1);
    g.fillStyle = rgba(T.blue, 0.12); g.fillRect(x, y, Math.abs(m.x1 - m.x0), Math.abs(m.y1 - m.y0));
    g.strokeStyle = rgba(T.blue, 0.8); g.strokeRect(x + 0.5, y + 0.5, Math.abs(m.x1 - m.x0), Math.abs(m.y1 - m.y0));
  }
  if (o.zoomBox) {
    const m = o.zoomBox, x = Math.min(m.x0, m.x1), y = Math.min(m.y0, m.y1);
    g.strokeStyle = T.fgHi; g.lineWidth = 1; g.setLineDash([4, 3]);
    g.strokeRect(Math.round(x) + 0.5, Math.round(y) + 0.5, Math.round(Math.abs(m.x1 - m.x0)), Math.round(Math.abs(m.y1 - m.y0)));
    g.setLineDash([]);
  }
  g.restore();
  // keys sounding: clicked on the keyboard, or played from the typing keyboard
  for (const k of o.hoverKey != null ? [o.hoverKey, ...(o.lit ?? [])] : o.lit ?? []) {
    const y = rollY(G, k);
    if (y > H || y + G.rowH < 0) continue;
    g.fillStyle = rgba(T.blue, 0.45); g.fillRect(0, y + 0.5, G.kw - 1, G.rowH - 1);
  }
}
