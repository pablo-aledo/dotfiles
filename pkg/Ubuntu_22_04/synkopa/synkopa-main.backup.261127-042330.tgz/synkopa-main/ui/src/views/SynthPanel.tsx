// The built-in synth's page in the channel window, laid out like a modern soft synth: a preset
// bar, three tabs (OSC / MOD / FX) and cards that each draw what their knobs do — the oscillator
// waveform (with unison copies), the filter's response, the envelopes and LFO shapes. Edits are
// `putChannel` (engine fast path, held notes follow).
import { For, Show } from 'solid-js';
import type { JSX } from '@solidjs/web';
import { createSignal, effect, onCleanup, onMount } from '../lib/reactive';
import type { AutoTarget, Channel, ParamDef, SynthCatalog } from '../api/types';
import { t, tName } from '../lib/i18n';
import { pFmt, pNorm, pVal } from '../lib/presets';
import { clampSynth, synthParam, synthValue, withSynthParam, withSynthPreset } from '../lib/synth';
import { autoDisplay, autoTweak, autoWheel, isAutomated, isOverridden, paramMenu, type Tweak } from '../state/automation';
import { commit, Gesture } from '../state/edit';
import { chanById, chanOp } from '../state/pattern';
import { S } from '../state/store';
import { openMenu, say, type MenuItem } from '../state/ui';
import { Knob, Segmented } from '../ui/Knob';
import { rgba, T, themeVersion } from '../ui/theme';

type SynthCh = Channel & { kind: 'synth' };
type Ctx = {
  cat: SynthCatalog; ch: () => SynthCh;
  /** The value a control shows: the automated one while it plays, else the patch's. */
  v: (id: string) => number;
  set: (id: string, x: number, label?: string) => void; def: (id: string) => ParamDef | undefined;
  /** Driven by an automation clip. */
  auto: (id: string) => boolean;
  /** The automation target of a parameter (capture/override look it up). */
  target: (id: string) => AutoTarget;
  /** The parameter's right-click menu (automate, select its clips, reset to default). */
  menu: (id: string, x: number, y: number) => void;
};

/** First wavetable (Shape is its position), the saw and square waves (params::WAVES). */
const WT_FIRST = 8, SAW = 2, SQUARE = 3;
const SLOTS = [1, 2, 3, 4, 5, 6, 7, 8];
const C_OSC = '#a78bfa', C_FLT = '#f59e0b', C_ENV = '#34d399', C_LFO = '#60a5fa', C_FX = '#f472b6';
type Tab = 'osc' | 'mod' | 'fx';
const [lastTab, setLastTab] = createSignal<Tab>('osc');

export function SynthPanel(props: { c: Channel }) {
  const cat = () => S.catalog?.synth as SynthCatalog | undefined;
  return (
    <Show when={cat()} fallback={<div class="note" style={{ padding: '14px' }}>{t('b.sp.unavailable')}</div>}>
      {c => <Panel cat={c()} c={props.c} />}
    </Show>
  );
}

function Panel(props: { cat: SynthCatalog; c: Channel }) {
  const ch = () => (chanById(props.c.id) ?? props.c) as SynthCh;
  const target = (id: string) => ({ kind: 'synth' as const, chanId: ch().id, param: id });
  const v = (id: string) => autoDisplay(target(id)) ?? synthValue(props.cat, ch().synth, id);
  const def = (id: string) => synthParam(props.cat, id);
  const set = (id: string, x: number, label?: string) => {
    const d = def(id); if (!d) return;
    commit([chanOp(withSynthParam(props.cat, ch(), id, clampSynth(d, x)))], label ?? tName(d.label));
  };
  const auto = (id: string) => isAutomated(target(id));
  const menu = (id: string, x: number, y: number) => {
    const d = def(id); if (!d) return;
    paramMenu(x, y, target(id), () => set(id, d.def), ch().color);
  };
  const ctx: Ctx = { cat: props.cat, ch, v, set, def, auto, target, menu };
  const presetName = () => ch().synth.preset;
  const list = () => props.cat.presets;
  const load = (name: string) => { commit([chanOp(withSynthPreset(props.cat, ch(), name))], t('b.sp.presetUndo')); say(t('b.sp.presetSay', { name: tName(name) })); };
  const step = (d: number) => {
    if (!list().length) return;
    const i = list().findIndex(p => p.name === presetName());
    load(list()[(i + d + list().length) % list().length].name);
  };
  const pick = (x: number, y: number) => {
    const items: MenuItem[] = [{ t: 'title', label: t('b.sp.presets') }];
    for (const g of props.cat.categories) {
      const ps = props.cat.presets.filter(p => p.category === g);
      if (ps.length) items.push({ t: 'sub', label: tName(g), items: ps.map(p => ({ t: 'item', label: tName(p.name), kbd: p.name === presetName() ? '●' : '', act: () => load(p.name) }) as MenuItem) });
    }
    openMenu(x, y, items, 360);
  };
  return (
    <div class="syn">
      <div class="syn-top">
        <div class="syn-preset">
          <button class="arrow" title={t('b.sp.prev')} onClick={() => step(-1)}>‹</button>
          <button class="name" onClick={e => { const r = e.currentTarget.getBoundingClientRect(); pick(r.left, r.bottom + 4); }} title={t('b.sp.choose')}>
            <span class="ell">{presetName() ? tName(presetName()!) : t('b.sp.custom')}</span>
            <span class="cat">{tName(list().find(p => p.name === presetName())?.category ?? '') || t('b.sp.edited')}</span>
          </button>
          <button class="arrow" title={t('b.sp.next')} onClick={() => step(1)}>›</button>
        </div>
        <div class="syn-tabs">
          <For each={[['osc', 'OSC'], ['mod', 'MOD'], ['fx', 'FX']] as [Tab, string][]}>{([id, l]) =>
            <button class={{ on: lastTab() === id }} onClick={() => setLastTab(id)}>{l}</button>}</For>
        </div>
        <div class="syn-voice">
          <Choice ctx={ctx} id="v_mode" />
          <K ctx={ctx} id="v_glide" label="Glide" />
          <K ctx={ctx} id="fx_out" label={t('b.sp.output')} />
        </div>
      </div>
      <Macros ctx={ctx} />
      <Show when={lastTab() === 'osc'}><OscTab ctx={ctx} /></Show>
      <Show when={lastTab() === 'mod'}><ModTab ctx={ctx} /></Show>
      <Show when={lastTab() === 'fx'}><FxTab ctx={ctx} /></Show>
    </div>
  );
}

// ------------------------------------------------------------------ tabs

function OscTab(props: { ctx: Ctx }) {
  const c = props.ctx;
  return (
    <div class="syn-grid osc">
      <Osc ctx={c} n={1} />
      <Osc ctx={c} n={2} />
      <Card title={t('b.sp.subNoise')} color={C_OSC} class="sub">
        <div class="syn-row"><K ctx={c} id="sub_level" label="Sub" color={C_OSC} /><Choice ctx={c} id="sub_oct" /></div>
        <div class="syn-row"><K ctx={c} id="noise_level" label={t('b.sp.noise')} color={C_OSC} /><K ctx={c} id="noise_color" label={t('b.sp.colour')} color={C_OSC} /></div>
      </Card>
      <Card title={t('b.sp.filter')} color={C_FLT} class="flt" head={<Choice ctx={c} id="flt_type" />}>
        <Plot draw={(g, w, h) => drawFilter(g, w, h, c)} deps={() => [c.v('flt_type'), c.v('flt_cutoff'), c.v('flt_res'), c.v('flt_drive')]} />
        <div class="syn-row">
          <K ctx={c} id="flt_cutoff" label="Cutoff" color={C_FLT} size="md" />
          <K ctx={c} id="flt_res" label={t('b.sp.resonance')} color={C_FLT} size="md" />
          <K ctx={c} id="flt_drive" label="Drive" color={C_FLT} />
          <K ctx={c} id="flt_env" label={t('b.sp.envelope')} color={C_FLT} />
          <K ctx={c} id="flt_key" label="Key" color={C_FLT} />
        </div>
      </Card>
      <Card title="Unison" color={C_OSC} class="uni">
        <Choice ctx={c} id="uni_voices" />
        <div class="syn-row"><K ctx={c} id="uni_detune" label="Detune" color={C_OSC} /><K ctx={c} id="uni_width" label={t('b.sp.width')} color={C_OSC} /></div>
      </Card>
      <Card title={t('b.sp.ampEnv')} color={C_ENV} class="amp">
        <Plot draw={(g, w, h) => drawAdsr(g, w, h, c, 'amp')} deps={() => [c.v('amp_a'), c.v('amp_d'), c.v('amp_s'), c.v('amp_r')]} />
        <div class="syn-row">
          <K ctx={c} id="amp_a" label={t('b.sp.attack')} color={C_ENV} /><K ctx={c} id="amp_d" label={t('b.sp.decay')} color={C_ENV} />
          <K ctx={c} id="amp_s" label={t('b.sp.sustain')} color={C_ENV} /><K ctx={c} id="amp_r" label={t('b.sp.release')} color={C_ENV} />
        </div>
      </Card>
    </div>
  );
}

function ModTab(props: { ctx: Ctx }) {
  const c = props.ctx;
  return (
    <div class="syn-grid mod">
      <Card title={t('b.sp.modEnv')} color={C_ENV} class="menv">
        <Plot draw={(g, w, h) => drawAdsr(g, w, h, c, 'mod')} deps={() => [c.v('mod_a'), c.v('mod_d'), c.v('mod_s'), c.v('mod_r')]} />
        <div class="syn-row">
          <K ctx={c} id="mod_a" label={t('b.sp.attack')} color={C_ENV} /><K ctx={c} id="mod_d" label={t('b.sp.decay')} color={C_ENV} />
          <K ctx={c} id="mod_s" label={t('b.sp.sustain')} color={C_ENV} /><K ctx={c} id="mod_r" label={t('b.sp.release')} color={C_ENV} />
        </div>
      </Card>
      <For each={[1, 2]}>{n => (
        <Card title={'LFO ' + n} color={C_LFO} class={'lfo' + n} head={<Choice ctx={c} id={`l${n}_wave`} />}>
          <Plot draw={(g, w, h) => drawLfo(g, w, h, c.v(`l${n}_wave`))} deps={() => [c.v(`l${n}_wave`)]} />
          <div class="syn-row">
            <K ctx={c} id={`l${n}_rate`} label={t('b.sp.rate')} color={C_LFO} />
            <K ctx={c} id={`l${n}_rise`} label={t('b.sp.rise')} color={C_LFO} />
            <Choice ctx={c} id={`l${n}_sync`} />
          </div>
        </Card>
      )}</For>
      <Card title={t('b.sp.matrix')} color={C_LFO} class="matrix">
        <div class="syn-mgrid">
          <For each={SLOTS}>{n => (
            <div class={['syn-mrow', { off: c.v(`m${n}_src`) === 0 }]}>
              <span class="slot">{n}</span>
              <Choice ctx={c} id={`m${n}_src`} bare />
              <span class="to">→</span>
              <Choice ctx={c} id={`m${n}_dst`} bare />
              <AmtBar ctx={c} id={`m${n}_amt`} />
            </div>
          )}</For>
        </div>
      </Card>
    </div>
  );
}

function FxTab(props: { ctx: Ctx }) {
  const c = props.ctx;
  return (
    <div class="syn-grid fx">
      <Card title="Drive" color={C_FX}><div class="syn-row"><K ctx={c} id="fx_drive" label={t('b.sp.overdrive')} color={C_FX} size="md" /></div></Card>
      <Card title="Chorus" color={C_FX}><div class="syn-row"><K ctx={c} id="fx_chorus" label={t('b.sp.amount')} color={C_FX} size="md" /></div></Card>
      <Card title="Delay" color={C_FX}>
        <div class="syn-row"><K ctx={c} id="fx_delay" label={t('b.sp.amount')} color={C_FX} size="md" /><K ctx={c} id="fx_dfb" label={t('b.sp.feedback')} color={C_FX} /></div>
        <Choice ctx={c} id="fx_dtime" />
      </Card>
      <Card title="Reverb" color={C_FX}><div class="syn-row"><K ctx={c} id="fx_reverb" label={t('b.sp.amount')} color={C_FX} size="md" /><K ctx={c} id="fx_rsize" label={t('b.sp.size')} color={C_FX} /></div></Card>
    </div>
  );
}

function Osc(props: { ctx: Ctx; n: 1 | 2 }) {
  const c = props.ctx, p = 'o' + props.n + '_';
  return (
    <Card title={t('b.sp.osc', { n: props.n })} color={C_OSC} class={'osc' + props.n} head={<Choice ctx={c} id={p + 'wave'} bare />}
      dim={c.v(p + 'level') <= 0}>
      <Plot draw={(g, w, h) => drawOsc(g, w, h, c, props.n)}
        deps={() => [c.v(p + 'wave'), c.v(p + 'shape'), c.v(p + 'level'), c.v(p + 'warp'), c.v(p + 'wamt'), c.v('o1_coarse'), c.v('o2_coarse'), c.v('o2_fine'), c.v('o1_wave'), c.v('o2_wave'), c.v('uni_voices'), c.v('uni_detune')]} />
      <div class="syn-row">
        <K ctx={c} id={p + 'level'} label={t('b.sp.level')} color={C_OSC} size="md" />
        <K ctx={c} id={p + 'shape'} label={c.v(p + 'wave') >= WT_FIRST ? t('b.sp.position') : t('b.sp.shape')} color={C_OSC} />
        <K ctx={c} id={p + 'coarse'} label={t('b.sp.coarse')} color={C_OSC} />
        <Show when={props.n === 2}><K ctx={c} id="o2_fine" label="Fine" color={C_OSC} /></Show>
      </div>
      <div class="syn-row syn-warp">
        <Choice ctx={c} id={p + 'warp'} select />
        <div class={{ 'syn-off': c.v(p + 'warp') === 0 }} title={c.v(p + 'warp') === 0 ? t('b.sp.warpOff') : undefined}>
          <K ctx={c} id={p + 'wamt'} label={t('b.sp.warp')} color={C_OSC} />
        </div>
      </div>
    </Card>
  );
}

// ------------------------------------------------------------------ building blocks

function Card(props: { title: string; color: string; class?: string; head?: JSX.Element; dim?: boolean; children: JSX.Element }) {
  return (
    <div class={['syn-card ' + (props.class ?? ''), { dim: !!props.dim }]} style={{ '--sc': props.color }}>
      <div class="syn-chd"><span class="t">{props.title}</span><div style={{ flex: 1 }} />{props.head}</div>
      {props.children}
    </div>
  );
}

function K(props: { ctx: Ctx; id: string; label: string; color?: string; size?: 'sm' | 'md' }) {
  const d = () => props.ctx.def(props.id);
  let g: Tweak | null = null;
  const staticOps = (p: ParamDef, t: number) => [chanOp(withSynthParam(props.ctx.cat, props.ctx.ch(), props.id, pVal(p, t)))];
  return (
    <Show when={d()}>{p => (
      <Knob key={'syn' + props.id} label={props.label} size={props.size ?? 'sm'} color={props.color}
        t={() => pNorm(p(), props.ctx.v(props.id))} text={() => pFmt(p(), props.ctx.v(props.id))}
        zero={() => (p().min < 0 && p().max > 0 && !p().log ? pNorm(p(), 0) : 0)}
        title={t('b.sp.knobTitle', { label: tName(p().label) })}
        onStart={() => { g = autoTweak(props.ctx.target(props.id), props.label, t => staticOps(p(), t), { color: props.color }); }}
        onChange={t => { g?.move(t); say(props.label + ' ' + pFmt(p(), pVal(p(), t))); }}
        onEnd={() => { g?.end(); g = null; }}
        onReset={() => props.ctx.set(props.id, p().def, props.label)}
        automated={() => props.ctx.auto(props.id)}
        overridden={() => isOverridden(props.ctx.target(props.id))}
        onMenu={(x, y) => props.ctx.menu(props.id, x, y)}
        onWheel={t => autoWheel(props.ctx.target(props.id), 'syn' + props.id, props.label, t, t2 => staticOps(p(), t2), { color: props.color })} />
    )}</Show>
  );
}

function Choice(props: { ctx: Ctx; id: string; bare?: boolean; select?: boolean }) {
  const d = () => props.ctx.def(props.id);
  return (
    <Show when={d()?.options}>{opts => (
      <Show when={opts().length <= 5 && !props.select} fallback={
        <select class={['sel syn-sel', { auto: props.ctx.auto(props.id) }]} title={tName(d()!.label)} value={String(Math.round(props.ctx.v(props.id)))} onChange={e => props.ctx.set(props.id, +e.currentTarget.value)}
          onContextMenu={e => { e.preventDefault(); e.stopPropagation(); props.ctx.menu(props.id, e.clientX, e.clientY); }}>
          <For each={opts()}>{(o, i) => <option value={String(i())}>{tName(o)}</option>}</For>
        </select>}>
        <Segmented small options={opts().map(o => tName(o))} value={() => Math.round(props.ctx.v(props.id))} pick={i => props.ctx.set(props.id, i)} title={tName(d()!.label)}
          onMenu={(x, y) => props.ctx.menu(props.id, x, y)} />
      </Show>
    )}</Show>
  );
}

/** Bipolar amount as a horizontal bar from the centre (drag ↔, 2× klik = 0). */
function AmtBar(props: { ctx: Ctx; id: string }) {
  const v = () => props.ctx.v(props.id);
  const down = (e: PointerEvent) => {
    if (e.button !== 0) return; e.preventDefault();
    const el = e.currentTarget as HTMLElement, r = el.getBoundingClientRect();
    if (e.detail === 2) { props.ctx.set(props.id, 0, t('b.sp.modAmt')); return; }
    const g = new Gesture(t('b.sp.modAmt'));
    const at = (x: number) => { const amt = Math.max(-1, Math.min(1, ((x - r.left) / r.width) * 2 - 1)); g.update([chanOp(withSynthParam(props.ctx.cat, props.ctx.ch(), props.id, Math.round(amt * 100)))]); say(t('b.sp.amtSay', { n: Math.round(amt * 100) })); };
    at(e.clientX);
    const mv = (ev: PointerEvent) => at(ev.clientX);
    const up = () => { g.end(); window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  };
  return (
    <div class={['syn-amt', { auto: props.ctx.auto(props.id) }]} onPointerDown={down} title={t('b.sp.amtTitle')}
      onContextMenu={e => { e.preventDefault(); e.stopPropagation(); props.ctx.menu(props.id, e.clientX, e.clientY); }}>
      <div class="fill" style={{ left: (v() < 0 ? 50 + v() / 2 : 50) + '%', width: Math.abs(v()) / 2 + '%' }} />
      <span>{(v() > 0 ? '+' : '') + Math.round(v())}%</span>
    </div>
  );
}

/** The four macros, on every tab. Each is named after what the matrix routes it to (Serum-style:
 * a preset's main gestures on four knobs); an unrouted macro says how to route it. */
function Macros(props: { ctx: Ctx }) {
  const c = props.ctx;
  const targets = (n: number) => {
    const src = 8 + n, out: string[] = [];
    for (const s of SLOTS) {
      if (Math.round(c.v(`m${s}_src`)) !== src || c.v(`m${s}_amt`) === 0) continue;
      const name = c.def(`m${s}_dst`)?.options?.[Math.round(c.v(`m${s}_dst`))];
      if (name && !out.includes(tName(name))) out.push(tName(name));
    }
    return out;
  };
  return (
    <div class="syn-macros">
      <span class="t">{t('b.sp.macros')}</span>
      <For each={[1, 2, 3, 4]}>{n => {
        const tg = () => targets(n);
        return (
          <div class={['syn-macro', { free: !tg().length }]} title={tg().length ? `Macro ${n} → ${tg().join(', ')}` : t('b.sp.macroFree', { n })}>
            <K ctx={c} id={`macro${n}`} label={tg().length ? tg()[0] + (tg().length > 1 ? ` +${tg().length - 1}` : '') : `Macro ${n}`} color={C_LFO} />
          </div>
        );
      }}</For>
    </div>
  );
}

/** A canvas that redraws when its deps or the theme change. */
function Plot(props: { draw: (g: CanvasRenderingContext2D, w: number, h: number) => void; deps: () => unknown[] }) {
  let cv!: HTMLCanvasElement;
  const paint = () => {
    const w = cv.clientWidth, h = cv.clientHeight; if (!w || !h) return;
    const dpr = window.devicePixelRatio || 1;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const g = cv.getContext('2d')!;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    props.draw(g, w, h);
  };
  onMount(() => { const ro = new ResizeObserver(paint); ro.observe(cv); onCleanup(() => ro.disconnect()); });
  effect(() => { props.deps(); themeVersion(); paint(); });
  return <canvas ref={cv} class="syn-plot" />;
}

// ------------------------------------------------------------------ drawings

function grid(g: CanvasRenderingContext2D, w: number, h: number, cols = 8, rows = 4) {
  g.fillStyle = T.viz; g.fillRect(0, 0, w, h);
  g.strokeStyle = T.vizGrid; g.lineWidth = 1; g.beginPath();
  for (let i = 1; i < cols; i++) { const x = Math.round(i * w / cols) + 0.5; g.moveTo(x, 0); g.lineTo(x, h); }
  for (let i = 1; i < rows; i++) { const y = Math.round(i * h / rows) + 0.5; g.moveTo(0, y); g.lineTo(w, y); }
  g.stroke();
}

/** Wave `w` at shape/position `s` ∈ [0,1], phase x ∈ [0,1): the engine's own tables (`catalog.waves`),
 * frames crossfaded like the oscillator; Square is a pulse of width 0.5 − 0.45·s made of two saws. */
function tableAt(waves: number[][][], w: number, s: number, x: number): number {
  const read = (f: number[], ph: number) => { const n = f.length, y = (ph - Math.floor(ph)) * n, i = Math.floor(y) % n, fr = y - Math.floor(y); return f[i] + (f[(i + 1) % n] - f[i]) * fr; };
  if (w === SQUARE) { const saw = waves[SAW]?.[0]; return saw ? (read(saw, x) - read(saw, x + 0.5 - 0.45 * s)) * 0.5 : 0; }
  const fr = waves[w]; if (!fr?.length) return 0;
  const pos = s * (fr.length - 1), f0 = Math.min(fr.length - 1, Math.floor(pos)), k = pos - f0;
  const a = read(fr[f0], x);
  return k > 1e-4 ? a + (read(fr[Math.min(fr.length - 1, f0 + 1)], x) - a) * k : a;
}

/** A warp's table phase and gain at phase x (mirrors `voice::warp_phase`); `m` is the FM modulator. */
function warpAt(mode: number, a: number, x: number, m: number): [number, number] {
  const frac = (v: number) => v - Math.floor(v);
  switch (mode) {
    case 1: { const e = Math.min(x, 1 - x), win = 0.035, s = Math.sin(Math.min(1, e / win) * Math.PI / 2);
      return [frac(x * (1 + 7 * a)), e < win ? 1 - Math.min(1, a * 6) * (1 - s * s) : 1]; }
    case 2: { const y = 2 * x - 1; return [0.5 + 0.5 * ((1 - a) * y + a * y * y * y), 1]; }
    case 3: { const b = 0.95 * a / (Math.PI * 2), q1 = frac(x + b * Math.sin(Math.PI * 2 * x)); return [frac(q1 + b * Math.sin(Math.PI * 2 * q1)), 1]; }
    case 4: return [frac(x + a * m), 1];
    default: return [x, 1];
  }
}

function drawOsc(g: CanvasRenderingContext2D, w: number, h: number, c: Ctx, n: 1 | 2) {
  grid(g, w, h);
  const p = 'o' + n + '_', wave = Math.round(c.v(p + 'wave')), s = c.v(p + 'shape') / 100, lvl = c.v(p + 'level') / 100;
  const voices = [1, 3, 5, 7][Math.round(c.v('uni_voices'))] ?? 1, det = c.v('uni_detune') / 100;
  const mid = h / 2, amp = (h / 2 - 6) * Math.max(0.15, lvl);
  const waves = c.cat.waves ?? [];
  const mode = Math.round(c.v(p + 'warp')), wa = c.v(p + 'wamt') / 100;
  // FM: the other oscillator at its pitch ratio is the modulator
  const o = n === 1 ? 'o2_' : 'o1_', ratio = Math.pow(2, ((n === 1 ? 1 : -1) * (c.v('o2_coarse') + c.v('o2_fine') / 100 - c.v('o1_coarse'))) / 12);
  const ow = Math.round(c.v(o + 'wave')), os = c.v(o + 'shape') / 100;
  const at = (x: number) => {
    const [q, gain] = warpAt(mode, wa, x, mode === 4 ? tableAt(waves, ow, os, x * ratio) : 0);
    return tableAt(waves, wave, s, q) * gain;
  };
  // a wavetable's neighbouring frames, faint behind the one that plays
  const fr = wave === SQUARE ? 0 : (waves[wave]?.length ?? 0);
  if (fr > 2) {
    for (let f = 0; f < fr; f++) {
      g.beginPath();
      for (let i = 0; i <= w; i += 2) { const y = mid - tableAt(waves, wave, f / (fr - 1), (i / w * 2) % 1) * amp; i ? g.lineTo(i, y) : g.moveTo(i, y); }
      g.strokeStyle = rgba(C_OSC, 0.07); g.lineWidth = 1; g.stroke();
    }
  }
  const path = (phase: number) => {
    g.beginPath();
    for (let i = 0; i <= w; i++) { const x = ((i / w) * 2 + phase) % 1; const y = mid - at(x) * amp; i ? g.lineTo(i, y) : g.moveTo(i, y); }
  };
  // unison copies: faint, phase-spread by the detune
  for (let k = 1; k < voices; k++) { path(((k * 0.618) % 1) * det * 0.5); g.strokeStyle = rgba(C_OSC, 0.18); g.lineWidth = 1.5; g.stroke(); }
  path(0);
  g.lineTo(w, mid); g.lineTo(0, mid); g.closePath();
  g.fillStyle = rgba(C_OSC, 0.12); g.fill();
  path(0); g.strokeStyle = C_OSC; g.lineWidth = 2; g.shadowColor = rgba(C_OSC, 0.6); g.shadowBlur = 6; g.stroke(); g.shadowBlur = 0;
}

function drawFilter(g: CanvasRenderingContext2D, w: number, h: number, c: Ctx) {
  grid(g, w, h, 10, 4);
  const type = Math.round(c.v('flt_type')), fc = c.v('flt_cutoff'), res = c.v('flt_res') / 100;
  const Q = 0.707 * Math.pow(18, res * res);
  const top = 18, bot = -36, ydb = (db: number) => (top - Math.max(bot, Math.min(top, db))) / (top - bot) * h;
  g.font = '10px monospace'; g.fillStyle = T.vizLabel;
  for (const f of [100, 1000, 10000]) { const x = Math.log(f / 20) / Math.log(1000) * w; g.fillText(f >= 1000 ? f / 1000 + 'k' : String(f), x + 3, h - 4); }
  g.beginPath();
  for (let i = 0; i <= w; i++) {
    const f = 20 * Math.pow(1000, i / w), x = f / fc;
    const re = 1 - x * x, im = x / Q, den = re * re + im * im;
    let mag2: number;
    if (type === 0) mag2 = 1 / den;
    else if (type === 1) mag2 = 1 / (den * den);
    else if (type === 2) mag2 = im * im / den;
    else if (type === 3) mag2 = (x ** 4) / den;
    else mag2 = (re * re) / den;
    const db = 10 * Math.log10(Math.max(1e-9, mag2));
    i ? g.lineTo(i, ydb(db)) : g.moveTo(i, ydb(db));
  }
  g.strokeStyle = C_FLT; g.lineWidth = 2; g.shadowColor = rgba(C_FLT, 0.6); g.shadowBlur = 6; g.stroke(); g.shadowBlur = 0;
  g.lineTo(w, h); g.lineTo(0, h); g.closePath(); g.fillStyle = rgba(C_FLT, 0.12); g.fill();
  const xc = Math.log(fc / 20) / Math.log(1000) * w;
  g.fillStyle = C_FLT; g.beginPath(); g.arc(xc, ydb(0), 4, 0, Math.PI * 2); g.fill();
}

function drawAdsr(g: CanvasRenderingContext2D, w: number, h: number, c: Ctx, k: 'amp' | 'mod') {
  grid(g, w, h, 8, 4);
  const a = c.v(k + '_a'), d = c.v(k + '_d'), s = c.v(k + '_s') / 100, r = c.v(k + '_r');
  // each stage gets width ∝ log of its time, the sustain a fixed hold
  const lw = (t: number) => Math.log10(1 + t);
  const hold = 1.4, tot = lw(a) + lw(d) + hold + lw(r);
  const sx = (w - 8) / tot, x0 = 4, top = 8, bot = h - 6, y = (lv: number) => bot - lv * (bot - top);
  const xa = x0 + lw(a) * sx, xd = xa + lw(d) * sx, xs = xd + hold * sx, xr = xs + lw(r) * sx;
  g.beginPath(); g.moveTo(x0, y(0));
  for (let i = 1; i <= 24; i++) { const t = i / 24; g.lineTo(x0 + (xa - x0) * t, y(1 - Math.pow(1 - t, 2.2))); }
  for (let i = 1; i <= 24; i++) { const t = i / 24; g.lineTo(xa + (xd - xa) * t, y(s + (1 - s) * Math.pow(1 - t, 3))); }
  g.lineTo(xs, y(s));
  for (let i = 1; i <= 24; i++) { const t = i / 24; g.lineTo(xs + (xr - xs) * t, y(s * Math.pow(1 - t, 3))); }
  g.strokeStyle = C_ENV; g.lineWidth = 2; g.shadowColor = rgba(C_ENV, 0.6); g.shadowBlur = 6; g.stroke(); g.shadowBlur = 0;
  g.lineTo(xr, bot); g.lineTo(x0, bot); g.closePath(); g.fillStyle = rgba(C_ENV, 0.12); g.fill();
  g.fillStyle = C_ENV;
  for (const [px, py] of [[xa, y(1)], [xd, y(s)], [xs, y(s)], [xr, y(0)]]) { g.beginPath(); g.arc(px, py, 3.5, 0, Math.PI * 2); g.fill(); }
  g.font = '10px monospace'; g.fillStyle = T.vizLabel;
  g.fillText('A', (x0 + xa) / 2 - 3, h - 2); g.fillText('D', (xa + xd) / 2 - 3, h - 2); g.fillText('S', (xd + xs) / 2 - 3, h - 2); g.fillText('R', (xs + xr) / 2 - 3, h - 2);
}

function drawLfo(g: CanvasRenderingContext2D, w: number, h: number, wave: number) {
  grid(g, w, h, 8, 2);
  const mid = h / 2, amp = h / 2 - 8, wv = Math.round(wave);
  const hold = [0.6, -0.3, 0.9, -0.7, 0.2, -0.9, 0.5, 0.1];
  g.beginPath();
  for (let i = 0; i <= w; i++) {
    const x = (i / w) * 2 % 1, cyc = Math.floor((i / w) * 2);
    const y = wv === 0 ? Math.sin(Math.PI * 2 * x) : wv === 1 ? 1 - 4 * Math.abs(x - 0.5) : wv === 2 ? 1 - 2 * x : wv === 3 ? (x < 0.5 ? 1 : -1) : hold[(cyc * 4 + Math.floor(x * 4)) % hold.length];
    const py = mid - y * amp; i ? g.lineTo(i, py) : g.moveTo(i, py);
  }
  g.strokeStyle = C_LFO; g.lineWidth = 2; g.shadowColor = rgba(C_LFO, 0.6); g.shadowBlur = 6; g.stroke(); g.shadowBlur = 0;
}

