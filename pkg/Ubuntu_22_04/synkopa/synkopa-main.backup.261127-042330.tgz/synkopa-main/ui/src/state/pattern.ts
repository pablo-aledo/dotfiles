// Pattern commands: the current pattern (FL's pattern selector), the Channel Rack and Piano roll
// windows, pattern and channel edits, auditions and the pattern loop preview.
// Every edit is an op (putPattern / putChannel / removeChannel) and one undo step.
import { createRoot } from 'solid-js';
import { createSignal, watch } from '../lib/reactive';
import { inFilter, liveFilter, type RackFilter } from '../lib/rackGroups';
import { topFloating } from './winOrder';
import { t, tName } from '../lib/i18n';
import { newSynthChannel } from '../lib/synth';
import { nextChannelColor } from '../lib/color';
import { prefs } from './prefs';
import { be } from '../api/backend';
import { keysInstrument } from '../lib/keysCatalog';
import { KEYS_DEFAULT_INSTRUMENT, KEYS_DYNAMICS, MB_BODY, MB_BRIGHTNESS, MB_MECHANICAL, MB_RELEASE, MB_RING, MB_SPREAD, SAMPLE_ROOT, samplerDefault, TOTAL_BEATS, VOL_UNITY, type Channel, type Id, type LibFile, type Note, type Op, type Pattern, type PluginInfo } from '../api/types';
import { baseName, clamp, mod } from '../lib/format';
import { BAR, barsText, burnChannelLoop, cloneNotes, loopStepsOf, notesText, setChannelLoop, stepsOf } from '../lib/pattern';
import { fitOnScreen, rackFitWidth } from '../lib/rack';
import { dockKeyAction } from '../lib/layout';
import { commit, enqueue } from './edit';
import { newTrack } from '../lib/clipOps';
import { planMoveNotes } from '../lib/moveNotes';
import { allocId, plain, plainNotes, rawOf, S } from './store';
import { curBeat, tele } from './telemetry';
import { loopSpan, type BeatRange } from '../lib/patLoop';
import { docked, say, setU, tucked, U } from './ui';
import { warnIfNoAudio } from './audioWatch';
import { markPlayCmd } from './telemetry';
import { leaveMixView } from './mixView';
import { planRoute, rangeSelect, toggleSelect } from '../lib/mixer';

/** Channel Rack geometry shared with the view (sizes the window to its content). */
export const RACK_LEFT = 212, RACK_HEAD = 34, RACK_ROW = 32;
/** Frame around the step grid (px): left of the first step and right of the last; above and below the rows. */
export const RACK_PAD_X = 10, RACK_PAD_Y = 8;
/**
 * Channel Rack step cell width and the inset of its button (px), per the "Step spacing" setting.
 * Every spacing keeps a 16 px button; only the gap between neighbours grows (4 / 8 / 12 px).
 * Fixed per setting: resizing the window shows more or fewer steps (the grid scrolls) instead of
 * stretching or squeezing them.
 */
export const RACK_SPACINGS = { normal: { cw: 20, pad: 2 }, roomy: { cw: 24, pad: 4 }, wide: { cw: 28, pad: 6 } } as const;
export type RackSpacing = keyof typeof RACK_SPACINGS;
const spacing = () => RACK_SPACINGS[prefs().rackSpacing] ?? RACK_SPACINGS.normal;
/** Step cell width in the Channel Rack (px). */
export const stepW = () => spacing().cw;
/** Inset of a step button inside its cell (px): half the gap between two buttons. */
export const stepPad = () => spacing().pad;
/** The Channel Rack window's narrowest width (px). */
export const RACK_MIN_W = 480;

/** The pattern the engine loops on its own (PAT mode / preview). */
let previewId: Id | null = null;

const PCOLORS = ['#4f8ef7', '#e0a44a', '#7c8cf8', '#47b8a8', '#d9678f', '#5fbf8a', '#9a8cf0', '#69c3d6'];

export const patById = (id: Id | undefined | null) => (id == null ? undefined : S.project.patterns.find(p => p.id === id));
export const chanById = (id: Id | undefined | null) => (id == null ? undefined : S.project.channels?.find(c => c.id === id));
export const channels = () => S.project.channels ?? [];
/** The current pattern (the toolbar's pattern selector); the first one when it is gone. */
export const curPat = () => patById(U.pat) ?? S.project.patterns[0];
/** The selected channel (Piano roll, graph editor, typing keyboard); the first one when it is gone. */
export const selChan = () => chanById(U.selCh) ?? channels()[0];

// ---------------------------------------------------------------- current pattern

/** Make `id` the current pattern (FL's pattern selector): the rack, the roll and PAT mode follow, and the playlist paints it. */
export function setCurPattern(id: Id, quiet = false) {
  const pt = patById(id); if (!pt) return;
  // keep the selected channel; with none yet, the first one this pattern plays
  const selCh = chanById(U.selCh) ? U.selCh : channels().find(c => pt.notes.some(n => n.ch === c.id))?.id ?? channels()[0]?.id ?? null;
  setU({ pat: id, selCh, cur: { kind: 'pat', ref: id, clipId: null } });
  if (!quiet) say(t('b.st.curPat', { n: S.project.patterns.indexOf(pt) + 1, name: pt.name }));
}
createRoot(() => {
  // a pattern picked in the playlist or the browser (the paint brush) becomes the current one
  // (its fields, not its identity: a store write merges into the same object)
  watch(() => (U.cur?.kind === 'pat' ? U.cur.ref : null), ref => { if (ref != null && ref !== U.pat && patById(ref)) setU('pat', ref); });
  // PAT mode keeps looping the current pattern when it changes (FL)
  watch(() => curPat()?.id, id => { if (id != null && U.patPlaying && previewId !== id) void togglePreview(id); }, { defer: true });
});
/**
 * After the user switched patterns: a pattern that changed with no pattern window open would be
 * invisible (and a closed rack is hard to find), so the Channel Rack shows it. An open Piano roll
 * or rack already follows the current pattern; the Mix view is left alone.
 */
export function showPatternWindow() {
  if (!U.rackWin && !U.rollWin && !U.mixView) openRack();
}
/** Numpad + / −: the next / previous pattern (wraps). */
export function stepPattern(d: number) {
  const ps = S.project.patterns; if (!ps.length) return;
  const i = Math.max(0, ps.findIndex(p => p.id === curPat()?.id));
  setCurPattern(ps[mod(i + d, ps.length)].id);
  showPatternWindow();
}
/** The blank pattern the wheel opened past the last one; dropped again if left untouched (FL). */
let scratchPat: Id | null = null;
const isBlank = (p: Pattern) => !p.notes.length && !S.project.clips.some(c => c.kind === 'pat' && c.ref === p.id);
/**
 * The wheel over a pattern selector (FL): previous / next without wrapping; past the last pattern a
 * new blank one. That blank pattern only stays once something is put in it: wheeling back off it
 * removes it again, so browsing does not leave a trail of empty patterns.
 */
export function scrollPattern(d: number) {
  const ps = S.project.patterns; if (!ps.length) return;
  const i = Math.max(0, ps.findIndex(p => p.id === curPat()?.id));
  if (d > 0 && i === ps.length - 1) {
    if (isBlank(ps[i])) { showPatternWindow(); return; } // already on a blank one: nothing to add
    newPattern(); scratchPat = curPat()?.id ?? null;
    showPatternWindow();
    return;
  }
  const j = clamp(i + d, 0, ps.length - 1); if (j === i) return;
  const left = ps[i];
  setCurPattern(ps[j].id);
  if (left.id === scratchPat) {
    scratchPat = null;
    if (isBlank(left)) commit([{ op: 'removePattern', id: left.id }], t('b.st.delPat'));
  }
  showPatternWindow();
}
/** Numpad 1–9: the n-th pattern (1-based). */
export function pickPatternNum(n: number) {
  const pt = S.project.patterns[n - 1];
  if (!pt) { say(t('b.st.noPatN', { n })); return; }
  setCurPattern(pt.id);
  showPatternWindow();
}
/** F4: the first empty pattern after the current one, or a new one (FL "next empty pattern"). */
export function nextEmptyPattern() {
  const ps = S.project.patterns, i = ps.findIndex(p => p.id === curPat()?.id);
  const empty = [...ps.slice(i + 1), ...ps.slice(0, Math.max(0, i))].find(p => !p.notes.length);
  if (empty) setCurPattern(empty.id); else newPattern();
  showPatternWindow();
}

// ---------------------------------------------------------------- windows

type WinKey = 'rackWin' | 'rollWin';
const dockOf = (k: WinKey) => docked(k === 'rackWin' ? 'rack' : 'roll');
/** The Channel Rack / Piano roll is open as a floating window (not docked): it counts among the window layer's windows. */
export const rackFloating = () => !!U.rackWin && !docked('rack');
export const rollFloating = () => !!U.rollWin && !docked('roll');
/** Bring a pattern window to the front of the window layer (showing the layer if it was tucked away). A docked panel has no front. */
function front(k: WinKey) {
  const w = U[k]; if (!w || dockOf(k)) return;
  if (w.z === U.zTop && !tucked(w.z)) return;
  const z = U.zTop + 1;
  setU('zTop', z); setU(k, 'z', z);
}
export const rackFront = () => front('rackWin');
export const rollFront = () => front('rollWin');
/** The window is open and visible on top of every other floating window. */
/** The floating pattern window is the one in front of every floating window (F6 / F7 then hide it). */
function onTop(k: WinKey) {
  return !!U[k] && !dockOf(k) && topFloating()?.kind === (k === 'rackWin' ? 'rack' : 'roll');
}
const SEL: Record<WinKey, string> = { rackWin: '.rackwin', rollWin: '.rollwin' };
/** The pattern window (floating or docked) has the keyboard. */
const hasFocus = (k: WinKey) => !!document.querySelector(SEL[k])?.contains(document.activeElement);
/** Give a pattern window the keyboard once it is on screen. */
const focusSoon = (k: WinKey) => requestAnimationFrame(() => (document.querySelector(SEL[k]) as HTMLElement | null)?.focus({ preventScroll: true }));

/**
 * The Channel Rack's width for a pattern of `steps` steps at window position `x`: the pattern and
 * its greyed extra bar at the comfortable step width, up to ~4 bars and the screen's right edge.
 */
export const rackWidthFor = (steps: number, x: number) => rackFitWidth(steps, { left: RACK_LEFT, cw: stepW(), pad: 2 * RACK_PAD_X + 2, min: RACK_MIN_W, room: window.innerWidth - x - 10 });
/** The rack's place and width for `steps` steps: as wide as the pattern needs, sliding left before it would scroll (the screen is the only limit). */
export const rackPlaceFor = (steps: number, x: number) => fitOnScreen(x, rackWidthFor(steps, 10), window.innerWidth);
/** F6: open the Channel Rack (or bring it to the front). */
export function openRack() {
  leaveMixView(); // the pattern windows live in the arrange layout
  if (!S.project.patterns.length) { say(t('b.st.noPatterns')); return; }
  if (docked('rack')) focusSoon('rackWin');
  if (U.rackWin) { rackFront(); return; }
  const pt = curPat()!, rows = Math.max(4, channels().length + 1);
  const w = rackWidthFor(stepsOf(pt), 30);
  const need = RACK_HEAD + rows * RACK_ROW + 12 + 2 * RACK_PAD_Y;
  const z = U.zTop + 1;
  // where it was when it was last closed (kept on screen), else centred under the toolbar
  const g = U.rackFloat;
  const x = g ? clamp(g.x, 0, Math.max(0, window.innerWidth - 120)) : Math.max(20, Math.round((window.innerWidth - w) / 2));
  const y = g ? clamp(g.y, 0, Math.max(0, window.innerHeight - 80)) : 64;
  const h = clamp(Math.max(need, g?.h ?? 0), 220, Math.max(220, window.innerHeight - y - 20));
  // as wide as when it was closed if that is wider (patterns browsed before), like FL
  const fit = rackPlaceFor(stepsOf(pt), x), pl = g && g.w > fit.w ? fitOnScreen(x, g.w, window.innerWidth) : fit;
  // a docked rack keeps the floating place for when it floats again; opening it docked does not show the window layer
  setU({ zTop: z, rackWin: { x: pl.x, y, w: pl.w, h, z } });
}
/** Close the Channel Rack; it reopens where it was (`rackFloat`: kept across restarts). */
export function closeRack() { const w = U.rackWin; if (w) setU('rackFloat', { x: w.x, y: w.y, w: w.w, h: w.h }); setU('rackWin', null); }
/** A docked panel's F6 / F7: show it, give it the keyboard, or hide it when it already has the keyboard. */
function dockKey(k: WinKey, open: () => void, close: () => void) {
  const a = dockKeyAction(!!U[k], hasFocus(k));
  if (a === 'hide') close(); else if (a === 'show') open(); else focusSoon(k);
}
export function toggleRack() {
  if (leaveMixView()) return openRack(); // F6 in the Mix view: back to arrange, rack shown
  if (docked('rack')) return dockKey('rackWin', openRack, closeRack);
  if (onTop('rackWin')) closeRack(); else openRack();
}
/** View menu: show / hide the Channel Rack (the check mark is whether it is open). */
export function toggleRackShown() { if (leaveMixView()) return openRack(); if (docked('rack')) { if (U.rackWin) closeRack(); else openRack(); } else toggleRack(); }
/** A pattern panel that was docked floats again: kept on screen, in front, with the keyboard. */
export function patWinFloated(which: 'rack' | 'roll') {
  const k: WinKey = which === 'rack' ? 'rackWin' : 'rollWin';
  if (!U[k]) return;
  keepOnScreen(); front(k); focusSoon(k);
}

/** F7: open the Piano roll on `ch` (default: the selected channel), or bring it to the front. */
export function openRoll(ch?: Id) {
  leaveMixView();
  if (!S.project.patterns.length) { say(t('b.st.noPatterns')); return; }
  if (ch != null) selectChannel(ch);
  if (!selChan()) { say(t('b.st.noChannels')); return; }
  // the roll takes the keyboard (tools, arrows, Ctrl+C/V) as soon as it is shown
  focusSoon('rollWin');
  if (U.rollWin) { rollFront(); return; }
  const z = U.zTop + 1, g = U.rollFloat, W = window.innerWidth, H = window.innerHeight;
  // full screen by default, like FL's piano roll (a melody needs the room; the Channel Rack stays
  // one F6 away). A window the user made smaller reopens where they left it.
  if (g && !U.rollMax) {
    const w = clamp(g.w, 640, Math.max(640, W - 20)), h = clamp(g.h, 360, Math.max(360, H - 20));
    setU({ zTop: z, rollWin: { x: clamp(g.x, 0, Math.max(0, W - 120)), y: clamp(g.y, 0, Math.max(0, H - 80)), w, h, z } });
    return;
  }
  setU({ zTop: z, rollMax: true, rollWin: { ...fullArea(), z } });
}
/** Everything under the toolbar: where the maximised Piano roll goes (it covers the browser and the mixer too). */
function fullArea() {
  const W = window.innerWidth, H = window.innerHeight;
  const y = Math.round(document.querySelector('.toolbar')?.getBoundingClientRect().bottom ?? 54);
  return { x: 0, y, w: Math.max(640, W), h: Math.max(360, H - y) };
}
let rollRestore: { x: number; y: number; w: number; h: number } | null = null;
/** Double-click on the floating Piano roll's title bar: go back to the size before, or fill the screen again. Docked, it has no such size. */
export function toggleRollMax() {
  const w = U.rollWin; if (!w || docked('roll')) return;
  if (!U.rollMax) { rollRestore = { x: w.x, y: w.y, w: w.w, h: w.h }; setU('rollMax', true); setU('rollWin', v => v && { ...v, ...fullArea() }); return; }
  const W = window.innerWidth, H = window.innerHeight;
  const b = rollRestore ?? { w: clamp(Math.round(W * 0.62), 640, W - 40), h: clamp(Math.round(H * 0.58), 360, H - 100), x: Math.round(W * 0.19), y: 96 };
  setU('rollMax', false);
  setU('rollWin', v => v && { ...v, ...b });
}
/** A drag or resize of the Piano roll's frame: it is no longer full screen. */
export function rollMoved() { if (U.rollMax) setU('rollMax', false); }
/** Close the Piano roll; it reopens where it was (`rollFloat`: kept across restarts). */
export function closeRoll() { const w = U.rollWin; if (w) setU('rollFloat', { x: w.x, y: w.y, w: w.w, h: w.h }); setU('rollWin', null); }
export function toggleRoll() {
  if (leaveMixView()) return openRoll();
  if (docked('roll')) return dockKey('rollWin', () => openRoll(), closeRoll);
  if (onTop('rollWin')) closeRoll(); else openRoll();
}
/** View menu: show / hide the Piano roll (the check mark is whether it is open). */
export function toggleRollShown() { if (leaveMixView()) return openRoll(); if (docked('roll')) { if (U.rollWin) closeRoll(); else openRoll(); } else toggleRoll(); }
/** Escape: close the top floating pattern window when it is above every effect window (never a docked panel). True when one closed. */
/**
 * Open a pattern from the playlist / browser: make it current and show the Channel Rack. Always
 * the rack: it used to open the Piano roll instead when one channel played the pattern, so the
 * same double-click showed different windows (the roll is one click away on the row's mini roll, or F7).
 */
export function openPattern(id: Id) {
  setCurPattern(id, true);
  const pt = patById(id); if (!pt) return;
  const used = [...new Set(pt.notes.map(n => n.ch))];
  if (used.length === 1) selectChannel(used[0]);
  openRack();
}
/** Select a channel; the mixer follows to the insert it plays through (FL), so mixing it needs no hunt for the strip. */
export function selectChannel(id: Id) {
  if (U.chSel.length) setU('chSel', []);
  if (U.selCh === id) return;
  setU('selCh', id);
  const ins = chanById(id)?.insert, m = ins ? S.project.inserts.find(x => x.id === ins) : undefined;
  if (m && U.mixSel !== m.id) setU({ mixSel: m.id, fxSel: m.fx[0]?.id ?? null });
}

/** Shift+click on a channel name: select the channels from the selected one to this one (the selected one stays the anchor). */
export function selectChannelRange(id: Id) {
  const anchor = selChan()?.id ?? null;
  if (anchor == null) return selectChannel(id);
  setU('chSel', rangeSelect(channels().map(c => c.id), anchor, id));
}
/** Shift+Ctrl+click: add the channel to the selection or take it out. */
export function toggleChannelSelected(id: Id) {
  const anchor = selChan()?.id ?? null;
  const next = toggleSelect(U.chSel.filter(x => chanById(x)), anchor, id);
  if (!next.length) return setU('chSel', []);
  // the anchor (the Piano roll's channel) stays a selected one
  if (anchor == null || !next.includes(anchor)) setU('selCh', next[next.length - 1]);
  setU('chSel', next.length > 1 ? next : []);
}
/** The selected Channel Rack channels, in rack order: the multi-selection, else the selected channel (as the rack highlights it; none without channels). */
export function selectedChannels(): Channel[] {
  if (!U.chSel.length) { const c = selChan(); return c ? [c] : []; }
  const ids = new Set(U.chSel);
  return channels().filter(c => ids.has(c.id));
}
export const isChannelSelected = (id: Id) => (U.chSel.length ? U.chSel.includes(id) : selChan()?.id === id);

/**
 * FL's Ctrl+L / Shift+Ctrl+L: route the selected channels to the insert `insId`, or one per insert
 * from it on (creating the missing inserts, named after their channel). One undo step.
 */
export function routeSelectedChannels(insId: Id, spread: boolean) {
  const cs = selectedChannels();
  if (!cs.length) { say(t('c.mv.noSel')); return; }
  const at = S.project.inserts.findIndex(m => m.id === insId);
  if (spread && at === 0) { say(t('c.mv.spreadMaster')); return; }
  const plan = planRoute(cs, S.project.inserts, insId, spread, allocId);
  if (!plan) return;
  const ops: Op[] = plan.create.map(n => ({ op: 'putInsert' as const, insert: { id: n.id, name: n.name, color: '#8b93a1', vol: VOL_UNITY, pan: 0, muted: false, solo: false, fx: [] } }));
  for (const [ch, ins] of plan.assign) { const c = chanById(ch); if (c && c.insert !== ins) ops.push(chanOp(c, { insert: ins })); }
  if (!ops.length) { say(t('c.mv.already')); return; }
  commit(ops, t(spread ? 'c.mv.undoSpread' : 'c.mv.undoRoute'));
  const label = (id: Id) => { const i = S.project.inserts.findIndex(m => m.id === id); return i === 0 ? 'Master' : t('b.pe.insWord', { n: i }); };
  const last = plan.assign[plan.assign.length - 1][1];
  say(spread
    ? t('c.mv.saySpread', { n: cs.length, from: label(insId), to: label(last) }) + (plan.create.length ? t('c.mv.sayNew', { n: plan.create.length }) : '')
    : t('c.mv.sayRoute', { names: cs.length > 3 ? t('c.mv.nChannels', { n: cs.length }) : cs.map(c => c.name).join(', '), to: label(insId) }));
}

// ---------------------------------------------------------------- patterns

/** The pattern with other notes. Copies only the new notes (once per frame of a drag: the old ones are dropped anyway). */
export const putNotes = (pt: Pattern, notes: Note[]): Op => {
  const { notes: _old, ...rest } = rawOf(pt);
  return { op: 'putPattern', pattern: { ...plain(rest), notes: plainNotes(notes) } };
};
export const patOp = (pt: Pattern, patch: Partial<Pattern>): Op => ({ op: 'putPattern', pattern: { ...plain(pt), ...plain(patch) } });
/** The channel's loop set/clear (`loop` steps, 0 clears — FL 20.1's channel looping). */
export const putChannelLoop = (pt: Pattern, ch: Id, loop: number): Op => ({ op: 'putPattern', pattern: plain(setChannelLoop(rawOf(pt), ch, loop)) });
/** The channel's loop burned into steps: every repeat a real step, loop gone (FL's "Burn to pattern"). */
export const putBurnLoop = (pt: Pattern, ch: Id): Op => ({ op: 'putPattern', pattern: plain(burnChannelLoop(rawOf(pt), ch)) });

const freshName = (base: string) => {
  const names = new Set(S.project.patterns.map(p => p.name));
  if (!names.has(base)) return base;
  for (let k = 2; ; k++) if (!names.has(base + ' ' + k)) return base + ' ' + k;
};
export function newPattern() {
  const n = S.project.patterns.length;
  const pt: Pattern = { id: allocId(), name: freshName('Pattern ' + (n + 1)), color: PCOLORS[n % PCOLORS.length], len: BAR, minLen: BAR, notes: [] };
  commit([{ op: 'putPattern', pattern: pt }], t('b.pat.new'));
  setCurPattern(pt.id, true);
  say(t('b.st.newSay', { name: pt.name }));
}
/** Shift+Ctrl+C (FL "Clone"): a copy of the pattern right after it, made current. */
export function clonePattern(pt = curPat()) {
  if (!pt) return;
  const np: Pattern = { ...plain(pt), id: allocId(), name: freshName(pt.name) };
  commit([{ op: 'putPattern', pattern: np }], t('b.st.clonePat'));
  setCurPattern(np.id, true);
  say(t('b.st.clonedPat', { name: pt.name, to: np.name }));
}
/** Delete a pattern and every playlist clip that plays it (one undo step). */
export function deletePattern(pt = curPat()) {
  if (!pt) return;
  const clips = S.project.clips.filter(c => c.kind === 'pat' && c.ref === pt.id).map(c => c.id);
  const i = S.project.patterns.findIndex(p => p.id === pt.id);
  commit([...(clips.length ? [{ op: 'removeClips', ids: clips } as Op] : []), { op: 'removePattern', id: pt.id }], t('b.st.delPat'));
  const next = S.project.patterns[Math.min(i, S.project.patterns.length - 1)];
  if (next) setCurPattern(next.id, true);
  say(t('b.st.deletedPat', { name: pt.name, clips: clips.length }));
}
export function renamePattern(pt: Pattern, name: string) {
  const v = name.trim(); if (!v || v === pt.name) return;
  commit([patOp(pt, { name: v })], t('b.st.renamePat'));
}
export function recolorPattern(pt: Pattern, color: string) { commit([patOp(pt, { color })], t('b.st.colorPat')); }
/**
 * FL "Split by channel": one new pattern per channel the pattern plays (named after the
 * channel), its clips replaced by one clip per channel on consecutive tracks.
 */
export function splitByChannel(pt = curPat()) {
  if (!pt) return;
  const used = channels().filter(c => pt.notes.some(n => n.ch === c.id));
  if (used.length < 2) { say(t('b.st.splitOne')); return; }
  const ops: Op[] = [], made: Pattern[] = [];
  for (const c of used) {
    const np: Pattern = { id: allocId(), name: freshName(pt.name + ' – ' + c.name), color: c.color, len: pt.len, minLen: pt.minLen ?? BAR, swing: pt.swing, notes: plain(pt.notes.filter(n => n.ch === c.id)), ...(loopStepsOf(pt, c.id) > 0 ? { channelLoops: { [String(c.id)]: loopStepsOf(pt, c.id) } } : {}) };
    made.push(np); ops.push({ op: 'putPattern', pattern: np });
  }
  const old = S.project.clips.filter(c => c.kind === 'pat' && c.ref === pt.id);
  // one clip per channel on the tracks below the original; tracks that do not exist yet are
  // added (the clips used to pile up on the last track)
  let nt = S.project.tracks.length;
  const clips = [], need = old.length ? Math.max(...old.map(c => c.track)) + made.length : 0;
  for (; nt < need; nt++) ops.push({ op: 'putTrack', track: newTrack(allocId(), nt) });
  for (const c of old) for (let k = 0; k < made.length; k++) clips.push({ ...plain(c), id: allocId(), track: c.track + k, ref: made[k].id });
  if (old.length) ops.push({ op: 'removeClips', ids: old.map(c => c.id) }, { op: 'putClips', clips });
  ops.push({ op: 'removePattern', id: pt.id });
  commit(ops, t('b.st.splitPat'));
  setCurPattern(made[0].id, true);
  say(t('b.st.splitSay', { name: pt.name, n: made.length }));
}
/**
 * Moves notes `idx` of `pt` to a new pattern at the same steps (one undo step), made current.
 * The playlist keeps sounding the same: every clip of `pt` gets a clip of the new one beside it.
 */
export function moveNotesToNewPattern(pt: Pattern, idx: readonly number[]) {
  const P = rawOf(S.project), src = rawOf(pt);
  const chs = new Set(idx.map(i => src.notes[i]?.ch));
  const ch = chs.size === 1 ? channels().find(c => chs.has(c.id)) : undefined;
  const name = freshName(src.name + ' – ' + (ch?.name ?? t('b.st.movePart')));
  const color = ch?.color ?? PCOLORS[P.patterns.length % PCOLORS.length];
  const plan = planMoveNotes(plain(P), plain(src), idx, name, color, allocId);
  if (!plan) { say(t('b.pe.noSel')); return; }
  commit(plan.ops, t('b.st.moveNotes'));
  setCurPattern(plan.pattern.id, true);
  say(t(plan.placed ? 'b.st.movedNotesClips' : 'b.st.movedNotes', { x: notesText(plan.pattern.notes.length), name: plan.pattern.name, n: plan.placed }));
}
/** "+ bar": keep one more (empty) bar at the end of the pattern. */
export function addBar(pt = curPat()) {
  if (!pt) return;
  if (pt.len + BAR > TOTAL_BEATS) return;
  commit([patOp(pt, { minLen: pt.len + BAR })], t('b.st.patLen'));
  say(t('b.st.barsSay', { name: pt.name, bars: barsText((pt.len + BAR) / BAR) }));
}
/** "− bar": drop the last bar, with the notes that start in it (notes running into it end at the new end).
 * Refused while a channel loop would stick out of the shorter pattern (raise or burn it first). */
export function removeBar(pt = curPat()) {
  if (!pt || pt.len <= BAR) return;
  const newSteps = Math.round((pt.len - BAR) * 4);
  const sticking = Object.entries(pt.channelLoops ?? {}).find(([, l]) => l > newSteps);
  if (sticking) {
    say(t('b.rk.loopBarTip', { n: sticking[1] }));
    return;
  }
  const end = (pt.len - BAR) * 4;
  const gone = pt.notes.filter(n => n.step >= end - 1e-4).length;
  const notes = pt.notes.filter(n => n.step < end - 1e-4).map(n => (n.step + n.len > end ? { ...n, len: end - n.step } : n));
  commit([patOp(pt, { minLen: pt.len - BAR, notes })], t('b.st.patLen'));
  say(t('b.st.barsSay', { name: pt.name, bars: barsText((pt.len - BAR) / BAR) }) + (gone ? t('b.st.barGone', { x: notesText(gone) }) : ''));
}

// ---------------------------------------------------------------- channels

/** The Channel Rack's group filter (FL's filter groups): every channel, the unsorted ones (''), or one group. */
const [rackFilterRaw, setRackFilter] = createSignal<RackFilter>(null);
/** The filter in force: one whose last channel left falls back to every channel. */
export const rackFilter = () => liveFilter(channels(), rackFilterRaw());
export { setRackFilter };
/** The channels the rack shows. */
export const rackChannels = () => { const f = rackFilter(); return f == null ? channels() : channels().filter(c => inFilter(c, f)); };

export function chanOp(c: Channel, patch: Partial<Channel> = {}, index?: number): Op {
  const ch = { ...plain(c), ...patch } as Channel;
  // a channel added while the rack shows one group joins it (FL)
  const f = rackFilter();
  if (f && ch.group === undefined && !channels().some(x => x.id === ch.id)) ch.group = f;
  if (!ch.group) delete ch.group;
  return { op: 'putChannel', channel: ch, ...(index != null ? { index } : {}) };
}
export function setChannel(c: Channel, patch: Partial<Channel>, label: string) { commit([chanOp(c, patch)], label); }
export function toggleChanMute(c: Channel) { setChannel(c, c.mute ? { mute: false } : { mute: true, solo: false }, t('b.st.muteCh')); say(c.name + t(c.mute ? 'b.st.unmuted' : 'b.st.muted')); }
export function toggleChanSolo(c: Channel) { setChannel(c, c.solo ? { solo: false } : { solo: true, mute: false }, t('b.st.soloCh')); say(c.name + t(c.solo ? 'b.st.soloOff' : 'b.st.soloOn')); }

/** A new channel of the built-in synth playing factory preset `name` (or the blank patch). */
export function addSynth(name: string | null) {
  const cat = S.catalog?.synth; if (!cat) { say(t('b.st.synthNA')); return; }
  const c = newSynthChannel(cat, allocId(), name, freshColor());
  commit([chanOp(c)], t('b.st.addSynth'));
  selectChannel(c.id);
  say(t('b.st.synthSay', { name: name ? tName(name) : t('b.st.emptySound') }));
}
/** A new channel's colour: one the rack uses least, so its steps and notes stand apart. */
const freshColor = () => nextChannelColor(channels().map(c => c.color));
const keysChannel = (id: Id): Channel => ({ id, name: keysInstrument(KEYS_DEFAULT_INSTRUMENT)?.name ?? 'Grand Piano', color: '#e0a44a', kind: 'keys', keys: { instrument: KEYS_DEFAULT_INSTRUMENT, dynamics: KEYS_DYNAMICS.def }, vol: 0.7937, pan: 0, mute: false, solo: false, insert: null, root: 60 });
/** A new Music Box channel: the modeled tine instrument. */
const musicBoxChannel = (id: Id): Channel => ({
  id, name: 'Music Box', color: '#cf8e52', kind: 'musicbox',
  musicBox: { ring: MB_RING.def, brightness: MB_BRIGHTNESS.def, body: MB_BODY.def, mechanical: MB_MECHANICAL.def, spread: MB_SPREAD.def, release: MB_RELEASE.def },
  vol: 0.7937, pan: 0, mute: false, solo: false, insert: null, root: 60,
});
/** `root`: the key at which the file plays at its own pitch (a library file may know it). */
const samplerChannel = (id: Id, s: { id: Id; name: string; color: string }, root: number = SAMPLE_ROOT): Channel => ({ id, name: s.name, color: s.color, kind: 'sample', source: s.id, sampler: samplerDefault(), vol: 0.7937, pan: 0, mute: false, solo: false, insert: null, root });

/** A channel hosting a scanned VST3 instrument, from its default sound (no saved state yet). */
const pluginChannel = (id: Id, p: PluginInfo): Channel => ({
  id, name: p.name, color: '#9b7cf8', kind: 'plugin',
  plugin: { format: 'vst3', path: p.path, cid: p.cid, name: p.name, vendor: p.vendor },
  vol: 0.7937, pan: 0, mute: false, solo: false, insert: null, root: 60,
});

/**
 * What a channel can play, for "add" and "replace": a synth preset, Synkopa Instruments, a sampler of a source (`root`: the
 * file's own pitch, if known), or a scanned VST3 instrument.
 */
export type InstrumentPick =
  | { kind: 'synth'; preset: string | null } | { kind: 'keys' } | { kind: 'musicbox' } | { kind: 'sample'; source: Id; root?: number }
  | { kind: 'plugin'; plugin: PluginInfo };
function makeChannel(id: Id, pick: InstrumentPick): Channel | null {
  switch (pick.kind) {
    case 'synth': { const cat = S.catalog?.synth; if (!cat) { say(t('b.st.synthNA')); return null; } return newSynthChannel(cat, id, pick.preset, freshColor()); }
    case 'keys': return keysChannel(id);
    case 'musicbox': return musicBoxChannel(id);
    case 'sample': { const src = S.project.sources.find(x => x.id === pick.source); return src ? samplerChannel(id, src, pick.root) : null; }
    case 'plugin': return pluginChannel(id, pick.plugin);
  }
}
/**
 * FL "Replace": the channel plays another instrument. Its notes, level, pan, mute/solo, mixer
 * routing and colour stay; the name and the root key come from the new instrument. One undo step.
 */
export function replaceChannel(c: Channel, pick: InstrumentPick) {
  const fresh = makeChannel(c.id, pick); if (!fresh) return;
  const keep = { id: c.id, color: c.color, vol: c.vol, pan: c.pan, mute: c.mute, solo: c.solo, insert: c.insert, ...(c.group ? { group: c.group } : {}) };
  commit([{ op: 'putChannel', channel: { ...fresh, ...keep } }], t('b.st.replaceCh'));
  say(t('b.st.replacedCh', { from: c.name, to: fresh.name }));
}
/** An audio file to make a sampler of: a library file (which may know its root key) or a path dropped from disk. */
export type SampleFile = Pick<LibFile, 'path'> & { root?: number };
/** Imports files and waits until their sources are in the store (the import's state event may still be in flight). */
async function importSources(paths: string[]): Promise<Id[]> {
  const r = await be().importAudio({ paths, step: false }); // the channel made from them is the undo step
  for (let k = 0; k < 50 && !r.sourceIds.every(id => S.project.sources.some(s => s.id === id)); k++) await new Promise(res => setTimeout(res, 20));
  return r.sourceIds;
}
/**
 * Make `c` a sampler of a file: a library file, or the first one picked in the file dialog.
 * A sampler keeps its own settings (envelope, cut group …): only the sample changes.
 */
export async function replaceWithFile(c: Channel, file?: SampleFile) {
  try {
    const path = file?.path ?? (await be().pickAudioFiles())?.[0];
    if (!path) return;
    const [id] = await importSources([path]);
    if (id == null) return;
    replaceWithSource(c, id, file?.root);
  } catch (e) { say(t('b.st.samplerErr', { err: String(e) })); }
}
/** Make `c` a sampler of project source `id` (`root`: the file's own pitch, if known). A sampler keeps its settings. */
export function replaceWithSource(c: Channel, id: Id, root?: number) {
  const live = chanById(c.id) ?? c, src = S.project.sources.find(s => s.id === id);
  if (!src) return;
  if (live.kind === 'sample') {
    if (live.source === id) return;
    commit([chanOp(live, { source: id, name: src.name, root: root ?? live.root } as Partial<Channel>)], t('b.cw.changeSample'));
    say(t('b.st.replacedCh', { from: live.name, to: src.name }));
  } else replaceChannel(live, { kind: 'sample', source: id, root });
}

/** A new channel playing a scanned VST3 instrument (the engine loads it; a failure shows on the channel). */
export function addPlugin(p: PluginInfo) {
  const c = { ...pluginChannel(allocId(), p), color: freshColor() };
  commit([chanOp(c)], t('b.st.addPlugin'));
  selectChannel(c.id);
  say(t('b.st.pluginSay', { name: p.name }));
}
/** A new Synkopa Instruments channel: the sampled grand piano. */
export function addKeys() {
  const c = { ...keysChannel(allocId()), color: freshColor() };
  commit([chanOp(c)], t('b.st.addKeys'));
  selectChannel(c.id);
  say(t('b.st.keysSay'));
}
/**
 * Make a Keys channel play another instrument of the catalog (one undo step). Its articulation
 * and a release override belong to the old instrument and are dropped; a channel still named
 * after its instrument (or the default name) takes the new one's name.
 */
export function setKeysInstrument(id: Id, instrument: string) {
  const c = chanById(id);
  const inst = keysInstrument(instrument);
  if (c?.kind !== 'keys' || !inst) return;
  const was = c.keys.instrument ?? KEYS_DEFAULT_INSTRUMENT;
  if (was === instrument) return;
  const named = c.name === 'Synkopa Keys' || c.name === keysInstrument(was)?.name;
  // the sound-shaping knobs stay (browsing instruments keeps the channel's tone); the release and
  // the articulation were the old instrument's
  const keys = { ...c.keys, instrument };
  delete keys.release;
  delete keys.articulation;
  commit([chanOp(c, { name: named ? inst.name : c.name, keys } as Partial<Channel>)], t('b.kp.instCh'));
  say(t('b.kp.instSay', { name: named ? inst.name : c.name, inst: inst.name }));
}
/** Pick the articulation a Keys channel plays (the keyswitch key; `undefined` = the instrument's default). */
export function setKeysArticulation(id: Id, key: number | undefined) {
  const c = chanById(id);
  if (c?.kind !== 'keys' || c.keys.articulation === key) return;
  const keys = { ...c.keys, articulation: key };
  if (key == null) delete keys.articulation;
  commit([chanOp(c, { keys } as Partial<Channel>)], t('b.kp.artCh'));
}
/** A new Music Box channel: the modeled tine instrument. */
export function addMusicBox() {
  const c = { ...musicBoxChannel(allocId()), color: freshColor() };
  commit([chanOp(c)], t('b.st.addMusicBox'));
  selectChannel(c.id);
  say(t('b.st.musicBoxSay'));
}
/** A new sampler channel of a project source, at `index` in the rack (default: the end). Without a `root` it starts at
 *  the root its audio clips were given in the sample editor (FL: the audio clip channel's root note). */
export function addSampler(sourceId: Id, root?: number, index?: number) {
  const s = S.project.sources.find(x => x.id === sourceId); if (!s) return;
  const clipRoot = S.project.clips.find(x => x.kind === 'audio' && x.ref === sourceId && x.root != null)?.root;
  const c = { ...samplerChannel(allocId(), s, root ?? clipRoot), color: freshColor() };
  commit([chanOp(c, {}, index)], t('b.st.addSampler'));
  selectChannel(c.id);
  say(t('b.st.samplerSay', { name: s.name }));
}
/**
 * Import audio files and add one sampler channel per file: library files (which may know their
 * root key), or with nothing given the files picked in the dialog. Resolve the insertion index
 * after import so it follows its anchor if the rack order changes while loading the files.
 */
export async function addSamplerFiles(files?: SampleFile[] | null, index?: () => number | undefined) {
  try {
    const list: SampleFile[] | undefined = files ?? (await be().pickAudioFiles())?.map(path => ({ path }));
    if (!list?.length) return;
    const ids = await importSources(list.map(f => f.path));
    const at = index?.();
    if (ids.length === 1) { addSampler(ids[0], list[0]?.root, at); return; }
    // several files dropped at once are one edit: one Ctrl+Z takes them all back
    const colors = channels().map(c => c.color); // each new channel its own colour, not all the next free one
    const made = ids.flatMap((id, k) => {
      const s = S.project.sources.find(x => x.id === id); if (!s) return [];
      const clipRoot = S.project.clips.find(x => x.kind === 'audio' && x.ref === id && x.root != null)?.root;
      const color = nextChannelColor(colors); colors.push(color);
      return [{ ...samplerChannel(allocId(), s, list[k]?.root ?? clipRoot), color }];
    });
    if (!made.length) return;
    commit(made.map((c, k) => chanOp(c, {}, at != null ? at + k : undefined)), t('b.st.addSampler'));
    selectChannel(made[made.length - 1].id);
    say(t('b.st.samplersSay', { n: made.length }));
  } catch (e) { say(t('b.st.samplerErr', { err: String(e) })); }
}
export async function cloneChannel(c: Channel) {
  // a plugin's sound lives in its running instance until the project is saved: the copy starts from that
  let src = c;
  if (c.kind === 'plugin' && !S.fxErrors[c.id]) {
    try { src = { ...c, plugin: { ...c.plugin, state: await be().pluginState(c.id) } }; } catch (e) { console.warn(e); }
  }
  const id = allocId(), idx = channels().findIndex(x => x.id === c.id) + 1;
  const ops: Op[] = [chanOp({ ...src, id, name: c.name + ' 2', mute: false, solo: false }, {}, idx)];
  // FL clones the channel's steps too: in every pattern — and the clone keeps the loop, so
  // it plays exactly like the original
  for (const pt of S.project.patterns) {
    const l = rawOf(pt).channelLoops?.[String(c.id)];
    if (pt.notes.some(n => n.ch === c.id)) {
      const notes = cloneNotes(pt.notes, c.id, id);
      const op = putNotes(pt, notes) as Extract<Op, { op: 'putPattern' }>;
      if (l != null) op.pattern.channelLoops = { ...op.pattern.channelLoops, [String(id)]: l };
      ops.push(op);
    } else if (l != null) {
      ops.push(patOp(pt, { channelLoops: { ...rawOf(pt).channelLoops, [String(id)]: l } }));
    }
  }
  commit(ops, t('b.st.cloneCh'));
  selectChannel(id);
  say(t('b.st.cloned', { name: c.name }));
}
export function deleteChannel(c: Channel) {
  const used = S.project.patterns.filter(pt => pt.notes.some(n => n.ch === c.id)).length;
  commit([{ op: 'removeChannel', id: c.id }], t('b.st.delCh'));
  if (U.selCh === c.id) setU('selCh', channels()[0]?.id ?? null);
  say(t('b.st.deletedCh', { name: c.name, used: used ? t(used === 1 ? 'b.st.usedIn1' : 'b.st.usedInN', { n: used }) : '' }));
}
export const chanSource = (c: Channel) => (c.kind === 'sample' ? S.project.sources.find(s => s.id === c.source) : undefined);
export const chanKindLabel = (c: Channel) => {
  switch (c.kind) {
    case 'synth': return t('b.st.kindSynth', { name: c.synth.preset ? tName(c.synth.preset) : t('b.st.kindCustom') });
    case 'keys': return t('b.st.kindKeys');
    case 'musicbox': return t('b.st.kindMusicBox');
    case 'plugin': return t('b.st.kindPlugin', { name: [c.plugin.name, c.plugin.vendor].filter(Boolean).join(' · ') });
    case 'sample': return t('b.st.kindSample', { name: chanSource(c) ? baseName(chanSource(c)!.path) : t('b.cw.noFile') });
  }
};

// ---------------------------------------------------------------- sound

export function audition(ch: Id, key?: number, vel = 0.8, force = false) {
  if (!force && !prefs().noteAudition) return;
  be().noteAudition({ ch, key, vel, pattern: curPat()?.id }).catch(e => console.warn(e));
}


// FL's PAT / SONG switch (L): in PAT mode Space loops the current pattern, in SONG the playlist.
const MODE_KEY = 'wave.patMode';
const [patMode, setPatModeS] = createSignal((() => { try { const v = localStorage.getItem(MODE_KEY); return v == null ? true : v === '1'; } catch { return true; } })());
export { patMode };
export function setPatMode(on: boolean) {
  setPatModeS(on);
  try { localStorage.setItem(MODE_KEY, on ? '1' : '0'); } catch { /* private window */ }
  say(on ? t('b.st.modePat', { name: modePattern()?.name ?? '—' }) : t('b.st.modeSong'));
}
/** The pattern PAT mode plays: the current one. */
export const modePattern = () => curPat();
export const previewPattern = () => (U.patPlaying ? previewId : null);
export async function togglePreview(id: Id) {
  try {
    if (U.patPlaying && previewId === id) { await stopPreview(); say(t('b.st.prevStopped')); return; }
    previewId = id;
    warnIfNoAudio();
    markPlayCmd();
    if (U.playing) setU('playing', false);
    // queued behind pending edits: a pattern made a moment ago must reach the engine first
    const pt = patById(id);
    await enqueue(() => be().patternPlay(id, { from: pt ? patFrom(pt) : 0, range: patLoopOf(id) }));
    markPlayCmd();
    setU('patPlaying', true);
    if (S.transport.rec && S.transport.recNotes && patMode()) return say(t('d.act.recPatNow', { name: patById(id)?.name ?? '' }));
    say(t('b.st.prevSay', { mode: t(patMode() ? 'b.st.modePatWord' : 'b.st.modePrevWord'), name: patById(id)?.name ?? t('b.st.patternWord'), hint: patMode() ? '' : t('b.st.prevHint') }));
  } catch (e) { say(t('b.st.prevErr', { err: String(e) })); }
}
// ---- the pattern loop's start position and range (the Piano roll's ruler, FL's pattern-mode
// position and time selection): per pattern, for this session — not saved, not an edit.
const [patLoops, setPatLoops] = createSignal<ReadonlyMap<Id, BeatRange>>(new Map());
const [patStarts, setPatStarts] = createSignal<ReadonlyMap<Id, number>>(new Map());
/** The part of pattern `id` its loop plays (null = all of it). */
export const patLoopOf = (id: Id): BeatRange | null => patLoops().get(id) ?? null;
/** Where pattern `id`'s loop starts playing (beats), as last clicked on its ruler. */
export const patStartOf = (id: Id): number => patStarts().get(id) ?? 0;
/** Where the loop of `pt` starts: its start position when inside the loop range, else the range's start. */
export function patFrom(pt: Pattern): number {
  const r = loopSpan(patLoopOf(pt.id), pt.len), s = patStartOf(pt.id);
  return s >= r.a && s < r.b ? s : r.a;
}
/** Sets (null clears) the loop range of pattern `id`; a loop of it that plays follows at once. */
export function setPatLoop(id: Id, r: BeatRange | null) {
  setPatLoops(m => { const n = new Map(m); if (r) n.set(id, { a: r.a, b: r.b }); else n.delete(id); return n; });
  if (U.patPlaying && previewId === id) void enqueue(() => be().patternLoop(r)).catch(e => say(t('b.st.prevErr', { err: String(e) })));
}
/** The loop of pattern `id` starts at `beat` from now on; a loop of it that plays jumps there. */
export function setPatStart(id: Id, beat: number) {
  setPatStarts(m => new Map(m).set(id, Math.max(0, beat)));
  if (U.patPlaying && previewId === id) {
    const pt = patById(id); if (!pt) return;
    void enqueue(() => be().patternPlay(id, { from: patFrom(pt), range: patLoopOf(id) })).catch(e => say(t('b.st.prevErr', { err: String(e) })));
  }
}
export async function stopPreview() {
  markPlayCmd();
  try { await enqueue(() => be().patternPlay(null)); markPlayCmd(); setU('patPlaying', false); } catch (e) { console.warn(e); }
}

/**
 * Where the playhead is inside pattern `pt` (beats), or −1: the loop preview of this pattern,
 * else the song playhead over a clip that plays it.
 */
export function patPlayhead(pt: Pattern): number {
  if (U.patPlaying && previewId === pt.id && tele.frame.patBeat >= 0) return tele.frame.patBeat;
  if (!U.playing) return -1;
  const b = curBeat();
  for (const c of S.project.clips) {
    if (c.kind !== 'pat' || c.ref !== pt.id || c.muted || b < c.start || b >= c.start + c.len) continue;
    return mod(b - c.start + c.offset, pt.len);
  }
  return -1;
}
export const playStep = (pt: Pattern) => { const b = patPlayhead(pt); return b < 0 ? -1 : Math.floor(b * 4 + 1e-6) % stepsOf(pt); };

// The Channel Rack grows with its channels (a new channel and the "+ Channel" row used to land
// below the window's edge), and both pattern windows stay reachable when the app window shrinks.
createRoot(() => {
  watch(() => channels().length, (n, prev) => {
    // with auto height the rack fits itself, both ways (views/ChannelRack.tsx)
    const w = U.rackWin; if (!w || docked('rack') || prev == null || n <= prev || prefs().rackAutoH) return;
    const need = RACK_HEAD + (n + 1) * RACK_ROW + 12 + 2 * RACK_PAD_Y;
    if (need > w.h) setU('rackWin', 'h', Math.min(need, Math.max(220, window.innerHeight - w.y - 20)));
  });
  window.addEventListener('resize', keepOnScreen);
});
/** Keep the floating pattern windows reachable (the app window shrank, or a docked panel floats again at an old place). */
function keepOnScreen() {
  if (U.rollWin && U.rollMax) { const a = fullArea(); setU('rollWin', v => v && { ...v, ...a }); }
  for (const k of ['rackWin', 'rollWin'] as const) {
    const w = U[k]; if (!w) continue;
    const x = clamp(w.x, 0, Math.max(0, window.innerWidth - 120)), y = clamp(w.y, 0, Math.max(0, window.innerHeight - 80));
    if (x !== w.x || y !== w.y) setU(k, v => v && { ...v, x, y });
  }
}
