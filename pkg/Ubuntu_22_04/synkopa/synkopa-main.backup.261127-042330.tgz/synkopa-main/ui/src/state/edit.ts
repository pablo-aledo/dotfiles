import { t as tl } from '../lib/i18n';
// Sending edits to the engine: discrete commits, drag gestures (transient ops throttled to
// animation frames), and the rules for accepting `state` events while edits are in flight.
//
// Every mutating call goes through one serial queue: Tauri runs async commands concurrently,
// and begin_gesture / apply_ops / end_gesture must reach the engine in the order we sent them.
import { be } from '../api/backend';
import type { Clip, Op, StateDto } from '../api/types';
import { setGestureProbe } from './peaks';
import { applyLocal, replaceMeta, replaceState, S } from './store';
import { say } from './ui';

let inflight = 0;          // queued/unanswered mutating requests
let gestures = 0;          // gestures between begin and end
let lastReplyRev = 0;      // newest revision the engine reported for one of *our* batches
let stash: StateDto | null = null;
let recovery: Promise<void> | null = null; // a refusal's state read-back, while it runs
let resyncTries = 0;       // read-back retries after the backend itself failed
let deferredResync = false; // retry timer fired while an edit/gesture was still active

export const projectRevision = () => Math.max(S.revision, lastReplyRev);

/** True while a drag gesture is open (begin_gesture sent, end_gesture not yet answered). */
export const inGesture = () => gestures > 0;
setGestureProbe(inGesture);

let queue: Promise<unknown> = Promise.resolve();
/** Run `fn` after every previously queued engine call has finished. */
export function enqueue<T>(fn: () => Promise<T>): Promise<T> {
  inflight++;
  const p = queue.then(fn, fn);
  queue = p.catch(() => {}).finally(() => { inflight--; settle(); });
  return p;
}

/** Called for every `state` event. */
export function onStateEvent(dto: StateDto) {
  if (inflight > 0 || gestures > 0) {
    if (!stash || dto.revision >= stash.revision) stash = dto;
    return;
  }
  if (dto.revision < lastReplyRev) return; // older than our last edit
  if (dto.revision === lastReplyRev) { replaceMeta(dto); scheduleReconcile(dto); return; }
  replaceState(dto); reconciledRev = dto.revision;
}

let reconciledRev = -1; // project revision last reconciled in full

function settle() {
  if (inflight > 0 || gestures > 0) return;
  // A failed read-back may have timed out while endGesture was still pending.
  // Retry once the queue and gesture have actually settled; don't lose the repair.
  if (deferredResync) {
    deferredResync = false;
    void resync();
  }
  if (!stash) return;
  const s = stash; stash = null;
  if (s.revision < lastReplyRev || s.revision < S.revision) return;
  // The engine state is exactly the result of our own last batch, which is already applied
  // locally: take the cheap fields now and reconcile the whole project when the UI is idle
  // (on a big song the reconcile takes ~30 ms and stalled every edit).
  if (s.revision === lastReplyRev) { replaceMeta(s); scheduleReconcile(s); }
  else { replaceState(s); reconciledRev = s.revision; }
}

let idleDto: StateDto | null = null;
const idle: (cb: () => void) => void = (globalThis as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => void }).requestIdleCallback
  ? cb => (globalThis as unknown as { requestIdleCallback: (cb: () => void, o?: { timeout: number }) => void }).requestIdleCallback(cb, { timeout: 1500 })
  : cb => setTimeout(cb, 200);
function scheduleReconcile(dto: StateDto) {
  if (dto.revision === reconciledRev) return; // e.g. play/stop: the project did not change
  const first = !idleDto; idleDto = dto;
  if (!first) return;
  idle(() => {
    const d = idleDto; idleDto = null;
    // a newer edit or gesture since then: its own state will settle later
    if (!d || inflight > 0 || gestures > 0 || d.revision !== lastReplyRev) return;
    replaceState(d); reconciledRev = d.revision;
  });
}

const noteRev = (r: unknown) => { const v = (r as { revision?: number } | null)?.revision; if (typeof v === 'number') lastReplyRev = Math.max(lastReplyRev, v); };

/** A reply that carries a whole state (undo/redo/new/open) always wins. */
export function acceptReply(dto: StateDto) {
  lastReplyRev = dto.revision; stash = null;
  replaceState(dto);
}

export function resync(err?: unknown): Promise<void> {
  if (err) { console.warn('[wave] edit rejected:', err); say(tl('a.err', { e: String((err as Error)?.message ?? err) })); }
  recovery = (async () => {
    try {
      const dto = await be().getState();
      resyncTries = 0;
      deferredResync = false;
      if (dto.revision < S.revision) return; // a newer state is already on screen
      lastReplyRev = dto.revision; stash = null; replaceState(dto);
    } catch (e) {
      // the read failed too: the refused frame must not stay on screen for ever, but a
      // backend that errors on reads must not be spun against either — retry, bounded
      console.error(e);
      scheduleResync();
    }
  })();
  return recovery;
}

function scheduleResync() {
  if (resyncTries >= 4) return; // bounded: a backend that keeps failing is not spun against
  resyncTries++;
  setTimeout(() => {
    // A gesture's end may still be waiting on the engine when this timer fires.
    // Keep the retry for settle() instead of silently losing the refused frame.
    if (inflight > 0 || gestures > 0) {
      deferredResync = true;
      return;
    }
    void resync();
  }, 250);
}

/** Test hook: the mutating queue has drained and any refusal's read-back has landed. */
export function settled(): Promise<void> {
  return queue.then(
    () => {},
    () => {},
  ).then(() => recovery ?? undefined).then(() => {});
}

/** One undo step: apply locally, send to the engine. */
export function commit(ops: Op[], label: string) {
  if (!ops.length) return;
  endWheelGestures();
  applyLocal(ops);
  enqueue(() => be().applyOps(ops, { label })).then(noteRev, e => resync(e));
}

// ---- gestures ----

function opKey(op: Op): string {
  switch (op.op) {
    case 'putTrack': return 't' + op.track.id;
    case 'putInsert': return 'i' + op.insert.id;
    case 'putFx': return 'f' + op.fx.id;
    case 'moveFx': return 'm' + op.fxId;
    case 'putPattern': return 'p' + op.pattern.id;
    case 'putChannel': return 'ch' + op.channel.id;
    case 'putSource': return 's' + op.source.id;
    case 'setBpm': return 'bpm';
    case 'setTempoPoints': return 'tempo';
    case 'setLoop': return 'loop';
    case 'putAutomation': return 'a' + op.automation.id;
    case 'putComp': return 'c' + op.comp.id;
    case 'putNotebook': return 'nb';
    case 'putMarker': return 'mk' + op.marker.id;
    case 'editTune': return 'et' + op.clip;
    default: return op.op;
  }
}

export class Gesture {
  private putClips = new Map<number, Clip>();
  private removed = new Set<number>();
  private other = new Map<string, Op>();
  private order: string[] = [];
  private scheduled = false;
  private busy = false;
  private done = false;
  changed = false;

  constructor(private label: string, wheel = false) {
    if (!wheel) endWheelGestures();
    gestures++;
    enqueue(() => be().beginGesture(label)).catch(e => console.warn(e));
  }

  /** Apply locally now; coalesce and send at the next animation frame. */
  update(ops: Op[]) {
    if (this.done || !ops.length) return;
    applyLocal(ops);
    this.changed = true;
    for (const op of ops) {
      if (op.op === 'putClips') { for (const c of op.clips) { this.putClips.set(c.id, c); this.removed.delete(c.id); } this.mark('clips'); }
      else if (op.op === 'removeClips') { for (const id of op.ids) { this.removed.add(id); this.putClips.delete(id); } this.mark('remove'); }
      else { this.other.set(opKey(op), op); this.mark(opKey(op)); }
    }
    if (!this.scheduled) {
      this.scheduled = true;
      requestAnimationFrame(() => { this.scheduled = false; this.flush(); });
    }
  }
  private mark(k: string) { if (!this.order.includes(k)) this.order.push(k); }
  /** The ops `take()` would send, without taking them. */
  private peek(): Op[] {
    const ops: Op[] = [];
    for (const k of this.order) {
      if (k === 'clips') { if (this.putClips.size) ops.push({ op: 'putClips', clips: [...this.putClips.values()] }); }
      else if (k === 'remove') { if (this.removed.size) ops.push({ op: 'removeClips', ids: [...this.removed] }); }
      else { const op = this.other.get(k); if (op) ops.push(op); }
    }
    return ops;
  }
  private take(): Op[] {
    const ops = this.peek();
    this.putClips.clear(); this.removed.clear(); this.other.clear(); this.order = [];
    return ops;
  }
  private flush() {
    if (this.busy || this.done) return; // a pending reply flushes again; end() sends the rest
    const ops = this.take();
    if (!ops.length) return;
    this.busy = true;
    enqueue(() => be().applyOps(ops, { label: this.label, transient: true }))
      // a refused frame must not leave its local state on screen: pull the engine's truth, like commit()
      .then(noteRev, e => resync(e).then(() => {
        // the read-back put the engine's truth on screen — and with it wiped the frames that
        // buffered while this one was in flight (each was applied locally from `update` but
        // never sent). Reapply just those still-pending ops so the preview matches what the
        // next flush sends; the refused ops themselves stay gone (they were taken to send).
        const pending = this.peek();
        if (pending.length) applyLocal(pending);
      }))
      .finally(() => { this.busy = false; if (this.order.length) this.flush(); });
  }

  /** Flush what is left and close the undo step. */
  end(label?: string) {
    if (this.done) return;
    this.done = true;
    const ops = this.take();
    if (ops.length) enqueue(() => be().applyOps(ops, { label: this.label, transient: true })).then(noteRev, e => resync(e));
    enqueue(() => be().endGesture(label ?? this.label)).catch(e => console.warn(e)).finally(() => { gestures--; settle(); });
  }
}

/** Wheel edits: a gesture that closes itself after the wheel goes quiet. */
const wheelG = new Map<string, { g: Gesture; t: number }>();
export function wheelEdit(key: string, label: string, ops: Op[]) {
  let w = wheelG.get(key);
  if (!w) {
    for (const k of [...wheelG.keys()]) if (k !== key) closeWheel(k);
    w = { g: new Gesture(label, true), t: 0 }; wheelG.set(key, w);
  }
  w.g.update(ops);
  clearTimeout(w.t);
  w.t = window.setTimeout(() => closeWheel(key), 450);
}
function closeWheel(key: string) {
  const w = wheelG.get(key); if (!w) return;
  clearTimeout(w.t); wheelG.delete(key); w.g.end();
}
/** Gestures do not nest in the engine: close any open wheel gesture first. */
export function endWheelGestures() { for (const k of [...wheelG.keys()]) closeWheel(k); }
