// Mix assistant (crates/engine/src/masking.rs): which inserts cover each other, from telemetry,
// and the two things the user can do about it. The UI's only permanent trace is a dot on the
// masker's mixer strip, and only while a collision is reported.
import { createSignal } from 'solid-js';
import { be, getBackend } from '../api/backend';
import type { Collision } from '../api/telemetry';
import type { Id } from '../api/types';
import { t } from '../lib/i18n';
import { enqueue, resync } from './edit';
import { insName, S } from './store';
import { say, setU } from './ui';

const [collisions, setCollisions] = createSignal<Collision[]>([], { equals: (a, b) => a === b });
export { collisions };

/** Called by the telemetry loop; the decoder hands over a new array only when the report changed. */
export function noteCollisions(list: Collision[]) {
  if (list !== collisions()) setCollisions(list);
}

/** Collisions where `id` is the insert that should give way. */
export const maskedBy = (id: Id) => collisions().filter(c => c.masker === id);

/** "44–56 Hz", "180 Hz–1.1 kHz", "1.4–5.7 kHz". */
export function hzRange(lo: number, hi: number): string {
  const f = (x: number) => (x >= 1000 ? (x / 1000).toFixed(x >= 10000 ? 0 : 1) : String(Math.round(x)));
  if (lo >= 1000) return `${f(lo)}–${f(hi)} kHz`;
  if (hi >= 1000) return `${f(lo)} Hz–${f(hi)} kHz`;
  return `${f(lo)}–${f(hi)} Hz`;
}

const nameOf = (id: Id) => {
  const m = S.project.inserts.find(x => x.id === id);
  return m ? m.name || insName(m) : String(id);
};

/** One sentence: "808 covers Kick at 44–56 Hz". */
export const collisionText = (c: Collision) => t('c.mask.covers', { a: nameOf(c.masker), b: nameOf(c.protect), hz: hzRange(c.lo, c.hi) });

function drop(c: Collision) {
  setCollisions(collisions().filter(x => !(x.masker === c.masker && x.protect === c.protect)));
}

/** Adds the fix to the masker, on request only: an ordinary EQ at the end of its chain whose
 *  dynamic band is keyed from the protected insert (the standard sidechain). One undo step; the
 *  new EQ is selected so its strip shows where it went. */
export async function fixCollision(c: Collision) {
  try {
    const label = t('c.mask.fix', { b: nameOf(c.protect) });
    const r = await enqueue(() => be().mixAssist('unmask', { masker: c.masker, protect: c.protect, lo: c.lo, hi: c.hi, center: c.center, overlap: c.overlap, keyDb: c.keyDb, label }));
    await resync();
    drop(c);
    if (typeof r.fxId === 'number') setU({ mixSel: c.masker, fxSel: r.fxId });
    say(t('c.mask.fixed', { a: nameOf(c.masker), b: nameOf(c.protect) }));
  } catch (e) {
    say(t('c.mask.failed', { why: String(e).replace(/^Error: /, '') }));
  }
}

/** Stops reporting the pair (kept in the project, undoable). */
export async function ignoreCollision(c: Collision) {
  try {
    await enqueue(() => be().mixAssist('mask_ignore', { a: c.masker, b: c.protect, label: t('c.mask.ignore') }));
    await resync();
    drop(c);
    say(t('c.mask.ignored', { a: nameOf(c.masker), b: nameOf(c.protect) }));
  } catch (e) {
    say(t('c.mask.failed', { why: String(e).replace(/^Error: /, '') }));
  }
}

/** The app setting (Settings ▸ Editing); the engine forgets what it heard when switched off. */
export async function setAssistant(on: boolean) {
  // the saved setting is applied at startup, before the backend is up: wait for it, or the
  // engine (which starts with the assistant on) never hears the user switched it off
  const b = await getBackend();
  try { await b.mixAssist('mix_assistant', { on }); } catch (e) { console.warn('[wave] mix assistant', e); }
  if (!on) setCollisions([]);
}
