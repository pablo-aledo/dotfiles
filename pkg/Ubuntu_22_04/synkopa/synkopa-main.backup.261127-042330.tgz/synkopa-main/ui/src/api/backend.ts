// Typed wrappers over the Tauri commands/events in docs/architecture.md.
// When `window.__TAURI_INTERNALS__` is absent (plain browser) the in-browser mock is used.
import type { AskService } from '../lib/askLink';
import { Channel, invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import type { BeatRange } from '../lib/patLoop';
import type {
  PreviewWave,
  AudioConfig, AudioDevices, AudioHost, AudioStatus, LatencyReport, Catalog, CliStatus, ExportAudioOptions, ExportProgress, ExportResult, ExportStemsOptions, ExportStemsResult, F0ModelStatus, FxChainLoadResult, FxChainPreset, Id, ImportResult, MidiExportResult, MidiImportArgs, MidiImportResult, MidiInfo, Relinked, RelinkSearch,
  KeysStatus, LibraryFiles, LibraryList, LibraryProgress, Melody, MelodyChannel, MidiDevice, MidiNoteEvent, MidiStatus, ModelProgress, AppInfo, UpdateInfo, UpdateProgress, MusicAnalysis, AutoVocalPlan, AutoVocalResult, AutoVocalStyle, MasterListenResult, Op, OpenResult, PitchAnalysis, RecentProject, PitchTarget, RecoveredProject, RefTune, SaveResult, StateDto, TransportDto, PluginScan, PluginParam, PluginCrashSuspect,
  AudioToMidiArgs, AudioToMidiResult, ExtractStemsResult, StemId, StemModelStatus, StemsProgress, ChordAnalysis, ChordDetail, ChordModelStatus, ChordsToPatternResult,
} from './types';

export interface OsDropEvent { type: 'over' | 'drop' | 'leave'; paths: string[]; x: number; y: number }

export interface EventMap {
  state: StateDto;
  'project-open-requested': null;
  /** The gear in a plugin window's header (Synkopa's header above a plugin's own interface): show Synkopa's window for that effect or plugin channel. */
  'plugin-settings': { id: Id };
  /** The pin in a plugin window's header: the user pinned (`pinned`) or unpinned the window on top of the app. */
  'plugin-pin': { id: Id; pinned: boolean };
  'library-progress': LibraryProgress;
  /** Synkopa Instruments: the piano started loading, is ready, or is not on this computer. */
  'keys-status': KeysStatus;
  'model-progress': ModelProgress;
  /** `extractStems` moved on (stage, fraction of the separation done). */
  'stems-progress': StemsProgress;
  /** A stem export (`exportStems`) started the next file. */
  'export-progress': ExportProgress;
  /** The update installer is downloading (`updateDownload`). `total` is 0 when the size is unknown. */
  'update-progress': UpdateProgress;
  'audio-status': AudioStatus;
  /** Keyboard connected, unplugged or failed, or the choice changed. */
  'midi-status': MidiStatus;
  /** A key went down or up on the MIDI keyboard. */
  'midi-note': MidiNoteEvent;
}

export interface Backend {
  readonly isMock: boolean;
  getState(): Promise<StateDto>;
  applyOps(ops: Op[], opts?: { label?: string; transient?: boolean }): Promise<{ revision: number }>;
  beginGesture(label?: string): Promise<void>;
  endGesture(label?: string): Promise<void>;
  undo(): Promise<StateDto>;
  redo(): Promise<StateDto>;
  transportPlay(fromBeat: number): Promise<void>;
  transportStop(): Promise<void>;
  /** A second Stop (panic): cut every tail still ringing — voices, effect tails, the preview. Not an edit. */
  transportSilence(): Promise<void>;
  transportSet(patch: Partial<Pick<TransportDto, 'metro' | 'countIn' | 'rec' | 'monitor' | 'recAudio' | 'recNotes' | 'recQuantize' | 'recAutomation' | 'recAutoLatch'>>): Promise<TransportDto>;
  /** Whether automation `id` drives its target while playing; `on: false` re-enables it (a tweak had overridden it). */
  automationOverride(id: Id, on: boolean): Promise<TransportDto>;
  subscribeTelemetry(onFrame: (buf: ArrayBuffer) => void): Promise<void>;
  watchFx(ids: Id[]): Promise<void>;
  fxCatalog(): Promise<Catalog>;
  /** `step: false`: the files are loaded for an edit that follows (a sampler channel made from them), which is the undo step. */
  importAudio(args: { paths: string[]; track?: number; beat?: number; step?: boolean }): Promise<ImportResult>;
  /** Native "open files" dialog for audio; null when cancelled. */
  pickAudioFiles(): Promise<string[] | null>;
  sourcePeaks(id: Id, norm?: boolean, rev?: boolean): Promise<Float32Array>;
  /** Candidate slice points of a source (the sampler's slice mode): [position 0..1, strength 0..1] pairs. */
  sourceOnsets(id: Id): Promise<Float32Array>;
  /** Like sourcePeaks, but of what the clip actually plays (norm/rev/pitch edits applied); whole source length. */
  clipPeaks(clipId: Id): Promise<Float32Array>;
  /** Pitch curve, levels and note segmentation of an audio clip's source (seconds of the source). */
  pitchAnalyze(clipId: Id): Promise<PitchAnalysis>;
  /** Tune to Reference target of an audio clip: with `reference` a preview for those parameters,
   *  without it the clip's own `tune.reference`. The alignment is cached, so changing parameters is cheap. */
  pitchTarget(clipId: Id, reference?: RefTune): Promise<PitchTarget>;
  /** Which pitch detector analyses (RMVPE when its model is installed, else YIN). */
  f0ModelStatus(): Promise<F0ModelStatus>;
  /** Downloads the RMVPE model (progress: `model-progress`), verifies it, starts using it. */
  f0ModelInstall(): Promise<F0ModelStatus>;
  /** The optional GAME note model: installed or not, and what finds the notes now ("game" | "tracker"). */
  noteModelStatus(): Promise<F0ModelStatus>;
  /** Downloads the GAME note model (progress: `model-progress` with id `game`), SHA-256 checked, unpacks and uses it. */
  noteModelInstall(): Promise<F0ModelStatus>;
  /** Tempo (BPM) and musical key of an audio clip, or key/tempo of the project's active audio clips (excluding `excludeFx`'s insert). */
  musicAnalyze(args?: { clipId?: Id; excludeFx?: Id }): Promise<MusicAnalysis>;
  /** The chord recognition model (ChordMini): size, licence, whether it is installed. */
  chordsModelStatus(): Promise<ChordModelStatus>;
  /** Downloads the chord model (progress: `model-progress` with id `chordmini`), SHA-256 checked. */
  chordsModelInstall(): Promise<ChordModelStatus>;
  /** The chords of an audio clip on the project's beats. Rejects with `ERR_NO_CHORD_MODEL` when the model is missing.
   *  The first call per source takes a second or two; later ones (other detail, moved clip, new tempo) are instant. */
  chordsAnalyze(clipId: Id, detail?: ChordDetail): Promise<ChordAnalysis>;
  /** "Send to piano roll": the clip's chords between project beats `from..to` (default the whole clip) as block chords
   *  (root in the bass, smooth voice leading) in a new pattern on `channel` (default a new Synkopa Keys piano), placed on
   *  the Playlist from the bar of the first chord on a free track below the audio. One undo step. */
  chordsToPattern(args: { clipId: Id; from?: number; to?: number; detail?: ChordDetail; channel?: Id | null }): Promise<ChordsToPatternResult>;
  /** Convert to MIDI (melody): the clip's notes as a new pattern under it in one undo step; `preview` changes nothing. */
  audioToMidi(args: AudioToMidiArgs): Promise<AudioToMidiResult>;
  /** "Auto wokal": measures a vocal clip (key from `beatClipId`, else from the other tracks) and returns the calibrated
   *  insert chain. Read-only; takes a few seconds per minute of audio. `bakeRider`: the rider is left out of
   *  `chain` and returned as `riderBake` — pass its params to `bakeRider` (no live look-ahead delay on the insert). */
  autoVocalPlan(args: { clipId: Id; beatClipId?: Id; style?: AutoVocalStyle; bakeRider?: boolean }): Promise<AutoVocalPlan>;
  /** Renders the Vocal Rider (`params`: catalog ids, e.g. `plan.riderBake.params`) into an audio clip's audio
   *  (region, clip gain, norm/rev/pitch edits; fades stay) as a new source; the clip (same id) plays it with gain
   *  0 dB. One undo step; the original source stays in the project. Slow: seconds per minute of audio. */
  bakeRider(args: { clipId: Id; params: Record<string, number> }): Promise<{ sourceId: Id; clipId: Id }>;
  /** The whole Auto Vocal journey in one command (`synkopa auto-vocal`): measures the clip (key from
   *  `beatClipId`), bakes the rider unless `noBake` or the source was baked before, and applies the calibrated
   *  chain to the insert — same-kind effects replaced, an EQ in front stays. The bake and the chain are two undo
   *  steps; `label` names the chain's. Progress arrives as `auto-vocal {clipId, stage}` events
   *  ("plan", "bake", "chain") — `onStage` receives them in the mock too. */
  autoVocal(
    args: { clipId: Id; beatClipId?: Id; style?: AutoVocalStyle; noBake?: boolean; label?: string },
    onStage?: (stage: string) => void,
  ): Promise<AutoVocalResult>;
  /** The Master listens to the whole song as it reaches the effect and sets every control
   *  (`synkopa master-listen`, app/src/actions.rs `master_listen`): one undo step. `target` overrides
   *  the effect's own Target. Progress 0..1 arrives as `master-listen {fxId, progress}` events —
   *  `onProgress` receives them in the mock too. Rejects with "cancelled" after `masterListenCancel`. */
  masterListen(args: { fxId: Id; target?: number; label?: string }, onProgress?: (p: number) => void): Promise<MasterListenResult>;
  /** Stops a running Master listen; it changes nothing. */
  masterListenCancel(): Promise<void>;
  /** FL's "Sidechain to ▸" and the Compressor window's source menu, as one command (`synkopa sidechain`):
   *  with `fxId`, that Compressor listens to `from` (`off`: back to its own input); with `from`/`to`, the
   *  target's first free Compressor is keyed or a ducking one is added (`added`); `off` without `fxId`: every
   *  Compressor on `to` keyed from `from` goes back to its own input. The engine validates every key. */
  sidechain(args: { fxId?: Id; from?: Id; to?: Id; off?: boolean; ifRevision?: number; label?: string }): Promise<{ fxId: Id | null; added: boolean; revision: number }>;
  trimClip(clipId: Id): Promise<{ sourceId: Id }>;
  /** FL's "Make unique" for audio clips (all of one source, on one track): they get their own copy of the source
   *  (same file and audio, own name "Name #2" and colour) on a new track right below theirs, routed to a free mixer
   *  insert (no track or channel routed to it, no effects; a new one when none is free), named after the copy.
   *  One undo step; other clips of the source are untouched. Rejects other clip kinds and mixed sources/tracks. */
  makeUnique(clipIds: Id[]): Promise<{ sourceId: Id; track: number; insertId: Id }>;
  /** FL's *Export in place*: the clips rendered (through their inserts and effects, not the master's, tails kept) over the span
   *  they cover into one audio clip on a new track right below them, routed to the master; the originals are muted.
   *  With `range` (the playlist's time selection, beats `[from, to]`) only that span is rendered: the given clips that overlap
   *  it, or with none given every clip that plays there; a clip crossing an edge is split and only its inside part muted.
   *  One undo step. Rejects a selection that renders silent; `exportCancel` stops it (`cancelled`). */
  exportInPlace(clipIds: Id[], range?: [number, number]): Promise<{ sourceId: Id; clipId: Id; track: number } | { cancelled: true }>;
  /** The stem separation model (HTDemucs): size, licence, whether it is installed. */
  stemsModelStatus(): Promise<StemModelStatus>;
  /** Downloads the stem model (progress: `model-progress` with id `htdemucs`), SHA-256 checked. `stemsCancel` stops it. */
  stemsModelInstall(): Promise<StemModelStatus | { cancelled: true }>;
  /** FL's *Extract stems*: the audio clip separated into `stems` (progress: `stems-progress`), one new track per stem
   *  right below the clip with a clip at the same place playing the same part the same way; the clip is muted. One
   *  undo step. Rejects with `ERR_NO_STEM_MODEL` when the model is missing; `stemsCancel` stops it (`cancelled`). */
  extractStems(clipId: Id, stems: StemId[]): Promise<ExtractStemsResult | { cancelled: true }>;
  /** Stops a running `extractStems` or `stemsModelInstall`; nothing is left behind. */
  stemsCancel(): Promise<void>;
  /** Points sources at other files (decoded first), one undo step. Rejects when no file decodes. */
  relinkSources(items: { sourceId: Id; path: string }[]): Promise<Relinked[]>;
  /** Finds the missing sources' files in `folder` (and below) by name; relinks the unambiguous ones of the remembered length. */
  relinkSearch(folder: string): Promise<RelinkSearch>;
  /** Native folder dialog (starting in `start`); null when cancelled. */
  pickFolder(start?: string): Promise<string | null>;
  /** Native "open file" dialog for one audio file (starting in `start`); null when cancelled. */
  pickAudioFile(start?: string): Promise<string | null>;
  /** The parts of a standard MIDI file and what each would become. */
  midiInspect(path: string): Promise<MidiInfo>;
  /** Imports parts as a new pattern on the Playlist (or one part into a channel): one undo step. */
  midiImport(args: MidiImportArgs): Promise<MidiImportResult>;
  /** Writes the song (pattern clips as placed) or one pattern as a .mid file. */
  midiExport(args: { out: string; pattern?: Id }): Promise<MidiExportResult>;
  /** Mix assistant (app/src/mix_assist.rs): `mix_assistant` {on?} → {on}; `masking` {from?, to?, scan?}
   *  → {collisions}; `unmask` {masker, protect, lo, hi, keyDb} → {fxId, insert, revision} (one undo
   *  step); `mask_ignore` {a, b} → {revision}. */
  mixAssist(cmd: 'mix_assistant' | 'masking' | 'unmask' | 'mask_ignore', args: Record<string, unknown>): Promise<Record<string, unknown>>;
  /** FX chain presets in the user's library, by name, and the folder they are kept in. */
  fxChains(): Promise<{ dir: string; presets: FxChainPreset[] }>;
  /** Saves the effects of `insert` as preset `name`; an existing name fails with `EXISTS:` unless `overwrite`. */
  fxChainSave(insert: Id, name: string, overwrite?: boolean): Promise<{ name: string; effects: number }>;
  /** Puts a preset on `insert` as one undo step; an insert with effects needs `mode`. Never touches volume, pan or routing. */
  fxChainLoad(insert: Id, name: string, mode?: 'replace' | 'append'): Promise<FxChainLoadResult>;
  fxChainRename(name: string, to: string): Promise<{ name: string }>;
  /** Deletes the preset's file for good. */
  fxChainDelete(name: string): Promise<unknown>;
  /** Native "open" dialog for a .mid file; null when cancelled. */
  pickMidiFile(): Promise<string | null>;
  /** Native "save" dialog for a .mid file, suggesting `name`; null when cancelled. */
  pickMidiSave(name: string): Promise<string | null>;
  /** Renders a comp clip to a new source; the clip becomes an ordinary audio clip (one undo step). */
  flattenComp(clipId: Id): Promise<{ sourceId: Id }>;
  /** Plays one whole take instead of the comp (null = back to the comp). Live only, not undone. */
  compAudition(compId: Id, takeId: Id | null): Promise<void>;
  /** Plays one clip alone. `from` (seconds of the source): from there, the take with its pitch edits at the
   *  source's own speed, to the end of the clip (the pitch editor's Solo); rejects when nothing is left after it. */
  previewClip(clipId: Id, from?: number): Promise<void>;
  /** The sample editor's keyboard on an audio clip: its sample at MIDI `key`, transposed from the clip's root (plus its
   *  pitch knob) at the sample's own speed, over the clip's region. `vel` 0..1. Rejects for a missing clip. */
  previewClipKey(args: { clipId: Id; key: number; vel?: number }): Promise<void>;
  /** Channels whose notes play over an audio clip (pattern clips in the playlist), best fit to the singing first. */
  melodyChannels(clipId: Id): Promise<MelodyChannel[]>;
  /** The notes `channel` plays over the clip as a melody reference (a copy; `span`: seconds of the source). */
  melodyReference(clipId: Id, channel: Id, span?: [number, number] | null): Promise<{ melody: Melody; fit: number }>;
  /** Play a file alone (the Browser's preview); resolves with its length and waveform (the toolbar's status line). */
  previewFile(path: string): Promise<PreviewWave>;
  previewStop(): Promise<void>;
  /** Play a project source alone (Browser ▸ Project ▸ Audio), from its loaded audio; resolves like `previewFile`. */
  previewSource(id: Id): Promise<PreviewWave>;
  /** Play one note of a channel now (not an edit). `key` MIDI (default: the channel's root), `vel` 0..1, `pattern`: the one being edited (routing). */
  noteAudition(args: { ch: Id; key?: number; vel?: number; pattern?: Id }): Promise<void>;
  /** Computer keyboard as a piano: key down (`on`) / up on a channel. */
  typingNote(args: { ch: Id; key: number; vel?: number; on: boolean }): Promise<void>;
  /** Loop one pattern on its own (null stops), from `from` beats into it (default 0) and only
   *  over `range` (beats; none = the whole pattern). Exclusive with the song transport. Starting
   *  the pattern that plays again jumps to `from`. */
  patternPlay(pattern: Id | null, opts?: { from?: number; range?: BeatRange | null }): Promise<void>;
  /** The playing pattern loop's range (null = the whole pattern), without restarting it. */
  patternLoop(range: BeatRange | null): Promise<void>;
  audioHosts(): Promise<AudioHost[]>;
  audioDevices(host: string): Promise<AudioDevices>;
  audioGetConfig(): Promise<AudioStatus>;
  audioSetConfig(cfg: AudioConfig): Promise<AudioStatus>;
  /** Plays 8 clicks on the output (instead of the mix) for ~5 s while recording the input
   *  (microphone at the speaker, or a cable from an output to an input) and finds them by
   *  cross-correlation. Transport must be stopped. Saves nothing: apply `suggestedOffsetMs`
   *  with `audioSetConfig({ ...cfg, recOffsetMs })`. Rejects when no click came back. */
  audioMeasureLatency(): Promise<LatencyReport>;
  /** MIDI input ports the OS lists right now. */
  midiListDevices(): Promise<MidiDevice[]>;
  /** Choose the MIDI keyboard (null = none) and open it. Saved with the audio settings and reopened at startup. */
  midiSelectDevice(id: string | null): Promise<MidiStatus>;
  midiStatus(): Promise<MidiStatus>;
  /** Which channel (instrument) the keyboard plays (null = the first pitched channel). With a track armed and transport recording, played notes land as a pattern clip on that track. */
  midiSetTarget(channel: Id | null): Promise<MidiStatus>;
  /** Plays every key at `fixed` (1..127), or at the keyboard's velocity (null); saved across sessions. */
  midiSetVelocity(fixed: number | null): Promise<MidiStatus>;
  libraryList(): Promise<LibraryList>;
  libraryInstall(id: string): Promise<void>;
  /** Synkopa Instruments: whether the piano's recordings are on this computer and loaded. */
  keysStatus(): Promise<KeysStatus>;
  /** Loads a missing or failed Keys instrument (or a kit's instruments) again. */
  keysRetry(id: string): Promise<KeysStatus>;
  libraryFiles(q: { kit?: string; folder?: string }): Promise<LibraryFiles>;
  libraryAddFolder(): Promise<string[]>;
  libraryRemoveFolder(path: string): Promise<string[]>;
  /** A new project: empty (eight tracks, the starter kit in the Channel Rack), or with `demo` the built-in demo project. */
  projectNew(demo?: boolean): Promise<StateDto>;
  /** The file dialog when `path` is omitted. */
  projectOpen(path?: string, ifRevision?: number): Promise<OpenResult>;
  /** File → Open recent: projects opened or saved lately, newest first (at most 10). */
  recentProjects(): Promise<RecentProject[]>;
  /** Takes `path` off the recent list; without a path, clears it. */
  recentForget(path?: string): Promise<void>;
  /** Project paths received at launch or forwarded by another instance. */
  takeProjectOpenRequests(): Promise<string[]>;
  /** The save dialog when the project has no path yet or `saveAs`. */
  /** `version`: save beside the current file as the next `Name_N` and continue there (FL's save new version); a project never saved asks for a name. */
  projectSave(saveAs?: boolean, version?: boolean): Promise<SaveResult>;
  projectExportZip(ifRevision: number): Promise<SaveResult>;
  /** Autosave tick: keeps the crash-recovery snapshot of the unsaved changes current, saved project
   *  or not, without touching the project's file (removes it once nothing is unsaved). True when written. */
  recoveryWrite(): Promise<boolean>;
  /** Unsaved projects left behind by a Synkopa that crashed or was killed, newest first. */
  recoveryList(): Promise<RecoveredProject[]>;
  /** Opens a recovered project with its changes unsaved: as its own file again (Save writes there), or untitled. */
  recoveryRestore(id: string): Promise<{ state: StateDto; warnings: string[] }>;
  /** Deletes a recovered project the user does not want. */
  recoveryDiscard(id: string): Promise<void>;
  /** Offline bounce of the master mix to stereo WAV or MP3. */
  exportAudio(opts: ExportAudioOptions): Promise<ExportResult>;
  /**
   * Stem export, like FL Studio's "Split mixer tracks": asks for a folder, then writes one
   * WAV per mixer insert that has sound (named after the insert, after its effects and fader, before the
   * master), plus `Master.wav` (the mix with master effects) when `includeMaster`. Muted inserts and
   * inserts with nothing routed into them get no file; solo is ignored. All files have the same length.
   * Progress: `export-progress`. No file is left behind when aborted.
   */
  exportStems(opts: ExportStemsOptions): Promise<ExportStemsResult>;
  /** Abort an in-flight `exportAudio` / `exportStems` before a file is written. */
  exportCancel(): Promise<void>;
  /** Installed effects of every hosted format (VST3; LV2 on Linux). A cold `rescan` is slow. */
  pluginScan(rescan: boolean): Promise<PluginScan>;
  /** A plugin's own window (VST3; LV2 with an X11 interface on Linux) under Synkopa's header showing `label`. Rejects with
   *  `NO_EDITOR: …` when the plugin has no window of its own, and with the reason when none can be shown here. */
  pluginEditor(fxId: Id, open: boolean, label?: { title: string; subtitle: string }, pinned?: boolean): Promise<void>;
  /** Whether the plugin's own window is open (it may have been closed with its X). */
  pluginEditorOpen(fxId: Id): Promise<boolean>;
  /** The plugins that were loaded when the last session ended without exiting (usually empty): Synkopa did not leave through the front door, and one of these may be why. */
  pluginCrashSuspects(): Promise<PluginCrashSuspect[]>;
  /** Keep a plugin's module out of future scans (the follow-up to `pluginCrashSuspects`). */
  pluginBlock(format: string, path: string): Promise<void>;
  /** Load a plugin Synkopa's safety check refused (its `fxErrors` entry contains `UNSAFE_PLUGIN`), from now on; every slot with it is retried. */
  pluginLoadAnyway(fxId: Id): Promise<void>;
  pluginParams(fxId: Id): Promise<PluginParam[]>;
  /** A live plugin's current state (base64, what `PluginRef.state` stores): an effect or a plugin channel by id. */
  pluginState(fxId: Id): Promise<string>;
  pluginSetParam(fxId: Id, id: number, value: number): Promise<void>;
  cliStatus(): Promise<CliStatus>;
  /** The running version, the version whose release notes were last shown, and whether updates are checked automatically. */
  appInfo(): Promise<AppInfo>;
  /** Asks GitHub Releases for a newer version (null = this is the newest). Rejects when offline or the release is malformed. */
  updateCheck(): Promise<UpdateInfo | null>;
  /** Downloads the update found by `updateCheck` (progress: `update-progress`) and verifies its signature. Nothing restarts. */
  updateDownload(): Promise<void>;
  /** Installs the downloaded update and restarts Synkopa (the call does not return then). Rejects on a failure; the old version keeps running. */
  updateInstall(): Promise<void>;
  updateSetAuto(on: boolean): Promise<void>;
  /** Whether downloads (sample kits, models) skip the HTTPS certificate check: for a company proxy whose root certificate is not installed. Downloads are checksum-verified either way. */
  netIgnoreCertErrors(): Promise<boolean>;
  netSetIgnoreCertErrors(on: boolean): Promise<void>;
  /** Remembers that the release notes of `version` were shown. */
  updateMarkSeen(version: string): Promise<void>;
  /** Opens the release page of `version` (null = the releases list) in the system browser. */
  openReleasePage(version?: string | null): Promise<void>;
  /** "Ask AI": opens `service` in the system browser (ChatGPT with `prompt` in the link, DeepWiki on the
   *  repository). No ChatGPT prompt opens a new chat; one whose link is past MAX_ASK_URL (lib/askLink) is rejected. */
  openAsk(service: AskService, prompt: string | null): Promise<void>;
  /** Opens the Synkopa Discord server in the system browser. */
  openDiscord(): Promise<void>;
  on<K extends keyof EventMap>(ev: K, cb: (payload: EventMap[K]) => void): Promise<() => void>;
  /** OS file drag & drop with real paths (Tauri) or file names (mock). */
  onOsDrop(cb: (e: OsDropEvent) => void): Promise<() => void>;
  /** Window title (file name + dirty mark). */
  setTitle(title: string): void;
  /** Native window controls for the custom title bar; null in the browser mock (no window chrome to drive). */
  readonly win: WindowCtl | null;
}

export interface WindowCtl {
  minimize(): Promise<void>;
  toggleMaximize(): Promise<void>;
  close(): Promise<void>;
  isMaximized(): Promise<boolean>;
  startDragging(): Promise<void>;
  /** Full screen (F11): no taskbar, no window frame. */
  isFullscreen(): Promise<boolean>;
  setFullscreen(on: boolean): Promise<void>;
  /** Called on every window resize (maximise state may have changed). */
  onResized(cb: () => void): Promise<() => void>;
  /** The user asked to close the window (its X, Alt+F4): decide (save prompts) and call
   *  `destroy()` to really close it, or do nothing to keep it open. */
  onCloseRequested(cb: (destroy: () => Promise<void>) => Promise<void>): Promise<() => void>;
  /** The webview's own zoom (the View menu's scale; keeps text crisp). False = not supported
   *  here, the caller falls back to CSS zoom. */
  setZoom(z: number): Promise<boolean>;
}

function tauriWindow(): WindowCtl {
  const w = () => import('@tauri-apps/api/window').then(m => m.getCurrentWindow());
  return {
    minimize: async () => (await w()).minimize(),
    toggleMaximize: async () => (await w()).toggleMaximize(),
    close: async () => (await w()).close(),
    isMaximized: async () => (await w()).isMaximized(),
    startDragging: async () => (await w()).startDragging(),
    isFullscreen: async () => (await w()).isFullscreen(),
    setFullscreen: async on => (await w()).setFullscreen(on),
    onResized: async cb => (await w()).onResized(() => cb()),
    onCloseRequested: async cb => {
      const win = await w();
      // one guard at a time: a second close event while the save prompt is open is swallowed
      // (the window stays open) instead of prompting again or destroying mid-prompt
      let guarding = false;
      return win.onCloseRequested(async ev => {
        ev.preventDefault();
        if (guarding) return;
        guarding = true;
        try {
          await cb(async () => { await win.destroy(); });
        } finally {
          guarding = false;
        }
      });
    },
    setZoom: async z => {
      try {
        const { getCurrentWebview } = await import('@tauri-apps/api/webview');
        await getCurrentWebview().setZoom(z);
        return true;
      } catch {
        return false;
      }
    },
  };
}

const toF32 = (r: unknown): Float32Array => {
  if (r instanceof ArrayBuffer) return new Float32Array(r.slice(0, r.byteLength - (r.byteLength % 4)));
  if (ArrayBuffer.isView(r)) { const b = r as ArrayBufferView; return new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength - (b.byteLength % 4))); }
  if (Array.isArray(r)) {
    // A Vec<u8> serialised as JSON numbers: reinterpret as little-endian bytes.
    const u8 = Uint8Array.from(r as number[]);
    return new Float32Array(u8.buffer, 0, u8.byteLength >> 2);
  }
  return new Float32Array(0);
};

export function tauriBackend(): Backend {
  return {
    isMock: false,
    win: tauriWindow(),
    getState: () => invoke('get_state'),
    applyOps: (ops, opts) => invoke('apply_ops', { ops, label: opts?.label ?? null, transient: opts?.transient ?? false }),
    beginGesture: label => invoke('begin_gesture', { label: label ?? null }),
    endGesture: label => invoke('end_gesture', { label: label ?? null }),
    undo: () => invoke('undo'),
    redo: () => invoke('redo'),
    transportPlay: fromBeat => invoke('transport_play', { fromBeat }),
    transportStop: () => invoke('transport_stop'),
    transportSilence: () => invoke('transport_silence'),
    transportSet: patch => invoke('transport_set', patch),
    automationOverride: (id, on) => invoke('automation_override', { id, on }),
    async subscribeTelemetry(onFrame) {
      const ch = new Channel<ArrayBuffer>();
      ch.onmessage = m => onFrame(m instanceof ArrayBuffer ? m : (toF32(m).buffer as ArrayBuffer));
      await invoke('telemetry_subscribe', { channel: ch });
    },
    watchFx: ids => invoke('watch_fx', { ids }),
    fxCatalog: () => invoke('fx_catalog'),
    importAudio: a => invoke('import_audio', { paths: a.paths, track: a.track ?? null, beat: a.beat ?? null, step: a.step ?? true }),
    async pickAudioFiles() {
      // tauri-plugin-dialog's command, invoked directly so the UI needs no extra npm dependency.
      const r = await invoke<string | string[] | null>('plugin:dialog|open', {
        options: { multiple: true, directory: false, filters: [{ name: 'Audio', extensions: ['wav', 'mp3', 'flac', 'ogg', 'aif', 'aiff', 'm4a'] }] },
      });
      return r == null ? null : Array.isArray(r) ? r : [r];
    },
    sourcePeaks: async (id, norm, rev) => toF32(await invoke('source_peaks', { id, norm: !!norm, rev: !!rev })),
    sourceOnsets: async id => toF32(await invoke('source_onsets', { id })),
    clipPeaks: async clipId => toF32(await invoke('clip_peaks', { clipId })),
    pitchAnalyze: clipId => invoke('pitch_analyze', { clipId }),
    pitchTarget: (clipId, reference) => invoke('pitch_target', { clipId, reference: reference ?? null }),
    f0ModelStatus: () => invoke('f0_model_status'),
    f0ModelInstall: () => invoke('f0_model_install'),
    noteModelStatus: () => invoke('note_model_status'),
    noteModelInstall: () => invoke('note_model_install'),
    musicAnalyze: a => invoke('music_analyze', { clipId: a?.clipId ?? null, excludeFx: a?.excludeFx ?? null }),
    chordsModelStatus: () => invoke('chords_model_status'),
    chordsModelInstall: () => invoke('chords_model_install'),
    chordsAnalyze: (clipId, detail) => invoke('chords_analyze', { clipId, detail: detail ?? null }),
    chordsToPattern: args => invoke('chords_to_pattern', { args }),
    audioToMidi: args => invoke('audio_to_midi', { args }),
    autoVocalPlan: a => invoke('auto_vocal_plan', { clipId: a.clipId, beatClipId: a.beatClipId ?? null, style: a.style ?? null, bakeRider: a.bakeRider ?? null }),
    bakeRider: a => invoke('bake_rider', { clipId: a.clipId, params: a.params }),
    autoVocal: async (a, onStage) => {
      // stage events are best-effort: a failed listen() must never mask the command's result,
      // and a journey only hears its own clip's stages (the payload carries the clipId)
      const off = onStage
        ? listen('auto-vocal', e => {
            const p = e.payload as { clipId?: Id; stage?: string };
            if (p.clipId === a.clipId) onStage(p.stage ?? '');
          }).catch(() => null)
        : null;
      try {
        return await invoke('auto_vocal', { clipId: a.clipId, beatClipId: a.beatClipId ?? null, style: a.style ?? null, noBake: a.noBake ?? null, label: a.label ?? null });
      } finally {
        void off?.then(unlisten => unlisten?.(), () => {});
      }
    },
    masterListen: async (a, onProgress) => {
      // progress events are best-effort, like Auto Vocal's stages
      const off = onProgress
        ? listen('master-listen', e => {
            const p = e.payload as { fxId?: Id; progress?: number };
            if (p.fxId === a.fxId && typeof p.progress === 'number') onProgress(p.progress);
          }).catch(() => null)
        : null;
      try {
        return await invoke('master_listen', { fxId: a.fxId, target: a.target ?? null, label: a.label ?? null });
      } finally {
        void off?.then(unlisten => unlisten?.(), () => {});
      }
    },
    masterListenCancel: () => invoke('master_listen_cancel'),
    sidechain: a => invoke('sidechain', { fxId: a.fxId ?? null, from: a.from ?? null, to: a.to ?? null, off: a.off ?? null, ifRevision: a.ifRevision ?? null, label: a.label ?? null }),
    trimClip: clipId => invoke('trim_clip', { clipId }),
    makeUnique: clipIds => invoke('make_unique', { clipIds }),
    exportInPlace: (clipIds, range) => invoke('export_in_place', { clipIds, range: range ?? null }),
    stemsModelStatus: () => invoke('stems_model_status'),
    stemsModelInstall: () => invoke('stems_model_install'),
    extractStems: (clipId, stems) => invoke('extract_stems', { clipId, stems }),
    stemsCancel: () => invoke('stems_cancel'),
    relinkSources: async items => (await invoke<{ relinked: Relinked[] }>('relink_sources', { args: { items } })).relinked,
    relinkSearch: async folder => (await invoke<{ search: RelinkSearch }>('relink_search', { args: { folder } })).search,
    async pickFolder(start) {
      const r = await invoke<string | null>('plugin:dialog|open', { options: { directory: true, multiple: false, defaultPath: start ?? undefined } });
      return r ?? null;
    },
    async pickAudioFile(start) {
      const r = await invoke<string | string[] | null>('plugin:dialog|open', {
        options: { multiple: false, directory: false, defaultPath: start ?? undefined, filters: [{ name: 'Audio', extensions: ['wav', 'mp3', 'flac', 'ogg', 'oga'] }] },
      });
      return r == null ? null : Array.isArray(r) ? r[0] ?? null : r;
    },
    mixAssist: (cmd, args) => invoke('mix_assist', { cmd, args }),
    fxChains: () => invoke('fx_chain', { cmd: 'fx_chains', args: {} }),
    fxChainSave: (insert, name, overwrite = false) => invoke('fx_chain', { cmd: 'fx_chain_save', args: { insert, name, overwrite } }),
    fxChainLoad: (insert, name, mode) => invoke('fx_chain', { cmd: 'fx_chain_load', args: { insert, name, mode } }),
    fxChainRename: (name, to) => invoke('fx_chain', { cmd: 'fx_chain_rename', args: { name, to } }),
    fxChainDelete: name => invoke('fx_chain', { cmd: 'fx_chain_delete', args: { name } }),
    midiInspect: path => invoke('midi', { cmd: 'midi_inspect', args: { path } }),
    midiImport: args => invoke('midi', { cmd: 'midi_import', args }),
    midiExport: args => invoke('midi', { cmd: 'midi_export', args }),
    async pickMidiFile() {
      const r = await invoke<string | string[] | null>('plugin:dialog|open', { options: { multiple: false, directory: false, filters: [{ name: 'MIDI', extensions: ['mid', 'midi'] }] } });
      return r == null ? null : Array.isArray(r) ? r[0] ?? null : r;
    },
    async pickMidiSave(name) {
      return (await invoke<string | null>('plugin:dialog|save', { options: { defaultPath: name, filters: [{ name: 'MIDI', extensions: ['mid'] }] } })) ?? null;
    },
    flattenComp: clipId => invoke('flatten_comp', { clipId }),
    compAudition: (compId, takeId) => invoke('comp_audition', { compId, takeId }),
    previewClip: (clipId, from) => invoke('preview_clip', { clipId, from: from ?? null }),
    previewClipKey: a => invoke('preview_clip_key', { clipId: a.clipId, key: a.key, vel: a.vel ?? null }),
    melodyChannels: clipId => invoke('melody_channels', { clipId }),
    melodyReference: (clipId, channel, span) => invoke('melody_reference', { clipId, channel, span: span ?? null }),
    previewFile: path => invoke('preview_file', { path }),
    previewStop: () => invoke('preview_stop'),
    previewSource: id => invoke('preview_source', { id }),
    typingNote: a => invoke('typing_note', { ch: a.ch, key: a.key, vel: a.vel ?? null, on: a.on }),
    noteAudition: a => invoke('note_audition', { ch: a.ch, key: a.key ?? null, vel: a.vel ?? null, pattern: a.pattern ?? null }),
    patternPlay: (pattern, o) => invoke('pattern_play', { pattern, from: o?.from ?? null, range: o?.range ? [o.range.a, o.range.b] : null }),
    patternLoop: range => invoke('pattern_loop', { range: range ? [range.a, range.b] : null }),
    audioHosts: () => invoke('audio_hosts'),
    audioDevices: host => invoke('audio_devices', { host }),
    audioGetConfig: () => invoke('audio_get_config'),
    // Sent both as `config` and flattened, so either command signature deserialises it.
    audioSetConfig: cfg => invoke('audio_set_config', { config: cfg, ...cfg }),
    audioMeasureLatency: () => invoke('audio_measure_latency'),
    midiListDevices: () => invoke('midi_list_devices'),
    midiSelectDevice: id => invoke('midi_select_device', { id }),
    midiStatus: () => invoke('midi_status'),
    midiSetTarget: channel => invoke('midi_set_target', { channel }),
    midiSetVelocity: fixed => invoke('midi_set_velocity', { fixed }),
    libraryList: () => invoke('library_list'),
    libraryInstall: id => invoke('library_install', { id }),
    keysStatus: () => invoke('keys_status'),
    keysRetry: (id: string) => invoke('keys_retry', { id }),
    libraryFiles: q => invoke('library_files', { kit: q.kit ?? null, folder: q.folder ?? null }),
    libraryAddFolder: () => invoke('library_add_folder'),
    libraryRemoveFolder: path => invoke('library_remove_folder', { path }),
    projectNew: demo => invoke('project_new', { demo: !!demo }),
    projectOpen: (path, ifRevision) => invoke('project_open', { path: path ?? null, ifRevision }),
    takeProjectOpenRequests: () => invoke('take_project_open_requests'),
    recentProjects: () => invoke('recent_projects'),
    recentForget: path => invoke('recent_forget', { path: path ?? null }),
    projectSave: (saveAs, version) => invoke('project_save', { saveAs: !!saveAs, version: !!version }),
    projectExportZip: ifRevision => invoke('project_export_zip', { ifRevision }),
    recoveryWrite: () => invoke('recovery_write'),
    recoveryList: () => invoke('recovery_list'),
    recoveryRestore: id => invoke('recovery_restore', { id }),
    recoveryDiscard: id => invoke('recovery_discard', { id }),
    exportAudio: opts => invoke('export_audio', { ...opts }),
    exportStems: opts => invoke('export_stems', { ...opts }),
    exportCancel: () => invoke('export_cancel'),
    pluginScan: rescan => invoke('plugin_scan', { rescan }),
    pluginEditor: (fxId, open, label, pinned) => invoke('plugin_editor', { fxId, open, title: label?.title, subtitle: label?.subtitle, pinned }),
    pluginEditorOpen: fxId => invoke('plugin_editor_open', { fxId }),
    pluginCrashSuspects: () => invoke('plugin_crash_suspects'),
    pluginBlock: (format, path) => invoke('plugin_block', { format, path }),
    pluginLoadAnyway: fxId => invoke('plugin_load_anyway', { fxId }),
    pluginParams: fxId => invoke('plugin_params', { fxId }),
    pluginState: fxId => invoke('plugin_state', { fxId }),
    pluginSetParam: (fxId, id, value) => invoke('plugin_set_param', { fxId, id, value }),
    cliStatus: () => invoke('cli_status'),
    appInfo: () => invoke('app_info'),
    updateCheck: () => invoke('update_check'),
    updateDownload: () => invoke('update_download'),
    updateInstall: () => invoke('update_install'),
    updateSetAuto: on => invoke('update_set_auto', { on }),
    netIgnoreCertErrors: () => invoke('net_ignore_cert_errors'),
    netSetIgnoreCertErrors: on => invoke('net_set_ignore_cert_errors', { on }),
    updateMarkSeen: version => invoke('update_mark_seen', { version }),
    openReleasePage: version => invoke('open_release_page', { version: version ?? null }),
    openAsk: (service, prompt) => invoke('open_ask', { service, prompt }),
    openDiscord: () => invoke('open_discord'),
    on: async (ev, cb) => listen(ev, e => cb(e.payload as never)),
    async onOsDrop(cb) {
      const { getCurrentWebview } = await import('@tauri-apps/api/webview');
      return getCurrentWebview().onDragDropEvent(e => {
        const p = e.payload as { type: string; paths?: string[]; position?: { x: number; y: number } };
        const dpr = window.devicePixelRatio || 1;
        const x = (p.position?.x ?? 0) / dpr, y = (p.position?.y ?? 0) / dpr;
        if (p.type === 'over' || p.type === 'enter') cb({ type: 'over', paths: p.paths ?? [], x, y });
        else if (p.type === 'drop') cb({ type: 'drop', paths: p.paths ?? [], x, y });
        else cb({ type: 'leave', paths: [], x, y });
      });
    },
    setTitle(title) {
      document.title = title;
      import('@tauri-apps/api/window').then(m => m.getCurrentWindow().setTitle(title)).catch(() => {});
    },
  };
}

export const isTauri = () => typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

let instance: Backend | null = null;
let pending: Promise<Backend> | null = null;
/** The one backend; callers racing at startup share the same instance. */
export function getBackend(): Promise<Backend> {
  if (instance) return Promise.resolve(instance);
  pending ??= (async () => {
    if (isTauri()) instance = tauriBackend();
    else {
      const { MockBackend } = await import('./mock');
      instance = new MockBackend();
    }
    return instance;
  })();
  return pending;
}
/** Synchronous access after `getBackend()` resolved once (at startup). */
export const be = (): Backend => {
  if (!instance) throw new Error('backend not initialised');
  return instance;
};
