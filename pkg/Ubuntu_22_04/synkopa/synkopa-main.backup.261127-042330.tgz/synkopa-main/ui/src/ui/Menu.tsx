import { For, Match, Show, Switch } from 'solid-js';
import { createSignal, onCleanup, onMount } from '../lib/reactive';
import type { MenuItem } from '../state/ui';
import { CHECK_GLYPH, menuGlyph, type MenuGlyph } from './menuIcons';
import { closeMenu, U } from '../state/ui';
import { rawOf, S } from '../state/store';
import { commit } from '../state/edit';
import { clamp, dbText } from '../lib/format';
import { t } from '../lib/i18n';
import { Icon } from './icons';
import { SUGGESTED, SWATCHES } from '../lib/color';
import { INST_ICONS, InstIcon } from './instIcons';
import { isPointerEvent, pressKeepsMenu } from './menuPress';
import { PopupBoundary } from './PanelBoundary';

/** An optional boolean as Solid 1 wrote it into an `aria-*` attribute: "true" / "false", absent when unset. */
const ariaBool = (v: boolean | undefined): 'true' | 'false' | undefined => (v == null ? undefined : v ? 'true' : 'false');

/**
 * The one context menu (items are built by whoever opens it).
 *
 * A press outside an open menu dismisses it, and the whole press is swallowed (a native menu's
 * click-outside: the control under the pointer does not also fire). That used to be a full-screen
 * backdrop div, but a veil sits above the menu bar: the bar's own z-lift is trapped under the
 * toolbar's stacking context, so pressing another title never reached its button and closed the
 * open menu only — one menu per press. Instead a capture listener dismisses everywhere except
 * inside the open menu and on the bar's titles, whose presses (and hover) open or switch menus.
 */
export function ContextMenu() {
  onMount(() => {
    // the release half of an absorbed press: the click (auxclick / contextmenu for the other
    // buttons) must not fire on whatever sits under the pointer; `swallowing` resets on the
    // next press, so a stray button's events from another press are never eaten
    let swallowing = false;
    const release = (e: UIEvent) => {
      if (!swallowing) return;
      // a click synthesized without a press (Enter / Space on the focused control, el.click())
      // is not part of the dismissed press and reaches it even while the press is swallowed
      if (!isPointerEvent(e)) return;
      e.preventDefault();
      e.stopPropagation();
    };
    const down = (e: PointerEvent) => {
      swallowing = false;
      if (!U.menu) return;
      const el = e.target instanceof Element ? e.target : null;
      if (pressKeepsMenu(el)) return;
      closeMenu();
      e.preventDefault(); // the dismissal keeps focus where it was, like a native menu
      e.stopPropagation();
      swallowing = true;
    };
    document.addEventListener('pointerdown', down, true);
    for (const t of ['pointerup', 'click', 'auxclick', 'contextmenu'] as const)
      document.addEventListener(t, release, true);
    onCleanup(() => {
      document.removeEventListener('pointerdown', down, true);
      for (const t of ['pointerup', 'click', 'auxclick', 'contextmenu'] as const)
        document.removeEventListener(t, release, true);
    });
  });
  return (
    <Show when={U.menu} keyed>
      {/* a menu that fails to build says so in its place (a press there keeps it, like the menu's own) */}
      {menu => (
        <PopupBoundary name={t('d.ui.pn.menu')} x={menu.x} y={menu.y} close={closeMenu} class="ctxmenu">
          <MenuList items={menu.items} x={menu.x} y={menu.y} />
        </PopupBoundary>
      )}
    </Show>
  );
}

/** One menu panel (`ctxmenu` marks it for the press dismissal; `sub` items open a nested panel on hover). */
function MenuList(props: { items: MenuItem[]; x: number; y: number; sub?: boolean }) {
  const [open, setOpen] = createSignal<{ i: number; x: number; y: number } | null>(null);
  let el!: HTMLDivElement;
  const [pos, setPos] = createSignal({ x: props.x, y: props.y });
  // the opener's height is only an estimate: measure, so a tall menu opened low keeps its bottom rows on screen
  onMount(() => {
    const r = el.getBoundingClientRect();
    setPos({ x: props.x, y: Math.max(4, Math.min(props.y, window.innerHeight - r.height - 4)) });
  });
  const openSub = (i: number, b: HTMLElement) => {
    const r = b.getBoundingClientRect(), W = 230;
    setOpen({ i, x: r.right + W > window.innerWidth ? r.left - W : r.right - 2, y: r.top - 5 });
  };
  const glyph = (it: { label: string; glyph?: MenuGlyph; checked?: boolean }) => it.checked != null ? (it.checked ? CHECK_GLYPH : null) : it.glyph ?? menuGlyph(it.label);
  return (
    <>
          <div ref={el} class={['menu ctxmenu', { submenu: !!props.sub }]} style={{ left: pos().x + 'px', top: pos().y + 'px' }} onPointerDown={e => e.stopPropagation()}>
            <For each={props.items}>
              {it => (
                <Switch>
                  <Match when={it.t === 'title' && it}>{i => <div class="mt">{i().label}</div>}</Match>
                  <Match when={it.t === 'sep'}><div class="ms" /></Match>
                  <Match when={it.t === 'sec' && it}>{i => <div class="msec">{i().label}</div>}</Match>
                  <Match when={it.t === 'sub' && it}>
                    {i => {
                      const idx = props.items.indexOf(i());
                      return (
                        <button class={['mi', { hot: open()?.i === idx }]} onPointerEnter={e => openSub(idx, e.currentTarget)} onClick={e => openSub(idx, e.currentTarget)}>
                          <span class="row" style={{ gap: '8px' }}><MenuIco g={glyph(i())} /><span>{i().label}</span></span>
                          <span class="kbd">›</span>
                        </button>
                      );
                    }}
                  </Match>
                  <Match when={it.t === 'item' && it}>
                    {i => (
                      <button role={i().checked != null ? 'menuitemcheckbox' : 'menuitem'} aria-checked={ariaBool(i().checked)} aria-disabled={ariaBool(i().disabled)} class={['mi', { danger: !!i().danger, dis: !!i().disabled }]} title={i().title ?? ''} onPointerEnter={() => setOpen(null)}
                        onClick={() => { if (i().disabled) return; closeMenu(); i().act(); }}>
                        <span class="row" style={{ gap: '8px' }}>
                          <Show when={i().icon} fallback={<MenuIco g={glyph(i())} />}>
                            <span class="tile" style={{ width: '18px', height: '18px', 'border-radius': '4px', background: (i().iconColor ?? '#9aa2ad') + '26', color: i().iconColor ?? 'var(--fg3)' }}>
                              <Icon d={i().icon!} size={12} sw={2.2} />
                            </span>
                          </Show>
                          <span>{i().label}</span>
                        </span>
                        <span class="kbd">{i().kbd ?? ''}</span>
                      </button>
                    )}
                  </Match>
                  <Match when={it.t === 'swatches' && it}>
                    {i => <SwatchRow current={i().current} pick={c => { i().pick(c); closeMenu(); }} />}
                  </Match>
                  <Match when={it.t === 'icons' && it}>
                    {i => (
                      <div class="iconpick">
                        <For each={Object.entries(INST_ICONS)}>{([id, g]) => (
                          <button title={id === i().current ? t('d.ui.iconremove', { label: g.label }) : g.label} class={{ on: id === i().current }}
                            style={{ color: id === i().current ? (i().color ?? 'var(--fg-hi)') : undefined }}
                            onClick={() => { i().pick(id === i().current ? null : id); closeMenu(); }}>
                            <InstIcon id={id} size={14} />
                          </button>
                        )}</For>
                      </div>
                    )}
                  </Match>
                  <Match when={it.t === 'gain' && it}>
                    {i => {
                      const clip = () => S.project.clips.find(c => c.id === i().clipId);
                      // a clip of the selection: the whole selection gets the same step (one undo step)
                      const set = (d: number) => {
                        const c = clip(); if (!c) return;
                        const cs = U.sel.includes(c.id) ? S.project.clips.filter(x => U.sel.includes(x.id)) : [c];
                        commit([{ op: 'putClips', clips: cs.map(x => ({ ...rawOf(x), gain: clamp(x.gain + d, -24, 12) })) }], t('d.ui.clipvol'));
                      };
                      return (
                        <div class="gainrow">
                          <span style={{ flex: 1, font: '500 12px var(--sans)', color: 'var(--fg)' }}>{t('d.ui.clipvol')}</span>
                          <button onClick={() => set(-1)}>−</button>
                          <span style={{ 'min-width': '54px', 'text-align': 'center', font: '500 11px var(--mono)', color: 'var(--blue)' }}>{dbText(clip()?.gain ?? 0)}</span>
                          <button onClick={() => set(1)}>+</button>
                        </div>
                      );
                    }}
                  </Match>
                  <Match when={it.t === 'chips' && it}>
                    {i => (
                      <div class={['chiprow', { dis: !!i().disabled }]}>
                        <Show when={i().label}><span class="cl">{i().label}</span></Show>
                        <div class="chips">
                          <For each={i().options}>{(o, k) => (
                            <button class={{ on: i().active === k() }} disabled={i().disabled}
                              onClick={() => { if (i().disabled) return; if (i().close !== false) closeMenu(); i().pick(k()); }}>{o}</button>
                          )}</For>
                        </div>
                      </div>
                    )}
                  </Match>
                  <Match when={it.t === 'rename' && it}>
                    {i => {
                      let el!: HTMLInputElement;
                      onMount(() => { el.value = i().value; setTimeout(() => { el.focus(); el.select(); }, 0); });
                      // Enter or a click elsewhere keeps the name, Escape drops it
                      let done = false;
                      const keep = () => { if (done) return; done = true; const v = el.value.trim(); closeMenu(); if (v) i().done(v); };
                      return <input ref={el} onBlur={keep} onKeyDown={e => {
                        e.stopPropagation();
                        if (e.key === 'Enter') keep();
                        if (e.key === 'Escape') { done = true; closeMenu(); }
                      }} />;
                    }}
                  </Match>
                </Switch>
              )}
            </For>
          </div>
          {/* keyed: hovering another submenu row must swap the panel, not keep the first one */}
          <Show when={open()} keyed>{o => {
            const it = props.items[o.i];
            return it && it.t === 'sub' ? <MenuList items={it.items} x={o.x} y={o.y} sub /> : null;
          }}</Show>
    </>
  );
}

function MenuIco(props: { g: MenuGlyph | null }) {
  return (
    <span class="mico">
      <Show when={props.g}>{g => <svg viewBox={g().vb} width="12" height="12" fill="currentColor"><path fill-rule={g().eo ? 'evenodd' : 'nonzero'} d={g().d} /></svg>}</Show>
    </span>
  );
}

/**
 * A colour row that stays small: the current colour (when it is not one of them) and five
 * suggestions; "…" opens the full palette and a free colour picker in place.
 */
function SwatchRow(props: { current?: string; pick: (c: string) => void }) {
  const [more, setMore] = createSignal(false);
  const cur = () => props.current?.toLowerCase();
  const row = () => {
    const c = props.current;
    return c && !SUGGESTED.includes(c.toLowerCase()) ? [c, ...SUGGESTED] : SUGGESTED;
  };
  const sw = (c: string) => (
    <button title={t('d.ui.color')} style={{ background: c, 'box-shadow': c.toLowerCase() === cur() ? '0 0 0 2px var(--fg-hi)' : 'none' }} onClick={() => props.pick(c)} />
  );
  return (
    <div class="swatches">
      <For each={more() ? SWATCHES : row()}>{sw}</For>
      <Show when={!more()} fallback={
        <label class="swmore" title={t('d.ui.colorCustom')}>
          <input type="color" value={props.current ?? '#4f8ef7'} onChange={e => props.pick(e.currentTarget.value)} />
          <span>+</span>
        </label>
      }>
        <button class="swmore" title={t('d.ui.colorMore')} onClick={() => setMore(true)}>…</button>
      </Show>
    </div>
  );
}
