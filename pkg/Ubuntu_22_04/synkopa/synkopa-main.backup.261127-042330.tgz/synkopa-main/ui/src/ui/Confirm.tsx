// "Unsaved changes" question before New / Open / closing the window, and the offer to
// recover an unsaved project after a crash.
import { Show } from 'solid-js';
import { createSignal } from '../lib/reactive';
import { lang, t } from '../lib/i18n';
import { S } from '../state/store';
import { DialogBoundary } from './PanelBoundary';
import { modal } from './modal';

type Answer = 'save' | 'discard' | 'cancel';
const [ask, setAsk] = createSignal<{ what: string; done: (a: Answer) => void } | null>(null);

/** Resolves 'discard' straight away when nothing is unsaved. */
export function confirmUnsaved(what: string): Promise<Answer | 'busy'> {
  if (ask()) return Promise.resolve('busy'); // keep the first confirmation actionable
  if (!S.dirty) return Promise.resolve('discard');
  return new Promise(res => setAsk({ what, done: a => { setAsk(null); res(a); } }));
}

export type RecoverAnswer = 'restore' | 'discard' | 'later';
const [askRec, setAskRec] = createSignal<{ savedMs: number; openPath: string | null; project: string | null; done: (a: RecoverAnswer) => void } | null>(null);

/**
 * "Synkopa closed unexpectedly…": restore the project, delete it, or keep it for the next start.
 * `openPath`: the project file open now (e.g. the one just opened from Explorer), which a
 * restore replaces in this window; the question says so.
 */
/** `project`: the file the recovered changes belong to (null: a project that was never saved). */
export function confirmRecover(savedMs: number, openPath: string | null = null, project: string | null = null): Promise<RecoverAnswer> {
  return new Promise(res => setAskRec({ savedMs, openPath, project, done: a => { setAskRec(null); res(a); } }));
}

const fileName = (path: string) => path.split(/[\\/]/).pop()!;
const when = (ms: number) => new Date(ms).toLocaleString(lang() === 'pl' ? 'pl-PL' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' });

export function ConfirmDialog() {
  return (<>
    <Show when={askRec()}>
      {q => (
        <DialogBoundary name={t('d.ui.recover')} close={() => q().done('later')} z={300}>
        <div class="overlay" style={{ 'z-index': 300 }}>
          <div class="dialog dlgsm" role="alertdialog" aria-labelledby="rec-hd" ref={el => modal(el, { close: () => q().done('later') })}
            onKeyDown={e => { if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'BUTTON') { e.preventDefault(); q().done('restore'); } }}>
            <div class="hd"><span id="rec-hd">{t('d.ui.recover')}</span><button title={t('d.ui.recover.later.tip')} aria-label={t('d.upd.btn.close')} onClick={() => q().done('later')}>×</button></div>
            <p class="dlgtext">
              {q().project ? t('d.ui.recover.bodyNamed', { when: when(q().savedMs), name: t('d.ui.named', { name: fileName(q().project!) }) }) : t('d.ui.recover.body', { when: when(q().savedMs) })}
              <Show when={q().openPath}>{p => <> {t('d.ui.recover.replaces', { name: t('d.ui.named', { name: fileName(p()) }) })}</>}</Show>
            </p>
            <div class="dlgfoot">
              <button class="smallbtn" title={t('d.ui.recover.later.tip')} onClick={() => q().done('later')}>{t('d.ui.recover.later')}</button>
              <button class="smallbtn danger" onClick={() => q().done('discard')}>{t('d.ui.recover.discard')}</button>
              <button class="smallbtn primary" data-autofocus onClick={() => q().done('restore')}>{t('d.ui.recover.restore')}</button>
            </div>
          </div>
        </div>
        </DialogBoundary>
      )}
    </Show>
    <Show when={ask()}>
      {q => (
        <DialogBoundary name={t('d.ui.unsaved')} close={() => q().done('cancel')} z={300}>
        <div class="overlay" style={{ 'z-index': 300 }} onPointerDown={() => q().done('cancel')}>
          <div class="dialog dlgsm" role="alertdialog" aria-labelledby="unsaved-hd" ref={el => modal(el, { close: () => q().done('cancel') })} onPointerDown={e => e.stopPropagation()}
            onKeyDown={e => { if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'BUTTON') { e.preventDefault(); q().done('save'); } }}>
            <div class="hd"><span id="unsaved-hd">{t('d.ui.unsaved')}</span><button aria-label={t('d.upd.btn.close')} onClick={() => q().done('cancel')}>×</button></div>
            <p class="dlgtext">
              {t('d.ui.unsaved.body', { name: S.path ? t('d.ui.named', { name: fileName(S.path) }) : t('d.ui.unnamed'), what: q().what })}
            </p>
            <div class="dlgfoot">
              <button class="smallbtn" onClick={() => q().done('cancel')}>{t('d.ui.cancel')}</button>
              <button class="smallbtn danger" onClick={() => q().done('discard')}>{t('d.ui.discard')}</button>
              <button class="smallbtn primary" data-autofocus onClick={() => q().done('save')}>{t('d.ui.save')}</button>
            </div>
          </div>
        </div>
        </DialogBoundary>
      )}
    </Show>
  </>);
}
