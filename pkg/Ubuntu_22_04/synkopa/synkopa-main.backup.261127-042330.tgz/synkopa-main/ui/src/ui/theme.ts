// Colour tokens. CSS reads the same names as variables (styles.css, `:root` / `[data-theme=light]`);
// canvas code reads them from `T`, which is mutated in place when the theme changes. Cached
// canvas layers include `theme.epoch` in their key (frameLoop `Layer`), so they re-render.
import { createSignal } from '../lib/reactive';
import { t } from '../lib/i18n';
import type { TranslationKey } from '../lib/i18n';

export interface Tokens {
  // surfaces
  bg0: string; bg1: string; bg2: string; bg3: string; bg4: string; bg5: string; bg6: string; bg7: string;
  line: string; line2: string; line3: string;
  // text
  fg: string; fgHi: string; fg2: string; fg3: string; fg4: string; fg5: string; fg6: string;
  // accents
  blue: string; blueHi: string; green: string; amber: string; pan: string; red: string; onBg: string;
  // plots (effect windows, editors)
  viz: string; vizPanel: string; vizGrid: string; vizGrid2: string; vizAxis: string; vizLabel: string;
  /** main curve / ink on plots */
  ink: string;
  /** "before" signal (spectrum pre, input pitch, input level) */
  pre: string;
  /** "after" signal (spectrum post, corrected pitch, output) */
  post: string;
  playhead: string;
  /** text drawn on a saturated fill */
  onFill: string;
  /** playlist */
  grid: string; gridBar: string; gridBeat: string; laneAlt: string; rulerBg: string; rulerText: string; clipBody: string;
  shade: string;
  /** piano keys (pitch views) */
  keyW: string; keyB: string; keyWText: string; keyBText: string;
  /** text on a band/accent-coloured handle */
  onBand: string;
  /** a light-tinted accent fill strength multiplier (light needs a bit more) */
  tint: number;
  /** playlist clips: body/header mixes of the clip colour with a base, ink for notes/waveforms */
  clipBase: string; clipBodyPct: number; clipHeadPct: number; clipHeadSelPct: number; clipHeadSelTo: string;
  clipInkTo: string; clipInkPct: number; clipText: string; clipTextSel: string; laneArm: string; gridShade: string;
}

export const DARK: Tokens = {
  // three clear elevations: the grid well (bg2), panels (bg3–bg5), raised items (bg6–bg7), 1px lines between
  bg0: '#0d0f13', bg1: '#111318', bg2: '#13161c', bg3: '#191c23', bg4: '#1a1e26', bg5: '#1c2028', bg6: '#242a34', bg7: '#2a303b',
  line: '#2a303b', line2: '#343b47', line3: '#3c4452',
  fg: '#dde1e8', fgHi: '#f4f6f9', fg2: '#c0c6cf', fg3: '#a8b0bb', fg4: '#98a1ae', fg5: '#808a99', fg6: '#687282',
  blue: '#4f8ef7', blueHi: '#8fb6ff', green: '#4ec08a', amber: '#e0a44a', pan: '#b18cf5', red: '#e05263', onBg: '#2c3a52',
  viz: '#0f1115', vizPanel: '#13161b', vizGrid: '#1a1e25', vizGrid2: '#242a33', vizAxis: '#303743', vizLabel: '#566070',
  ink: '#f4f6f9', pre: '#a8b0bb', post: '#8fb6ff', playhead: '#eef1f5', onFill: '#0b1220',
  grid: '#13161c', gridBar: '#2b323d', gridBeat: '#1d222a', laneAlt: '#16191f', rulerBg: '#191c23', rulerText: '#8d96a3', clipBody: '#12151a',
  shade: 'rgba(0,0,0,.55)',
  keyW: '#9aa1ad', keyB: '#1d2128', keyWText: '#1a1e24', keyBText: '#e6e9ee', onBand: '#0b1220', tint: 1,
  clipBase: '#12151a', clipBodyPct: 18, clipHeadPct: 50, clipHeadSelPct: 75, clipHeadSelTo: '#ffffff',
  clipInkTo: '#ffffff', clipInkPct: 85, clipText: '#f4f6f9', clipTextSel: '#0b1220', laneArm: '#1d161c', gridShade: 'rgba(255,255,255,.035)',
};

export const LIGHT: Tokens = {
  bg0: '#d9dde3', bg1: '#eef0f3', bg2: '#f6f7f9', bg3: '#f1f3f5', bg4: '#f7f8fa', bg5: '#e9ecf0', bg6: '#e2e6eb', bg7: '#ffffff',
  line: '#d3d8df', line2: '#c6ccd4', line3: '#bfc6cf',
  fg: '#2a3038', fgHi: '#0f1318', fg2: '#3c444f', fg3: '#525b67', fg4: '#69727e', fg5: '#858d98', fg6: '#9aa1ab',
  blue: '#2563d9', blueHi: '#1f56c2', green: '#1f9461', amber: '#b9770f', pan: '#7446d6', red: '#cf2f45', onBg: '#d6e3fb',
  viz: '#fbfcfd', vizPanel: '#f3f5f8', vizGrid: '#eceff3', vizGrid2: '#dfe3e9', vizAxis: '#c9cfd7', vizLabel: '#8a929d',
  ink: '#151a21', pre: '#7f8894', post: '#2563d9', playhead: '#11161c', onFill: '#ffffff',
  grid: '#f6f7f9', gridBar: '#cfd5dc', gridBeat: '#e3e7ec', laneAlt: '#eff1f4', rulerBg: '#eceff3', rulerText: '#5d6672', clipBody: '#ffffff',
  shade: 'rgba(255,255,255,.62)',
  keyW: '#eceff3', keyB: '#3a4049', keyWText: '#1a1e24', keyBText: '#eef1f4', onBand: '#0b1220', tint: 1.4,
  clipBase: '#ffffff', clipBodyPct: 16, clipHeadPct: 62, clipHeadSelPct: 100, clipHeadSelTo: '#000000',
  clipInkTo: '#000000', clipInkPct: 78, clipText: '#0f1318', clipTextSel: '#ffffff', laneArm: '#f7eef1', gridShade: 'rgba(0,0,0,.045)',
};

// ---- extra themes: generated from a hue/saturation for surfaces and an accent ----
function hsl(h: number, sat: number, l: number): string {
  const s = sat / 100, L = l / 100, k = (n: number) => (n + h / 30) % 12, a = s * Math.min(L, 1 - L);
  const f = (n: number) => Math.round(255 * (L - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1)))).toString(16).padStart(2, '0');
  return '#' + f(0) + f(8) + f(4);
}

/** Extra CSS variables that are not canvas tokens. */
type Css = Record<string, string>;
export interface ThemeDef { id: string; name: string; light: boolean; t: Tokens; css: Css; swatch: [string, string, string] }

function darkTheme(id: string, name: string, h: number, s: number, accent: [string, string], o: { lift?: number; fgS?: number; warm?: [string, string, string] } = {}): ThemeDef {
  const d = o.lift ?? 0, L = (l: number) => hsl(h, s, Math.max(0, l + d)), F = (l: number) => hsl(h, o.fgS ?? Math.min(s, 14), l);
  const [green, amber, red] = o.warm ?? [DARK.green, DARK.amber, DARK.red];
  const t: Tokens = {
    ...DARK,
    bg0: L(4.5), bg1: L(6.5), bg2: L(8.4), bg3: L(9.8), bg4: L(10.6), bg5: L(11), bg6: L(13), bg7: L(14.8),
    line: L(17.6), line2: L(20.6), line3: L(21.8),
    fg: F(86), fgHi: F(96), fg2: F(74), fg3: F(64), fg4: F(53), fg5: F(40), fg6: F(32),
    blue: accent[0], blueHi: accent[1], green, amber, pan: DARK.pan, red, onBg: L(24),
    viz: L(5.5), vizPanel: L(7.5), vizGrid: L(11), vizGrid2: L(15), vizAxis: L(19), vizLabel: F(32),
    grid: L(8.4), gridBar: L(17), gridBeat: L(12.5), laneAlt: L(9.5), rulerBg: L(9.8), rulerText: F(53), clipBody: L(7.5),
    keyB: L(15), clipBase: L(7.5), laneArm: hsl(330, 18, 8.5 + d),
  };
  const css: Css = {
    '--sel-bg': L(17), '--sel-bg2': L(15), '--sel-ring': L(28), '--drag-bg': L(21), '--mixer-bg': L(7.6), '--dialog-bg': L(12.5),
    '--arm-bg': hsl(330, 14, 11 + d), '--knob-track': L(20.6), '--knob-cap': L(20.6), '--viz': t.viz,
  };
  return { id, name, light: false, t, css, swatch: [t.bg2, t.bg6, accent[0]] };
}

function lightTheme(id: string, name: string, h: number, s: number, accent: [string, string]): ThemeDef {
  const L = (l: number) => hsl(h, s, l), F = (l: number) => hsl(h, Math.min(s, 16), l);
  const t: Tokens = {
    ...LIGHT,
    bg0: L(86.5), bg1: L(94), bg2: L(97), bg3: L(95.5), bg4: L(97.5), bg5: L(93), bg6: L(90.5), bg7: L(99.5),
    line: L(85), line2: L(80.5), line3: L(78),
    fg: F(19), fgHi: F(7), fg2: F(27), fg3: F(36), fg4: F(45), fg5: F(56), fg6: F(64),
    blue: accent[0], blueHi: accent[1], onBg: hsl(h, 40, 90),
    viz: L(98.8), vizPanel: L(96.5), vizGrid: L(93.5), vizGrid2: L(89), vizAxis: L(81), grid: L(97), gridBar: L(83), gridBeat: L(91),
    laneAlt: L(94.5), rulerBg: L(93.5), clipBody: L(99.5), clipBase: L(99.5),
  };
  const css: Css = { '--sel-bg': hsl(h, 45, 90), '--sel-bg2': hsl(h, 40, 92), '--sel-ring': hsl(h, 45, 76), '--drag-bg': hsl(h, 45, 86), '--mixer-bg': L(91.5), '--dialog-bg': L(99.5), '--viz': t.viz };
  return { id, name, light: true, t, css, swatch: [t.bg2, t.bg6, accent[0]] };
}

/** A lighter grey-blue dark theme (One Dark-like panels): same elevation order as DARK, shifted up.
 *  Every CSS variable is set explicitly so nothing falls through to Grafit's `:root` values. */
const SLATE_T: Tokens = {
  // surfaces span a wide range (deep wells to raised panels) and text is near white: the first
  // version kept One Dark's narrow range and read as low-contrast grey on grey
  bg0: '#15171c', bg1: '#1d2026', bg2: '#282c34', bg3: '#2c313a', bg4: '#30353f', bg5: '#333945', bg6: '#3c424e', bg7: '#454c59',
  line: '#474e5b', line2: '#535b69', line3: '#606979',
  fg: '#d3d8e0', fgHi: '#f6f8fb', fg2: '#c4cad4', fg3: '#b6bdc9', fg4: '#a5adba', fg5: '#8f97a6', fg6: '#788190',
  blue: '#61afef', blueHi: '#a8d4fa', green: '#98c379', amber: '#e5c07b', pan: '#c678dd', red: '#e06c75', onBg: '#3d5270',
  viz: '#1a1d22', vizPanel: '#20242a', vizGrid: '#30353f', vizGrid2: '#3c424e', vizAxis: '#535b69', vizLabel: '#8f97a6',
  ink: '#f6f8fb', pre: '#b6bdc9', post: '#a8d4fa', playhead: '#ffffff', onFill: '#15171c',
  grid: '#282c34', gridBar: '#525a69', gridBeat: '#3a404b', laneAlt: '#2d323b', rulerBg: '#2c313a', rulerText: '#a5adba', clipBody: '#20242a',
  shade: 'rgba(0,0,0,.45)',
  keyW: '#d5d9e0', keyB: '#2c313a', keyWText: '#15171c', keyBText: '#f6f8fb', onBand: '#15171c', tint: 1,
  clipBase: '#20242a', clipBodyPct: 22, clipHeadPct: 52, clipHeadSelPct: 78, clipHeadSelTo: '#ffffff',
  clipInkTo: '#ffffff', clipInkPct: 85, clipText: '#f6f8fb', clipTextSel: '#15171c', laneArm: '#3a2c33', gridShade: 'rgba(255,255,255,.05)',
};
const SLATE: ThemeDef = {
  id: 'slate', name: 'Łupek', light: false, t: SLATE_T, swatch: [SLATE_T.bg2, SLATE_T.bg6, SLATE_T.blue],
  css: {
    '--sel-bg': '#48536a', '--sel-bg2': '#3c4556', '--sel-ring': '#7686a3', '--drag-bg': '#556078', '--mixer-bg': '#22262d', '--dialog-bg': '#333945',
    '--on-accent': '#15171c', '--on-warm': '#15171c', '--danger': '#f07f8a', '--arm-bg': '#44313a', '--playhead': SLATE_T.playhead,
    '--knob-track': '#535b69', '--knob-cap': '#606979', '--knob-ptr': '#ffffff', '--fader-cap': '#d5d9e0', '--shadow': 'rgba(0,0,0,.5)', '--shadow2': 'rgba(0,0,0,.36)',
    '--viz': SLATE_T.viz, '--win-close': '#c42b1c', '--on-band': SLATE_T.onBand,
  },
};

/** A mid-grey dark theme (Ableton's "Mid Dark" idea): surfaces around 20–30 % lightness, for
 *  bright rooms and for eyes that tire of near-black. Text stays near white so contrast holds. */
function midDarkTheme(id: string, name: string, h: number, s: number, accent: [string, string]): ThemeDef {
  const L = (l: number) => hsl(h, s, l), F = (l: number) => hsl(h, Math.min(s, 8), l);
  const t: Tokens = {
    ...DARK,
    bg0: L(12.5), bg1: L(16.5), bg2: L(20.5), bg3: L(22), bg4: L(23.5), bg5: L(24.5), bg6: L(28), bg7: L(31.5),
    line: L(34), line2: L(38.5), line3: L(43),
    fg: F(89), fgHi: F(98), fg2: F(83), fg3: F(76), fg4: F(68), fg5: F(60), fg6: F(51),
    blue: accent[0], blueHi: accent[1], green: '#6fcf98', amber: '#ebb35c', pan: '#b99cf7', red: '#f06b7a', onBg: hsl(218, 26, 38),
    viz: L(15), vizPanel: L(18), vizGrid: L(23.5), vizGrid2: L(28), vizAxis: L(38.5), vizLabel: F(60),
    ink: F(98), pre: F(76), post: accent[1], playhead: '#ffffff', onFill: L(12.5),
    grid: L(20.5), gridBar: L(38), gridBeat: L(27), laneAlt: L(22), rulerBg: L(22), rulerText: F(68), clipBody: L(18),
    shade: 'rgba(0,0,0,.4)', keyW: F(87), keyB: L(22), keyWText: L(12.5), keyBText: F(98), onBand: L(12.5),
    clipBase: L(18), clipBodyPct: 24, clipHeadPct: 54, clipHeadSelPct: 80, clipText: F(98), clipTextSel: L(12.5),
    laneArm: hsl(335, 12, 25), gridShade: 'rgba(255,255,255,.05)',
  };
  const css: Css = {
    '--sel-bg': hsl(218, 14, 37), '--sel-bg2': hsl(218, 12, 32), '--sel-ring': hsl(218, 20, 59), '--drag-bg': hsl(218, 14, 42),
    '--mixer-bg': L(18), '--dialog-bg': L(25), '--on-accent': L(12.5), '--on-warm': L(12.5), '--danger': '#ff8592',
    '--arm-bg': hsl(335, 14, 26), '--playhead': '#ffffff', '--knob-track': L(38.5), '--knob-cap': L(43), '--knob-ptr': '#ffffff',
    '--fader-cap': F(87), '--shadow': 'rgba(0,0,0,.45)', '--shadow2': 'rgba(0,0,0,.32)', '--viz': t.viz, '--win-close': '#c42b1c', '--on-band': L(12.5),
  };
  return { id, name, light: false, t, css, swatch: [t.bg2, t.bg6, accent[0]] };
}

/** A mid-grey light theme (Ableton's "Mid Light"): surfaces around 75–85 %, no glaring white,
 *  text and accents darkened so labels keep ≥ 4.5:1 against the panels. */
function midLightTheme(id: string, name: string, h: number, s: number, accent: [string, string]): ThemeDef {
  const L = (l: number) => hsl(h, s, l), F = (l: number) => hsl(h, Math.min(s, 14), l);
  const t: Tokens = {
    ...LIGHT,
    bg0: L(70), bg1: L(78.5), bg2: L(82), bg3: L(80.5), bg4: L(83.5), bg5: L(76.5), bg6: L(74), bg7: L(88),
    line: L(70), line2: L(66), line3: L(62),
    fg: F(14), fgHi: F(4), fg2: F(20), fg3: F(26), fg4: F(32), fg5: F(40), fg6: F(48),
    blue: accent[0], blueHi: accent[1], green: '#16784d', amber: '#8f5c08', pan: '#6a3fc4', red: '#b3243a', onBg: hsl(h, 30, 70),
    viz: L(85), vizPanel: L(81.5), vizGrid: L(78.5), vizGrid2: L(73), vizAxis: L(64), vizLabel: F(40),
    ink: F(6), pre: F(32), post: accent[0], playhead: F(4), onFill: '#ffffff',
    grid: L(82), gridBar: L(63), gridBeat: L(73.5), laneAlt: L(79.5), rulerBg: L(78.5), rulerText: F(26), clipBody: L(88),
    shade: 'rgba(200,205,212,.6)', keyW: L(94), keyWText: F(10), tint: 1.5,
    clipBase: L(88), clipBodyPct: 22, clipHeadPct: 66, clipText: F(4), laneArm: hsl(340, 14, 80), gridShade: 'rgba(0,0,0,.055)',
  };
  const css: Css = {
    '--sel-bg': hsl(h, 30, 74), '--sel-bg2': hsl(h, 26, 77), '--sel-ring': hsl(218, 40, 57), '--drag-bg': hsl(h, 32, 70),
    '--mixer-bg': L(75), '--dialog-bg': L(84), '--on-accent': '#ffffff', '--on-warm': '#ffffff', '--danger': '#a81c33',
    '--arm-bg': hsl(340, 16, 80), '--playhead': F(4), '--knob-track': L(66), '--knob-cap': L(91), '--knob-ptr': F(10),
    '--fader-cap': L(94), '--shadow': 'rgba(20,28,40,.28)', '--shadow2': 'rgba(20,28,40,.3)', '--viz': t.viz,
  };
  return { id, name, light: true, t, css, swatch: [t.bg2, t.bg6, accent[0]] };
}

/** Every theme the settings offer. Ids are saved on this computer, never rename them. */
export const THEMES: ThemeDef[] = [
  { id: 'dark', name: 'Grafit', light: false, t: DARK, css: {}, swatch: [DARK.bg2, DARK.bg6, DARK.blue] },
  SLATE,
  midDarkTheme('dim', 'Przyciemniony', 220, 5, ['#6fa3ff', '#b0ccff']),
  darkTheme('midnight', 'Północ', 220, 34, ['#5b8cff', '#9db8ff'], { lift: 1 }),
  darkTheme('violet', 'Fiolet', 265, 22, ['#a07cf6', '#c6b0ff'], { lift: 1 }),
  darkTheme('forest', 'Las', 155, 16, ['#3fbf8a', '#86e0b8'], { warm: ['#5cc98f', '#e0a44a', '#e05263'] }),
  darkTheme('studio', 'Studio', 28, 14, ['#f0973f', '#ffc285'], { lift: 1, warm: ['#7fc06a', '#e8b04a', '#e05a4f'] }),
  darkTheme('rose', 'Róż', 340, 14, ['#f06292', '#ffa6c4']),
  darkTheme('oled', 'Czerń (OLED)', 220, 6, ['#4f8ef7', '#8fb6ff'], { lift: -4, fgS: 6 }),
  { id: 'light', name: 'Jasny', light: true, t: LIGHT, css: {}, swatch: [LIGHT.bg2, LIGHT.bg6, LIGHT.blue] },
  lightTheme('paper', 'Papier', 38, 30, ['#c2651b', '#a9530f']),
  lightTheme('sky', 'Błękit', 210, 35, ['#1f6fe0', '#1858b8']),
  midLightTheme('fog', 'Mgła', 215, 10, ['#1d55c4', '#1747a8']),
  midLightTheme('sand', 'Piasek', 36, 16, ['#a4480c', '#8a3b08']),
];

const THEME_NAME_KEYS: Record<string, TranslationKey> = {
  dark: 'd.theme.dark', slate: 'd.theme.slate', midnight: 'd.theme.midnight', violet: 'd.theme.violet', forest: 'd.theme.forest', studio: 'd.theme.studio',
  rose: 'd.theme.rose', oled: 'd.theme.oled', light: 'd.theme.light', paper: 'd.theme.paper', sky: 'd.theme.sky',
  dim: 'd.theme.dim', fog: 'd.theme.fog', sand: 'd.theme.sand',
};
/** Display name of a theme in the current language (the Polish `name` stays as the data). */
export function themeName(th: ThemeDef): string { const k = THEME_NAME_KEYS[th.id]; return k ? t(k) : th.name; }

/** Current tokens (mutated in place on theme change; read at draw time). */
export const T: Tokens = { ...DARK };
/** A theme id from THEMES, or 'system' (Grafit / Jasny following the OS). */
export type ThemeMode = string;
export const theme = { epoch: 0, light: false };
const [themeVersion, setThemeVersion] = createSignal(0);
const [themeMode, setThemeModeSig] = createSignal<ThemeMode>('dark');
export { themeMode, themeVersion };

const KEY = 'wave.theme';
let mq: MediaQueryList | null = null;
let cssSet: string[] = [];

function resolve(mode: ThemeMode): ThemeDef {
  const id = mode === 'system' ? (mq?.matches ? 'light' : 'dark') : mode;
  return THEMES.find(t => t.id === id) ?? THEMES[0];
}

const VAR_TOKENS = ['bg0', 'bg1', 'bg2', 'bg3', 'bg4', 'bg5', 'bg6', 'bg7', 'line', 'line2', 'line3', 'fg', 'fgHi', 'fg2', 'fg3', 'fg4', 'fg5', 'fg6', 'blue', 'blueHi', 'green', 'amber', 'pan', 'red', 'onBg'] as const;

function apply(def: ThemeDef) {
  Object.assign(T, def.t);
  theme.light = def.light;
  theme.epoch++;
  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    root.dataset.theme = def.light ? 'light' : 'dark';
    for (const k of cssSet) root.style.removeProperty(k);
    cssSet = [];
    if (def.id !== 'dark' && def.id !== 'light') {
      const vars: Css = { ...def.css };
      for (const k of VAR_TOKENS) vars['--' + k.replace(/[A-Z]/g, m => '-' + m.toLowerCase())] = def.t[k];
      for (const [k, v] of Object.entries(vars)) { root.style.setProperty(k, v); cssSet.push(k); }
    }
  }
  setThemeVersion(v => v + 1);
}

/** Switch theme (persisted). */
export function setTheme(mode: ThemeMode) {
  try { localStorage.setItem(KEY, mode); } catch { /* private mode */ }
  setThemeModeSig(mode);
  apply(resolve(mode));
}

/** Read the saved theme and follow the OS when set to "system". Call once at startup. */
export function initTheme() {
  if (typeof window === 'undefined') return;
  mq = window.matchMedia?.('(prefers-color-scheme: light)') ?? null;
  let mode: ThemeMode = 'dark';
  try { const v = localStorage.getItem(KEY); if (v && (v === 'system' || THEMES.some(t => t.id === v))) mode = v; } catch { /* ignore */ }
  setThemeModeSig(mode);
  apply(resolve(mode));
  mq?.addEventListener?.('change', () => { if (themeMode() === 'system') apply(resolve('system')); });
}

// ---- colour helpers for canvas ----
const rgbaCache = new Map<string, string>();
/** `hex` at opacity `a` (cached). */
export function rgba(hex: string, a: number): string {
  const k = hex + a;
  let v = rgbaCache.get(k);
  if (!v) {
    let h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h.slice(0, 6), 16);
    v = `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
    rgbaCache.set(k, v);
  }
  return v;
}
