import '@fontsource-variable/geist';
import '@fontsource-variable/geist-mono';
import './styles.css';
import { render } from '@solidjs/web';
import { getBackend } from './api/backend';
import { onStateEvent } from './state/edit';
import { replaceState, S, setS } from './state/store';
import { openRack } from './state/pattern';
import { startTelemetry } from './state/telemetry';
import { restoreRecFilter } from './state/actions';
import './state/recFeedback';
import './state/patternFollow';
import { say, setU } from './state/ui';
import { watchAudio } from './state/audioWatch';
import { App } from './App';
import { AppBoundary } from './ui/PanelBoundary';
import { initTheme } from './ui/theme';
import { initPrefs, prefs } from './state/prefs';
import { setFullscreen, watchFullscreen } from './state/fullscreen';
import { initUpdates, offerWelcome } from './state/updates';
import { t } from './lib/i18n';
import { loadStdLib } from './state/library';
import { offerRecovery, projectOpen } from './state/actions';

import { installSelectPopups } from './ui/SelectPopup';
import { install as installModals } from './ui/modal';

initTheme();
installSelectPopups();
installModals();
initPrefs();
if (import.meta.env.VITE_PERF) void import('./perfHook'); // perf harness only; compiled out otherwise

async function boot() {
  const be = await getBackend();
  watchFullscreen();
  if (prefs().startFullscreen) void setFullscreen(true);
  const [catalog, state] = await Promise.all([be.fxCatalog(), be.getState()]);
  setS('catalog', catalog);
  replaceState(state);
  await be.on('state', onStateEvent);
  await restoreRecFilter();
  await startTelemetry();
  void watchAudio(() => be.audioGetConfig(), cb => be.on('audio-status', cb), say)
    .catch(e => console.error('[wave] audio status', e));
  // the standard library's file list, so the first "add channel" menu already offers it
  void loadStdLib();
  // initial selection like the prototype: the Vocal insert with its compressor
  const voc = S.project.inserts.find(m => m.fx.length > 1) ?? S.project.inserts[1] ?? S.project.inserts[0];
  if (voc) setU({ mixSel: voc.id, fxSel: voc.fx[1]?.id ?? voc.fx[0]?.id ?? null });
  const p = S.project.patterns[0];
  setU('cur', p ? { kind: 'pat', ref: p.id, clipId: null } : S.project.sources[0] ? { kind: 'audio', ref: S.project.sources[0].id, clipId: null } : null);
  setU('playing', S.transport.playing);
  const root = document.getElementById('root')!;
  root.replaceChildren(); // the loading bar from index.html
  // the last guard: a render failure no panel caught shows a full-window message (retry, reload)
  // instead of a frozen window
  render(() => <AppBoundary><App /></AppBoundary>, root);
  // nothing on the playlist yet: start on the Channel Rack, where a beat begins (FL)
  if (!S.project.clips.length && S.project.patterns.length) openRack();
  const updatesReady = initUpdates(); // version, "What's new" after an update, the first automatic check
  let offerStartupRecovery = true;
  let projectOpens = Promise.resolve();
  const openRequestedProjects = () => {
    projectOpens = projectOpens.then(async () => {
      const paths = await be.takeProjectOpenRequests();
      for (const path of paths) await projectOpen(path);
      // once, after the launch's own project opened (Explorer double-click after a crash too):
      // a restore replaces it only through the question, which names it, and guardUnsaved
      if (offerStartupRecovery) {
        offerStartupRecovery = false;
        await offerRecovery();
      }
    }).catch(e => console.error('[wave] project open request:', e));
  };
  await be.on('project-open-requested', openRequestedProjects);
  openRequestedProjects(); // also catch launches received while the webview was starting
  // the first start of a fresh install offers the demo project, unless it began with the user's own file
  void Promise.all([updatesReady, projectOpens]).then(() => offerWelcome(!S.path && !S.dirty));
}

boot().catch(e => {
  console.error(e);
  const pre = document.createElement('pre');
  pre.style.cssText = 'color:#e8607a;padding:20px;font:12px monospace';
  pre.textContent = t('startup.failed', { error: String(e?.stack ?? e) });
  document.getElementById('root')!.replaceChildren(pre);
});
