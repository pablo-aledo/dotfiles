//! `synkopa --project FILE …`: the CLI's actions run in this process on a project file, with
//! no window, no audio device, no MIDI and no session socket. The same [`actions`] the
//! running app uses, against an engine of its own.

use std::path::{Path, PathBuf};
use std::sync::Arc;

use parking_lot::Mutex;
use serde_json::Value;
use wave_engine::keys::KeysBank;
use wave_engine::{Engine, Project};

use crate::actions::{self, Host, R};
use crate::plugins::Plugins;

/// Sample rate and block of the inert audio half that keeps VST3 instances live.
const LIVE_SR: f32 = 48_000.0;
const LIVE_BLOCK: usize = 512;

pub struct Files;

impl wave_cli::Files for Files {
    fn open(&self, path: &Path) -> Result<(Box<dyn wave_cli::Doc>, Vec<String>), String> {
        let h = Headless::new(Project::empty());
        let warnings = h.engine.open(path).map_err(|e| e.to_string())?;
        Ok((Box::new(h), warnings))
    }

    fn create(&self, template: &str) -> Result<Box<dyn wave_cli::Doc>, String> {
        let p = match template {
            "empty" => Project::empty(),
            "sketch" => Project::sketch(),
            "demo" => Project::demo(),
            t => return Err(format!("unknown template `{t}` (empty, sketch, demo)")),
        };
        Ok(Box::new(Headless::new(p)))
    }
}

pub struct Headless {
    engine: Arc<Engine>,
    plugins: Arc<Plugins>,
    /// The pitch model guard: outer `None` = not tried yet; `Some(err)` = tried once, with
    /// `err` saying why it is unusable (inner `None` = usable).
    model: Mutex<Option<Option<String>>>,
    /// Synkopa Instruments instruments loaded (or that failed to load) so far, by catalog id.
    keys: Mutex<std::collections::HashMap<&'static str, R<()>>>,
    /// The audio-thread half nobody plays: it makes the engine instantiate hosted plugins
    /// live (their parameters and state are reachable), pumped by hand after each command.
    rt: Mutex<Option<wave_engine::rt::Rt>>,
}

impl Headless {
    pub(crate) fn new(project: Project) -> Self {
        let plugins = Plugins::new();
        crate::plugins::register_bundled(None);
        let engine = Engine::new(Project::empty(), plugins.factory());
        // a fresh engine has no recording take: this cannot fail
        let _ = engine.new_project(project);
        Self { engine, plugins, model: Mutex::new(None), keys: Mutex::new(Default::default()), rt: Mutex::new(None) }
    }

    /// Lets the inert audio half take the commands and graphs queued for it.
    fn pump(&self) {
        if let Some(rt) = self.rt.lock().as_mut() {
            let (mut l, mut r) = ([0f32; LIVE_BLOCK], [0f32; LIVE_BLOCK]);
            rt.process(&mut l, &mut r, None);
        }
    }
}

/// Where an installed app keeps the bundled piano (Tauri resources) relative to the binary.
fn bundled_keys() -> Option<PathBuf> {
    let exe = std::env::current_exe().ok()?;
    let dir = exe.parent()?;
    let mut c = vec![dir.join("keys"), dir.join("../Resources/keys")];
    if cfg!(debug_assertions) {
        c.push(Path::new(env!("CARGO_MANIFEST_DIR")).join("resources").join("keys"));
    }
    let piano = wave_engine::keys::instrument(wave_engine::keys::DEFAULT_INSTRUMENT)?;
    c.into_iter().find(|d| KeysBank::present(piano, d))
}

impl Host for Headless {
    fn engine(&self) -> &Arc<Engine> {
        &self.engine
    }
    fn plugins(&self) -> &Arc<Plugins> {
        &self.plugins
    }
    fn live(&self) -> bool {
        false
    }
    fn audio_json(&self) -> Value {
        Value::Null
    }
    fn cli_json(&self) -> Value {
        Value::Null
    }
    fn model_error(&self) -> Option<String> {
        self.model.lock().clone().and_then(|tried| tried)
    }
    fn set_model_error(&self, e: Option<String>) {
        // a reported error is an attempt: the guard must not reactivate over it
        *self.model.lock() = Some(e);
    }
    fn wait_keys(&self) -> R<()> {
        for id in self.engine.keys_instruments() {
            let Some(info) = wave_engine::keys::instrument(&id) else { return Err(crate::keys::unknown_msg(&id)) };
            // each instrument is loaded once per command-line session (a failure is remembered)
            let mut done = self.keys.lock();
            let r = done
                .entry(info.id)
                .or_insert_with(|| {
                    let d = crate::keys::find_dir(bundled_keys(), info).ok_or_else(|| crate::keys::missing_msg(info))?;
                    let bank = KeysBank::load_instrument(info, &d).map_err(|e| crate::keys::error_msg(info, &e))?;
                    self.engine.set_keys_bank(info.id, Some(Arc::new(bank)));
                    Ok(())
                })
                .clone();
            r?;
        }
        Ok(())
    }
    fn keys_installed(&self) -> bool {
        wave_engine::keys::instrument(wave_engine::keys::DEFAULT_INSTRUMENT)
            .is_some_and(|i| crate::keys::find_dir(bundled_keys(), i).is_some())
    }
    fn ensure_pitch_model(&self) {
        let mut m = self.model.lock();
        tried_once(&mut m, || crate::models::activate_all(&self.engine).err());
    }
    fn ensure_live_plugins(&self) {
        let mut rt = self.rt.lock();
        if rt.is_none() {
            *rt = Some(self.engine.create_rt(LIVE_SR, LIVE_BLOCK));
        }
    }
}

impl wave_cli::Doc for Headless {
    fn call(&self, command: &str, args: &Value, if_revision: Option<u64>) -> Result<Value, String> {
        let r = actions::control(self, command, args, if_revision, None);
        self.pump();
        r
    }
    fn revision(&self) -> u64 {
        self.engine.revision()
    }
    fn dirty(&self) -> bool {
        self.engine.state().dirty
    }
    fn save(&self, path: &Path) -> Result<(), String> {
        self.engine.save(path).map_err(|e| e.to_string())
    }
}

/// Runs `activate` only when the slot says "not tried yet", then remembers the outcome (the
/// error `Option`: inner `None` = the model is usable). A usable model is not reactivated on
/// every call: `activate` builds a fresh ONNX Runtime session from the ~345 MB file each time.
fn tried_once<T>(slot: &mut Option<Option<T>>, activate: impl FnOnce() -> Option<T>) {
    if slot.is_none() {
        *slot = Some(activate());
    }
}

#[cfg(test)]
mod tests {
    use super::Files;
    use serde_json::json;
    use wave_cli::Files as _;

    #[test]
    fn a_usable_model_is_not_reactivated_on_every_call() {
        let mut slot: Option<Option<String>> = None;
        let mut calls = 0;
        super::tried_once(&mut slot, || {
            calls += 1;
            None
        });
        super::tried_once(&mut slot, || {
            calls += 1;
            None
        });
        assert_eq!(calls, 1, "the model loads once per process, not once per ensure call");
        assert_eq!(slot, Some(None), "a usable model leaves no remembered error");
    }

    #[test]
    fn a_failed_activation_is_remembered_and_not_retried() {
        let mut slot = None;
        super::tried_once(&mut slot, || Some("junk bytes, not a model".to_owned()));
        super::tried_once(&mut slot, || Some("a different failure".to_owned()));
        assert_eq!(slot, Some(Some("junk bytes, not a model".to_owned())), "the first error sticks");
    }

    #[test]
    fn a_reported_model_error_counts_as_tried() {
        // f0_model_install reports its failure through set_model_error; a later ensure must
        // not reactivate over it (the OnceLock this replaces behaved the same way)
        let mut slot: Option<Option<String>> = Some(Some("no model file".to_owned()));
        super::tried_once(&mut slot, || panic!("must not run past a reported error"));
    }

    fn tmp(name: &str) -> std::path::PathBuf {
        let d = std::env::temp_dir().join(format!("wave-headless-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn a_file_is_edited_saved_and_reopened_without_the_app() {
        let d = tmp("roundtrip");
        let path = d.join("song.wave");
        let doc = Files.create("sketch").unwrap();
        assert!(!doc.dirty());
        doc.call("apply", &json!({"ops": [{"op": "setBpm", "bpm": 97}]}), None).unwrap();
        doc.call("pattern", &json!({"id": 1, "ch": "kick", "steps": "x.x. x.x. x.x. x.x."}), None).unwrap();
        assert!(doc.dirty());
        doc.save(&path).unwrap();
        assert!(!doc.dirty());

        let (doc, warnings) = Files.open(&path).unwrap();
        assert!(warnings.is_empty(), "{warnings:?}");
        assert!(!doc.dirty());
        let ctx = doc.call("context", &json!({}), None).unwrap();
        assert_eq!(ctx["bpm"], 97.0);
        let pat = doc.call("pattern", &json!({"id": 1}), None).unwrap();
        let kick = pat["rows"].as_array().unwrap().iter().find(|r| r["name"] == "Kick").unwrap();
        assert_eq!(kick["steps"], "x.x. x.x. x.x. x.x.");
        let st = doc.call("status", &json!({}), None).unwrap();
        assert_eq!(st["mode"], "file");
        assert!(st["path"].as_str().unwrap().ends_with("song.wave"));
        std::fs::remove_dir_all(&d).ok();
    }

    #[test]
    fn route_and_unroute_wire_the_mixer_and_survive_a_save() {
        let d = tmp("route");
        let path = d.join("routed.wave");
        let doc = Files.create("sketch").unwrap();
        let ins = |doc: &dyn wave_cli::Doc, id: u64| {
            let ctx = doc.call("context", &json!({}), None).unwrap();
            ctx["inserts"].as_array().unwrap().iter().find(|m| m["id"] == id).unwrap().clone()
        };
        // 2 → 1 only, at -6 dB-ish
        doc.call("route", &json!({"from": 2, "to": 1, "gain": 0.5, "only": true}), None).unwrap();
        let m = ins(&*doc, 2);
        assert_eq!(m["toMaster"], false);
        assert_eq!(m["sends"], json!([{"to": 1, "gain": 0.5}]));
        // the way back would loop
        let err = doc.call("route", &json!({"from": 1, "to": 2}), None).unwrap_err();
        assert!(err.contains("loop"), "{err}");
        // a second send, then the master again
        doc.call("route", &json!({"from": 2, "to": 3}), None).unwrap();
        doc.call("route", &json!({"from": 2, "to": 0}), None).unwrap();
        assert_eq!(ins(&*doc, 2)["toMaster"], true);
        doc.save(&path).unwrap();
        let (doc, warnings) = Files.open(&path).unwrap();
        assert!(warnings.is_empty(), "{warnings:?}");
        assert_eq!(ins(&*doc, 2)["sends"].as_array().unwrap().len(), 2);
        doc.call("unroute", &json!({"from": 2, "to": 1}), None).unwrap();
        doc.call("unroute", &json!({"from": 2, "to": 3}), None).unwrap();
        let m = ins(&*doc, 2);
        assert!(m["sends"].as_array().unwrap().is_empty() && m["toMaster"] == true);
        assert!(doc.call("unroute", &json!({"from": 2, "to": 0}), None).unwrap_err().contains("silent"));
        std::fs::remove_dir_all(&d).ok();
    }

    #[test]
    fn pattern_commands_round_trip_triggers_and_sampler_fades() {
        let dir = tmp("steps");
        let path = dir.join("steps.wave");
        let doc = Files.create("sketch").unwrap();
        let row = |v: serde_json::Value| v["rows"].as_array().unwrap().iter().find(|r| r["name"] == "Kick").unwrap().clone();
        let steps = row(doc.call("pattern", &json!({"id": 1, "ch": "kick", "steps": "x..."}), None).unwrap());
        assert!(steps.get("notes").is_none());
        let both = json!([
            {"step": 0.0, "len": 1.0, "p": 60, "v": 0.5, "trig": true},
            {"step": 4.0, "len": 1.0, "p": 60, "v": 0.75, "trig": false}
        ]);
        let explicit = row(doc.call("pattern", &json!({"id": 1, "ch": "kick", "notes": both}), None).unwrap());
        assert_eq!(explicit["notes"], both);
        doc.call("channels", &json!({"ch": "kick", "param": "fadeInMs", "value": 50}), None).unwrap();
        doc.save(&path).unwrap();
        let (reopened, warnings) = Files.open(&path).unwrap();
        assert!(warnings.is_empty());
        assert_eq!(row(reopened.call("pattern", &json!({"id": 1}), None).unwrap())["notes"], both);
        let channels = reopened.call("channels", &json!({}), None).unwrap();
        let kick = channels.as_array().unwrap().iter().find(|c| c["name"] == "Kick").unwrap();
        assert_eq!(kick["sampler"]["fadeInMs"], 50.0);
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn transport_undo_and_auditions_need_the_app() {
        let doc = Files.create("sketch").unwrap();
        for cmd in crate::actions::LIVE_ONLY {
            let e = doc.call(cmd, &json!({"id": 1, "path": "x.wave", "clipId": 1, "ch": 1}), None).unwrap_err();
            assert!(e.starts_with("NEEDS_APP"), "{cmd}: {e}");
        }
        assert!(!doc.dirty());
    }

    #[test]
    fn renders_and_stems_come_from_the_file() {
        let d = tmp("render");
        let doc = Files.create("sketch").unwrap();
        let out = d.join("mix.wav");
        let r = doc.call("render", &json!({"out": out.display().to_string(), "to": 8.0, "tail": 0.0, "rate": 44100.0}), None).unwrap();
        assert_eq!(r["stats"]["silent"], false, "{r}");
        assert_eq!(r["stats"]["sampleRate"], 44100);
        assert!(out.is_file());
        let stems = d.join("stems");
        let r = doc.call("render", &json!({"out": stems.display().to_string(), "to": 16.0, "stems": true}), None).unwrap();
        assert_eq!(r["files"].as_array().unwrap().len(), 4, "{r}");
        assert!(!doc.dirty(), "a bounce is not an edit");
        std::fs::remove_dir_all(&d).ok();
    }

    #[test]
    fn a_saved_project_renders_a_wrapped_24_bit_wav() {
        let dir = tmp("wrapped-pcm24");
        let project = dir.join("song.wave");
        Files.create("sketch").unwrap().save(&project).unwrap();
        let (doc, _) = Files.open(&project).unwrap();

        let out = dir.join("loop.wav");
        let result = doc
            .call("render", &json!({"out": out, "from": 0, "to": 4, "rate": 44100, "wrapTail": true, "wavBits": 24, "dither": true}), None)
            .unwrap();
        assert_eq!(result["wrapTail"], true);
        assert_eq!(result["tail"], 0.0);
        assert_eq!(result["stats"]["silent"], false);
        let wav = std::fs::read(out).unwrap();
        assert_eq!(u16::from_le_bytes(wav[34..36].try_into().unwrap()), 24);
        let seconds = result["stats"]["seconds"].as_f64().unwrap();
        assert!((seconds - 4.0 * 60.0 / 128.0).abs() < 1.0 / 44100.0);
        assert!(!doc.dirty());
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn plugin_access_starts_live_instances_without_breaking_edits_or_bounces() {
        let d = tmp("live");
        let doc = Files.create("sketch").unwrap();
        // the master limiter is a built-in effect, not a hosted plugin
        let e = doc.call("vst3_params", &json!({"fxId": 900}), None).unwrap_err();
        assert!(e.contains("not a loaded plugin"), "{e}");
        doc.call("set_param", &json!({"fxId": 900, "param": "ceil", "value": -1.0}), None).unwrap();
        let out = d.join("after.wav");
        let r = doc.call("render", &json!({"out": out.display().to_string(), "to": 4.0}), None).unwrap();
        assert_eq!(r["stats"]["silent"], false, "{r}");
        doc.save(&d.join("s.wave")).unwrap();
        std::fs::remove_dir_all(&d).ok();
    }

    #[test]
    fn missing_audio_is_listed_and_relinked_from_a_folder_through_the_shared_actions() {
        let d = tmp("relink");
        let old = d.join("samples").join("loop.wav");
        std::fs::create_dir_all(old.parent().unwrap()).unwrap();
        let data: Vec<f32> = (0..24_000).flat_map(|_| [0.2f32, 0.2]).collect();
        wave_engine::sources::write_wav(&old, &data, 48_000).unwrap();
        let doc = Files.create("empty").unwrap();
        doc.call("import", &json!({"paths": [old.display().to_string()], "track": 0, "beat": 0}), None).unwrap();
        let project = d.join("song.wave");
        doc.save(&project).unwrap();
        let moved = d.join("elsewhere").join("loop.wav");
        std::fs::create_dir_all(moved.parent().unwrap()).unwrap();
        std::fs::rename(&old, &moved).unwrap();

        let (doc, warnings) = Files.open(&project).unwrap();
        assert_eq!(warnings.len(), 1);
        let list = doc.call("missing", &json!({}), None).unwrap();
        let row = &list.as_array().unwrap()[0];
        assert_eq!(row["name"], "loop");
        assert_eq!(row["clips"], 1);
        assert_eq!(row["library"], false);
        let r = doc.call("relink", &json!({"folder": d.display().to_string()}), None).unwrap();
        assert_eq!(r["search"]["relinked"].as_array().unwrap().len(), 1, "{r}");
        assert!(doc.dirty());
        assert_eq!(doc.call("missing", &json!({}), None).unwrap(), json!([]));
        assert!(doc.call("relink", &json!({"sourceId": 1}), None).is_err(), "a path is required");
        std::fs::remove_dir_all(&d).ok();
    }

    #[test]
    fn a_broken_file_is_an_error_not_an_empty_project() {
        let d = tmp("broken");
        let p = d.join("x.wave");
        std::fs::write(&p, "not json").unwrap();
        let e = Files.open(&p).err().unwrap();
        assert!(e.contains("not a Synkopa project"), "{e}");
        assert!(Files.open(&d.join("missing.wave")).is_err());
        assert!(Files.create("nope").is_err());
        std::fs::remove_dir_all(&d).ok();
    }

    #[test]
    fn demo_template_saves_reopens_and_renders_without_warnings() {
        let d = tmp("demo-template");
        let path = d.join("demo.wave");
        let doc = Files.create("demo").unwrap();
        assert!(!doc.dirty());
        doc.save(&path).unwrap();
        let (reopened, warnings) = Files.open(&path).unwrap();
        assert!(warnings.is_empty(), "{warnings:?}");
        let ctx = reopened.call("context", &json!({}), None).unwrap();
        assert_eq!(ctx["bpm"], 136.0);
        let out = d.join("preview.wav");
        let r = reopened.call("render", &json!({"out": out.display().to_string(), "from": 16.0, "to": 24.0, "tail": 0.0}), None).unwrap();
        assert_eq!(r["stats"]["silent"], false, "{r}");
        assert_eq!(r["stats"]["clippedSamples"], 0, "{r}");
        std::fs::remove_dir_all(&d).ok();
    }
}
