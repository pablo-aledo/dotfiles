//! Everything the GUI and the CLI can ask for, implemented once.
//!
//! The actions run against a [`Host`]: the running app (`App`), or a project file opened
//! by `synkopa --project FILE` with no window and no audio device (`headless::Headless`).

use std::path::{Path, PathBuf};
use std::sync::Arc;

use serde_json::{json, Value};
use wave_engine::catalog::{self, load_preset, new_fx};
use wave_engine::{Engine, Fx, FxKind, Op, PluginRef, RefTune};

use crate::plugins::Plugins;

pub type R<T> = Result<T, String>;

pub fn export_project_zip(engine: &Engine, out: &Path, if_revision: Option<u64>) -> R<Value> {
    let mut out = out.to_path_buf();
    if out.extension().is_none() {
        out.set_extension("zip");
    }
    engine.export_project_zip(&out, if_revision).map_err(|e| e.to_string())?;
    Ok(json!({ "path": out.display().to_string() }))
}

/// What an action needs from the process it runs in.
pub trait Host {
    fn engine(&self) -> &Arc<Engine>;
    fn plugins(&self) -> &Arc<Plugins>;
    /// True in the running app: an audio device, a live undo history and a musician.
    /// False for a project file edited from the command line.
    fn live(&self) -> bool;
    fn audio_json(&self) -> Value;
    fn cli_json(&self) -> Value;
    /// Why the installed RMVPE model could not be used, if it could not.
    fn model_error(&self) -> Option<String>;
    /// After an install attempt: remember why the model still cannot be used, or clear it.
    fn set_model_error(&self, _e: Option<String>) {}
    /// Before an offline bounce: the Synkopa Instruments piano the project plays is loaded.
    fn wait_keys(&self) -> R<()>;
    /// Before pitch work or a bounce of pitch-edited clips: the pitch model is in place.
    fn ensure_pitch_model(&self) {}
    /// Before VST3 parameter access: the project's plugins run as live instances.
    fn ensure_live_plugins(&self) {}
    /// The Synkopa Instruments piano recordings are on this computer (an import gives piano parts to it).
    fn keys_installed(&self) -> bool {
        false
    }
    /// Where FX chain presets are kept (the user's library; tests use a temporary folder).
    fn fx_chain_dir(&self) -> PathBuf {
        crate::fx_chains::default_dir()
    }
}

/// Commands that need the audio device, the musician's undo history or the app's window.
pub const LIVE_ONLY: &[&str] = &["play", "stop", "pattern_play", "pattern_loop", "comp_audition", "note_audition", "undo", "redo", "open"];

/// Every verb `control` answers — the `catalog` reply's command list, the front door scripts
/// are told to consult. A verb added without an entry here is invisible to them.
pub const ALL_COMMANDS: &[&str] = &[
    "status",
    "context",
    "catalog",
    "schema",
    "apply",
    "undo",
    "redo",
    "play",
    "stop",
    "render",
    "import",
    "add_fx",
    "route",
    "unroute",
    "sidechain",
    "set_param",
    "load_preset",
    "save",
    "open",
    "export_project_zip",
    "pitch_analyze",
    "pitch_target",
    "pitch_inspect",
    "pitch_compare",
    "pitch_suggest",
    "pitch_edit",
    "pitch_render",
    "melody_channels",
    "melody_reference",
    "tune_ref",
    "f0_model",
    "f0_model_install",
    "note_model",
    "note_model_install",
    "music_analyze",
    "chords_model",
    "chords_model_install",
    "chords_analyze",
    "chords_to_pattern",
    "audio_to_midi",
    "auto_vocal_plan",
    "auto_vocal",
    "master_listen",
    "bake_rider",
    "midi_inspect",
    "midi_import",
    "midi_export",
    "mix_assistant",
    "masking",
    "unmask",
    "mask_ignore",
    "fx_chains",
    "fx_chain_save",
    "fx_chain_load",
    "fx_chain_rename",
    "fx_chain_delete",
    "missing",
    "relink",
    "set_project",
    "make_unique",
    "export_in_place",
    "stems_model",
    "stems_model_install",
    "extract_stems",
    "takes",
    "comp",
    "flatten_comp",
    "comp_audition",
    "channels",
    "markers",
    "pattern",
    "pattern_play",
    "pattern_loop",
    "note_audition",
    "plugin_scan",
    "plugin_add",
    "plugin_params",
    "plugin_set_param",
    "plugin_load_anyway",
    "vst3_scan",
    "vst3_add",
    "vst3_params",
    "vst3_set_param",
];

fn live_only_error(cmd: &str) -> String {
    let why = match cmd {
        "undo" | "redo" => "a project file has no undo history (each `synkopa --project` call starts fresh; edit with `apply` and keep the file under version control, or use --dry-run / --save-as to try an edit)",
        "open" => "pass the file with --project instead",
        _ => "it plays through the audio device; render with `synkopa --project FILE render --out x.wav` to listen",
    };
    format!("NEEDS_APP: `{cmd}` needs the running app: {why}")
}

pub(crate) fn arg<'a>(a: &'a Value, k: &str) -> Option<&'a Value> {
    a.get(k).filter(|v| !v.is_null())
}
pub(crate) fn as_index(v: &Value) -> Option<u64> {
    v.as_u64().or_else(|| v.as_f64().filter(|f| *f >= 0.0 && f.fract() == 0.0).map(|f| f as u64))
}
pub(crate) fn need_u64(a: &Value, k: &str) -> R<u64> {
    arg(a, k).and_then(as_index).ok_or(format!("`{k}` (whole number) is required"))
}
pub(crate) fn need_str<'a>(a: &'a Value, k: &str) -> R<&'a str> {
    arg(a, k).and_then(Value::as_str).ok_or(format!("`{k}` (string) is required"))
}
/// A `[from, to]` pair of beats (`null` or missing = none).
fn beat_range(a: &Value, k: &str) -> R<Option<(f64, f64)>> {
    match arg(a, k) {
        None | Some(Value::Null) => Ok(None),
        Some(Value::Array(v)) if v.len() == 2 => match (v[0].as_f64(), v[1].as_f64()) {
            (Some(x), Some(y)) => Ok(Some((x, y))),
            _ => Err(format!("`{k}` must be two numbers (beats)")),
        },
        Some(_) => Err(format!("`{k}` must be [from, to] in beats")),
    }
}

pub(crate) fn opt_f64(a: &Value, k: &str) -> Option<f64> {
    arg(a, k).and_then(Value::as_f64)
}

pub fn parse_kind(s: &str) -> R<FxKind> {
    serde_json::from_value(json!(s)).map_err(|_| {
        format!("unknown effect type `{s}` (eq, comp, gate, filter, sat, delay, half, warp, chorus, phaser, stereo, multiband, analyzer, reverb, limit, master, fet, deess, tune, denoise, voice, rider)")
    })
}

pub fn add_fx(app: &dyn Host, insert_id: u64, kind: FxKind, preset: Option<usize>, index: Option<usize>) -> R<(u64, u64)> {
    if kind == FxKind::Plugin {
        return Err("use plugin_add for hosted plugins".into());
    }
    let p = app.engine().project();
    if p.insert(insert_id).is_none() {
        return Err(format!("no insert {insert_id}"));
    }
    let id = p.next_id;
    let mut fx = new_fx(id, kind, p.bpm);
    if let Some(i) = preset {
        if !load_preset(&mut fx, i, p.bpm) {
            return Err(format!("{} has no preset {i}", catalog::type_name(kind)));
        }
    }
    let rev = app.engine().apply(&[Op::PutFx { insert_id, fx, index }], false, None).map_err(|e| e.to_string())?;
    Ok((id, rev))
}

/// Ducking settings for a Compressor that [`sidechain`] adds (the mixer's "Sidechain to ▸" uses
/// the same, `ui/src/state/sidechain.ts`): fast attack, a release that swells back before the
/// next beat, deep enough to hear the pump on a typical kick.
pub const DUCK_PARAMS: [(&str, f64); 6] = [("thr", -24.0), ("ratio", 6.0), ("att", 1.0), ("rel", 150.0), ("gain", 0.0), ("det", 0.0)];

/// Sidechain compression: a Compressor whose detector listens to another insert.
///
/// * `fx` given: that Compressor listens to `from` (`off`: back to its own input).
/// * otherwise, as FL Studio's "Sidechain to this track": insert `from` drives a Compressor on
///   `to`: one already keyed from it is kept, else the first Compressor of `to`'s chain without
///   a sidechain gets it, else a Compressor set up for ducking is added at the end. `off`:
///   every Compressor on `to` keyed from `from` goes back to its own input.
///
/// One undo step named `label`. Returns the Compressor (`null` after `off` without `fx`),
/// whether it was added, and the revision.
pub fn sidechain(
    app: &dyn Host,
    fx: Option<u64>,
    from: Option<u64>,
    to: Option<u64>,
    off: bool,
    if_revision: Option<u64>,
    label: Option<&str>,
) -> R<Value> {
    let p = app.engine().project();
    let apply = |ops: &[Op]| app.engine().apply_labeled(ops, false, if_revision, label).map_err(|e| e.to_string());
    if let Some(fx_id) = fx {
        let (m, f) = p.find_fx(fx_id).ok_or(format!("no effect {fx_id}"))?;
        let mut f = f.clone();
        f.key = if off { None } else { Some(from.ok_or("pass --from INSERT (or --off)")?) };
        let rev = apply(&[Op::PutFx { insert_id: m.id, fx: f, index: None }])?;
        return Ok(json!({ "fxId": fx_id, "added": false, "revision": rev }));
    }
    let (from, to) = (from.ok_or("pass --from INSERT")?, to.ok_or("pass --to INSERT (or --fx ID)")?);
    let m = p.insert(to).ok_or(format!("no insert {to}"))?;
    p.insert(from).ok_or(format!("no insert {from}"))?;
    // ducking is a Compressor's: a Gate or Filter keyed from `from` was set up in its own window
    // and is neither "already sidechained" nor removed by `off`
    let keyed: Vec<&Fx> = m.fx.iter().filter(|f| f.kind == FxKind::Comp && f.key == Some(from)).collect();
    if off {
        let ops: Vec<Op> = keyed.iter().map(|f| Op::PutFx { insert_id: to, fx: Fx { key: None, ..(*f).clone() }, index: None }).collect();
        if ops.is_empty() {
            return Err(format!("no effect on insert {to} listens to insert {from}"));
        }
        let rev = apply(&ops)?;
        return Ok(json!({ "fxId": null, "added": false, "revision": rev }));
    }
    if let Some(f) = keyed.first() {
        return Ok(json!({ "fxId": f.id, "added": false, "revision": app.engine().state().revision }));
    }
    // "Sidechain to" means ducking: it keys a free Compressor (a Gate or Filter is keyed from its own window)
    if let Some(f) = m.fx.iter().find(|f| f.kind == FxKind::Comp && f.key.is_none()) {
        let rev = apply(&[Op::PutFx { insert_id: to, fx: Fx { key: Some(from), ..f.clone() }, index: None }])?;
        return Ok(json!({ "fxId": f.id, "added": false, "revision": rev }));
    }
    let id = p.next_id;
    let mut f = new_fx(id, FxKind::Comp, p.bpm);
    for (k, v) in DUCK_PARAMS {
        f.params.insert(k.into(), v);
    }
    f.preset = None;
    f.key = Some(from);
    let rev = apply(&[Op::PutFx { insert_id: to, fx: f, index: None }])?;
    Ok(json!({ "fxId": id, "added": true, "revision": rev }))
}

/// Mixer routing (FL Studio style): insert `from` sends to insert `to` at `gain` (linear,
/// 0..2; a send that exists gets the new level). `to` = 0 (the master) turns the output into
/// the master back on. `only`: the output goes only where it sends, no longer to the master
/// ("route to this track only"). A send that would close a loop is refused.
pub fn route(app: &dyn Host, from: u64, to: u64, gain: Option<f32>, only: bool, if_revision: Option<u64>) -> R<u64> {
    let p = app.engine().project();
    let mut m = p.insert(from).cloned().ok_or(format!("no insert {from}"))?;
    if from == 0 {
        return Err("the master is the output: it sends nowhere".into());
    }
    if to == 0 {
        m.master = true;
    } else {
        if p.insert(to).is_none() {
            return Err(format!("no insert {to}"));
        }
        match m.sends.iter_mut().find(|s| s.to == to) {
            Some(s) => s.gain = gain.unwrap_or(s.gain),
            None => m.sends.push(wave_engine::model::InsertSend { to, gain: gain.unwrap_or(1.0) }),
        }
        if only {
            m.master = false;
        }
    }
    app.engine().apply(&[Op::PutInsert { insert: m }], false, if_revision).map_err(|e| e.to_string())
}

/// Removes insert `from`'s send to `to`; `to` = 0 stops its output into the master (it then
/// goes only where it sends, so it must send somewhere).
pub fn unroute(app: &dyn Host, from: u64, to: u64, if_revision: Option<u64>) -> R<u64> {
    let p = app.engine().project();
    let mut m = p.insert(from).cloned().ok_or(format!("no insert {from}"))?;
    if to == 0 {
        if m.sends.is_empty() {
            return Err(format!("insert {from} sends nowhere else: it would fall silent (mute it instead)"));
        }
        m.master = false;
    } else {
        let n = m.sends.len();
        m.sends.retain(|s| s.to != to);
        if m.sends.len() == n {
            return Err(format!("insert {from} does not send to insert {to}"));
        }
        // nothing left to go to: back to the master rather than silence
        if m.sends.is_empty() {
            m.master = true;
        }
    }
    app.engine().apply(&[Op::PutInsert { insert: m }], false, if_revision).map_err(|e| e.to_string())
}

/// The clip's source was already baked: its name ends " (rider)". The chain then leaves the
/// rider out (it is in the audio) and no second bake is made — same guard as the app.
fn already_baked(e: &Engine, clip_id: u64) -> bool {
    let p = e.project();
    p.clips
        .iter()
        .find(|c| c.id == clip_id)
        .and_then(|c| p.sources.iter().find(|s| s.id == c.source))
        .map(|s| s.name.ends_with(" (rider)"))
        .unwrap_or(false)
}

/// The Auto Vocal plan as ops on `insert`: the insert's effects of the kinds the chain brings
/// (and any old rider) are removed — others, e.g. an EQ, stay in front — then each stage is put
/// with its calibrated params (full param sets over the defaults, the stage's mix, bypassed when
/// not enabled, not a preset). The plan leaves the vocal far under the limiter, so the level
/// suggestion is folded into the limiter's gain to bring it to mix level (what the app does).
/// Returns the ops and the ids the chain stages will get.
fn chain_ops(e: &Engine, insert: u64, plan: &wave_engine::autovocal::AutoVocalPlan) -> (Vec<Op>, Vec<u64>) {
    let p = e.project();
    let makeup = plan.track_gain_db.unwrap_or(-18.0 - plan.stages.lufs_after);
    let makeup = (makeup.clamp(0.0, 24.0) * 10.0).round() / 10.0;
    let mut kinds = plan.chain.iter().map(|f| f.kind).collect::<std::collections::HashSet<_>>();
    kinds.insert(FxKind::Rider);
    let mut ops: Vec<Op> = p
        .insert(insert)
        .into_iter()
        .flat_map(|m| m.fx.iter())
        .filter(|f| kinds.contains(&f.kind))
        .map(|f| Op::RemoveFx { fx_id: f.id })
        .collect();
    let mut ids = Vec::with_capacity(plan.chain.len());
    for (n, stage) in plan.chain.iter().enumerate() {
        let id = p.next_id + n as u64;
        let mut fx = new_fx(id, stage.kind, p.bpm);
        fx.params.extend(stage.params.iter().map(|(k, v)| (k.clone(), *v)));
        fx.mix = stage.mix as f32;
        fx.preset = None;
        fx.bypass = !stage.enabled;
        if stage.kind == FxKind::Limit {
            let gain = fx.params.get("gain").copied().unwrap_or(0.0) + makeup;
            fx.params.insert("gain".into(), gain.clamp(0.0, 24.0));
        }
        ops.push(Op::PutFx { insert_id: insert, fx, index: None });
        ids.push(id);
    }
    (ops, ids)
}

/// "Auto Vocal" as one action — the whole journey the app's button and `synkopa auto-vocal`
/// share: measure the clip (the beat clip joins the key analysis), bake the Vocal Rider into
/// the audio unless it is already there or `no_bake`, and put the calibrated chain on the
/// clip's insert (same-kind effects are replaced, an EQ in front stays). The bake and the
/// chain are two undo steps; `label` names the chain's step (the bake keeps the engine's
/// own). `progress` reports the stages ("plan", "bake", "chain") for front doors that show
/// them. A stale `if_revision` refuses before the bake, not after half the job; the apply's
/// own guard skips the bake's own step. The reply carries the plan summary the button's
/// toast quotes (`key`, `spread`).
#[allow(clippy::too_many_arguments)] // the verb's whole surface, one optional each
pub fn auto_vocal(
    app: &dyn Host,
    clip: u64,
    beat: Option<u64>,
    style: wave_engine::autovocal::Style,
    no_bake: bool,
    if_revision: Option<u64>,
    label: Option<&str>,
    progress: &dyn Fn(&str),
) -> R<Value> {
    let e = app.engine();
    app.ensure_pitch_model();
    // the guard is checked at entry as well: a stale one refuses before the bake, not
    // after half of the job is done
    if let Some(r) = if_revision {
        if e.revision() != r {
            return Err(format!("{} project is at revision {}, not {r}", wave_engine::errors::ERR_REVISION_CONFLICT, e.revision()));
        }
    }
    // the insert and the revision it was read at are captured together, before the plan and
    // the bake take their time: an edit that re-routes the clip meanwhile makes the apply's
    // guard refuse, instead of the chain landing on the insert the clip no longer plays
    let base = e.revision();
    let insert = e.clip_insert(clip).ok_or("no such clip")?;
    if insert == 0 {
        return Err("the clip plays on the master insert; route its track to its own mixer insert first".into());
    }
    // every refusal is done: only now does the journey report its first stage, so a refused
    // run reports none (the mock and the UI's stage list count the same way)
    progress("plan");
    let plan = e.auto_vocal_plan(clip, beat, style, !no_bake).map_err(|x| x.to_string())?;
    // the rider is rendered into the audio instead of living on the insert (no playback
    // delay); a clip that was baked before is not baked twice (same guard as the app)
    let mut baked = None;
    if let Some(rb) = plan.rider_bake.as_ref().filter(|_| !already_baked(e, clip)) {
        progress("bake");
        // the engine checks the guard under the commit lock: a project that moved on
        // while the rider rendered refuses the bake before a source is written
        let (s, c) = e.bake_rider(clip, &rb.params, if_revision).map_err(|x| x.to_string())?;
        baked = Some(json!({ "sourceId": s, "clipId": c }));
    }
    progress("chain");
    let (ops, fx_ids) = chain_ops(e, insert, &plan);
    // the apply is guarded on the revision captured before the plan: our own bake moved
    // the project one step past it (a foreign change still conflicts), the caller's own
    // guard counts from the entry check instead
    let guard = Some(if_revision.unwrap_or(base) + u64::from(baked.is_some()));
    if let Err(x) = e.apply_labeled(&ops, false, guard, label) {
        // the bake is already committed (its own undo step): say so, or a retry skips it
        // as already baked and the caller never learns the audio changed
        return Err(match &baked {
            Some(b) => format!(
                "{x} (the rider was already baked into the clip: {b}, project now at revision {}; the effect chain was not added, run auto-vocal again to add it)",
                e.revision()
            ),
            None => x.to_string(),
        });
    }
    Ok(json!({
        "revision": e.revision(), "clipId": clip, "insertId": insert, "style": plan.style,
        "riderBaked": baked, "fxIds": fx_ids, "fxCount": plan.chain.iter().filter(|s| s.enabled).count(),
        "trackGainDb": plan.track_gain_db, "warnings": plan.warnings,
        "key": plan.analysis.key.as_ref().map(|k| k.name.clone()), "spread": plan.stages.iqr400_db,
    }))
}

/// Set while a Master listen runs; `master_listen_cancel` raises it.
pub static MASTER_LISTEN_CANCEL: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// The Master's "listen to the whole song" as one action — the effect window's button, the
/// automatic first listen when a Master is added, and `synkopa master-listen` share it: render
/// what reaches the effect over the whole song, measure, set every control
/// (`wave_engine::mastering`), and store the report on the effect. One undo step (`label`,
/// default "Master: listen"). `target` overrides the effect's own Target. The apply is guarded on
/// the revision the listen started from: a project edited meanwhile is refused (listen again)
/// rather than given settings for a song it no longer is. `progress` gets 0..1.
pub fn master_listen(
    app: &dyn Host,
    fx_id: u64,
    target: Option<usize>,
    if_revision: Option<u64>,
    label: Option<&str>,
    progress: &mut dyn FnMut(f32),
) -> R<Value> {
    use std::sync::atomic::Ordering::Relaxed;
    let e = app.engine();
    if let Some(r) = if_revision {
        if e.revision() != r {
            return Err(format!("{} project is at revision {}, not {r}", wave_engine::errors::ERR_REVISION_CONFLICT, e.revision()));
        }
    }
    if let Some(t) = target {
        if t >= wave_engine::dsp::master::TARGETS.len() {
            return Err(format!("`target` is 0..{}", wave_engine::dsp::master::TARGETS.len() - 1));
        }
    }
    let base = e.revision();
    // the flag is cleared when a listen ends, not when it starts: a Stop pressed while the listen
    // still waits in the edit queue must cancel it
    let got = e.master_listen(fx_id, target, &MASTER_LISTEN_CANCEL, progress).map_err(|x| x.to_string());
    MASTER_LISTEN_CANCEL.store(false, Relaxed);
    let got = got?;
    let p = e.project();
    let (insert, old) = p.find_fx(fx_id).ok_or("the effect was removed while listening")?;
    let mut fx = old.clone();
    fx.params = got.params;
    fx.listen = Some(got.report.clone());
    fx.preset = None;
    let ops = [Op::PutFx { insert_id: insert.id, fx, index: None }];
    e.apply_labeled(&ops, false, Some(if_revision.unwrap_or(base)), Some(label.unwrap_or("Master: listen")))
        .map_err(|x| format!("{x} (the project changed while the Master was listening; listen again)"))?;
    let fx = e.project().find_fx(fx_id).map(|(_, f)| f.clone());
    Ok(json!({ "revision": e.revision(), "fxId": fx_id, "fx": fx, "listen": got.report }))
}

/// The RMVPE model download as one action, the button and `synkopa f0-model-install` share:
/// install (SHA-256 checked inside `models::install`), activate, and remember why the model
/// still cannot be used. `progress` reports (done, total) for front doors that show a bar.
pub fn f0_model_install(app: &dyn Host, progress: &dyn Fn(u64, u64)) -> Result<crate::models::ModelStatus, String> {
    if let Err(e) = crate::models::install(progress) {
        app.set_model_error(Some(e.clone()));
        return Err(e);
    }
    match crate::models::activate(app.engine()) {
        Ok(true) => {
            app.set_model_error(None);
            Ok(crate::models::status(app.engine(), None))
        }
        Ok(false) => {
            let m = "the model file is missing after the install".to_string();
            app.set_model_error(Some(m.clone()));
            Err(m)
        }
        Err(m) => {
            app.set_model_error(Some(m.clone()));
            Err(m)
        }
    }
}

/// The clip's pitch analysis, with the model ensured first — what the button, the CLI and
/// `pitch inspect` all start from.
pub fn pitch_analysis(app: &dyn Host, clip: u64) -> Result<std::sync::Arc<wave_engine::pitch::PitchAnalysis>, String> {
    app.ensure_pitch_model();
    app.engine().pitch_analysis(clip).map_err(|e| e.to_string())
}

/// The clip's tune-to-reference target, with the model ensured first.
pub fn pitch_target(
    app: &dyn Host,
    clip: u64,
    reference: Option<RefTune>,
) -> Result<std::sync::Arc<wave_engine::reference::PitchTarget>, String> {
    app.ensure_pitch_model();
    app.engine().pitch_target(clip, reference).map_err(|e| e.to_string())
}

/// "Auto wokal"'s plan (read-only measure), with the model ensured first.
pub fn vocal_plan(
    app: &dyn Host,
    clip: u64,
    beat: Option<u64>,
    style: wave_engine::autovocal::Style,
    bake: bool,
) -> Result<wave_engine::autovocal::AutoVocalPlan, String> {
    app.ensure_pitch_model();
    app.engine().auto_vocal_plan(clip, beat, style, bake).map_err(|e| e.to_string())
}

/// Tempo and key of a clip, or of the project's active audio clips.
pub fn music_analysis(app: &dyn Host, clip: Option<u64>, exclude: Option<u64>) -> Result<wave_engine::music::MusicAnalysis, String> {
    app.engine().music_analysis(clip, exclude).map_err(|e| e.to_string())
}

/// The plugin scan, with the project's plugins running live while it is read.
pub fn plugin_scan(app: &dyn Host, rescan: bool) -> Result<crate::plugins::ScanResult, String> {
    app.ensure_live_plugins();
    Ok(app.plugins().scan(rescan))
}

/// A hosted plugin's parameters, with the project's plugins running live.
pub fn plugin_params(app: &dyn Host, fx: u64) -> Result<Vec<crate::plugins::ParamInfo>, String> {
    app.ensure_live_plugins();
    app.plugins().params(fx)
}

/// Sets a hosted plugin parameter, with the project's plugins running live.
pub fn plugin_set_param(app: &dyn Host, fx: u64, id: u32, value: f64) -> Result<(), String> {
    app.ensure_live_plugins();
    app.plugins().set_param(fx, id, value)
}

/// Renders the Vocal Rider into an audio clip's audio as a new source and swaps the clip onto
/// it (one undo step; the original source stays). The button's journey step and `synkopa
/// bake-rider` share it.
pub fn bake_rider(app: &dyn Host, clip: u64, params: &std::collections::BTreeMap<String, f64>, if_revision: Option<u64>) -> R<Value> {
    let (source, baked) = app.engine().bake_rider(clip, params, if_revision).map_err(|x| x.to_string())?;
    Ok(json!({ "clipId": baked, "sourceId": source, "revision": app.engine().revision() }))
}

/// FL's *Export in place*: the selected clips rendered to one audio clip on a new track below
/// them (originals muted, one undo step). A bounce waits for the Synkopa Keys piano first; a
/// cancelled bounce comes back as the error [`wave_engine::errors::ERR_CANCELLED`].
pub fn export_in_place(
    app: &dyn Host,
    ids: &[u64],
    range: Option<(f64, f64)>,
    cancel: &std::sync::atomic::AtomicBool,
    progress: &mut dyn FnMut(wave_engine::RenderProgress),
) -> R<Value> {
    app.wait_keys()?;
    let r = app.engine().export_in_place(ids, range, IN_PLACE_RATE, cancel, progress).map_err(|x| x.to_string())?;
    Ok(json!({ "sourceId": r.source_id, "clipId": r.clip_id, "track": r.track, "revision": app.engine().revision() }))
}

/// FL's *Make unique*: the clips get their own copy of their source on a new track right below
/// theirs (one undo step; other clips of the source are untouched).
pub fn make_unique(app: &dyn Host, ids: &[u64]) -> R<Value> {
    let r = app.engine().make_unique_audio(ids).map_err(|x| x.to_string())?;
    Ok(json!({ "sourceId": r.source_id, "track": r.track, "insertId": r.insert_id, "revision": app.engine().revision() }))
}

/// The comp clip rendered to one audio source; the clip plays it instead (one undo step).
pub fn flatten_comp(app: &dyn Host, clip: u64) -> R<Value> {
    let id = app.engine().flatten_comp(clip).map_err(|x| x.to_string())?;
    Ok(json!({ "clipId": clip, "sourceId": id, "revision": app.engine().revision() }))
}

pub fn set_param(app: &dyn Host, fx_id: u64, param: &str, value: f64, if_revision: Option<u64>) -> R<u64> {
    let p = app.engine().project();
    let (m, f) = p.find_fx(fx_id).ok_or(format!("no effect {fx_id}"))?;
    let def = catalog::params(f.kind).iter().find(|d| d.id == param).ok_or_else(|| {
        format!(
            "{} has no parameter `{param}` (has: {})",
            catalog::type_name(f.kind),
            catalog::params(f.kind).iter().map(|d| d.id).collect::<Vec<_>>().join(", ")
        )
    })?;
    if !(def.min..=def.max).contains(&value) {
        return Err(format!("{param} must be within {}..{} {}", def.min, def.max, def.unit));
    }
    let mut f = f.clone();
    f.params.insert(param.into(), value);
    app.engine().apply(&[Op::PutFx { insert_id: m.id, fx: f, index: None }], false, if_revision).map_err(|e| e.to_string())
}

pub fn preset(app: &dyn Host, fx_id: u64, index: usize) -> R<u64> {
    let p = app.engine().project();
    let (m, f) = p.find_fx(fx_id).ok_or(format!("no effect {fx_id}"))?;
    let mut f = f.clone();
    if !load_preset(&mut f, index, p.bpm) {
        return Err(format!("no preset {index}"));
    }
    app.engine().apply(&[Op::PutFx { insert_id: m.id, fx: f, index: None }], false, None).map_err(|e| e.to_string())
}

/// "Load anyway": the effect or plugin channel `id` (and every other use of the same plugin)
/// loads although Synkopa's safety check refused it, from now on. Not an edit (no undo step).
pub fn plugin_load_anyway(app: &dyn Host, id: u64) -> R<()> {
    let p = app.engine().project();
    let (plugin, instrument) = match p.find_fx(id) {
        Some((_, f)) => (f.plugin.clone().ok_or("that effect is not a hosted plugin")?, false),
        None => match p.channel(id).and_then(wave_engine::Channel::plugin) {
            Some(pl) => (pl.clone(), true),
            None => return Err(format!("no plugin effect or plugin channel has id {id}")),
        },
    };
    app.plugins().trust(&plugin, instrument);
    app.ensure_live_plugins();
    app.engine().retry_plugins();
    Ok(())
}

/// Put a scanned plugin (`format` `vst3` or `lv2`; LV2 plugins are found by `cid`, their
/// URI, and `path` may be empty) on an insert.
pub fn plugin_add(app: &dyn Host, insert_id: u64, format: &str, path: &str, cid: &str, index: Option<usize>) -> R<(u64, u64)> {
    if format != PluginRef::VST3 && format != PluginRef::LV2 {
        return Err(format!("unknown plugin format `{format}` (vst3, lv2)"));
    }
    // an LV2 plugin is named by its URI alone; a VST3 needs its module path to be unambiguous
    if format == PluginRef::VST3 && path.is_empty() {
        return Err("`path` is required for a VST3 plugin".into());
    }
    let p = app.engine().project();
    if p.insert(insert_id).is_none() {
        return Err(format!("no insert {insert_id}"));
    }
    let entry = app.plugins().info(format, path, cid).ok_or("that plugin is not in the scan results; run a plugin scan first")?;
    if let Some(why) = &entry.unsupported {
        return Err(format!("{} cannot be used: {why}", entry.name));
    }
    // the load error below comes from instantiating the plugin live
    app.ensure_live_plugins();
    let id = p.next_id;
    let fx = wave_engine::Fx {
        id,
        kind: FxKind::Plugin,
        bypass: false,
        mix: 1.0,
        preset: None,
        params: Default::default(),
        bands: None,
        plugin: Some(PluginRef {
            format: entry.format,
            path: entry.path,
            cid: entry.cid,
            name: entry.name,
            vendor: entry.vendor,
            state: None,
        }),
        maps: None,
        listen: None,
        key: None,
    };
    let rev = app.engine().apply(&[Op::PutFx { insert_id, fx, index }], false, None).map_err(|e| e.to_string())?;
    if let Some(err) = app.engine().state().fx_errors.get(&id) {
        return Err(format!("added, but the plugin failed to load: {err}"));
    }
    Ok((id, rev))
}

/// Level statistics of interleaved stereo.
pub fn stats(x: &[f32], sr: u32) -> Value {
    let n = x.len().max(1);
    let peak = x.iter().fold(0f32, |a, b| a.max(b.abs()));
    let rms = (x.iter().map(|v| (v * v) as f64).sum::<f64>() / n as f64).sqrt() as f32;
    let clipped = x.iter().filter(|v| v.abs() >= 0.999).count();
    let db = |g: f32| if g > 1e-9 { (20.0 * (g as f64).log10() * 10.0).round() / 10.0 } else { -180.0 };
    json!({
        "seconds": x.len() as f64 / 2.0 / sr as f64,
        "sampleRate": sr,
        "peakDbfs": db(peak),
        "rmsDbfs": db(rms),
        "crestDb": ((db(peak) - db(rms)) * 10.0).round() / 10.0,
        "clippedSamples": clipped,
        "silent": peak < 1e-5,
    })
}

/// Output container of an offline bounce.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ExportFormat {
    Wav(WavEncoding),
    Mp3 { kbps: u32 },
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum WavEncoding {
    #[default]
    Float32,
    Pcm24 {
        dither: bool,
    },
    /// CD audio: 16-bit signed PCM.
    Pcm16 {
        dither: bool,
    },
}

impl WavEncoding {
    pub fn parse(bits: Option<u32>, dither: bool) -> R<Self> {
        match bits.unwrap_or(32) {
            16 => Ok(Self::Pcm16 { dither }),
            24 => Ok(Self::Pcm24 { dither }),
            32 if !dither => Ok(Self::Float32),
            32 => Err("dither applies only to 16- or 24-bit PCM WAV".into()),
            _ => Err("WAV bit depth must be 16 or 24 (PCM) or 32 (float)".into()),
        }
    }

    fn write(self, out: &std::path::Path, audio: &[f32], rate: u32) -> R<()> {
        use wave_engine::sources::{write_wav, write_wav_pcm16, write_wav_pcm24};
        match self {
            Self::Float32 => write_wav(out, audio, rate),
            Self::Pcm24 { dither } => write_wav_pcm24(out, audio, rate, dither),
            Self::Pcm16 { dither } => write_wav_pcm16(out, audio, rate, dither),
        }
    }
}

/// How many slices the live waveform of an export has (`ExportStatus::wave`).
pub const WAVE_SLICES: usize = 240;

/// Sample rate of the audio *Export in place* writes.
pub const IN_PLACE_RATE: u32 = 48_000;

/// What an export is doing right now, for the progress readout (`export-progress`).
#[derive(Clone, Debug, PartialEq, serde::Serialize)]
pub struct ExportStatus {
    /// Files finished before the current one, and how many there are; `done == total` at the end.
    pub done: usize,
    pub total: usize,
    /// The file being made ("Master", an insert name, or the mix's file name); "" at the end.
    pub name: String,
    /// `prepare` (time-stretching audio), `render`, `write` (encoding the file) or `done`.
    pub stage: &'static str,
    /// 0‥1 through the current file's stage.
    pub frac: f64,
    /// Song position just rendered, in beats (past the end while the tail rings out).
    pub beat: f64,
    /// Largest |sample| of the current file so far (above 1.0 clips in an integer file).
    pub peak: f32,
    /// The current file's peak per slice, 0‥255 for 0‥1 (louder is 255), `WAVE_SLICES` long.
    pub wave: Vec<u8>,
}

/// Turns the engine's per-block render reports into throttled [`ExportStatus`] updates.
struct Tracker<'a> {
    report: &'a dyn Fn(&ExportStatus),
    status: ExportStatus,
    peaks: Vec<f32>,
    last: Option<std::time::Instant>,
}

impl<'a> Tracker<'a> {
    /// At most this often while rendering; stage changes always go out.
    const EVERY: std::time::Duration = std::time::Duration::from_millis(50);

    fn new(report: &'a dyn Fn(&ExportStatus), total: usize) -> Self {
        let status = ExportStatus { done: 0, total, name: String::new(), stage: "prepare", frac: 0.0, beat: 0.0, peak: 0.0, wave: vec![] };
        Self { report, status, peaks: vec![0.0; WAVE_SLICES], last: None }
    }

    fn file(&mut self, done: usize, name: &str, beat: f64) {
        self.peaks.iter_mut().for_each(|p| *p = 0.0);
        let s = &mut self.status;
        (s.done, s.name, s.stage, s.frac, s.beat, s.peak) = (done, name.to_string(), "prepare", 0.0, beat, 0.0);
        self.send(true);
    }

    fn stage(&mut self, stage: &'static str) {
        self.status.stage = stage;
        self.status.frac = if stage == "prepare" { 0.0 } else { 1.0 };
        self.send(true);
    }

    fn finish(&mut self) {
        let s = &mut self.status;
        (s.done, s.name, s.stage, s.frac) = (s.total, String::new(), "done", 1.0);
        self.send(true);
    }

    fn on(&mut self, p: wave_engine::RenderProgress) {
        use wave_engine::RenderProgress::{Preparing, Rendering};
        match p {
            Preparing { done, total } => {
                self.status.stage = "prepare";
                self.status.frac = done as f64 / total.max(1) as f64;
                self.send(false);
            }
            Rendering { done, total, peak, beat } => {
                let at = (done.saturating_sub(1) * WAVE_SLICES / total.max(1)).min(WAVE_SLICES - 1);
                self.peaks[at] = self.peaks[at].max(peak);
                let s = &mut self.status;
                s.stage = "render";
                s.frac = done as f64 / total.max(1) as f64;
                s.beat = beat;
                s.peak = s.peak.max(peak);
                self.send(done >= total);
            }
        }
    }

    fn send(&mut self, now: bool) {
        let t = std::time::Instant::now();
        if !now && self.last.is_some_and(|l| t.duration_since(l) < Self::EVERY) {
            return;
        }
        self.last = Some(t);
        self.status.wave = self.peaks.iter().map(|p| (p.clamp(0.0, 1.0) * 255.0).round() as u8).collect();
        (self.report)(&self.status);
    }
}

impl ExportFormat {
    /// `format`: "wav" (default) or "mp3"; `kbps`: 128/192/256/320 (default 320, mp3 only).
    pub fn parse(format: Option<&str>, kbps: Option<u32>, wav_bits: Option<u32>, dither: bool) -> R<Self> {
        match format.map(str::to_ascii_lowercase).as_deref() {
            None | Some("wav") => Ok(Self::Wav(WavEncoding::parse(wav_bits, dither)?)),
            Some("mp3") => {
                if wav_bits.is_some() || dither {
                    return Err("WAV bit depth and dither apply only to WAV export".into());
                }
                let kbps = kbps.unwrap_or(320);
                if ![128, 192, 256, 320].contains(&kbps) {
                    return Err("mp3Kbps must be 128, 192, 256 or 320".into());
                }
                Ok(Self::Mp3 { kbps })
            }
            Some(o) => Err(format!("format must be wav or mp3, not `{o}`")),
        }
    }

    pub fn check_wrap(self, wrap: bool) -> R<()> {
        if wrap && matches!(self, Self::Mp3 { .. }) {
            return Err("wrap tail requires WAV export".into());
        }
        Ok(())
    }

    fn write(self, out: &std::path::Path, audio: &[f32], rate: u32, title: Option<&str>) -> R<()> {
        match self {
            Self::Wav(encoding) => encoding.write(out, audio, rate),
            Self::Mp3 { kbps } => wave_engine::sources::write_mp3(out, audio, rate, kbps, title),
        }
    }

    pub fn extension(self) -> &'static str {
        match self {
            Self::Wav(_) => "wav",
            Self::Mp3 { .. } => "mp3",
        }
    }
}

#[derive(Clone, Copy)]
pub struct Bounce {
    pub from: f64,
    pub to: f64,
    pub tail: f64,
    pub rate: u32,
    pub wrap: bool,
    /// Render this pattern alone, as PAT mode plays it (`from..to` is then its range), not the song.
    pub pattern: Option<u64>,
}

impl Bounce {
    fn render(
        self,
        engine: &wave_engine::Engine,
        insert: Option<u64>,
        cancel: &std::sync::atomic::AtomicBool,
        tracker: &mut Tracker,
    ) -> R<Vec<f32>> {
        use wave_engine::RenderTail;
        let tail = if self.wrap { RenderTail::Wrap } else { RenderTail::Seconds(self.tail) };
        engine
            .render_bounce(insert, self.pattern, self.from, self.to, tail, self.rate, cancel, &mut |p| tracker.on(p))
            .map_err(|e| e.to_string())
    }

    fn tail_seconds(self) -> f64 {
        if self.wrap {
            0.0
        } else {
            self.tail
        }
    }
}

/// Offline bounce shared by the GUI export dialog and `synkopa render`. `progress` hears what it is
/// doing (throttled while rendering).
pub fn render_to_file(
    app: &dyn Host,
    out: &std::path::Path,
    bounce: Bounce,
    cancel: &std::sync::atomic::AtomicBool,
    fmt: ExportFormat,
    progress: &dyn Fn(&ExportStatus),
) -> R<Value> {
    fmt.check_wrap(bounce.wrap)?;
    // a bounce must not start while the piano is still loading (it would be silent)
    app.wait_keys()?;
    let mut tracker = Tracker::new(progress, 1);
    tracker.file(0, &out.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default(), bounce.from);
    let audio = bounce.render(app.engine(), None, cancel, &mut tracker)?;
    if cancel.load(std::sync::atomic::Ordering::Relaxed) {
        return Err("cancelled".into());
    }
    let title = if matches!(fmt, ExportFormat::Mp3 { .. }) {
        app.engine().state().path.and_then(|p| std::path::Path::new(&p).file_stem().map(|s| s.to_string_lossy().into_owned()))
    } else {
        None
    };
    tracker.stage("write");
    fmt.write(out, &audio, bounce.rate, title.as_deref())?;
    tracker.finish();
    Ok(json!({
        "out": out.display().to_string(),
        "fromBeat": bounce.from,
        "toBeat": bounce.to,
        "tail": bounce.tail_seconds(),
        "wrapTail": bounce.wrap,
        "pattern": bounce.pattern,
        "format": fmt.extension(),
        "stats": stats(&audio, bounce.rate),
    }))
}

/// A file name for `name` that is valid on Windows, macOS and Linux: characters the file systems
/// refuse become `_`, trailing dots and spaces go, a reserved device name (`CON`, `NUL`, …) gets a
/// leading `_`, and an empty or very long name is replaced or cut.
pub fn safe_file_stem(name: &str) -> String {
    let cleaned: String = name.chars().map(|c| if c.is_control() || "<>:\"/\\|?*".contains(c) { '_' } else { c }).collect();
    let cleaned = cleaned.trim().trim_end_matches(['.', ' ']).chars().take(100).collect::<String>();
    let cleaned = cleaned.trim_end().to_string();
    if cleaned.is_empty() {
        return "Insert".into();
    }
    let base = cleaned.split('.').next().unwrap_or("").to_ascii_uppercase();
    let reserved = matches!(base.as_str(), "CON" | "PRN" | "AUX" | "NUL")
        || ((base.starts_with("COM") || base.starts_with("LPT"))
            && base.len() == 4
            && base.as_bytes()[3].is_ascii_digit()
            && base.as_bytes()[3] != b'0');
    if reserved {
        format!("_{cleaned}")
    } else {
        cleaned
    }
}

/// Where "save new version" writes next to `current`: `Beat.synkopa` → `Beat_2.synkopa`,
/// `Beat_2` → `Beat_3` (FL Studio's Ctrl+N). A name already taken is skipped, so an earlier
/// version is never overwritten; `taken` says whether a path exists.
pub fn next_version_path(current: &Path, taken: impl Fn(&Path) -> bool) -> PathBuf {
    let stem = current.file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "Song".into());
    let ext = current.extension().map(|e| e.to_string_lossy().into_owned()).unwrap_or_else(|| "synkopa".into());
    // a trailing `_<number>` is the version; anything else (also `Beat_final`) starts at 2
    let (base, from) = match stem.rsplit_once('_') {
        Some((b, n)) if !b.is_empty() && !n.is_empty() && n.len() <= 6 && n.bytes().all(|c| c.is_ascii_digit()) => {
            (b.to_string(), n.parse::<u32>().unwrap_or(1).saturating_add(1))
        }
        _ => (stem, 2),
    };
    let mut n = from.max(2);
    loop {
        let p = current.with_file_name(format!("{base}_{n}.{ext}"));
        if !taken(&p) {
            return p;
        }
        n = n.saturating_add(1);
    }
}

/// File stems for `names` in one folder: made safe by [`safe_file_stem`] and made unique with a
/// ` (2)`, ` (3)` suffix. Compared without regard to case, because Windows and macOS do.
pub fn unique_file_stems(names: &[String]) -> Vec<String> {
    let mut taken: std::collections::HashSet<String> = std::collections::HashSet::new();
    names
        .iter()
        .map(|n| {
            let base = safe_file_stem(n);
            let mut cand = base.clone();
            let mut k = 2;
            while !taken.insert(cand.to_lowercase()) {
                cand = format!("{base} ({k})");
                k += 1;
            }
            cand
        })
        .collect()
}

/// Render one stereo file per mixer insert with sound, plus the optional master mix.
/// Stage files until all stems are encoded. `progress` hears each file start, its render (throttled),
/// its encoding, and the end.
pub fn render_stems_to_dir(
    engine: &wave_engine::Engine,
    dir: &std::path::Path,
    bounce: Bounce,
    cancel: &std::sync::atomic::AtomicBool,
    include_master: bool,
    fmt: ExportFormat,
    progress: &dyn Fn(&ExportStatus),
) -> R<Value> {
    use std::sync::atomic::Ordering::Relaxed;
    fmt.check_wrap(bounce.wrap)?;
    if bounce.to <= bounce.from {
        return Err("`to` must be after `from`".into());
    }
    let project = match bounce.pattern {
        Some(id) => wave_engine::pattern_project(engine.project(), id),
        None => engine.project(),
    };
    // (insert id — None is the master mix, display name)
    let mut jobs: Vec<(Option<u64>, String)> = vec![];
    if include_master {
        jobs.push((None, "Master".into()));
    }
    for (id, name) in wave_engine::Engine::stem_inserts(&project) {
        jobs.push((Some(id), if name.trim().is_empty() { format!("Insert {id}") } else { name }));
    }
    if jobs.is_empty() {
        return Err("nothing to export: every mixer track is muted or has no sound routed to it".into());
    }
    std::fs::create_dir_all(dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
    let staging = tempfile::Builder::new()
        .prefix(".wave-stems-")
        .tempdir_in(dir)
        .map_err(|e| format!("cannot stage stems in {}: {e}", dir.display()))?;
    let ext = fmt.extension();
    let stems = unique_file_stems(&jobs.iter().map(|j| j.1.clone()).collect::<Vec<_>>());
    let total = jobs.len();
    let mut tracker = Tracker::new(progress, total);
    let mut parts: Vec<(PathBuf, PathBuf)> = vec![];
    let mut files: Vec<Value> = vec![];
    let mut skipped: Vec<String> = vec![];
    for (i, (job, name)) in jobs.iter().enumerate() {
        tracker.file(i, name, bounce.from);
        let audio = bounce.render(engine, *job, cancel, &mut tracker)?;
        if cancel.load(Relaxed) {
            return Err("cancelled".into());
        }
        let st = stats(&audio, bounce.rate);
        // an insert that only looked busy (an empty pattern, an automation clip) gets no file
        if job.is_some() && st["silent"] == json!(true) {
            skipped.push(name.clone());
            continue;
        }
        let file = format!("{}.{ext}", stems[i]);
        let part = staging.path().join(&file);
        tracker.stage("write");
        fmt.write(&part, &audio, bounce.rate, None).map_err(|error| format!("cannot write {file}: {error}"))?;
        parts.push((part, dir.join(&file)));
        files.push(json!({ "name": name, "file": file, "master": job.is_none(), "stats": st }));
    }
    if cancel.load(Relaxed) {
        return Err("cancelled".into());
    }
    if parts.is_empty() {
        return Err("nothing to export: everything rendered silent".into());
    }
    for (_, destination) in &parts {
        if destination.is_dir() {
            return Err(format!("cannot write {}: destination is a directory", destination.display()));
        }
    }
    for (part, destination) in parts {
        std::fs::rename(part, &destination).map_err(|e| format!("cannot write {}: {e}", destination.display()))?;
    }
    tracker.finish();
    Ok(json!({
        "dir": dir.display().to_string(),
        "fromBeat": bounce.from,
        "toBeat": bounce.to,
        "tail": bounce.tail_seconds(),
        "wrapTail": bounce.wrap,
        "pattern": bounce.pattern,
        "format": ext,
        "files": files,
        "skipped": skipped,
    }))
}

pub fn render(app: &dyn Host, a: &Value) -> R<Value> {
    let out = PathBuf::from(need_str(a, "out")?);
    let p = app.engine().project();
    let wrap = arg(a, "wrapTail").and_then(Value::as_bool).unwrap_or(false);
    let from = opt_f64(a, "from");
    let to = opt_f64(a, "to");
    let pattern = opt_f64(a, "pattern").map(|v| v as u64);
    let (from, to) = match (pattern, wrap, p.loop_range) {
        (Some(_), true, _) => return Err("wrap tail is for a loop of the song, not a pattern export".into()),
        (Some(id), false, _) => {
            let (a0, b0) = wave_engine::Engine::pattern_range(&p, id).ok_or_else(|| format!("no pattern {id}"))?;
            (from.unwrap_or(a0), to.unwrap_or(b0))
        }
        (None, true, Some(l)) if l.b > l.a => (from.unwrap_or(l.a), to.unwrap_or(l.b)),
        (None, true, _) => from.zip(to).ok_or("wrap tail requires a project loop or both `from` and `to`")?,
        (None, false, range) => (from.unwrap_or(0.0), to.unwrap_or_else(|| range.map_or_else(|| p.song_end(), |l| l.b))),
    };
    let bounce =
        Bounce { from, to, tail: opt_f64(a, "tail").unwrap_or(2.0), rate: opt_f64(a, "rate").unwrap_or(48000.0) as u32, wrap, pattern };
    let wav_bits = arg(a, "wavBits")
        .map(|value| match value.as_f64() {
            Some(16.0) => Ok(16),
            Some(24.0) => Ok(24),
            Some(32.0) => Ok(32),
            _ => Err("WAV bit depth must be 16 or 24 (PCM) or 32 (float)"),
        })
        .transpose()?;
    let dither = arg(a, "dither").and_then(Value::as_bool).unwrap_or(false);
    let stems = arg(a, "stems").and_then(Value::as_bool).unwrap_or(false);
    let by_ext = (!stems && out.extension().is_some_and(|ext| ext.eq_ignore_ascii_case("mp3"))).then_some("mp3");
    let fmt = ExportFormat::parse(
        arg(a, "format").and_then(Value::as_str).or(by_ext),
        opt_f64(a, "mp3Kbps").map(|k| k as u32),
        wav_bits,
        dither,
    )?;
    fmt.check_wrap(wrap)?;
    if p.clips.iter().any(|c| c.tune.is_some()) {
        // pitch-edited clips are rendered with the same detector the app uses
        app.ensure_pitch_model();
    }
    if stems {
        if !out.is_dir()
            && out.extension().and_then(|e| e.to_str()).is_some_and(|e| e.eq_ignore_ascii_case("wav") || e.eq_ignore_ascii_case("mp3"))
        {
            return Err("with stems, `out` is a folder for the files, not a .wav/.mp3 file".into());
        }
        let master = arg(a, "master").and_then(Value::as_bool).unwrap_or(true);
        // a stem export must not start while the piano is still loading (its stems would be silent)
        app.wait_keys()?;
        return render_stems_to_dir(app.engine(), &out, bounce, &std::sync::atomic::AtomicBool::new(false), master, fmt, &|_| {});
    }
    render_to_file(app, &out, bounce, &std::sync::atomic::AtomicBool::new(false), fmt, &|_| {})
}

/// A gain as the UI shows it: `-inf` once it is inaudible, else signed decibels.
fn db_string(g: f32) -> String {
    if g < 1e-6 {
        "-inf".to_string()
    } else {
        format!("{:+.1} dB", 20.0 * g.log10())
    }
}

pub fn context(app: &dyn Host, full: bool) -> Value {
    let st = app.engine().state();
    if full {
        return json!({ "revision": st.revision, "project": st.project, "transport": st.transport, "path": st.path, "fxErrors": st.fx_errors });
    }
    let p = &st.project;
    let db = |t: f32| db_string(wave_engine::fader_gain(t));
    json!({
        "revision": st.revision,
        "path": st.path,
        "dirty": st.dirty,
        "bpm": p.bpm,
        "key": p.key,
        "scale": p.scale,
        "loop": p.loop_range,
        "songEndBeat": p.song_end(),
        "transport": st.transport,
        "tracks": p.tracks.iter().enumerate().map(|(i, t)| json!({
            "index": i, "id": t.id, "name": t.name, "insert": t.insert, "volume": db(t.vol),
            "muted": t.muted, "solo": t.solo, "armed": t.arm,
            "clips": p.clips.iter().filter(|c| c.track as usize == i).count(),
            "takes": p.clips.iter().filter(|c| c.track as usize == i && c.kind == wave_engine::ClipKind::Comp).filter_map(|c| p.comp(c.source)).map(|cp| cp.takes.len()).sum::<usize>(),
        })).collect::<Vec<_>>(),
        "inserts": p.inserts.iter().map(|m| json!({
            "id": m.id, "name": m.name, "volume": db(m.vol), "pan": m.pan, "muted": m.muted, "solo": m.solo,
            "toMaster": m.master, "sends": m.sends.iter().map(|s| json!({"to": s.to, "gain": s.gain})).collect::<Vec<_>>(),
            "fx": m.fx.iter().map(|f| json!({
                "id": f.id, "type": f.kind, "name": f.plugin.as_ref().map(|x| x.name.clone()).unwrap_or_else(|| catalog::type_name(f.kind).into()),
                "bypass": f.bypass, "preset": f.preset.and_then(|i| catalog::presets(f.kind).get(i as usize).map(|p| p.name)),
                "params": f.params, "error": st.fx_errors.get(&f.id),
            })).collect::<Vec<_>>(),
        })).collect::<Vec<_>>(),
        "patterns": p.patterns.iter().map(|x| json!({"id": x.id, "name": x.name, "lenBeats": x.len, "swing": x.swing, "notes": x.notes.len()})).collect::<Vec<_>>(),
        "channels": p.channels.iter().map(|c| channel_json(p, c)).collect::<Vec<_>>(),
        "sources": p.sources.iter().map(|s| json!({"id": s.id, "name": s.name, "seconds": s.dur, "path": s.path})).collect::<Vec<_>>(),
        "clips": p.clips.len(),
        "markers": p.markers.iter().map(marker_json).collect::<Vec<_>>(),
        "notebook": p.notebook.pages.iter().map(|pg| json!({"id": pg.id, "name": pg.name, "startBar": pg.start_bar, "lines": pg.text.lines().count()})).collect::<Vec<_>>(),
        "nextId": p.next_id,
    })
}

pub fn schema() -> Value {
    json!({
        "automation": "an automation plays through a clip of kind `auto` whose `ref` is the automation id; points t = beats from the automation start, v = 0..1 normalised (log params normalised logarithmically); optional per point, for the segment ending there: tension -1..1 (0 = straight) and shape curve|double|hold|stairs (stairs: tension sets 2..16 steps). While the app records with its Automation filter on, control tweaks during playback send these same putAutomation ops (touch: until release; Latch holds until stop); a manual tweak on an automated control while playing overrides its envelope until the transport stops",
        "units": "time in beats (quarter notes); pattern len in beats (4 = 1 bar, derived from the notes, at least minLen), note step/len in sixteenths, note v (velocity) 0..1, swing 0..1; fades in seconds; vol = fader 0..1 (0.7937 = 0 dB); clip gain in dB; pan -1..1",
        "patterns": "channels are global (Channel Rack rows, `synkopa channels`); a pattern note plays channel `ch`; trig = true for a step trigger without sampler note-off; p = MIDI key (absent = the channel's root, the key at which a sampler plays its file unpitched); swing delays notes on odd 16ths by swing × ½ step; the pattern length is derived: the end of the last note rounded up to a bar, at least `minLen` beats (a `len` you send is ignored); when it grows, clips that show exactly one whole pass (offset 0) follow, but stop at the next clip on their track; when it shrinks, clips that showed only the pattern are cut back to its new end. The Playlist keeps a pattern clip within one pass of its pattern (len <= pattern len - offset) when its edge is dragged. Easier: `synkopa pattern --id N --ch C --steps \"x...x...x...x...\"`",
        "ids": "take new ids from context.nextId and count up",
        "routing": "an insert's output goes to the master (`master`: true, the default) and/or, post-fader, to other inserts through `sends` [{to, gain 0..2 linear}] (a bus, a shared reverb). `master` false = only where it sends. Loops and sends to itself or to the master (id 0) are refused. Easier: `synkopa route --from 3 --to 1 [--gain 0.5] [--only true]`, `synkopa unroute --from 3 --to 1`",
        "stretch": "audio clips only: `stretch` 0.25..4 = how many times longer the clip plays its audio (2 = half speed); `offset` and `len` are beats of the stretched audio, so stretching a clip from s0 to s1 multiplies its len and offset by s1/s0. Pitch is kept (rendered in the background; the clip plays resampled until it is ready, see state `stretching`) unless `resample` is true (speed and pitch change together, like a turntable)",
        "ops": {
            "putClips": {"clips": [{"id": 0, "track": 0, "start": 0, "len": 4, "offset": 0, "kind": "pat|audio|auto|comp", "ref": "pattern, source, automation or comp id", "muted": false, "gain": 0, "fadeIn": 0, "fadeOut": 0, "pan": 0, "norm": false, "rev": false, "stretch": 1, "resample": false}]},
            "removeClips": {"ids": [0]},
            "putTrack": {"track": {"id": 0, "name": "", "color": "#4f8ef7", "muted": false, "solo": false, "arm": false, "vol": 0.7937, "h": 56, "insert": 1}},
            "putInsert": {"insert": {"id": 0, "name": "", "color": "#8b93a1", "vol": 0.7937, "pan": 0, "muted": false, "solo": false, "fx": [], "sends": [{"to": 2, "gain": 1}], "master": true}},
            "removeInsert": {"id": 0},
            "putFx": {"insertId": 1, "fx": {"id": 0, "type": "comp", "bypass": false, "params": {"thr": -18}}, "index": null},
            "removeFx": {"fxId": 0},
            "moveFx": {"fxId": 0, "to": 0},
            "putPattern": {"pattern": {"id": 0, "name": "", "color": "#4f8ef7", "minLen": 4, "swing": 0, "channelLoops": "optional: {channel id: loop length in whole steps} — the channel's steps 0..n repeat to fill the pattern (notes from step n on are ignored)", "notes": [{"ch": "channel id", "step": 0, "len": 1, "p": 36, "v": 1}]}},
            "putChannel": {"channel": {"id": 0, "name": "Kick", "color": "#4f8ef7", "kind": "sample|synth|keys|musicbox", "source": "source id (kind sample)", "sampler": "kind sample, optional: {start, end (0..1 of the file), reverse, norm, semi, fine, env (volume envelope on), delay, attack, hold, decay, release, fadeInMs, fadeOutMs (ms), sustain (0..1), attackTension, decayTension, releaseTension (-1..1), cut (0 = none, 1..8)}", "slices": "kind sample, optional: slice mode, increasing fractions of the file in 0..1 where each slice starts (at most 128); key root plays slice 1, root+1 slice 2, ...; a slice plays to the next at the file's pitch and cuts the one sounding; omit or [] = off", "keys": "kind keys, optional: {instrument (catalog id, default grand-piano), release (ms; absent = the instrument's own), dynamics (0..100 %), articulation (keyswitch key of the instrument's articulations; absent = its default), attack (0..2000 ms), tone (-100..100), width (0..150 %), tune (-100..100 cents), noise (0..100 %)}", "vol": 0.7937, "pan": 0, "mute": false, "solo": false, "insert": "insert id or null (= the clip's track)", "root": 60, "group": "Channel Rack filter group, optional (absent = unsorted)"}, "index": null},
            "removeChannel": {"id": 0},
            "removePattern": {"id": 0},
            "putSource": {"source": "rename/recolour an existing source"},
            "removeSource": {"id": 0},
            "setBpm": {"bpm": 128},
            "setLoop": {"loop": {"a": 0, "b": 16}},
            "setMaskIgnore": {"pairs": [[6, 7]]},
            "putAutomation": {"automation": {"id": 0, "name": "Reverb mix", "color": "#e0a44a", "target": {"kind": "fx|mix|insertVol|insertPan|trackVol|chanVol|chanPan|synth|keys|musicBox|clipGain|clipPan", "fxId": 0, "chanId": 0, "param": "fx: mix or band:<i>:f|g|q; synth: catalog id; keys: release|dynamics|attack|tone|width|tune|noise; musicBox: ring|brightness|body|mechanical|spread|release", "id": "insert/track/channel/clip id for vol/pan/gain"}, "points": [{"t": 0, "v": 0.2}, {"t": 8, "v": 0.8, "tension": -0.4}, {"t": 12, "v": 0.5, "shape": "hold"}]}},
            "removeAutomation": {"id": 0},
            "transformNotes": {"pattern": 1, "verb": {"kind": "humanize|quantize|euclidFill|strum|chop|glue|arpeggiate|euclidDrums|melody|chord|progression", "len": 1, "mode": "up|down|upDown|random", "rate": 1, "gate": 0.9, "octaves": 1, "timing": 0.3, "velocity": 0.2, "grid": 1, "amount": 1, "scaleAware": false, "ch": 0, "k": 4, "n": 16, "rotate": 0, "vel": 0.7, "width": 0.5, "ramp": 0.05, "voices": [{"ch": 0, "k": 4, "n": 16, "rotate": 0, "vel": 0.7}], "bars": 2, "density": 0.5, "repeat": 1, "harmony": "diatonic|maj|min|7|maj7|min7", "template": "pop|pop2|minloop|trap|iivI|doowop|andalusian|blues|canon|chance", "voiceLead": true, "degrees": [0, 5, 2, 6]}, "seed": 7, "select": {"kind": "indices|range", "indices": [1, 2], "from": 0, "to": 16, "ch": 0}},
            "setKey": {"key": 2, "scale": 1},
            "putComp": {"comp": {"id": 0, "name": "Comp 1", "xfade": 0.01, "takes": [{"id": 0, "name": "Take 1", "ref": "source id", "start": 0, "len": 8, "offset": 0}], "regions": [{"take": 0, "from": 0, "to": 4, "xfade": 0.02}]}},
            "removeComp": {"id": 0},
            "editTune": {"clip": 412, "edit": {"base": "segmentation fingerprint from `synkopa pitch inspect` (optional; refused as STALE_NOTES when the notes changed)", "init": "[[start, end], …] seconds: the analysis' notes, used only when the clip has no notes of its own yet (`pitch edit` adds it)", "notes": [{"i": 3, "shift": -20, "shiftBy": 0, "drift": 0.2, "formant": 0, "gain": 0, "speed": 60}], "reset": [5], "split": [{"i": 7, "at": 12.35}], "merge": [9], "clear": false, "erasePencil": [[1.0, 1.5]], "pencil": [[2.0, 64.0], [2.02, 64.1]]}},
            "putNotebook": {"notebook": {"pages": [{"id": 0, "name": "Zwrotka 1", "startBar": 1, "text": "[Zwrotka]\nfirst bar\n\nthird bar"}]}},
            "putMarker": {"marker": {"id": 0, "at": 32, "name": "Hook"}},
            "removeMarker": {"id": 0},
        },
        "markers": "Playlist time markers (labels only, never played): `at` in beats on the song timeline (0..2048), name up to 80 characters, at most 256; kept sorted by `at`. putMarker adds, moves or renames (by id), removeMarker deletes. A marker's section runs to the next marker (the last one: to the song end). Easier: `synkopa markers --add Hook --bar 9`, `synkopa markers --loop Hook`",
        "notebook": "lyrics notebook (text only, never played): pages in tab order; each line of `text` is one bar counted from `startBar` (1-based, bar = 4 beats), an empty line is a bar of rest, a line wrapped in [brackets] is a header and takes no bar. putNotebook replaces all pages; the full text is in `synkopa context --full`",
        "comps": "take lanes: a clip of kind `comp` plays comp `ref`; takes/regions are in comp beats (comp beat = clip.offset + timeline beat − clip.start); regions sorted, non-overlapping, gaps are silent; xfade in seconds (equal-power crossfade centred on each region start, default 0.01). Easier: `synkopa takes --track N`, `synkopa comp --track N --set '[{\"take\":ID,\"from\":B,\"to\":B}]'` (timeline beats)",
        "maskIgnore": "pairs of inserts the mix assistant does not report as masking each other (`synkopa mix ignore N`); setMaskIgnore replaces them (sorted within a pair, no repeats, not the master). The fix (`synkopa mix fix N`) is an EQ whose dynamic band is keyed (`fx.key`) from the protected insert: with a sidechain, every dynamic band of an EQ follows the key in its band instead of its own signal",
        "pitchEdits": "editTune changes only a clip's pitch edits (the pitch editor's notes): indices name the notes as `synkopa pitch inspect` lists them (before this op), whatever order the parts are in; they apply as clear, reset, notes, split, merge, erasePencil, pencil. shift/formant in cents (within 2400), drift 0..1, gain -24..12 dB, speed 0..1000 ms (null = the reference's, else immediate). Easier: `synkopa pitch edit`",
        "example": [{"op": "setBpm", "bpm": 140}, {"op": "removeClips", "ids": [3]}],
    })
}

pub fn import(app: &dyn Host, a: &Value) -> R<Value> {
    let paths: Vec<PathBuf> = arg(a, "paths")
        .and_then(Value::as_array)
        .ok_or("`paths` is required")?
        .iter()
        .filter_map(|v| v.as_str().map(PathBuf::from))
        .collect();
    let place = match (opt_f64(a, "track"), opt_f64(a, "beat")) {
        (Some(t), b) => Some((t as u32, b.unwrap_or(0.0))),
        (None, Some(b)) => Some((0, b)),
        _ => None,
    };
    // `step: false`: the file is loaded for an edit that follows (a sampler channel), which is the undo step
    let step = arg(a, "step").and_then(Value::as_bool).unwrap_or(true);
    let (s, c, errors) = app.engine().import_audio_with(&paths, place, step).map_err(|e| e.to_string())?;
    Ok(json!({ "sourceIds": s, "clipIds": c, "errors": errors }))
}

// ---------------------------------------------------------------- missing audio

/// Sources whose audio is not loaded: `[{sourceId, name, path, error, library, clips, channels}]`
/// (`library`: a `lib:` sample of a kit that is not installed — install the kit, not relinkable).
pub fn missing(app: &dyn Host) -> Value {
    let st = app.engine().state();
    let p = &st.project;
    let mut out: Vec<Value> = p
        .sources
        .iter()
        .filter_map(|s| {
            let why = st.missing.get(&s.id)?;
            let clips = p.clips.iter().filter(|c| c.kind == wave_engine::ClipKind::Audio && c.source == s.id).count();
            let channels = p.channels.iter().filter(|c| c.sample_source() == Some(s.id)).count();
            Some(json!({ "sourceId": s.id, "name": s.name, "path": s.path, "error": why,
                         "library": s.path.starts_with(wave_engine::factory::SCHEME), "clips": clips, "channels": channels }))
        })
        .collect();
    out.sort_by_key(|v| v["sourceId"].as_u64());
    json!(out)
}

/// Points missing (or any non-library) sources at files again, as one undo step:
/// `{folder}` searches a folder and relinks the unambiguous matches (the rest come back as
/// `candidates`); `{items: [{sourceId, path}]}` or `{sourceId, path}` relinks those files.
pub fn relink(app: &dyn Host, a: &Value) -> R<Value> {
    let e = app.engine();
    if let Some(folder) = arg(a, "folder").and_then(Value::as_str) {
        let r = e.relink_search(Path::new(folder)).map_err(|x| x.to_string())?;
        return Ok(json!({ "search": r, "revision": e.revision() }));
    }
    let items: Vec<wave_engine::Relink> = match arg(a, "items") {
        Some(v) => serde_json::from_value(v.clone()).map_err(|x| format!("`items`: {x}"))?,
        None => vec![wave_engine::Relink { source_id: need_u64(a, "sourceId")?, path: need_str(a, "path")?.to_string() }],
    };
    if items.is_empty() {
        return Err("nothing to relink".into());
    }
    let r = e.relink_sources(&items).map_err(|x| x.to_string())?;
    Ok(json!({ "relinked": r, "revision": e.revision() }))
}

// ---------------------------------------------------------------- channels & patterns

/// Synkopa Instruments instruments, for `synkopa catalog`.
fn keys_catalog() -> Value {
    json!(wave_engine::keys::CATALOG
        .iter()
        .map(|i| json!({
            "id": i.id,
            "name": i.name,
            "category": i.category,
            "description": i.description,
            "bundled": i.bundled,
            "kit": i.kit,
            "articulations": wave_engine::keys::articulations(i.id),
        }))
        .collect::<Vec<_>>())
}

/// A Synkopa Instruments instrument by catalog id or name (any case).
fn keys_instrument(s: &str) -> R<&'static wave_engine::keys::InstrumentInfo> {
    wave_engine::keys::CATALOG.iter().find(|i| i.id.eq_ignore_ascii_case(s) || i.name.eq_ignore_ascii_case(s)).ok_or_else(|| {
        let ids: Vec<&str> = wave_engine::keys::CATALOG.iter().map(|i| i.id).collect();
        format!("Synkopa Instruments has no instrument `{s}` ({})", ids.join(", "))
    })
}

fn channel_json(p: &wave_engine::Project, c: &wave_engine::Channel) -> Value {
    use wave_engine::ChannelSrc;
    let g = c.gain();
    let (kind, what) = match &c.src {
        ChannelSrc::Sample { source, sampler, slices } => (
            "sample",
            json!({ "source": source, "sourceName": p.sources.iter().find(|s| s.id == *source).map(|s| s.name.clone()), "sampler": sampler, "slices": slices }),
        ),
        ChannelSrc::Synth { synth } => ("synth", json!({ "preset": synth.preset })),
        ChannelSrc::Keys { keys } => (
            "keys",
            json!({
                "instrument": keys.instrument,
                "instrumentName": wave_engine::keys::instrument(&keys.instrument).map(|i| i.name),
                "articulation": keys.articulation.and_then(|k| wave_engine::keys::articulations(&keys.instrument).iter().find(|a| a.key == k)).map(|a| a.name.clone()),
                "release": keys.release,
                "dynamics": keys.dynamics,
                "attack": keys.attack,
                "tone": keys.tone,
                "width": keys.width,
                "tune": keys.tune,
                "noise": keys.noise,
            }),
        ),
        ChannelSrc::MusicBox { music_box } => (
            "musicbox",
            json!({ "ring": music_box.ring, "brightness": music_box.brightness, "body": music_box.body, "mechanical": music_box.mechanical, "spread": music_box.spread, "release": music_box.release }),
        ),
        ChannelSrc::Plugin { plugin } => (
            "plugin",
            json!({ "plugin": { "format": plugin.format, "name": plugin.name, "vendor": plugin.vendor, "path": plugin.path, "cid": plugin.cid } }),
        ),
    };
    let mut v = json!({
        "id": c.id, "index": p.channels.iter().position(|x| x.id == c.id), "name": c.name, "kind": kind,
        "volume": db_string(g), "vol": c.vol, "pan": c.pan,
        "mute": c.mute, "solo": c.solo, "insert": c.insert, "root": c.root, "group": c.group,
        "notes": p.patterns.iter().map(|pt| pt.notes.iter().filter(|n| n.ch == c.id).count()).sum::<usize>(),
    });
    if let (Value::Object(m), Value::Object(w)) = (&mut v, what) {
        m.extend(w);
    }
    v
}

fn marker_json(m: &wave_engine::Marker) -> Value {
    json!({ "id": m.id, "name": m.name, "at": m.at, "bar": m.at / wave_engine::BAR_BEATS + 1.0 })
}

/// A marker by id, or by name (case-insensitive; the first one when names repeat).
fn find_marker<'a>(p: &'a wave_engine::Project, v: &Value) -> R<&'a wave_engine::Marker> {
    if let Some(id) = as_index(v) {
        return p.marker(id).ok_or(format!("no marker {id} (see `synkopa markers`)"));
    }
    let s = v.as_str().ok_or("a marker is named by its id or its name")?.trim().to_lowercase();
    p.markers.iter().find(|m| m.name.to_lowercase() == s).ok_or(format!("no marker named `{s}` (see `synkopa markers`)"))
}

/// `at` in beats, or `bar` (1-based, may be fractional: 9.5 = the middle of bar 9).
fn marker_pos(a: &Value) -> R<Option<f64>> {
    match (opt_f64(a, "at"), opt_f64(a, "bar")) {
        (Some(_), Some(_)) => Err("give `at` (beats) or `bar`, not both".into()),
        (Some(b), None) => Ok(Some(b)),
        (None, Some(bar)) if bar >= 1.0 => Ok(Some((bar - 1.0) * wave_engine::BAR_BEATS)),
        (None, Some(bar)) => Err(format!("bars count from 1, not {bar}")),
        (None, None) => Ok(None),
    }
}

fn marker_name(v: &Value) -> R<String> {
    let n = v.as_str().ok_or("a marker name is text")?.trim().to_string();
    if n.chars().count() > wave_engine::MARKER_NAME_MAX {
        return Err(format!("a marker name has at most {} characters", wave_engine::MARKER_NAME_MAX));
    }
    Ok(n)
}

/// Playlist markers (FL's time markers): list; `add` (a name) at `at`/`bar` (default: the start
/// position); `marker` (id or name) with a new `name` and/or `at`/`bar`; `remove`; `loop` (the
/// section from the marker to the next one becomes the loop). Each edit is one undo step.
pub fn markers(app: &dyn Host, a: &Value, if_revision: Option<u64>) -> R<Value> {
    let e = app.engine();
    let mut p = e.project();
    let list = |p: &wave_engine::Project| p.markers.iter().map(marker_json).collect::<Vec<_>>();
    let mut added = None;
    let (op, label) = if let Some(n) = arg(a, "add") {
        let at = marker_pos(a)?.unwrap_or_else(|| e.state().transport.start_beat.max(0.0));
        let id = p.alloc_id();
        added = Some(id);
        (Op::PutMarker { marker: wave_engine::Marker { id, at, name: marker_name(n)? } }, "Add marker")
    } else if let Some(v) = arg(a, "remove") {
        (Op::RemoveMarker { id: find_marker(&p, v)?.id }, "Delete marker")
    } else if let Some(v) = arg(a, "loop") {
        let id = find_marker(&p, v)?.id;
        (Op::SetLoop { range: p.marker_section(id) }, "Loop section")
    } else if let Some(v) = arg(a, "marker") {
        let mut m = find_marker(&p, v)?.clone();
        let (name, at) = (arg(a, "name"), marker_pos(a)?);
        if name.is_none() && at.is_none() {
            return Err("say what changes: `name` and/or `at` / `bar`".into());
        }
        if let Some(n) = name {
            m.name = marker_name(n)?;
        }
        if let Some(b) = at {
            m.at = b;
        }
        (Op::PutMarker { marker: m }, if at.is_some() { "Move marker" } else { "Rename marker" })
    } else {
        return Ok(json!(list(&p)));
    };
    let rev = e.apply_labeled(&[op], false, if_revision, Some(label)).map_err(|x| x.to_string())?;
    let p = e.project();
    Ok(json!({ "revision": rev, "added": added, "loop": p.loop_range, "markers": list(&p) }))
}

/// A channel by id, by name (case-insensitive) or by built-in instrument name.
fn find_channel<'a>(p: &'a wave_engine::Project, v: &Value) -> R<&'a wave_engine::Channel> {
    if let Some(id) = as_index(v) {
        return p.channel(id).ok_or(format!("no channel {id} (see `synkopa channels`)"));
    }
    let s = v.as_str().ok_or("`ch` is a channel id or name")?.to_lowercase();
    p.channels.iter().find(|c| c.name.to_lowercase() == s).ok_or(format!("no channel named `{s}` (see `synkopa channels`)"))
}

/// The channel `v` names as this command has edited it so far: one command can set several
/// things (`--instrument` and `--param`), and each later op must build on the earlier ones.
fn edited_channel(p: &wave_engine::Project, ops: &[Op], v: &Value) -> R<wave_engine::Channel> {
    let c = find_channel(p, v)?;
    let edited = ops.iter().rev().find_map(|o| match o {
        Op::PutChannel { channel, .. } if channel.id == c.id => Some(channel.clone()),
        _ => None,
    });
    Ok(edited.unwrap_or_else(|| c.clone()))
}

pub fn channels(app: &dyn Host, a: &Value, if_revision: Option<u64>) -> R<Value> {
    use wave_engine::{factory, Channel, ChannelSrc};
    let e = app.engine();
    let mut p = e.project();
    let mut ops = vec![];
    let mut added = None;
    if let Some(k) = arg(a, "add").and_then(Value::as_str) {
        // a sampler playing a standard-library sample: its file name (with or without
        // ".flac"), its display name, or the start of either ("kick" = the first kick)
        let want = k.to_lowercase();
        let stem = |f: &factory::FactoryFile| f.file.trim_end_matches(".flac").to_string();
        // the samples the Library tab lists come first; a hidden one (kept for older songs) only
        // by its exact name, so "kick-trap" is one of the listed trap kicks, not the old hidden file
        let exact = |f: &&factory::FactoryFile| stem(f) == want.trim_end_matches(".flac") || f.name.to_lowercase() == want;
        let f = factory::listed_files()
            .find(exact)
            .or_else(|| factory::listed_files().find(|f| stem(f).starts_with(&want) || f.name.to_lowercase().starts_with(&want)))
            .or_else(|| factory::files().iter().find(exact))
            .ok_or(format!("no standard-library sample `{k}`: try kick-808, snare-studio, hat-808-open, bass-808, marimba ... (the browser's Library tab lists them all)"))?;
        // the import adds the project source (or finds the one already there)
        let (srcs, ..) = e.import_audio_with(&[PathBuf::from(factory::lib_path(f.file))], None, false).map_err(|x| x.to_string())?;
        p = e.project();
        let mut ch = Channel::sampler(p.next_id, f.name, factory::color(f), srcs[0]);
        ch.root = f.root;
        added = Some(ch.id);
        ops.push(Op::PutChannel { channel: ch, index: None });
    }
    if let Some(src) = arg(a, "sample").and_then(as_index) {
        let s = p.sources.iter().find(|s| s.id == src).ok_or(format!("no source {src} (see `synkopa context`)"))?;
        let id = p.next_id + ops.len() as u64;
        let ch = Channel::sampler(id, &s.name, &s.color, src);
        added = Some(id);
        ops.push(Op::PutChannel { channel: ch, index: None });
    }
    if let Some(name) = arg(a, "synth").and_then(Value::as_str) {
        // a synth channel playing a factory preset ("" = the blank patch)
        let id = p.next_id + ops.len() as u64;
        let synth = if name.is_empty() {
            wave_engine::SynthState::default()
        } else {
            wave_engine::poly::preset_state(name).ok_or(format!("no synth preset `{name}` (see `synkopa catalog`)"))?
        };
        let bass = wave_engine::poly::presets::all().iter().any(|x| x.name == name && matches!(x.category, "808" | "Bas"));
        let label = if name.is_empty() { "Synth".to_string() } else { name.to_string() };
        let ch = Channel { root: if bass { 36 } else { 60 }, ..Channel::new(id, &label, "#9b7cf8", ChannelSrc::Synth { synth }) };
        added = Some(id);
        ops.push(Op::PutChannel { channel: ch, index: None });
    }
    if let Some(want) = arg(a, "plugin").and_then(Value::as_str) {
        // a hosted VST3 instrument from the last plugin scan: its class id, or its name
        // (case-insensitive; the start of it picks the first match)
        let r = app.plugins().scan(false);
        let w = want.to_lowercase();
        let entry = r
            .instruments
            .iter()
            .find(|i| i.cid.eq_ignore_ascii_case(want) || i.name.to_lowercase() == w)
            .or_else(|| r.instruments.iter().find(|i| i.name.to_lowercase().starts_with(&w)))
            .ok_or(format!(
                "no scanned VST3 instrument `{want}`{}",
                if r.instruments.is_empty() {
                    " (none is scanned: run `synkopa plugin_scan --rescan`)".to_string()
                } else {
                    format!("; installed: {}", r.instruments.iter().map(|i| i.name.as_str()).collect::<Vec<_>>().join(", "))
                }
            ))?;
        let id = p.next_id + ops.len() as u64;
        let plugin = wave_engine::PluginRef {
            format: entry.format.clone(),
            path: entry.path.clone(),
            cid: entry.cid.clone(),
            name: entry.name.clone(),
            vendor: entry.vendor.clone(),
            state: None,
        };
        let ch = Channel::new(id, &entry.name, "#9b7cf8", ChannelSrc::Plugin { plugin });
        added = Some(id);
        ops.push(Op::PutChannel { channel: ch, index: None });
    }
    if arg(a, "keys").and_then(Value::as_bool).unwrap_or(false) {
        // a Synkopa Instruments channel: the grand piano, or the instrument `--instrument` names
        let id = p.next_id + ops.len() as u64;
        let mut keys = wave_engine::KeysState::default();
        let mut name = wave_engine::keys::instrument(&keys.instrument).map_or("Grand Piano", |i| i.name);
        if let Some(i) = arg(a, "instrument").and_then(Value::as_str) {
            let info = keys_instrument(i)?;
            keys.instrument = info.id.into();
            name = info.name;
        }
        let ch = Channel::new(id, name, "#e0a44a", ChannelSrc::Keys { keys });
        added = Some(id);
        ops.push(Op::PutChannel { channel: ch, index: None });
    } else if let (Some(v), true) = (arg(a, "ch"), arg(a, "instrument").is_some() || arg(a, "articulation").is_some()) {
        // switch a Keys channel's instrument and/or articulation
        let mut c = edited_channel(&p, &ops, v)?;
        let ChannelSrc::Keys { keys } = &mut c.src else { return Err(format!("channel `{}` is not Synkopa Instruments", c.name)) };
        if let Some(i) = arg(a, "instrument").and_then(Value::as_str) {
            let info = keys_instrument(i)?;
            if keys.instrument != info.id {
                keys.instrument = info.id.into();
                // another instrument has its own articulations and release
                keys.articulation = None;
                keys.release = None;
            }
        }
        if let Some(art) = arg(a, "articulation").and_then(Value::as_str) {
            let arts = wave_engine::keys::articulations(&keys.instrument);
            let names = || arts.iter().map(|x| x.name.to_lowercase()).collect::<Vec<_>>().join(", ");
            keys.articulation = Some(
                arts.iter()
                    .find(|x| x.name.eq_ignore_ascii_case(art) || x.key.to_string() == art)
                    .ok_or_else(|| {
                        if arts.is_empty() {
                            format!("{} has no articulations", keys.instrument)
                        } else {
                            format!("{} has no articulation `{art}` ({})", keys.instrument, names())
                        }
                    })?
                    .key,
            );
        }
        ops.push(Op::PutChannel { channel: c, index: None });
    }
    if arg(a, "musicbox").and_then(Value::as_bool).unwrap_or(false) {
        // a Music Box channel: the modeled tine instrument
        let id = p.next_id + ops.len() as u64;
        let ch = Channel::new(id, "Music Box", "#cf8e52", ChannelSrc::MusicBox { music_box: Default::default() });
        added = Some(id);
        ops.push(Op::PutChannel { channel: ch, index: None });
    }
    if let (Some(v), Some(name)) = (arg(a, "ch"), arg(a, "preset").and_then(Value::as_str)) {
        // load a factory preset into a synth channel
        let mut c = edited_channel(&p, &ops, v)?;
        if !matches!(c.src, ChannelSrc::Synth { .. }) {
            return Err(format!("channel `{}` is not a synth", c.name));
        }
        c.src = ChannelSrc::Synth {
            synth: wave_engine::poly::preset_state(name).ok_or(format!("no synth preset `{name}` (see `synkopa catalog`)"))?,
        };
        ops.push(Op::PutChannel { channel: c, index: None });
    }
    if let (Some(v), Some(param)) = (arg(a, "ch"), arg(a, "param").and_then(Value::as_str)) {
        // one synth knob
        let mut c = edited_channel(&p, &ops, v)?;
        let value = opt_f64(a, "value").ok_or("`value` is required")?;
        match &mut c.src {
            ChannelSrc::Synth { synth } => {
                let i = wave_engine::poly::params::index_of(param)
                    .ok_or(format!("the synth has no parameter `{param}` (see `synkopa catalog`)"))?;
                synth.params.insert(param.to_string(), wave_engine::poly::params::clamp(i, value) as f64);
                synth.preset = None;
            }
            ChannelSrc::Plugin { plugin } => {
                return Err(format!(
                    "`{}` is a plugin instrument: list its parameters with `synkopa plugin_params --fxId {}` and set one with `synkopa plugin_set_param`",
                    plugin.name, c.id
                ))
            }
            ChannelSrc::Keys { keys } => match param {
                // 0 = the instrument's own release
                "release" if value <= 0.0 => keys.release = None,
                "release" => keys.release = Some((value as f32).clamp(wave_engine::keys::RELEASE_MS.0, wave_engine::keys::RELEASE_MS.1)),
                "dynamics" => keys.dynamics = (value as f32).clamp(0.0, 100.0),
                "attack" => keys.attack = (value as f32).clamp(wave_engine::keys::ATTACK_MS.0, wave_engine::keys::ATTACK_MS.1),
                "tone" => keys.tone = (value as f32).clamp(wave_engine::keys::TONE.0, wave_engine::keys::TONE.1),
                "width" => keys.width = (value as f32).clamp(wave_engine::keys::WIDTH.0, wave_engine::keys::WIDTH.1),
                "tune" => keys.tune = (value as f32).clamp(wave_engine::keys::TUNE.0, wave_engine::keys::TUNE.1),
                "noise" => keys.noise = (value as f32).clamp(wave_engine::keys::NOISE.0, wave_engine::keys::NOISE.1),
                _ => {
                    return Err(format!(
                        "Synkopa Instruments has no parameter `{param}` (release and attack in ms, 0 = the instrument's; dynamics, width and noise in %; tone −100..100; tune in cents)"
                    ))
                }
            },
            ChannelSrc::MusicBox { music_box } => {
                let v = value as f32;
                use wave_engine::musicbox as mb;
                match param {
                    "ring" => music_box.ring = v.clamp(mb::RING.0, mb::RING.1),
                    "brightness" => music_box.brightness = v.clamp(mb::BRIGHTNESS.0, mb::BRIGHTNESS.1),
                    "body" => music_box.body = v.clamp(mb::BODY.0, mb::BODY.1),
                    "mechanical" => music_box.mechanical = v.clamp(mb::MECHANICAL.0, mb::MECHANICAL.1),
                    "spread" => music_box.spread = v.clamp(mb::SPREAD.0, mb::SPREAD.1),
                    "release" => music_box.release = v.clamp(mb::RELEASE_MS.0, mb::RELEASE_MS.1),
                    _ => {
                        return Err(format!(
                            "the music box has no parameter `{param}` (ring, brightness, body, mechanical, spread in %; release in ms)"
                        ))
                    }
                }
            }
            ChannelSrc::Sample { sampler, .. } => {
                let (v, on) = (value as f32, value != 0.0);
                match param {
                    "start" => sampler.start = v,
                    "end" => sampler.end = v,
                    "reverse" => sampler.reverse = on,
                    "norm" => sampler.norm = on,
                    "semi" => sampler.semi = value.round().clamp(-128.0, 127.0) as i8,
                    "fine" => sampler.fine = v,
                    // `gate`: the envelope switch's name in older scripts
                    "env" | "gate" => sampler.env = on,
                    "delay" => sampler.delay = v,
                    "attack" => sampler.attack = v,
                    "hold" => sampler.hold = v,
                    "decay" => sampler.decay = v,
                    "sustain" => sampler.sustain = v,
                    "release" => sampler.release = v,
                    "attackTension" => sampler.attack_tension = v,
                    "decayTension" => sampler.decay_tension = v,
                    "releaseTension" => sampler.release_tension = v,
                    "fadeInMs" => sampler.fade_in_ms = v,
                    "fadeOutMs" => sampler.fade_out_ms = v,
                    "cut" => sampler.cut = value.round().clamp(0.0, 255.0) as u8,
                    _ => return Err(format!("the sampler has no parameter `{param}` (start, end: 0..1; reverse, norm, env: 0 or 1; semi, fine; delay, attack, hold, decay, release, fadeInMs, fadeOutMs in ms; sustain 0..1; attackTension, decayTension, releaseTension -1..1; cut 0..8)")),
                }
            }
        }
        ops.push(Op::PutChannel { channel: c, index: None });
    }
    if let (Some(v), Some(g)) = (arg(a, "ch"), arg(a, "group").and_then(Value::as_str)) {
        // the Channel Rack filter group ("" = none)
        let mut c = edited_channel(&p, &ops, v)?;
        let g = g.trim();
        if g.chars().count() > 40 {
            return Err("a group name has at most 40 characters".into());
        }
        c.group = (!g.is_empty()).then(|| g.to_string());
        ops.push(Op::PutChannel { channel: c, index: None });
    }
    if let Some(v) = arg(a, "remove") {
        ops.push(Op::RemoveChannel { id: find_channel(&p, v)?.id });
    }
    if ops.is_empty() {
        return Ok(json!(p.channels.iter().map(|c| channel_json(&p, c)).collect::<Vec<_>>()));
    }
    let rev = e.apply(&ops, false, if_revision).map_err(|x| x.to_string())?;
    let p = e.project();
    Ok(json!({ "revision": rev, "added": added, "channels": p.channels.iter().map(|c| channel_json(&p, c)).collect::<Vec<_>>() }))
}

/// One character per 16th: `.` empty, `x` full velocity, `1`..`9` = 10..90 %.
fn step_char(v: f32) -> char {
    if v >= 0.95 {
        'x'
    } else {
        char::from_digit((v * 10.0).round().clamp(1.0, 9.0) as u32, 10).unwrap_or('x')
    }
}

/// Parses a step string: `x`/`X` = on (velocity `vel`), `1`..`9` = 10..90 %, `.` `-` `_` `0` = off;
/// spaces and `|` are ignored (for readability: "x... x... | x... x...").
pub fn parse_steps(s: &str, vel: f32) -> R<Vec<(f32, f32)>> {
    let mut out = vec![];
    let mut k = 0;
    for ch in s.chars() {
        match ch {
            ' ' | '|' => continue,
            'x' | 'X' => out.push((k as f32, vel)),
            '1'..='9' => out.push((k as f32, ch.to_digit(10).unwrap() as f32 / 10.0)),
            '.' | '-' | '_' | '0' => {}
            other => return Err(format!("`{other}` in --steps: use x (on), 1-9 (velocity 10-90 %), . (off)")),
        }
        k += 1;
    }
    Ok(out)
}

/// Parses `--loop`: a step count sets the loop, `0` or `"off"` clears it (`Ok(None)`), and
/// anything else — including a bare value-less flag — is a usage error naming the bounds.
fn parse_loop(l: &Value, steps: u32) -> Result<Option<u32>, String> {
    if l.as_str() == Some("off") || l.as_str() == Some("0") || l.as_u64() == Some(0) {
        return Ok(None);
    }
    l.as_u64()
        .filter(|n| *n > 0 && *n <= steps as u64)
        .map(|n| Some(n as u32))
        .ok_or_else(|| format!("--loop is a step count 1..{steps} here (the pattern's length), 0 or \"off\" to clear"))
}

fn pattern_json(p: &wave_engine::Project, pt: &wave_engine::Pattern) -> Value {
    let steps = (pt.len * 4.0).round().max(1.0) as usize;
    let rows: Vec<Value> = p
        .channels
        .iter()
        .filter(|c| pt.notes.iter().any(|n| n.ch == c.id) || pt.channel_loops.contains_key(&c.id))
        .map(|c| {
            let mut line = vec!['.'; steps];
            let notes: Vec<_> = pt.notes.iter().filter(|n| n.ch == c.id).collect();
            for n in &notes {
                let i = n.step.round() as usize;
                if i < steps {
                    line[i] = step_char(n.v);
                }
            }
            let s: String = line.chunks(4).map(|g| g.iter().collect::<String>()).collect::<Vec<_>>().join(" ");
            let mut occupied = std::collections::HashSet::new();
            let simple = notes.iter().all(|n| {
                n.trig == Some(true) && n.len == 1.0 && n.p.is_none() && n.step.fract() == 0.0 && occupied.insert(n.step as usize)
            });
            let mut row = json!({ "ch": c.id, "name": c.name, "steps": s });
            if let Some(&l) = pt.channel_loops.get(&c.id) {
                row["loop"] = json!(l);
            }
            if !simple {
                row["notes"] = json!(notes
                    .iter()
                    .map(|n| {
                        let mut j =
                            json!({ "step": n.step, "len": n.len, "p": n.p.unwrap_or(c.root), "v": n.v, "trig": n.trig.unwrap_or(false) });
                        if n.slide {
                            j["slide"] = json!(true);
                        }
                        j
                    })
                    .collect::<Vec<_>>());
            }
            row
        })
        .collect();
    json!({ "id": pt.id, "name": pt.name, "color": pt.color, "bars": pt.len / 4.0, "lenBeats": pt.len, "minBars": pt.min_len / 4.0, "swing": (pt.swing * 100.0).round(), "rows": rows })
}

/// `synkopa pattern`: show a pattern as step strings, or edit it (one undo step).
pub fn pattern(app: &dyn Host, a: &Value, if_revision: Option<u64>) -> R<Value> {
    use wave_engine::{Note, Pattern};
    let e = app.engine();
    let p = e.project();
    let new = arg(a, "new").and_then(Value::as_bool).unwrap_or(false);
    let mut pt = if new {
        Pattern {
            id: p.next_id,
            name: format!("Pattern {}", p.patterns.len() + 1),
            color: "#4f8ef7".into(),
            len: 4.0,
            min_len: 4.0,
            notes: vec![],
            swing: 0.0,
            channel_loops: std::collections::BTreeMap::new(),
        }
    } else {
        let id = match arg(a, "id").and_then(as_index) {
            Some(id) => id,
            None if p.patterns.len() == 1 => p.patterns[0].id,
            None => {
                return Err(format!(
                    "which pattern? pass --id ({})",
                    p.patterns.iter().map(|x| format!("{} {}", x.id, x.name)).collect::<Vec<_>>().join(", ")
                ))
            }
        };
        p.patterns.iter().find(|x| x.id == id).cloned().ok_or(format!("no pattern {id}"))?
    };
    let before = pt.clone();
    if let Some(n) = arg(a, "name").and_then(Value::as_str) {
        pt.name = n.into();
    }
    if let Some(c) = arg(a, "color").and_then(Value::as_str) {
        pt.color = c.into();
    }
    if let Some(b) = opt_f64(a, "bars") {
        // the shortest the pattern may be: it still grows with notes past it
        if !(1.0..=wave_engine::TOTAL_BEATS / 4.0).contains(&b) || b.fract() != 0.0 {
            return Err(format!(
                "--bars is a whole number 1..{} (the pattern still grows to fit its notes)",
                wave_engine::TOTAL_BEATS / 4.0
            ));
        }
        pt.min_len = b * 4.0;
    }
    if let Some(s) = opt_f64(a, "swing") {
        if !(0.0..=100.0).contains(&s) {
            return Err("--swing is 0..100 (%)".into());
        }
        pt.swing = (s / 100.0) as f32;
    }
    let steps = arg(a, "steps").and_then(Value::as_str);
    let notes = arg(a, "notes");
    let stamp = arg(a, "stamp");
    // stamp is handled below on its own: it replaces only its target step, so it must
    // not enter the channel-wide replacement path
    if steps.is_some() || notes.is_some() || arg(a, "clear").and_then(Value::as_bool).unwrap_or(false) {
        let ch = find_channel(&p, arg(a, "ch").ok_or("--ch (channel id or name) is required with --steps / --notes / --clear")?)?.id;
        pt.notes.retain(|n| n.ch != ch);
        if let Some(s) = steps {
            let vel = opt_f64(a, "vel").unwrap_or(1.0) as f32;
            if !(0.0..=1.0).contains(&vel) {
                return Err("--vel is 0..1".into());
            }
            pt.notes.extend(parse_steps(s, vel)?.into_iter().map(|(k, v)| Note { v, ..Note::trigger(ch, k, None) }));
        }
        if let Some(ns) = notes {
            let list = ns.as_array().ok_or("--notes is a JSON array of {step, len, p?, v?, trig?, slide?}")?;
            for n in list {
                let step = opt_f64(n, "step").ok_or("each note needs `step` (16ths)")? as f32;
                let len = opt_f64(n, "len").unwrap_or(1.0) as f32;
                let key = arg(n, "p").and_then(as_index).map(|k| k.min(127) as u8);
                let v = opt_f64(n, "v").unwrap_or(1.0) as f32;
                let trigger = arg(n, "trig").map(|v| v.as_bool().ok_or("note `trig` must be a boolean")).transpose()?.unwrap_or(false);
                let slide = arg(n, "slide").map(|v| v.as_bool().ok_or("note `slide` must be a boolean")).transpose()?.unwrap_or(false);
                if slide && trigger {
                    return Err("a slide note is held for its length (the glide time): it cannot be a trigger".into());
                }
                pt.notes.push(Note { v, trig: Some(trigger), slide, ..Note::new(ch, step, len, key) });
            }
        }
    }
    // prospective length: `--bars` just raised the minimum, and the loop/stamp checks below
    // must see the length the pattern will actually have (the engine derives it the same way)
    pt.fit_len();
    let pre_loop_len = pt.len;
    // `synkopa notes stamp` lands here: one chord written through the existing note op
    let mut stamped: Option<Value> = stamp.map(|st| -> Result<Value, String> {
        let ch = find_channel(&p, arg(a, "ch").ok_or("--ch (channel id or name) is required with --stamp")?)?.id;
        let step = opt_f64(st, "step").ok_or("stamp needs `step` (16ths)")? as f32;
        let root = arg(st, "root").and_then(as_index).filter(|r| *r <= 127).ok_or("stamp needs `root` (a MIDI key 0..127, or a note name)")? as u8;
        let ty = st.get("type").and_then(Value::as_str).ok_or("stamp needs `type` (a chord id like min7 — see `synkopa schema`)")?;
        let inv = arg(st, "inv").and_then(as_index).unwrap_or(0);
        let len = opt_f64(st, "len").unwrap_or(4.0) as f32;
        if !(step.is_finite() && step >= 0.0 && len.is_finite() && len > 0.0) {
            return Err("stamp: `step` must be ≥ 0 and `len` > 0".into());
        }
        if wave_engine::transform::chord_intervals(ty).is_none() {
            return Err(format!("stamp: unknown chord type `{}` ({})", ty, wave_engine::transform::CHORD_TYPES.iter().map(|(id, _)| *id).collect::<Vec<_>>().join(", ")));
        }
        // an effective loop (an explicit --loop wins, else the channel's own) bounds the
        // stamp: a chord past it would be trimmed right after, and a successful reply must
        // not report notes nothing plays
        let eff_loop = match arg(a, "loop").map(|l| parse_loop(l, (pt.len * 4.0).round() as u32)).transpose()? {
            Some(l) => l,
            None => pt.channel_loops.get(&ch).copied(),
        };
        if eff_loop.is_some_and(|l| step >= l as f32) {
            return Err(format!("stamp: the channel loops its first {} steps — stamp inside the cell, or raise or clear the loop", eff_loop.unwrap()));
        }
        let pitches = wave_engine::transform::chord_pitches(root, ty, inv as u32)
            .ok_or_else(|| format!("stamp: root {root} pushes the top voice past MIDI 127"))?;
        // re-stamping a step replaces its notes on that channel: no pile-up
        pt.notes.retain(|n| !(n.ch == ch && n.step == step));
        pt.notes.extend(pitches.iter().map(|&k| Note { v: 0.8, ..Note::new(ch, step, len, Some(k)) }));
        Ok(json!({ "notes": pitches.iter().map(|&k| json!({ "step": step, "len": len, "p": k, "v": 0.8 })).collect::<Vec<_>>(), "label": wave_engine::transform::chord_name(&pitches) }))
    }).transpose()?;
    // A per-channel loop (FL Studio 20.1's channel looping): the channel's steps 0..n
    // repeat to fill the pattern, so setting it trims that channel's notes from step n on
    // (one undo step, nothing hidden); 0 or "off" clears the loop and keeps the cell. It
    // runs after every note write above, so `--loop` + `--steps`/`--stamp` in one call
    // trim the final notes.
    let mut loop_touched = false;
    if let Some(l) = arg(a, "loop") {
        let ch = find_channel(&p, arg(a, "ch").ok_or("--ch (channel id or name) is required with --loop")?)?.id;
        let loop_steps = parse_loop(l, (pt.len * 4.0).round() as u32)?;
        match loop_steps {
            None => {
                pt.channel_loops.remove(&ch);
            }
            Some(n) => {
                pt.notes.retain(|note| !(note.ch == ch && note.step >= n as f32));
                pt.channel_loops.insert(ch, n);
                loop_touched = true;
            }
        }
    }
    // the loop's invariant holds on every write: notes a steps/notes/stamp write put past
    // an already-set loop would never play, so they go in the same op
    if let Some(chv) = arg(a, "ch") {
        if let Ok(c) = find_channel(&p, chv) {
            if let Some(&l) = pt.channel_loops.get(&c.id) {
                let had = pt.notes.len();
                pt.notes.retain(|note| !(note.ch == c.id && note.step >= l as f32));
                loop_touched |= pt.notes.len() != had;
            }
        }
    }
    // the loop contract: setting or trimming for a loop never shrinks the pattern. The
    // length the pattern had becomes the minimum only when the remaining notes would
    // otherwise fall short of it — if they still reach it, min_len stays the user's and a
    // later deletion of the note that holds the length shrinks the pattern again
    if loop_touched && Pattern::content_len(&pt.notes) < pre_loop_len {
        pt.min_len = pt.min_len.max(pre_loop_len);
        pt.fit_len();
    }
    if let Some(s) = stamped.as_mut() {
        s["revision"] = json!(e.apply(&[Op::PutPattern { pattern: pt.clone() }], false, if_revision).map_err(|x| x.to_string())?);
        return Ok(s.clone());
    }
    if !new && pt == before {
        return Ok(pattern_json(&p, &pt));
    }
    let rev = e.apply(&[Op::PutPattern { pattern: pt.clone() }], false, if_revision).map_err(|x| x.to_string())?;
    let p = e.project();
    let pt = p.patterns.iter().find(|x| x.id == pt.id).ok_or("the pattern vanished")?;
    let mut v = pattern_json(&p, pt);
    v["revision"] = json!(rev);
    Ok(v)
}

// ---------------------------------------------------------------- takes & comps

/// The comp clip a takes/comp command means: `clip` if given, else the only one on `track`.
fn comp_clip(p: &wave_engine::Project, a: &Value) -> R<wave_engine::Clip> {
    use wave_engine::ClipKind;
    if let Some(id) = arg(a, "clip").and_then(as_index) {
        return p.clips.iter().find(|c| c.id == id && c.kind == ClipKind::Comp).cloned().ok_or(format!("clip {id} is not a comp clip"));
    }
    let track = need_u64(a, "track")? as u32;
    if track as usize >= p.tracks.len() {
        return Err(format!("no track {track} (tracks are 0..{})", p.tracks.len().saturating_sub(1)));
    }
    let cs: Vec<_> = p.clips.iter().filter(|c| c.track == track && c.kind == ClipKind::Comp).collect();
    match cs.len() {
        0 => Err(format!("track {track} has no takes (record with a loop set, or record over an existing clip)")),
        1 => Ok(cs[0].clone()),
        _ => Err(format!(
            "track {track} has several comp clips; pick one with --clip ({})",
            cs.iter().map(|c| c.id.to_string()).collect::<Vec<_>>().join(", ")
        )),
    }
}

/// Takes and comp of the comp clips on a track, in timeline beats.
pub fn takes(app: &dyn Host, a: &Value) -> R<Value> {
    let p = app.engine().project();
    let track = need_u64(a, "track")? as u32;
    let audition = app.engine().state().audition;
    let out: Vec<Value> = p
        .clips
        .iter()
        .filter(|c| c.track == track && c.kind == wave_engine::ClipKind::Comp)
        .filter_map(|c| {
            let cp = p.comp(c.source)?;
            let tl = |b: f64| b - c.offset + c.start;
            Some(json!({
                "clipId": c.id, "compId": cp.id, "name": cp.name, "start": c.start, "len": c.len,
                "xfadeMs": cp.xfade * 1000.0, "audition": audition.get(&cp.id),
                "takes": cp.takes.iter().map(|t| json!({
                    "id": t.id, "name": t.name, "source": t.source, "start": tl(t.start), "len": t.len,
                    "usedBeats": cp.regions.iter().filter(|r| r.take == t.id).map(|r| r.to - r.from).sum::<f64>(),
                })).collect::<Vec<_>>(),
                "regions": cp.regions.iter().map(|r| json!({
                    "take": r.take, "from": tl(r.from), "to": tl(r.to), "xfadeMs": r.xfade.map(|x| x * 1000.0),
                })).collect::<Vec<_>>(),
            }))
        })
        .collect();
    if out.is_empty() {
        return Err(format!("track {track} has no takes"));
    }
    Ok(json!(out))
}

/// Edits the comp of a comp clip. Times are timeline beats, crossfades milliseconds.
/// `regions` replaces the comp, `take` uses one whole take, `xfadeMs` sets the default
/// crossfade, `removeUnused` drops takes the comp does not play. One undo step.
pub fn comp(app: &dyn Host, a: &Value, if_revision: Option<u64>) -> R<Value> {
    let p = app.engine().project();
    let clip = comp_clip(&p, a)?;
    let mut cp = p.comp(clip.source).cloned().ok_or("the clip's comp is missing")?;
    let local = |b: f64| b - clip.start + clip.offset;
    let ms = |v: &Value, k: &str| -> R<Option<f32>> {
        match arg(v, k) {
            None => Ok(None),
            Some(x) => x.as_f64().map(|m| Some((m / 1000.0) as f32)).ok_or(format!("`{k}` must be a number of milliseconds")),
        }
    };
    let mut did = vec![];
    if let Some(rs) = arg(a, "regions") {
        let rs = rs.as_array().ok_or("`regions` must be an array of {take, from, to, xfadeMs?}")?;
        let mut regions = vec![];
        for r in rs {
            let take = need_u64(r, "take")?;
            let (from, to) = (opt_f64(r, "from").ok_or("each region needs `from`")?, opt_f64(r, "to").ok_or("each region needs `to`")?);
            regions.push(wave_engine::CompRegion { take, from: local(from), to: local(to), xfade: ms(r, "xfadeMs")? });
        }
        regions.sort_by(|x, y| x.from.total_cmp(&y.from));
        // a range wider than its take plays the take only
        for r in regions.iter_mut() {
            if let Some(t) = cp.take(r.take) {
                r.from = r.from.max(t.start);
                r.to = r.to.min(t.end());
            }
        }
        regions.retain(|r| r.to > r.from + 1e-9);
        cp.regions = regions;
        did.push("regions");
    }
    if let Some(t) = arg(a, "take").and_then(as_index) {
        let tk = cp.take(t).cloned().ok_or(format!("the comp has no take {t}"))?;
        cp.regions.clear();
        cp.write(t, tk.start, tk.end());
        did.push("take");
    }
    if let Some(x) = ms(a, "xfadeMs")? {
        cp.xfade = x;
        did.push("xfade");
    }
    if arg(a, "removeUnused").and_then(Value::as_bool).unwrap_or(false) {
        let used: Vec<u64> = cp.regions.iter().map(|r| r.take).collect();
        let n = cp.takes.len();
        cp.takes.retain(|t| used.contains(&t.id));
        if cp.takes.is_empty() {
            return Err("the comp plays no take; keep at least one".into());
        }
        did.push(if cp.takes.len() < n { "removeUnused" } else { "nothingUnused" });
    }
    if did.is_empty() {
        return Err("nothing to do: pass regions, take, xfadeMs or removeUnused".into());
    }
    let rev = app.engine().apply(&[Op::PutComp { comp: cp }], false, if_revision).map_err(|e| e.to_string())?;
    Ok(json!({ "revision": rev, "clipId": clip.id, "changed": did }))
}

/// Switches a clip to Tune to Reference (`reference` = source id), or back to
/// manual editing with `off`. Unset parameters keep their current values.
pub fn tune_ref(app: &dyn Host, a: &Value, if_revision: Option<u64>) -> R<u64> {
    let p = app.engine().project();
    let cid = need_u64(a, "clipId")?;
    let mut clip = p.clips.iter().find(|c| c.id == cid).cloned().ok_or(format!("no clip {cid}"))?;
    let mut tune = clip.tune.take().unwrap_or_default();
    if arg(a, "off").and_then(Value::as_bool).unwrap_or(false) {
        tune.reference = None;
    } else {
        let prev = tune.reference.clone();
        // `melodyChannel`: the notes that channel plays over the clip become the reference (a
        // copy, collected again by naming the channel again); `reference`: a recording
        let melody = match arg(a, "melodyChannel").and_then(as_index) {
            Some(ch) => Some(app.engine().melody_reference(cid, ch, None).map_err(|e| e.to_string())?.0),
            None if arg(a, "reference").is_some() => None,
            None => prev.as_ref().and_then(|r| r.melody.clone()),
        };
        let source = match &melody {
            Some(_) => 0,
            None => arg(a, "reference")
                .and_then(as_index)
                .or(prev.as_ref().filter(|r| r.melody.is_none()).map(|r| r.source))
                .ok_or("`reference` (source id) or `melodyChannel` is required")?,
        };
        let unit = |k: &str, d: f32| -> R<f32> {
            match opt_f64(a, k) {
                Some(v) if (0.0..=100.0).contains(&v) => Ok(v as f32 / 100.0),
                Some(_) => Err(format!("`{k}` is a percentage 0..100")),
                None => Ok(d),
            }
        };
        let base = prev.unwrap_or(RefTune {
            source,
            correction: 1.0,
            vibrato: 1.0,
            influence: 1.0,
            octave: None,
            key: 0,
            scale: 0,
            speed: None,
            melody: None,
        });
        let octave = match arg(a, "octave") {
            Some(Value::String(s)) if s == "auto" => None,
            Some(v) => Some(v.as_i64().ok_or("`octave` is auto or a whole number of semitones")? as i32),
            None => base.octave,
        };
        let speed = match opt_f64(a, "speed") {
            Some(v) if (0.0..=1000.0).contains(&v) => Some(v as f32),
            Some(_) => return Err("`speed` is 0..1000 ms".into()),
            None => base.speed,
        };
        tune.reference = Some(RefTune {
            source,
            correction: unit("correction", base.correction)?,
            vibrato: unit("vibrato", base.vibrato)?,
            // a melody gives every note's pitch: no scale share
            influence: if melody.is_some() { 1.0 } else { unit("influence", base.influence)? },
            octave,
            key: arg(a, "key").and_then(as_index).map(|k| k as u32).unwrap_or(base.key),
            scale: arg(a, "scale").and_then(as_index).map(|k| k as u32).unwrap_or(base.scale),
            speed,
            melody,
        });
    }
    clip.tune = tune.is_active().then_some(tune);
    app.engine().apply(&[Op::PutClips { clips: vec![clip] }], false, if_revision).map_err(|e| e.to_string())
}

/// The CLI entry: one request → JSON data.
pub fn control(app: &dyn Host, cmd: &str, a: &Value, if_revision: Option<u64>, label: Option<&str>) -> R<Value> {
    let e = app.engine();
    // the CLI's file mode carries the undo label in the args (no session header field), so every
    // label-named verb honors `--label` there too; the session header keeps precedence. The
    // top-level `label` arg key is reserved for this — verbs must not use it for content
    let label = label.or_else(|| arg(a, "label").and_then(Value::as_str));
    let ok_rev = |r: u64| json!({ "revision": r });
    if !app.live() && LIVE_ONLY.contains(&cmd) {
        return Err(live_only_error(cmd));
    }
    match cmd {
        "pitch_analyze" | "pitch_target" | "tune_ref" | "auto_vocal_plan" | "auto_vocal" | "f0_model" | "note_model" => {
            app.ensure_pitch_model()
        }
        c if crate::pitch_actions::COMMANDS.contains(&c) => app.ensure_pitch_model(),
        "vst3_params" | "vst3_set_param" | "plugin_params" | "plugin_set_param" => app.ensure_live_plugins(),
        _ => {}
    }
    if let Some(r) = crate::pitch_actions::control(app, cmd, a, if_revision) {
        return r;
    }
    if let Some(r) = crate::midi_actions::control(app, cmd, a, if_revision) {
        return r;
    }
    if let Some(r) = crate::fx_chains::control(app, cmd, a, if_revision) {
        return r;
    }
    if let Some(r) = crate::mix_assist::control(app, cmd, a, if_revision, label) {
        return r;
    }
    if let Some(r) = crate::stems_actions::control(app, cmd, a, if_revision) {
        return r;
    }
    if let Some(r) = crate::chords_actions::control(app, cmd, a, if_revision) {
        return r;
    }
    if let Some(r) = crate::audio_midi_actions::control(app, cmd, a, if_revision) {
        return r;
    }
    match cmd {
        "status" => {
            let st = e.state();
            Ok(
                json!({ "revision": st.revision, "transport": st.transport, "path": st.path, "dirty": st.dirty, "mode": if app.live() { "app" } else { "file" }, "audio": app.audio_json(), "cli": app.cli_json() }),
            )
        }
        "context" => Ok(context(app, arg(a, "full").and_then(Value::as_bool).unwrap_or(false))),
        "catalog" => Ok(json!({ "effects": catalog::catalog(), "keys": keys_catalog(), "commands": ALL_COMMANDS })),
        "schema" => Ok(schema()),
        "apply" => {
            let ops: Vec<Op> =
                serde_json::from_value(arg(a, "ops").cloned().unwrap_or(json!([]))).map_err(|er| format!("BAD_OPS: {er}"))?;
            e.apply_labeled(&ops, false, if_revision, label).map(ok_rev).map_err(|er| er.to_string())
        }
        "undo" => Ok(json!({ "undone": e.undo() })),
        "redo" => Ok(json!({ "redone": e.redo() })),
        "play" => {
            e.play(opt_f64(a, "from").unwrap_or(e.state().transport.start_beat));
            Ok(json!({ "playing": true }))
        }
        "stop" => {
            // the transport stops either way; a recording that could not be written comes
            // back as the action's error, so the UI can tell the user
            let t = e.stop().map_err(|e| e.to_string())?;
            Ok(json!({ "playing": false, "transport": t }))
        }
        "render" => render(app, a),
        "export_project_zip" => export_project_zip(e, Path::new(need_str(a, "out")?), if_revision),
        "import" => import(app, a),
        "add_fx" => {
            let kind = parse_kind(need_str(a, "type")?)?;
            let (id, rev) = add_fx(app, need_u64(a, "insertId")?, kind, arg(a, "preset").and_then(as_index).map(|x| x as usize), None)?;
            Ok(json!({ "fxId": id, "revision": rev }))
        }
        "route" => {
            let only = arg(a, "only").map(|v| v.as_bool().ok_or("`only` must be a boolean")).transpose()?.unwrap_or(false);
            route(app, need_u64(a, "from")?, need_u64(a, "to")?, opt_f64(a, "gain").map(|g| g as f32), only, if_revision).map(ok_rev)
        }
        "unroute" => unroute(app, need_u64(a, "from")?, need_u64(a, "to")?, if_revision).map(ok_rev),
        "sidechain" => {
            let off = arg(a, "off").map(|v| v.as_bool().ok_or("`off` must be a boolean")).transpose()?.unwrap_or(false);
            let num = |k: &str| arg(a, k).and_then(Value::as_u64);
            sidechain(app, num("fxId"), num("from"), num("to"), off, if_revision, label)
        }
        "set_param" => {
            set_param(app, need_u64(a, "fxId")?, need_str(a, "param")?, opt_f64(a, "value").ok_or("`value` is required")?, if_revision)
                .map(ok_rev)
        }
        "load_preset" => preset(app, need_u64(a, "fxId")?, need_u64(a, "index")? as usize).map(ok_rev),
        "save" => {
            let path = match arg(a, "path").and_then(Value::as_str) {
                Some(p) => PathBuf::from(p),
                None => e.state().path.map(PathBuf::from).ok_or("the project has never been saved; pass --path")?,
            };
            e.save(&path).map_err(|x| x.to_string())?;
            Ok(json!({ "path": path.display().to_string() }))
        }
        "open" => {
            let w = e.open(&PathBuf::from(need_str(a, "path")?)).map_err(|x| x.to_string())?;
            Ok(json!({ "warnings": w }))
        }
        "takes" => takes(app, a),
        "channels" => channels(app, a, if_revision),
        "markers" => markers(app, a, if_revision),
        "pattern" => pattern(app, a, if_revision),
        "pattern_play" => {
            let id = arg(a, "id").and_then(as_index);
            let from = opt_f64(a, "from").unwrap_or(0.0);
            let range = beat_range(a, "range")?;
            e.pattern_play(id, from, range).map_err(|x| x.to_string())?;
            Ok(json!({ "patternPlaying": id, "from": from, "range": range.map(|(x, y)| [x, y]) }))
        }
        "pattern_loop" => {
            let range = beat_range(a, "range")?;
            e.pattern_loop(range).map_err(|x| x.to_string())?;
            Ok(json!({ "range": range.map(|(x, y)| [x, y]) }))
        }
        "note_audition" => {
            let p = e.project();
            let ch = find_channel(&p, arg(a, "ch").ok_or("`ch` is required")?)?.id;
            e.note_audition(
                ch,
                arg(a, "key").and_then(as_index).map(|k| k.min(127) as u8),
                opt_f64(a, "vel").unwrap_or(0.8) as f32,
                arg(a, "pattern").and_then(as_index),
            )
            .map_err(|x| x.to_string())?;
            Ok(json!({}))
        }
        "comp" => comp(app, a, if_revision),
        "missing" => Ok(missing(app)),
        "relink" => relink(app, a),
        "set_project" => {
            let p = arg(a, "project").cloned().ok_or("`project`: the whole project, as `context --full` gives it")?;
            let p = wave_engine::Project::from_json(p).map_err(|x| format!("BAD_PROJECT: {x}"))?;
            e.set_project(p, if_revision, label).map(ok_rev).map_err(|x| x.to_string())
        }
        "make_unique" => {
            let ids: Vec<u64> = arg(a, "clipIds")
                .and_then(Value::as_array)
                .ok_or("`clipIds` (array of clip ids) is required")?
                .iter()
                .filter_map(as_index)
                .collect();
            make_unique(app, &ids)
        }
        "export_in_place" => {
            let range = match (opt_f64(a, "fromBeat"), opt_f64(a, "toBeat")) {
                (Some(f), Some(t)) => Some((f, t)),
                (None, None) => None,
                _ => return Err("`fromBeat` and `toBeat` go together".into()),
            };
            let ids: Vec<u64> = match arg(a, "clipIds") {
                Some(v) => v.as_array().ok_or("`clipIds` must be an array of clip ids")?.iter().filter_map(as_index).collect(),
                None if range.is_some() => vec![],
                None => return Err("`clipIds` (array of clip ids) or `fromBeat`/`toBeat` is required".into()),
            };
            export_in_place(app, &ids, range, &std::sync::atomic::AtomicBool::new(false), &mut |_| {})
        }
        "flatten_comp" => flatten_comp(app, comp_clip(&e.project(), a)?.id),
        "comp_audition" => {
            let clip = comp_clip(&e.project(), a)?;
            e.audition(clip.source, arg(a, "take").and_then(as_index)).map_err(|x| x.to_string())?;
            Ok(json!({ "compId": clip.source, "audition": e.state().audition.get(&clip.source) }))
        }
        "pitch_analyze" => {
            let an = pitch_analysis(app, need_u64(a, "clipId")?)?;
            Ok(json!({ "rate": an.rate, "backend": an.backend, "notes": an.notes }))
        }
        "pitch_target" => {
            let params = match arg(a, "reference") {
                Some(v) => Some(serde_json::from_value::<RefTune>(v.clone()).map_err(|er| format!("BAD_ARGS: reference: {er}"))?),
                None => None,
            };
            let t = pitch_target(app, need_u64(a, "clipId")?, params)?;
            if arg(a, "full").and_then(Value::as_bool).unwrap_or(false) {
                return Ok(json!(&*t));
            }
            Ok(
                json!({ "score": t.score, "octave": t.octave, "reason": t.reason, "start": t.start as f64 / t.rate as f64, "notes": t.notes }),
            )
        }
        "melody_channels" => melody_channels(e, need_u64(a, "clipId")?),
        "melody_reference" => {
            let span = match arg(a, "span") {
                Some(Value::Null) | None => None,
                Some(v) => Some(serde_json::from_value::<[f64; 2]>(v.clone()).map_err(|er| format!("BAD_ARGS: span: {er}"))?),
            };
            melody_reference(e, need_u64(a, "clipId")?, need_u64(a, "channel")?, span)
        }
        "tune_ref" => tune_ref(app, a, if_revision).map(ok_rev),
        "f0_model" => Ok(json!(crate::models::status(e, app.model_error()))),
        "f0_model_install" => {
            // the download (~345 MB) is SHA-256 checked inside `install`; blocking is fine here —
            // session requests run on their own thread (the app path streams progress events instead)
            f0_model_install(app, &|_, _| {}).map(|st| json!(st))
        }
        "note_model" => Ok(json!(crate::models::note_status(e))),
        // the download (~46 MB) is SHA-256 checked, then unpacked and loaded
        "note_model_install" => crate::models::note_install(e, |_, _| {}).map(|st| json!(st)),
        "music_analyze" => {
            let cid = arg(a, "clipId").and_then(as_index);
            let ex = arg(a, "excludeFx").and_then(as_index);
            Ok(json!(music_analysis(app, cid, ex)?))
        }
        "auto_vocal_plan" => {
            let cid = need_u64(a, "clipId")?;
            let beat = arg(a, "beatClipId").and_then(as_index);
            let style = match arg(a, "style").and_then(Value::as_str) {
                Some("hard") => wave_engine::autovocal::Style::Hard,
                _ => wave_engine::autovocal::Style::Natural,
            };
            let bake = arg(a, "bakeRider").and_then(Value::as_bool).unwrap_or(false);
            let plan = vocal_plan(app, cid, beat, style, bake)?;
            Ok(json!(plan))
        }
        "bake_rider" => {
            let cid = need_u64(a, "clipId")?;
            let params: std::collections::BTreeMap<String, f64> = match arg(a, "params") {
                Some(v) => serde_json::from_value(v.clone()).map_err(|er| format!("BAD_ARGS: params: {er}"))?,
                None => Default::default(),
            };
            bake_rider(app, cid, &params, if_revision)
        }
        "auto_vocal" => {
            let cid = need_u64(a, "clipId")?;
            let beat = arg(a, "beatClipId").and_then(as_index);
            let style = match arg(a, "style").and_then(Value::as_str) {
                Some("hard") => wave_engine::autovocal::Style::Hard,
                _ => wave_engine::autovocal::Style::Natural,
            };
            let no_bake = arg(a, "noBake").and_then(Value::as_bool).unwrap_or(false);
            auto_vocal(app, cid, beat, style, no_bake, if_revision, label, &|_| {})
        }
        "master_listen" => {
            let fx = need_u64(a, "fxId")?;
            let target = arg(a, "target").and_then(as_index).map(|t| t as usize);
            master_listen(app, fx, target, if_revision, label, &mut |_| {})
        }
        "plugin_scan" => Ok(json!(plugin_scan(app, arg(a, "rescan").and_then(Value::as_bool).unwrap_or(false))?)),
        "vst3_scan" => {
            let r = app.plugins().scan(arg(a, "rescan").and_then(Value::as_bool).unwrap_or(false));
            Ok(json!(r.plugins.into_iter().filter(|p| p.format == PluginRef::VST3).collect::<Vec<_>>()))
        }
        "plugin_add" | "vst3_add" => {
            let cid = need_str(a, "cid")?;
            // an LV2 plugin is named by its URI; a VST3 class id is hex
            let guess = if cid.contains(":") { PluginRef::LV2 } else { PluginRef::VST3 };
            let format = if cmd == "vst3_add" { PluginRef::VST3 } else { arg(a, "format").and_then(Value::as_str).unwrap_or(guess) };
            let path = arg(a, "path").and_then(Value::as_str).unwrap_or("");
            let (id, rev) = plugin_add(app, need_u64(a, "insertId")?, format, path, cid, None)?;
            Ok(json!({ "fxId": id, "revision": rev }))
        }
        "plugin_params" | "vst3_params" => {
            let q = arg(a, "query").and_then(Value::as_str).map(str::to_lowercase);
            let ps = plugin_params(app, need_u64(a, "fxId")?)?;
            Ok(json!(ps
                .into_iter()
                .filter(|p| q.as_ref().map(|q| p.name().to_lowercase().contains(q)).unwrap_or(true))
                .collect::<Vec<_>>()))
        }
        "plugin_load_anyway" => {
            plugin_load_anyway(app, need_u64(a, "fxId")?)?;
            Ok(json!({}))
        }
        "plugin_set_param" | "vst3_set_param" => {
            plugin_set_param(app, need_u64(a, "fxId")?, need_u64(a, "id")? as u32, opt_f64(a, "value").ok_or("`value` is required")?)?;
            Ok(json!({}))
        }
        other => Err(format!("UNKNOWN_COMMAND: `{other}` (see `synkopa catalog`)")),
    }
}

/// `melody_channels`: the channels whose notes play over an audio clip, best fit to the
/// singing first: `[{channel, name, notes, fit}]` (`fit` 0..1).
pub fn melody_channels(e: &wave_engine::Engine, clip_id: u64) -> Result<Value, String> {
    let list = e.melody_channels(clip_id).map_err(|x| x.to_string())?;
    let p = e.project();
    Ok(json!(list
        .into_iter()
        .map(|(id, n, fit)| json!({ "channel": id, "name": p.channels.iter().find(|c| c.id == id).map(|c| c.name.clone()).unwrap_or_default(), "notes": n, "fit": fit }))
        .collect::<Vec<_>>()))
}

/// `melody_reference`: the notes of `channel` over an audio clip as a melody reference
/// (`span`: seconds of the source) — `{melody: {channel, span?, notes}, fit}`.
pub fn melody_reference(e: &wave_engine::Engine, clip_id: u64, channel: u64, span: Option<[f64; 2]>) -> Result<Value, String> {
    let (m, fit) = e.melody_reference(clip_id, channel, span).map_err(|x| x.to_string())?;
    Ok(json!({ "melody": m, "fit": fit }))
}

#[cfg(test)]
mod tests {
    use super::{
        parse_steps, render_stems_to_dir, safe_file_stem, unique_file_stems, Bounce, ExportFormat, ExportStatus, WavEncoding, WAVE_SLICES,
    };
    use std::sync::atomic::AtomicBool;
    use std::sync::Arc;
    use wave_engine::{Engine, NoPlugins, Project};

    #[test]
    fn save_new_version_counts_up_and_never_lands_on_an_existing_file() {
        use super::next_version_path;
        use std::path::{Path, PathBuf};
        let free = |_: &Path| false;
        let dir = Path::new("songs");
        assert_eq!(next_version_path(&dir.join("Beat.synkopa"), free), dir.join("Beat_2.synkopa"));
        assert_eq!(next_version_path(&dir.join("Beat_2.synkopa"), free), dir.join("Beat_3.synkopa"));
        assert_eq!(next_version_path(&dir.join("Beat_19.wave"), free), dir.join("Beat_20.wave"));
        // not a version number: a word, a bare number, a leading underscore
        assert_eq!(next_version_path(&dir.join("Beat_final.synkopa"), free), dir.join("Beat_final_2.synkopa"));
        assert_eq!(next_version_path(&dir.join("808.synkopa"), free), dir.join("808_2.synkopa"));
        assert_eq!(next_version_path(&dir.join("_7.synkopa"), free), dir.join("_7_2.synkopa"));
        // names in use are skipped
        let used: Vec<PathBuf> = vec![dir.join("Beat_2.synkopa"), dir.join("Beat_3.synkopa")];
        assert_eq!(next_version_path(&dir.join("Beat.synkopa"), |p| used.iter().any(|u| u == p)), dir.join("Beat_4.synkopa"));
        assert_eq!(next_version_path(&dir.join("Beat_2.synkopa"), |p| used.iter().any(|u| u == p)), dir.join("Beat_4.synkopa"));
    }

    fn tmp(name: &str) -> std::path::PathBuf {
        let d = std::env::temp_dir().join(format!("wave-stems-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&d);
        d
    }

    fn names(dir: &std::path::Path) -> Vec<String> {
        let mut v: Vec<String> = std::fs::read_dir(dir)
            .map(|r| r.filter_map(|e| e.ok()).map(|e| e.file_name().to_string_lossy().into_owned()).collect())
            .unwrap_or_default();
        v.sort();
        v
    }

    fn sketch() -> Arc<Engine> {
        Engine::new(Project::sketch(), Arc::new(NoPlugins))
    }

    fn bounce(to: f64) -> Bounce {
        Bounce { from: 0.0, to, tail: 0.0, rate: 48_000, wrap: false, pattern: None }
    }

    #[test]
    fn wav_format_defaults_and_dither_validation() {
        assert_eq!(ExportFormat::parse(None, None, None, false).unwrap(), ExportFormat::Wav(WavEncoding::Float32));
        assert_eq!(ExportFormat::parse(Some("wav"), None, Some(24), true).unwrap(), ExportFormat::Wav(WavEncoding::Pcm24 { dither: true }));
        assert!(ExportFormat::parse(Some("wav"), None, Some(32), true).is_err());
        assert_eq!(ExportFormat::parse(Some("wav"), None, Some(16), true).unwrap(), ExportFormat::Wav(WavEncoding::Pcm16 { dither: true }));
        assert_eq!(
            ExportFormat::parse(Some("wav"), None, Some(16), false).unwrap(),
            ExportFormat::Wav(WavEncoding::Pcm16 { dither: false })
        );
        assert!(ExportFormat::parse(Some("wav"), None, Some(8), false).is_err());
        assert!(ExportFormat::parse(Some("mp3"), None, Some(24), false).is_err());
        assert!(ExportFormat::parse(Some("mp3"), None, None, true).is_err());
    }

    #[test]
    fn stem_files_are_named_after_the_inserts_and_are_all_equally_long() {
        let dir = tmp("ok");
        let e = sketch();
        let seen = std::sync::Mutex::new(vec![]);
        let r = render_stems_to_dir(&e, &dir, bounce(16.0), &AtomicBool::new(false), true, ExportFormat::Wav(WavEncoding::Float32), &|s| {
            seen.lock().unwrap().push(s.clone())
        })
        .unwrap();
        assert_eq!(names(&dir), ["Bass.wav", "Drums.wav", "Hats.wav", "Master.wav"], "no staged file is left");
        // 32-bit float stereo: 8 bytes a frame plus a small header, the same in every file
        let data = (16.0 * 60.0 / 128.0 * 48_000.0) as u64 * 8;
        let lens: Vec<u64> = names(&dir).iter().map(|n| std::fs::metadata(dir.join(n)).unwrap().len()).collect();
        assert!(lens.iter().all(|l| *l == lens[0] && (data..data + 200).contains(l)), "{lens:?} vs {data}");
        assert_eq!(r["files"].as_array().unwrap().len(), 4);
        assert_eq!(r["files"][0]["file"], "Master.wav");
        assert_eq!(r["files"][0]["master"], true);
        assert_eq!(r["skipped"].as_array().unwrap().len(), 0);
        let seen = seen.lock().unwrap();
        let first = seen.first().unwrap();
        assert_eq!((first.done, first.total, first.name.as_str(), first.stage), (0, 4, "Master", "prepare"));
        let last = seen.last().unwrap();
        assert_eq!((last.done, last.total, last.stage), (4, 4, "done"), "the last call reports everything done");
        // every file is announced, rendered to its end and then written, in order
        let order: Vec<String> = r["files"].as_array().unwrap().iter().map(|f| f["name"].as_str().unwrap().to_string()).collect();
        for (i, name) in order.iter().enumerate() {
            let mine: Vec<&ExportStatus> = seen.iter().filter(|s| s.done == i && s.stage != "done").collect();
            assert!(mine.iter().all(|s| &s.name == name && s.wave.len() == WAVE_SLICES));
            let stages: Vec<&str> = mine.iter().map(|s| s.stage).collect();
            assert_eq!(stages.first(), Some(&"prepare"));
            assert_eq!(stages.last(), Some(&"write"));
            let rendered = mine.iter().rfind(|s| s.stage == "render").unwrap();
            assert_eq!(rendered.frac, 1.0, "{name}: the last render report is the end of the file");
            assert!(rendered.peak > 0.01 && rendered.wave.iter().filter(|&&p| p > 0).count() > 20, "{name}: {:?}", rendered.wave);
            assert!(mine.windows(2).all(|w| w[0].frac <= w[1].frac || w[1].stage != w[0].stage), "{name}: progress never goes back");
        }
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn mp3_stems_decode_and_report_their_format() {
        let dir = tempfile::tempdir().unwrap();
        let bounce = Bounce { rate: 44_100, ..bounce(4.0) };
        let format = ExportFormat::Mp3 { kbps: 192 };
        let result = render_stems_to_dir(&sketch(), dir.path(), bounce, &AtomicBool::new(false), true, format, &|_| {}).unwrap();

        assert_eq!(result["format"], "mp3");
        assert_eq!(names(dir.path()), ["Bass.mp3", "Drums.mp3", "Master.mp3"]);
        assert_eq!(result["skipped"], serde_json::json!(["Hats"]));
        let expected_frames = (result["files"][0]["stats"]["seconds"].as_f64().unwrap() * f64::from(bounce.rate)).round() as usize;
        for file in names(dir.path()) {
            let audio = wave_engine::sources::Audio::load(&dir.path().join(&file)).unwrap();
            assert_eq!(audio.sr, bounce.rate);
            // The in-app MP3 decoder can include the Info frame, encoder delay, and final padding.
            // Gapless-aware decoding is checked separately against the corresponding WAV.
            assert!(
                audio.frames.abs_diff(expected_frames) <= 3 * 1_152,
                "{file}: decoded {} frames for {expected_frames} source frames",
                audio.frames
            );
        }

        let wrap = Bounce { wrap: true, ..bounce };
        let err = render_stems_to_dir(&sketch(), dir.path(), wrap, &AtomicBool::new(false), true, format, &|_| {}).unwrap_err();
        assert_eq!(err, "wrap tail requires WAV export");
    }

    #[test]
    fn a_destination_directory_keeps_existing_files_untouched() {
        let dir = tempfile::tempdir().unwrap();
        let master = dir.path().join("Master.mp3");
        std::fs::write(&master, b"existing master").unwrap();
        std::fs::create_dir(dir.path().join("Bass.mp3")).unwrap();
        let err = render_stems_to_dir(
            &sketch(),
            dir.path(),
            bounce(4.0),
            &AtomicBool::new(false),
            true,
            ExportFormat::Mp3 { kbps: 192 },
            &|_| {},
        )
        .unwrap_err();
        assert!(err.contains("destination is a directory"));
        assert_eq!(std::fs::read(master).unwrap(), b"existing master");
        assert_eq!(names(dir.path()), ["Bass.mp3", "Master.mp3"]);
    }

    #[test]
    fn the_master_file_is_optional() {
        let dir = tmp("nomaster");
        let r = render_stems_to_dir(
            &sketch(),
            &dir,
            bounce(16.0),
            &AtomicBool::new(false),
            false,
            ExportFormat::Wav(WavEncoding::Pcm24 { dither: false }),
            &|_| {},
        )
        .unwrap();
        assert_eq!(names(&dir), ["Bass.wav", "Drums.wav", "Hats.wav"]);
        let bytes = std::fs::read(dir.join("Bass.wav")).unwrap();
        assert_eq!(u16::from_le_bytes(bytes[34..36].try_into().unwrap()), 24);
        assert!(r["files"].as_array().unwrap().iter().all(|f| f["master"] == false));
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn a_stem_that_renders_silent_gets_no_file_and_is_reported() {
        // the hats only play from beat 8, so a bounce of beats 0..4 has nothing in them
        let dir = tmp("silent");
        let r = render_stems_to_dir(
            &sketch(),
            &dir,
            bounce(4.0),
            &AtomicBool::new(false),
            false,
            ExportFormat::Wav(WavEncoding::Float32),
            &|_| {},
        )
        .unwrap();
        assert_eq!(names(&dir), ["Bass.wav", "Drums.wav"]);
        assert_eq!(r["skipped"], serde_json::json!(["Hats"]));
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn cancelling_leaves_nothing_behind() {
        let dir = tmp("cancel");
        let cancel = AtomicBool::new(false);
        // cancel from the progress callback once the second file has started: one file is already staged
        let r = render_stems_to_dir(&sketch(), &dir, bounce(16.0), &cancel, true, ExportFormat::Wav(WavEncoding::Float32), &|s| {
            if s.done == 2 {
                cancel.store(true, std::sync::atomic::Ordering::Relaxed);
            }
        });
        assert_eq!(r.unwrap_err(), "cancelled");
        assert!(names(&dir).is_empty(), "left: {:?}", names(&dir));
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn nothing_to_export_is_an_error_not_an_empty_folder() {
        let mut p = Project::sketch();
        for t in p.tracks.iter_mut() {
            t.muted = true;
        }
        let dir = tmp("none");
        let e = Engine::new(p, Arc::new(NoPlugins));
        let err =
            render_stems_to_dir(&e, &dir, bounce(8.0), &AtomicBool::new(false), false, ExportFormat::Wav(WavEncoding::Float32), &|_| {})
                .unwrap_err();
        assert!(err.contains("nothing to export"), "{err}");
        assert!(!dir.exists() || names(&dir).is_empty());
        // with the master asked for, the (silent) mix is still written: it is what the song sounds like
        let r = render_stems_to_dir(&e, &dir, bounce(8.0), &AtomicBool::new(false), true, ExportFormat::Wav(WavEncoding::Float32), &|_| {})
            .unwrap();
        assert_eq!(names(&dir), ["Master.wav"]);
        assert_eq!(r["files"][0]["stats"]["silent"], true);
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn an_unwritable_folder_fails_cleanly() {
        let blocker = tmp("blocker");
        std::fs::write(&blocker, b"a file where the folder should go").unwrap();
        let err = render_stems_to_dir(
            &sketch(),
            &blocker.join("stems"),
            bounce(8.0),
            &AtomicBool::new(false),
            true,
            ExportFormat::Wav(WavEncoding::Float32),
            &|_| {},
        )
        .unwrap_err();
        assert!(err.contains("cannot create"), "{err}");
        std::fs::remove_file(&blocker).ok();
    }

    #[test]
    fn file_names_are_safe_and_unique() {
        assert_eq!(safe_file_stem("Kick / Snare: 2"), "Kick _ Snare_ 2");
        assert_eq!(safe_file_stem("  Lead...  "), "Lead");
        assert_eq!(safe_file_stem(""), "Insert");
        assert_eq!(safe_file_stem("???"), "___");
        assert_eq!(safe_file_stem("con"), "_con");
        assert_eq!(safe_file_stem("NUL.txt"), "_NUL.txt");
        assert_eq!(safe_file_stem("COM1"), "_COM1");
        assert_eq!(safe_file_stem("COM0"), "COM0");
        assert_eq!(safe_file_stem("Wokal główny"), "Wokal główny");
        assert_eq!(safe_file_stem(&"x".repeat(300)).len(), 100);
        let n = |v: &[&str]| unique_file_stems(&v.iter().map(|s| s.to_string()).collect::<Vec<_>>());
        assert_eq!(n(&["Bass", "bass", "BASS", "Bass (2)"]), ["Bass", "bass (2)", "BASS (3)", "Bass (2) (2)"]);
        assert_eq!(n(&["Master", "Master"]), ["Master", "Master (2)"]);
    }

    #[test]
    fn step_strings() {
        assert_eq!(parse_steps("x... x... | x.5. ..9.", 1.0).unwrap(), vec![(0.0, 1.0), (4.0, 1.0), (8.0, 1.0), (10.0, 0.5), (14.0, 0.9)]);
        assert_eq!(parse_steps("X-X_", 0.6).unwrap(), vec![(0.0, 0.6), (2.0, 0.6)]);
        assert!(parse_steps("x?x", 1.0).is_err());
        assert!(parse_steps("", 1.0).unwrap().is_empty());
    }
}

#[cfg(test)]
#[path = "autovocal_actions_tests.rs"]
mod autovocal_tests;
#[cfg(test)]
#[path = "master_actions_tests.rs"]
mod master_tests;

#[cfg(test)]
#[path = "export_in_place_tests.rs"]
mod export_in_place_tests;

#[cfg(test)]
#[path = "read_verb_tests.rs"]
mod read_verb_tests;

#[cfg(test)]
#[path = "sidechain_actions_tests.rs"]
mod sidechain_tests;

#[cfg(test)]
#[path = "undo_label_tests.rs"]
mod undo_label_tests;

#[cfg(test)]
#[path = "pattern_loop_tests.rs"]
mod pattern_loop_tests;

#[cfg(test)]
mod keys_channel_tests {
    use super::*;
    use crate::headless::Headless;
    use wave_engine::{ChannelSrc, Project};

    #[test]
    fn one_command_switches_the_instrument_and_sets_a_knob() {
        let h = Headless::new(Project::empty());
        let id = channels(&h, &json!({ "keys": true }), None).unwrap()["added"].as_u64().unwrap();
        // each part builds on the one before it: the knob does not undo the switch
        channels(&h, &json!({ "ch": id, "instrument": "wurlitzer", "param": "dynamics", "value": 50 }), None).unwrap();
        let p = h.engine().project();
        let ChannelSrc::Keys { keys } = &p.channel(id).unwrap().src else { panic!("not Keys") };
        assert_eq!((keys.instrument.as_str(), keys.dynamics), ("wurlitzer", 50.0));
    }
}
