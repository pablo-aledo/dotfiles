//! The sample library: the standard library that ships inside the program
//! (`wave_engine::factory`), the kits downloaded on demand (every file pinned by
//! SHA-256 in `assets-manifest.json`) and folders the user adds.

use std::io::Read;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

const MANIFEST: &str = include_str!("../../assets-manifest.json");
/// What a folder walk lists: exactly what the decoders open, so nothing shown fails to play.
const AUDIO_EXT: &[&str] = wave_engine::AUDIO_EXTENSIONS;

#[derive(Deserialize)]
struct Manifest {
    instruments: Vec<Kit>,
}

#[derive(Deserialize, Clone)]
struct Kit {
    id: String,
    name: String,
    #[serde(default)]
    description: String,
    #[serde(default)]
    attribution: String,
    samples: Vec<Sample>,
}

#[derive(Deserialize, Clone)]
struct Sample {
    file: String,
    url: String,
    sha256: String,
    bytes: u64,
    #[serde(default)]
    note: Option<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct KitInfo {
    pub id: String,
    pub name: String,
    pub description: String,
    pub bytes: u64,
    pub count: usize,
    pub installed: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FileInfo {
    pub name: String,
    pub path: String,
    pub group: String,
    /// MIDI key at which the file sounds at its own pitch, when the library knows it
    /// (a sampler channel made from the file is rooted there, so it plays in tune).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub root: Option<u8>,
    /// The file plays a note at `root` (false for drums and noises, whose root is only where
    /// the keyboard plays them unchanged).
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub pitched: bool,
}

/// A library listing: the files, and whether a folder bigger than the walk's cap was cut off
/// (the browser's list says so under the files).
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Listing {
    pub files: Vec<FileInfo>,
    pub truncated: bool,
}

fn manifest() -> Manifest {
    serde_json::from_str(MANIFEST).expect("embedded manifest is valid")
}

pub fn library_dir() -> PathBuf {
    wave_engine::factory::library_dir()
}

fn kit_dir(id: &str) -> PathBuf {
    library_dir().join(id)
}

/// Download size of every manifest kit, bytes.
pub fn kit_sizes() -> &'static std::collections::HashMap<String, u64> {
    static SIZES: std::sync::OnceLock<std::collections::HashMap<String, u64>> = std::sync::OnceLock::new();
    SIZES.get_or_init(|| manifest().instruments.into_iter().map(|k| (k.id, k.samples.iter().map(|s| s.bytes).sum())).collect())
}

fn installed(k: &Kit) -> bool {
    let d = kit_dir(&k.id);
    k.samples.iter().all(|s| d.join(&s.file).is_file())
}

/// The standard library first (always there), then the downloadable kits.
pub fn kits() -> Vec<KitInfo> {
    let standard = KitInfo {
        id: wave_engine::factory::KIT.into(),
        name: "Standard library".into(),
        description: "Drums, percussion, orchestra, tonal one-shots and effects that ship with Synkopa".into(),
        bytes: wave_engine::factory::files().iter().map(|f| f.bytes.len() as u64).sum(),
        count: wave_engine::factory::listed_files().count(),
        installed: true,
    };
    let downloads = manifest().instruments.into_iter().map(|k| KitInfo {
        installed: installed(&k),
        bytes: k.samples.iter().map(|s| s.bytes).sum(),
        count: k.samples.len(),
        id: k.id,
        name: k.name,
        description: k.description,
    });
    std::iter::once(standard).chain(downloads).collect()
}

/// The standard library's files, written into the library folder if they are not there yet.
fn standard_files() -> Result<Listing, String> {
    let dir =
        wave_engine::factory::install().map_err(|e| format!("could not write the standard library to {}: {e}", library_dir().display()))?;
    Ok(Listing {
        truncated: false,
        files: wave_engine::factory::listed_files()
            .map(|f| FileInfo {
                name: f.name.into(),
                path: dir.join(f.file).display().to_string(),
                group: f.group.into(),
                root: Some(f.root),
                pitched: f.pitched,
            })
            .collect(),
    })
}

/// Downloads every missing file of a kit, verifying checksums. Blocking.
pub fn install(id: &str, progress: impl Fn(usize, usize)) -> Result<(), String> {
    if id == wave_engine::factory::KIT {
        return standard_files().map(|_| ());
    }
    let kit = manifest().instruments.into_iter().find(|k| k.id == id).ok_or(format!("no kit {id}"))?;
    let dir = kit_dir(id);
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let total = kit.samples.len();
    for (i, s) in kit.samples.iter().enumerate() {
        progress(i, total);
        let dst = dir.join(&s.file);
        if dst.is_file() {
            continue;
        }
        let mut resp = crate::net::agent().get(&s.url).call().map_err(|e| format!("{}: {}", s.file, crate::net::explain(&e)))?;
        let mut bytes = Vec::with_capacity(s.bytes as usize);
        // never more than the manifest says (a hostile or broken server cannot fill the memory)
        resp.body_mut().with_config().limit(s.bytes + 1).reader().read_to_end(&mut bytes).map_err(|e| format!("{}: {e}", s.file))?;
        if bytes.len() as u64 != s.bytes {
            return Err(format!(
                "{}: {} bytes instead of {} — the download was cut short or altered; nothing was saved",
                s.file,
                bytes.len(),
                s.bytes
            ));
        }
        let got = hex(&Sha256::digest(&bytes));
        if !got.eq_ignore_ascii_case(&s.sha256) {
            return Err(format!("{}: checksum mismatch — the download was altered or damaged; nothing was saved", s.file));
        }
        let tmp = dst.with_extension("part");
        std::fs::write(&tmp, &bytes).map_err(|e| e.to_string())?;
        std::fs::rename(&tmp, &dst).map_err(|e| e.to_string())?;
    }
    if !kit.attribution.is_empty() {
        let _ = std::fs::write(dir.join("ATTRIBUTION.txt"), &kit.attribution);
    }
    progress(total, total);
    Ok(())
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}

pub fn kit_files(id: &str) -> Result<Listing, String> {
    if id == wave_engine::factory::KIT {
        return standard_files();
    }
    let Some(kit) = manifest().instruments.into_iter().find(|k| k.id == id) else { return Ok(Listing { files: vec![], truncated: false }) };
    let dir = kit_dir(id);
    Ok(Listing {
        truncated: false,
        files: kit
            .samples
            .iter()
            .filter(|s| dir.join(&s.file).is_file())
            .map(|s| {
                let note = s.note.clone().unwrap_or_default();
                let group = note.split([',', ' ']).next().filter(|g| !g.is_empty()).unwrap_or(&kit.name).to_string();
                FileInfo {
                    name: if note.is_empty() { s.file.clone() } else { note },
                    path: dir.join(&s.file).display().to_string(),
                    group,
                    root: None,
                    pitched: false,
                }
            })
            .collect(),
    })
}

/// Audio files under `root` (recursive), grouped by sub-folder; a folder bigger than the cap
/// is cut off and `truncated` says so. The walk collects one file past the cap so a folder of
/// exactly `cap` files is not reported as truncated.
pub fn folder_files(root: &Path) -> Listing {
    folder_walk(root, FOLDER_CAP)
}

/// How many files a folder walk returns at most; the rest is left out (`truncated`).
const FOLDER_CAP: usize = 5000;

fn folder_walk(root: &Path, cap: usize) -> Listing {
    let mut out = vec![];
    let mut stack = vec![root.to_path_buf()];
    while let Some(d) = stack.pop() {
        let Ok(rd) = std::fs::read_dir(&d) else { continue };
        let mut entries: Vec<_> = rd.flatten().collect();
        entries.sort_by_key(|e| e.file_name());
        for e in entries {
            let p = e.path();
            if p.is_dir() {
                stack.push(p);
            } else if p.extension().and_then(|x| x.to_str()).is_some_and(|x| AUDIO_EXT.contains(&x.to_ascii_lowercase().as_str())) {
                let group = p
                    .parent()
                    .and_then(|q| q.strip_prefix(root).ok())
                    .map(|q| q.display().to_string())
                    .filter(|g| !g.is_empty())
                    .unwrap_or_else(|| root.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default());
                out.push(FileInfo {
                    name: p.file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default(),
                    path: p.display().to_string(),
                    group,
                    root: None,
                    pitched: false,
                });
                if out.len() > cap {
                    out.truncate(cap);
                    return Listing { files: out, truncated: true };
                }
            }
        }
    }
    Listing { files: out, truncated: false }
}

#[cfg(test)]
mod tests {
    #[test]
    fn manifest_parses_and_has_kits() {
        let k = super::kits();
        assert!(k.iter().any(|k| k.id == "808-kit"));
        assert!(k.iter().all(|k| k.count > 0 && k.bytes > 0));
        // the standard library leads the list and needs no download
        assert_eq!(k[0].id, wave_engine::factory::KIT);
        assert!(k[0].installed && k[0].count >= 140);
    }

    #[test]
    fn folder_walk_groups_by_subfolder_and_reports_truncation() {
        let dir = std::env::temp_dir().join(format!("wave-library-walk-{}", std::process::id()));
        let a = dir.join("Kicks");
        let b = dir.join("Snares");
        std::fs::create_dir_all(&a).unwrap();
        std::fs::create_dir_all(&b).unwrap();
        std::fs::write(dir.join("top.wav"), b"").unwrap();
        std::fs::write(a.join("kick.wav"), b"").unwrap();
        std::fs::write(b.join("snare.wav"), b"").unwrap();
        std::fs::write(dir.join("readme.txt"), b"").unwrap();
        let all = super::folder_walk(&dir, 10);
        assert_eq!(all.files.len(), 3);
        assert!(!all.truncated);
        assert_eq!(all.files.iter().find(|f| f.group == "Kicks").map(|f| f.name.as_str()), Some("kick"));
        assert_eq!(all.files.iter().find(|f| f.group == "Snares").map(|f| f.name.as_str()), Some("snare"));
        // a file at the walk's root is grouped under the folder's own name; non-audio is skipped
        assert_eq!(all.files.iter().find(|f| f.name == "top").unwrap().group, dir.file_name().unwrap().to_string_lossy());
        assert!(!all.files.iter().any(|f| f.name.contains("readme")));
        // cut off at the cap says so; a folder of exactly the cap does not
        let cut = super::folder_walk(&dir, 2);
        assert_eq!(cut.files.len(), 2);
        assert!(cut.truncated);
        assert!(!super::folder_walk(&dir, 3).truncated);
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn folder_walk_lists_exactly_the_formats_the_decoders_open() {
        let dir = std::env::temp_dir().join(format!("wave-library-formats-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        for name in ["a.wav", "b.AIF", "c.aiff", "d.mp3", "e.m4a", "f.wma", "g.aac"] {
            std::fs::write(dir.join(name), b"").unwrap();
        }
        let listed = super::folder_walk(&dir, 100).files;
        let mut names: Vec<_> = listed.iter().map(|f| f.name.as_str()).collect();
        names.sort();
        assert_eq!(names, ["a", "b", "c", "d"], "formats with no decoder behind them are not offered");
        // every listed extension is one the decoder claims
        for f in &listed {
            let ext = std::path::Path::new(&f.path).extension().unwrap().to_string_lossy().to_ascii_lowercase();
            assert!(wave_engine::AUDIO_EXTENSIONS.contains(&ext.as_str()), "{ext}");
        }
        std::fs::remove_dir_all(&dir).unwrap();
    }
}
