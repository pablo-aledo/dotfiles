require 'starscope/version'
require 'starscope/db'
