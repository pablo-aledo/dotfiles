module Starscope
  VERSION = '1.6.1'.freeze
end
