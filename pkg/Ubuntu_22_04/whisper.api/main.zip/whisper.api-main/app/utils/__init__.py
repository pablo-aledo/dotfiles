import logging

from .utils import get_all_routes, print_routes

logger = logging.getLogger(__name__)
