# Examples

This directory contains different examples of using Ollama.
