# LangChain Web Summarization

This example summarizes a website

## Setup

```
pip install -r requirements.txt
```

## Run

```
python main.py
```
