# LangChain

This example is a basic "hello world" of using LangChain with Ollama.

## Setup

```
pip install -r requirements.txt
```

## Run

```
python main.py
```

Running this example will print the response for "hello":

```
Hello! It's nice to meet you. hopefully you are having a great day! Is there something I can help you with or would you like to chat?
```
