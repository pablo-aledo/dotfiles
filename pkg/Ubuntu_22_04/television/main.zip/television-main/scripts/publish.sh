cargo publish -p television-derive
sleep 10
cargo publish -p television-fuzzy
sleep 10
cargo publish -p television-utils
sleep 10
cargo publish -p television-channels
sleep 10
cargo publish -p television-previewers
sleep 10
cargo publish -p television-screen
sleep 10
cargo publish -p television
