---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Problem**
A description of what is the problem that can be fixed with the feature you propose.

**Feature**
A description of the feature you propose.

**Examples**
One or more code examples that shows the feature in action.

**Additional context**
Any other context about the feature request here.
