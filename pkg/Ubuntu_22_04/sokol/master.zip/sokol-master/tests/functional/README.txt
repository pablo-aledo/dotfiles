Test the public API behaviour with dummy backends.
