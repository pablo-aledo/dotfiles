Spine examples taken from:

https://github.com/EsotericSoftware/spine-runtimes/tree/4.1/examples
