#define SOKOL_LOG_IMPL
#include "sokol_log.h"
