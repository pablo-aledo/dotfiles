#include "sokol_gfx.h"
#define SOKOL_IMPL
#include "sokol_shape.h"

void use_shape_impl(void) {
    sshape_plane_sizes(10);
}
