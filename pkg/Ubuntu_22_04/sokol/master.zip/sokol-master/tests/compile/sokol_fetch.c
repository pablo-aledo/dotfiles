#define SOKOL_IMPL
#include "sokol_fetch.h"

void use_fetch_impl(void) {
    sfetch_setup(&(sfetch_desc_t){0});
}
