#include "sokol_gfx.h"
#define SOKOL_IMPL
#include "sokol_debugtext.h"

void use_debugtext_impl() {
    sdtx_setup({});
}
