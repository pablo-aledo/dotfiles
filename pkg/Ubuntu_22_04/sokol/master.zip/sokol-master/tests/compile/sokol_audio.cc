#define SOKOL_IMPL
#include "sokol_audio.h"

void use_audio_impl() {
    saudio_setup({});
}
