#define SOKOL_IMPL
#include "sokol_time.h"

void use_time_impl(void) {
    stm_setup();
}
