#include "sokol_gfx.h"
#define SOKOL_IMPL
#include "sokol_gl.h"

void use_gl_impl() {
    sgl_setup({});
}
