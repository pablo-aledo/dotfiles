#define SOKOL_IMPL
#include "sokol_gfx.h"

void use_gfx_impl() {
    sg_setup({});
}
