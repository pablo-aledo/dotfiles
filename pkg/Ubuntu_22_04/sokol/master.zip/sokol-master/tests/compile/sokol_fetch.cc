#define SOKOL_IMPL
#include "sokol_fetch.h"

void use_fetch_impl() {
    sfetch_setup({});
}
