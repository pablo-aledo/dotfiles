#define SOKOL_IMPL
#include "sokol_gfx.h"

void use_gfx_impl(void) {
    sg_setup(&(sg_desc){0});
}
