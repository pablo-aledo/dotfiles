#define SOKOL_IMPL
#include "sokol_args.h"

void use_args_impl(void) {
    sargs_setup(&(sargs_desc){0});
}
