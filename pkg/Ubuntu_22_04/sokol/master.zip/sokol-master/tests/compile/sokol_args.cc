#define SOKOL_IMPL
#include "sokol_args.h"

void use_args_impl() {
    sargs_setup({});
}
