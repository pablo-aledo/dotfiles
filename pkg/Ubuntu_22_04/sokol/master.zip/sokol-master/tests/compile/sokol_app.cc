#define SOKOL_IMPL
#include "sokol_app.h"

void use_app_impl() {
    sapp_run({ });
}
