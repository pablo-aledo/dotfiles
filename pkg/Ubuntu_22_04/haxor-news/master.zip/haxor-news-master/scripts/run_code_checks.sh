#!/usr/bin/env bash

flake8 --max-line-length=80 --exclude=build,docs,scratch,docs,haxor,html2text,onions.py,compat.py .
