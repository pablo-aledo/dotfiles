#include "translator/Translator.h"

std::unique_ptr<Translator> GraphPlanarTranslator() {
  return nullptr;
}
