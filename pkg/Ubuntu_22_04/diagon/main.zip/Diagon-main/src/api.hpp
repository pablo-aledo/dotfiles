#ifndef DIAGON_API_H
#define DIAGON_API_H

extern "C" const char* API();

#endif /* end of include guard: DIAGON_API_H */
