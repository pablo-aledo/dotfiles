.. module:: mingus.containers.mt_exceptions

===============================
mingus.containers.mt_exceptions
===============================


.. class:: InstrumentRangeError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: MeterFormatError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: NoteFormatError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: UnexpectedObjectError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``
----



:doc:`Back to Index</index>`
