.. module:: mingus.core.mt_exceptions

=========================
mingus.core.mt_exceptions
=========================


.. class:: Error


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: FingerError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: FormatError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: KeyError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: NoteFormatError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``

.. class:: RangeError


   .. attribute:: args

      Attribute of type: getset_descriptor
      ``<attribute 'args' of 'exceptions.BaseException' objects>``

   .. attribute:: message

      Attribute of type: getset_descriptor
      ``<attribute 'message' of 'exceptions.BaseException' objects>``
----



:doc:`Back to Index</index>`
