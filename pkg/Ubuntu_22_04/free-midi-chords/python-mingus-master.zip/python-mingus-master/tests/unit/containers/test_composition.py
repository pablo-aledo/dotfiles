# -*- coding: utf-8 -*-
from __future__ import absolute_import

import unittest

# noinspection PyUnresolvedReferences
from mingus.containers.composition import Composition


class test_Composition(unittest.TestCase):
    def setUp(self):
        pass
