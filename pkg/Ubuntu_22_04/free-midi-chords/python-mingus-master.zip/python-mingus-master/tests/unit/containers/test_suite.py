# -*- coding: utf-8 -*-
from __future__ import absolute_import

import unittest

# noinspection PyUnresolvedReferences
from mingus.containers.suite import Suite


class test_Suite(unittest.TestCase):
    def setUp(self):
        pass
