from __future__ import absolute_import

import unittest

# noinspection PyUnresolvedReferences
import mingus.extra.musicxml as mxl


class test_MusicXML(unittest.TestCase):
    def setUp(self):
        pass
