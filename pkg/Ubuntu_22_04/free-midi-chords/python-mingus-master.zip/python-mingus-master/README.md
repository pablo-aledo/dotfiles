mingus
======

mingus is a package for Python used by programmers, musicians, composers
and researchers to make and analyse music.

Install with `pip install mingus`

[Browse the documentation](http://bspaans.github.io/python-mingus/)

