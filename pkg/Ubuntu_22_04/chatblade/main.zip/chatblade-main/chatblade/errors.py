class ChatbladeError(Exception):
    pass
