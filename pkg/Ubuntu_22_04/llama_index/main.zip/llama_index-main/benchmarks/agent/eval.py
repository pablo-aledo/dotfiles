def contains_expected_response(response: str, expected_response: str) -> bool:
    """Check if the response contains the expected response."""
    return expected_response in response
