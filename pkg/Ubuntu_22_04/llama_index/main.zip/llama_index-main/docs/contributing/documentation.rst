.. mdinclude:: ../DOCS_README.md
