LiteLLM
=========

.. autopydantic_model:: llama_index.llms.litellm.LiteLLM
