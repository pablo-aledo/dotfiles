OpenAILike
==========

.. autopydantic_model:: llama_index.llms.openai_like.OpenAILike
