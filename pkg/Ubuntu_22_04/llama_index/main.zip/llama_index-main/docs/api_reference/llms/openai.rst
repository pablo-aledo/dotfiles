OpenAI
======

.. autopydantic_model:: llama_index.llms.openai.OpenAI
