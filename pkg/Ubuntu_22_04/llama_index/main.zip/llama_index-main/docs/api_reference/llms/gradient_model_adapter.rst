Gradient Model Adapter
=========

.. autopydantic_model:: llama_index.llms.gradient.GradientModelAdapterLLM
    :inherited-members: CustomLLM
