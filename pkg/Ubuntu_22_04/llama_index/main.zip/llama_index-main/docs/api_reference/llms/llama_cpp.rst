LlamaCPP
========

.. autopydantic_model:: llama_index.llms.llama_cpp.LlamaCPP
