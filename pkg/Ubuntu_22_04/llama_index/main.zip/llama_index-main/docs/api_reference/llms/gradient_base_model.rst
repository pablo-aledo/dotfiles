Gradient Base Model
=========

.. autopydantic_model:: llama_index.llms.gradient.GradientBaseModelLLM
    :inherited-members: CustomLLM
