LangChainLLM
============

.. autopydantic_model:: llama_index.llms.langchain.LangChainLLM
