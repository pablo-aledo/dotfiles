PaLM
====

.. autopydantic_model:: llama_index.llms.palm.PaLM
