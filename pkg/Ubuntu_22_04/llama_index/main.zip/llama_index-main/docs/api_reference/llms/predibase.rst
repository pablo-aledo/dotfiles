Predibase
=========

.. autopydantic_model:: llama_index.llms.predibase.Predibase
