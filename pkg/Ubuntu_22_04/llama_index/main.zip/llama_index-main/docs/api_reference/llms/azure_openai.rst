Azure OpenAI
============

.. autopydantic_model:: llama_index.llms.azure_openai.AzureOpenAI
