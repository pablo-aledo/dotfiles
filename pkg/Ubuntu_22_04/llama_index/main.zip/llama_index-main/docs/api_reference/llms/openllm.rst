OpenLLM
=======

.. autopydantic_model:: llama_index.llms.openllm.OpenLLM

.. autopydantic_model:: llama_index.llms.openllm.OpenLLMAPI
