XOrbits Xinference
==================

.. autopydantic_model:: llama_index.llms.xinference.Xinference
