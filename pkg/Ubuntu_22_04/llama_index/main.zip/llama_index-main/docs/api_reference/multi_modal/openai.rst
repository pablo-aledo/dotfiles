OpenAI
======

.. autopydantic_model:: llama_index.multi_modal_llms.openai.OpenAIMultiModal
