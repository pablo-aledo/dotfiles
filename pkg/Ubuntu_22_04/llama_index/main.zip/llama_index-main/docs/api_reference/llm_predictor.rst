.. _Ref-Node:

LLM Predictors
=================

.. automodule:: llama_index.llm_predictor
   :members:
   :inherited-members:
