Router Query Engine
=======================

.. automodule:: llama_index.query_engine.router_query_engine
   :members:
   :inherited-members:
   :exclude-members: acombine_responses, combine_responses, default_node_to_metadata_fn
