Transform Retriever
=======================

.. automodule:: llama_index.retrievers.transform_retriever
   :members:
   :inherited-members:
..    :exclude-members: index_struct, query, set_llm_predictor, set_prompt_helper
