Query Bundle
============

.. automodule:: llama_index.indices.query.schema
   :members: QueryBundle
   :inherited-members:
   :exclude-members:
