Empty Index Retriever
=======================

.. automodule:: llama_index.indices.empty.retrievers
   :members:
   :inherited-members:
..    :exclude-members: index_struct, query, set_llm_predictor, set_prompt_helper
