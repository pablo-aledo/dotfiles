.. _Ref-Node-Postprocessor:

Node Postprocessor
===================

.. automodule:: llama_index.indices.postprocessor
   :members:
   :inherited-members:
