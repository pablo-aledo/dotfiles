.. _Ref-Indices-Tree:

Tree Index
==========

Building the Tree Index

.. automodule:: llama_index.indices.tree
   :members:
   :inherited-members:
