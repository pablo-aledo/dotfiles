.. _Ref-Indices-Knowledge-Graph:

Knowledge Graph Index
=====================

Building the Knowledge Graph Index

.. automodule:: llama_index.indices.knowledge_graph
   :members:
   :inherited-members:
   :exclude-members: delete, docstore, index_struct, index_struct_cls
