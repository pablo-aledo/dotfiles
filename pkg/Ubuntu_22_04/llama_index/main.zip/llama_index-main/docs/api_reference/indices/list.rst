.. _Ref-Indices-List:

Summary Index
==========

Building the Summary Index

.. automodule:: llama_index.indices.list
   :members:
   :inherited-members:
   :exclude-members: delete, docstore, index_struct, index_struct_cls
