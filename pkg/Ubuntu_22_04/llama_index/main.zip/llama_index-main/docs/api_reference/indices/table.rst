.. _Ref-Indices-Table:

Table Index
===========

Building the Keyword Table Index

.. automodule:: llama_index.indices.keyword_table
   :members:
   :inherited-members:
