.. _Ref-Evaluation:


Evaluation
====

We have modules for both LLM-based evaluation and retrieval-based evaluation.

.. automodule:: llama_index.evaluation
   :members:
   :inherited-members:
