.. _Ref-Storage-Vector-Store:

Vector Store
=====================

.. automodapi:: llama_index.vector_stores
   :no-inheritance-diagram:
