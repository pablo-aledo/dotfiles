.. _Ref-Storage-Docstore:

Document Store
=====================

.. automodule:: llama_index.storage.docstore
   :members:
   :inherited-members:
