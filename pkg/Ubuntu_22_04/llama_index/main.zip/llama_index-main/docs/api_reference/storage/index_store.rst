.. _Ref-Storage-Index-Store:

Index Store
=====================

.. automodule:: llama_index.storage.index_store
   :members:
   :inherited-members:
