# Resources

Data from this directory is linked in inside of the binary.

## Script templates

For convinience of distributing a single binary that requires no installation, files in `templates` directory are linked into the binary. They are stripped offile extensions and shown as templates via `scriptisto new` command.
