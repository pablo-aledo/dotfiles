import 'functions.dart';

void main(List<String> arguments) {
  print(
      'Hello Dart, arguments=$arguments getWorkingDirectory()=${getWorkingDirectory()}');
}
