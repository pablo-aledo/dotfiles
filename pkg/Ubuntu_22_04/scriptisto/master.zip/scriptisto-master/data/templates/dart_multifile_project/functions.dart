// This file will also be checked for changes by scriptisto

import 'dart:io';

String getWorkingDirectory() {
  return Directory.current.path;
}
