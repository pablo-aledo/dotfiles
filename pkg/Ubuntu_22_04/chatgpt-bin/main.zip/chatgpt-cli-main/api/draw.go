package api

type Draw struct {
	Model  string `json:"model"`
	Prompt string `json:"prompt"`
}
