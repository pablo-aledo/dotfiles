./scripts/run_test.sh Contract
