#!/bin/bash
make compile
`make run-command` "$@"
