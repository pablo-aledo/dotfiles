import type { LayoutLoad } from "./$types";

interface t {
  id: string;
  created: string;
  model: string;
  subtitle: string;
}

export const load: LayoutLoad = async ({ fetch }) => {
  const r = await fetch("/api/chat/");
  const chats = (await r.json()) as t[];
  return {
    chats,
  };
};
