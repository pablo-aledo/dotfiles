#pragma once

#include <string>

namespace hex::plugin::builtin {

    std::string demangle(const std::string &mangled);

}