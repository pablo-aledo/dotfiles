#pragma once

namespace hex::plugin::builtin {

    void openProject();
    bool saveProject();
    bool saveProjectAs();

}
