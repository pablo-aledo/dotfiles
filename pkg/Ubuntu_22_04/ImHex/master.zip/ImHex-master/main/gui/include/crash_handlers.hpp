#pragma once

namespace hex::crash {

    void setupCrashHandlers();

}