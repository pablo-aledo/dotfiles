#pragma once

constexpr static auto ImHexApiURL  = "https://api.werwolv.net/imhex";
constexpr static auto GitHubApiURL = "https://api.github.com/repos/WerWolv/ImHex";
