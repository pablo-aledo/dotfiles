# Security Policy

## Supported Versions

Supported is generally only the latest version that can be downloaded from the Release tab. If you have issues, you might get instructed to use the Nightly release version instead.
If you built ImHex yourself and experience issues that are not present in the version built by GitHub, you're on your own.

## Reporting a Vulnerability

Any critical vulnerabilities can be reported through Discord (@werwolv).
