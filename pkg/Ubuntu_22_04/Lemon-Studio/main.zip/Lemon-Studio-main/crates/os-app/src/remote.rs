// Copyright (C) 2026 ItsAlphaNeon
// SPDX-License-Identifier: GPL-3.0-or-later
// This file is part of Lemon Studio: https://github.com/ItsAlphaNeon/Lemon-Studio

//! Remote control: MIDI controllers linked to knobs. The links (kept in `settings.txt`, key `midi_links`), how a
//! controller value drives its knob (formula, mode, pickup, smoothing), the Remote control settings box ("Link to
//! controller..." on a knob's menu; drawn by `views::remote_box`) and Multilink to controllers.
// spec: ui/remote-control.md

use std::collections::VecDeque;
use std::time::{Duration, Instant};

use crate::app::{App, State};
use crate::knobs::KnobId;
use crate::playlist::{Cmd, PItem};
use crate::typein::Target;

/// How a link treats a button's 127 / 0 (spec §3).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Mode {
    #[default]
    Default,
    Hold,
    Latch,
    Inc,
    Stay,
}

impl Mode {
    pub const ALL: [Mode; 5] = [Mode::Default, Mode::Hold, Mode::Latch, Mode::Inc, Mode::Stay];

    pub fn name(self) -> &'static str {
        match self {
            Mode::Default => "Default",
            Mode::Hold => "Hold",
            Mode::Latch => "Latch",
            Mode::Inc => "Inc",
            Mode::Stay => "Stay",
        }
    }
}

/// The mapping formula (spec §3).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Formula {
    #[default]
    Input,
    Inverted,
    Square,
    Root,
}

impl Formula {
    pub const ALL: [Formula; 4] = [Formula::Input, Formula::Inverted, Formula::Square, Formula::Root];

    pub fn name(self) -> &'static str {
        match self {
            Formula::Input => "Input",
            Formula::Inverted => "1 - Input",
            Formula::Square => "Input ^ 2",
            Formula::Root => "Sqrt(Input)",
        }
    }

    /// The note beside the combo.
    pub fn note(self) -> &'static str {
        match self {
            Formula::Input => "(default 1:1 mapping)",
            Formula::Inverted => "(inverted)",
            Formula::Square => "(slow start)",
            Formula::Root => "(fast start)",
        }
    }

    pub fn map(self, x: f32) -> f32 {
        let x = x.clamp(0.0, 1.0);
        match self {
            Formula::Input => x,
            Formula::Inverted => 1.0 - x,
            Formula::Square => x * x,
            Formula::Root => x.sqrt(),
        }
    }
}

/// Smoothing time's range and default, in milliseconds (spec §3).
pub const SMOOTH_MIN: u16 = 10;
pub const SMOOTH_MAX: u16 = 1000;
pub const SMOOTH_DEFAULT: u16 = 100;

/// A controller linked to a knob.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Link {
    /// The device's port (Settings > MIDI); `None` = any device.
    pub port: Option<u8>,
    /// MIDI channel 0..15.
    pub ch: u8,
    pub cc: u8,
    pub mode: Mode,
    pub formula: Formula,
    /// Smoothing time in milliseconds, when on.
    pub smooth: Option<u16>,
    /// Drives the selected channel's knob of the same kind (channel volume / pan targets).
    pub omni: bool,
    pub target: Target,
}

impl Link {
    pub fn new(ch: u8, cc: u8, target: Target) -> Link {
        Link { port: None, ch, cc, mode: Mode::Default, formula: Formula::Input, smooth: None, omni: false, target }
    }

    /// Whether a controller message from a device of port `port` drives it.
    fn hears(&self, port: Option<u8>, ch: u8, cc: u8) -> bool {
        self.ch == ch && self.cc == cc && (self.port.is_none() || self.port == port)
    }

    /// The same controller as `o` (Remove conflicts).
    fn same_controller(&self, o: &Link) -> bool {
        self.ch == o.ch && self.cc == o.cc && self.port == o.port
    }
}

/// Whether `t` can be linked: the piano roll tool dialogs' knobs live only while their dialog is open. A rack row's
/// mixer track box and LED can be (Lemon Studio's design): the controller's travel spans Master to the last insert,
/// and turns the channel on from its middle. So can the effects inside a container, their parameters and their wet
/// and dry levels (Lemon Studio's design: spec plugins/patcher/README.md §4.2).
fn linkable(t: Target) -> bool {
    // A member's level knob links as its level (`KnobId::target`).
    !matches!(t, Target::Knob(KnobId::Strum(_) | KnobId::Arp(_) | KnobId::PianoDlg(_) | KnobId::AutoLfo(..) | KnobId::MidiOut(..) | KnobId::Member(..)) | Target::Latency(..))
}

/// A target as `settings.txt` keeps it (`none` for one that is not linkable, which reads back as nothing).
fn target_text(t: Target) -> String {
    match t {
        Target::Knob(k) => match k {
            KnobId::MasterVol => "mainvol".into(),
            KnobId::MasterPitch => "mainpitch".into(),
            KnobId::MixPan(m) => format!("mixpan:{m}"),
            KnobId::MixSep(m) => format!("mixsep:{m}"),
            KnobId::SlotMix(m, s) => format!("slotmix:{m}:{s}"),
            KnobId::Send(a, b) => format!("send:{a}:{b}"),
            KnobId::ChanVol(r) => format!("chanvol:{r}"),
            KnobId::ChanPan(r) => format!("chanpan:{r}"),
            KnobId::Swing => "swing".into(),
            KnobId::Eq(m, b, f) => format!("eq:{m}:{b}:{f}"),
            KnobId::Strum(_) | KnobId::Arp(_) | KnobId::PianoDlg(_) | KnobId::AutoLfo(..) | KnobId::MidiOut(..) | KnobId::Member(..) => "none".into(),
        },
        Target::Fader(m) => format!("fader:{m}"),
        Target::Param(key, i) => format!("param:{key}:{i}"),
        Target::RackTrack(r) => format!("racktrack:{r}"),
        Target::RackLed(r) => format!("rackled:{r}"),
        Target::Member(m, k, id, wet) => format!("{}:{m}:{k}:{id}", if wet { "memberwet" } else { "memberdry" }),
        Target::MemberParam(m, k, id, i) => format!("memberparam:{m}:{k}:{id}:{i}"),
        Target::Latency(..) => "none".into(),
    }
}

fn parse_target(s: &str) -> Option<Target> {
    let mut f = s.split(':');
    let kind = f.next()?;
    let mut n = || f.next().and_then(|v| v.parse::<usize>().ok());
    Some(match kind {
        "mainvol" => Target::Knob(KnobId::MasterVol),
        "mainpitch" => Target::Knob(KnobId::MasterPitch),
        "swing" => Target::Knob(KnobId::Swing),
        "mixpan" => Target::Knob(KnobId::MixPan(n()? as u16)),
        "mixsep" => Target::Knob(KnobId::MixSep(n()? as u16)),
        "slotmix" => Target::Knob(KnobId::SlotMix(n()? as u16, n()? as u8)),
        "send" => Target::Knob(KnobId::Send(n()? as u16, n()? as u16)),
        "chanvol" => Target::Knob(KnobId::ChanVol(n()?)),
        "chanpan" => Target::Knob(KnobId::ChanPan(n()?)),
        "eq" => Target::Knob(KnobId::Eq(n()? as u16, n()? as u8, n()? as u8)),
        "fader" => Target::Fader(n()? as u16),
        "param" => Target::Param(n()?, n()?),
        "racktrack" => Target::RackTrack(n()?),
        "rackled" => Target::RackLed(n()?),
        "memberwet" | "memberdry" => Target::Member(n()? as u16, n()? as u8, n()? as u32, kind == "memberwet"),
        "memberparam" => Target::MemberParam(n()? as u16, n()? as u8, n()? as u32, n()?),
        _ => return None,
    })
}

/// `port|channel|controller|mode|formula|smoothing ms (0 = off)|omni|target`.
fn link_text(l: &Link) -> String {
    let mode = Mode::ALL.iter().position(|&m| m == l.mode).unwrap_or(0);
    let formula = Formula::ALL.iter().position(|&f| f == l.formula).unwrap_or(0);
    let port = l.port.map_or_else(|| "---".into(), |p| p.to_string());
    format!("{port}|{}|{}|{mode}|{formula}|{}|{}|{}", l.ch, l.cc, l.smooth.unwrap_or(0), u8::from(l.omni), target_text(l.target))
}

fn parse_link(s: &str) -> Option<Link> {
    let f: Vec<&str> = s.split('|').map(str::trim).collect();
    if f.len() != 8 {
        return None;
    }
    let smooth = f[5].parse::<u16>().ok()?;
    Some(Link {
        port: f[0].parse().ok(),
        ch: f[1].parse::<u8>().ok()?.min(15),
        cc: f[2].parse::<u8>().ok()?.min(127),
        mode: *Mode::ALL.get(f[3].parse::<usize>().ok()?)?,
        formula: *Formula::ALL.get(f[4].parse::<usize>().ok()?)?,
        smooth: (smooth > 0).then(|| smooth.clamp(SMOOTH_MIN, SMOOTH_MAX)),
        omni: f[6] == "1",
        target: parse_target(f[7])?,
    })
}

const KEY: &str = "midi_links";

/// The links kept (spec §5).
pub fn links() -> Vec<Link> {
    crate::settings_file::get(KEY).map(|v| v.split(';').filter_map(parse_link).collect()).unwrap_or_default()
}

pub fn set_links(l: &[Link]) {
    crate::settings_file::write(KEY, &l.iter().map(link_text).collect::<Vec<_>>().join(";"));
}

/// The link of target `t`, if it has one.
pub fn link_of(t: Target) -> Option<Link> {
    links().into_iter().find(|l| l.target == t)
}

/// Makes link `l`: it replaces the target's earlier link; with `remove_conflicts`, links of the same controller go too.
pub fn add(l: Link, remove_conflicts: bool) {
    let mut all = links();
    all.retain(|o| o.target != l.target && !(remove_conflicts && o.same_controller(&l)));
    all.push(l);
    set_links(&all);
}

pub fn remove(t: Target) {
    let mut all = links();
    all.retain(|o| o.target != t);
    set_links(&all);
}

/// A link's row in the browser's Remote control section (Lemon Studio's design: spec ui/browser.md "Current project
/// children"): what it drives, named with its owner as automation clips are ("Kick - Channel volume", "Bus 1 - To
/// Bus 2", "Lemon Reverb - Bus 3 - Mix"), then its controller as the Remote control settings box sets it ("channel 1,
/// ctrl 7"), and "omni" for one that drives the selected channel's knob.
pub fn label(s: &State, l: &Link) -> String {
    let channel = |r: usize| crate::views::browser::channel_label(s, r).unwrap_or_else(|| format!("Channel {}", r + 1));
    let name = crate::typein::target_name(s, l.target);
    let what = match l.target {
        Target::Knob(KnobId::ChanVol(r) | KnobId::ChanPan(r)) if !l.omni => format!("{} - {name}", channel(r)),
        Target::RackTrack(r) | Target::RackLed(r) => format!("{} - {name}", channel(r)),
        Target::Knob(KnobId::Send(a, _)) => format!("{} - {name}", crate::mixer::name(s, a)),
        Target::Param(key, index) => crate::params::clip_name(s, key, index),
        Target::MemberParam(m, k, id, index) => match crate::container::member_key(s, crate::container::place_key(m, k), id) {
            Some(key) => crate::params::clip_name(s, key, index),
            None => format!("{} - {name}", crate::container::place_name(s, m, k)),
        },
        _ => name,
    };
    let omni = if l.omni { ", omni" } else { "" };
    format!("{what}: channel {}, ctrl {}{omni}", l.ch + 1, l.cc)
}

/// The menu's Remote control part (spec §1): Link to controller..., Override global link... (greyed), and Remove link
/// for a linked target.
pub fn menu_items(t: Option<Target>) -> Vec<PItem> {
    let t = t.filter(|&t| linkable(t));
    let mut v = vec![
        PItem::head("Remote control"),
        match t {
            Some(t) => PItem::new("MIDI learn...", Cmd::Remote(RCmd::Link(t))),
            None => PItem::not_yet("MIDI learn..."),
        },
        PItem::new("Override global mapping...", Cmd::Nothing).off(),
    ];
    if let Some(t) = t.filter(|&t| link_of(t).is_some()) {
        v.push(PItem::new("Remove link", Cmd::Remote(RCmd::Unlink(t))));
    }
    v
}

/// The menu commands.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum RCmd {
    Link(Target),
    Unlink(Target),
    /// A plugin window menu's Link all parameters...: hosted instance key (spec §6).
    LinkAll(usize),
    /// Mixer options ▸ Link all parameters...: the mixer track's own controls (`track_targets`).
    LinkTrack(u16),
}

/// The Remote control settings box (spec §2, §3), while open.
#[derive(Debug, Clone, PartialEq)]
pub struct LinkBox {
    pub target: Target,
    /// Its top left.
    pub at: (f32, f32),
    pub port: Option<u8>,
    /// 0..15 (shown 1..16).
    pub ch: u8,
    pub cc: Option<u8>,
    pub auto: bool,
    pub omni: bool,
    pub mode: Mode,
    pub formula: Formula,
    pub smooth: bool,
    pub time: u16,
    pub conflicts: bool,
    /// Link all parameters... (spec §6): the instance's parameters, or a mixer track's controls (the mixer's Link all
    /// parameters..., Lemon Studio's design), to link in order to the controller set and the ones after it (`target`
    /// is the first); empty for a single link.
    pub all: Vec<Target>,
}

impl LinkBox {
    pub fn new(target: Target, at: (f32, f32)) -> LinkBox {
        let mut b = LinkBox {
            target,
            at,
            port: None,
            ch: 0,
            cc: None,
            auto: true,
            omni: false,
            mode: Mode::Default,
            formula: Formula::Input,
            smooth: false,
            time: SMOOTH_DEFAULT,
            conflicts: true,
            all: Vec::new(),
        };
        // An existing link opens with its settings.
        if let Some(l) = link_of(target) {
            b.port = l.port;
            b.ch = l.ch;
            b.cc = Some(l.cc);
            b.omni = l.omni;
            b.mode = l.mode;
            b.formula = l.formula;
            b.smooth = l.smooth.is_some();
            b.time = l.smooth.unwrap_or(SMOOTH_DEFAULT);
        }
        b
    }

    /// Reset: every field back to its default (spec §3).
    pub fn reset(&mut self) {
        *self = LinkBox { target: self.target, at: self.at, all: std::mem::take(&mut self.all), ..LinkBox::new_blank(self.target) };
    }

    fn new_blank(target: Target) -> LinkBox {
        LinkBox {
            target,
            at: (0.0, 0.0),
            port: None,
            ch: 0,
            cc: None,
            auto: true,
            omni: false,
            mode: Mode::Default,
            formula: Formula::Input,
            smooth: false,
            time: SMOOTH_DEFAULT,
            conflicts: true,
            all: Vec::new(),
        }
    }

    /// Link all parameters... of hosted instance `key` (spec §6): its visible parameters `params`, the box blank.
    pub fn all(key: usize, params: Vec<usize>, at: (f32, f32)) -> LinkBox {
        LinkBox::group(params.into_iter().map(|i| Target::Param(key, i)).collect(), at)
    }

    /// Link all parameters... over `targets` (at least one), the box blank.
    pub fn group(targets: Vec<Target>, at: (f32, f32)) -> LinkBox {
        let first = targets.first().copied().unwrap_or(Target::Param(0, 0));
        LinkBox { at, all: targets, ..LinkBox::new_blank(first) }
    }

    /// The links Accept makes: the one link, or for Link all parameters... one per parameter on the controller set and
    /// the ones after it, as far as controller 127 goes.
    pub fn links(&self) -> Vec<Link> {
        let Some(l) = self.link() else { return Vec::new() };
        if self.all.is_empty() {
            return vec![l];
        }
        self.all.iter().zip(l.cc..=127).map(|(&target, cc)| Link { cc, target, ..l }).collect()
    }

    /// The link it makes on Accept: none while Ctrl is "---".
    pub fn link(&self) -> Option<Link> {
        Some(Link {
            port: self.port,
            ch: self.ch,
            cc: self.cc?,
            mode: self.mode,
            formula: self.formula,
            smooth: self.smooth.then_some(self.time),
            omni: self.omni && omni_kind(self.target),
            target: self.target,
        })
    }
}

/// Targets Omni works for: a rack channel's knobs.
pub fn omni_kind(t: Target) -> bool {
    matches!(t, Target::Knob(KnobId::ChanVol(_) | KnobId::ChanPan(_)))
}

/// The box's parts (`Action::Remote`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum RAct {
    /// The panel (swallows clicks).
    Body,
    Close,
    Port,
    Channel,
    Ctrl,
    Auto,
    Omni,
    Mode,
    Formula,
    Smooth,
    Time,
    Conflicts,
    Reset,
    Accept,
}

impl RAct {
    /// A value box (the wheel and a vertical drag step it).
    pub fn is_value(self) -> bool {
        matches!(self, RAct::Port | RAct::Channel | RAct::Ctrl | RAct::Time)
    }
}

/// Multilink to controllers (spec §4): on, and the knobs changed since, in order.
#[derive(Debug, Default, Clone)]
pub struct Multi {
    pub on: bool,
    pub queue: VecDeque<Target>,
}

/// A link's state while the program runs.
#[derive(Debug, Clone, Copy, Default)]
struct Live {
    /// The value this link last gave its knob.
    set: Option<f32>,
    /// Its last mapped input.
    last_in: Option<f32>,
    /// Pickup: the controller has met the knob.
    engaged: bool,
    /// Smoothing: from, to, since, over.
    glide: Option<(f32, f32, Instant, Duration)>,
}

/// The links read from `settings.txt` and their live state.
#[derive(Debug, Default)]
pub struct Remote {
    links: Vec<Link>,
    live: Vec<Live>,
    /// The `midi_links` text `links` was read from.
    read: Option<String>,
}

impl Remote {
    /// The kept links, read again when `settings.txt`'s text changed.
    fn sync(&mut self) {
        let now = crate::settings_file::get(KEY);
        if self.read != now {
            self.links = links();
            self.live = vec![Live::default(); self.links.len()];
            self.read = now;
        }
    }

    /// A glide is running: the shell keeps ticking.
    pub fn busy(&self) -> bool {
        self.live.iter().any(|l| l.glide.is_some())
    }
}

/// A value close enough to another to count as it.
const NEAR: f32 = 1.0 / 127.0;

impl App {
    /// The knob a link drives now (Omni: the selected channel's).
    fn remote_target(&self, l: &Link) -> Target {
        match l.target {
            Target::Knob(KnobId::ChanVol(_)) if l.omni => Target::Knob(KnobId::ChanVol(self.state.selected_channel)),
            Target::Knob(KnobId::ChanPan(_)) if l.omni => Target::Knob(KnobId::ChanPan(self.state.selected_channel)),
            t => t,
        }
    }

    /// A controller message from device `dev` (spec §2-§5): the open box detects it, Multilink links it, the links it
    /// drives take it. Returns whether something took it (otherwise it goes to the instrument).
    pub(crate) fn remote_cc(&mut self, dev: &str, ch: u8, cc: u8, v: u8) -> bool {
        let port = crate::midi_cfg::input(dev).port;
        if let Some(b) = self.state.link_box.as_mut().filter(|b| b.auto) {
            b.port = port;
            b.ch = ch;
            b.cc = Some(cc);
            self.state.message = Some(format!("Detected: channel {}, controller {cc}", ch + 1));
            if crate::prefs::check(&crate::prefs::AUTO_ACCEPT) {
                self.link_accept();
            }
            self.invalidate();
            return true;
        }
        self.remote.sync();
        let hit: Vec<usize> = (0..self.remote.links.len()).filter(|&i| self.remote.links[i].hears(port, ch, cc)).collect();
        if hit.is_empty() && self.state.multilink.on {
            if let Some(t) = self.state.multilink.queue.pop_front() {
                let mut l = Link::new(ch, cc, t);
                l.port = port;
                add(l, true);
                self.remote.sync();
                let name = crate::typein::caption(&self.state, t);
                self.state.message = Some(format!("Linked channel {}, controller {cc} to {}", ch + 1, name.trim_start_matches("Value for ")));
                if self.state.multilink.queue.is_empty() {
                    self.state.multilink.on = false;
                }
                self.invalidate();
                return true;
            }
        }
        for i in hit.iter().copied() {
            self.remote_drive(i, v);
        }
        !hit.is_empty()
    }

    /// Link `i` gets controller value `v` (spec §5).
    fn remote_drive(&mut self, i: usize, v: u8) {
        let l = self.remote.links[i];
        let t = self.remote_target(&l);
        // A rack box's position over its travel (its track over the last insert, the LED 0 / 1), a knob's value.
        let now = crate::typein::position(&self.state, t).or_else(|| crate::typein::get(&self.state, t));
        let Some(now) = now.map(|x| x as f32) else { return };
        let x = l.formula.map(f32::from(v) / 127.0);
        let pressed = v > 0;
        let val = match l.mode {
            Mode::Default | Mode::Hold => x,
            Mode::Stay if !pressed => return,
            Mode::Stay => x,
            Mode::Latch if !pressed => return,
            Mode::Latch => {
                if now >= 0.5 { 0.0 } else { 1.0 }
            }
            Mode::Inc if !pressed => return,
            Mode::Inc => {
                let n = now + 1.0 / 16.0;
                if n > 1.0 + 1e-4 { 0.0 } else { n.min(1.0) }
            }
        };
        let live = &mut self.remote.live[i];
        // Pickup (takeover mode): after another change, nothing until the controller meets the knob.
        if crate::prefs::check(&crate::prefs::PICKUP) && matches!(l.mode, Mode::Default | Mode::Hold | Mode::Stay) {
            if live.set.is_none_or(|s| (s - now).abs() > 1e-4) {
                live.engaged = false;
            }
            if !live.engaged {
                let met = (val - now).abs() <= NEAR || live.last_in.is_some_and(|p| (p - now) * (val - now) <= 0.0);
                live.last_in = Some(val);
                if !met {
                    return;
                }
                live.engaged = true;
            }
        }
        live.last_in = Some(val);
        match l.smooth {
            Some(ms) => {
                live.glide = Some((now, val, Instant::now(), Duration::from_millis(u64::from(ms))));
            }
            None => {
                live.set = Some(val);
                self.remote_set(t, val);
            }
        }
    }

    /// The glides move on (spec §3 Smoothing).
    pub(crate) fn remote_tick(&mut self) {
        if !self.remote.busy() {
            return;
        }
        for i in 0..self.remote.live.len() {
            let Some((from, to, since, over)) = self.remote.live[i].glide else { continue };
            let k = (since.elapsed().as_secs_f32() / over.as_secs_f32().max(1e-3)).min(1.0);
            let v = from + (to - from) * k;
            if k >= 1.0 {
                self.remote.live[i].glide = None;
            }
            self.remote.live[i].set = Some(v);
            let t = self.remote_target(&self.remote.links[i]);
            self.remote_set(t, v);
        }
    }

    /// Sets the knob as a change of it with the mouse would: undoable (one step while the same knob keeps changing),
    /// recorded while recording automation.
    fn remote_set(&mut self, t: Target, v: f32) {
        let v = v.clamp(0.0, 1.0);
        match t {
            Target::Knob(k) => {
                crate::history::knob(&mut self.state, k, true);
                self.state.set_knob(k, v);
                self.record_knob(k);
            }
            Target::Fader(m) => {
                if let Some(tr) = crate::mixer::track_mut(&mut self.state, m) {
                    tr.volume = Some(f64::from(v));
                    self.state.piano.dirty = true;
                }
                self.record_control(&crate::app::Action::Fader(m));
            }
            Target::Param(key, index) => {
                crate::params::set_param_value(&mut self.state, key, index, f64::from(v));
                self.record_plugin_param(key, index, f64::from(v));
            }
            // An effect inside a container: its instance while it is loaded.
            Target::MemberParam(m, k, id, index) => {
                if let Some(key) = crate::container::member_key(&self.state, crate::container::place_key(m, k), id) {
                    crate::params::set_param_value(&mut self.state, key, index, f64::from(v));
                    self.record_plugin_param(key, index, f64::from(v));
                }
            }
            // A container member's level: one undo step while it keeps moving; recorded as its automation target.
            Target::Member(m, k, id, wet) => {
                crate::container::set_level_run(&mut self.state, m, k, id, wet, v);
                if let Some(target) = crate::container::level_target(&self.state, m, k, id, wet) {
                    self.record_param(target, (0.0, 1.0), f64::from(v));
                }
            }
            // One undo step for each track the box moves to, and each switch of the LED (`typein::set_value`).
            Target::RackTrack(_) | Target::RackLed(_) => {
                let to = crate::typein::at_position(&self.state, t, f64::from(v));
                crate::typein::set_value(&mut self.state, t, to);
            }
            // Never linked (no remote control).
            Target::Latency(..) => {}
        }
        self.invalidate();
    }

    /// A menu's Remote control command.
    pub(crate) fn remote_cmd(&mut self, c: RCmd) {
        match c {
            RCmd::Link(t) => {
                let (w, h) = crate::views::remote_box::SIZE;
                let (sw, sh) = self.state.screen;
                let at = ((self.mouse.0 - 20.0).clamp(0.0, (sw - w).max(0.0)), (self.mouse.1 - 20.0).clamp(0.0, (sh - h).max(0.0)));
                self.state.link_box = Some(LinkBox::new(t, at));
                self.state.message = Some("Just move your MIDI controller".into());
            }
            RCmd::Unlink(t) => {
                remove(t);
                self.state.message = Some("Link removed".into());
            }
            RCmd::LinkAll(key) => {
                self.params_tick();
                let params: Vec<usize> = self.state.params.visible(key).map(|(i, _)| i).collect();
                if params.is_empty() {
                    self.state.message = Some("This plugin has no parameters to link".into());
                    return self.invalidate();
                }
                let (w, h) = crate::views::remote_box::SIZE;
                let (sw, sh) = self.state.screen;
                let at = ((self.mouse.0 - 20.0).clamp(0.0, (sw - w).max(0.0)), (self.mouse.1 - 20.0).clamp(0.0, (sh - h).max(0.0)));
                // An effect inside a container links by its place and id (`params::link_target`).
                let targets = params.into_iter().map(|i| crate::params::link_target(&self.state, key, i)).collect();
                self.state.link_box = Some(LinkBox::group(targets, at));
                self.state.message = Some("Move the MIDI controller for the first parameter".into());
            }
            RCmd::LinkTrack(t) => {
                let targets = track_targets(&self.state, t);
                if targets.is_empty() {
                    return self.invalidate();
                }
                let (w, h) = crate::views::remote_box::SIZE;
                let (sw, sh) = self.state.screen;
                let at = ((self.mouse.0 - 20.0).clamp(0.0, (sw - w).max(0.0)), (self.mouse.1 - 20.0).clamp(0.0, (sh - h).max(0.0)));
                self.state.link_box = Some(LinkBox::group(targets, at));
                self.state.message = Some("Move the MIDI controller for the track's volume".into());
            }
        }
        self.invalidate();
    }

    /// Accept: makes the link and closes the box (spec §3).
    pub(crate) fn link_accept(&mut self) {
        let Some(b) = self.state.link_box.take() else { return };
        if !b.all.is_empty() {
            let made = b.links();
            for l in &made {
                add(*l, b.conflicts);
            }
            self.state.message = Some(match (made.first(), made.last()) {
                (Some(a), Some(z)) => format!(
                    "Linked {} parameters of {} to channel {}, controllers {} to {}",
                    made.len(),
                    group_name(&self.state, &b),
                    a.ch + 1,
                    a.cc,
                    z.cc
                ),
                _ => "No controller: nothing linked".into(),
            });
            return self.invalidate();
        }
        match b.link() {
            Some(l) => {
                add(l, b.conflicts);
                let name = crate::typein::caption(&self.state, b.target);
                self.state.message = Some(format!("Linked channel {}, controller {} to {}", l.ch + 1, l.cc, name.trim_start_matches("Value for ")));
            }
            None => self.state.message = Some("No controller: nothing linked".into()),
        }
        self.invalidate();
    }

    /// A click on the box.
    pub(crate) fn link_box_act(&mut self, a: RAct) {
        let Some(b) = self.state.link_box.as_mut() else { return };
        match a {
            RAct::Body | RAct::Port | RAct::Channel | RAct::Ctrl | RAct::Time => {}
            RAct::Close => self.state.link_box = None,
            RAct::Auto => b.auto = !b.auto,
            RAct::Omni => b.omni = !b.omni,
            RAct::Smooth => b.smooth = !b.smooth,
            RAct::Conflicts => b.conflicts = !b.conflicts,
            RAct::Reset => b.reset(),
            RAct::Accept => return self.link_accept(),
            RAct::Mode => {
                let i = Mode::ALL.iter().position(|&m| m == b.mode).unwrap_or(0);
                b.mode = Mode::ALL[(i + 1) % Mode::ALL.len()];
            }
            RAct::Formula => {
                let i = Formula::ALL.iter().position(|&f| f == b.formula).unwrap_or(0);
                b.formula = Formula::ALL[(i + 1) % Formula::ALL.len()];
            }
        }
        self.invalidate();
    }

    /// The wheel (or a drag) on one of the box's value boxes: `steps` up or down.
    pub(crate) fn link_box_step(&mut self, a: RAct, steps: i32) {
        let Some(b) = self.state.link_box.as_mut() else { return };
        let step = |v: Option<u8>, max: i32| -> Option<u8> {
            // "---" sits below 0.
            let n = v.map_or(-1, i32::from) + steps;
            (n >= 0).then(|| n.min(max) as u8)
        };
        match a {
            RAct::Port => b.port = step(b.port, 255),
            RAct::Ctrl => b.cc = step(b.cc, 127),
            RAct::Channel => b.ch = (i32::from(b.ch) + steps).clamp(0, 15) as u8,
            RAct::Time => b.time = (i32::from(b.time) + steps * 10).clamp(i32::from(SMOOTH_MIN), i32::from(SMOOTH_MAX)) as u16,
            _ => return,
        }
        self.invalidate();
    }

    /// Multilink to controllers switched (OPTIONS, Ctrl+J, the toolbar; spec §4).
    pub(crate) fn toggle_multilink(&mut self) {
        let m = &mut self.state.multilink;
        m.on = !m.on;
        m.queue.clear();
        self.state.message = Some(if m.on {
            "Multi MIDI learn: change the knobs to link, then move a controller for each, in the same order".into()
        } else {
            "Multi MIDI learn: off".into()
        });
        self.invalidate();
    }

    /// A knob changed with the mouse: Multilink queues it (once).
    pub(crate) fn multilink_knob(&mut self, t: Target) {
        let m = &mut self.state.multilink;
        if m.on && !m.queue.contains(&t) {
            m.queue.push_back(t);
            let name = crate::typein::caption(&self.state, t);
            let n = self.state.multilink.queue.len();
            self.state.message = Some(format!("MIDI learn {n}: {}", name.trim_start_matches("Value for ")));
        }
    }
}

/// What Link all parameters... links (the box's field, its hint): the plugin's name, or the mixer track's.
pub fn group_name(s: &State, b: &LinkBox) -> String {
    match b.target {
        Target::Param(key, _) => crate::params::owner_name(s, key),
        Target::MemberParam(m, k, id, _) => match crate::container::member_key(s, crate::container::place_key(m, k), id) {
            Some(key) => crate::params::owner_name(s, key),
            None => crate::container::place_name(s, m, k),
        },
        Target::Fader(t) => crate::mixer::name(s, t),
        t => crate::typein::caption(s, t).trim_start_matches("Value for ").to_string(),
    }
}

/// The mixer's Link all parameters... (Lemon Studio's design): track `t`'s own controls in the strip's order: volume,
/// pan, stereo separation, the equaliser's three bands (gain, frequency, width each), the send levels of its routes,
/// then the mix levels of its filled slots.
pub fn track_targets(s: &State, t: u16) -> Vec<Target> {
    let Some(track) = crate::mixer::track(s, t) else { return Vec::new() };
    let mut v = vec![Target::Fader(t), Target::Knob(KnobId::MixPan(t)), Target::Knob(KnobId::MixSep(t))];
    v.extend((0..3).flat_map(|b| (0..3).map(move |f| Target::Knob(KnobId::Eq(t, b, f)))));
    let mut routes: Vec<u16> = track.routes.iter().copied().filter(|&d| d != t).collect();
    routes.sort_unstable();
    routes.dedup();
    v.extend(routes.into_iter().map(|d| Target::Knob(KnobId::Send(t, d))));
    v.extend((0..10u8).filter(|&k| crate::mixer::slot_name(s, t, k).is_some()).map(|k| Target::Knob(KnobId::SlotMix(t, k))));
    v
}

/// Whether the box is open (it is modal).
pub fn is_open(s: &State) -> bool {
    s.link_box.is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn links_are_kept() {
        let mut l = Link::new(2, 21, Target::Knob(KnobId::ChanVol(3)));
        l.port = Some(4);
        l.mode = Mode::Inc;
        l.smooth = Some(250);
        let p = Link::new(0, 7, Target::Param(1, 12));
        add(l, true);
        add(p, true);
        assert_eq!(links(), vec![l, p]);
        // The same controller: the earlier link goes.
        let m = Link { target: Target::Fader(2), ..l };
        add(m, true);
        assert_eq!(links(), vec![p, m]);
        remove(Target::Param(1, 12));
        assert_eq!(links(), vec![m]);
        for t in [Target::Knob(KnobId::Eq(1, 2, 0)), Target::Knob(KnobId::Send(1, 0)), Target::Knob(KnobId::MasterPitch), Target::RackTrack(4), Target::RackLed(2)] {
            assert_eq!(parse_target(&target_text(t)), Some(t));
        }
        // The effects inside a container, by place and id (their hosted keys are the session's).
        for t in [Target::Member(3, 9, 15, true), Target::Member(0, 0, 1, false), Target::MemberParam(2, 4, 7, 1999)] {
            assert!(linkable(t));
            assert_eq!(parse_target(&target_text(t)), Some(t));
        }
        assert_eq!(target_text(Target::MemberParam(2, 4, 7, 19)), "memberparam:2:4:7:19");
    }

    /// VIEW > Remote control works: the browser on the Current project tab with its Remote control section open and
    /// selected, one row per link, named after what it drives and its controller.
    #[test]
    fn view_remote_control_lists_the_links() {
        use crate::views::browser::{rows, section_key, REMOTE_CONTROL};
        use crate::views::menus::{item_at, works, VIEW};
        let mut app = App::new(None);
        app.state.project = crate::app::test_project();
        set_links(&[]);
        add(Link::new(0, 7, Target::Knob(KnobId::ChanVol(1))), true);
        add(Link { omni: true, ..Link::new(1, 10, Target::Knob(KnobId::ChanPan(0))) }, true);
        add(Link::new(15, 74, Target::Fader(2)), true);
        let at = (0..40).find(|&i| item_at(VIEW, i).is_some_and(|it| it.label == "Remote control")).unwrap();
        assert!(works(VIEW, item_at(VIEW, at).unwrap()));
        app.state.show_browser = false;
        app.menu_item(VIEW, at);
        let key = section_key(REMOTE_CONTROL).unwrap();
        assert!(app.state.show_browser && app.state.browser_open.contains(&key) && app.state.browser_sel.as_ref() == Some(&key));
        let listed: Vec<String> = rows(&app.state).into_iter().filter(|r| r.key.starts_with(&format!("{key}/"))).map(|r| r.label).collect();
        let bus2 = crate::mixer::name(&app.state, 2);
        assert_eq!(listed, ["Clap - Channel volume: channel 1, ctrl 7".to_string(), "Channel panning: channel 2, ctrl 10, omni".into(), format!("{bus2} - Volume: channel 16, ctrl 74")]);
        set_links(&[]);
    }

    #[test]
    fn formulas() {
        assert_eq!(Formula::Inverted.map(0.25), 0.75);
        assert_eq!(Formula::Square.map(0.5), 0.25);
        assert_eq!(Formula::Root.map(0.25), 0.5);
    }

    /// Link all parameters... (spec §6): one link per parameter, on the controller set and the ones after it, as far as
    /// controller 127; Reset keeps the parameters.
    #[test]
    fn the_box_links_all_parameters() {
        let mut b = LinkBox::all(7, vec![0, 2, 3, 5], (0.0, 0.0));
        assert_eq!(b.target, Target::Param(7, 0));
        assert!(b.links().is_empty(), "no controller yet");
        b.cc = Some(20);
        b.ch = 1;
        let l = b.links();
        assert_eq!(l.iter().map(|l| (l.cc, l.target)).collect::<Vec<_>>(), [(20, Target::Param(7, 0)), (21, Target::Param(7, 2)), (22, Target::Param(7, 3)), (23, Target::Param(7, 5))]);
        assert!(l.iter().all(|l| l.ch == 1 && !l.omni));
        b.cc = Some(126);
        assert_eq!(b.links().len(), 2, "up to controller 127");
        b.reset();
        assert_eq!((b.cc, b.all.len()), (None, 4));
    }

    /// The mixer's Link all parameters... (Lemon Studio's design): the current track's volume, pan, separation, nine
    /// equaliser knobs, its sends and its filled slots' mix levels, linked on the first controller and the ones after it.
    #[test]
    fn the_mixer_links_a_tracks_controls() {
        use crate::playlist::Cmd;
        let mut app = App::new(None);
        app.state.project = crate::app::test_project();
        set_links(&[]);
        app.state.selected_mixer = 1;
        if let Some(t) = crate::mixer::track_mut(&mut app.state, 1) {
            t.routes = vec![2, 0];
        }
        let menu = crate::mixer::options_menu(&app.state, 0.0, 0.0);
        let item = menu.items.iter().find(|i| i.label == "Link all parameters...").unwrap();
        assert!(item.enabled);
        assert_eq!(item.cmd, Cmd::Remote(RCmd::LinkTrack(1)));
        crate::playlist::run(&mut app, item.cmd.clone());
        let b = app.state.link_box.clone().expect("the box");
        let mut want = vec![Target::Fader(1), Target::Knob(KnobId::MixPan(1)), Target::Knob(KnobId::MixSep(1))];
        want.extend((0..3).flat_map(|b| (0..3).map(move |f| Target::Knob(KnobId::Eq(1, b, f)))));
        want.extend([Target::Knob(KnobId::Send(1, 0)), Target::Knob(KnobId::Send(1, 2))]);
        want.extend((0..10u8).filter(|&k| crate::mixer::slot_name(&app.state, 1, k).is_some()).map(|k| Target::Knob(KnobId::SlotMix(1, k))));
        assert_eq!((b.target, &b.all), (Target::Fader(1), &want));
        // The controller moved: every control linked, controllers 20 and on.
        app.remote_cc("Test", 0, 20, 64);
        assert!(app.state.link_box.is_none(), "auto accepted");
        let made = links();
        assert_eq!(made.iter().map(|l| l.target).collect::<Vec<_>>(), want);
        assert_eq!(made.iter().map(|l| l.cc).collect::<Vec<_>>(), (20..20 + want.len() as u8).collect::<Vec<_>>());
        assert!(app.state.message.as_deref().is_some_and(|m| m.contains(&crate::mixer::name(&app.state, 1))), "{:?}", app.state.message);
        // The volume follows its controller.
        assert!(app.remote_cc("Test", 0, 20, 127));
        assert_eq!(crate::mixer::track(&app.state, 1).and_then(|t| t.volume), Some(1.0));
        set_links(&[]);
    }

    #[test]
    fn the_box_makes_its_link() {
        let mut b = LinkBox::new(Target::Knob(KnobId::ChanPan(0)), (0.0, 0.0));
        assert_eq!(b.link(), None, "no controller yet");
        b.cc = Some(10);
        b.omni = true;
        let l = b.link().unwrap();
        assert!(l.omni && l.cc == 10 && l.port.is_none());
        b.reset();
        assert_eq!(b.cc, None);
    }
}
