// Copyright (C) 2026 ItsAlphaNeon
// SPDX-License-Identifier: GPL-3.0-or-later
// This file is part of Lemon Studio: https://github.com/ItsAlphaNeon/Lemon-Studio

//! Lemon Studio's DSP building blocks, shared by the engine and Lemon Studio's own plugins: the arithmetic the engine
//! pages specify, at the precision they give, so that a project plays the way it was made.
//!
//! - [`level`]: the level curve, knob positions as products with a reciprocal, the constant-power pan split.
//! - [`glide`]: the per-block gain glide.
//! - [`mixer`]: a mixer track's fader matrix and its three-band equaliser.
//! - [`resample`]: the sampler's windowed-sinc resampler (table or exact weights).
//! - [`stretch`]: time stretching and pitch shifting (Signalsmith Stretch).
//! - [`articulator`]: a channel's envelopes and LFOs, stepped once per tick for every voice.
//! - [`channel_filter`]: the channel filter a voice runs through.
//! - [`tone`]: the spectral make-up of a sound's stretches, for colourful waveforms.
//! - [`transients`]: Lemon's transient detector and beat finder (auto slicing, Detect beats).
//! - [`pitch`]: Lemon's pitch tracker (YIN), for Tesla's Detect pitch regions.
//! - [`curve`]: Image-Line's curves (envelopes, LFOs, maps) as Citrus and Pulp Filter walk them.
//! - [`num`]: the plugin pages' arithmetic (`single( )`, Round, flushes) and a little-endian state reader.
//!
// spec: audio/conventions.md, audio/mixer.md, audio/sampler.md, audio/time-stretch.md, audio/envelopes-and-lfos.md,
// audio/channel-filter.md, plugins/image-line-curves.md, plugins/lemon-slicer.md §3

pub mod articulator;
pub mod channel_filter;
pub mod curve;
pub mod glide;
pub mod level;
pub mod mixer;
pub mod num;
pub mod pitch;
pub mod resample;
pub mod stretch;
pub mod tone;
pub mod transients;
