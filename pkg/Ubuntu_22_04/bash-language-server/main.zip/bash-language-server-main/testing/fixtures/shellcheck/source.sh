#!/bin/bash

# shellcheck source=shellcheck/sourced.sh
source ./sourced.sh

echo "$foo"
