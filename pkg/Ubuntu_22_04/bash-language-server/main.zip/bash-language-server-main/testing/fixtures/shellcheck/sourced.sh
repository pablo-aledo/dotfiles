#!/bin/bash
export foo=1
