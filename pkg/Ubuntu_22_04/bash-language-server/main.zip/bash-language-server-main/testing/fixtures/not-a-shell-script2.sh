#!/usr/bin/env python2.7
# set -x

def func():
  print 'hello world'
