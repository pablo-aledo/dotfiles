if this is not a shell script, then it should not be parsed

echo "Or is it?"

