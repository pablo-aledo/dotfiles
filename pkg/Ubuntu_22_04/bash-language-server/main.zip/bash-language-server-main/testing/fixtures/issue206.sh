readonly FOO=$1
readonly BAR=$UNDEFINED/$FOO
