. ./extension  # notice no file extension meaning it isn't found by the background analysis

echo "It resolves ${XXX} in the sourced file"
