export function isWindows() {
  return process.platform === 'win32'
}
