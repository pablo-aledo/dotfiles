# Bash Language Server

This folder holds the node server written in Typescript that implements the Language Server Protocol (LSP).
