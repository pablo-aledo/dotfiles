#ifndef OPENSPLAT_H
#define OPENSPLAT_H

#include "model.hpp"

#endif