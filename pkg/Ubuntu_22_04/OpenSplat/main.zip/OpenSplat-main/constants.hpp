#ifndef CONSTANTS_H
#define CONSTANTS_H

#define PI 3.14159265358979323846
#define FLOAT_EPS 1e-9f

#ifndef APP_VERSION
#define APP_VERSION "dev"
#endif

#ifndef APP_REVISION
#define APP_REVISION "dev"
#endif

#endif