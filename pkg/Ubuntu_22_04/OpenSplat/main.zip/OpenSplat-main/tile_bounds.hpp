#ifndef TILE_BOUNDS_H
#define TILE_BOUNDS_H

#include <tuple> 

typedef std::tuple<int, int, int> TileBounds; 

#endif