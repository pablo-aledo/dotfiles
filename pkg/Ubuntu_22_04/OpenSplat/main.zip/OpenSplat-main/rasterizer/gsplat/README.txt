This is a modified version of gsplat (https://github.com/nerfstudio-project/gsplat)

It is released under the AGPLv3 license. The original project is licensed under Apache2. 