//
//  AppDelegate.h
//  whisper.objc
//
//  Created by Georgi Gerganov on 23.10.22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

