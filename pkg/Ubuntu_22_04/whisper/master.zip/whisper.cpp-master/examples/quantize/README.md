# quantize

Tool for integer quantization of Whisper `ggml` model files
