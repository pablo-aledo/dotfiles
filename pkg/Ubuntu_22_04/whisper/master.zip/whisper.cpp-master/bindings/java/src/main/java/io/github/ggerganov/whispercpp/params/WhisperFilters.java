package io.github.ggerganov.whispercpp.params;

import java.util.List;

public class WhisperFilters {
    int n_mel;
    int n_fft;

    List<Float> data;
}
