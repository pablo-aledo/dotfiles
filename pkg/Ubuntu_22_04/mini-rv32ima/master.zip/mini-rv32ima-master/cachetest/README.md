# Cachetest (incomplete)

Playing with the idea of being able to have a cache, for systems where main system RAM access is slow.

