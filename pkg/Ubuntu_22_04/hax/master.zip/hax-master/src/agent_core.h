/* SPDX-License-Identifier: MIT */
#ifndef HAX_AGENT_CORE_H
#define HAX_AGENT_CORE_H

#include <stddef.h>

#include "provider.h"
#include "tool.h"

/* State and conversation-record bookkeeping shared by the interactive and one-shot frontends:
 * the canonical flat item log (struct agent_session) with its views and mutators, and the
 * helpers that keep the record consistent with its logs and background tasks. Anything here
 * must behave identically in both frontends and needs no live provider stream — provider
 * round-trips belong in agent_loop, presentation in the frontends. */

/* Synthetic history content used to keep interrupted or refused tool turns well formed. */
#define INTERRUPT_MARKER "[interrupted]"
#define REFUSED_RESULT   "error: tool calls are disabled in this session"
#define REFUSED_MARKER   "[refused: --raw, no tools advertised]"

/* Synthetic user text for an empty-send resume. Origin, not text, identifies continuations. */
#define CONTINUE_MARKER "[continue]"

struct hax_opts {
    int raw;                   /* send only user content and advertise no tools */
    const char *resume_path;   /* borrowed session path; NULL starts a new session */
    int provider_autoselected; /* show the one-shot provider-selection banner */
    int json;                  /* one-shot: stream conversation records as JSONL on stdout */
};

const struct tool *agent_find_tool(const char *name);

/* Return the configured provider id, or the live provider's borrowed name when unset. */
const char *agent_provider_id(const struct provider *provider);

/* Return agent_provider_id(), substituting "none" when no provider is selected. */
const char *agent_provider_log_name(const struct provider *provider);

/* Honor `no_session`; auto mode disables recording only for internal providers. */
int agent_recording_enabled(const struct provider *provider);

/* State shared by the interactive and one-shot frontends. String and vector fields are owned
 * except for provider_id, which remains valid only while the producing provider is alive. */
struct agent_session {
    char *model;       /* exact model id; NULL/empty when unresolved */
    char *model_label; /* display/environment label; NULL when model is NULL */
    char *effort;      /* NULL omits reasoning effort */
    /* Stable id stamped into reasoning provenance; never the configurable display name. */
    const char *provider_id;
    char *system_prompt;
    struct tool_def *tools;
    size_t n_tools;
    int raw_mode;

    /* The whole conversation, including prefixes a compaction has already summarized. */
    struct item *items;
    size_t n_items;
    size_t cap_items;
    /* Items /undo removed from the conversation, in their original order. They are no longer
     * context, but the requests they record were still served and paid for. */
    struct item *retired;
    size_t n_retired;
    size_t cap_retired;
    /* Wall time of completed user turns, as the session file records it. */
    long worked_ms;
    long last_user_turn_ms; /* -1 until a user turn completes */
};

/* Initialize a session. A missing model is valid so the interactive frontend can prompt for one. */
void agent_session_init(struct agent_session *session, struct provider *provider,
                        const struct hax_opts *opts);

/* Re-resolve request settings for `provider` without changing history or tools. Like startup, a
 * provider with no configured or default model leaves the model unset until one is chosen. */
void agent_session_reconfigure(struct agent_session *session, struct provider *provider);

/* Wait for model metadata and update cached effort. Returns true if it changed. `previous`, when
 * non-NULL, receives ownership of the replaced value; otherwise the old value is freed. */
int agent_session_resync_effort(struct agent_session *session, struct provider *provider,
                                char **previous);

void agent_session_free(struct agent_session *session);

/* Clear conversation items, retired items, and timing while preserving session settings and
 * item-vector capacity. */
void agent_session_reset(struct agent_session *session);

/* Move items[from, n_items) to the retired list and forget the last user turn's duration. */
void agent_session_retire(struct agent_session *session, size_t from);

struct session_loaded;

/* Replace the conversation, retired items, and timing with a loaded session file's, taking
 * ownership of its arrays and leaving its metadata for the caller. */
void agent_session_adopt(struct agent_session *session, struct session_loaded *loaded);

/* Record a completed user turn's wall time. */
void agent_session_add_worked(struct agent_session *session, long elapsed_ms);

/* Return a borrowed provider context, valid until the next session mutation. Items before the
 * newest compaction seed are excluded: compaction summarizes a prefix rather than discarding it,
 * so this is the only view that answers what the model sees. */
struct context agent_session_context(const struct agent_session *session);

/* Transfer ownership of `item` into the session. */
void agent_session_append(struct agent_session *session, struct item item);

/* Append a turn boundary followed by a copied user message. */
void agent_session_add_user(struct agent_session *session, const char *text);

/* Append the synthetic user turn used to resume an interrupted response. */
void agent_session_add_continuation(struct agent_session *session);

/* Append a boundary between provider round-trips in one user turn. */
void agent_session_add_boundary(struct agent_session *session);

/* Append an owned usage footer for one provider round-trip. `response` is the identity the
 * provider reported for it, or NULL when the footer stands in for no single stream. `origin` is
 * ITEM_ORIGIN_COMPACTION for a summarization request, whose window is not the conversation's. */
void agent_session_add_turn_usage(struct agent_session *session, const struct provider *provider,
                                  const struct stream_usage *usage, long elapsed_ms,
                                  const struct stream_response *response, enum item_origin origin);

/* Add an interrupt marker unless the latest content is an already-marked tool result. */
void agent_session_mark_interrupt(struct agent_session *session);

/* How a continuation without new user input speaks for the recorded tail. */
enum agent_resume_tail {
    AGENT_RESUME_TAIL_EMPTY,  /* no conversation to continue */
    AGENT_RESUME_TAIL_MARKED, /* abort repair stamped the tail: append a continuation message */
    AGENT_RESUME_TAIL_USER,   /* unanswered user message: re-send history as recorded */
    AGENT_RESUME_TAIL_CLEAN,  /* finished seam: continue it verbatim, owing a turn boundary */
};

enum agent_resume_tail agent_session_resume_tail(const struct agent_session *session);

struct session_log;
struct session_meta;
struct transcript_log;

/* What an adopted record leaves for the run continuing it. */
struct agent_resumed {
    struct session_log *session_log; /* owned; NULL unless recording reopened the file */
    enum agent_resume_tail tail;
    int compact_owed; /* the record ends over the compaction threshold: compact before sending */
};

/* Bind an adopted record at `path` to the run continuing it: reopen the file for appending when
 * recording is enabled, stage the live selection there, append the history to `transcript`,
 * settle model metadata, and read what the record's tail owes the run. `recorded` is the file's
 * own selection, against which the staged one reads as an override. Call after the provider is
 * final and before anything consults model metadata. */
void agent_session_prepare_resumed(struct agent_session *session, struct provider *provider,
                                   const char *path, const struct session_meta *recorded,
                                   struct transcript_log *transcript, struct agent_resumed *out);

/* Context-window size of the newest request a usage footer records in the model-visible
 * context, or -1 when none reports it. This is the recorded counterpart of a live run's
 * latest-usage snapshot, for continuation decisions such as compact-before-send; compaction's
 * own accounting, which describes the summarized request rather than the fresh seed's window,
 * is ignored. */
long agent_session_last_context_tokens(const struct agent_session *session);

/* Whether any footer that model metadata can price or bound reports input or output tokens:
 * live footers, inherited or not, and retired footers of this session's own turns. */
int agent_session_has_reported_usage(const struct agent_session *session);

struct turn;

struct agent_absorb_result {
    size_t items_from;
    int had_tool_call;
};

/* Transfer completed turn items into the session. The caller still owns and resets `turn`. */
struct agent_absorb_result agent_session_absorb(struct agent_session *session, struct turn *turn);

struct transcript_log;
struct session_log;

/* Record items both logs have not seen yet; NULL-safe on either log. */
void agent_flush_logs(struct transcript_log *tlog, struct session_log *slog,
                      const struct item *items, size_t n_items);

/* Resolve every uncollected background task into the conversation record — final status for
 * finished ones, killed-at-exit for the rest — flush the logs, and kill whatever still runs.
 * Tasks belong to the conversation that started them: call this before its record is replaced
 * or closed, so it never dangles on a "[detached as task ...]" report or advertises output the
 * shutdown destroys, and no completion is announced into an unrelated conversation. */
void agent_finalize_tasks(struct agent_session *session, struct transcript_log *tlog,
                          struct session_log *slog);

#endif /* HAX_AGENT_CORE_H */
