/* SPDX-License-Identifier: MIT */
#include "agent.h"

#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "agent_core.h"
#include "agent_dispatch.h"
#include "agent_loop.h"
#include "agent_stats.h"
#include "banner.h"
#include "catalog.h"
#include "compact.h"
#include "config.h"
#include "diag.h"
#include "file_mention.h"
#include "history.h"
#include "model_meta.h"
#include "paste_image.h"
#include "provider.h"
#include "select.h"
#include "session.h"
#include "slash.h"
#include "transcript.h"
#include "xalloc.h"
#include "render/disp.h"
#include "render/footer.h"
#include "render/markdown.h"
#include "render/render_ctx.h"
#include "system/clock.h"
#include "system/fs.h"
#include "system/locale.h"
#include "system/spawn.h"
#include "system/tempfiles.h"
#include "terminal/ansi.h"
#include "terminal/input.h"
#include "terminal/input_core.h"
#include "terminal/interrupt.h"
#include "terminal/notify.h"
#include "terminal/theme.h"
#include "terminal/ui.h"
#include "terminal/vt_resolve.h"
#include "terminal/width.h"
#include "tools/bash_process.h"
#include "tools/task_registry.h"

/* Use ASCII unless wcwidth() can measure the themed UTF-8 glyph correctly. */
static const char *build_prompt(char *buffer, size_t size)
{
    if (locale_have_utf8())
        snprintf(buffer, size, "%s" ANSI_BOLD "❯" ANSI_BOLD_OFF "%s ", theme_open(THEME_ACCENT),
                 theme_close(THEME_ACCENT));
    else
        snprintf(buffer, size, ANSI_BOLD ">" ANSI_BOLD_OFF " ");
    return buffer;
}

/* Raw ANSI goes in as zero-width controls, or it would commit a pending newline before the next
 * separator. */
static void md_emit_to_disp(const char *bytes, size_t byte_count, int is_raw, void *user)
{
    struct disp *disp = user;
    if (is_raw)
        disp_write_raw(disp, bytes, byte_count);
    else
        disp_write(disp, bytes, byte_count);
}

static int markdown_enabled(void)
{
    /* Cursor-addressed Markdown must never leak into piped output. */
    if (!isatty(fileno(stdout)))
        return 0;
    return config_bool("markdown");
}

static int reasoning_visible(void)
{
    return config_bool("show_reasoning");
}

void agent_display_refresh(struct agent_state *state)
{
    theme_init();
    struct render_ctx *render = state->render;
    render->show_reasoning = reasoning_visible();
    if (render->md) {
        md_free(render->md);
        render->md = NULL;
    }
    if (markdown_enabled())
        render->md = md_new(md_emit_to_disp, &render->disp, md_cols());
}

/* Show one summary per user turn: its duration, the latest context snapshot, and cumulative
 * session spend. Wrap only at segment boundaries to keep values intact. */
static void display_stats_line(struct render_ctx *render, const struct provider *provider,
                               const struct agent_session *session, long elapsed_ms)
{
    struct agent_stats stats;
    agent_stats_collect(session, 0, 0, provider, &stats);
    char segments[AGENT_STATS_MAX_SEGMENTS][AGENT_STATS_SEGMENT_LEN];
    int segment_count = agent_format_stats_segments(
        segments, stats.context_tokens, model_meta_context(provider, session->model), elapsed_ms,
        stats.total.spend, stats.total.spend_estimated);
    if (segment_count == 0)
        return;

    struct disp *disp = &render->disp;
    render_open_block(render);
    disp_write_ansi(disp, ANSI_DIM);

    /* Segment bytes equal columns; the separator occupies three display columns. */
    int width = display_width();
    int column = 0;
    for (int i = 0; i < segment_count; i++) {
        int segment_width = (int)strlen(segments[i]);
        if (column > 0) {
            if (column + 3 + segment_width > width) {
                disp_putc(disp, '\n');
                column = 0;
            } else {
                disp_printf(disp, " · ");
                column += 3;
            }
        }
        disp_printf(disp, "%s", segments[i]);
        column += segment_width;
    }
    disp_write_ansi(disp, ANSI_RESET);
    disp_putc(disp, '\n');
    disp_flush(disp);
}

/* Read on every paint, so Esc shows at once in every phase of a turn, tool runs included, and no
 * label change hides it. An abort implies a pause and ends the turn moments later. */
static const char *pause_label(void *user)
{
    (void)user;
    return interrupt_pause_requested() ? "pausing... (esc again to interrupt)" : NULL;
}

/* Curl wait/chunk hook for cancellation and the timer-driven retry label. */
static int agent_stream_tick(void *user)
{
    struct render_ctx *render = user;
    /* Before first content, a pause cancels at once; the loop maps the empty turn to a resumable
     * pause. */
    if (interrupt_pause_requested() && !render->stream.content_seen)
        return 1;
    render_update_retry_label(render);
    return interrupt_abort_requested();
}

static int render_on_event(const struct stream_event *event, void *user)
{
    struct render_ctx *render = user;
    struct disp *disp = &render->disp;

    if (event->kind != EV_RETRY)
        render_retry_end(render);

    /* Once output exists, a pause must preserve it by waiting for a turn seam. */
    if (event->kind == EV_TEXT_DELTA || event->kind == EV_REASONING_DELTA ||
        event->kind == EV_REASONING_ITEM || event->kind == EV_TOOL_CALL_START)
        render->stream.content_seen = 1;

    switch (event->kind) {
    case EV_TEXT_DELTA:
        render_text_delta(render, event->u.text_delta.text, strlen(event->u.text_delta.text));
        break;
    case EV_TOOL_CALL_START:
        render_tool_call_start(render, event->u.tool_call_start.name);
        break;
    case EV_REASONING_ITEM:
        render_reasoning_end(render);
        break;
    case EV_TOOL_CALL_END:
    case EV_TOOL_CALL_DELTA:
        /* No live display: tool calls render as a single block during dispatch so parallel calls
         * don't visually interleave. */
        break;
    case EV_REASONING_DELTA:
        render_reasoning_delta(render, event->u.reasoning_delta.text);
        break;
    case EV_RETRY:
        /* A mid-stream retry abandons any partially rendered output; the next attempt
         * re-streams the whole response. */
        render_stream_retry(render, event->u.retry.attempt, event->u.retry.max_attempts,
                            event->u.retry.delay_ms);
        break;
    case EV_PROGRESS:
        render_progress(render, event->u.progress.processed, event->u.progress.total,
                        event->u.progress.cache);
        break;
    case EV_DONE:
        disp_flush(disp);
        break;
    case EV_ERROR:
        /* Closing the render state flushes partial text before the error line. */
        render_open_block(render);
        disp_write_ansi(disp, theme_open(THEME_ERROR));
        disp_printf(disp, "[error: %s]", event->u.error.message);
        disp_write_ansi(disp, ANSI_RESET);
        disp_putc(disp, '\n');
        disp_flush(disp);
        break;
    }

    return 0;
}

/* Match interrupt_init()'s two-TTY gate; otherwise abnormal-exit restoration is not installed
 * and a hidden cursor could leak to the parent shell. */
static int cursor_supported(void)
{
    return isatty(STDIN_FILENO) && isatty(STDOUT_FILENO);
}

static void cursor_show(void)
{
    if (!cursor_supported())
        return;
    fputs(ANSI_CURSOR_SHOW, stdout);
    fflush(stdout);
}

static void cursor_hide(void)
{
    if (!cursor_supported())
        return;
    fputs(ANSI_CURSOR_HIDE, stdout);
    fflush(stdout);
}

/* Without -R, less prints SGR as the literal text "ESC[1m", and a $PAGER naming it routinely omits
 * the option. It goes directly after the command word: appending would hand it to the last stage
 * of a pipeline, or place it past a `--`. Repeating the user's own -R is harmless. */
static char *pager_with_color(const char *command)
{
    char *head = fs_shell_head(command);
    if (!head)
        return xstrdup(command);
    const char *name = strrchr(head, '/');
    name = name ? name + 1 : head;
    size_t head_end = strspn(command, " \t") + strlen(head);
    char *colored = strcmp(name, "less") == 0
                        ? xasprintf("%.*s -R%s", (int)head_end, command, command + head_end)
                        : xstrdup(command);
    free(head);
    return colored;
}

/* Fall back to `more` (passes SGR through) since minimal installs often lack less. A broken $PAGER
 * is an error, not a fallback trigger — silently substituting would hide it. Returns an allocated
 * command, or NULL after reporting why. */
static char *resolve_pager(void)
{
    static const char *const FALLBACKS[] = {"less", "more"};

    const char *configured = getenv("PAGER");
    if (configured && *configured) {
        if (fs_shell_head_resolves(configured))
            return pager_with_color(configured);
        ui_error("$PAGER (%s) not found — fix it, or unset it to use a fallback", configured);
        return NULL;
    }
    for (size_t i = 0; i < sizeof(FALLBACKS) / sizeof(FALLBACKS[0]); i++) {
        char *found = fs_which(FALLBACKS[i]);
        if (found) {
            free(found);
            return pager_with_color(FALLBACKS[i]);
        }
    }
    ui_error("no pager found — install less or set $PAGER");
    return NULL;
}

/* Probe before forking: `sh -c` on a missing pager exits 127 only after hax has already written
 * the content into a dead pipe. */
static int view_pager_open(struct spawn_pipe *pipe)
{
    char *pager = resolve_pager();
    if (!pager) {
        /* No disp in modal context; restore the block gap before the repainted prompt. */
        putchar('\n');
        return -1;
    }
    /* The conversation is arbitrary UTF-8: a pager that cannot decode it escapes the body itself,
     * not merely the decorations around it. */
    pager = spawn_shell_cmd_force_utf8(pager);
    /* Keep pager signals in the child; early pager exit must become EPIPE, not terminate hax. */
    int rc = spawn_pipe_open_write(pipe, pager);
    free(pager);
    return rc;
}

static char *capture_paste(void *user)
{
    (void)user;
    return paste_image_capture();
}

/* Bracketed paste bypasses the Ctrl-V hook, so convert file URIs in the body filter too. */
static char *filter_paste(const char *text, void *user)
{
    (void)user;
    return paste_image_uris_to_paths(text);
}

/* View callbacks borrow agent_run's live state so vector growth and provider replacement cannot
 * stale captured pointers. */
static void show_transcript_cb(void *user)
{
    const struct agent_state *state = user;
    struct spawn_pipe pager;
    if (view_pager_open(&pager) < 0)
        return;
    /* Only the model-visible window: a compacted prefix is what the seed stands in for. */
    struct context window = agent_session_context(state->session);
    transcript_render(pager.stream, window.system_prompt, window.tools, window.n_tools,
                      window.items, window.n_items);
    spawn_pipe_close(&pager);
}

/* Render history through a private context so paging cannot disturb live display state. Resolve
 * cursor-addressed output before starting the pager. Provider switches are not history items, so
 * the banner identifies the current selection. */
static void show_history_cb(void *user)
{
    const struct agent_state *state = user;
    const struct agent_session *session = state->session;
    struct render_ctx render = {.show_reasoning = reasoning_visible()};
    char *output = NULL;
    size_t output_len = 0;
    FILE *memory_stream = open_memstream(&output, &output_len);
    if (!memory_stream)
        return;
    render.disp.sink = memory_stream;
    if (markdown_enabled())
        render.md = md_new(md_emit_to_disp, &render.disp, md_cols());

    banner_identity(memory_stream, state->provider, session);
    /* Pager progress is byte-based, so include the prompt count when nonzero. */
    size_t prompts = agent_user_turn_count(session);
    struct banner_writer header;
    banner_open(&header, memory_stream);
    banner_put(&header, "", ANSI_DIM, ANSI_BOLD_OFF, "conversation");
    if (prompts > 0) {
        char count[32];
        snprintf(count, sizeof(count), "%zu prompt%s", prompts, prompts == 1 ? "" : "s");
        banner_put(&header, " · ", ANSI_DIM, ANSI_BOLD_OFF, count);
    }
    banner_close(&header);
    /* Direct banner writes leave one committed newline outside disp's bookkeeping. */
    disp_sync_external_line(&render.disp);

    if (session->n_items == 0) {
        render_open_block(&render);
        disp_write_ansi(&render.disp, ANSI_DIM);
        disp_printf(&render.disp, "(nothing in this conversation yet)");
        disp_write_ansi(&render.disp, ANSI_RESET);
        disp_putc(&render.disp, '\n');
    } else {
        history_render(&render, HISTORY_FULL, session->items, session->n_items, 0);
    }
    /* Flush the final Markdown tail before resolving terminal output. */
    render_set_mode(&render, RENDER_IDLE);
    disp_commit_newlines(&render.disp);
    md_free(render.md);
    disp_free(&render.disp);
    fclose(memory_stream);

    struct spawn_pipe pager;
    if (view_pager_open(&pager) == 0) {
        vt_resolve(output, output_len, pager.stream);
        spawn_pipe_close(&pager);
    }
    free(output);
}

void agent_apply_settings(struct agent_state *state, struct provider *provider,
                          enum apply_announce announce)
{
    struct agent_session *session = state->session;
    struct provider *previous_provider = state->provider;
    int provider_changed = provider != previous_provider;
    /* Snapshot the model before reconfigure overwrites it, to tell a real
     * /model change from a /provider or /effort apply that left it the same. */
    char *previous_model = session->model ? xstrdup(session->model) : NULL;
    agent_session_reconfigure(session, provider);
    agent_display_refresh(state);

    if (provider_changed) {
        state->provider = provider;
        if (previous_provider)
            previous_provider->destroy(previous_provider);
    }

    /* Provider identity affects probed metadata even when the model id is unchanged. */
    int model_changed =
        (previous_model == NULL) != (session->model == NULL) ||
        (previous_model && session->model && strcmp(previous_model, session->model) != 0);
    free(previous_model);
    if (provider_changed || model_changed)
        model_meta_refresh(provider, session->model);

    /* Reconfiguration rebuilds the system prompt, including its model-specific environment. */
    transcript_log_reset(state->transcript, session->system_prompt, session->tools,
                         session->n_tools);
    transcript_log_append(state->transcript, session->items, session->n_items);

    /* Metadata is staged until the next append, so unused selections stay out of the log. */
    session_log_set_meta(state->session_log, agent_provider_log_name(provider), session->model,
                         session->model_label, session->effort, config_str("preset"));

    if (announce == APPLY_SILENT)
        return;

    if (announce == APPLY_BANNER_WHEN_EMPTY && session->n_items == 0) {
        render_open_block(state->render);
        banner_print(provider, session);
        disp_sync_external_line(&state->render->disp); /* banner bypasses disp */
        fflush(stdout);
        return;
    }

    /* Selection notices are display-only; the model cannot act on them. */
    const char *model_label = session->model_label ? session->model_label : session->model;
    /* Include the stance because a preset can change more than provider and model. */
    const char *preset = config_str("preset");
    char *stance = (preset && *preset) ? xasprintf("[%s] ", preset) : xstrdup("");
    const char *provider_name = provider->name ? provider->name : "?";
    char *label;
    if (!model_label)
        label = xasprintf("switched to %s%s · no model — use /model", stance, provider_name);
    else if (session->effort)
        label = xasprintf("switched to %s%s · %s · %s", stance, provider_name, model_label,
                          session->effort);
    else
        label = xasprintf("switched to %s%s · %s", stance, provider_name, model_label);
    free(stance);

    render_open_block(state->render);
    disp_write_ansi(&state->render->disp, ANSI_DIM);
    disp_printf(&state->render->disp, "%s", label);
    disp_write_ansi(&state->render->disp, ANSI_RESET);
    disp_putc(&state->render->disp, '\n');
    disp_flush(&state->render->disp);
    free(label);
}

/* Swapping or cutting history invalidates both resumable state and compaction debt tied to the
 * old tail. */
static void clear_resume_state(struct agent_state *state)
{
    state->resume_reason = AGENT_RESUME_NONE;
    state->compaction_deferred = 0;
}

/* A resumed record can end mid-story; re-offer the empty-send continue its run lost with the
 * process. A clean tail is indistinguishable from a finished conversation, so only marked or
 * unanswered tails re-arm the affordance. */
static void apply_resumed(struct agent_state *state, const struct agent_resumed *resumed)
{
    clear_resume_state(state);
    state->session_log = resumed->session_log;
    switch (resumed->tail) {
    case AGENT_RESUME_TAIL_MARKED:
    case AGENT_RESUME_TAIL_USER:
        state->resume_reason = AGENT_RESUME_INTERRUPTED;
        break;
    case AGENT_RESUME_TAIL_CLEAN:
    case AGENT_RESUME_TAIL_EMPTY:
        break;
    }
    state->compaction_deferred = resumed->compact_owed;
}

/* Interactive front for agent_finalize_tasks: announce the stop before the kill. */
static void finalize_tasks(struct agent_state *state)
{
    size_t running_tasks = task_running_count();
    if (running_tasks > 0) {
        ui_note("stopping %zu running background task%s", running_tasks,
                running_tasks == 1 ? "" : "s");
        disp_sync_external_line(&state->render->disp);
    }
    agent_finalize_tasks(state->session, state->transcript, state->session_log);
}

void agent_new_conversation(struct agent_state *state)
{
    finalize_tasks(state);
    clear_resume_state(state);
    agent_session_reset(state->session);
    transcript_log_reset(state->transcript, state->session->system_prompt, state->session->tools,
                         state->session->n_tools);
    session_log_reset(state->session_log);
    /* Old-turn temporary files are unreachable after history is reset. Must follow the task
     * shutdown: unlinking a live task's advertised spool would leave its log path dangling. */
    tempfiles_cleanup();
    /* finalize_tasks' stop note consumed the dispatcher's separator; restore the blank line
     * before the banner (a no-op when nothing was printed). */
    disp_block_separator(&state->render->disp);
    banner_print(state->provider, state->session);
}

/* A pause or turn limit leaves no trace in the conversation, so only the prompt names it; an
 * interruption or provider error is already explained above. The prompt carries the empty-send
 * meaning, so slash-command output cannot scroll it away. */
static const char *resume_placeholder(enum agent_resume_reason reason)
{
    switch (reason) {
    case AGENT_RESUME_NONE:
        return NULL;
    case AGENT_RESUME_PAUSED:
        return "paused — enter to continue";
    case AGENT_RESUME_MAX_TURNS:
        return "max turns reached — enter to continue";
    case AGENT_RESUME_INTERRUPTED:
        return "enter to continue";
    case AGENT_RESUME_ERROR:
        return "enter to retry";
    }
    return NULL;
}

/* Ends every hard-interrupted user turn: a tool's own marker covers only its call, and collapsed or
 * undispatched calls draw none. */
static void render_interrupt_marker(struct render_ctx *render)
{
    render_open_block(render);
    disp_write_ansi(&render->disp, ANSI_DIM);
    disp_printf(&render->disp, "%s", INTERRUPT_MARKER);
    disp_write_ansi(&render->disp, ANSI_RESET);
    disp_putc(&render->disp, '\n');
    disp_flush(&render->disp);
}

/* Only typed prompts and compaction seeds render as replay anchors; continuations and task
 * notes would replay as an empty turn heading. */
static int is_replay_anchor(const struct item *item)
{
    return item->kind == ITEM_USER_MESSAGE &&
           (item->origin == ITEM_ORIGIN_NONE || item->origin == ITEM_ORIGIN_COMPACT_SEED);
}

/* Replay only the final visible user turn so restored context does not displace live history.
 * Anchor on its user item rather than a turn boundary because one prompt may span several model
 * turns. Non-interactive runs render no replay. */
static void replay_user_turn(struct render_ctx *render, const struct agent_session *session,
                             const char *heading, const struct provider *provider)
{
    if (session->n_items == 0 || !isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO))
        return;

    size_t anchor_index = 0;
    int anchor_found = 0;
    size_t earlier_count = 0;
    for (size_t i = session->n_items; i-- > 0;) {
        if (!is_replay_anchor(&session->items[i]))
            continue;
        if (!anchor_found) {
            anchor_index = i;
            anchor_found = 1;
        } else {
            earlier_count++;
        }
    }

    render_open_block(render);
    disp_write_ansi(&render->disp, ANSI_DIM);
    if (earlier_count > 0)
        disp_printf(&render->disp, "── %s · %zu earlier message%s · ctrl-o for full history ──",
                    heading, earlier_count, earlier_count == 1 ? "" : "s");
    else
        disp_printf(&render->disp, "── %s · ctrl-o for full history ──", heading);
    disp_write_ansi(&render->disp, ANSI_RESET);
    disp_putc(&render->disp, '\n');

    if (anchor_found)
        history_render(render, HISTORY_BRIEF, session->items, session->n_items, anchor_index);

    /* Markdown may leave its final row open; terminate it before returning to the prompt. */
    render_set_mode(render, RENDER_IDLE);
    if (render->disp.committed_newlines == 0 && render->disp.pending_newlines == 0)
        disp_putc(&render->disp, '\n');
    disp_commit_newlines(&render->disp);
    disp_flush(&render->disp);
    /* A resumed screen ends as the original did, with the last user turn's stats. */
    if (provider)
        display_stats_line(render, provider, session, session->last_user_turn_ms);
}

void agent_resume_session(struct agent_state *state, const char *path)
{
    /* Claim activity before reading; another process may run the daily sweep concurrently. */
    (void)session_touch(path);
    struct agent_session *session = state->session;
    struct session_loaded loaded;
    if (session_load_all(path, &loaded) != 0) {
        session_loaded_free(&loaded);
        ui_error("could not read session");
        /* Replace the picker's stale newline count with the error line's committed newline. */
        disp_sync_external_line(&state->render->disp);
        return;
    }

    /* Resolve tasks into the conversation being left while its logs still record it. */
    finalize_tasks(state);

    /* Close the prior log before restoring settings so it cannot record the switch. */
    session_log_close(state->session_log);
    state->session_log = NULL;

    /* Restore settings before swapping history so announcements are framed against the
     * conversation being left and new logs use the restored system prompt and model. */
    select_restore_session(state, loaded.meta.provider, loaded.meta.model, loaded.meta.effort,
                           loaded.meta.preset);

    /* Keep tracked temporary files when replacing history; resumable branches may share paths. */
    agent_session_adopt(session, &loaded);
    transcript_log_reset(state->transcript, session->system_prompt, session->tools,
                         session->n_tools);
    struct agent_resumed resumed;
    agent_session_prepare_resumed(session, state->provider, path, &loaded.meta, state->transcript,
                                  &resumed);
    session_loaded_free(&loaded);
    apply_resumed(state, &resumed);
    replay_user_turn(state->render, session, "resumed", state->provider);
}

static int turn_item_index(const struct agent_session *session, size_t turn_index,
                           size_t *item_index_out)
{
    size_t turns_seen = 0;
    for (size_t i = 0; i < session->n_items; i++) {
        if (item_is_typed_prompt(&session->items[i])) {
            if (turns_seen == turn_index) {
                *item_index_out = i;
                return 0;
            }
            turns_seen++;
        }
    }
    return -1;
}

size_t agent_user_turn_count(const struct agent_session *session)
{
    size_t count = 0;
    for (size_t i = 0; i < session->n_items; i++)
        if (item_is_typed_prompt(&session->items[i]))
            count++;
    return count;
}

const char *agent_user_turn_text(const struct agent_session *session, size_t turn_index)
{
    size_t item_index;
    if (turn_item_index(session, turn_index, &item_index) != 0)
        return NULL;
    return session->items[item_index].text;
}

/* Shared tail of /undo and /fork. `cut_index` is the item truncation point; `turn_index`
 * identifies the first discarded prompt to stage for recall. An undo retires the cut items, whose
 * requests this session still paid for; a fork leaves them to the source session. */
static void reshape_after_cut(struct agent_state *state, size_t cut_index, size_t turn_index,
                              const char *heading, int retire)
{
    struct agent_session *session = state->session;
    clear_resume_state(state);

    /* Capture recall text before freeing the discarded item. */
    const char *recall_text = agent_user_turn_text(session, turn_index);
    free(state->pending_recall);
    state->pending_recall = recall_text ? xstrdup(recall_text) : NULL;

    if (retire) {
        agent_session_retire(session, cut_index);
    } else {
        for (size_t i = cut_index; i < session->n_items; i++)
            item_free(&session->items[i]);
        session->n_items = cut_index;
    }

    transcript_log_reset(state->transcript, session->system_prompt, session->tools,
                         session->n_tools);
    transcript_log_append(state->transcript, session->items, session->n_items);
    /* Cleanup is all-or-nothing, and the retained prefix may still reference tracked files. */
    replay_user_turn(state->render, session, heading, NULL);
}

void agent_undo(struct agent_state *state, size_t turn_index)
{
    struct agent_session *session = state->session;
    size_t cut_index;
    if (turn_item_index(session, turn_index, &cut_index) != 0)
        return;
    if (cut_index > 0 && session->items[cut_index - 1].kind == ITEM_TURN_BOUNDARY)
        cut_index--;

    size_t removed_turns = agent_user_turn_count(session) - turn_index;

    /* Record the cut before applying it; on I/O failure bail with history intact, or the file
     * would keep the old branch as live and the next append would extend it. */
    if (session_log_undo(state->session_log, turn_index, cut_index) != 0) {
        ui_error("could not record the undo in the session file; conversation left unchanged");
        disp_sync_external_line(&state->render->disp);
        return;
    }

    char heading[64];
    snprintf(heading, sizeof(heading), "undid %zu user turn%s", removed_turns,
             removed_turns == 1 ? "" : "s");
    reshape_after_cut(state, cut_index, turn_index, heading, 1);
}

void agent_fork(struct agent_state *state, size_t turn_index)
{
    struct agent_session *session = state->session;
    size_t cut_index;
    if (turn_index >= agent_user_turn_count(session)) {
        cut_index = session->n_items;
    } else {
        if (turn_item_index(session, turn_index, &cut_index) != 0)
            return;
        if (cut_index > 0 && session->items[cut_index - 1].kind == ITEM_TURN_BOUNDARY)
            cut_index--;
    }

    /* Without a materialized log, fork cannot preserve the original branch. */
    if (!session_log_materialized(state->session_log)) {
        ui_error("/fork needs session recording (it is disabled or unavailable)");
        disp_sync_external_line(&state->render->disp);
        return;
    }

    const char *source_path = session_log_path(state->session_log);
    /* The branch continues from the live selection, whatever the copied prefix ran under. */
    struct session_header selection = {
        .provider = agent_provider_log_name(state->provider),
        .model = session->model,
        .model_label = session->model_label,
        .effort = session->effort,
        .preset = config_str("preset"),
    };
    char *new_path = NULL;
    if (session_fork_file(source_path, session->items, cut_index, &selection, &new_path) != 0) {
        ui_error("could not create fork");
        disp_sync_external_line(&state->render->disp);
        return;
    }
    /* Open the new logger before closing the old one so failure is atomic. */
    struct session_log *new_session_log =
        session_log_resume(new_path, selection.provider, selection.model, selection.effort,
                           selection.preset, cut_index);
    if (!new_session_log) {
        unlink(new_path);
        free(new_path);
        ui_error("could not open the fork session file; conversation left unchanged");
        disp_sync_external_line(&state->render->disp);
        return;
    }
    session_log_set_meta(new_session_log, agent_provider_log_name(state->provider), session->model,
                         session->model_label, session->effort, config_str("preset"));
    free(new_path);
    session_log_close(state->session_log);
    state->session_log = new_session_log;

    /* The branch reads the copied prefix but the source paid for it, and what the source undid
     * or spent is not the branch's record. */
    for (size_t i = 0; i < cut_index; i++)
        session->items[i].inherited = 1;
    for (size_t i = 0; i < session->n_retired; i++)
        item_free(&session->retired[i]);
    session->n_retired = 0;
    session->worked_ms = 0;
    session->last_user_turn_ms = -1;
    reshape_after_cut(state, cut_index, turn_index, "forked", 0);
}

/* Compaction has no pause seam, so either interrupt cancels the retriable transaction. */
static int compact_tick(void *user)
{
    return agent_stream_tick(user) || interrupt_pause_requested();
}

static int compact_cancelled(void *user)
{
    (void)user;
    interrupt_resolve_pending_escape();
    return interrupt_abort_requested() || interrupt_pause_requested();
}

static void compact_notice(struct render_ctx *render, const char *format, ...)
{
    va_list args;
    char message[256];
    va_start(args, format);
    vsnprintf(message, sizeof(message), format, args);
    va_end(args);
    render_open_block(render);
    disp_write_ansi(&render->disp, ANSI_DIM);
    disp_printf(&render->disp, "── %s ──", message);
    disp_write_ansi(&render->disp, ANSI_RESET);
    disp_putc(&render->disp, '\n');
    disp_flush(&render->disp);
}

/* As agent_compact(), but leaves the status row up for the work that follows. */
static int compact_conversation(struct agent_state *state, const char *instructions, int automatic)
{
    struct agent_session *session = state->session;
    struct provider *provider = state->provider;
    struct render_ctx *render = state->render;

    if (!provider) {
        if (!automatic)
            compact_notice(render, "no provider selected — use /provider");
        return 0;
    }
    if (!session->model || !*session->model) {
        if (!automatic)
            compact_notice(render, "no model selected — use /model (or /provider)");
        return 0;
    }
    if (session->n_items == 0) {
        if (!automatic)
            compact_notice(render, "nothing to compact");
        return 0;
    }

    render_set_mode(render, RENDER_IDLE);
    /* Before the status row shows, so it never paints another label first, nor a pause left from
     * an earlier turn. */
    footer_set_label(render->footer, "compacting", "compacting...");
    interrupt_clear_requests();
    interrupt_arm();
    render_stream_begin(render);
    struct compact_params params = {
        .session = session,
        .provider = provider,
        .session_log = state->session_log,
        .transcript_log = state->transcript,
        .instructions = instructions,
        .hooks =
            {
                .user = render,
                .tick = compact_tick,
                .is_cancelled = compact_cancelled,
            },
    };

    struct compact_result result;
    compact_run(&params, &result);
    interrupt_disarm();
    /* Release the held label. */
    footer_set_label(render->footer, "working", "working...");

    int compacted = result.outcome == COMPACT_COMPLETE;
    /* Any successful compaction — manual included — settles a deferred end-of-turn pass: the
     * oversized history it referred to is gone. */
    if (compacted)
        state->compaction_deferred = 0;
    /* Manual compaction moves the model past the resumable tail; retract the empty-send offer. */
    if (compacted && !automatic)
        clear_resume_state(state);
    switch (result.outcome) {
    case COMPACT_COMPLETE:
        compact_notice(render, "conversation compacted");
        break;
    case COMPACT_CANCELLED:
        compact_notice(render, "compaction cancelled");
        break;
    case COMPACT_PROVIDER_ERROR:
        compact_notice(render, "compaction failed: %s",
                       result.error_message ? result.error_message : "stream failed");
        break;
    case COMPACT_NO_SUMMARY:
        compact_notice(render, "compaction produced no summary");
        break;
    case COMPACT_NO_PROVIDER:
        if (!automatic)
            compact_notice(render, "no provider selected — use /provider");
        break;
    case COMPACT_NO_MODEL:
        if (!automatic)
            compact_notice(render, "no model selected — use /model (or /provider)");
        break;
    case COMPACT_EMPTY:
        if (!automatic)
            compact_notice(render, "nothing to compact");
        break;
    }
    compact_result_destroy(&result);
    return compacted;
}

int agent_compact(struct agent_state *state, const char *instructions, int automatic)
{
    int compacted = compact_conversation(state, instructions, automatic);
    render_finish(state->render);
    return compacted;
}

struct repl_loop_ctx {
    struct agent_state *state;
};

static int repl_loop_on_event(const struct stream_event *event, void *user)
{
    struct repl_loop_ctx *ctx = user;
    return render_on_event(event, ctx->state->render);
}

static int repl_loop_tick(void *user)
{
    struct repl_loop_ctx *ctx = user;
    return agent_stream_tick(ctx->state->render);
}

static void repl_loop_turn_begin(void *user)
{
    struct repl_loop_ctx *ctx = user;
    render_stream_begin(ctx->state->render);
}

static int repl_loop_checkpoint(void *user)
{
    (void)user;
    interrupt_resolve_pending_escape();
    if (interrupt_abort_requested())
        return AGENT_LOOP_SIG_ABORT;
    if (interrupt_pause_requested())
        return AGENT_LOOP_SIG_PAUSE;
    return AGENT_LOOP_SIG_NONE;
}

static struct item repl_loop_tool_call(const struct item *call, enum agent_loop_tool_action action,
                                       int image_input, void *user)
{
    struct repl_loop_ctx *ctx = user;
    struct render_ctx *render = ctx->state->render;
    if (action == AGENT_LOOP_TOOL_REFUSE) {
        render_set_mode(render, RENDER_IDLE);
        return dispatch_tool_refused(render, call);
    }
    if (action == AGENT_LOOP_TOOL_SKIP) {
        render_set_mode(render, RENDER_IDLE);
        return dispatch_tool_skipped(render, call);
    }
    return dispatch_tool_call(render, call, image_input);
}

static void repl_loop_compact(void *user)
{
    struct repl_loop_ctx *ctx = user;
    compact_conversation(ctx->state, NULL, 1);
    /* Preserve cancellation for the loop checkpoint; otherwise re-arm after compaction. */
    if (!interrupt_abort_requested() && !interrupt_pause_requested()) {
        interrupt_clear_requests();
        interrupt_arm();
    }
}

static void repl_loop_task_note(const char *text, void *user)
{
    struct repl_loop_ctx *ctx = user;
    struct render_ctx *render = ctx->state->render;
    render_open_block(render);
    disp_write_ansi(&render->disp, ANSI_DIM);
    disp_write(&render->disp, text, strlen(text));
    disp_write_ansi(&render->disp, ANSI_RESET);
    disp_putc(&render->disp, '\n');
    disp_flush(&render->disp);
}

static char *slash_hint_cb(const char *buf, void *user)
{
    (void)user;
    return slash_hint(buf);
}

static int handle_slash_input(struct input *input, struct agent_state *state, const char *line)
{
    if (!*line)
        return 0;

    if (slash_dispatch(line, state) == SLASH_NOT_A_COMMAND)
        return 0;

    input_history_add_session(input, line);
    if (state->pending_recall) {
        input_history_add_session(input, state->pending_recall);
        free(state->pending_recall);
        state->pending_recall = NULL;
    }
    if (state->pending_preseed) {
        input_set_preseed(input, state->pending_preseed);
        free(state->pending_preseed);
        state->pending_preseed = NULL;
    }
    return 1;
}

static void set_resume_state(struct agent_state *state, const struct agent_loop_result *result)
{
    switch (result->outcome) {
    case AGENT_LOOP_COMPLETE:
        clear_resume_state(state);
        return;
    case AGENT_LOOP_PAUSED:
        state->resume_reason = AGENT_RESUME_PAUSED;
        return;
    case AGENT_LOOP_MAX_TURNS:
        state->resume_reason = AGENT_RESUME_MAX_TURNS;
        return;
    case AGENT_LOOP_INTERRUPTED:
        state->resume_reason = AGENT_RESUME_INTERRUPTED;
        return;
    case AGENT_LOOP_PROVIDER_ERROR:
        state->resume_reason = AGENT_RESUME_ERROR;
        return;
    }
}

int agent_run(struct provider **provider_io, const struct hax_opts *options)
{
    /* Slash handlers replace state.provider; resynchronize this local after each dispatch and
     * return the final live provider to the caller. */
    struct provider *current_provider = *provider_io;
    struct agent_session session;
    agent_session_init(&session, current_provider, options);

    /* Recording controls new session and prompt-history writes, not reads. Mid-run resume
     * re-evaluates it after restoring the provider. */
    int recording_enabled = agent_recording_enabled(current_provider);

    /* Load resumed history before initializing dependent views and logs. An unreadable file is
     * fatal because starting fresh would use the wrong context. The record's own selection
     * stays loaded until the log is bound; flags may have overridden it. */
    struct session_loaded loaded = {0};
    if (options->resume_path) {
        if (session_load_all(options->resume_path, &loaded) != 0) {
            hax_err("could not resume session '%s'", options->resume_path);
            agent_session_free(&session);
            return 1;
        }
        agent_session_adopt(&session, &loaded);
    }

    putchar('\n');
    banner_print(current_provider, &session);
    /* The embedded disp outlives its Markdown callback; spinner and Markdown handles are owned
     * by this frame. */
    struct render_ctx render = {.disp = {.sink = stdout, .committed_newlines = 1},
                                .show_reasoning = reasoning_visible()};
    render.footer = footer_new("working...");
    footer_attach(render.footer, &render.disp);
    footer_set_label_override(render.footer, pause_label, NULL);
    render.md = markdown_enabled() ? md_new(md_emit_to_disp, &render.disp, md_cols()) : NULL;
    /* Transcript logging is optional; its API is NULL-safe. */
    struct transcript_log *transcript =
        transcript_log_open(session.system_prompt, session.tools, session.n_tools);
    /* Slash handlers borrow this frame. Keep the session log on state because /resume can replace
     * and close it mid-run. */
    struct agent_state state = {.session = &session,
                                .provider = current_provider,
                                .transcript = transcript,
                                .render = &render};
    if (options->resume_path) {
        struct agent_resumed resumed;
        agent_session_prepare_resumed(&session, current_provider, options->resume_path,
                                      &loaded.meta, transcript, &resumed);
        session_loaded_free(&loaded);
        apply_resumed(&state, &resumed);
        replay_user_turn(&render, &session, "resumed", current_provider);
    } else if (recording_enabled) {
        state.session_log =
            session_log_open(agent_provider_log_name(current_provider), session.model,
                             session.model_label, session.effort, config_str("preset"));
    }
    struct input *input = input_new();
    /* Prompt recall is scoped like sessions and remains readable when recording is disabled. */
    char *cwd = getcwd(NULL, 0);
    char *history_path = session_prompt_history_path(cwd);
    input_history_open_tty(input, history_path, recording_enabled);
    free(history_path);
    free(cwd);
    struct input_completer slash_completer;
    slash_completer_init(&slash_completer, &state);
    input_add_completer(input, &slash_completer);
    input_add_completer(input, &file_mention_completer);
    input_set_hint(input, slash_hint_cb, NULL);
    input_set_paste_hook(input, capture_paste, NULL);
    input_set_paste_filter(input, filter_paste, NULL);
    /* Raw mode clears IEXTEN, so Ctrl-O does not trigger BSD/macOS VDISCARD. */
    input_bind_modal_key(input, INPUT_KEY_CTRL('O'), show_history_cb, &state);
    input_bind_modal_key(input, INPUT_KEY_CTRL('T'), show_transcript_cb, &state);
    /* Capture terminal state before raw input; non-TTY initialization is a no-op. */
    interrupt_init();
    interrupt_set_fatal_signal_hook(bash_shell_pgids_kill);

    char prompt_buffer[64];

    for (;;) {
        disp_block_separator(&render.disp);
        /* Only a resumable turn gives an empty send a meaning; otherwise
         * the editor keeps swallowing bare Enter. */
        input_set_empty_submit(input, resume_placeholder(state.resume_reason));
        cursor_show();
        /* Rebuilt each iteration so a runtime theme change (/config theme …)
         * recolors the prompt instead of keeping the startup theme's bytes. */
        char *line = input_readline(input, build_prompt(prompt_buffer, sizeof(prompt_buffer)));
        cursor_hide();
        if (!line) {
            putchar('\n');
            break;
        }
        /* Empty input continues only resumable turns. */
        if (!*line && state.resume_reason == AGENT_RESUME_NONE) {
            free(line);
            continue;
        }

        /* An empty send erased its prompt row, so the separator above it still stands. Slash
         * handlers may override this when they drive the display themselves. */
        if (*line)
            disp_sync_external_line(&render.disp);
        if (handle_slash_input(input, &state, line)) {
            current_provider = state.provider;
            free(line);
            continue;
        }
        if (*line)
            input_history_add(input, line);

        /* Provider absence takes precedence over a possibly configured model. */
        if (!current_provider) {
            /* ui_note bypasses disp, so record its committed newline. */
            disp_block_separator(&render.disp);
            ui_note("no provider selected — use /provider to choose one, then resend");
            disp_sync_external_line(&render.disp);
            free(line);
            continue;
        }

        /* Keep unresolved-model prompts recallable while directing the user to a selector. */
        if (!session.model || !*session.model) {
            disp_block_separator(&render.disp);
            ui_note("no model selected — use /model (or /provider) to choose one, then resend");
            disp_sync_external_line(&render.disp);
            free(line);
            continue;
        }

        /* Settle deferred compaction before appending steering input or sending another oversized
         * request. */
        if (state.compaction_deferred) {
            agent_compact(&state, NULL, 1);
            /* A newly latched interrupt belongs to compaction and cancels the whole send; retain
             * the debt for the next attempt. */
            if (interrupt_abort_requested() || interrupt_pause_requested()) {
                free(line);
                continue;
            }
            /* Settled on success (agent_compact clears the flag), attempted
             * on failure: either way, don't retry ahead of every send. */
            state.compaction_deferred = 0;
        }

        int continued = 0;
        /* Boundaries precede fresh prompts. An empty send asks the recorded tail how to
         * continue, so a compaction seed just appended above supersedes an older marker. */
        if (*line) {
            agent_session_add_user(&session, line);
        } else {
            switch (agent_session_resume_tail(&session)) {
            case AGENT_RESUME_TAIL_MARKED:
                agent_session_add_continuation(&session);
                break;
            case AGENT_RESUME_TAIL_USER:
                break; /* the recorded prompt is unanswered; re-send history as-is */
            case AGENT_RESUME_TAIL_CLEAN:
            case AGENT_RESUME_TAIL_EMPTY:
                continued = 1;
                break;
            }
        }
        free(line);

        /* A background metadata probe may refine effort before the first request; announce the
         * value that will actually be sent. */
        char *previous_effort = NULL;
        if (agent_session_resync_effort(&session, current_provider, &previous_effort)) {
            disp_block_separator(&render.disp);
            ui_note("effort %s → %s · %s", previous_effort ? previous_effort : "(unset)",
                    session.effort ? session.effort : "(unset)",
                    session.model_label ? session.model_label : "?");
            disp_sync_external_line(&render.disp);
        }
        free(previous_effort);
        /* Stage the final pre-request selection; an already-written header is unaffected. */
        session_log_set_meta(state.session_log, agent_provider_log_name(current_provider),
                             session.model, session.model_label, session.effort,
                             config_str("preset"));
        /* Persist the prompt before entering a provider call that may hang or be interrupted. */
        agent_flush_logs(transcript, state.session_log, session.items, session.n_items);

        /* The effort resync above normally started the catalog refresh; this covers a provider
         * whose metadata path did not need it, and warns once about stale data at the first
         * request whose estimates it may distort. */
        model_meta_prefetch(current_provider);
        long stale_days = catalog_stale_days();
        if (stale_days > 0) {
            disp_block_separator(&render.disp);
            ui_note("model catalog last refreshed %ld days ago — cost estimates may be stale",
                    stale_days);
            disp_sync_external_line(&render.disp);
        }

        /* Each request subsumes the prior prefix, so the latest reported usage is the current
         * window state. -1 means no request reported it. */
        long user_turn_context_tokens = -1;
        long user_turn_start_ms = monotonic_ms();
        int user_turn_errored = 0;

        footer_set_timer(render.footer, user_turn_start_ms);

        /* Clear stale editor interrupts before arming first-Esc pause and second-Esc abort. */
        interrupt_clear_requests();
        interrupt_arm();
        struct repl_loop_ctx loop_ctx = {.state = &state};
        struct agent_loop_params loop_params = {
            .session = &session,
            .provider = current_provider,
            .tlog = state.transcript,
            .slog = state.session_log,
            .max_turns = config_int("max_turns"),
            .continued = continued,
            .hooks =
                {
                    .user = &loop_ctx,
                    .observe = repl_loop_on_event,
                    .tick = repl_loop_tick,
                    .turn_begin = repl_loop_turn_begin,
                    .checkpoint = repl_loop_checkpoint,
                    .tool_call = repl_loop_tool_call,
                    .compact = repl_loop_compact,
                    .task_note = repl_loop_task_note,
                },
        };
        struct agent_loop_result loop_result;
        agent_loop_run(&loop_params, &loop_result);
        user_turn_context_tokens = loop_result.last_context_tokens;
        user_turn_errored = loop_result.outcome == AGENT_LOOP_PROVIDER_ERROR;
        int user_turn_complete = loop_result.outcome == AGENT_LOOP_COMPLETE;
        set_resume_state(&state, &loop_result);
        agent_loop_result_destroy(&loop_result);
        interrupt_disarm();
        /* Snapshot Esc before auto-compaction clears the interrupt latch. */
        int user_pressed_escape = interrupt_pause_requested();
        footer_set_timer(render.footer, 0);

        /* Close active rendering before post-turn output can emit terminal control sequences. */
        render_finish(&render);

        if (state.resume_reason == AGENT_RESUME_INTERRUPTED)
            render_interrupt_marker(&render);

        /* Time worked counts errored/interrupted turns too — the wall time
         * was spent either way, and /session's total should reflect it. */
        long user_turn_ms = monotonic_ms() - user_turn_start_ms;
        agent_session_add_worked(&session, user_turn_ms);
        session_log_user_turn(state.session_log, user_turn_ms);

        if (!user_turn_errored)
            display_stats_line(&render, current_provider, &session, user_turn_ms);

        /* Auto-compact only completed, Esc-free turns. Clean pauses defer compaction until the
         * next send; errors and aborts retain partial history for retry or explicit
         * compaction. */
        if (compact_should_auto(user_turn_context_tokens,
                                model_meta_context(current_provider, session.model))) {
            if (user_turn_complete && !user_pressed_escape)
                agent_compact(&state, NULL, 1);
            else if (user_turn_complete || state.resume_reason == AGENT_RESUME_PAUSED ||
                     state.resume_reason == AGENT_RESUME_MAX_TURNS)
                state.compaction_deferred = 1;
        }

        /* Esc means the user is already present; otherwise notify when the REPL becomes idle,
         * including errors and max-turn pauses. */
        if (!user_pressed_escape)
            notify_attention();
    }

    finalize_tasks(&state);

    const char *resume_hint = session_log_resume_hint(state.session_log);
    if (resume_hint)
        ui_note("resume with: hax --resume=%s", resume_hint);

    *provider_io = current_provider;

    footer_free(render.footer);
    input_free(input);
    if (render.md)
        md_free(render.md);
    disp_free(&render.disp);
    transcript_log_close(transcript);
    session_log_close(state.session_log);
    free(state.pending_preseed);
    agent_session_free(&session);
    return 0;
}
