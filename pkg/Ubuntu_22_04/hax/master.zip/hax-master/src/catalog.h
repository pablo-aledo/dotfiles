/* SPDX-License-Identifier: MIT */
#ifndef HAX_CATALOG_H
#define HAX_CATALOG_H

#include <jansson.h>

#include "effort.h"

/* The model catalog resolves per-model pricing, token limits, image support, and reasoning-effort
 * metadata. User `catalog.models` configuration takes precedence over a cached models.dev
 * snapshot; missing providers, models, and fields remain unknown. `provider_id` is the models.dev
 * provider key and may differ from the runtime provider name. The prefetch lifecycle refreshes the
 * cached snapshot asynchronously. */

#define CATALOG_TIERS_MAX 4

/* Rate overrides for requests whose total input exceeds a positive `context_threshold`. */
struct catalog_tier {
    long context_threshold;
    double cost_input;
    double cost_output;
    double cost_cache_read;
    double cost_cache_write;
    double cost_cache_write_1h;
};

enum catalog_support {
    CATALOG_SUPPORT_UNKNOWN = -1,
    CATALOG_SUPPORT_NO,
    CATALOG_SUPPORT_YES,
};

/* Metadata merged from catalog.models configuration over the cached models.dev snapshot. */
struct catalog_entry {
    /* USD per million tokens; negative = unknown. */
    double cost_input;
    double cost_output;
    double cost_cache_read;
    double cost_cache_write;
    double cost_cache_write_1h;

    /* Token limits; 0 = unknown. */
    long context_window;
    long max_output;

    enum catalog_support image_input;

    /* `known` distinguishes an unsupported effort ladder from absent metadata. */
    struct effort_set efforts;

    /* A declared list replaces the lower-priority list rather than merging with it. */
    struct catalog_tier tiers[CATALOG_TIERS_MAX];
    int n_tiers;
    int tiers_declared; /* Distinguishes an absent list from a declared empty list. */
};

/* Initialize every field to its documented unknown state. */
void catalog_entry_init(struct catalog_entry *entry);

/* Resolve one model. Configuration wins field by field over the cached snapshot. Returns 0 when
 * any metadata resolved and -1 otherwise. `out` is always initialized. Results from the snapshot,
 * including misses, are memoized until a successful refresh. */
int catalog_lookup(const char *provider_id, const char *model, struct catalog_entry *out);

/* Resolve `model_count` models for one provider while loading its cached snapshot once. `models`
 * and `out` must contain `model_count` elements. If non-NULL, `found[i]` receives 1 when any
 * metadata resolved and 0 otherwise. NULL or empty model IDs are unresolved. */
void catalog_lookup_many(const char *provider_id, const char *const *models, size_t model_count,
                         struct catalog_entry *out, int *found);

/* Parse the top-level member named `key` without tree-parsing the full JSON object. Returns a new
 * reference, or NULL when the member is absent or malformed. The caller must call json_decref. */
json_t *catalog_extract_member(const char *text, const char *key);

/* Return whether cache writes replace the input charge. A known write rate below the input rate is
 * treated as a storage surcharge; unknown rates use the more common replacement policy. */
int catalog_cache_write_replaces_input(const struct catalog_entry *entry);

/* Per-category costs for one request, in USD. */
struct catalog_split {
    double cost_input;
    double cost_cache_read;
    double cost_cache_write;
    double cost_output;
    long uncached_input_tokens;
};

/* Price one request in USD. Cache-read and cache-write counts are subsets of input, and
 * `cache_write_1h_tokens` is a subset of cache writes. Negative counts are treated as zero. The
 * highest context tier exceeded by total input replaces the base rates for the whole request, with
 * unknown tier rates falling back to their base rates. An unknown 1h write rate uses twice the
 * input rate. Returns -1 unless input and output rates are known. If non-NULL, `split` is zeroed
 * even when pricing fails. */
double catalog_price(const struct catalog_entry *entry, long input_tokens, long output_tokens,
                     long cache_read_tokens, long cache_write_tokens, long cache_write_1h_tokens,
                     struct catalog_split *split);

/* Start the process-wide background refresh when the snapshot is older than catalog.refresh.
 * Empty catalog.url or a non-positive refresh interval disables fetching. Only the first call per
 * process does work. Returns the stale snapshot's age in days once it exceeds the warning
 * threshold, otherwise 0. Fetch failures leave the existing snapshot untouched. */
long catalog_prefetch(void);

/* Give short-lived runs up to `max_wait_ms` to finish a background refresh, then cancel and join
 * it. No-op when no refresh is running. */
void catalog_drain(long max_wait_ms);

/* Cancel and join the background refresh, then clear memoized lookups. Must run before
 * curl_global_cleanup(). */
void catalog_shutdown(void);

#endif /* HAX_CATALOG_H */
