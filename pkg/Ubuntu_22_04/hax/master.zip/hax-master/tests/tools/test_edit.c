/* SPDX-License-Identifier: MIT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "harness.h"
#include "tool.h"
#include "xalloc.h"
#include "system/fs.h"

static char *seed_file(const char *dir, const char *name, const char *content)
{
    char *path = xasprintf("%s/%s", dir, name);
    FILE *f = fopen(path, "w");
    EXPECT(f != NULL);
    fputs(content, f);
    fclose(f);
    return path;
}

static char *read_file(const char *path)
{
    size_t n = 0;
    return fs_read_file(path, &n);
}

static void test_edit_missing_path(void)
{
    char *out = TOOL_EDIT.run("{\"old_string\":\"a\",\"new_string\":\"b\"}", NULL);
    EXPECT(strstr(out, "missing 'path'") != NULL);
    free(out);
}

static void test_edit_missing_old(void)
{
    char *out = TOOL_EDIT.run("{\"path\":\"/tmp/x\",\"new_string\":\"b\"}", NULL);
    EXPECT(strstr(out, "missing 'old_string'") != NULL);
    free(out);
}

static void test_edit_missing_new(void)
{
    char *out = TOOL_EDIT.run("{\"path\":\"/tmp/x\",\"old_string\":\"a\"}", NULL);
    EXPECT(strstr(out, "missing 'new_string'") != NULL);
    free(out);
}

static void test_edit_old_empty(void)
{
    char *out =
        TOOL_EDIT.run("{\"path\":\"/tmp/x\",\"old_string\":\"\",\"new_string\":\"b\"}", NULL);
    EXPECT(strstr(out, "'old_string' must be non-empty") != NULL);
    free(out);
}

static void test_edit_identical_strings(void)
{
    char *out =
        TOOL_EDIT.run("{\"path\":\"/tmp/x\",\"old_string\":\"a\",\"new_string\":\"a\"}", NULL);
    EXPECT(strstr(out, "identical") != NULL);
    free(out);
}

static void test_edit_unique_match(void)
{
    char *dir = t_tempdir();
    char *path = seed_file(dir, "f.txt", "alpha\nbeta\ngamma\n");

    char *args =
        xasprintf("{\"path\":\"%s\",\"old_string\":\"beta\",\"new_string\":\"BETA\"}", path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "-beta") != NULL);
    EXPECT(strstr(out, "+BETA") != NULL);
    free(out);

    char *got = read_file(path);
    EXPECT_STR_EQ(got, "alpha\nBETA\ngamma\n");
    free(got);

    free(path);
}

static void test_edit_no_match(void)
{
    char *dir = t_tempdir();
    char *path = seed_file(dir, "f.txt", "alpha\n");

    char *args = xasprintf("{\"path\":\"%s\",\"old_string\":\"zzz\",\"new_string\":\"q\"}", path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "not found") != NULL);
    free(out);

    char *got = read_file(path);
    EXPECT_STR_EQ(got, "alpha\n");
    free(got);

    free(path);
}

static void test_edit_multi_match_requires_replace_all(void)
{
    char *dir = t_tempdir();
    char *path = seed_file(dir, "f.txt", "foo\nfoo\nfoo\n");

    char *args = xasprintf("{\"path\":\"%s\",\"old_string\":\"foo\",\"new_string\":\"bar\"}", path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "matches 3 places") != NULL);
    free(out);

    char *got = read_file(path);
    EXPECT_STR_EQ(got, "foo\nfoo\nfoo\n");
    free(got);

    free(path);
}

static void test_edit_replace_all(void)
{
    char *dir = t_tempdir();
    char *path = seed_file(dir, "f.txt", "foo\nfoo\nfoo\n");

    char *args = xasprintf(
        "{\"path\":\"%s\",\"old_string\":\"foo\",\"new_string\":\"bar\",\"replace_all\":true}",
        path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "+bar") != NULL);
    free(out);

    char *got = read_file(path);
    EXPECT_STR_EQ(got, "bar\nbar\nbar\n");
    free(got);

    free(path);
}

static void test_edit_deletes_entire_content(void)
{
    char *dir = t_tempdir();
    char *path = seed_file(dir, "f.txt", "delete me");

    char *args =
        xasprintf("{\"path\":\"%s\",\"old_string\":\"delete me\",\"new_string\":\"\"}", path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "-delete me") != NULL);
    free(out);

    char *got = read_file(path);
    EXPECT_STR_EQ(got, "");
    free(got);
    free(path);
}

static void test_edit_multiline_match(void)
{
    char *dir = t_tempdir();
    char *path = seed_file(dir, "f.c", "int main(void)\n{\n\treturn 0;\n}\n");

    char *args = xasprintf(
        "{\"path\":\"%s\",\"old_string\":\"\\treturn 0;\\n\",\"new_string\":\"\\treturn 42;\\n\"}",
        path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "-\treturn 0;") != NULL);
    EXPECT(strstr(out, "+\treturn 42;") != NULL);
    free(out);

    char *got = read_file(path);
    EXPECT_STR_EQ(got, "int main(void)\n{\n\treturn 42;\n}\n");
    free(got);

    free(path);
}

static void test_edit_refuses_fifo(void)
{
    /* A blocking read from a writer-less FIFO never returns, so reject it as non-regular before
     * reading. */
    char *dir = t_tempdir();
    char *path = xasprintf("%s/pipe", dir);
    EXPECT(mkfifo(path, 0644) == 0);

    char *args = xasprintf("{\"path\":\"%s\",\"old_string\":\"a\",\"new_string\":\"b\"}", path);
    char *out = TOOL_EDIT.run(args, NULL);
    free(args);
    EXPECT(strstr(out, "not a regular file") != NULL);
    free(out);

    struct stat st;
    EXPECT(stat(path, &st) == 0);
    EXPECT(S_ISFIFO(st.st_mode));

    free(path);
}

static void test_edit_nonexistent_file(void)
{
    char *out = TOOL_EDIT.run("{\"path\":\"/nonexistent/hax/edit/path\",\"old_string\":\"a\","
                              "\"new_string\":\"b\"}",
                              NULL);
    EXPECT(strstr(out, "error reading") != NULL);
    free(out);
}

int main(void)
{
    test_edit_missing_path();
    test_edit_missing_old();
    test_edit_missing_new();
    test_edit_old_empty();
    test_edit_identical_strings();
    test_edit_unique_match();
    test_edit_no_match();
    test_edit_multi_match_requires_replace_all();
    test_edit_replace_all();
    test_edit_deletes_entire_content();
    test_edit_multiline_match();
    test_edit_refuses_fifo();
    test_edit_nonexistent_file();
    T_REPORT();
}
