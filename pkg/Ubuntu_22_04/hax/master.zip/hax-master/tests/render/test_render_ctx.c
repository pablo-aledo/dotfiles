/* SPDX-License-Identifier: MIT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "harness.h"
#include "render/disp.h"
#include "render/markdown.h"
#include "render/render_ctx.h"
#include "terminal/ansi.h"

struct fixture {
    struct render_ctx render;
    FILE *stream;
    char *bytes;
    size_t len;
};

static int fixture_init(struct fixture *fixture)
{
    memset(fixture, 0, sizeof(*fixture));
    fixture->stream = open_memstream(&fixture->bytes, &fixture->len);
    EXPECT(fixture->stream != NULL);
    if (!fixture->stream)
        return 0;
    fixture->render.disp.sink = fixture->stream;
    fixture->render.disp.committed_newlines = 2;
    return 1;
}

static const char *fixture_output(struct fixture *fixture)
{
    disp_flush(&fixture->render.disp);
    return fixture->bytes ? fixture->bytes : "";
}

static void emit_markdown(const char *bytes, size_t len, int is_raw, void *user)
{
    struct disp *disp = user;
    if (is_raw)
        fwrite(bytes, 1, len, disp_sink(disp));
    else
        disp_write(disp, bytes, len);
}

static void fixture_enable_markdown(struct fixture *fixture)
{
    fixture->render.md = md_new(emit_markdown, &fixture->render.disp, 40);
}

static void fixture_destroy(struct fixture *fixture)
{
    md_free(fixture->render.md);
    disp_free(&fixture->render.disp);
    fclose(fixture->stream);
    free(fixture->bytes);
}

static void test_text_delta_ignores_initial_line_endings(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    const char *line_endings = "\r\n\r";
    render_text_delta(&fixture.render, line_endings, strlen(line_endings));
    EXPECT(fixture.render.mode == RENDER_IDLE);
    EXPECT(!fixture.render.stream.answer_started);

    const char *text = "\n\n\thello";
    render_text_delta(&fixture.render, text, strlen(text));
    EXPECT_STR_EQ(fixture_output(&fixture), "    hello");
    EXPECT(fixture.render.mode == RENDER_TEXT);
    EXPECT(fixture.render.stream.answer_started);
    fixture_destroy(&fixture);
}

static void test_text_delta_preserves_line_endings_after_text_starts(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_text_delta(&fixture.render, "first", strlen("first"));
    render_text_delta(&fixture.render, "\nsecond", strlen("\nsecond"));

    EXPECT_STR_EQ(fixture_output(&fixture), "first\nsecond");
    fixture_destroy(&fixture);
}

static void test_plain_text_expands_tabs(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_text_delta(&fixture.render, "a\tb\t", strlen("a\tb\t"));
    EXPECT_STR_EQ(fixture_output(&fixture), "a    b    ");
    EXPECT(fixture.render.disp.column == 10);
    fixture_destroy(&fixture);
}

static void test_closing_reasoning_resets_style(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_set_mode(&fixture.render, RENDER_REASONING);
    render_write_text(&fixture.render, "thought", strlen("thought"));
    render_set_mode(&fixture.render, RENDER_IDLE);
    disp_commit_newlines(&fixture.render.disp);

    EXPECT_STR_EQ(fixture_output(&fixture), ANSI_DIM ANSI_ITALIC "thought" ANSI_RESET "\n");
    fixture_destroy(&fixture);
}

/* Closing a reasoning block writes its newline outside the markdown wrapper. A later reasoning
 * block in the same stream must wrap from column 0, not the previous block's end column. */
static void test_reasoning_reopened_wraps_from_column_zero(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;
    fixture_enable_markdown(&fixture);

    const char *first = "0123456789 0123456789 0123456789";
    render_set_mode(&fixture.render, RENDER_REASONING);
    render_write_text(&fixture.render, first, strlen(first));
    render_set_mode(&fixture.render, RENDER_IDLE);

    const char *second = "abcdefghij klmnopqrst";
    render_set_mode(&fixture.render, RENDER_REASONING);
    render_write_text(&fixture.render, second, strlen(second));
    render_set_mode(&fixture.render, RENDER_IDLE);

    EXPECT(strstr(fixture_output(&fixture), second) != NULL);
    fixture_destroy(&fixture);
}

static void test_stream_begin_resets_per_stream_state(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    fixture.render.retry.deadline_ms = 20;
    fixture.render.retry.next_attempt = 2;
    fixture.render.retry.max_attempts = 3;
    fixture.render.stream.content_seen = 1;
    fixture.render.stream.answer_started = 1;
    render_stream_begin(&fixture.render);

    EXPECT(fixture.render.mode == RENDER_WAITING);
    EXPECT(fixture.render.retry.deadline_ms == 0);
    EXPECT(fixture.render.retry.next_attempt == 0);
    EXPECT(fixture.render.retry.max_attempts == 0);
    EXPECT(!fixture.render.stream.content_seen);
    EXPECT(!fixture.render.stream.answer_started);
    fixture_destroy(&fixture);
}

static void test_stream_begin_preserves_tool_cluster(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_set_mode(&fixture.render, RENDER_TOOL_CLUSTER);
    fixture.render.cluster.last_tool = "read";
    fixture.render.cluster.line_open = 1;
    fixture.render.stream.content_seen = 1;
    render_stream_begin(&fixture.render);

    EXPECT(fixture.render.mode == RENDER_TOOL_CLUSTER);
    EXPECT_STR_EQ(fixture.render.cluster.last_tool, "read");
    EXPECT(fixture.render.cluster.line_open);
    EXPECT(!fixture.render.stream.content_seen);
    fixture_destroy(&fixture);
}

static void test_stream_retry_marks_rendered_output(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_text_delta(&fixture.render, "partial", strlen("partial"));
    EXPECT(fixture.render.stream.output_rendered);
    render_stream_retry(&fixture.render, 1, 3, 1000);

    EXPECT(strstr(fixture_output(&fixture), "[unexpected end]") != NULL);
    EXPECT(fixture.render.mode == RENDER_WAITING);
    EXPECT(!fixture.render.stream.content_seen);
    EXPECT(!fixture.render.stream.answer_started);
    EXPECT(!fixture.render.stream.output_rendered);
    fixture_destroy(&fixture);
}

static void test_stream_retry_silent_without_output(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    fixture.render.stream.content_seen = 1;
    render_stream_retry(&fixture.render, 1, 3, 1000);

    EXPECT_STR_EQ(fixture_output(&fixture), "");
    EXPECT(fixture.render.mode == RENDER_IDLE);
    EXPECT(!fixture.render.stream.content_seen);
    fixture_destroy(&fixture);
}

static void test_retry_lasts_until_the_retried_attempt_streams(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_stream_retry(&fixture.render, 1, 3, 1000);
    EXPECT(fixture.render.retry.deadline_ms > 0);
    EXPECT(fixture.render.retry.next_attempt == 2);
    EXPECT(fixture.render.retry.max_attempts == 3);

    render_retry_end(&fixture.render);
    EXPECT(fixture.render.retry.deadline_ms == 0);
    fixture_destroy(&fixture);
}

static void test_finish_ends_a_pending_retry(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_stream_retry(&fixture.render, 1, 3, 1000);
    render_finish(&fixture.render);
    EXPECT(fixture.render.mode == RENDER_IDLE);
    EXPECT(fixture.render.retry.deadline_ms == 0);
    fixture_destroy(&fixture);
}

static void test_retry_label_counts_down_then_marks_in_flight(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    fixture.render.retry.deadline_ms = 10000;
    fixture.render.retry.next_attempt = 2;
    fixture.render.retry.max_attempts = 5;
    char label[64];

    render_retry_label(&fixture.render, 7500, label, sizeof(label));
    EXPECT_STR_EQ(label, "retrying in 3s (attempt 2/5)...");
    render_retry_label(&fixture.render, 9990, label, sizeof(label));
    EXPECT_STR_EQ(label, "retrying in 1s (attempt 2/5)...");
    render_retry_label(&fixture.render, 10000, label, sizeof(label));
    EXPECT_STR_EQ(label, "retrying (attempt 2/5)...");
    render_retry_label(&fixture.render, 16000, label, sizeof(label));
    EXPECT_STR_EQ(label, "retrying (attempt 2/5)...");
    fixture_destroy(&fixture);
}

static void test_closing_tool_cluster_resets_substate(void)
{
    struct fixture fixture;
    if (!fixture_init(&fixture))
        return;

    render_set_mode(&fixture.render, RENDER_TOOL_CLUSTER);
    fixture.render.cluster.last_tool = "read";
    fixture.render.cluster.line_open = 1;
    render_set_mode(&fixture.render, RENDER_IDLE);

    EXPECT(fixture.render.cluster.last_tool == NULL);
    EXPECT(!fixture.render.cluster.line_open);
    fixture_destroy(&fixture);
}

int main(void)
{
    test_text_delta_ignores_initial_line_endings();
    test_text_delta_preserves_line_endings_after_text_starts();
    test_plain_text_expands_tabs();
    test_closing_reasoning_resets_style();
    test_reasoning_reopened_wraps_from_column_zero();
    test_stream_begin_resets_per_stream_state();
    test_stream_begin_preserves_tool_cluster();
    test_stream_retry_marks_rendered_output();
    test_stream_retry_silent_without_output();
    test_retry_lasts_until_the_retried_attempt_streams();
    test_finish_ends_a_pending_retry();
    test_retry_label_counts_down_then_marks_in_flight();
    test_closing_tool_cluster_resets_substate();

    T_REPORT();
}
