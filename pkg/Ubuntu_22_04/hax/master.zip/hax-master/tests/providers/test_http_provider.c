/* SPDX-License-Identifier: MIT */
#include <errno.h>
#include <jansson.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "catalog.h"
#include "config.h"
#include "diag.h"
#include "effort.h"
#include "harness.h"
#include "loopback.h"
#include "provider.h"
#include "xalloc.h"
#include "providers/http_provider.h"
#include "providers/openai_models.h"
#include "providers/provider_config.h"
#include "providers/registry.h"
#include "transport/http.h"

/* The full ladder is the default offer; no_efforts opts a def out entirely. */
static void test_list_efforts_wiring(void)
{
    struct provider_def with_efforts = {
        .id = "with-efforts",
        .base_url = "http://example.invalid/v1",
    };
    struct provider *provider = http_provider_new(&with_efforts);
    EXPECT(provider != NULL);
    if (provider) {
        EXPECT(provider->list_models != NULL);
        EXPECT(provider->list_efforts != NULL);
        const char *const *efforts = NULL;
        size_t n_efforts = provider->list_efforts(provider, &efforts);
        EXPECT(n_efforts == EFFORT_LADDER_N);
        EXPECT(efforts != NULL && strcmp(efforts[0], "none") == 0);
        EXPECT(strcmp(efforts[n_efforts - 1], "max") == 0);
        provider->destroy(provider);
    }

    struct provider_def without_efforts = {
        .id = "without-efforts",
        .base_url = "http://example.invalid/v1",
        .no_efforts = 1,
    };
    provider = http_provider_new(&without_efforts);
    EXPECT(provider != NULL);
    if (provider) {
        const char *const *efforts = NULL;
        EXPECT(provider->list_efforts(provider, &efforts) == 0);
        provider->destroy(provider);
    }
}

/* On the Messages wire the effort ladder steers adaptive thinking, so only a budget/off pin,
 * configured or shipped in the def, hides it: an unpinned mode upgrades when an effort is
 * chosen. */
static void test_messages_efforts_follow_thinking_mode(void)
{
    struct provider_def def = {
        .id = "x",
        .api = "anthropic-messages",
        .base_url = "http://example.invalid/v1",
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        /* A pure Messages provider drops "minimal" (no Messages meaning) but keeps "none"
         * (thinking off). */
        const char *const *efforts = NULL;
        EXPECT(provider->list_efforts(provider, &efforts) == EFFORT_LADDER_N - 1);
        EXPECT(efforts != NULL && strcmp(efforts[0], "none") == 0);
        EXPECT(strcmp(efforts[1], "low") == 0);

        EXPECT(config_load("{\"providers\": {\"x\": {\"thinking_mode\": \"budget\"}}}") == 0);
        EXPECT(provider->list_efforts(provider, &efforts) == 0);

        EXPECT(config_load("{\"providers\": {\"x\": {\"thinking_mode\": \"adaptive\"}}}") == 0);
        EXPECT(provider->list_efforts(provider, &efforts) == EFFORT_LADDER_N - 1);
        EXPECT(config_load("{\"providers\": {\"x\": {\"thinking_mode\": \"auto\"}}}") == 0);
        EXPECT(provider->list_efforts(provider, &efforts) == EFFORT_LADDER_N - 1);

        /* A typo is not a pin: requests fall back to the default, so the ladder stays. */
        EXPECT(config_load("{\"providers\": {\"x\": {\"thinking_mode\": \"bugdet\"}}}") == 0);
        EXPECT(provider->list_efforts(provider, &efforts) == EFFORT_LADDER_N - 1);
        EXPECT(config_load(NULL) == 0);
        provider->destroy(provider);
    }

    /* On a mixed provider — a model_apis rule routes some models to another wire — a budget pin
     * affects only the Messages models, so the ladder must survive for the routed ones. */
    EXPECT(config_load("{\"providers\": {\"x\": {\"thinking_mode\": \"budget\","
                       " \"model_apis\": {\"gpt-*\": \"openai-completions\"}}}}") == 0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        const char *const *efforts = NULL;
        EXPECT(provider->list_efforts(provider, &efforts) == EFFORT_LADDER_N);
        provider->destroy(provider);
    }
    EXPECT(config_load(NULL) == 0);

    /* A def pin means the same as a configured one. */
    struct provider_def pinned = {
        .id = "x",
        .api = "anthropic-messages",
        .base_url = "http://example.invalid/v1",
        .thinking_mode = "budget",
    };
    provider = http_provider_new(&pinned);
    EXPECT(provider != NULL);
    if (provider) {
        const char *const *efforts = NULL;
        EXPECT(provider->list_efforts(provider, &efforts) == 0);
        provider->destroy(provider);
    }
}

static int headers_have_version(char **headers)
{
    for (char **header = headers; header && *header; header++)
        if (strncmp(*header, "anthropic-version:", 18) == 0)
            return 1;
    return 0;
}

/* providers.<id>.api overlays an unpinned def's dialect in either direction — a custom Messages
 * endpoint is declared exactly this way — with the metadata auth scheme following the resolved
 * wire (the version header marks the Messages side). An unsupported value fails construction
 * rather than guessing a protocol. */
static void test_api_override_moves_wire(void)
{
    struct provider_def def = {
        .id = "x",
        .base_url = "http://example.invalid/v1",
    };
    EXPECT(config_load("{\"providers\": {\"x\": {\"api\": \"anthropic-messages\"}}}") == 0);
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        char **headers = http_provider_metadata_headers(provider);
        EXPECT(headers_have_version(headers));
        string_array_free(headers);
        provider->destroy(provider);
    }

    struct provider_def messages_def = {
        .id = "x",
        .api = "anthropic-messages",
        .base_url = "http://example.invalid/v1",
    };
    EXPECT(config_load("{\"providers\": {\"x\": {\"api\": \"responses\"}}}") == 0);
    provider = http_provider_new(&messages_def);
    EXPECT(provider != NULL);
    if (provider) {
        char **headers = http_provider_metadata_headers(provider);
        EXPECT(!headers_have_version(headers));
        string_array_free(headers);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"x\": {\"api\": \"bogus\"}}}") == 0);
    unsigned long diagnostics_before = hax_diag_sequence();
    EXPECT(http_provider_new(&def) == NULL);
    EXPECT(hax_diag_sequence() == diagnostics_before + 1);
    EXPECT(config_load(NULL) == 0);
}

/* The /models dialect and its auth scheme follow metadata_api, not the request wire: a Messages
 * endpoint can front an OpenAI-shaped catalog and vice versa. The version header marks the
 * Anthropic side. */
static void test_metadata_api_override(void)
{
    EXPECT(config_load("{\"providers\": {\"x\": {\"metadata_api\": \"openai\"}}}") == 0);
    struct provider_def messages_def = {
        .id = "x",
        .api = "anthropic-messages",
        .base_url = "http://example.invalid/v1",
    };
    struct provider *provider = http_provider_new(&messages_def);
    EXPECT(provider != NULL);
    if (provider) {
        char **headers = http_provider_metadata_headers(provider);
        EXPECT(!headers_have_version(headers));
        EXPECT(provider->probe_model == openai_probe_model);
        string_array_free(headers);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"x\": {\"metadata_api\": \"anthropic\"}}}") == 0);
    struct provider_def chat_def = {
        .id = "x",
        .base_url = "http://example.invalid/v1",
    };
    provider = http_provider_new(&chat_def);
    EXPECT(provider != NULL);
    if (provider) {
        char **headers = http_provider_metadata_headers(provider);
        EXPECT(headers_have_version(headers));
        EXPECT(provider->probe_model != NULL);
        string_array_free(headers);
        provider->destroy(provider);
    }
    EXPECT(config_load(NULL) == 0);
}

static void refine_nothing(const json_t *entry, struct model_info *out)
{
    (void)entry;
    (void)out;
}

/* On the OpenAI side the probe reads the full listing, authenticated like the listing itself, and
 * a parse_model hook refines the model's entry. */
static void test_parse_model_probes_listing(void)
{
    EXPECT(config_load("{\"providers\": {\"x\": {\"api_key\": \"sk-test\"}}}") == 0);
    struct provider_def def = {
        .id = "x",
        .base_url = "http://example.invalid/v1",
        .parse_model = refine_nothing,
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL && provider->probe_model != NULL);
    if (provider && provider->probe_model) {
        struct model_probe probe = {0};
        EXPECT(provider->probe_model(provider, "m", &probe) == 0);
        EXPECT_STR_EQ(probe.url, "http://example.invalid/v1/models");
        EXPECT(probe.headers && strcmp(probe.headers[0], "Authorization: Bearer sk-test") == 0);
        EXPECT(probe.parse_entry == refine_nothing);
        model_probe_clear(&probe);
        /* Without a model the same request serves the listing alone. */
        EXPECT(provider->probe_model(provider, NULL, &probe) == 0);
        EXPECT_STR_EQ(probe.url, "http://example.invalid/v1/models");
        model_probe_clear(&probe);
    }
    if (provider)
        provider->destroy(provider);

    /* Without parse_model the listing still serves its ids. */
    def.parse_model = NULL;
    provider = http_provider_new(&def);
    EXPECT(provider != NULL && provider->probe_model != NULL);
    if (provider && provider->probe_model) {
        struct model_probe probe = {0};
        EXPECT(provider->probe_model(provider, "m", &probe) == 0);
        EXPECT_STR_EQ(probe.url, "http://example.invalid/v1/models");
        EXPECT(probe.parse_entry == NULL);
        model_probe_clear(&probe);
    }
    if (provider)
        provider->destroy(provider);
    EXPECT(config_load(NULL) == 0);
}

struct error_log {
    int n_errors;
    char message[256];
};

static int log_error(const struct stream_event *event, void *user)
{
    struct error_log *log = user;
    if (event->kind == EV_ERROR) {
        log->n_errors++;
        snprintf(log->message, sizeof(log->message), "%s", event->u.error.message);
    }
    return 0;
}

/* Point the catalog cache tier at a private snapshot naming each model's wire. */
static void write_catalog_fixture(void)
{
    char *dir = t_tempdir();
    setenv("XDG_CACHE_HOME", dir, 1);
    char path[512];
    snprintf(path, sizeof(path), "%s/hax", dir);
    mkdir(path, 0755);
    snprintf(path, sizeof(path), "%s/hax/catalog.json", dir);
    FILE *f = fopen(path, "w");
    if (!f)
        FAIL("fopen %s: %s", path, strerror(errno));
    fputs("{\"zen-test\": {\"npm\": \"@ai-sdk/openai-compatible\", \"models\": {"
          "\"claude-hint\": {\"provider\": {\"npm\": \"@ai-sdk/anthropic\"}},"
          "\"claude-adaptive\": {\"provider\": {\"npm\": \"@ai-sdk/anthropic\"},"
          " \"reasoning_options\": [{\"type\": \"effort\", \"values\": [\"low\", \"high\"]},"
          " {\"type\": \"budget_tokens\"}]},"
          "\"claude-budget\": {\"provider\": {\"npm\": \"@ai-sdk/anthropic\"},"
          " \"reasoning_options\": [{\"type\": \"budget_tokens\"}]},"
          "\"gemini-hint\": {\"provider\": {\"npm\": \"@ai-sdk/google\"}},"
          "\"think-hint\": {\"interleaved\": {\"field\": \"reasoning_content\"}},"
          "\"no-replay\": {\"interleaved\": false}}}}",
          f);
    fclose(f);
}

/* One provider, one endpoint, three wires: model_apis rules and catalog hints pick each
 * request's protocol, path, and auth scheme; unmatched models keep the default wire. */
static void test_model_wire_routing(void)
{
    write_catalog_fixture();
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 9,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    EXPECT(config_load("{\"providers\": {\"zen\": {\"api_key\": \"sk-test\","
                       " \"model_apis\": {\"claude-rule-*\": \"anthropic-messages\","
                       " \"r-*\": \"openai-responses\"}}},"
                       " \"catalog\": {\"models\": {\"zen-test\": {"
                       " \"cfg-pin\": {\"api\": \"anthropic-messages\"}}}}}") == 0);
    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "zen",
        .api = "catalog",
        .base_url = base_url,
        .catalog_id = "zen-test",
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (!provider)
        return;

    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {.items = items, .n_items = 1, .image_input = 1};
    struct error_log log = {0};
    provider->stream(provider, &context, "claude-rule-1", log_error, &log, NULL, NULL);
    provider->stream(provider, &context, "r-1", log_error, &log, NULL, NULL);
    provider->stream(provider, &context, "claude-hint", log_error, &log, NULL, NULL);
    provider->stream(provider, &context, "plain", log_error, &log, NULL, NULL);
    context.effort = "high";
    provider->stream(provider, &context, "claude-hint", log_error, &log, NULL, NULL);
    context.effort = NULL;
    provider->stream(provider, &context, "cfg-pin", log_error, &log, NULL, NULL);
    context.effort = "minimal";
    provider->stream(provider, &context, "claude-rule-1", log_error, &log, NULL, NULL);
    context.effort = NULL;
    provider->stream(provider, &context, "claude-adaptive", log_error, &log, NULL, NULL);
    context.effort = "high";
    provider->stream(provider, &context, "claude-budget", log_error, &log, NULL, NULL);
    context.effort = NULL;
    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 9);

    EXPECT(strncmp(server.requests[0], "POST /messages HTTP", 19) == 0);
    EXPECT(strstr(server.requests[0], "x-api-key: sk-test\r\n") != NULL);
    EXPECT(strstr(server.requests[0], "anthropic-version: 2023-06-01\r\n") != NULL);
    EXPECT(strstr(server.requests[0], "\"max_tokens\"") != NULL);
    /* No effort selected: the compat-safe budget default. */
    EXPECT(strstr(server.requests[0], "\"budget_tokens\"") != NULL);

    EXPECT(strncmp(server.requests[1], "POST /responses HTTP", 20) == 0);
    EXPECT(strstr(server.requests[1], "Authorization: Bearer sk-test\r\n") != NULL);

    EXPECT(strncmp(server.requests[2], "POST /messages HTTP", 19) == 0);

    EXPECT(strncmp(server.requests[3], "POST /chat/completions HTTP", 27) == 0);
    EXPECT(strstr(server.requests[3], "Authorization: Bearer sk-test\r\n") != NULL);

    /* A selected effort upgrades the unconfigured default to adaptive thinking. */
    EXPECT(strncmp(server.requests[4], "POST /messages HTTP", 19) == 0);
    EXPECT(strstr(server.requests[4], "\"adaptive\"") != NULL);
    EXPECT(strstr(server.requests[4], "\"effort\":\"high\"") != NULL);
    EXPECT(strstr(server.requests[4], "\"budget_tokens\"") == NULL);

    /* A catalog.models api pin routes like a snapshot hint. */
    EXPECT(strncmp(server.requests[5], "POST /messages HTTP", 19) == 0);

    /* "minimal" can reach a rule-routed Messages model on a mixed provider; the wire cannot
     * spell it, so the request clamps to the Messages minimum instead. */
    EXPECT(strncmp(server.requests[6], "POST /messages HTTP", 19) == 0);
    EXPECT(strstr(server.requests[6], "\"adaptive\"") != NULL);
    EXPECT(strstr(server.requests[6], "\"effort\":\"low\"") != NULL);
    EXPECT(strstr(server.requests[6], "\"minimal\"") == NULL);

    /* Catalog effort levels select adaptive thinking before any effort is chosen; with none
     * chosen, the model picks its own. */
    EXPECT(strncmp(server.requests[7], "POST /messages HTTP", 19) == 0);
    EXPECT(strstr(server.requests[7], "\"adaptive\"") != NULL);
    EXPECT(strstr(server.requests[7], "\"output_config\"") == NULL);
    EXPECT(strstr(server.requests[7], "\"budget_tokens\"") == NULL);

    /* An effort accepted before the catalog landed does not force adaptive thinking on a
     * model the catalog now marks budget-only. */
    EXPECT(strstr(server.requests[8], "\"budget_tokens\"") != NULL);
    EXPECT(strstr(server.requests[8], "\"adaptive\"") == NULL);
    EXPECT(strstr(server.requests[8], "\"output_config\"") == NULL);

    EXPECT(log.n_errors == 9); /* every canned reply is a 400 */
    provider->destroy(provider);
    EXPECT(config_load(NULL) == 0);
}

/* The def-declared Messages defaults reach the request: prefer-adaptive thinking gives a model
 * the catalog does not know adaptive (not a compat-safe budget) while a catalogued budget-only
 * ladder still gets budget, and prompt-cache markers come without the def asking for them.
 * Effort "none" has no Messages spelling, so it disables thinking instead of riding
 * output_config. A configured cache=false is the only thing that drops the markers. */
static void test_messages_defaults_follow_def(void)
{
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 4,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "fp",
        .api = "anthropic-messages",
        .base_url = base_url,
        .thinking_mode = "prefer-adaptive",
        .strict_signatures = 1,
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (!provider)
        return;

    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {.items = items, .n_items = 1, .image_input = 1};
    struct error_log log = {0};
    provider->stream(provider, &context, "claude-x", log_error, &log, NULL, NULL);
    context.effort = "none";
    provider->stream(provider, &context, "claude-x", log_error, &log, NULL, NULL);
    EXPECT(config_load("{\"providers\": {\"fp\": {\"cache\": false}}}") == 0);
    provider->stream(provider, &context, "claude-x", log_error, &log, NULL, NULL);
    context.effort = NULL;
    EXPECT(config_load("{\"catalog\": {\"models\": {\"fp\": {\"claude-budget\": {"
                       "\"reasoning_options\": [{\"type\": \"budget_tokens\"}]}}}}}") == 0);
    provider->stream(provider, &context, "claude-budget", log_error, &log, NULL, NULL);
    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 4);

    EXPECT(strstr(server.requests[0], "\"adaptive\"") != NULL);
    EXPECT(strstr(server.requests[0], "\"budget_tokens\"") == NULL);
    EXPECT(strstr(server.requests[0], "\"cache_control\"") != NULL);

    EXPECT(strstr(server.requests[1], "\"thinking\"") == NULL);
    EXPECT(strstr(server.requests[1], "\"output_config\"") == NULL);
    EXPECT(strstr(server.requests[1], "\"cache_control\"") != NULL);

    EXPECT(strstr(server.requests[2], "\"cache_control\"") == NULL);

    EXPECT(strstr(server.requests[3], "\"budget_tokens\"") != NULL);
    EXPECT(strstr(server.requests[3], "\"adaptive\"") == NULL);
    provider->destroy(provider);
    EXPECT(config_load(NULL) == 0);
}

struct fake_auth {
    int logged_out;
    int can_recover;
    int prepared;
    int token_generation;
    int destroyed;
};

static int fake_auth_prepare(void *auth_state, int allow_refresh, http_tick_cb tick,
                             void *tick_user)
{
    (void)allow_refresh;
    (void)tick;
    (void)tick_user;
    struct fake_auth *auth = auth_state;
    auth->prepared++;
    return auth->logged_out ? -1 : 0;
}

static char **fake_auth_headers(const void *auth_state, const char *session_id, int streaming)
{
    const struct fake_auth *auth = auth_state;
    char *bearer = xasprintf("Authorization: Bearer fake-%d", auth->token_generation);
    char *session = xasprintf("x-fake-session: %s", session_id);
    const char *fixed[] = {bearer, session, streaming ? "x-fake-stream: 1" : NULL, NULL};
    char **headers = string_array_concat(fixed, NULL);
    free(bearer);
    free(session);
    return headers;
}

static int fake_auth_recover(void *auth_state, int *retried, http_tick_cb tick, void *tick_user)
{
    (void)tick;
    (void)tick_user;
    struct fake_auth *auth = auth_state;
    if (*retried || !auth->can_recover)
        return 0;
    *retried = 1;
    auth->token_generation++;
    return 1;
}

static char *fake_auth_unauthorized_message(void *auth_state)
{
    struct fake_auth *auth = auth_state;
    return xstrdup(auth->logged_out ? "fake logged out" : "fake token expired");
}

static void fake_auth_destroy(void *auth_state)
{
    ((struct fake_auth *)auth_state)->destroyed++;
}

static const struct http_auth_ops FAKE_AUTH_OPS = {
    .prepare = fake_auth_prepare,
    .headers = fake_auth_headers,
    .recover = fake_auth_recover,
    .unauthorized_message = fake_auth_unauthorized_message,
    .destroy = fake_auth_destroy,
};

/* The state the next fake_auth_source hands out; the def hook takes no test-owned context. */
static struct fake_auth *fake_auth_next;

static int fake_auth_source(const struct provider_def *def, struct http_auth_source *out)
{
    (void)def;
    out->ops = &FAKE_AUTH_OPS;
    out->state = fake_auth_next;
    return 0;
}

/* An auth source replaces the API key: prepare gates the stream, its headers authenticate every
 * attempt, a 401 gets one bounded recovery with rotated credentials, and a terminal 401 reports
 * the source's message. */
static void test_auth_source_stream(void)
{
    struct loopback server = {
        .response = "HTTP/1.1 401 Unauthorized\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 3,
    };
    server.responses[1] =
        "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno";
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct fake_auth auth = {.can_recover = 1, .token_generation = 1};
    fake_auth_next = &auth;
    struct provider_def def = {
        .id = "fa",
        .base_url = base_url,
        .auth_source = fake_auth_source,
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (!provider)
        return;

    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {
        .items = items, .n_items = 1, .image_input = 1, .session_id = "conv-a"};
    struct error_log log = {0};
    provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
    auth.can_recover = 0;
    provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 3);

    EXPECT(strstr(server.requests[0], "Authorization: Bearer fake-1\r\n") != NULL);
    EXPECT(strstr(server.requests[0], "x-fake-stream: 1\r\n") != NULL);
    /* The conversation's id reaches the source through the request facts. */
    EXPECT(strstr(server.requests[0], "x-fake-session: conv-a\r\n") != NULL);
    /* The recovery rotated the token and the retry re-built its headers. */
    EXPECT(strstr(server.requests[1], "Authorization: Bearer fake-2\r\n") != NULL);
    EXPECT(strstr(server.requests[2], "Authorization: Bearer fake-2\r\n") != NULL);

    EXPECT(auth.prepared == 2);
    EXPECT(log.n_errors == 2);
    EXPECT(strstr(log.message, "fake token expired") != NULL);

    provider->destroy(provider);
    EXPECT(auth.destroyed == 1);
}

/* A logged-out source fails the stream before any request, with its own message. */
static void test_auth_source_logged_out(void)
{
    struct fake_auth auth = {.logged_out = 1};
    fake_auth_next = &auth;
    struct provider_def def = {
        .id = "fa",
        .base_url = "http://127.0.0.1:1",
        .auth_source = fake_auth_source,
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (!provider)
        return;

    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {.items = items, .n_items = 1, .image_input = 1};
    struct error_log log = {0};
    EXPECT(provider->stream(provider, &context, "m", log_error, &log, NULL, NULL) == -1);
    EXPECT(auth.prepared == 1);
    EXPECT(log.n_errors == 1);
    EXPECT(strstr(log.message, "fake logged out") != NULL);
    provider->destroy(provider);
}

static void fake_load_defaults(char **default_model, char **default_effort)
{
    *default_model = xstrdup("companion-model");
    *default_effort = xstrdup("high");
}

/* Def-declared body members ride every request under the user's extra_body, and
 * companion-tool defaults land on the provider. */
static void test_def_extra_body_and_defaults(void)
{
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 2,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "fx",
        .base_url = base_url,
        .extra_body = "{\"text\": {\"verbosity\": \"low\"}}",
        .load_defaults = fake_load_defaults,
    };
    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {.items = items, .n_items = 1, .image_input = 1};
    struct error_log log = {0};

    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        EXPECT_STR_EQ(provider->default_model, "companion-model");
        EXPECT_STR_EQ(provider->default_effort, "high");
        provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    /* The user's member overrides the def's. */
    EXPECT(config_load("{\"providers\": {\"fx\": {\"extra_body\":"
                       " {\"text\": {\"verbosity\": \"high\"}}}}}") == 0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 2);
    EXPECT(strstr(server.requests[0], "\"verbosity\":\"low\"") != NULL);
    EXPECT(strstr(server.requests[1], "\"verbosity\":\"high\"") != NULL);
    EXPECT(strstr(server.requests[1], "\"low\"") == NULL);
    EXPECT(config_load(NULL) == 0);
}

/* Def-declared headers ride every request with the conversation's id in the session placeholder
 * and as the prompt-cache key; without a conversation the process id stands in; config headers
 * replace same-named defaults. */
static void test_def_extra_headers_follow_conversation(void)
{
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 3,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "fh",
        .base_url = base_url,
        .send_cache_key = 1,
        .extra_headers = "{\"x-def-session\": \"{session_id}\", \"x-def-client\": \"hax\"}",
    };
    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {
        .items = items, .n_items = 1, .image_input = 1, .session_id = "conv-1"};
    struct error_log log = {0};

    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
        context.session_id = NULL;
        provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"fh\": {\"extra_headers\":"
                       " {\"X-Def-Client\": \"custom\"}}}}") == 0);
    context.session_id = "conv-1";
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "m", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 3);

    EXPECT(strstr(server.requests[0], "x-def-session: conv-1\r\n") != NULL);
    EXPECT(strstr(server.requests[0], "x-def-client: hax\r\n") != NULL);
    EXPECT(strstr(server.requests[0], "\"prompt_cache_key\":\"conv-1\"") != NULL);

    char process_header[80];
    snprintf(process_header, sizeof(process_header), "x-def-session: %s\r\n",
             provider_process_session_id());
    EXPECT(strstr(server.requests[1], process_header) != NULL);

    EXPECT(strstr(server.requests[2], "x-def-session: conv-1\r\n") != NULL);
    EXPECT(strstr(server.requests[2], "X-Def-Client: custom\r\n") != NULL);
    EXPECT(strstr(server.requests[2], "x-def-client: hax") == NULL);
    EXPECT(config_load(NULL) == 0);
}

static void stream_one_reasoned_turn(struct provider *provider, char *model, struct error_log *log)
{
    struct item items[] = {
        {.kind = ITEM_USER_MESSAGE, .text = "hello"},
        {.kind = ITEM_REASONING,
         .reasoning_text = "thought",
         .reasoning_field = "reasoning",
         .provider = "zen",
         .model = model},
        {.kind = ITEM_ASSISTANT_MESSAGE, .text = "hi"},
    };
    struct context context = {.items = items, .n_items = 3};
    provider->stream(provider, &context, model, log_error, log, NULL, NULL);
}

/* Replay precedence: a configured setting (even "off"), a catalog hint (a member or off), the def
 * default, then the recorded member. "auto" and "on" ask for the default order. */
static void test_interleaved_reasoning_replay(void)
{
    write_catalog_fixture();
    catalog_shutdown(); /* drop lookups memoized against an earlier fixture */
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 9,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "zen",
        .base_url = base_url,
        .catalog_id = "zen-test",
    };
    struct error_log log = {0};

    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        stream_one_reasoned_turn(provider, "think-hint", &log);
        stream_one_reasoned_turn(provider, "plain", &log);
        stream_one_reasoned_turn(provider, "no-replay", &log);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_roundtrip\": \"reasoning\"}}}") ==
           0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        stream_one_reasoned_turn(provider, "think-hint", &log);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_roundtrip\": \"off\"}}}") == 0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        stream_one_reasoned_turn(provider, "think-hint", &log);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_roundtrip\": \"auto\"}}}") == 0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        stream_one_reasoned_turn(provider, "think-hint", &log);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_roundtrip\": \"on\"}}}") == 0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        stream_one_reasoned_turn(provider, "plain", &log);
        stream_one_reasoned_turn(provider, "no-replay", &log);
        provider->destroy(provider);
    }

    EXPECT(config_load(NULL) == 0);
    def.reasoning_roundtrip = "reasoning_content";
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        stream_one_reasoned_turn(provider, "plain", &log);
        provider->destroy(provider);
    }

    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 9);

    EXPECT(strstr(server.requests[0], "\"reasoning_content\":\"thought\"") != NULL);
    EXPECT(strstr(server.requests[1], "\"reasoning\":\"thought\"") != NULL);
    EXPECT(strstr(server.requests[2], "thought") == NULL);
    EXPECT(strstr(server.requests[3], "\"reasoning\":\"thought\"") != NULL);
    EXPECT(strstr(server.requests[4], "thought") == NULL);
    /* "auto" names the default resolution, not a member called "auto". */
    EXPECT(strstr(server.requests[5], "\"reasoning_content\":\"thought\"") != NULL);
    EXPECT(strstr(server.requests[5], "\"auto\"") == NULL);
    EXPECT(strstr(server.requests[6], "\"reasoning\":\"thought\"") != NULL);
    EXPECT(strstr(server.requests[7], "thought") == NULL);
    EXPECT(strstr(server.requests[8], "\"reasoning_content\":\"thought\"") != NULL);

    EXPECT(config_load(NULL) == 0);
}

/* A reasoning-less tool call keeps the member where the def requires it, whether the member comes
 * from a catalog hint or the def, and even when the catalog hints against replay. Otherwise it is
 * required where the catalog names the model's member, under a pinned name if one is configured.
 * providers.<id>.reasoning_required overrides either way. */
static void test_required_reasoning_replay(void)
{
    write_catalog_fixture();
    catalog_shutdown();
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 10,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "zen",
        .base_url = base_url,
        .catalog_id = "zen-test",
        .reasoning_roundtrip = "reasoning_content",
        .reasoning_required = 1,
    };
    struct provider_def plain_def = {
        .id = "zen",
        .base_url = base_url,
        .catalog_id = "zen-test",
    };
    struct item items[] = {
        {.kind = ITEM_USER_MESSAGE, .text = "hello"},
        {.kind = ITEM_TOOL_CALL, .call_id = "c1", .tool_name = "read", .tool_arguments_json = "{}"},
        {.kind = ITEM_TOOL_RESULT, .call_id = "c1", .output = "x"},
    };
    struct context context = {.items = items, .n_items = 3};
    struct error_log log = {0};
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "think-hint", log_error, &log, NULL, NULL);
        provider->stream(provider, &context, "plain", log_error, &log, NULL, NULL);
        provider->stream(provider, &context, "no-replay", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    provider = http_provider_new(&plain_def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "think-hint", log_error, &log, NULL, NULL);
        provider->stream(provider, &context, "plain", log_error, &log, NULL, NULL);
        provider->stream(provider, &context, "no-replay", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_required\": \"off\"}}}") == 0);
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "think-hint", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }
    provider = http_provider_new(&plain_def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "think-hint", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_required\": \"on\","
                       " \"reasoning_roundtrip\": \"reasoning_content\"}}}") == 0);
    provider = http_provider_new(&plain_def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "plain", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    EXPECT(config_load("{\"providers\": {\"zen\": {\"reasoning_roundtrip\": \"reasoning\"}}}") ==
           0);
    provider = http_provider_new(&plain_def);
    EXPECT(provider != NULL);
    if (provider) {
        provider->stream(provider, &context, "think-hint", log_error, &log, NULL, NULL);
        provider->destroy(provider);
    }

    EXPECT(config_load(NULL) == 0);

    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 10);
    EXPECT(strstr(server.requests[0], "\"reasoning_content\":\"\"") != NULL);
    EXPECT(strstr(server.requests[1], "\"reasoning_content\":\"\"") != NULL);
    EXPECT(strstr(server.requests[2], "\"reasoning_content\":\"\"") != NULL);
    EXPECT(strstr(server.requests[3], "\"reasoning_content\":\"\"") != NULL);
    EXPECT(strstr(server.requests[4], "reasoning_content") == NULL);
    EXPECT(strstr(server.requests[5], "reasoning_content") == NULL);
    EXPECT(strstr(server.requests[6], "reasoning_content") == NULL);
    EXPECT(strstr(server.requests[7], "reasoning_content") == NULL);
    EXPECT(strstr(server.requests[8], "\"reasoning_content\":\"\"") != NULL);
    EXPECT(strstr(server.requests[9], "\"reasoning\":\"\"") != NULL);
    EXPECT(strstr(server.requests[9], "reasoning_content") == NULL);
}

static int construction_warns(const struct provider_def *def, const char *config)
{
    EXPECT(config_load(config) == 0);
    unsigned long diagnostics_before = hax_diag_sequence();
    struct provider *provider = http_provider_new(def);
    EXPECT(provider != NULL);
    if (provider)
        provider->destroy(provider);
    EXPECT(config_load(NULL) == 0);
    return hax_diag_sequence() != diagnostics_before;
}

/* The requirement goes unmet without a field to send, so construction says so: when replay is
 * off, and when nothing names the field a reasoning-less message would need. */
static void test_unmet_reasoning_requirement_warns(void)
{
    struct provider_def def = {.id = "x", .base_url = "http://example.invalid/v1"};
    EXPECT(construction_warns(&def, "{\"providers\": {\"x\": {\"reasoning_required\": true}}}"));
    EXPECT(construction_warns(&def, "{\"providers\": {\"x\": {\"reasoning_required\": true,"
                                    " \"reasoning_roundtrip\": \"off\"}}}"));
    EXPECT(!construction_warns(&def, "{\"providers\": {\"x\": {\"reasoning_required\": true,"
                                     " \"reasoning_roundtrip\": \"reasoning_content\"}}}"));
    EXPECT(!construction_warns(&def, "{\"providers\": {\"x\": {\"reasoning_required\": true,"
                                     " \"catalog_id\": \"deepseek\"}}}"));
    EXPECT(!construction_warns(&def, NULL));
}

/* Runtime-id catalog.models configuration routes wires and reasoning replay even when the
 * provider has no catalog identity to resolve the snapshot under. */
static void test_config_only_routing_without_catalog_id(void)
{
    catalog_shutdown(); /* drop lookups memoized against an earlier fixture */
    struct loopback server = {
        .response = "HTTP/1.1 400 Bad Request\r\nContent-Length: 2\r\nConnection: close\r\n\r\nno",
        .n_requests = 2,
    };
    int port = loopback_start(&server);
    EXPECT(port > 0);
    if (port <= 0)
        return;

    EXPECT(config_load("{\"catalog\": {\"models\": {\"zen\": {"
                       " \"claude-pin\": {\"api\": \"anthropic-messages\"},"
                       " \"think-pin\": {\"interleaved\": {\"field\": \"reasoning_content\"}}"
                       "}}}}") == 0);
    char base_url[64];
    snprintf(base_url, sizeof(base_url), "http://127.0.0.1:%d", port);
    struct provider_def def = {
        .id = "zen",
        .api = "catalog",
        .base_url = base_url,
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (!provider)
        return;

    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {.items = items, .n_items = 1, .image_input = 1};
    struct error_log log = {0};
    provider->stream(provider, &context, "claude-pin", log_error, &log, NULL, NULL);
    stream_one_reasoned_turn(provider, "think-pin", &log);
    loopback_stop(&server);
    EXPECT(atomic_load(&server.served) == 2);

    EXPECT(strncmp(server.requests[0], "POST /messages HTTP", 19) == 0);
    EXPECT(strncmp(server.requests[1], "POST /chat/completions HTTP", 27) == 0);
    EXPECT(strstr(server.requests[1], "\"reasoning_content\":\"thought\"") != NULL);

    provider->destroy(provider);
    EXPECT(config_load(NULL) == 0);
}

/* api "catalog" with no routing source warns at construction; cost or limit overrides are not a
 * routing source, only a configured api hint is. */
static void test_catalog_routing_warning(void)
{
    struct provider_def def = {
        .id = "zen",
        .api = "catalog",
        .base_url = "http://127.0.0.1:1",
    };

    EXPECT(config_load("{\"catalog\": {\"models\": {\"zen\": {"
                       "\"m\": {\"limit\": {\"context\": 872000}}}}}}") == 0);
    unsigned long diagnostics_before = hax_diag_sequence();
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    EXPECT(hax_diag_sequence() == diagnostics_before + 1);
    if (provider)
        provider->destroy(provider);

    EXPECT(config_load("{\"catalog\": {\"models\": {\"zen\": {"
                       "\"m\": {\"api\": \"anthropic-messages\"}}}}}") == 0);
    diagnostics_before = hax_diag_sequence();
    provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    EXPECT(hax_diag_sequence() == diagnostics_before);
    if (provider)
        provider->destroy(provider);

    EXPECT(config_load(NULL) == 0);
}

/* A catalog hint naming an unimplemented protocol fails cleanly before any request. */
static void test_unsupported_protocol_reported(void)
{
    struct provider_def def = {
        .id = "zen",
        .api = "catalog",
        .base_url = "http://127.0.0.1:1",
        .catalog_id = "zen-test",
    };
    struct provider *provider = http_provider_new(&def);
    EXPECT(provider != NULL);
    if (!provider)
        return;

    struct item items[] = {{.kind = ITEM_USER_MESSAGE, .text = "hello"}};
    struct context context = {.items = items, .n_items = 1, .image_input = 1};
    struct error_log log = {0};
    EXPECT(provider->stream(provider, &context, "gemini-hint", log_error, &log, NULL, NULL) == -1);
    EXPECT(log.n_errors == 1);
    EXPECT(strstr(log.message, "protocol") != NULL);
    provider->destroy(provider);
}

int main(void)
{
    signal(SIGPIPE, SIG_IGN);
    test_list_efforts_wiring();
    test_messages_efforts_follow_thinking_mode();
    test_api_override_moves_wire();
    test_metadata_api_override();
    test_parse_model_probes_listing();
    test_model_wire_routing();
    test_messages_defaults_follow_def();
    test_auth_source_stream();
    test_auth_source_logged_out();
    test_def_extra_body_and_defaults();
    test_def_extra_headers_follow_conversation();
    test_interleaved_reasoning_replay();
    test_required_reasoning_replay();
    test_unmet_reasoning_requirement_warns();
    test_config_only_routing_without_catalog_id();
    test_catalog_routing_warning();
    test_unsupported_protocol_reported();
    T_REPORT();
}
