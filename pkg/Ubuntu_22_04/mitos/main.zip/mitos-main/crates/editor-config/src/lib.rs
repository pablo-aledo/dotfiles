//! Editor settings, defaults, custom command definitions, and serialization.
//!
//! File discovery and merging belong to the application. Applying settings to
//! a running editor belongs to the editor runtime.

use ::clipboard::ClipboardProvider;

use std::{collections::HashSet, num::NonZeroU8, path::PathBuf, time::Duration};

use ::diagnostics::Severity;
use editor_core::{LineEnding, NATIVE_LINE_ENDING};
use language_config::{AutoPairConfig, IndentationHeuristic, SoftWrap, SpellingConfig};
use serde::{Deserialize, Deserializer, Serialize, Serializer};
use workspace::trust::ImplicitTrustLevel;

use ui_core::graphics::CursorKind;

mod commands;
mod diagnostics;
mod watch;
pub use commands::{CustomCommand, CustomCommands};
pub use diagnostics::{DiagnosticFilter, InlineDiagnosticsConfig};
pub use watch::WatchConfig;

pub const DEFAULT_AUTO_SAVE_DELAY: u64 = 3000;

fn deserialize_duration_millis<'de, D>(deserializer: D) -> Result<Duration, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let millis = u64::deserialize(deserializer)?;
    Ok(Duration::from_millis(millis))
}

fn serialize_duration_millis<S>(duration: &Duration, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    serializer.serialize_u64(
        duration
            .as_millis()
            .try_into()
            .map_err(|_| serde::ser::Error::custom("duration value overflowed u64"))?,
    )
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct GutterConfig {
    /// Gutter Layout
    pub layout: Vec<GutterType>,
    /// Options specific to the "line-numbers" gutter
    pub line_numbers: GutterLineNumbersConfig,
}

impl Default for GutterConfig {
    fn default() -> Self {
        Self {
            layout: vec![
                GutterType::Diagnostics,
                GutterType::Spacer,
                GutterType::LineNumbers,
                GutterType::Spacer,
                GutterType::Diff,
            ],
            line_numbers: GutterLineNumbersConfig::default(),
        }
    }
}

impl From<Vec<GutterType>> for GutterConfig {
    fn from(x: Vec<GutterType>) -> Self {
        GutterConfig {
            layout: x,
            ..Default::default()
        }
    }
}

fn deserialize_gutter_seq_or_struct<'de, D>(deserializer: D) -> Result<GutterConfig, D::Error>
where
    D: Deserializer<'de>,
{
    struct GutterVisitor;

    impl<'de> serde::de::Visitor<'de> for GutterVisitor {
        type Value = GutterConfig;

        fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
            write!(
                formatter,
                "an array of gutter names or a detailed gutter configuration"
            )
        }

        fn visit_seq<S>(self, mut seq: S) -> Result<Self::Value, S::Error>
        where
            S: serde::de::SeqAccess<'de>,
        {
            let mut gutters = Vec::new();
            while let Some(gutter) = seq.next_element::<String>()? {
                gutters.push(
                    gutter
                        .parse::<GutterType>()
                        .map_err(serde::de::Error::custom)?,
                )
            }

            Ok(gutters.into())
        }

        fn visit_map<M>(self, map: M) -> Result<Self::Value, M::Error>
        where
            M: serde::de::MapAccess<'de>,
        {
            let deserializer = serde::de::value::MapAccessDeserializer::new(map);
            Deserialize::deserialize(deserializer)
        }
    }

    deserializer.deserialize_any(GutterVisitor)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct GutterLineNumbersConfig {
    /// Minimum number of characters to use for line number gutter. Defaults to 3.
    pub min_width: usize,
}

impl Default for GutterLineNumbersConfig {
    fn default() -> Self {
        Self { min_width: 3 }
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum InlineBlameShow {
    /// Hide inline blame and skip automatic requests.
    Never,
    /// Show the inline blame on the cursor line
    CursorLine,
    /// Show inline blame on all visible lines
    AllLines,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct InlineBlameConfig {
    /// How to show the inline blame
    pub show: InlineBlameShow,
    /// How the inline blame should look like and the information it includes
    pub format: String,
}

impl Default for InlineBlameConfig {
    fn default() -> Self {
        Self {
            show: InlineBlameShow::Never,
            format: "{author}, {time-ago} • {title} • {commit}".to_owned(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct FilePickerConfig {
    /// IgnoreOptions
    /// Enables ignoring hidden files.
    /// Whether to hide hidden files in file picker and global search results. Defaults to true.
    pub hidden: bool,
    /// Enables following symlinks.
    /// Whether to follow symbolic links in file picker and file or directory completions. Defaults to true.
    pub follow_symlinks: bool,
    /// Hides symlinks that point into the current directory. Defaults to true.
    pub deduplicate_links: bool,
    /// Enables reading ignore files from parent directories. Defaults to true.
    pub parents: bool,
    /// Enables reading `.ignore` files.
    /// Whether to hide files listed in .ignore in file picker and global search results. Defaults to true.
    pub ignore: bool,
    /// Enables reading `.gitignore` files.
    /// Whether to hide files listed in .gitignore in file picker and global search results. Defaults to true.
    pub git_ignore: bool,
    /// Enables reading global .gitignore, whose path is specified in git's config: `core.excludefile` option.
    /// Whether to hide files listed in global .gitignore in file picker and global search results. Defaults to true.
    pub git_global: bool,
    /// Enables reading `.git/info/exclude` files.
    /// Whether to hide files listed in .git/info/exclude in file picker and global search results. Defaults to true.
    pub git_exclude: bool,
    /// WalkBuilder options
    /// Maximum Depth to recurse directories in file picker and global search. Defaults to `None`.
    pub max_depth: Option<usize>,
}

impl Default for FilePickerConfig {
    fn default() -> Self {
        Self {
            hidden: true,
            follow_symlinks: true,
            deduplicate_links: true,
            parents: true,
            ignore: true,
            git_ignore: true,
            git_global: true,
            git_exclude: true,
            max_depth: None,
        }
    }
}

#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct FileExplorerConfig {
    /// IgnoreOptions
    /// Enables ignoring hidden files.
    /// Whether to hide hidden files in file explorer and global search results. Defaults to false.
    pub hidden: bool,
    /// Enables following symlinks.
    /// Whether to follow symbolic links in file picker and file or directory completions. Defaults to false.
    pub follow_symlinks: bool,
    /// Enables reading ignore files from parent directories. Defaults to false.
    pub parents: bool,
    /// Enables reading `.ignore` files.
    /// Whether to hide files listed in .ignore in file picker and global search results. Defaults to false.
    pub ignore: bool,
    /// Enables reading `.gitignore` files.
    /// Whether to hide files listed in .gitignore in file picker and global search results. Defaults to false.
    pub git_ignore: bool,
    /// Enables reading global .gitignore, whose path is specified in git's config: `core.excludefile` option.
    /// Whether to hide files listed in global .gitignore in file picker and global search results. Defaults to false.
    pub git_global: bool,
    /// Enables reading `.git/info/exclude` files.
    /// Whether to hide files listed in .git/info/exclude in file picker and global search results. Defaults to false.
    pub git_exclude: bool,
}

fn serialize_alphabet<S>(alphabet: &[char], serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    let alphabet: String = alphabet.iter().collect();
    serializer.serialize_str(&alphabet)
}

fn deserialize_alphabet<'de, D>(deserializer: D) -> Result<Vec<char>, D::Error>
where
    D: Deserializer<'de>,
{
    use serde::de::Error;

    let str = String::deserialize(deserializer)?;
    let chars: Vec<_> = str.chars().collect();
    let unique_chars: HashSet<_> = chars.iter().copied().collect();
    if unique_chars.len() != chars.len() {
        return Err(<D::Error as Error>::custom(
            "jump-label-alphabet must contain unique characters",
        ));
    }
    Ok(chars)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct Config {
    /// Whether to show the welcome screen when Mitos starts without a file. Defaults to true.
    pub welcome_screen: bool,
    /// Shell to use for shell commands. Defaults to ["cmd", "/C"] on Windows and ["sh", "-c"] otherwise.
    pub shell: Vec<String>,
    /// Line number mode.
    pub line_number: LineNumber,
    #[serde(deserialize_with = "deserialize_gutter_seq_or_struct")]
    pub gutters: GutterConfig,
    /// Automatic insertion of pairs to parentheses, brackets,
    /// etc. A custom `pairs` table maps opening to closing characters.
    /// Defaults to enabled with the built-in pairs.
    pub auto_pairs: AutoPairConfig,
    /// Set a global text_width
    pub text_width: usize,
    /// Time in milliseconds since last keypress before idle timers trigger.
    /// Used for various UI timeouts. Defaults to 250ms.
    #[serde(
        serialize_with = "serialize_duration_millis",
        deserialize_with = "deserialize_duration_millis"
    )]
    pub idle_timeout: Duration,
    /// `true` if mitos should automatically add a line comment token if you're currently in a comment
    /// and press `enter`.
    pub continue_comments: bool,
    /// Whether to display infoboxes. Defaults to true.
    pub auto_info: bool,
    /// Whether to show icons in the user interface. Defaults to false.
    pub icons: bool,
    pub file_picker: FilePickerConfig,
    pub file_explorer: FileExplorerConfig,
    /// Configuration of the statusline elements
    pub statusline: StatusLineConfig,
    /// Search configuration.
    #[serde(default)]
    pub search: SearchConfig,
    pub lsp: LspConfig,
    /// Column numbers at which to draw the rulers. Defaults to `[]`, meaning no rulers.
    pub rulers: Vec<u16>,
    #[serde(default)]
    pub whitespace: WhitespaceConfig,
    /// Persistently display breadcrumb along the top of each view, below any bufferline.
    pub breadcrumb: BreadcrumbConfig,
    /// Vertical indent width guides.
    pub indent_guides: IndentGuidesConfig,
    pub soft_wrap: SoftWrap,
    /// labels characters used in jumpmode
    #[serde(
        serialize_with = "serialize_alphabet",
        deserialize_with = "deserialize_alphabet"
    )]
    pub jump_label_alphabet: Vec<char>,
    /// Show information about the commit that last changed a line.
    pub inline_blame: InlineBlameConfig,
    /// Spell checking: which dictionaries to use and how to filter tokens. Off by default (no
    /// dictionaries); languages can override this in `languages.toml`.
    pub spelling: SpellingConfig,
    pub buffer_picker: BufferPickerConfig,
    /// Workspace-trust configuration.
    pub workspace_trust: WorkspaceTrustConfig,
    /// Commands defined in the top-level `[commands]` configuration table.
    #[serde(skip)]
    pub commands: CustomCommands,
    pub scroll: ScrollConfig,
    pub mouse: MouseConfig,
    pub cursor: CursorConfig,
    pub completion: CompletionConfig,
    pub inline_completion: InlineCompletionConfig,
    pub format: FormatConfig,
    pub clipboard: ClipboardConfig,
    pub files: FilesConfig,
    pub diagnostics: DiagnosticsConfig,
    pub indent: IndentConfig,
    pub bufferline: BufferLineConfig,
    pub rainbow_brackets: RainbowBracketsConfig,
}

/// User-facing configuration for `[editor.workspace-trust]`.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Deserialize, Serialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct WorkspaceTrustConfig {
    /// What to trust implicitly without an explicit grant. See [`ImplicitTrustLevelConfig`].
    pub level: ImplicitTrustLevelConfig,
    /// Whether opening a file in an untrusted workspace surfaces the trust modal. The statusline
    /// `[⚠]` indicator is always shown either way; disabling the prompt is for users who would
    /// rather act explicitly via `:workspace-trust` than be interrupted. Defaults to `true`.
    pub prompt: bool,
    /// Glob patterns whose matching workspaces are implicitly trusted.
    pub trusted: Vec<String>,
}

impl Default for WorkspaceTrustConfig {
    fn default() -> Self {
        Self {
            level: ImplicitTrustLevelConfig::default(),
            prompt: true,
            trusted: Vec::new(),
        }
    }
}

#[derive(Debug, Default, PartialEq, Eq, PartialOrd, Ord, Deserialize, Serialize, Clone, Copy)]
#[serde(rename_all = "kebab-case")]
pub enum ImplicitTrustLevelConfig {
    /// Don't trust anything implicitly — prompt for every new workspace.
    None,
    /// Trust Mitos-launched server processes (LSP and DAP) implicitly. Workspace-local config and
    /// git full-trust still require explicit `:workspace-trust`. This is the default — language
    /// servers are configured globally, so auto-starting them in fresh workspaces matches user
    /// expectations while the workspace-controlled `.mitos/` config still requires opt-in.
    #[default]
    Servers,
    /// Trust everything implicitly. Explicit excludes still win.
    Insecure,
}

impl From<ImplicitTrustLevelConfig> for ImplicitTrustLevel {
    fn from(v: ImplicitTrustLevelConfig) -> Self {
        match v {
            ImplicitTrustLevelConfig::None => ImplicitTrustLevel::None,
            ImplicitTrustLevelConfig::Servers => ImplicitTrustLevel::Servers,
            ImplicitTrustLevelConfig::Insecure => ImplicitTrustLevel::Insecure,
        }
    }
}

impl From<&WorkspaceTrustConfig> for workspace::trust::Config {
    fn from(v: &WorkspaceTrustConfig) -> Self {
        Self {
            level: v.level.into(),
            prompt: v.prompt,
            trusted_globs: workspace::trust::build_trusted_globs(&v.trusted),
        }
    }
}

impl Config {
    pub fn code_action_hint(&self) -> bool {
        self.gutters.layout.contains(&GutterType::CodeActionHint)
            || self
                .statusline
                .left
                .contains(&StatusLineElement::CodeActionHint)
            || self
                .statusline
                .right
                .contains(&StatusLineElement::CodeActionHint)
    }
}

#[derive(Debug, Default, PartialEq, Eq, PartialOrd, Ord, Deserialize, Serialize, Clone, Copy)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct BreadcrumbConfig {
    pub enable: bool,
    #[serde(default)]
    pub path: BreadcrumbPathOptions,
}

#[derive(Debug, Default, PartialEq, Eq, PartialOrd, Ord, Deserialize, Serialize, Clone, Copy)]
#[serde(rename_all = "kebab-case")]
pub enum BreadcrumbPathOptions {
    #[default]
    Full,
    File,
    None,
}

#[derive(Debug, Default, PartialEq, Eq, PartialOrd, Ord, Deserialize, Serialize, Clone, Copy)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct BufferPickerConfig {
    pub start_position: PickerStartPosition,
}

#[derive(Debug, Default, PartialEq, Eq, PartialOrd, Ord, Deserialize, Serialize, Clone, Copy)]
#[serde(rename_all = "kebab-case")]
pub enum PickerStartPosition {
    #[default]
    Current,
    Previous,
}

impl PickerStartPosition {
    #[must_use]
    pub fn is_previous(self) -> bool {
        matches!(self, Self::Previous)
    }

    #[must_use]
    pub fn is_current(self) -> bool {
        matches!(self, Self::Current)
    }
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize, Eq, PartialOrd, Ord)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct SmartTabConfig {
    pub enable: bool,
    pub supersede_menu: bool,
}

impl Default for SmartTabConfig {
    fn default() -> Self {
        SmartTabConfig {
            enable: true,
            supersede_menu: false,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspConfig {
    pub enable: bool,
    /// Workspace-relative ceilings for language-server root discovery.
    pub workspace_roots: Vec<PathBuf>,
    pub progress: LspProgressConfig,
    pub messages: LspMessagesConfig,
    pub signature_help: LspSignatureHelpConfig,
    pub inlay_hints: LspInlayHintsConfig,
    pub document_highlight: LspDocumentHighlightConfig,
    pub color_swatches: LspColorSwatchesConfig,
    pub code_lenses: LspCodeLensesConfig,
    pub completion: LspCompletionConfig,
    pub references: LspReferencesConfig,
}

impl Default for LspConfig {
    fn default() -> Self {
        Self {
            enable: true,
            workspace_roots: Vec::new(),
            progress: LspProgressConfig::default(),
            messages: LspMessagesConfig::default(),
            signature_help: LspSignatureHelpConfig::default(),
            inlay_hints: LspInlayHintsConfig::default(),
            document_highlight: LspDocumentHighlightConfig::default(),
            color_swatches: LspColorSwatchesConfig::default(),
            code_lenses: LspCodeLensesConfig::default(),
            completion: LspCompletionConfig::default(),
            references: LspReferencesConfig::default(),
        }
    }
}

#[derive(Default, Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspProgressConfig {
    pub enable: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspMessagesConfig {
    pub enable: bool,
}

impl Default for LspMessagesConfig {
    fn default() -> Self {
        Self { enable: true }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspSignatureHelpConfig {
    pub auto_trigger: bool,
    pub show_documentation: bool,
}

impl Default for LspSignatureHelpConfig {
    fn default() -> Self {
        Self {
            auto_trigger: true,
            show_documentation: true,
        }
    }
}

#[derive(Default, Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspInlayHintsConfig {
    pub enable: bool,
    pub length_limit: Option<NonZeroU8>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspDocumentHighlightConfig {
    pub auto_trigger: bool,
}

impl Default for LspDocumentHighlightConfig {
    fn default() -> Self {
        Self { auto_trigger: true }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspColorSwatchesConfig {
    pub enable: bool,
}

impl Default for LspColorSwatchesConfig {
    fn default() -> Self {
        Self { enable: true }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspCodeLensesConfig {
    pub enable: bool,
}

impl Default for LspCodeLensesConfig {
    fn default() -> Self {
        Self { enable: true }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspCompletionConfig {
    pub snippets: bool,
}

impl Default for LspCompletionConfig {
    fn default() -> Self {
        Self { snippets: true }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct LspReferencesConfig {
    pub include_declaration: bool,
}

impl Default for LspReferencesConfig {
    fn default() -> Self {
        Self {
            include_declaration: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct SearchConfig {
    /// Smart case: Case insensitive searching unless pattern contains upper case characters. Defaults to true.
    pub smart_case: bool,
    /// Whether the search should wrap after depleting the matches. Default to true.
    pub wrap_around: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct StatusLineConfig {
    /// Show one statusline for the focused view instead of one per view.
    pub global: bool,
    pub left: Vec<StatusLineElement>,
    pub right: Vec<StatusLineElement>,
    pub separator: String,
    pub mode: ModeConfig,
    pub diagnostics: Vec<Severity>,
    pub workspace_diagnostics: Vec<Severity>,
}

impl Default for StatusLineConfig {
    fn default() -> Self {
        use StatusLineElement as E;

        Self {
            global: false,
            left: vec![
                E::Mode,
                E::Spinner,
                E::Branch,
                E::FileName,
                E::ReadOnlyIndicator,
                E::FileModificationIndicator,
            ],
            right: vec![
                E::Diagnostics,
                E::Selections,
                E::Register,
                E::Position,
                E::FileEncoding,
            ],
            separator: String::from("│"),
            mode: ModeConfig::default(),
            diagnostics: vec![Severity::Warning, Severity::Error],
            workspace_diagnostics: vec![Severity::Warning, Severity::Error],
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", default, deny_unknown_fields)]
pub struct ModeConfig {
    pub color: bool,
    pub normal: String,
    pub insert: String,
    pub select: String,
}

impl Default for ModeConfig {
    fn default() -> Self {
        Self {
            color: false,
            normal: String::from("NOR"),
            insert: String::from("INS"),
            select: String::from("SEL"),
        }
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum StatusLineElement {
    /// The editor mode (Normal, Insert, Visual/Selection)
    Mode,

    /// The LSP activity spinner
    Spinner,

    /// The file basename (the leaf of the open file's path)
    FileBaseName,

    /// The relative file path
    FileName,

    /// The file absolute path
    FileAbsolutePath,

    // The file modification indicator
    FileModificationIndicator,

    /// An indicator that shows `"[readonly]"` when a file cannot be written
    ReadOnlyIndicator,

    /// The file encoding
    FileEncoding,

    /// The file line endings (CRLF or LF)
    FileLineEnding,

    /// The file indentation style
    FileIndentStyle,

    /// The file type (language ID or "text")
    FileType,

    /// A summary of the number of errors and warnings
    Diagnostics,

    /// A summary of the number of errors and warnings on file and workspace
    WorkspaceDiagnostics,

    /// The number of selections (cursors)
    Selections,

    /// The number of characters currently in primary selection
    PrimarySelectionLength,

    /// The cursor position
    Position,

    /// The separator string
    Separator,

    /// The cursor position as a percent of the total file
    PositionPercentage,

    /// The total line numbers of the current file
    TotalLineNumbers,

    /// A single space
    Spacer,

    /// The current branch name, or detached commit hash
    Branch,

    /// Indicator for selected register
    Register,

    /// The base of current working directory
    CurrentWorkingDirectory,

    /// Indicator for when code actions are available
    CodeActionHint,
}

/// Cursor shapes for each editor mode.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct CursorShapeConfig {
    pub normal: CursorKind,
    pub select: CursorKind,
    pub insert: CursorKind,
}

/// bufferline render modes
#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum BufferLine {
    /// Don't render bufferline
    #[default]
    Never,
    /// Always render
    Always,
    /// Only if multiple buffers are open
    Multiple,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum LineNumber {
    /// Show absolute line number
    Absolute,

    /// If focused and in normal/select mode, show relative line number to the primary cursor.
    /// If unfocused or in insert mode, show absolute line number.
    Relative,
}

impl std::str::FromStr for LineNumber {
    type Err = anyhow::Error;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "absolute" | "abs" => Ok(Self::Absolute),
            "relative" | "rel" => Ok(Self::Relative),
            _ => anyhow::bail!("Line number can only be `absolute` or `relative`."),
        }
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum GutterType {
    /// Show diagnostics and other features like breakpoints
    Diagnostics,
    /// Show line numbers
    LineNumbers,
    /// Show one blank space
    Spacer,
    /// Highlight local changes
    Diff,
    /// Indicator for when code actions are available
    CodeActionHint,
}

impl std::str::FromStr for GutterType {
    type Err = anyhow::Error;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "diagnostics" => Ok(Self::Diagnostics),
            "spacer" => Ok(Self::Spacer),
            "line-numbers" => Ok(Self::LineNumbers),
            "diff" => Ok(Self::Diff),
            "code-action-hint" => Ok(Self::CodeActionHint),
            _ => anyhow::bail!(
                "Gutter type can only be `diagnostics`, `spacer`, `line-numbers` or `diff`."
            ),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct WhitespaceConfig {
    pub render: WhitespaceRender,
    pub characters: WhitespaceCharacters,
}

impl Default for WhitespaceConfig {
    fn default() -> Self {
        Self {
            render: WhitespaceRender::Basic(WhitespaceRenderValue::None),
            characters: WhitespaceCharacters::default(),
        }
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged, rename_all = "kebab-case", deny_unknown_fields)]
pub enum WhitespaceRender {
    Basic(WhitespaceRenderValue),
    Specific {
        default: Option<WhitespaceRenderValue>,
        space: Option<WhitespaceRenderValue>,
        nbsp: Option<WhitespaceRenderValue>,
        nnbsp: Option<WhitespaceRenderValue>,
        tab: Option<WhitespaceRenderValue>,
        newline: Option<WhitespaceRenderValue>,
    },
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum WhitespaceRenderValue {
    None,
    // TODO
    // Selection,
    All,
}

impl WhitespaceRender {
    pub fn space(&self) -> WhitespaceRenderValue {
        match *self {
            Self::Basic(val) => val,
            Self::Specific { default, space, .. } => {
                space.or(default).unwrap_or(WhitespaceRenderValue::None)
            }
        }
    }
    pub fn nbsp(&self) -> WhitespaceRenderValue {
        match *self {
            Self::Basic(val) => val,
            Self::Specific { default, nbsp, .. } => {
                nbsp.or(default).unwrap_or(WhitespaceRenderValue::None)
            }
        }
    }
    pub fn nnbsp(&self) -> WhitespaceRenderValue {
        match *self {
            Self::Basic(val) => val,
            Self::Specific { default, nnbsp, .. } => {
                nnbsp.or(default).unwrap_or(WhitespaceRenderValue::None)
            }
        }
    }
    pub fn tab(&self) -> WhitespaceRenderValue {
        match *self {
            Self::Basic(val) => val,
            Self::Specific { default, tab, .. } => {
                tab.or(default).unwrap_or(WhitespaceRenderValue::None)
            }
        }
    }
    pub fn newline(&self) -> WhitespaceRenderValue {
        match *self {
            Self::Basic(val) => val,
            Self::Specific {
                default, newline, ..
            } => newline.or(default).unwrap_or(WhitespaceRenderValue::None),
        }
    }
}

#[derive(Debug, Default, Clone, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case", deny_unknown_fields)]
pub struct AutoSave {
    /// Auto save after a delay in milliseconds. Defaults to disabled.
    #[serde(default)]
    pub after_delay: AutoSaveAfterDelay,
    /// Auto save on focus lost. Defaults to false.
    #[serde(default)]
    pub focus_lost: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AutoSaveAfterDelay {
    #[serde(default)]
    /// Enable auto save after delay. Defaults to false.
    pub enable: bool,
    #[serde(default = "default_auto_save_delay")]
    /// Time delay in milliseconds. Defaults to [DEFAULT_AUTO_SAVE_DELAY].
    pub timeout: u64,
}

impl Default for AutoSaveAfterDelay {
    fn default() -> Self {
        Self {
            enable: false,
            timeout: DEFAULT_AUTO_SAVE_DELAY,
        }
    }
}

fn default_auto_save_delay() -> u64 {
    DEFAULT_AUTO_SAVE_DELAY
}

fn deserialize_auto_save<'de, D>(deserializer: D) -> Result<AutoSave, D::Error>
where
    D: serde::Deserializer<'de>,
{
    #[derive(Deserialize, Serialize)]
    #[serde(untagged, deny_unknown_fields, rename_all = "kebab-case")]
    enum AutoSaveToml {
        EnableFocusLost(bool),
        AutoSave(AutoSave),
    }

    match AutoSaveToml::deserialize(deserializer)? {
        AutoSaveToml::EnableFocusLost(focus_lost) => Ok(AutoSave {
            focus_lost,
            ..Default::default()
        }),
        AutoSaveToml::AutoSave(auto_save) => Ok(auto_save),
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct WhitespaceCharacters {
    pub space: char,
    pub nbsp: char,
    pub nnbsp: char,
    pub tab: char,
    pub tabpad: char,
    pub newline: char,
}

impl Default for WhitespaceCharacters {
    fn default() -> Self {
        Self {
            space: '·',   // U+00B7
            nbsp: '⍽',    // U+237D
            nnbsp: '␣',   // U+2423
            tab: '→',     // U+2192
            newline: '⏎', // U+23CE
            tabpad: ' ',
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct IndentGuidesConfig {
    pub render: bool,
    pub character: char,
    pub skip_levels: u8,
}

impl Default for IndentGuidesConfig {
    fn default() -> Self {
        Self {
            skip_levels: 0,
            render: false,
            character: '│',
        }
    }
}

/// Line ending configuration.
#[derive(Default, Debug, Copy, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LineEndingConfig {
    /// The platform's native line ending.
    ///
    /// `crlf` on Windows, otherwise `lf`.
    #[default]
    Native,
    /// Line feed.
    LF,
    /// Carriage return followed by line feed.
    Crlf,
    /// Form feed.
    #[cfg(feature = "unicode-lines")]
    FF,
    /// Carriage return.
    #[cfg(feature = "unicode-lines")]
    CR,
    /// Next line.
    #[cfg(feature = "unicode-lines")]
    Nel,
}

impl From<LineEndingConfig> for LineEnding {
    fn from(line_ending: LineEndingConfig) -> Self {
        match line_ending {
            LineEndingConfig::Native => NATIVE_LINE_ENDING,
            LineEndingConfig::LF => LineEnding::LF,
            LineEndingConfig::Crlf => LineEnding::Crlf,
            #[cfg(feature = "unicode-lines")]
            LineEndingConfig::FF => LineEnding::FF,
            #[cfg(feature = "unicode-lines")]
            LineEndingConfig::CR => LineEnding::CR,
            #[cfg(feature = "unicode-lines")]
            LineEndingConfig::Nel => LineEnding::Nel,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct WordCompletion {
    pub enable: bool,
    pub trigger_length: NonZeroU8,
}

impl Default for WordCompletion {
    fn default() -> Self {
        Self {
            enable: true,
            trigger_length: NonZeroU8::new(7).unwrap(),
        }
    }
}

impl Default for Config {
    fn default() -> Self {
        Self {
            welcome_screen: true,
            shell: if cfg!(windows) {
                vec!["cmd".to_owned(), "/C".to_owned()]
            } else {
                vec!["sh".to_owned(), "-c".to_owned()]
            },
            line_number: LineNumber::Absolute,
            gutters: GutterConfig::default(),
            auto_pairs: AutoPairConfig::default(),
            text_width: 80,
            idle_timeout: Duration::from_millis(250),
            continue_comments: true,
            auto_info: true,
            icons: false,
            file_picker: FilePickerConfig::default(),
            file_explorer: FileExplorerConfig::default(),
            statusline: StatusLineConfig::default(),
            search: SearchConfig::default(),
            lsp: LspConfig::default(),
            rulers: Vec::new(),
            whitespace: WhitespaceConfig::default(),
            breadcrumb: BreadcrumbConfig::default(),
            indent_guides: IndentGuidesConfig::default(),
            soft_wrap: SoftWrap {
                enable: Some(false),
                ..SoftWrap::default()
            },
            jump_label_alphabet: ('a'..='z').collect(),
            inline_blame: InlineBlameConfig::default(),
            spelling: SpellingConfig::default(),
            buffer_picker: BufferPickerConfig::default(),
            workspace_trust: WorkspaceTrustConfig::default(),
            commands: CustomCommands::default(),
            scroll: ScrollConfig::default(),
            mouse: MouseConfig::default(),
            cursor: CursorConfig::default(),
            completion: CompletionConfig::default(),
            inline_completion: InlineCompletionConfig::default(),
            format: FormatConfig::default(),
            clipboard: ClipboardConfig::default(),
            files: FilesConfig::default(),
            diagnostics: DiagnosticsConfig::default(),
            indent: IndentConfig::default(),
            bufferline: BufferLineConfig::default(),
            rainbow_brackets: RainbowBracketsConfig::default(),
        }
    }
}

impl Default for SearchConfig {
    fn default() -> Self {
        Self {
            wrap_around: true,
            smart_case: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize, Eq, PartialOrd, Ord)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct AutoReloadConfig {
    pub enable: bool,
    pub prompt_if_modified: bool,
    /// Poll for changes to files outside the watched workspace
    pub poll: AutoReloadPoll,
}

impl Default for AutoReloadConfig {
    fn default() -> Self {
        AutoReloadConfig {
            enable: true,
            prompt_if_modified: true,
            poll: AutoReloadPoll::default(),
        }
    }
}

/// Configuration for polling unwatched files for external changes
#[derive(Debug, Clone, PartialEq, Deserialize, Serialize, Eq, PartialOrd, Ord)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct AutoReloadPoll {
    /// Enable polling for files outside the watched workspace
    pub enable: bool,
    /// Polling interval in milliseconds (default: 30000). This is only a backstop:
    /// unwatched files are normally re-checked when the terminal regains focus.
    pub interval: u64,
}

impl Default for AutoReloadPoll {
    fn default() -> Self {
        AutoReloadPoll {
            enable: true,
            interval: 30000,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct ScrollConfig {
    /// Padding to keep between the edge of the screen and the cursor when scrolling. Defaults to 5.
    pub padding: usize,
    /// Number of lines to scroll at once. Defaults to 3
    pub wheel_lines: isize,
}

impl Default for ScrollConfig {
    fn default() -> Self {
        Self {
            padding: 5,
            wheel_lines: 3,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct MouseConfig {
    /// Mouse support. Defaults to true.
    pub enable: bool,
    /// Which register to use for mouse yank.
    pub yank_register: char,
    /// Middle click paste support. Defaults to true.
    pub middle_click_paste: bool,
}

impl Default for MouseConfig {
    fn default() -> Self {
        Self {
            enable: true,
            yank_register: '*',
            middle_click_paste: true,
        }
    }
}

#[derive(Default, Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct CursorConfig {
    /// Highlight the lines cursors are currently on. Defaults to false.
    pub highlight_line: bool,
    /// Highlight the columns cursors are currently on. Defaults to false.
    pub highlight_column: bool,
    /// Shape for cursor in each mode
    pub shape: CursorShapeConfig,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct CompletionConfig {
    /// Automatic auto-completion, automatically pop up without user trigger. Defaults to true.
    pub auto_trigger: bool,
    /// Configures completion of words from open buffers.
    /// Defaults to enabled with a trigger length of 7.
    pub word: WordCompletion,
    /// Time in milliseconds after typing a word character before auto completions
    /// are shown, set to 5 for instant. Defaults to 250ms.
    #[serde(
        serialize_with = "serialize_duration_millis",
        deserialize_with = "deserialize_duration_millis"
    )]
    pub trigger_delay: Duration,
    /// Whether to insert the completion suggestion on hover. Defaults to true.
    pub preview_insert: bool,
    pub trigger_length: u8,
    /// Whether to instruct the LSP to replace the entire word when applying a completion
    /// or to only insert new text
    pub replace: bool,
    pub path: PathCompletionConfig,
}

impl Default for CompletionConfig {
    fn default() -> Self {
        Self {
            auto_trigger: true,
            word: WordCompletion::default(),
            trigger_delay: Duration::from_millis(250),
            preview_insert: true,
            trigger_length: 2,
            replace: false,
            path: PathCompletionConfig::default(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct InlineCompletionConfig {
    /// Delay after editing before requesting ghost text.
    #[serde(
        serialize_with = "serialize_duration_millis",
        deserialize_with = "deserialize_duration_millis"
    )]
    pub trigger_delay: Duration,
    /// Request ghost text automatically in insert mode.
    pub auto_trigger: bool,
}

impl Default for InlineCompletionConfig {
    fn default() -> Self {
        Self {
            trigger_delay: Duration::from_millis(150),
            auto_trigger: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct FormatConfig {
    /// Automatic formatting on save. Defaults to true.
    pub on_save: bool,
}

impl Default for FormatConfig {
    fn default() -> Self {
        Self { on_save: true }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct ClipboardConfig {
    /// Default register used for yank/paste. Defaults to '"'
    pub default_yank_register: char,
    // Set to override the default clipboard provider
    pub provider: ClipboardProvider,
}

impl Default for ClipboardConfig {
    fn default() -> Self {
        Self {
            default_yank_register: '"',
            provider: ClipboardProvider::default(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct FilesConfig {
    /// Automatic save on focus lost and/or after delay.
    /// Time delay in milliseconds since last edit after which auto save timer triggers.
    /// Time delay defaults to false with 3000ms delay. Focus lost defaults to false.
    #[serde(deserialize_with = "deserialize_auto_save")]
    pub auto_save: AutoSave,
    /// Which line ending to choose for new documents. Defaults to `native`. i.e. `crlf` on Windows, otherwise `lf`.
    pub default_line_ending: LineEndingConfig,
    /// Whether to read settings from [EditorConfig](https://editorconfig.org) files. Defaults to
    /// `true`.
    pub editor_config: bool,
    pub reload: AutoReloadConfig,
    pub watch: WatchConfig,
    pub save: SaveConfig,
}

impl Default for FilesConfig {
    fn default() -> Self {
        Self {
            auto_save: AutoSave::default(),
            default_line_ending: LineEndingConfig::default(),
            editor_config: true,
            reload: AutoReloadConfig::default(),
            watch: WatchConfig::default(),
            save: SaveConfig::default(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct SaveConfig {
    /// Whether to automatically insert a trailing line-ending on write if missing. Defaults to `true`.
    pub insert_final_newline: bool,
    /// Whether to use atomic operations to write documents to disk.
    /// This prevents data loss if the editor is interrupted while writing the file, but may
    /// confuse some file watching/hot reloading programs. Defaults to `true`.
    pub atomic: bool,
    /// Whether to automatically remove all trailing line-endings after the final one on write.
    /// Defaults to `false`.
    pub trim_final_newlines: bool,
    /// Whether to automatically remove all whitespace characters preceding line-endings on write.
    /// Defaults to `false`.
    pub trim_trailing_whitespace: bool,
}

impl Default for SaveConfig {
    fn default() -> Self {
        Self {
            insert_final_newline: true,
            atomic: true,
            trim_final_newlines: false,
            trim_trailing_whitespace: false,
        }
    }
}

#[derive(Default, Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct DiagnosticsConfig {
    /// Display diagnostic below the line they occur.
    pub inline: InlineDiagnosticsConfig,
    pub end_of_line: EndOfLineDiagnosticsConfig,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct EndOfLineDiagnosticsConfig {
    pub severity: DiagnosticFilter,
}

impl Default for EndOfLineDiagnosticsConfig {
    fn default() -> Self {
        Self {
            severity: DiagnosticFilter::Enable(Severity::Hint),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct IndentConfig {
    /// Enables smart tab
    pub smart_tab: Option<SmartTabConfig>,
    /// Which indent heuristic to use when a new line is inserted
    #[serde(default)]
    pub heuristic: IndentationHeuristic,
}

impl Default for IndentConfig {
    fn default() -> Self {
        Self {
            smart_tab: Some(SmartTabConfig::default()),
            heuristic: IndentationHeuristic::default(),
        }
    }
}

#[derive(Default, Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct BufferLineConfig {
    /// Persistently display open buffers along the top
    pub show: BufferLine,
}

#[derive(Default, Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct RainbowBracketsConfig {
    /// Whether to render rainbow colors for matching brackets. Defaults to `false`.
    pub enable: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct PathCompletionConfig {
    /// Enable filepath completion.
    /// Show files and directories if an existing path at the cursor was recognized,
    /// either absolute or relative to the current opened document or current working directory (if the buffer is not yet saved).
    /// Defaults to true.
    pub enable: bool,
}

impl Default for PathCompletionConfig {
    fn default() -> Self {
        Self { enable: true }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cursor_shapes_default_each_omitted_mode() {
        let shapes: CursorShapeConfig = toml::from_str("insert = 'bar'").unwrap();
        assert_eq!(shapes.normal, CursorKind::Block);
        assert_eq!(shapes.select, CursorKind::Block);
        assert_eq!(shapes.insert, CursorKind::Bar);
        let serialized = toml::to_string(&shapes).unwrap();
        assert_eq!(
            toml::from_str::<CursorShapeConfig>(&serialized).unwrap(),
            shapes
        );
        assert!(toml::from_str::<CursorShapeConfig>("unknown = 'bar'").is_err());
    }

    #[test]
    fn watcher_and_diagnostic_settings_keep_their_file_format() {
        let config: Config = toml::from_str(
            "[files.watch]\nmax-depth = 3\n[diagnostics.inline]\ncursor-line = 'error'",
        )
        .unwrap();
        assert_eq!(config.files.watch.max_depth, Some(3));
        assert!(config.files.watch.enable);
        assert_eq!(
            config.diagnostics.inline.cursor_line,
            DiagnosticFilter::Enable(Severity::Error)
        );
        assert_eq!(
            config.diagnostics.inline.other_lines,
            DiagnosticFilter::Disable
        );
    }
}
