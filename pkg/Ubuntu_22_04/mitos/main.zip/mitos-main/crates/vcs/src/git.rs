use anyhow::{bail, Context, Result};
use arc_swap::ArcSwap;
use gix::filter::plumbing::driver::apply::Delay;
use std::collections::BTreeMap;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use gix::bstr::{BString, ByteSlice, ByteVec};
use gix::diff::{index::Change as IndexChange, Rewrites};
use gix::dir::entry::Status;
use gix::objs::tree::EntryKind;
use gix::sec::trust::DefaultForLevel;
use gix::status::{
    index_worktree::Item,
    plumbing::index_as_worktree::{Change, EntryStatus},
    tree_index::TrackRenames,
    Item as StatusItem, UntrackedFiles,
};
use gix::{Commit, ObjectId, Repository, ThreadSafeRepository};

use crate::{ChangedFileScope, FileChange};

#[cfg(test)]
pub(super) mod test;

#[inline]
pub(super) fn get_repo_dir(file: &Path) -> Result<&Path> {
    file.parent().context("file has no parent directory")
}

pub fn get_diff_base(file: &Path, trust_full: bool) -> Result<Vec<u8>> {
    debug_assert!(!file.exists() || file.is_file());
    debug_assert!(file.is_absolute());
    let file = gix::path::realpath(file).context("resolve symlinks")?;

    // TODO cache repository lookup

    let repo_dir = get_repo_dir(&file)?;
    let repo = open_repo(repo_dir, trust_full)
        .context("failed to open git repo")?
        .to_thread_local();
    let head = repo.head_commit()?;
    let file_oid = find_file_in_commit(&repo, &head, &file)?;

    let file_object = repo.find_object(file_oid)?;
    let data = file_object.detach().data;
    // Get the actual data that git would make out of the git object.
    // This will apply the user's git config or attributes like crlf conversions.
    //
    // The whole filter pipeline still runs in untrusted (`Trust::Reduced`) mode so built-in
    // conversions like autocrlf keep working, but gix drops `filter.*.clean` / `filter.*.smudge`
    // drivers defined in untrusted (repository-local) config, so those external programs are not
    // executed unless the workspace was explicitly trusted. This relies on `open_repo` forcing the
    // trust level instead of letting gix re-derive it from `.git` ownership; see the note there.
    if let Some(work_dir) = repo.workdir() {
        let rela_path = file.strip_prefix(work_dir)?;
        let rela_path = gix::path::try_into_bstr(rela_path)?;
        let (mut pipeline, _) = repo.filter_pipeline(None)?;
        let mut worktree_outcome =
            pipeline.convert_to_worktree(&data, rela_path.as_ref(), Delay::Forbid)?;
        let mut buf = Vec::with_capacity(data.len());
        worktree_outcome.read_to_end(&mut buf)?;
        Ok(buf)
    } else {
        Ok(data)
    }
}

pub fn get_current_head_name(file: &Path, trust_full: bool) -> Result<Arc<ArcSwap<Box<str>>>> {
    debug_assert!(!file.exists() || file.is_file());
    debug_assert!(file.is_absolute());
    let file = gix::path::realpath(file).context("resolve symlinks")?;

    let repo_dir = get_repo_dir(&file)?;
    let repo = open_repo(repo_dir, trust_full)
        .context("failed to open git repo")?
        .to_thread_local();
    let head_ref = repo.head_ref()?;
    let head_commit = repo.head_commit()?;

    let name = match head_ref {
        Some(reference) => reference.name().shorten().to_string(),
        None => head_commit.id.to_hex_with_len(8).to_string(),
    };

    Ok(Arc::new(ArcSwap::from_pointee(name.into_boxed_str())))
}

pub fn for_each_changed_file(
    scope: &ChangedFileScope,
    trust_full: bool,
    f: impl Fn(&Path, Result<FileChange>) -> bool,
) -> Result<()> {
    status(
        &open_repo(scope.path(), trust_full)?.to_thread_local(),
        scope,
        f,
    )
}

/// Watch HEAD, the current branch ref, and packed refs, including linked worktrees.
pub fn get_watched_paths(path: &Path, trust_full: bool) -> Result<Vec<PathBuf>> {
    let repo = open_repo(path, trust_full)?.to_thread_local();
    let git_dir = repo.git_dir().canonicalize()?;
    let common_dir = repo.common_dir().canonicalize()?;
    let mut paths = vec![git_dir.join("HEAD"), common_dir.join("packed-refs")];
    if let Some(head) = repo.head_name()? {
        paths.push(common_dir.join(head.as_bstr().to_str()?));
    }
    Ok(paths)
}

pub(super) fn open_repo(path: &Path, trust_full: bool) -> Result<ThreadSafeRepository> {
    // `trust_full` is the workspace-trust decision made by the caller, and it must be the
    // authority on the gix trust level. gix's own discovery (`discover_*`) ignores a
    // caller-supplied trust level: it always re-derives trust from `.git` ownership, so a malicious
    // `.git/config` in a user-owned directory would be opened as `Trust::Full` regardless of our
    // gate. Worse, the GIT_DIR-environment branch of that discovery panics because it never sets a
    // trust level at all. So we split discovery from opening: find the repository path ourselves,
    // then `open_opts(..).with(trust)`, which forces the trust level and skips gix's ownership
    // check. Under `Trust::Reduced`, gix then refuses to honor untrusted repository-local config
    // such as `filter.*` smudge/clean drivers.

    let trust = if trust_full {
        gix::sec::Trust::Full
    } else {
        gix::sec::Trust::Reduced
    };

    // On Windows various configuration options are bundled as part of the git installation. The
    // lookup is expensive; only do it there.
    let config = gix::open::permissions::Config {
        system: true,
        git: true,
        user: true,
        env: true,
        includes: true,
        git_binary: cfg!(windows),
    };

    let permissions = gix::open::Permissions {
        config,
        ..gix::open::Permissions::default_for_level(trust)
    };

    let discover_options = gix::discover::upwards::Options {
        dot_git_only: true,
        ..Default::default()
    };
    let (repo_path, _trust_from_ownership) = gix::discover::upwards_opts(path, discover_options)
        .context("failed to discover git repo")?;
    let (git_dir, _work_dir) = repo_path.into_repository_and_work_tree_directories();

    let options = gix::open::Options::default()
        .permissions(permissions)
        // `git_dir` is the discovered `.git` directory (or a linked-worktree git dir), so open it
        // as-is rather than letting gix append `.git` again.
        .open_path_as_is(true)
        .with(trust);

    Ok(ThreadSafeRepository::open_opts(git_dir, options)?)
}

/// Emulates the result of running `git status` from the command line.
fn status(
    repo: &Repository,
    scope: &ChangedFileScope,
    f: impl Fn(&Path, Result<FileChange>) -> bool,
) -> Result<()> {
    let work_dir = repo
        .workdir()
        .ok_or_else(|| anyhow::anyhow!("working tree not found"))?
        .to_path_buf();

    let rewrites = Rewrites {
        copies: None,
        percentage: Some(0.5),
        limit: 1000,
        ..Default::default()
    };
    let status_platform = repo
        .status(gix::progress::Discard)?
        // Here we discard the `status.showUntrackedFiles` config, as it makes little sense in
        // our case to not list new (untracked) files. We could have respected this config
        // if the default value weren't `Collapsed` though, as this default value would render
        // the feature unusable to many.
        .untracked_files(UntrackedFiles::Files)
        // Detect renames in both the staging area and the working tree.
        .index_worktree_rewrites(Some(rewrites))
        .tree_index_track_renames(TrackRenames::Given(rewrites));

    let patterns = status_patterns(&work_dir, scope)?;

    let status_iter = status_platform.into_iter(patterns)?;
    // The two comparisons arrive in arbitrary order. Collect them per path so
    // partially staged files appear once with a deterministic status.
    #[derive(Default)]
    struct FileChanges {
        staged: Option<FileChange>,
        worktree: Option<FileChange>,
    }
    let mut changes: BTreeMap<PathBuf, FileChanges> = BTreeMap::new();

    for item in status_iter {
        let item = match item {
            Ok(item) => item,
            Err(err) => {
                if !f(&work_dir, Err(err.into())) {
                    return Ok(());
                }
                continue;
            }
        };
        let staged = matches!(&item, StatusItem::TreeIndex(_));
        let change = match item {
            StatusItem::IndexWorktree(Item::Modification {
                rela_path, status, ..
            }) => {
                let path = work_dir.join(rela_path.to_path()?);
                match status {
                    EntryStatus::Conflict { .. } => FileChange::Conflict { path },
                    EntryStatus::Change(Change::Removed) => FileChange::Deleted { path },
                    EntryStatus::Change(Change::Modification { .. }) => {
                        FileChange::Modified { path }
                    }
                    // Files marked with `git add --intent-to-add`. Such files
                    // still show up as new in `git status`, so it's appropriate
                    // to show them the same way as untracked files in the
                    // "changed file" picker. One example of this being used
                    // is Jujutsu, a Git-compatible VCS. It marks all new files
                    // with `--intent-to-add` automatically.
                    EntryStatus::IntentToAdd => FileChange::Untracked { path },
                    _ => continue,
                }
            }
            StatusItem::IndexWorktree(Item::DirectoryContents { entry, .. })
                if entry.status == Status::Untracked =>
            {
                FileChange::Untracked {
                    path: work_dir.join(entry.rela_path.to_path()?),
                }
            }
            StatusItem::IndexWorktree(Item::Rewrite {
                source,
                dirwalk_entry,
                ..
            }) => FileChange::Renamed {
                from_path: work_dir.join(source.rela_path().to_path()?),
                to_path: work_dir.join(dirwalk_entry.rela_path.to_path()?),
            },
            StatusItem::TreeIndex(IndexChange::Addition { location, .. }) => FileChange::Added {
                path: work_dir.join(location.to_path()?),
            },
            StatusItem::TreeIndex(IndexChange::Deletion { location, .. }) => FileChange::Deleted {
                path: work_dir.join(location.to_path()?),
            },
            StatusItem::TreeIndex(IndexChange::Modification { location, .. }) => {
                FileChange::Modified {
                    path: work_dir.join(location.to_path()?),
                }
            }
            StatusItem::TreeIndex(IndexChange::Rewrite {
                source_location,
                location,
                ..
            }) => FileChange::Renamed {
                from_path: work_dir.join(source_location.to_path()?),
                to_path: work_dir.join(location.to_path()?),
            },
            _ => continue,
        };
        let entry = changes.entry(change.path().to_path_buf()).or_default();
        if staged {
            entry.staged = Some(change);
        } else {
            entry.worktree = Some(change);
        }
    }

    for changes in changes.into_values() {
        let change = match (changes.staged, changes.worktree) {
            // An unstaged edit doesn't erase a staged addition or rename.
            (
                Some(staged @ (FileChange::Added { .. } | FileChange::Renamed { .. })),
                Some(FileChange::Modified { .. }),
            ) => staged,
            (_, Some(worktree)) => worktree,
            (Some(staged), None) => staged,
            (None, None) => continue,
        };
        if !f(&work_dir, Ok(change)) {
            break;
        }
    }

    Ok(())
}

fn status_patterns(work_dir: &Path, scope: &ChangedFileScope) -> Result<Vec<BString>> {
    match scope {
        ChangedFileScope::Directory(directory) => {
            let directory = gix::path::realpath(directory).context("resolve change scope")?;
            let canonical_work_dir =
                gix::path::realpath(work_dir).context("resolve repository worktree")?;
            let relative = directory
                .strip_prefix(canonical_work_dir)
                .context("change scope is outside the repository worktree")?;
            if relative.as_os_str().is_empty() {
                Ok(Vec::new())
            } else {
                let relative = gix::path::try_into_bstr(relative)?;
                let relative = gix::path::to_unix_separators_on_windows(relative);
                // gix otherwise resolves this repository-relative path from the process CWD,
                // which may already be inside `directory` and would prefix the scope twice.
                let mut pattern = BString::from(":(top,literal)");
                pattern.push_str(relative.as_ref().as_bytes());
                Ok(vec![pattern])
            }
        }
        ChangedFileScope::Repository(_) => Ok(Vec::new()),
    }
}

/// Finds the object that contains the contents of a file at a specific commit.
fn find_file_in_commit(repo: &Repository, commit: &Commit, file: &Path) -> Result<ObjectId> {
    let repo_dir = repo.workdir().context("repo has no worktree")?;
    let rel_path = file.strip_prefix(repo_dir)?;
    let tree = commit.tree()?;
    let tree_entry = tree
        .lookup_entry_by_path(rel_path)?
        .context("file is untracked")?;
    match tree_entry.mode().kind() {
        // not a file, everything is new, do not show diff
        mode @ (EntryKind::Tree | EntryKind::Commit | EntryKind::Link) => {
            bail!("entry at {} is not a file but a {mode:?}", file.display())
        }
        // found a file
        EntryKind::Blob | EntryKind::BlobExecutable => Ok(tree_entry.object_id()),
    }
}
