use std::{cell::RefCell, fs::File, io::Write, path::Path, process::Command};

use tempfile::TempDir;

use crate::{git, ChangedFileScope, FileChange};

pub(crate) fn exec_git_cmd(args: &[&str], git_dir: &Path) {
    let res = Command::new("git")
        .arg("-C")
        .arg(git_dir) // execute the git command in this directory
        .args(args)
        .env_remove("GIT_DIR")
        .env_remove("GIT_ASKPASS")
        .env_remove("SSH_ASKPASS")
        .env("GIT_TERMINAL_PROMPT", "false")
        .env("GIT_AUTHOR_DATE", "2000-01-01 00:00:00 +0000")
        .env("GIT_AUTHOR_EMAIL", "author@example.com")
        .env("GIT_AUTHOR_NAME", "author")
        .env("GIT_COMMITTER_DATE", "2000-01-02 00:00:00 +0000")
        .env("GIT_COMMITTER_EMAIL", "committer@example.com")
        .env("GIT_COMMITTER_NAME", "committer")
        .env("GIT_CONFIG_COUNT", "2")
        .env("GIT_CONFIG_KEY_0", "commit.gpgsign")
        .env("GIT_CONFIG_VALUE_0", "false")
        .env("GIT_CONFIG_KEY_1", "init.defaultBranch")
        .env("GIT_CONFIG_VALUE_1", "main")
        .output()
        .unwrap_or_else(|_| panic!("`git {args:?}` failed"));
    if !res.status.success() {
        println!("{}", String::from_utf8_lossy(&res.stdout));
        eprintln!("{}", String::from_utf8_lossy(&res.stderr));
        panic!("`git {args:?}` failed (see output above)")
    }
}

fn create_commit(repo: &Path, add_modified: bool) {
    create_commit_with_message(repo, add_modified, "message");
}

pub(crate) fn create_commit_with_message(repo: &Path, add_modified: bool, message: &str) {
    if add_modified {
        exec_git_cmd(&["add", "-A"], repo);
    }
    exec_git_cmd(&["commit", "-m", message], repo);
}

pub(crate) fn empty_git_repo() -> TempDir {
    let tmp = tempfile::tempdir().expect("create temp dir for git testing");
    exec_git_cmd(&["init"], tmp.path());
    exec_git_cmd(&["config", "user.email", "test@mitos.org"], tmp.path());
    exec_git_cmd(&["config", "user.name", "mitos-test"], tmp.path());
    tmp
}

#[test]
fn missing_file() {
    let temp_git = empty_git_repo();
    let file = temp_git.path().join("file.txt");
    File::create(&file).unwrap().write_all(b"foo").unwrap();

    assert!(git::get_diff_base(&file, true).is_err());
}

#[test]
fn unmodified_file() {
    let temp_git = empty_git_repo();
    let file = temp_git.path().join("file.txt");
    let contents = b"foo".as_slice();
    File::create(&file).unwrap().write_all(contents).unwrap();
    create_commit(temp_git.path(), true);
    assert_eq!(
        git::get_diff_base(&file, true).unwrap(),
        Vec::from(contents)
    );
}

#[test]
fn modified_file() {
    let temp_git = empty_git_repo();
    let file = temp_git.path().join("file.txt");
    let contents = b"foo".as_slice();
    File::create(&file).unwrap().write_all(contents).unwrap();
    create_commit(temp_git.path(), true);
    File::create(&file).unwrap().write_all(b"bar").unwrap();

    assert_eq!(
        git::get_diff_base(&file, true).unwrap(),
        Vec::from(contents)
    );
}

#[test]
fn changed_files_include_the_worktree_root_when_started_in_a_subdirectory() {
    let temp_git = empty_git_repo();
    let file = temp_git.path().join("file.txt");
    File::create(&file).unwrap().write_all(b"before").unwrap();
    create_commit(temp_git.path(), true);
    File::create(&file).unwrap().write_all(b"after").unwrap();

    let subdirectory = temp_git.path().join("nested");
    std::fs::create_dir(&subdirectory).unwrap();
    let changes = RefCell::new(Vec::new());

    git::for_each_changed_file(
        &ChangedFileScope::Repository(subdirectory),
        true,
        |worktree_root, change| {
            changes
                .borrow_mut()
                .push((worktree_root.to_path_buf(), change.unwrap()));
            true
        },
    )
    .unwrap();

    let changes = changes.into_inner();
    let (worktree_root, changed) = changes
        .iter()
        .find(|(_, change)| change.path() == file)
        .expect("modified root file should be reported");
    assert_eq!(worktree_root, temp_git.path());
    assert!(matches!(changed, crate::FileChange::Modified { .. }));
}

#[test]
fn changed_files_can_be_scoped_to_a_directory() {
    let temp_git = empty_git_repo();
    let project = temp_git.path().join("project");
    let source = project.join("src");
    std::fs::create_dir_all(&source).unwrap();
    let project_file = source.join("project.txt");
    let sibling_file = temp_git.path().join("sibling.txt");
    File::create(&project_file)
        .unwrap()
        .write_all(b"before")
        .unwrap();
    File::create(&sibling_file)
        .unwrap()
        .write_all(b"before")
        .unwrap();
    create_commit(temp_git.path(), true);
    File::create(&project_file)
        .unwrap()
        .write_all(b"after")
        .unwrap();
    File::create(&sibling_file)
        .unwrap()
        .write_all(b"after")
        .unwrap();

    for staged in [false, true] {
        if staged {
            exec_git_cmd(&["add", "-A"], temp_git.path());
        }
        let changes = RefCell::new(Vec::new());
        git::for_each_changed_file(
            &ChangedFileScope::Directory(project.clone()),
            true,
            |_worktree_root, change| {
                changes.borrow_mut().push(change.unwrap());
                true
            },
        )
        .unwrap();

        let changes = changes.into_inner();
        assert_eq!(changes.len(), 1);
        assert_eq!(changes[0].path(), project_file);
    }

    let patterns = git::status_patterns(
        temp_git.path(),
        &ChangedFileScope::Directory(project.clone()),
    )
    .unwrap();
    assert_eq!(patterns, [":(top,literal)project"]);
}

#[test]
fn changed_files_include_staged_changes_without_duplicate_paths() {
    let repo = empty_git_repo();
    let root = repo.path();
    std::fs::write(root.join(".gitattributes"), "* text eol=lf\n").unwrap();
    for (name, text) in [
        ("modified.txt", "modify this\n"),
        ("deleted.txt", "delete this\n"),
        ("original.txt", "rename this\n"),
        ("mixed.txt", "original content\n"),
    ] {
        std::fs::write(root.join(name), text).unwrap();
    }
    create_commit(root, true);
    std::fs::write(root.join("modified.txt"), "staged modification\n").unwrap();
    std::fs::write(root.join("added.txt"), "staged addition\n").unwrap();
    std::fs::write(root.join("mixed.txt"), "staged content\n").unwrap();
    exec_git_cmd(&["rm", "deleted.txt"], root);
    exec_git_cmd(&["mv", "original.txt", "renamed.txt"], root);
    exec_git_cmd(&["add", "-A"], root);
    // Keep the addition and rename classifications after further working-tree edits.
    std::fs::write(root.join("added.txt"), "staged addition\nfurther edit\n").unwrap();
    std::fs::write(root.join("renamed.txt"), "rename this\nfurther edit\n").unwrap();
    // Both comparisons matter even when the working file matches HEAD again.
    std::fs::write(root.join("mixed.txt"), "original content\n").unwrap();
    std::fs::write(root.join("untracked.txt"), "untracked\n").unwrap();
    let index = std::fs::read(root.join(".git/index")).unwrap();

    let changes = RefCell::new(Vec::new());
    git::for_each_changed_file(
        &ChangedFileScope::Repository(root.into()),
        true,
        |_, change| {
            changes.borrow_mut().push(change.unwrap());
            true
        },
    )
    .unwrap();
    let changes = changes.into_inner();
    let mut paths: Vec<_> = changes
        .iter()
        .map(|change| change.path().file_name().unwrap().to_owned())
        .collect();
    paths.sort();
    assert_eq!(
        paths,
        [
            "added.txt",
            "deleted.txt",
            "mixed.txt",
            "modified.txt",
            "renamed.txt",
            "untracked.txt"
        ]
    );
    assert!(changes.iter().any(
        |change| matches!(change, FileChange::Added { path } if path == &root.join("added.txt"))
    ));
    assert!(changes.iter().any(
        |change| matches!(change, FileChange::Deleted { path } if path == &root.join("deleted.txt"))
    ));
    assert!(changes.iter().any(|change| matches!(change, FileChange::Modified { path } if path == &root.join("modified.txt"))));
    assert!(changes.iter().any(|change| matches!(change, FileChange::Renamed { from_path, to_path } if from_path == &root.join("original.txt") && to_path == &root.join("renamed.txt"))));
    assert_eq!(std::fs::read(root.join(".git/index")).unwrap(), index);
}

#[test]
fn changed_files_include_staged_additions_before_the_first_commit() {
    let repo = empty_git_repo();
    let root = repo.path();
    for name in ["added.txt", "intent.txt", "untracked.txt"] {
        std::fs::write(root.join(name), name).unwrap();
    }
    exec_git_cmd(&["add", "added.txt"], root);
    exec_git_cmd(&["add", "--intent-to-add", "intent.txt"], root);

    let changes = RefCell::new(Vec::new());
    git::for_each_changed_file(
        &ChangedFileScope::Repository(root.into()),
        false,
        |_, change| {
            changes.borrow_mut().push(change.unwrap());
            true
        },
    )
    .unwrap();
    let changes = changes.into_inner();
    assert_eq!(changes.len(), 3);
    assert!(changes.iter().any(
        |change| matches!(change, FileChange::Added { path } if path == &root.join("added.txt"))
    ));
    for name in ["intent.txt", "untracked.txt"] {
        assert!(changes.iter().any(
            |change| matches!(change, FileChange::Untracked { path } if path == &root.join(name))
        ));
    }
}

#[test]
fn changed_files_keep_conflicts_alongside_staged_changes() {
    let repo = empty_git_repo();
    let root = repo.path();
    std::fs::write(root.join("conflict.txt"), "base\n").unwrap();
    std::fs::write(root.join("staged.txt"), "before\n").unwrap();
    create_commit(root, true);
    exec_git_cmd(&["checkout", "-b", "other"], root);
    std::fs::write(root.join("conflict.txt"), "theirs\n").unwrap();
    create_commit(root, true);
    exec_git_cmd(&["checkout", "main"], root);
    std::fs::write(root.join("conflict.txt"), "ours\n").unwrap();
    create_commit(root, true);
    let merge = Command::new("git")
        .arg("-C")
        .arg(root)
        .args(["merge", "--no-commit", "other"])
        .env_remove("GIT_DIR")
        .output()
        .unwrap();
    assert_eq!(merge.status.code(), Some(1), "merge should conflict");
    std::fs::write(root.join("staged.txt"), "after\n").unwrap();
    exec_git_cmd(&["add", "staged.txt"], root);

    let changes = RefCell::new(Vec::new());
    git::for_each_changed_file(
        &ChangedFileScope::Repository(root.into()),
        true,
        |_, change| {
            changes.borrow_mut().push(change.unwrap());
            true
        },
    )
    .unwrap();
    let changes = changes.into_inner();
    assert_eq!(changes.len(), 2);
    assert!(changes.iter().any(|change| matches!(change, FileChange::Conflict { path } if path == &root.join("conflict.txt"))));
    assert!(changes.iter().any(
        |change| matches!(change, FileChange::Modified { path } if path == &root.join("staged.txt"))
    ));
}

/// Test that `get_file_head` does not return content for a directory.
/// This is important to correctly cover cases where a directory is removed and replaced by a file.
/// If the contents of the directory object were returned a diff between a path and the directory children would be produced.
#[test]
fn directory() {
    let temp_git = empty_git_repo();
    let dir = temp_git.path().join("file.txt");
    std::fs::create_dir(&dir).expect("");
    let file = dir.join("file.txt");
    let contents = b"foo".as_slice();
    File::create(file).unwrap().write_all(contents).unwrap();

    create_commit(temp_git.path(), true);

    std::fs::remove_dir_all(&dir).unwrap();
    File::create(&dir).unwrap().write_all(b"bar").unwrap();
    assert!(git::get_diff_base(&dir, true).is_err());
}

/// Test that `get_diff_base` resolves symlinks so that the same diff base is
/// used as the target file.
///
/// This is important to correctly cover cases where a symlink is removed and
/// replaced by a file. If the contents of the symlink object were returned
/// a diff between a literal file path and the actual file content would be
/// produced (bad ui).
#[cfg(any(unix, windows))]
#[test]
fn symlink() {
    #[cfg(unix)]
    use std::os::unix::fs::symlink;
    #[cfg(not(unix))]
    use std::os::windows::fs::symlink_file as symlink;

    let temp_git = empty_git_repo();
    let file = temp_git.path().join("file.txt");
    let contents = Vec::from(b"foo");
    File::create(&file).unwrap().write_all(&contents).unwrap();
    let file_link = temp_git.path().join("file_link.txt");

    symlink("file.txt", &file_link).unwrap();
    create_commit(temp_git.path(), true);

    assert_eq!(git::get_diff_base(&file_link, true).unwrap(), contents);
    assert_eq!(git::get_diff_base(&file, true).unwrap(), contents);
}

/// Test that `get_diff_base` returns content when the file is a symlink to
/// another file that is in a git repo, but the symlink itself is not.
#[cfg(any(unix, windows))]
#[test]
fn symlink_to_git_repo() {
    #[cfg(unix)]
    use std::os::unix::fs::symlink;
    #[cfg(not(unix))]
    use std::os::windows::fs::symlink_file as symlink;

    let temp_dir = tempfile::tempdir().expect("create temp dir");
    let temp_git = empty_git_repo();

    let file = temp_git.path().join("file.txt");
    let contents = Vec::from(b"foo");
    File::create(&file).unwrap().write_all(&contents).unwrap();
    create_commit(temp_git.path(), true);

    let file_link = temp_dir.path().join("file_link.txt");
    symlink(&file, &file_link).unwrap();

    assert_eq!(git::get_diff_base(&file_link, true).unwrap(), contents);
    assert_eq!(git::get_diff_base(&file, true).unwrap(), contents);
}

#[test]
fn watched_paths_include_branch_refs_and_linked_worktree_metadata() {
    let repo = empty_git_repo();
    std::fs::write(repo.path().join("file.txt"), "hello\n").unwrap();
    create_commit(repo.path(), true);
    let paths = git::get_watched_paths(repo.path(), false).unwrap();
    assert!(paths.iter().any(|path| path.ends_with(".git/HEAD")));
    assert!(paths
        .iter()
        .any(|path| path.ends_with(".git/refs/heads/main")));
    assert!(paths.iter().any(|path| path.ends_with(".git/packed-refs")));
    exec_git_cmd(&["worktree", "add", "-b", "feature", "linked"], repo.path());
    let paths = git::get_watched_paths(&repo.path().join("linked"), false).unwrap();
    assert!(paths
        .iter()
        .any(|path| path.ends_with(".git/worktrees/linked/HEAD")));
    assert!(paths
        .iter()
        .any(|path| path.ends_with(".git/refs/heads/feature")));
    assert!(paths.iter().any(|path| path.ends_with(".git/packed-refs")));
}
