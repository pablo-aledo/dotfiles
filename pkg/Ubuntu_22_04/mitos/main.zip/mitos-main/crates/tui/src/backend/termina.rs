use std::io::{self, Write};

use ratatui::{
    backend::{Backend, ClearType, WindowSize as RatatuiWindowSize},
    buffer::Cell,
    layout::{Position, Size},
    style::{Color as RatatuiColor, Modifier},
};
use termina::{
    escape::{
        csi::{self, Csi, SgrAttributes, SgrModifiers},
        dcs::{self, Dcs},
        osc::{self, Osc},
    },
    style::{ColorSpec, CursorStyle, RgbColor},
    Event, OneBased, PlatformTerminal, Terminal as _, WindowSize as TerminaWindowSize,
};
use ui_core::{
    graphics::{CursorKind, Rect, UnderlineStyle},
    terminal::KittyKeyboardProtocolConfig,
    theme::{self, Color},
};

use crate::terminal::Config;

use super::BackendExt;

// These macros are helpers to set/unset modes like bracketed paste or enter/exit the alternate
// screen.
macro_rules! decset {
    ($mode:ident) => {
        Csi::Mode(csi::Mode::SetDecPrivateMode(csi::DecPrivateMode::Code(
            csi::DecPrivateModeCode::$mode,
        )))
    };
}
macro_rules! decreset {
    ($mode:ident) => {
        Csi::Mode(csi::Mode::ResetDecPrivateMode(csi::DecPrivateMode::Code(
            csi::DecPrivateModeCode::$mode,
        )))
    };
}

fn term_program() -> Option<String> {
    // Some terminals don't set $TERM_PROGRAM
    match std::env::var("TERM_PROGRAM") {
        Err(_) => std::env::var("TERM").ok(),
        Ok(term_program) => Some(term_program),
    }
}
fn vte_version() -> Option<usize> {
    std::env::var("VTE_VERSION").ok()?.parse().ok()
}

#[derive(Debug, Default, Clone, Copy)]
struct Capabilities {
    kitty_keyboard: KittyKeyboardSupport,
    synchronized_output: bool,
    true_color: bool,
    extended_underlines: bool,
    /// OSC11 / OSC111 - change the terminal's background color.
    dynamic_background_color: bool,
    theme_mode_updates: bool,
    theme_mode: Option<theme::Mode>,
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
enum KittyKeyboardSupport {
    /// The terminal doesn't support the protocol.
    #[default]
    None,
    /// The terminal supports the protocol but we haven't checked yet whether it has full or
    /// partial support for the flags we require.
    Some,
    /// The terminal only supports some of the flags we require.
    Partial,
    /// The terminal supports all flags require.
    Full,
}

#[derive(Debug)]
pub struct TerminaBackend {
    terminal: PlatformTerminal,
    config: Config,
    capabilities: Capabilities,
    reset_cursor_command: String,
    is_synchronized_output_set: bool,
    /// The requested terminal background color, set in `Self::set_background_color`.
    background_color: Option<RgbColor>,
    /// Whether Mitos currently owns an OSC 11 background override.
    background_color_is_set: bool,
}

impl TerminaBackend {
    pub fn new(config: Config) -> io::Result<Self> {
        use std::time::{Duration, Instant};

        let mut terminal = PlatformTerminal::new()?;

        // Colibri "midnight"
        const TEST_COLOR: RgbColor = RgbColor::new(59, 34, 76);

        terminal.enter_raw_mode()?;

        let mut capabilities = Capabilities::default();
        let start = Instant::now();

        // HACK: emitting OSC11 / OSC111 seems to break SGR and cause flickering in tmux.
        capabilities.dynamic_background_color = std::env::var_os("TMUX").is_none();

        capabilities.kitty_keyboard = match config.kitty_keyboard_protocol {
            KittyKeyboardProtocolConfig::Disabled => KittyKeyboardSupport::None,
            KittyKeyboardProtocolConfig::Enabled => KittyKeyboardSupport::Full,
            KittyKeyboardProtocolConfig::Auto => {
                write!(terminal, "{}", Csi::Keyboard(csi::Keyboard::QueryFlags))?;
                KittyKeyboardSupport::None
            }
        };

        // Many terminal extensions can be detected by querying the terminal for the state of the
        // extension and then sending a request for the primary device attributes (which is
        // consistently supported by all terminals). If we receive the status of the feature (for
        // example the current Kitty keyboard flags) then we know that the feature is supported.
        // If we only receive the device attributes then we know it is not.
        write!(
            terminal,
            "{}{}{}{}{}{}{}",
            // Synchronized output
            Csi::Mode(csi::Mode::QueryDecPrivateMode(csi::DecPrivateMode::Code(
                csi::DecPrivateModeCode::SynchronizedOutput
            ))),
            // Mode 2031 theme updates. Query the current theme.
            Csi::Mode(csi::Mode::QueryTheme),
            // True color and while we're at it, extended underlines:
            // <https://github.com/termstandard/colors?tab=readme-ov-file#querying-the-terminal>
            Csi::Sgr(csi::Sgr::Background(TEST_COLOR.into())),
            Csi::Sgr(csi::Sgr::UnderlineColor(TEST_COLOR.into())),
            Dcs::Request(dcs::DcsRequest::GraphicRendition),
            Csi::Sgr(csi::Sgr::Reset),
            // Finally request the primary device attributes
            Csi::Device(csi::Device::RequestPrimaryDeviceAttributes),
        )?;
        terminal.flush()?;

        let device_attributes = |event: &Event| {
            matches!(
                event,
                Event::Csi(Csi::Device(csi::Device::DeviceAttributes(_)))
            )
        };
        // TODO: tune this poll constant? Does it need to be longer when on an SSH connection?
        let poll_duration = Duration::from_millis(100);
        if terminal.poll(device_attributes, Some(poll_duration))? {
            while terminal.poll(Event::is_escape, Some(Duration::ZERO))? {
                match terminal.read(Event::is_escape)? {
                    Event::Csi(Csi::Keyboard(csi::Keyboard::ReportFlags(_))) => {
                        capabilities.kitty_keyboard = KittyKeyboardSupport::Some;
                    }
                    Event::Csi(Csi::Mode(csi::Mode::ReportDecPrivateMode {
                        mode: csi::DecPrivateMode::Code(csi::DecPrivateModeCode::SynchronizedOutput),
                        setting: csi::DecModeSetting::Set | csi::DecModeSetting::Reset,
                    })) => {
                        capabilities.synchronized_output = true;
                    }
                    Event::Csi(Csi::Mode(csi::Mode::ReportTheme(mode))) => {
                        capabilities.theme_mode_updates = true;
                        capabilities.theme_mode = Some(mode.into());
                    }
                    Event::Dcs(dcs::Dcs::Response {
                        value: dcs::DcsResponse::GraphicRendition(sgrs),
                        ..
                    }) => {
                        capabilities.true_color =
                            sgrs.contains(&csi::Sgr::Background(TEST_COLOR.into()));
                        capabilities.extended_underlines =
                            sgrs.contains(&csi::Sgr::UnderlineColor(TEST_COLOR.into()));
                    }
                    _ => (),
                }
            }

            let end = Instant::now();
            log::debug!(
                "Detected terminal capabilities in {:?}: {capabilities:?}",
                end.duration_since(start)
            );
        } else {
            log::debug!("Failed to detect terminal capabilities within {poll_duration:?}. Using default capabilities only");
        }

        capabilities.extended_underlines |= config.force_enable_extended_underlines;

        let mut reset_cursor_command = String::new();
        if let Ok(t) = termini::TermInfo::from_env() {
            capabilities.extended_underlines |= t.extended_cap("Smulx").is_some()
                || t.extended_cap("Su").is_some()
                || vte_version() >= Some(5102)
                // HACK: once WezTerm can support DECRQSS/DECRPSS for SGR we can remove this line.
                // <https://github.com/wezterm/wezterm/pull/6856>
                || matches!(term_program().as_deref(), Some("WezTerm"));

            if let Some(termini::Value::Utf8String(se_str)) = t.extended_cap("Se") {
                reset_cursor_command.push_str(se_str);
            };
            reset_cursor_command.push_str(
                t.utf8_string_cap(termini::StringCapability::CursorNormal)
                    .unwrap_or(""),
            );
            log::debug!(
                "Cursor reset escape sequence detected from terminfo: {reset_cursor_command:?}"
            );
        } else {
            log::debug!("terminfo could not be read, using default cursor reset escape sequence: {reset_cursor_command:?}");
        }
        reset_cursor_command
            .push_str(&Csi::Cursor(csi::Cursor::CursorStyle(CursorStyle::Default)).to_string());

        terminal.enter_cooked_mode()?;

        // In the case of a panic, reset the terminal eagerly. If we didn't do this and instead
        // relied on `Drop`, the backtrace would be lost because it is printed before we would
        // clear and exit the alternate screen.
        let hook_reset_cursor_command = reset_cursor_command.clone();
        terminal.set_panic_hook(move |term| {
            let _ = write!(
                term,
                "{}{}{}{}{}{}{}{}{}{}{}{}",
                Csi::Keyboard(csi::Keyboard::PopFlags(1)),
                decreset!(MouseTracking),
                decreset!(ButtonEventMouse),
                decreset!(AnyEventMouse),
                decreset!(RXVTMouse),
                decreset!(SGRMouse),
                hook_reset_cursor_command,
                decreset!(BracketedPaste),
                decreset!(FocusTracking),
                Osc::ResetDynamicColor(osc::DynamicColorNumber::TextBackgroundColor),
                Csi::Edit(csi::Edit::EraseInDisplay(csi::EraseInDisplay::EraseDisplay)),
                decreset!(ClearAndEnableAlternateScreen),
            );
        });

        Ok(Self {
            terminal,
            config,
            capabilities,
            reset_cursor_command,
            is_synchronized_output_set: false,
            background_color: None,
            background_color_is_set: false,
        })
    }

    pub fn terminal(&self) -> &PlatformTerminal {
        &self.terminal
    }

    fn enable_mouse_capture(&mut self) -> io::Result<()> {
        if self.config.enable_mouse_capture {
            write!(
                self.terminal,
                "{}{}{}{}{}",
                decset!(MouseTracking),
                decset!(ButtonEventMouse),
                decset!(AnyEventMouse),
                decset!(RXVTMouse),
                decset!(SGRMouse),
            )?;
        }
        Ok(())
    }

    fn disable_mouse_capture(&mut self) -> io::Result<()> {
        if self.config.enable_mouse_capture {
            write!(
                self.terminal,
                "{}{}{}{}{}",
                decreset!(MouseTracking),
                decreset!(ButtonEventMouse),
                decreset!(AnyEventMouse),
                decreset!(RXVTMouse),
                decreset!(SGRMouse),
            )?;
        }
        Ok(())
    }

    fn reset_background_color(&mut self) -> io::Result<()> {
        write_reset_background_color(&mut self.terminal)
    }

    fn enable_extensions(&mut self) -> io::Result<()> {
        const KEYBOARD_FLAGS: csi::KittyKeyboardFlags =
            csi::KittyKeyboardFlags::DISAMBIGUATE_ESCAPE_CODES
                .union(csi::KittyKeyboardFlags::REPORT_ALTERNATE_KEYS);

        match self.capabilities.kitty_keyboard {
            KittyKeyboardSupport::None | KittyKeyboardSupport::Partial => (),
            KittyKeyboardSupport::Full => {
                write!(
                    self.terminal,
                    "{}",
                    Csi::Keyboard(csi::Keyboard::PushFlags(KEYBOARD_FLAGS))
                )?;
            }
            KittyKeyboardSupport::Some => {
                write!(
                    self.terminal,
                    "{}{}",
                    // Enable the flags we need.
                    Csi::Keyboard(csi::Keyboard::PushFlags(KEYBOARD_FLAGS)),
                    // Then request the current flags. We need to check if the terminal enabled
                    // all of the flags we require.
                    Csi::Keyboard(csi::Keyboard::QueryFlags),
                )?;
                self.terminal.flush()?;

                let event = self.terminal.read(|event| {
                    matches!(
                        event,
                        Event::Csi(Csi::Keyboard(csi::Keyboard::ReportFlags(_)))
                    )
                })?;
                let Event::Csi(Csi::Keyboard(csi::Keyboard::ReportFlags(flags))) = event else {
                    unreachable!();
                };
                if flags != KEYBOARD_FLAGS {
                    log::info!("Turning off enhanced keyboard support because the terminal enabled different flags. Requested {KEYBOARD_FLAGS:?} but got {flags:?}");
                    write!(
                        self.terminal,
                        "{}",
                        Csi::Keyboard(csi::Keyboard::PopFlags(1))
                    )?;
                    self.terminal.flush()?;
                    self.capabilities.kitty_keyboard = KittyKeyboardSupport::Partial;
                } else {
                    log::debug!(
                        "The terminal fully supports the requested keyboard enhancement flags"
                    );
                    self.capabilities.kitty_keyboard = KittyKeyboardSupport::Full;
                }
            }
        }

        if self.capabilities.theme_mode_updates {
            // Enable mode 2031 theme mode notifications:
            write!(self.terminal, "{}", decset!(Theme))?;
        }

        Ok(())
    }

    fn disable_extensions(&mut self) -> io::Result<()> {
        if self.capabilities.kitty_keyboard == KittyKeyboardSupport::Full {
            write!(
                self.terminal,
                "{}",
                Csi::Keyboard(csi::Keyboard::PopFlags(1))
            )?;
        }

        if self.capabilities.theme_mode_updates {
            // Mode 2031 theme notifications.
            write!(self.terminal, "{}", decreset!(Theme))?;
        }

        Ok(())
    }

    // See <https://gist.github.com/christianparpart/d8a62cc1ab659194337d73e399004036>.
    // Synchronized output sequences tell the terminal when we are "starting to render" and
    // stopping, enabling to make better choices about when it draws a frame. This avoids all
    // kinds of ugly visual artifacts like tearing and flashing (i.e. the background color
    // after clearing the terminal).

    fn start_synchronized_render(&mut self) -> io::Result<()> {
        if self.capabilities.synchronized_output && !self.is_synchronized_output_set {
            write!(self.terminal, "{}", decset!(SynchronizedOutput))?;
            self.is_synchronized_output_set = true;
        }
        Ok(())
    }

    fn end_sychronized_render(&mut self) -> io::Result<()> {
        if self.is_synchronized_output_set {
            write!(self.terminal, "{}", decreset!(SynchronizedOutput))?;
            self.is_synchronized_output_set = false;
        }
        Ok(())
    }
}

impl TerminaBackend {
    fn claim(&mut self) -> io::Result<()> {
        self.terminal.enter_raw_mode()?;

        write!(
            self.terminal,
            "{}{}{}{}",
            // Enter an alternate screen.
            decset!(ClearAndEnableAlternateScreen),
            decset!(BracketedPaste),
            decset!(FocusTracking),
            // Clear the buffer. `ClearAndEnableAlternateScreen` **should** do this but some
            // things like mosh are buggy. See <https://github.com/helix-editor/helix/pull/1944>.
            Csi::Edit(csi::Edit::EraseInDisplay(csi::EraseInDisplay::EraseDisplay)),
        )?;
        if let Some(color) = self.background_color {
            write!(
                self.terminal,
                "{}",
                Osc::ChangeDynamicColors(
                    osc::DynamicColorNumber::TextBackgroundColor,
                    vec![color.into()]
                )
            )?;
            self.background_color_is_set = true;
        }
        self.enable_mouse_capture()?;
        self.enable_extensions()?;

        Ok(())
    }

    fn reconfigure(&mut self, mut config: Config) -> io::Result<()> {
        std::mem::swap(&mut self.config, &mut config);
        if self.config.enable_mouse_capture != config.enable_mouse_capture {
            if self.config.enable_mouse_capture {
                self.enable_mouse_capture()?;
            } else {
                self.disable_mouse_capture()?;
            }
        }
        self.capabilities.extended_underlines |= self.config.force_enable_extended_underlines;
        Ok(())
    }

    fn restore(&mut self) -> io::Result<()> {
        self.disable_extensions()?;
        self.disable_mouse_capture()?;
        write!(
            self.terminal,
            "{}{}{}{}",
            self.reset_cursor_command,
            decreset!(BracketedPaste),
            decreset!(FocusTracking),
            decreset!(ClearAndEnableAlternateScreen),
        )?;
        if self.background_color_is_set {
            self.reset_background_color()?;
            self.background_color_is_set = false;
        }
        self.terminal.flush()?;
        self.terminal.enter_cooked_mode()?;
        Ok(())
    }

    fn draw<'a, I>(&mut self, content: I) -> io::Result<()>
    where
        I: Iterator<Item = (u16, u16, &'a Cell)>,
    {
        let mut fg = RatatuiColor::Reset;
        let mut bg = RatatuiColor::Reset;
        let mut underline_color = RatatuiColor::Reset;
        let mut underline_style = UnderlineStyle::Reset;
        let mut modifier = Modifier::empty();
        let mut last_pos: Option<(u16, u16)> = None;
        for (x, y, cell) in content {
            // Move the cursor if the previous location was not (x - 1, y)
            if !matches!(last_pos, Some(p) if x == p.0 + 1 && y == p.1) {
                write!(
                    self.terminal,
                    "{}",
                    Csi::Cursor(csi::Cursor::Position {
                        col: OneBased::from_zero_based(x),
                        line: OneBased::from_zero_based(y),
                    })
                )?;
            }
            last_pos = Some((x, y));

            let mut attributes = SgrAttributes::default();
            if cell.fg != fg {
                attributes.foreground = Some(color_to_termina(cell.fg));
                fg = cell.fg;
            }
            if cell.bg != bg {
                attributes.background = Some(color_to_termina(cell.bg));
                bg = cell.bg;
            }
            if cell.modifier != modifier {
                attributes.modifiers = diff_modifiers(modifier, cell.modifier);
                modifier = cell.modifier;
            }

            if self.capabilities.extended_underlines && cell.underline_color != underline_color {
                write!(
                    self.terminal,
                    "{}",
                    Csi::Sgr(csi::Sgr::UnderlineColor(color_to_termina(
                        cell.underline_color
                    )))
                )?;
                underline_color = cell.underline_color;
            }
            let mut new_underline_style = UnderlineStyle::from_ratatui_modifier(cell.modifier);
            if !self.capabilities.extended_underlines
                && !matches!(
                    new_underline_style,
                    UnderlineStyle::Reset | UnderlineStyle::Line
                )
            {
                new_underline_style = UnderlineStyle::Line;
            }
            if new_underline_style != underline_style {
                write!(
                    self.terminal,
                    "{}",
                    Csi::Sgr(csi::Sgr::Underline(new_underline_style.into()))
                )?;
                underline_style = new_underline_style;
            }

            // `attributes` will be empty if nothing changed between two cells. Empty
            // `SgrAttributes` behave the same as a `Sgr::Reset` rather than a 'no-op' though so
            // we should avoid writing them if they're empty.
            if !attributes.is_empty() {
                write!(
                    self.terminal,
                    "{}",
                    Csi::Sgr(csi::Sgr::Attributes(attributes))
                )?;
            }

            write!(self.terminal, "{}", cell.symbol())?;
        }

        write!(self.terminal, "{}", Csi::Sgr(csi::Sgr::Reset))?;

        Ok(())
    }

    fn hide_cursor(&mut self) -> io::Result<()> {
        write!(self.terminal, "{}", decreset!(ShowCursor))
    }

    fn set_cursor_kind(&mut self, kind: CursorKind) -> io::Result<()> {
        let style = match kind {
            CursorKind::Block => CursorStyle::SteadyBlock,
            CursorKind::Bar => CursorStyle::SteadyBar,
            CursorKind::Underline => CursorStyle::SteadyUnderline,
        };
        write!(
            self.terminal,
            "{}",
            Csi::Cursor(csi::Cursor::CursorStyle(style)),
        )
    }

    fn set_cursor(&mut self, x: u16, y: u16) -> io::Result<()> {
        let col = OneBased::from_zero_based(x);
        let line = OneBased::from_zero_based(y);
        write!(
            self.terminal,
            "{}",
            Csi::Cursor(csi::Cursor::Position { line, col })
        )
    }

    fn clear(&mut self) -> io::Result<()> {
        write!(
            self.terminal,
            "{}",
            Csi::Edit(csi::Edit::EraseInDisplay(csi::EraseInDisplay::EraseDisplay))
        )
    }

    fn start_sync(&mut self) -> io::Result<()> {
        self.start_synchronized_render()
    }

    fn end_sync(&mut self) -> io::Result<()> {
        self.end_sychronized_render()
    }

    fn size(&self) -> io::Result<Rect> {
        let TerminaWindowSize { rows, cols, .. } = self.terminal.get_dimensions()?;
        Ok(Rect::new(0, 0, cols, rows))
    }

    fn flush(&mut self) -> io::Result<()> {
        self.terminal.flush()
    }

    fn supports_true_color(&self) -> bool {
        self.capabilities.true_color
    }

    fn get_theme_mode(&self) -> Option<theme::Mode> {
        self.capabilities.theme_mode
    }

    fn set_background_color(&mut self, color: Option<Color>) -> io::Result<()> {
        if !self.capabilities.dynamic_background_color {
            return Ok(());
        }
        match color {
            Some(Color::Rgb(r, g, b)) => {
                let color = RgbColor::new(r, g, b);
                write!(
                    self.terminal,
                    "{}",
                    Osc::ChangeDynamicColors(
                        osc::DynamicColorNumber::TextBackgroundColor,
                        vec![color.into()]
                    )
                )?;
                self.background_color = Some(color);
                self.background_color_is_set = true;
            }
            _ if self.background_color_is_set => {
                self.reset_background_color()?;
                self.background_color = None;
                self.background_color_is_set = false;
            }
            _ => {}
        }
        Ok(())
    }
}

fn write_reset_background_color<W: Write>(writer: &mut W) -> io::Result<()> {
    write!(
        writer,
        "{}",
        Osc::ResetDynamicColor(osc::DynamicColorNumber::TextBackgroundColor)
    )
}

impl Backend for TerminaBackend {
    type Error = io::Error;

    fn draw<'a, I>(&mut self, content: I) -> io::Result<()>
    where
        I: Iterator<Item = (u16, u16, &'a Cell)>,
    {
        TerminaBackend::draw(self, content)
    }

    fn hide_cursor(&mut self) -> io::Result<()> {
        TerminaBackend::hide_cursor(self)
    }

    fn show_cursor(&mut self) -> io::Result<()> {
        write!(self.terminal, "{}", decset!(ShowCursor))
    }

    fn get_cursor_position(&mut self) -> io::Result<Position> {
        write!(
            self.terminal,
            "{}",
            Csi::Cursor(csi::Cursor::RequestActivePositionReport)
        )?;
        self.terminal.flush()?;
        let event = self.terminal.read(|event| {
            matches!(
                event,
                Event::Csi(Csi::Cursor(csi::Cursor::ActivePositionReport { .. }))
            )
        })?;
        let Event::Csi(Csi::Cursor(csi::Cursor::ActivePositionReport { line, col })) = event else {
            return Err(io::Error::other("unexpected cursor-position response"));
        };
        Ok(Position::new(col.get_zero_based(), line.get_zero_based()))
    }

    fn set_cursor_position<P: Into<Position>>(&mut self, position: P) -> io::Result<()> {
        let Position { x, y } = position.into();
        TerminaBackend::set_cursor(self, x, y)
    }

    fn clear(&mut self) -> io::Result<()> {
        TerminaBackend::clear(self)
    }

    fn clear_region(&mut self, clear_type: ClearType) -> io::Result<()> {
        let edit = match clear_type {
            ClearType::All => csi::Edit::EraseInDisplay(csi::EraseInDisplay::EraseDisplay),
            ClearType::AfterCursor => {
                csi::Edit::EraseInDisplay(csi::EraseInDisplay::EraseToEndOfDisplay)
            }
            ClearType::BeforeCursor => {
                csi::Edit::EraseInDisplay(csi::EraseInDisplay::EraseToStartOfDisplay)
            }
            ClearType::CurrentLine => csi::Edit::EraseInLine(csi::EraseInLine::EraseLine),
            ClearType::UntilNewLine => csi::Edit::EraseInLine(csi::EraseInLine::EraseToEndOfLine),
        };
        write!(self.terminal, "{}", Csi::Edit(edit))
    }

    fn size(&self) -> io::Result<Size> {
        Ok(TerminaBackend::size(self)?.as_size())
    }

    fn window_size(&mut self) -> io::Result<RatatuiWindowSize> {
        let size = self.terminal.get_dimensions()?;
        Ok(RatatuiWindowSize {
            columns_rows: Size::new(size.cols, size.rows),
            pixels: Size::new(
                size.pixel_width.unwrap_or_default(),
                size.pixel_height.unwrap_or_default(),
            ),
        })
    }

    fn flush(&mut self) -> io::Result<()> {
        TerminaBackend::flush(self)
    }
}

impl BackendExt for TerminaBackend {
    fn claim(&mut self) -> io::Result<()> {
        TerminaBackend::claim(self)
    }

    fn reconfigure(&mut self, config: Config) -> io::Result<()> {
        TerminaBackend::reconfigure(self, config)
    }

    fn restore(&mut self) -> io::Result<()> {
        TerminaBackend::restore(self)
    }

    fn set_cursor_kind(&mut self, kind: CursorKind) -> io::Result<()> {
        TerminaBackend::set_cursor_kind(self, kind)
    }

    fn start_sync(&mut self) -> io::Result<()> {
        TerminaBackend::start_sync(self)
    }

    fn end_sync(&mut self) -> io::Result<()> {
        TerminaBackend::end_sync(self)
    }

    fn supports_true_color(&self) -> bool {
        TerminaBackend::supports_true_color(self)
    }

    fn get_theme_mode(&self) -> Option<theme::Mode> {
        TerminaBackend::get_theme_mode(self)
    }

    fn set_background_color(&mut self, color: Option<Color>) -> io::Result<()> {
        TerminaBackend::set_background_color(self, color)
    }
}

impl Drop for TerminaBackend {
    fn drop(&mut self) {
        // Avoid resetting the terminal while panicking because we set a panic hook above in
        // `Self::new`.
        if !std::thread::panicking() {
            let _ = self.disable_extensions();
            let _ = self.disable_mouse_capture();
            let _ = write!(
                self.terminal,
                "{}{}{}{}",
                self.reset_cursor_command,
                decreset!(BracketedPaste),
                decreset!(FocusTracking),
                decreset!(ClearAndEnableAlternateScreen),
            );
            if self.background_color_is_set {
                let _ = self.reset_background_color();
            }
            // NOTE: Drop for Platform terminal resets the mode and flushes the buffer when not
            // panicking.
        }
    }
}

fn diff_modifiers(from: Modifier, to: Modifier) -> SgrModifiers {
    let mut modifiers = SgrModifiers::default();

    let removed = from - to;
    if removed.contains(Modifier::REVERSED) {
        modifiers |= SgrModifiers::NO_REVERSE;
    }
    if removed.contains(Modifier::BOLD) {
        modifiers |= SgrModifiers::INTENSITY_NORMAL;
        if to.contains(Modifier::DIM) {
            modifiers |= SgrModifiers::INTENSITY_DIM
        }
    }
    if removed.contains(Modifier::DIM) {
        modifiers |= SgrModifiers::INTENSITY_NORMAL;
    }
    if removed.contains(Modifier::ITALIC) {
        modifiers |= SgrModifiers::NO_ITALIC;
    }
    if removed.contains(Modifier::CROSSED_OUT) {
        modifiers |= SgrModifiers::NO_STRIKE_THROUGH;
    }
    if removed.contains(Modifier::HIDDEN) {
        modifiers |= SgrModifiers::NO_INVISIBLE;
    }
    if removed.contains(Modifier::SLOW_BLINK) || removed.contains(Modifier::RAPID_BLINK) {
        modifiers |= SgrModifiers::BLINK_NONE;
    }

    let added = to - from;
    if added.contains(Modifier::REVERSED) {
        modifiers |= SgrModifiers::REVERSE;
    }
    if added.contains(Modifier::BOLD) {
        modifiers |= SgrModifiers::INTENSITY_BOLD;
    }
    if added.contains(Modifier::DIM) {
        modifiers |= SgrModifiers::INTENSITY_DIM;
    }
    if added.contains(Modifier::ITALIC) {
        modifiers |= SgrModifiers::ITALIC;
    }
    if added.contains(Modifier::CROSSED_OUT) {
        modifiers |= SgrModifiers::STRIKE_THROUGH;
    }
    if added.contains(Modifier::HIDDEN) {
        modifiers |= SgrModifiers::INVISIBLE;
    }
    if added.contains(Modifier::SLOW_BLINK) {
        modifiers |= SgrModifiers::BLINK_SLOW;
    }
    if added.contains(Modifier::RAPID_BLINK) {
        modifiers |= SgrModifiers::BLINK_RAPID;
    }

    modifiers
}

fn color_to_termina(color: RatatuiColor) -> ColorSpec {
    match color {
        RatatuiColor::Reset => ColorSpec::Reset,
        RatatuiColor::Black => ColorSpec::BLACK,
        RatatuiColor::Red => ColorSpec::RED,
        RatatuiColor::Green => ColorSpec::GREEN,
        RatatuiColor::Yellow => ColorSpec::YELLOW,
        RatatuiColor::Blue => ColorSpec::BLUE,
        RatatuiColor::Magenta => ColorSpec::MAGENTA,
        RatatuiColor::Cyan => ColorSpec::CYAN,
        RatatuiColor::Gray => ColorSpec::WHITE,
        RatatuiColor::DarkGray => ColorSpec::BRIGHT_BLACK,
        RatatuiColor::LightRed => ColorSpec::BRIGHT_RED,
        RatatuiColor::LightGreen => ColorSpec::BRIGHT_GREEN,
        RatatuiColor::LightYellow => ColorSpec::BRIGHT_YELLOW,
        RatatuiColor::LightBlue => ColorSpec::BRIGHT_BLUE,
        RatatuiColor::LightMagenta => ColorSpec::BRIGHT_MAGENTA,
        RatatuiColor::LightCyan => ColorSpec::BRIGHT_CYAN,
        RatatuiColor::White => ColorSpec::BRIGHT_WHITE,
        RatatuiColor::Indexed(index) => ColorSpec::PaletteIndex(index),
        RatatuiColor::Rgb(r, g, b) => RgbColor::new(r, g, b).into(),
    }
}

#[cfg(test)]
mod tests {
    use super::write_reset_background_color;

    #[test]
    fn reset_background_color_releases_the_dynamic_background() {
        let mut output = Vec::new();

        write_reset_background_color(&mut output).unwrap();

        assert_eq!(output, b"\x1b]111\x1b\\");
    }
}
