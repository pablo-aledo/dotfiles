//! Minimal stdio language server for document-feature integration tests.
//! Full text sync and UTF-16 positions exercise the real client transport.
use std::{
    collections::HashMap,
    io::{self, BufRead, Read, Write},
};

use serde_json::{json, Value};

fn respond(output: &mut impl Write, message: Value) -> anyhow::Result<()> {
    let body = serde_json::to_vec(&message)?;
    write!(output, "Content-Length: {}\r\n\r\n", body.len())?;
    output.write_all(&body)?;
    output.flush()?;
    Ok(())
}

fn range(start: usize, end: usize) -> Value {
    json!({"start": {"line": 0, "character": start}, "end": {"line": 0, "character": end}})
}

fn main() -> anyhow::Result<()> {
    let mut input = io::stdin().lock();
    let mut output = io::stdout().lock();
    let mut documents = HashMap::<String, String>::new();
    let mut versions = HashMap::<String, i64>::new();
    let mut diagnostic_requests = HashMap::<(String, i64), usize>::new();
    // Optional modes expose only the feature under test.
    let args: Vec<_> = std::env::args().skip(1).collect();
    let formatting = args.first().is_some_and(|arg| arg == "--formatting");
    let diagnostics = args.first().is_some_and(|arg| arg == "--diagnostics");
    let action_execution = args.first().is_some_and(|arg| arg == "--action-execution");
    let code_actions = args.first().is_some_and(|arg| arg == "--code-actions");
    let code_lenses = args.first().is_some_and(|arg| arg == "--code-lenses");
    let mut hold_lenses = args.iter().any(|arg| arg == "--hold-resolves");
    let mut held_lenses = Vec::<Value>::new();
    let navigation = args.first().is_some_and(|arg| arg == "--navigation");
    let language_features = args.first().is_some_and(|arg| arg == "--language-features");
    let signature_help = args.first().is_some_and(|arg| arg == "--signature-help");
    let inline_completion = args.first().is_some_and(|arg| arg == "--inline-completion");
    let completion = args.first().is_some_and(|arg| arg == "--completion");
    let lifecycle = args.first().is_some_and(|arg| arg == "--lifecycle");
    let mut request_log = if formatting
        || diagnostics
        || code_actions
        || lifecycle
        || signature_help
        || language_features
        || navigation
        || completion
        || inline_completion
        || action_execution
        || code_lenses
    {
        Some(std::fs::File::create(&args[2])?)
    } else {
        None
    };
    loop {
        let mut length = None;
        loop {
            let mut line = String::new();
            if input.read_line(&mut line)? == 0 {
                return Ok(());
            }
            if line == "\r\n" {
                break;
            }
            if let Some(value) = line.strip_prefix("Content-Length: ") {
                length = Some(value.trim().parse::<usize>()?);
            }
        }
        let mut bytes = vec![0; length.ok_or_else(|| anyhow::anyhow!("missing Content-Length"))?];
        input.read_exact(&mut bytes)?;
        let message: Value = serde_json::from_slice(&bytes)?;
        let method = message["method"].as_str().unwrap_or_default();
        let params = &message["params"];
        let uri = params["textDocument"]["uri"].as_str().unwrap_or_default();
        // Hold initialization until the test has finished attaching the document.
        // Otherwise a fast server can race launch_language_servers and didOpen.
        if method == "initialize"
            && let Some(index) = args.iter().position(|arg| arg == "--initialize-gate")
        {
            while !std::path::Path::new(&args[index + 1]).exists() {
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
        }
        if formatting || action_execution || code_lenses || language_features || navigation {
            writeln!(request_log.as_mut().unwrap(), "{message}")?;
            request_log.as_mut().unwrap().flush()?;
        }
        if lifecycle {
            writeln!(request_log.as_mut().unwrap(), "{message}")?;
            request_log.as_mut().unwrap().flush()?;
            // Tests can hold initialization until a pre-initialization notification is checked.
            if method == "initialize"
                && let Some(gate) = args.get(3)
            {
                while !std::path::Path::new(gate).exists() {
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
            }
        }
        if method == "initialize" && args.iter().any(|arg| arg == "--reject-initialize") {
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": message["id"],
                "error": {"code": -32603, "message": "test initialization failure"}}),
            )?;
            continue;
        }
        if method == "initialize" && args.iter().any(|arg| arg == "--ignore-initialize") {
            continue;
        }
        if method == "initialize" && args.iter().any(|arg| arg == "--exit-on-initialize") {
            return Ok(());
        }
        match method {
            "textDocument/didOpen" => {
                versions.insert(
                    uri.into(),
                    params["textDocument"]["version"].as_i64().unwrap(),
                );
                documents.insert(
                    uri.into(),
                    params["textDocument"]["text"].as_str().unwrap().into(),
                );
                if code_lenses && args.iter().any(|arg| arg == "--refresh") {
                    respond(
                        &mut output,
                        json!({"jsonrpc": "2.0", "id": "lens-refresh",
                        "method": "workspace/codeLens/refresh", "params": null}),
                    )?;
                }
                if lifecycle {
                    respond(
                        &mut output,
                        json!({"jsonrpc": "2.0", "method": "textDocument/publishDiagnostics",
                            "params": {"uri": uri, "version": params["textDocument"]["version"],
                                "diagnostics": [{"range": range(3, 6), "severity": 2, "message": args[1]}]}
                        }),
                    )?;
                }
                continue;
            }
            "textDocument/didChange" => {
                versions.insert(
                    uri.into(),
                    params["textDocument"]["version"].as_i64().unwrap(),
                );
                documents.insert(
                    uri.into(),
                    params["contentChanges"][0]["text"].as_str().unwrap().into(),
                );
                continue;
            }
            "exit" => return Ok(()),
            _ => {}
        }
        // Client replies to server requests are logged, but need no response.
        if !message["method"].is_string() {
            continue;
        }
        let Some(id) = message.get("id") else {
            continue;
        };
        let text = documents.get(uri).map(|s| s.trim()).unwrap_or_default();
        let end = text.encode_utf16().count();
        if method == "textDocument/diagnostic" && diagnostics {
            let label = &args[1];
            let version = versions.get(uri).copied().unwrap_or_default();
            writeln!(request_log.as_mut().unwrap(), "{params}")?;
            request_log.as_mut().unwrap().flush()?;
            let count = diagnostic_requests
                .entry((uri.into(), version))
                .or_default();
            *count += 1;
            if text.contains("retry") && *count == 1 {
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": id, "error": {
                        "code": lsp_client::lsp::error_codes::SERVER_CANCELLED,
                        "message": "retry once", "data": {"retriggerRequest": true}
                    }}),
                )?;
                continue;
            }
            let result_id = format!("{label}:{version}");
            let result = if params["previousResultId"].as_str() == Some(&result_id) {
                json!({"kind": "unchanged", "resultId": result_id})
            } else {
                let mut report = json!({"kind": "full", "items": [{
                    "range": range(3, end), "severity": 2, "message": format!("{label}: {text}")
                }]});
                if !text.contains("no-id") {
                    report["resultId"] = json!(result_id);
                }
                report
            };
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if method == "textDocument/codeAction"
            && action_execution
            && args.iter().any(|arg| arg == "--save-actions")
        {
            let kind = params["context"]["only"][0].as_str().unwrap_or("quickfix");
            let replacement = if kind == "source.first" {
                "first"
            } else {
                "second"
            };
            let result = json!([
                {"title": "disabled", "kind": kind, "disabled": {"reason": "unavailable"}},
                {"title": "unclassified"},
                {"title": "unrelated", "kind": format!("{kind}Other")},
                {"title": "command", "command": "fixture.command"},
                {"title": "save action", "kind": format!("{kind}.fixture"),
                    "data": {"uri": uri, "version": versions[uri],
                        "replacement": replacement, "end": end}}
            ]);
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if method == "textDocument/codeAction" && code_actions {
            writeln!(request_log.as_mut().unwrap(), "{params}")?;
            request_log.as_mut().unwrap().flush()?;
            let result = if text.contains("disabled") {
                json!([{"title": "disabled", "disabled": {"reason": "unavailable"}}])
            } else if text.contains("empty") {
                Value::Null
            } else if text.contains("command") {
                json!([{"title": "command", "command": "fixture.command"}])
            } else {
                json!([{"title": format!("{}: {text}", args[1]), "kind": "quickfix"}])
            };
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if method == "textDocument/inlineCompletion" && inline_completion {
            writeln!(request_log.as_mut().unwrap(), "{params}")?;
            request_log.as_mut().unwrap().flush()?;
            let items = json!([
                {"range": range(3, 5), "insertText": "print(界)\n\treturn 1"},
                {"insertText": "# alternate"}
            ]);
            let result = if text.contains("empty") {
                Value::Null
            } else if args.iter().any(|arg| arg == "--array") {
                items
            } else {
                json!({"items": items})
            };
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if navigation
            && matches!(
                method,
                "textDocument/definition"
                    | "textDocument/declaration"
                    | "textDocument/typeDefinition"
                    | "textDocument/implementation"
                    | "textDocument/references"
                    | "textDocument/documentHighlight"
            )
        {
            if args.iter().any(|arg| arg == "--hold-navigation") {
                continue;
            }
            if args.iter().any(|arg| arg == "--navigation-error") {
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": id, "error": {"code": -32603, "message": "navigation fixture error"}}),
                )?;
                continue;
            }
            let start = if args.iter().any(|arg| arg == "--utf-8") {
                5
            } else {
                3
            };
            let location = json!({"uri": uri, "range": range(start, start + 3)});
            let result = if text.contains("empty") {
                Value::Null
            } else {
                match method {
                    "textDocument/definition" => location,
                    "textDocument/declaration" | "textDocument/references" => json!([location]),
                    "textDocument/implementation" => {
                        json!([{"uri": "https://example.com/unsupported", "range": range(0, 1)}, location])
                    }
                    "textDocument/typeDefinition" => {
                        json!([{"targetUri": uri, "targetRange": range(start, start + 3), "targetSelectionRange": range(start + 1, start + 2)}])
                    }
                    "textDocument/documentHighlight" if text.contains("invalid") => {
                        json!([{"range": {"start": {"line": 999, "character": 0}, "end": {"line": 999, "character": 1}}}])
                    }
                    "textDocument/documentHighlight" => {
                        json!([{"range": range(start, start + 3)}, {"range": range(start + 4, start + 7)}])
                    }
                    _ => unreachable!(),
                }
            };
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if language_features && matches!(method, "textDocument/hover" | "textDocument/inlayHint") {
            if method == "textDocument/hover" && args.iter().any(|arg| arg == "--hold-hover") {
                continue;
            }
            let result = if text.contains("empty") {
                Value::Null
            } else if method == "textDocument/hover" {
                json!({"contents": {"kind": "plaintext", "value": format!("{}: {text}", args[1])}})
            } else {
                json!([{"position": {"line": 0, "character": 3}, "label": format!("界é {text}"), "kind": 1, "paddingLeft": true, "paddingRight": true}])
            };
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if method == "textDocument/signatureHelp" && signature_help {
            writeln!(request_log.as_mut().unwrap(), "{params}")?;
            request_log.as_mut().unwrap().flush()?;
            if let Some(index) = args.iter().position(|arg| arg == "--response-gate") {
                while !std::path::Path::new(&args[index + 1]).exists() {
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
            }
            if text.contains("error") {
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": id,
                    "error": {"code": -32603, "message": "signature fixture error"}}),
                )?;
                continue;
            }
            let result = if text.contains("empty") {
                Value::Null
            } else if text.contains("no-signatures") {
                json!({"signatures": []})
            } else {
                json!({"signatures": [
                    {"label": format!("{}: {text}", args[1]), "documentation": "first signature"},
                    {"label": "second(value)", "parameters": [{"label": "value"}], "activeParameter": 0}
                ], "activeSignature": 0})
            };
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if method == "textDocument/completion" && (completion || inline_completion) {
            writeln!(request_log.as_mut().unwrap(), "{params}")?;
            request_log.as_mut().unwrap().flush()?;
            if let Some(index) = args.iter().position(|arg| arg == "--response-gate") {
                while !std::path::Path::new(&args[index + 1]).exists() {
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
            }
            let end = params["position"]["character"].as_u64().unwrap() as usize;
            let line = params["position"]["line"].as_u64().unwrap();
            let mut edit_range = range(end.saturating_sub(2), end);
            edit_range["start"]["line"] = json!(line);
            edit_range["end"]["line"] = json!(line);
            let (first, second) = if inline_completion {
                ("print", "println")
            } else {
                ("apple", "apricot")
            };
            let result = json!({"isIncomplete": text.contains("incomplete"), "items": [
                {"label": first, "sortText": "2", "detail": args[1],
                    "textEdit": {"range": edit_range, "newText": first}},
                {"label": second, "sortText": "1", "detail": args[1],
                    "textEdit": {"range": edit_range, "newText": second}}
            ]});
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": result}),
            )?;
            continue;
        }
        if method == "completionItem/resolve" && (completion || inline_completion) {
            let mut item = params.clone();
            item["documentation"] = json!("resolved documentation");
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": item}),
            )?;
            continue;
        }
        if method == "codeAction/resolve" && action_execution {
            if let Some(index) = args.iter().position(|arg| arg == "--response-gate") {
                while !std::path::Path::new(&args[index + 1]).exists() {
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
            }
            if params["data"]["failure"] == "resolve" {
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": id,
                    "error": {"code": -32603, "message": "fixture resolve failure"}}),
                )?;
            } else {
                let mut action = params.clone();
                let version = if params["data"]["failure"] == "edit" {
                    -1
                } else {
                    params["data"]["version"].as_i64().unwrap()
                };
                action["edit"] = json!({"documentChanges": [{
                    "textDocument": {"uri": params["data"]["uri"], "version": version},
                    "edits": [{"range": range(0, params["data"]["end"].as_u64().unwrap_or(3) as usize),
                        "newText": params["data"]["replacement"].as_str().unwrap_or("fixed")}]
                }]});
                action["command"] = json!({"title": "after edit", "command": "fixture.command"});
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": id, "result": action}),
                )?;
            }
            continue;
        }
        if method == "codeLens/resolve" && code_lenses {
            if hold_lenses {
                held_lenses.push(message.clone());
                continue;
            }
            let mut lens = params.clone();
            // Fail one lens and leave another unresolved to exercise partial results.
            if params["data"]["kind"] == "failure" {
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": id,
                    "error": {"code": -32603, "message": "fixture resolution failure"}}),
                )?;
                continue;
            }
            if params["data"]["kind"] != "empty" {
                lens["command"] = json!({"title": format!("{} resolved", args[1]),
                    "command": "fixture.lens", "arguments": [args[1], params["data"]]});
            }
            respond(
                &mut output,
                json!({"jsonrpc": "2.0", "id": id, "result": lens}),
            )?;
            continue;
        }
        if method == "workspace/executeCommand"
            && code_lenses
            && params["command"] == "fixture.release-lenses"
        {
            hold_lenses = false;
            for message in std::mem::take(&mut held_lenses) {
                let mut lens = message["params"].clone();
                lens["command"] = json!({"title": format!("{} resolved", args[1]),
                    "command": "fixture.lens", "arguments": [args[1], lens["data"]]});
                respond(
                    &mut output,
                    json!({"jsonrpc": "2.0", "id": message["id"], "result": lens}),
                )?;
            }
        }
        if method == "documentLink/resolve"
            && let Some(index) = args.iter().position(|arg| arg == "--resolve-link-gate")
        {
            let gate = std::path::Path::new(&args[index + 1]);
            std::fs::write(gate.with_extension("started"), "ready")?;
            while !gate.exists() {
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
        }
        // Test documents start with an emoji and a space: UTF-16 column 3 is char 2.
        let result = match method {
            "initialize" if formatting => json!({"capabilities": {
                "textDocumentSync": 1, "documentRangeFormattingProvider": true
            }}),
            "textDocument/rangeFormatting" if formatting => json!([{
                "range": params["range"], "newText": "formatted"
            }]),
            "initialize" if code_lenses => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "codeLensProvider": {"resolveProvider": !args.iter().any(|arg| arg == "--no-resolve")},
                "executeCommandProvider": {"commands": ["fixture.lens"]}
            }}),
            "initialize" if action_execution => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "codeActionProvider": {"resolveProvider": !args.iter().any(|arg| arg == "--no-resolve")},
                "executeCommandProvider": {"commands": ["fixture.command"]}
            }}),
            "initialize" if inline_completion => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "inlineCompletionProvider": true,
                "completionProvider": {"resolveProvider": true}
            }}),
            "initialize" if completion => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "completionProvider": {"triggerCharacters": ["."], "resolveProvider": true}
            }}),
            "initialize" if navigation => json!({"capabilities": {
                "textDocumentSync": 1,
                "positionEncoding": if args.iter().any(|arg| arg == "--utf-8") { "utf-8" } else { "utf-16" },
                "definitionProvider": true, "declarationProvider": true, "typeDefinitionProvider": true,
                "implementationProvider": true, "referencesProvider": true, "documentHighlightProvider": true
            }}),
            "initialize" if language_features => json!({"capabilities": {
                "textDocumentSync": 1, "positionEncoding": "utf-16", "hoverProvider": true, "inlayHintProvider": true
            }}),
            "initialize" if signature_help => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "signatureHelpProvider": {"triggerCharacters": ["(", ","]}
            }}),
            "initialize" if lifecycle => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1, "documentSymbolProvider": true
            }}),
            "initialize" if code_actions => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1, "codeActionProvider": true
            }}),
            "initialize" if diagnostics => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "diagnosticProvider": {"identifier": args[1], "workspaceDiagnostics": false,
                    "interFileDependencies": args.iter().any(|arg| arg == "--inter-file")}
            }}),
            "initialize" => json!({"capabilities": {
                "positionEncoding": "utf-16", "textDocumentSync": 1,
                "documentSymbolProvider": true, "documentHighlightProvider": true,
                "colorProvider": true, "documentLinkProvider": {"resolveProvider": args.iter().any(|arg| arg == "--resolve-links")}, "codeLensProvider": {}
            }}),
            "textDocument/documentSymbol" => json!([{
                "name": text, "kind": 12, "range": range(0, end), "selectionRange": range(3, end)
            }]),
            "textDocument/documentHighlight" => json!([
                {"range": range(3, 5)}, {"range": range(4, end)}
            ]),
            "textDocument/documentColor" => json!([{
                "range": range(3, end), "color": {"red": 1.0, "green": 0.0, "blue": 0.0, "alpha": 1.0}
            }]),
            "textDocument/documentLink" if args.iter().any(|arg| arg == "--resolve-links") => {
                json!([{
                    "range": range(3, end), "data": {"target": format!("{uri}.resolved")}
                }])
            }
            "documentLink/resolve" => {
                let mut link = params.clone();
                link["target"] = params["data"]["target"].clone();
                link
            }
            "textDocument/documentLink" => json!([{
                "range": range(3, end), "target": "https://example.test/target"
            }]),
            "textDocument/codeLens" if code_lenses && text.contains("no lenses") => Value::Null,
            "textDocument/codeLens"
                if code_lenses && args.iter().any(|arg| arg == "--per-line") =>
            {
                Value::Array(
                    documents
                        .get(uri)
                        .unwrap()
                        .lines()
                        .enumerate()
                        .map(|(line, text)| {
                            json!({"range": {"start": {"line": line, "character": 0},
                        "end": {"line": line, "character": text.encode_utf16().count()}},
                        "data": {"server": args[1], "kind": "resolve", "line": line}})
                        })
                        .collect(),
                )
            }
            "textDocument/codeLens" if code_lenses => json!([
                {"range": range(3, end), "command": {"title": format!("{} ready", args[1]),
                    "command": "fixture.lens", "arguments": [args[1]]}},
                {"range": range(3, end), "data": {"server": args[1], "kind": "resolve"}},
                {"range": range(3, end), "data": {"server": args[1], "kind": "empty"}},
                {"range": range(3, end), "data": {"server": args[1], "kind": "failure"}},
                {"range": {"start": {"line": 99, "character": 0}, "end": {"line": 99, "character": 0}}}
            ]),
            "textDocument/codeLens" => json!([{"range": range(3, end)}]),
            _ => Value::Null,
        };
        respond(
            &mut output,
            json!({"jsonrpc": "2.0", "id": id, "result": result}),
        )?;
    }
}
