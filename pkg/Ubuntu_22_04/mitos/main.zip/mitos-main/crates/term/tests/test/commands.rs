use stdx::path;
use term::application::Application;
use view::{
    doc,
    quicklist::{QuicklistEntry, QuicklistPosition, QuicklistTarget},
};

use super::*;

mod insert;
mod movement;
mod replace;
mod reverse_selection_contents;
mod rotate_selection_contents;
#[cfg(feature = "git")]
mod vcs;
mod write;

#[tokio::test(flavor = "multi_thread")]
async fn select_all_diagnostics_inside_selection() -> anyhow::Result<()> {
    use ::diagnostics::{
        Diagnostic, DiagnosticProvider, DiagnosticTag, LanguageServerId, Severity,
    };
    use stdx::range::Range as DiagnosticRange;

    let mut app = AppBuilder::new()
        .with_input_text(indoc! {"\
            #[|]#aaa
            bbb
            ccc
        "})
        .build()?;

    let provider = DiagnosticProvider::Lsp {
        server_id: LanguageServerId::default(),
        identifier: None,
    };

    {
        let (_view, doc) = view::current!(app.editor);
        doc.replace_diagnostics(
            [
                Diagnostic {
                    range: DiagnosticRange { start: 0, end: 3 },
                    ends_at_word: true,
                    starts_at_word: true,
                    zero_width: false,
                    line: 0,
                    message: "first".into(),
                    severity: Some(Severity::Error),
                    code: None,
                    provider: provider.clone(),
                    tags: Vec::<DiagnosticTag>::new(),
                    source: None,
                    data: None,
                },
                Diagnostic {
                    range: DiagnosticRange { start: 8, end: 11 },
                    ends_at_word: true,
                    starts_at_word: true,
                    zero_width: false,
                    line: 2,
                    message: "second".into(),
                    severity: Some(Severity::Warning),
                    code: None,
                    provider,
                    tags: Vec::<DiagnosticTag>::new(),
                    source: None,
                    data: None,
                },
            ],
            &[],
            None,
        );
    }

    test_key_sequence(
        &mut app,
        Some("%mId"),
        Some(&|app| {
            let (view, doc) = view::current_ref!(app.editor);
            assert_eq!(
                indoc! {"\
                    #[aaa|]#
                    bbb
                    #(ccc|)#
                "},
                editor_core::test::plain(doc.text().slice(..), doc.selection(view.id))
            );
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn select_all_tree_sitter_textobjects_inside_selection() -> anyhow::Result<()> {
    test_with_config(
        AppBuilder::new().with_file("foo.rs", None),
        (
            indoc! {"\
                #[|]#fn foo(first: i32, second: bool) {}
            "},
            "%mIa",
            indoc! {"\
                fn foo(#[first: i32|]#, #(second: bool|)#) {}
            "},
        ),
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn select_all_word_textobjects_inside_selection() -> anyhow::Result<()> {
    test((
        indoc! {"\
            #[|]#one two three
        "},
        "%mIw",
        indoc! {"\
            #[one|]# #(two|)# #(three|)#
        "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn search_selection_detect_word_boundaries_at_eof() -> anyhow::Result<()> {
    // <https://github.com/helix-editor/helix/issues/12609>
    test((
        indoc! {"\
            #[o|]#ne
            two
            three"},
        "gej*h",
        indoc! {"\
            one
            two
            three#[
            |]#"},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_selection_duplication() -> anyhow::Result<()> {
    // Forward
    test((
        indoc! {"\
            #[lo|]#rem
            ipsum
            dolor
            "},
        "CC",
        indoc! {"\
            #(lo|)#rem
            #(ip|)#sum
            #[do|]#lor
            "},
    ))
    .await?;

    // Backward
    test((
        indoc! {"\
            #[|lo]#rem
            ipsum
            dolor
            "},
        "CC",
        indoc! {"\
            #(|lo)#rem
            #(|ip)#sum
            #[|do]#lor
            "},
    ))
    .await?;

    // Copy the selection to previous line, skipping the first line in the file
    test((
        indoc! {"\
            test
            #[testitem|]#
            "},
        "<A-C>",
        indoc! {"\
            test
            #[testitem|]#
            "},
    ))
    .await?;

    // Copy the selection to previous line, including the first line in the file
    test((
        indoc! {"\
            test
            #[test|]#
            "},
        "<A-C>",
        indoc! {"\
            #[test|]#
            #(test|)#
            "},
    ))
    .await?;

    // Copy the selection to next line, skipping the last line in the file
    test((
        indoc! {"\
            #[testitem|]#
            test
            "},
        "C",
        indoc! {"\
            #[testitem|]#
            test
            "},
    ))
    .await?;

    // Copy the selection to next line, including the last line in the file
    test((
        indoc! {"\
            #[test|]#
            test
            "},
        "C",
        indoc! {"\
            #(test|)#
            #[test|]#
            "},
    ))
    .await?;
    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_goto_file_impl() -> anyhow::Result<()> {
    let file = tempfile::NamedTempFile::new()?;

    fn match_paths(app: &Application, matches: Vec<&str>) -> usize {
        app.editor
            .documents()
            .filter_map(|d| d.path()?.file_name())
            .filter(|n| matches.iter().any(|m| *m == n.to_string_lossy()))
            .count()
    }

    // Single selection
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("ione.js<esc>%gf"),
        Some(&|app| {
            assert_eq!(1, match_paths(app, vec!["one.js"]));
        }),
        false,
    )
    .await?;

    // Multiple selection
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("ione.js<ret>two.js<esc>%<A-s>gf"),
        Some(&|app| {
            assert_eq!(2, match_paths(app, vec!["one.js", "two.js"]));
        }),
        false,
    )
    .await?;

    // Cursor on first quote
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("iimport 'one.js'<esc>B;gf"),
        Some(&|app| {
            assert_eq!(1, match_paths(app, vec!["one.js"]));
        }),
        false,
    )
    .await?;

    // Cursor on last quote
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("iimport 'one.js'<esc>bgf"),
        Some(&|app| {
            assert_eq!(1, match_paths(app, vec!["one.js"]));
        }),
        false,
    )
    .await?;

    // ';' is behind the path
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("iimport 'one.js';<esc>B;gf"),
        Some(&|app| {
            assert_eq!(1, match_paths(app, vec!["one.js"]));
        }),
        false,
    )
    .await?;

    // allow numeric values in path
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("iimport 'one123.js'<esc>B;gf"),
        Some(&|app| {
            assert_eq!(1, match_paths(app, vec!["one123.js"]));
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_picker_quicklist_navigation() -> anyhow::Result<()> {
    let dir = tempfile::tempdir()?;
    let alpha = dir.path().join("alpha.rs");
    let beta = dir.path().join("beta.rs");
    std::fs::write(&alpha, "fn alpha() {}\n")?;
    std::fs::write(&beta, "fn beta() {}\n")?;

    test_key_sequence(
        &mut AppBuilder::new()
            .with_file(&alpha, None)
            .with_file(&beta, None)
            .build()?,
        Some("<space>balpha<C-q><esc>]q"),
        Some(&|app| {
            let doc = doc!(app.editor);
            let expected = path::normalize(&alpha);
            assert_eq!(doc.path(), Some(expected.as_path()));
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_quicklist_navigation_from_empty_scratch_buffer() -> anyhow::Result<()> {
    let file = tempfile::NamedTempFile::new()?;
    std::fs::write(file.path(), "alpha\n")?;

    let mut app = AppBuilder::new().build()?;
    app.editor.replace_quicklist(vec![QuicklistEntry {
        target: QuicklistTarget::Path(file.path().to_path_buf()),
        position: QuicklistPosition::LineRange { start: 0, end: 0 },
    }]);

    test_key_sequence(
        &mut app,
        Some("]q"),
        Some(&|app| {
            let doc = doc!(app.editor);
            let expected = path::normalize(file.path());
            assert_eq!(doc.path(), Some(expected.as_path()));
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_quicklist_motion_pushes_pre_jump_location_to_jumplist() -> anyhow::Result<()> {
    let dir = tempfile::tempdir()?;
    let file = dir.path().join("quicklist.rs");
    std::fs::write(&file, "alpha\nbeta\ngamma\n")?;

    let mut app = AppBuilder::new().with_file(&file, None).build()?;

    let initial_cursor = 0;
    {
        let (view, doc) = view::current!(app.editor);
        doc.set_selection(view.id, editor_core::Selection::point(initial_cursor));
        view.sync_changes(doc);
    }
    app.editor.replace_quicklist(vec![QuicklistEntry {
        target: QuicklistTarget::Path(file.clone()),
        position: QuicklistPosition::LineRange { start: 1, end: 1 },
    }]);

    test_key_sequence(
        &mut app,
        Some("]q<C-o>"),
        Some(&|app| {
            let (view, doc) = view::current_ref!(app.editor);
            assert_eq!(
                doc.selection(view.id)
                    .primary()
                    .cursor(doc.text().slice(..)),
                initial_cursor,
            );
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_quicklist_picker_navigation() -> anyhow::Result<()> {
    let dir = tempfile::tempdir()?;
    let alpha = dir.path().join("alpha.rs");
    let beta = dir.path().join("beta.rs");
    std::fs::write(&alpha, "fn alpha() {}\n")?;
    std::fs::write(&beta, "fn beta() {}\n")?;

    test_key_sequence(
        &mut AppBuilder::new()
            .with_file(&alpha, None)
            .with_file(&beta, None)
            .build()?,
        Some("<space>balpha<C-q><esc><space>q<ret>"),
        Some(&|app| {
            let doc = doc!(app.editor);
            let expected = path::normalize(&alpha);
            assert_eq!(doc.path(), Some(expected.as_path()));
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_picker_quicklist_preserves_unsaved_buffer_entries() -> anyhow::Result<()> {
    test_key_sequence(
        &mut AppBuilder::new().with_input_text("#[hello|]#").build()?,
        Some("<space>b<C-q><esc>]q"),
        Some(&|app| {
            let doc = doc!(app.editor);
            assert_eq!(doc.path(), None);
            helpers::assert_status_not_error(&app.editor);
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_failed_quicklist_motion_does_not_pollute_jumplist() -> anyhow::Result<()> {
    test_key_sequence(
        &mut AppBuilder::new().build()?,
        Some("]q"),
        Some(&|app| {
            let (view, _) = view::current_ref!(app.editor);
            assert_eq!(view.jumps.iter().count(), 1);
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_jumplist_picker_quicklist_preserves_exact_selection() -> anyhow::Result<()> {
    let dir = tempfile::tempdir()?;
    let file = dir.path().join("jumplist.rs");
    std::fs::write(&file, "alpha\nbeta\ngamma\n")?;

    let mut app = AppBuilder::new().with_file(&file, None).build()?;

    let selection = editor_core::Selection::single(6, 10);
    {
        let (view, doc) = view::current!(app.editor);
        doc.set_selection(view.id, selection.clone());
        view.push_jump(doc, (doc.id(), selection.clone()));
    }

    test_key_sequence(
        &mut app,
        Some("<space>j<C-q><esc>]q"),
        Some(&|app| {
            let (view, doc) = view::current_ref!(app.editor);
            assert_eq!(doc.selection(view.id), &selection);
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_syntax_symbol_quicklist_preserves_exact_declaration_selection() -> anyhow::Result<()>
{
    let dir = tempfile::tempdir()?;
    let file = dir.path().join("symbols.rs");
    std::fs::write(&file, "fn alpha() {}\nfn banana() {}\n")?;

    test_key_sequence(
        &mut AppBuilder::new().with_file(&file, None).build()?,
        Some("<space>sbanana<C-q><esc>]q"),
        Some(&|app| {
            let (view, doc) = view::current_ref!(app.editor);
            let text = doc.text().slice(..);
            assert_eq!(
                doc.selection(view.id).primary().fragment(text),
                "fn banana() {}"
            );
        }),
        false,
    )
    .await?;

    Ok(())
}
#[tokio::test(flavor = "multi_thread")]
async fn test_multi_selection_paste() -> anyhow::Result<()> {
    test((
        indoc! {"\
            #[|lorem]#
            #(|ipsum)#
            #(|dolor)#
            "},
        "yp",
        indoc! {"\
            lorem#[|lorem]#
            ipsum#(|ipsum)#
            dolor#(|dolor)#
            "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_multi_selection_shell_commands() -> anyhow::Result<()> {
    // pipe
    test((
        indoc! {"\
            #[|lorem]#
            #(|ipsum)#
            #(|dolor)#
            "},
        "|echo foo<ret>",
        indoc! {"\
            #[|foo]#
            #(|foo)#
            #(|foo)#"
        },
    ))
    .await?;

    // insert-output
    test((
        indoc! {"\
            #[|lorem]#
            #(|ipsum)#
            #(|dolor)#
            "},
        "!echo foo<ret>",
        indoc! {"\
            #[|foo]#lorem
            #(|foo)#ipsum
            #(|foo)#dolor
            "},
    ))
    .await?;

    // append-output
    test((
        indoc! {"\
            #[|lorem]#
            #(|ipsum)#
            #(|dolor)#
            "},
        "<A-!>echo foo<ret>",
        indoc! {"\
            lorem#[|foo]#
            ipsum#(|foo)#
            dolor#(|foo)#
            "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_undo_redo() -> anyhow::Result<()> {
    // A jumplist selection is created at a point which is undone.
    //
    // * 2[<space>   Add two newlines at line start. We're now on line 3.
    // * <C-s>       Save the selection on line 3 in the jumplist.
    // * u           Undo the two newlines. We're now on line 1.
    // * <C-o><C-i>  Jump forward an back again in the jumplist. This would panic
    //               if the jumplist were not being updated correctly.
    test((
        "#[|]#",
        "2[<space><C-s>u<C-o><C-i>",
        "#[|]#",
        LineFeedHandling::AsIs,
    ))
    .await?;

    // A jumplist selection is passed through an edit and then an undo and then a redo.
    //
    // * [<space>    Add a newline at line start. We're now on line 2.
    // * <C-s>       Save the selection on line 2 in the jumplist.
    // * kd          Delete line 1. The jumplist selection should be adjusted to the new line 1.
    // * uU          Undo and redo the `kd` edit.
    // * <C-o>       Jump back in the jumplist. This would panic if the jumplist were not being
    //               updated correctly.
    // * <C-i>       Jump forward to line 1.
    test((
        "#[|]#",
        "[<space><C-s>kduU<C-o><C-i>",
        "#[|]#",
        LineFeedHandling::AsIs,
    ))
    .await?;

    // In this case we 'redo' manually to ensure that the transactions are composing correctly.
    test((
        "#[|]#",
        "[<space>u[<space>u",
        "#[|]#",
        LineFeedHandling::AsIs,
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_extend_line() -> anyhow::Result<()> {
    // extend with line selected then count
    test((
        indoc! {"\
            #[l|]#orem
            ipsum
            dolor
            
            "},
        "x2x",
        indoc! {"\
            #[lorem
            ipsum
            dolor\n|]#
            
            "},
    ))
    .await?;

    // extend with count on partial selection
    test((
        indoc! {"\
            #[l|]#orem
            ipsum
            
            "},
        "2x",
        indoc! {"\
            #[lorem
            ipsum\n|]#
            
            "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_character_info() -> anyhow::Result<()> {
    // UTF-8, single byte
    test_key_sequence(
        &mut helpers::AppBuilder::new().build()?,
        Some("ih<esc>h:char<ret>"),
        Some(&|app| {
            assert_eq!(
                r#""h" (U+0068) Dec 104 Hex 68"#,
                app.editor.get_status().unwrap().0
            );
        }),
        false,
    )
    .await?;

    // UTF-8, multi-byte
    test_key_sequence(
        &mut helpers::AppBuilder::new().build()?,
        Some("ië<esc>h:char<ret>"),
        Some(&|app| {
            assert_eq!(
                r#""ë" (U+0065 U+0308) Hex 65 + cc 88"#,
                app.editor.get_status().unwrap().0
            );
        }),
        false,
    )
    .await?;

    // Multiple characters displayed as one, escaped characters
    test_key_sequence(
        &mut helpers::AppBuilder::new().build()?,
        Some(":line<minus>ending crlf<ret>:char<ret>"),
        Some(&|app| {
            assert_eq!(
                r#""\r\n" (U+000d U+000a) Hex 0d + 0a"#,
                app.editor.get_status().unwrap().0
            );
        }),
        false,
    )
    .await?;

    // Non-UTF-8
    test_key_sequence(
        &mut helpers::AppBuilder::new().build()?,
        Some(":encoding ascii<ret>ih<esc>h:char<ret>"),
        Some(&|app| {
            assert_eq!(r#""h" Dec 104 Hex 68"#, app.editor.get_status().unwrap().0);
        }),
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_delete_char_backward() -> anyhow::Result<()> {
    // don't panic when deleting overlapping ranges
    test(("#(x|)# #[x|]#", "c<space><backspace><esc>", "#[\n|]#")).await?;
    test((
        "#( |)##( |)#a#( |)#axx#[x|]#a",
        "li<backspace><esc>",
        "#(a|)##(|a)#xx#[|a]#",
    ))
    .await?;

    Ok(())
}

// Cursor behavior is different when the text is created in the buffer vs loaded from a file.
// This test will not work for reproducing the crash or verifying the result after the fix.
// // #[tokio::test(flavor = "multi_thread")]
// async fn test_try_restore_indent() -> anyhow::Result<()> {
//     test((" #[ |]#foo\na#( |)#bar\n", "o<C-u><esc>", " foo\n#[\n|]#a bar\n#(\n|)#")).await?;
//     Ok(())
// }

#[tokio::test(flavor = "multi_thread")]
async fn test_try_restore_indent() -> anyhow::Result<()> {
    // Bug: 15228 try_restore_indent uses primary cursor position for all selections,
    // causing invalid range errors when multiple cursors are on different lines
    let file = temp_file_with_contents("  foo\na bar\n")?;
    test_key_sequence(
        &mut AppBuilder::new().with_file(file.path(), None).build()?,
        Some("jl<A-C>o<C-u><esc>"),
        None,
        false,
    )
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_delete_word_backward() -> anyhow::Result<()> {
    // don't panic when deleting overlapping ranges
    test(("fo#[o|]#ba#(r|)#", "a<C-w><esc>", "#[\n|]#")).await?;
    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_delete_word_forward() -> anyhow::Result<()> {
    // don't panic when deleting overlapping ranges
    test(("fo#[o|]#b#(|ar)#", "i<A-d><esc>", "fo#[\n|]#")).await?;
    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_delete_char_forward() -> anyhow::Result<()> {
    test((
        indoc! {"\
                #[abc|]#def
                #(abc|)#ef
                #(abc|)#f
                #(abc|)#
            "},
        "a<del><esc>",
        indoc! {"\
                #[abc|]#ef
                #(abc|)#f
                #(abc|)#
                #(abc|)#
            "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_insert_with_indent() -> anyhow::Result<()> {
    const INPUT: &str = indoc! { "
        #[f|]#n foo() {
            if let Some(_) = None {

            }
         
        }

        fn bar() {

        }
        "
    };

    // insert_at_line_start
    test((
        INPUT,
        ":lang rust<ret>%<A-s>I",
        indoc! { "
            #[f|]#n foo() {
                #(i|)#f let Some(_) = None {
                    #(\n|)#
                #(}|)#
            #( |)#
            #(}|)#
            #(\n|)#
            #(f|)#n bar() {
                #(\n|)#
            #(}|)#
            "
        },
    ))
    .await?;

    // insert_at_line_end
    test((
        INPUT,
        ":lang rust<ret>%<A-s>A",
        indoc! { "
            fn foo() {#[\n|]#
                if let Some(_) = None {#(\n|)#
                    #(\n|)#
                }#(\n|)#
             #(\n|)#
            }#(\n|)#
            #(\n|)#
            fn bar() {#(\n|)#
                #(\n|)#
            }#(\n|)#
            "
        },
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_open_below_last_line_of_extended_body() -> anyhow::Result<()> {
    // A new line past the end of an off-side body is claimed by its `@extend`
    // scope, so it keeps the body's indent
    test((
        indoc! { "
            def foo():
                #[x|]# = 1
            "
        },
        ":lang python<ret>o",
        indoc! { "
            def foo():
                x = 1
                #[\n|]#
            "
        },
    ))
    .await?;

    // ...unless `@extend.prevent-once` stops the extension
    test((
        indoc! { "
            def foo():
                #[p|]#ass
            "
        },
        ":lang python<ret>o",
        indoc! { "
            def foo():
                pass
            #[\n|]#
            "
        },
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_open_below_closed_yuck_list() -> anyhow::Result<()> {
    test(("(#[b|]#ox)\n", ":lang yuck<ret>o", "(box)\n#[\n|]#")).await?;

    // Closing an inner list keeps the enclosing list's indentation.
    test((
        indoc! { "
            (box
              (#[l|]#abel :text \"hi\")
            )
        " },
        ":lang yuck<ret>o",
        indoc! { "
            (box
              (label :text \"hi\")
              #[\n|]#
            )
        " },
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_open_below_closed_amber_function() -> anyhow::Result<()> {
    test((
        indoc! { "
            fun foo() {
                echo \"hi\"
            #[}|]#
        " },
        ":lang amber<ret>o",
        indoc! { "
            fun foo() {
                echo \"hi\"
            }
            #[\n|]#
        " },
    ))
    .await?;

    // Closing an inner block keeps the enclosing function's indentation.
    test((
        indoc! { "
            fun foo() {
                if true {
                    echo \"hi\"
                #[}|]#
            }
        " },
        ":lang amber<ret>o",
        indoc! { "
            fun foo() {
                if true {
                    echo \"hi\"
                }
                #[\n|]#
            }
        " },
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_insert_newline_after_last_gdscript_body_line() -> anyhow::Result<()> {
    test((
        "func foo():\n\tprint(#[1|]#)\n",
        ":lang gdscript<ret>A<ret>",
        "func foo():\n\tprint(1)\n\t#[\n|]#",
    ))
    .await
}

#[tokio::test(flavor = "multi_thread")]
async fn test_join_selections() -> anyhow::Result<()> {
    // normal join
    test((
        indoc! {"\
            #[a|]#bc
            def
        "},
        "J",
        indoc! {"\
            #[a|]#bc def
        "},
    ))
    .await?;

    // join with empty line
    test((
        indoc! {"\
            #[a|]#bc

            def
        "},
        "JJ",
        indoc! {"\
            #[a|]#bc def
        "},
    ))
    .await?;

    // join with additional space in non-empty line
    test((
        indoc! {"\
            #[a|]#bc

                def
        "},
        "JJ",
        indoc! {"\
            #[a|]#bc def
        "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_join_selections_space() -> anyhow::Result<()> {
    // join with empty lines panic
    test((
        indoc! {"\
            #[a

            b

            c

            d

            e|]#
        "},
        "<A-J>",
        indoc! {"\
            a#[ |]#b#( |)#c#( |)#d#( |)#e
        "},
    ))
    .await?;

    // normal join
    test((
        indoc! {"\
            #[a|]#bc
            def
        "},
        "<A-J>",
        indoc! {"\
            abc#[ |]#def
        "},
    ))
    .await?;

    // join with empty line
    test((
        indoc! {"\
            #[a|]#bc

            def
        "},
        "<A-J>",
        indoc! {"\
            #[a|]#bc
            def
        "},
    ))
    .await?;

    // join with additional space in non-empty line
    test((
        indoc! {"\
            #[a|]#bc

                def
        "},
        "<A-J><A-J>",
        indoc! {"\
            abc#[ |]#def
        "},
    ))
    .await?;

    // join with retained trailing spaces
    test((
        indoc! {"\
            #[aaa   

            bb  

            c |]#
        "},
        "<A-J>",
        indoc! {"\
            aaa   #[ |]#bb  #( |)#c 
        "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_join_selections_comment() -> anyhow::Result<()> {
    test((
        indoc! {"\
            /// #[a|]#bc
            /// def
        "},
        ":lang rust<ret>J",
        indoc! {"\
            /// #[a|]#bc def
        "},
    ))
    .await?;

    // Only join if the comment token matches the previous line.
    test((
        indoc! {"\
            #[| // a
            // b
            /// c
            /// d
            e
            /// f
            // g]#
        "},
        ":lang rust<ret>J",
        indoc! {"\
            #[| // a b /// c d e f // g]#
        "},
    ))
    .await?;

    test((
        "#[|\t// Join comments
\t// with indent]#",
        ":lang go<ret>J",
        "#[|\t// Join comments with indent]#",
    ))
    .await?;

    test((
        indoc! {"\
            #[|// Join comments
            // through injected comment syntax]#
        "},
        ":lang go<ret>J",
        indoc! {"\
            #[|// Join comments through injected comment syntax]#
        "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_toggle_comments_inside_comment_injection() -> anyhow::Result<()> {
    // A `//` line comment's text is injected as the `comment` language, which has no
    // comment-tokens of its own. With the cursor inside the comment, toggling must
    // resolve tokens from the enclosing language and un-comment the line,
    // not fall back to the hardcoded default `#`.
    test((
        indoc! {"\
            // #[a|]#bc
        "},
        ":lang rust<ret><C-c>",
        indoc! {"\
            #[a|]#bc
        "},
    ))
    .await?;

    // A `///` doc comment's text is injected as markdown (no line comment token of
    // its own). Toggling must strip the whole `///` marker via Rust's tokens rather
    // than insert a markdown `<!-- -->` inside or leave a stray `/`.
    test((
        indoc! {"\
            /// #[a|]#bc
        "},
        ":lang rust<ret><C-c>",
        indoc! {"\
            #[a|]#bc
        "},
    ))
    .await?;

    // Likewise for the `//!` inner doc comment marker.
    test((
        indoc! {"\
            //! #[a|]#bc
        "},
        ":lang rust<ret><C-c>",
        indoc! {"\
            #[a|]#bc
        "},
    ))
    .await?;

    // Commenting a normal code line still uses the top-level language's token
    // (no injection layer at the cursor), no regression for the common case.
    test((
        indoc! {"\
            #[l|]#et x = 5;
        "},
        ":lang rust<ret><C-c>",
        indoc! {"\
            // #[l|]#et x = 5;
        "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn test_read_file() -> anyhow::Result<()> {
    let mut file = tempfile::NamedTempFile::new()?;
    let contents_to_read = "some contents";
    let output_file = helpers::temp_file_with_contents(contents_to_read)?;

    test_key_sequence(
        &mut helpers::AppBuilder::new()
            .with_file(file.path(), None)
            .build()?,
        Some(&format!(":r {:?}<ret><esc>:w<ret>", output_file.path())),
        Some(&|app| {
            assert!(!app.editor.is_err(), "error: {:?}", app.editor.get_status());
        }),
        false,
    )
    .await?;

    let expected_contents = LineFeedHandling::Native.apply(contents_to_read);
    helpers::assert_file_has_content(&mut file, &expected_contents)?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn surround_delete() -> anyhow::Result<()> {
    // Test `surround_delete` when head < anchor
    test(("(#[|  ]#)", "mdm", "#[|  ]#")).await?;
    test(("(#[|  ]#)", "md(", "#[|  ]#")).await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn surround_replace_ts() -> anyhow::Result<()> {
    const INPUT: &str = r#"\
fn foo() {
    if let Some(_) = None {
        testing!("f#[|o]#o)");
    }
}
"#;
    test((
        INPUT,
        ":lang rust<ret>mrm'",
        r#"\
fn foo() {
    if let Some(_) = None {
        testing!('f#[|o]#o)');
    }
}
"#,
    ))
    .await?;

    test((
        INPUT,
        ":lang rust<ret>3mrm[",
        r#"\
fn foo() {
    if let Some(_) = None [
        testing!("f#[|o]#o)");
    ]
}
"#,
    ))
    .await?;

    test((
        INPUT,
        ":lang rust<ret>2mrm{",
        r#"\
fn foo() {
    if let Some(_) = None {
        testing!{"f#[|o]#o)"};
    }
}
"#,
    ))
    .await?;

    test((
        indoc! {"\
            #[a
            b
            c
            d
            e|]#
            f
            "},
        "s\\n<ret>r,",
        "a#[,|]#b#(,|)#c#(,|)#d#(,|)#e\nf\n",
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn macro_play_within_macro_record() -> anyhow::Result<()> {
    // <https://github.com/helix-editor/helix/issues/12697>
    //
    // * `"aQihello<esc>Q` record a macro to register 'a' which inserts "hello"
    // * `Q"aq<space>world<esc>Q` record a macro to the default macro register which plays the
    //   macro in register 'a' and then inserts " world"
    // * `%d` clear the buffer
    // * `q` replay the macro in the default macro register
    // * `i<ret>` add a newline at the end
    //
    // The inner macro in register 'a' should replay within the outer macro exactly once to insert
    // "hello world".
    test((
        indoc! {"\
            #[|]#
        "},
        r#""aQihello<esc>QQ"aqi<space>world<esc>Q%dqi<ret>"#,
        indoc! {"\
            hello world
            #[|]#"},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn global_search_with_multibyte_chars() -> anyhow::Result<()> {
    // Assert that `term::commands::global_search` handles multibyte characters correctly.
    test((
        indoc! {"\
            // Hello world!
            // #[|
            ]#
            "},
        // start global search
        " /«十分に長い マルチバイトキャラクター列» で検索<ret><esc>",
        indoc! {"\
            // Hello world!
            // #[|
            ]#
            "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn align_selections_with_varying_columns() -> anyhow::Result<()> {
    test((
        indoc! {r"
            #[|]#I    I  II I
            IIIIIIIII
            IIIII
            IIIIIIIII
        "},
        r"%sI<ret>&gg",
        indoc! {r"
            #[I|]#    I  II I
            I    I  II IIIII
            I    I  II I
            I    I  II IIIII
        "},
    ))
    .await?;

    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn file_navigation_decodes_file_urls_and_preserves_native_paths() -> anyhow::Result<()> {
    let directory = tempfile::tempdir()?;
    let path = directory.path().join("space # and ünicode.txt");
    std::fs::write(&path, "decoded target\n")?;
    let url = stdx::Url::from_file_path(&path).unwrap();
    for target in [
        url.to_string(),
        format!("{url}#line-1"),
        path.to_string_lossy().into_owned(),
    ] {
        let mut app = AppBuilder::new()
            .with_input_text(format!("#[{target}|]#\n"))
            .build()?;
        test_key_sequence(
            &mut app,
            Some("gf"),
            Some(&|app| {
                let doc = doc!(app.editor);
                assert_eq!(doc.path(), Some(stdx::path::canonicalize(&path).as_path()));
                assert_eq!(doc.text(), "decoded target\n");
            }),
            false,
        )
        .await?;
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread")]
async fn native_file_navigation_opens_binary_documents_in_the_editor() -> anyhow::Result<()> {
    let directory = tempfile::tempdir()?;
    let path = directory.path().join("target.pdf");
    std::fs::write(&path, b"%PDF-1.7 binary fixture")?;
    let mut app = AppBuilder::new()
        .with_input_text(format!("#[{}|]#\n", path.display()))
        .build()?;
    test_key_sequence(
        &mut app,
        Some("gf"),
        Some(&|app| {
            let doc = doc!(app.editor);
            assert_eq!(doc.path(), Some(stdx::path::canonicalize(&path).as_path()));
            assert!(doc.is_binary());
        }),
        false,
    )
    .await
}
