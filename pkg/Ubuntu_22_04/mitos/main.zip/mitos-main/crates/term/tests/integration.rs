#[cfg(feature = "integration")]
mod test {
    mod helpers;

    use editor_core::Selection;
    use language_config::AutoPairConfig;
    use term::config::Config;

    use indoc::indoc;

    use self::helpers::*;

    #[tokio::test(flavor = "multi_thread")]
    async fn hello_world() -> anyhow::Result<()> {
        test(("#[\n|]#", "ihello world<esc>", "hello world#[|\n]#")).await?;
        Ok(())
    }

    mod auto_pairs;
    mod auto_reload;
    mod auto_save;
    mod buffer_picker;
    mod code_action_hints;
    mod code_actions;
    mod code_lenses;
    mod command_line;
    mod command_palette;
    mod commands;
    mod completion;
    mod component_keymaps;
    mod config_application;
    mod cursor;
    mod debugger_terminal;
    mod document_features;
    mod formatting;
    mod inline_completion;
    mod language_features;
    mod lsp_alternatives;
    mod lsp_lifecycle;
    mod lsp_workspace;
    mod movement;
    mod navigation;
    mod pull_diagnostics;
    mod signature_help;
    mod spelling;
    mod splits;
    mod startup;
    mod statusline;
    mod workspace_trust;
}
