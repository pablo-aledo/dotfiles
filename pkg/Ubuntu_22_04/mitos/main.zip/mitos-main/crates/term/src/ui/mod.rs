pub mod blame;
mod completion;
mod document;
pub(crate) mod editor;
mod icons;
mod image;
mod info;
mod layout;
pub mod lsp;
mod markdown;
pub mod menu;
pub mod overlay;
mod panel;
pub mod picker;
pub mod popup;
pub mod prompt;
mod select;
mod spinner;
mod statusline;
mod text;
mod text_decorations;

use crate::compositor::Compositor;
use crate::job::{self, Callback};
pub use completion::Completion;
pub use editor::EditorView;
pub(crate) use icons::icon_span;
pub use markdown::Markdown;
pub use menu::Menu;
pub use picker::{Column as PickerColumn, FileLocation, Picker};
pub use popup::Popup;
pub use prompt::{Prompt, PromptEvent};
pub use select::Select;
pub use spinner::{ProgressSpinners, Spinner};
use stdx::rope;
pub use text::Text;
use theme::icons::ICONS;
use theme::Theme;
use view::{
    graphics::RectExt as _,
    quicklist::{QuicklistEntry, QuicklistPosition, QuicklistTarget},
    Editor,
};

use tui::text::{Line, Span};

use std::{borrow::Cow, path::Path, sync::Arc};
use std::{error::Error, path::PathBuf};

struct Utf8PathBuf {
    path: String,
    is_dir: bool,
    is_symlink: bool,
}

impl AsRef<str> for Utf8PathBuf {
    fn as_ref(&self) -> &str {
        &self.path
    }
}

pub fn prompt(
    cx: &mut crate::commands::Context,
    prompt: std::borrow::Cow<'static, str>,
    history_register: Option<char>,
    completion_fn: impl FnMut(&Editor, &str) -> Vec<prompt::Completion> + 'static,
    callback_fn: impl FnMut(&mut crate::compositor::Context, &str, PromptEvent) + 'static,
) {
    let mut prompt = Prompt::new(prompt, history_register, completion_fn, callback_fn);
    // Calculate the initial completion
    prompt.recalculate_completion(cx.editor);
    cx.push_layer(Box::new(prompt));
}

pub fn prompt_with_input(
    cx: &mut crate::commands::Context,
    prompt: std::borrow::Cow<'static, str>,
    input: String,
    history_register: Option<char>,
    completion_fn: impl FnMut(&Editor, &str) -> Vec<prompt::Completion> + 'static,
    callback_fn: impl FnMut(&mut crate::compositor::Context, &str, PromptEvent) + 'static,
) {
    let prompt = Prompt::new(prompt, history_register, completion_fn, callback_fn)
        .with_line(input, cx.editor);
    cx.push_layer(Box::new(prompt));
}

pub fn regex_prompt(
    cx: &mut crate::commands::Context,
    prompt: std::borrow::Cow<'static, str>,
    history_register: Option<char>,
    completion_fn: impl FnMut(&Editor, &str) -> Vec<prompt::Completion> + 'static,
    fun: impl Fn(&mut crate::compositor::Context, rope::Regex, PromptEvent) + 'static,
) {
    raw_regex_prompt(
        cx,
        prompt,
        history_register,
        completion_fn,
        move |cx, regex, _, event| fun(cx, regex, event),
    );
}
pub fn raw_regex_prompt(
    cx: &mut crate::commands::Context,
    prompt: std::borrow::Cow<'static, str>,
    history_register: Option<char>,
    completion_fn: impl FnMut(&Editor, &str) -> Vec<prompt::Completion> + 'static,
    fun: impl Fn(&mut crate::compositor::Context, rope::Regex, &str, PromptEvent) + 'static,
) {
    let (view, doc) = current!(cx.editor);
    let doc_id = view.document_id();
    let view_id = view.id;
    let snapshot = doc.selection(view.id).clone();
    let offset_snapshot = doc.view_offset(view.id);
    let config = cx.editor.config();

    let mut prompt = Prompt::new(
        prompt,
        history_register,
        completion_fn,
        move |cx: &mut crate::compositor::Context, input: &str, event: PromptEvent| {
            match event {
                PromptEvent::Abort => {
                    let doc = doc_mut!(cx.editor, &doc_id);
                    let view = view_mut!(cx.editor, view_id);
                    doc.set_selection(view.id, snapshot.clone());
                    doc.set_view_offset(view.id, offset_snapshot);
                }
                PromptEvent::Update | PromptEvent::Validate => {
                    // skip empty input
                    if input.is_empty() {
                        return;
                    }

                    let case_insensitive = if config.search.smart_case {
                        !input.chars().any(char::is_uppercase)
                    } else {
                        false
                    };

                    let is_crlf = doc!(cx.editor).line_ending == editor_core::LineEnding::Crlf;
                    match rope::RegexBuilder::new()
                        .syntax(
                            rope::Config::new()
                                .case_insensitive(case_insensitive)
                                .multi_line(true)
                                .crlf(is_crlf),
                        )
                        .build(input)
                    {
                        Ok(regex) => {
                            let doc = doc_mut!(cx.editor, &doc_id);
                            let view = view_mut!(cx.editor, view_id);

                            // revert state to what it was before the last update
                            doc.set_selection(view.id, snapshot.clone());

                            if event == PromptEvent::Validate {
                                // Equivalent to push_jump to store selection just before jump
                                view.push_jump(doc, (doc_id, snapshot.clone()));
                            }

                            fun(cx, regex, input, event);

                            let (view, doc) = current!(cx.editor);
                            view.ensure_cursor_in_view(doc, config.scroll.padding);
                        }
                        Err(err) => {
                            let doc = doc_mut!(cx.editor, &doc_id);
                            let view = view_mut!(cx.editor, view_id);
                            doc.set_selection(view.id, snapshot.clone());
                            doc.set_view_offset(view.id, offset_snapshot);

                            if event == PromptEvent::Validate {
                                let callback = async move {
                                    let call: job::Callback = Callback::EditorCompositor(Box::new(
                                        move |_editor: &mut Editor, compositor: &mut Compositor| {
                                            let contents = Text::new(format!("{}", err));
                                            let size = compositor.size();
                                            let editor_area = size.clip_bottom(2);
                                            let popup = Popup::new("invalid-regex", contents)
                                                .position(Some(text_layout::DisplayPosition::new(
                                                    editor_area.bottom().saturating_sub(1) as usize,
                                                    0,
                                                )))
                                                .auto_close(true);
                                            compositor.replace_or_push("invalid-regex", popup);
                                        },
                                    ));
                                    Ok(call)
                                };

                                cx.jobs.callback(callback);
                            }
                        }
                    }
                }
            }
        },
    )
    .with_language("regex", std::sync::Arc::clone(&cx.editor.syn_loader));
    // Calculate initial completion
    prompt.recalculate_completion(cx.editor);
    // prompt
    cx.push_layer(Box::new(prompt));
}

/// We want to exclude files that the editor can't handle yet
fn get_excluded_types() -> ignore::types::Types {
    use ignore::types::TypesBuilder;
    let mut type_builder = TypesBuilder::new();
    type_builder
        .add(
            "compressed",
            "*.{zip,gz,bz2,zst,lzo,sz,tgz,tbz2,lz,lz4,lzma,lzo,z,Z,xz,7z,rar,cab}",
        )
        .expect("Invalid type definition");
    type_builder.negate("all");
    type_builder
        .build()
        .expect("failed to build excluded_types")
}

#[derive(Debug)]
pub struct FilePickerData {
    root: PathBuf,
    theme: Arc<Theme>,
    icons: bool,
}
type FilePicker = Picker<PathBuf, FilePickerData>;

fn file_picker_paths(
    root: &Path,
    config: &editor_config::FilePickerConfig,
) -> impl Iterator<Item = PathBuf> + use<> {
    use ignore::WalkBuilder;
    let dedup_symlinks = config.deduplicate_links;
    let absolute_root = root.canonicalize().unwrap_or_else(|_| root.to_owned());

    let mut walk_builder = WalkBuilder::new(root);

    walk_builder
        .hidden(config.hidden)
        .parents(config.parents)
        .ignore(config.ignore)
        .follow_links(config.follow_symlinks)
        .git_ignore(config.git_ignore)
        .git_global(config.git_global)
        .git_exclude(config.git_exclude)
        .sort_by_file_name(|name1, name2| name1.cmp(name2))
        .max_depth(config.max_depth)
        .filter_entry(move |entry| ::search::include_entry(entry, &absolute_root, dedup_symlinks))
        .add_custom_ignore_filename(loader::config_dir().join("ignore"))
        .add_custom_ignore_filename(".mitos/ignore")
        .types(get_excluded_types())
        .build()
        .filter_map(|entry| {
            let entry = entry.ok()?;
            if !entry.path().is_file() {
                return None;
            }
            Some(entry.into_path())
        })
}

pub fn file_picker(editor: &Editor, root: PathBuf) -> FilePicker {
    let config = editor.config();
    let data = FilePickerData {
        root: root.clone(),
        theme: Arc::new(editor.theme.clone()),
        icons: config.icons,
    };
    let files = file_picker_paths(&root, &config.file_picker);

    let columns = [PickerColumn::new(
        "path",
        |item: &PathBuf, data: &FilePickerData| {
            let theme = data.theme.as_ref();
            let path = item.strip_prefix(&data.root).unwrap_or(item);
            let mut spans = Vec::with_capacity(4);

            if data.icons {
                let icons = ICONS.load();
                if let Some(file) = icons.fs().file() {
                    spans.push(icon_span(file.get_with_style_or_default(item, theme)));
                }
            }

            if let Some(dirs) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
                let directory_style = theme.get("ui.text.directory");
                spans.extend([
                    Span::styled(dirs.to_string_lossy(), directory_style),
                    Span::styled(std::path::MAIN_SEPARATOR_STR, directory_style),
                ]);
            }
            let filename = path
                .file_name()
                .expect("normalized paths can't end in `..`")
                .to_string_lossy();
            spans.push(Span::raw(filename));
            Line::from(spans).into()
        },
    )];
    let picker = Picker::new(
        editor.redraw().clone(),
        columns,
        0,
        [],
        data,
        move |cx, path: &PathBuf, action| {
            if let Err(err) = cx.editor.open(path, action) {
                cx.editor.set_error(|| {
                    if let Some(err) = err.source() {
                        format!("{}", err)
                    } else {
                        format!("unable to open \"{}\"", path.display())
                    }
                });
            }
        },
    )
    .with_preview(|_editor, path| Some((path.as_path().into(), None)))
    .with_file_updates(
        editor,
        |data| &data.root,
        |_, editor, data, cancel| {
            let config = editor.config().file_picker.clone();
            Box::pin(async move {
                Ok(tokio::task::spawn_blocking(move || {
                    file_picker_paths(&data.root, &config)
                        .take_while(|_| !cancel.is_canceled())
                        .collect()
                })
                .await?)
            })
        },
        |path| path,
    );
    let injector = picker.injector();
    tokio::task::spawn_blocking(move || {
        for file in files {
            if injector.push(file).is_err() {
                break;
            }
        }
    });
    picker
}

type FileExplorer = Picker<(PathBuf, bool), (PathBuf, Arc<Theme>, bool)>;

pub fn file_explorer(root: PathBuf, editor: &Editor) -> Result<FileExplorer, std::io::Error> {
    let options = directory_content(&root, &editor.config().file_explorer)?;

    let columns = [PickerColumn::new(
        "path",
        |(path, is_dir): &(PathBuf, bool),
         (_root, theme, show_icons): &(PathBuf, Arc<Theme>, bool)| {
            let name = path.file_name();
            let is_open = name.is_none() && *is_dir;
            let name = name.map_or_else(|| Cow::Borrowed(".."), |name| name.to_string_lossy());
            let directory_style = theme.get("ui.text.directory");

            if *is_dir {
                let mut spans = Vec::with_capacity(2);
                if *show_icons {
                    let icons = ICONS.load();
                    if let Some(directory) = icons.fs().directory() {
                        spans.push(icon_span(directory.get_with_style_or_default(
                            &name,
                            is_open,
                            theme,
                            directory_style,
                        )));
                    }
                }
                spans.push(Span::styled(format!("{name}/"), directory_style));
                Line::from(spans).into()
            } else {
                let mut spans = Vec::with_capacity(2);
                if *show_icons {
                    let icons = ICONS.load();
                    if let Some(file) = icons.fs().file() {
                        spans.push(icon_span(file.get_with_style_or_default(path, theme)));
                    }
                }
                spans.push(Span::raw(name.into_owned()));
                Line::from(spans).into()
            }
        },
    )];
    let picker = Picker::new_with_callback_result(
        editor.redraw().clone(),
        columns,
        0,
        options,
        (root, Arc::new(editor.theme.clone()), editor.config().icons),
        move |cx, (path, is_dir): &(PathBuf, bool), action| {
            if *is_dir {
                let new_root = stdx::path::normalize(path);
                return match directory_content(&new_root, &cx.editor.config().file_explorer) {
                    Ok(options) => picker::PickerCallbackResult::Replace {
                        options,
                        editor_data: (
                            new_root,
                            Arc::new(cx.editor.theme.clone()),
                            cx.editor.config().icons,
                        ),
                    },
                    Err(err) => {
                        cx.editor.set_error(|| err.to_string());
                        picker::PickerCallbackResult::KeepOpen
                    }
                };
            }

            if let Err(err) = cx.editor.open(path, action) {
                cx.editor.set_error(|| {
                    if let Some(err) = err.source() {
                        format!("{}", err)
                    } else {
                        format!("unable to open \"{}\"", path.display())
                    }
                });
            }
            picker::PickerCallbackResult::Close
        },
    )
    .with_preview(|_editor, (path, _is_dir)| Some((path.as_path().into(), None)))
    .with_quicklist(|_editor, (path, is_dir)| {
        if *is_dir {
            return None;
        }

        Some(QuicklistEntry {
            target: QuicklistTarget::Path(path.clone()),
            position: QuicklistPosition::None,
        })
    })
    .with_file_updates(
        editor,
        |data| &data.0,
        |_, editor, data, cancel| {
            let config = editor.config().file_explorer.clone();
            Box::pin(async move {
                Ok(tokio::task::spawn_blocking(move || {
                    directory_content_cancellable(&data.0, &config, || cancel.is_canceled())
                })
                .await??)
            })
        },
        |(path, _)| path,
    );

    Ok(picker)
}

fn directory_content(
    root: &Path,
    config: &editor_config::FileExplorerConfig,
) -> Result<Vec<(PathBuf, bool)>, std::io::Error> {
    directory_content_cancellable(root, config, || false)
}

fn directory_content_cancellable(
    root: &Path,
    config: &editor_config::FileExplorerConfig,
    cancelled: impl Fn() -> bool,
) -> Result<Vec<(PathBuf, bool)>, std::io::Error> {
    use ignore::WalkBuilder;

    // Keep the previous listing when its directory disappears or becomes unreadable.
    std::fs::read_dir(root)?;
    let mut walk_builder = WalkBuilder::new(root);

    let mut content: Vec<(PathBuf, bool)> = walk_builder
        .hidden(config.hidden)
        .parents(config.parents)
        .ignore(config.ignore)
        .follow_links(config.follow_symlinks)
        .git_ignore(config.git_ignore)
        .git_global(config.git_global)
        .git_exclude(config.git_exclude)
        .max_depth(Some(1))
        .add_custom_ignore_filename(loader::config_dir().join("ignore"))
        .add_custom_ignore_filename(".mitos/ignore")
        .types(get_excluded_types())
        .build()
        .take_while(|_| !cancelled())
        .filter_map(|entry| {
            entry
                .map(|entry| {
                    let path = entry.path();
                    let is_dir = path.is_dir();
                    (path.to_path_buf(), is_dir)
                })
                .ok()
                .filter(|entry| entry.0 != root)
        })
        .collect();

    content.sort_by(|(path1, is_dir1), (path2, is_dir2)| (!is_dir1, path1).cmp(&(!is_dir2, path2)));

    if root.parent().is_some() {
        content.insert(0, (root.join(".."), true));
    }

    Ok(content)
}

pub mod completers {
    use super::Utf8PathBuf;
    use crate::config::EditorSettings;
    use crate::ui::prompt::Completion;
    use command_line::{self, Tokenizer};
    use fuzzy::{fuzzy_match, MatchKind};
    use language_config::LanguageServerFeature;
    use std::borrow::Cow;
    use std::collections::BTreeSet;
    use std::sync::LazyLock;
    use tui::text::Span;
    use view::document::SCRATCH_BUFFER_NAME;
    use view::Editor;

    pub type Completer = fn(&Editor, &str) -> Vec<Completion>;

    pub fn none(_editor: &Editor, _input: &str) -> Vec<Completion> {
        Vec::new()
    }

    pub fn buffer(editor: &Editor, input: &str) -> Vec<Completion> {
        let names = editor.documents.values().map(|doc| {
            doc.display_path()
                .map(|p| p.display().to_string().into())
                .unwrap_or_else(|| Cow::from(SCRATCH_BUFFER_NAME))
        });

        fuzzy_match(input, names, MatchKind::Path)
            .into_iter()
            .map(|(name, _)| ((0..), name.into()))
            .collect()
    }

    pub fn theme(editor: &Editor, input: &str) -> Vec<Completion> {
        let names = editor.theme_loader.resources().names();

        fuzzy_match(input, names, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), name.into()))
            .collect()
    }

    /// Recursive function to get all keys from this value and add them to vec
    fn get_keys(value: &serde_json::Value, vec: &mut Vec<String>, scope: Option<&str>) {
        if let Some(map) = value.as_object() {
            for (key, value) in map.iter() {
                let key = match scope {
                    Some(scope) => format!("{}.{}", scope, key),
                    None => key.clone(),
                };
                get_keys(value, vec, Some(&key));
                if !value.is_object() {
                    vec.push(key);
                }
            }
        }
    }

    /// Completes names of language servers which are running for the current document.
    pub fn active_language_servers(editor: &Editor, input: &str) -> Vec<Completion> {
        let language_servers = doc!(editor).language_servers().map(|ls| ls.name());

        fuzzy_match(input, language_servers, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), Span::raw(name.to_string())))
            .collect()
    }

    /// Completes names of language servers which are configured for the language of the current
    /// document.
    pub fn configured_language_servers(editor: &Editor, input: &str) -> Vec<Completion> {
        let language_servers = doc!(editor)
            .language_config()
            .into_iter()
            .flat_map(|config| &config.language_servers)
            .map(|ls| ls.name.as_str());

        fuzzy_match(input, language_servers, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), Span::raw(name.to_string())))
            .collect()
    }

    pub fn setting(_editor: &Editor, input: &str) -> Vec<Completion> {
        static KEYS: LazyLock<Vec<String>> = LazyLock::new(|| {
            let mut keys = Vec::new();
            let json = serde_json::json!(EditorSettings::default());
            get_keys(&json, &mut keys, None);
            keys
        });

        fuzzy_match(input, &*KEYS, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), Span::raw(name)))
            .collect()
    }

    pub fn filename(editor: &Editor, input: &str) -> Vec<Completion> {
        filename_with_git_ignore(editor, input, true)
    }

    pub fn filename_with_git_ignore(
        editor: &Editor,
        input: &str,
        git_ignore: bool,
    ) -> Vec<Completion> {
        filename_impl(editor, input, git_ignore, |entry| {
            if entry.path().is_dir() {
                FileMatch::AcceptIncomplete
            } else {
                FileMatch::Accept
            }
        })
    }

    pub fn language(editor: &Editor, input: &str) -> Vec<Completion> {
        let text: String = "text".into();

        let loader = editor.syn_loader.load();
        let language_ids = loader
            .language_configs()
            .map(|config| &config.language_id)
            .chain(std::iter::once(&text));

        fuzzy_match(input, language_ids, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), name.to_owned().into()))
            .collect()
    }

    pub fn spelling_language(_editor: &Editor, input: &str) -> Vec<Completion> {
        // The available languages are the dictionaries vendored or dropped into the runtime
        // directories, plus `off` to disable spell-checking for the buffer.
        let mut languages = Vec::new();
        for runtime_dir in loader::runtime_dirs() {
            let Ok(entries) = std::fs::read_dir(runtime_dir.join("dictionaries")) else {
                continue;
            };
            for entry in entries.flatten() {
                if !entry.file_type().is_ok_and(|file_type| file_type.is_dir()) {
                    continue;
                }
                if let Ok(language) = entry.file_name().into_string()
                    && !languages.contains(&language)
                {
                    languages.push(language);
                }
            }
        }
        languages.sort();

        let candidates = languages
            .iter()
            .map(String::as_str)
            .chain(std::iter::once("off"));
        fuzzy_match(input, candidates, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), name.to_owned().into()))
            .collect()
    }

    pub fn lsp_workspace_command(editor: &Editor, input: &str) -> Vec<Completion> {
        let commands = doc!(editor)
            .language_servers_with_feature(LanguageServerFeature::WorkspaceCommand)
            .flat_map(|ls| {
                ls.capabilities()
                    .execute_command_provider
                    .iter()
                    .flat_map(|options| options.commands.iter())
            });

        fuzzy_match(input, commands, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), name.to_owned().into()))
            .collect()
    }

    pub fn directory(editor: &Editor, input: &str) -> Vec<Completion> {
        directory_with_git_ignore(editor, input, true)
    }

    pub fn directory_with_git_ignore(
        editor: &Editor,
        input: &str,
        git_ignore: bool,
    ) -> Vec<Completion> {
        filename_impl(editor, input, git_ignore, |entry| {
            if entry.path().is_dir() {
                FileMatch::Accept
            } else {
                FileMatch::Reject
            }
        })
    }

    #[derive(Copy, Clone, PartialEq, Eq)]
    enum FileMatch {
        /// Entry should be ignored
        Reject,
        /// Entry is usable but can't be the end (for instance if the entry is a directory and we
        /// try to match a file)
        AcceptIncomplete,
        /// Entry is usable and can be the end of the match
        Accept,
    }

    // TODO: we could return an iter/lazy thing so it can fetch as many as it needs.
    fn filename_impl<F>(
        editor: &Editor,
        input: &str,
        git_ignore: bool,
        filter_fn: F,
    ) -> Vec<Completion>
    where
        F: Fn(&ignore::DirEntry) -> FileMatch,
    {
        // Rust's filename handling is really annoying.

        use ignore::WalkBuilder;
        use std::path::Path;

        let is_tilde = input == "~";
        let path = stdx::path::expand_tilde(Path::new(input));

        let (dir, file_name) = if input.ends_with(std::path::MAIN_SEPARATOR) {
            (path, None)
        } else {
            let is_period = (input.ends_with((format!("{}.", std::path::MAIN_SEPARATOR)).as_str())
                && input.len() > 2)
                || input == ".";
            let file_name = if is_period {
                Some(String::from("."))
            } else {
                path.file_name()
                    .and_then(|file| file.to_str().map(|path| path.to_owned()))
            };

            let path = if is_period {
                path
            } else {
                match path.parent() {
                    Some(path) if !path.as_os_str().is_empty() => Cow::Borrowed(path),
                    // Path::new("h")'s parent is Some("")...
                    _ => Cow::Owned(stdx::env::current_working_dir()),
                }
            };

            (path, file_name)
        };

        let end = input.len()..;

        let files = WalkBuilder::new(&dir)
            .hidden(false)
            .follow_links(false) // We're scanning over depth 1
            .git_ignore(git_ignore)
            .max_depth(Some(1))
            .build()
            .filter_map(|file| {
                file.ok().and_then(|entry| {
                    let fmatch = filter_fn(&entry);

                    if fmatch == FileMatch::Reject {
                        return None;
                    }

                    let path = entry.path();
                    let is_dir = path.is_dir();
                    let file_type = entry.file_type();
                    let is_symlink = file_type.is_some_and(|ft| ft.is_symlink());
                    let mut path = if is_tilde {
                        // if it's a single tilde an absolute path is displayed so that when `TAB` is pressed on
                        // one of the directories the tilde will be replaced with a valid path not with a relative
                        // home directory name.
                        // ~ -> <TAB> -> /home/user
                        // ~/ -> <TAB> -> ~/first_entry
                        path.to_path_buf()
                    } else {
                        path.strip_prefix(&dir).unwrap_or(path).to_path_buf()
                    };

                    if fmatch == FileMatch::AcceptIncomplete {
                        path.push("");
                    }

                    let path = path.into_os_string().into_string().ok()?;
                    Some(Utf8PathBuf {
                        path,
                        is_dir,
                        is_symlink,
                    })
                })
            }) // TODO: unwrap or skip
            .filter(|path| !path.path.is_empty());

        let directory_color = editor.theme.get("ui.text.directory");
        let symlink_color = editor.theme.get("ui.text.symlink");

        let style_from_file = |file: Utf8PathBuf| {
            if file.is_symlink {
                Span::styled(file.path, symlink_color)
            } else if file.is_dir {
                Span::styled(file.path, directory_color)
            } else {
                Span::raw(file.path)
            }
        };

        // if empty, return a list of dirs and files in current dir
        if let Some(file_name) = file_name {
            let range = (input.len().saturating_sub(file_name.len()))..;
            fuzzy_match(&file_name, files, MatchKind::Path)
                .into_iter()
                .map(|(name, _)| (range.clone(), style_from_file(name)))
                .collect()

            // TODO: complete to longest common match
        } else {
            let mut files: Vec<_> = files
                .map(|file| (end.clone(), style_from_file(file)))
                .collect();
            files.sort_unstable_by(|(_, path1), (_, path2)| path1.content.cmp(&path2.content));
            files
        }
    }

    pub fn register(editor: &Editor, input: &str) -> Vec<Completion> {
        let iter = editor
            .registers
            .iter_preview()
            // Exclude special registers that shouldn't be written to
            .filter(|(ch, _)| !matches!(ch, '%' | '#' | '.'))
            .map(|(ch, _)| ch.to_string());

        fuzzy_match(input, iter, MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), name.into()))
            .collect()
    }

    pub fn program(_editor: &Editor, input: &str) -> Vec<Completion> {
        static PROGRAMS_IN_PATH: LazyLock<BTreeSet<String>> = LazyLock::new(|| {
            // Go through the entire PATH and read all files into a set.
            let Some(path) = std::env::var_os("PATH") else {
                return Default::default();
            };

            std::env::split_paths(&path)
                .filter_map(|path| std::fs::read_dir(path).ok())
                .flatten()
                .filter_map(|res| {
                    let entry = res.ok()?;
                    let file_type = entry.file_type().ok()?;
                    if file_type.is_file() || file_type.is_symlink() {
                        entry.file_name().into_string().ok()
                    } else {
                        None
                    }
                })
                .collect()
        });

        fuzzy_match(input, PROGRAMS_IN_PATH.iter(), MatchKind::Text)
            .into_iter()
            .map(|(name, _)| ((0..), name.clone().into()))
            .collect()
    }

    /// This expects input to be a raw string of arguments, because this is what Signature's raw_after does.
    pub fn repeating_filenames(editor: &Editor, input: &str) -> Vec<Completion> {
        let token = match Tokenizer::new(input, false).last() {
            Some(token) => token.unwrap(),
            None => return filename(editor, input),
        };

        let offset = token.content_start;

        let mut completions = filename(editor, &input[offset..]);
        for completion in completions.iter_mut() {
            completion.0.start += offset;
        }
        completions
    }

    pub fn shell(editor: &Editor, input: &str) -> Vec<Completion> {
        let (command, args, complete_command) = command_line::split(input);

        if complete_command {
            return program(editor, command);
        }

        let mut completions = repeating_filenames(editor, args);
        for completion in completions.iter_mut() {
            // + 1 for separator between `command` and `args`
            completion.0.start += command.len() + 1;
        }

        completions
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn directory_content_preserves_each_directory_level() {
        let root = tempfile::tempdir().unwrap();
        let config = editor_config::FileExplorerConfig::default();
        for service in ["authland", "portier"] {
            std::fs::create_dir_all(root.path().join(service).join("fleet").join("eu-west-1"))
                .unwrap();
        }
        std::fs::write(root.path().join("config.yaml"), "").unwrap();

        assert_eq!(
            directory_content(root.path(), &config).unwrap(),
            vec![
                (root.path().join(".."), true),
                (root.path().join("authland"), true),
                (root.path().join("portier"), true),
                (root.path().join("config.yaml"), false),
            ]
        );
        let service = root.path().join("authland");
        assert_eq!(
            directory_content(&service, &config).unwrap(),
            vec![(service.join(".."), true), (service.join("fleet"), true)]
        );
    }
}
