use arc_swap::{access::Map, ArcSwap};
use editor_core::{pos_at_coords, Range, Selection};
use futures_util::Stream;
use language::syntax;
use lsp_client::{lsp, util::lsp_range_to_range, LanguageServerId, LspProgressMap};
use serde_json::json;
use stdx::path::get_relative_path;
use tui::backend::BackendExt;
use view::{
    align_view,
    document::{DocumentOpenError, DocumentSavedEventResult},
    editor::{ConfigEvent, EditorEvent},
    graphics::Rect,
    tree::Layout,
    Align, Editor,
};

mod render;

use crate::{
    args::Args,
    compositor::{Compositor, Event},
    config::{Config, EditorSettings},
    handlers,
    job::Jobs,
    keymap::Keymaps,
    ui::{self, overlay::overlaid},
};

use log::{error, info, warn};
use std::{
    io::{stdin, IsTerminal},
    path::Path,
    sync::Arc,
};

#[cfg_attr(windows, allow(unused_imports))]
use anyhow::{Context, Error};

#[cfg(not(windows))]
use {signal_hook::consts::signal, signal_hook_tokio::Signals};
#[cfg(windows)]
type Signals = futures_util::stream::Empty<()>;

#[cfg(all(not(windows), not(feature = "integration")))]
use tui::backend::TerminaBackend;

#[cfg(all(windows, not(feature = "integration")))]
use tui::backend::CrosstermBackend;

#[cfg(feature = "integration")]
use tui::backend::TestBackend;

#[cfg(all(not(windows), not(feature = "integration")))]
type TerminalBackend = TerminaBackend;
#[cfg(all(windows, not(feature = "integration")))]
type TerminalBackend = CrosstermBackend<std::io::Stdout>;
#[cfg(feature = "integration")]
type TerminalBackend = TestBackend;

#[cfg(not(windows))]
type TerminalEvent = termina::Event;
#[cfg(windows)]
type TerminalEvent = crossterm::event::Event;

type Terminal = tui::Terminal<TerminalBackend>;

fn terminal_config(config: &Config) -> tui::terminal::Config {
    tui::terminal::Config {
        enable_mouse_capture: config.editor.mouse.enable,
        force_enable_extended_underlines: config.terminal.undercurl,
        kitty_keyboard_protocol: config.terminal.keyboard.kitty_protocol,
    }
}

pub struct Application {
    compositor: Compositor,
    terminal: Terminal,
    render_state: render::RenderState,
    pub editor: Editor,
    image_picker: Option<ratatui_image::picker::Picker>,

    config: Arc<ArcSwap<Config>>,
    config_updates: (
        tokio::sync::mpsc::UnboundedSender<crate::config::ConfigEvent>,
        tokio::sync::mpsc::UnboundedReceiver<crate::config::ConfigEvent>,
    ),

    signals: Signals,
    jobs: Jobs,
    _presentation_hooks: event::HookRegistration,
    lsp_progress: LspProgressMap,

    theme_mode: Option<theme::Mode>,
}

#[cfg(feature = "integration")]
fn setup_integration_logging() {
    let level = std::env::var("MITOS_LOG_LEVEL")
        .map(|lvl| lvl.parse().unwrap())
        .unwrap_or(log::LevelFilter::Info);

    crate::logging::init_stdout(level);
}

impl Application {
    pub fn new(
        args: Args,
        config: Config,
        lang_loader: syntax::Loader,
        workspace_trust: workspace::trust::WorkspaceTrust,
    ) -> Result<Self, Error> {
        Self::new_with_handler_setup(args, config, lang_loader, workspace_trust, |_, _| {})
    }

    /// Configure shared services before the editor owns them or opens any documents.
    pub fn new_with_handler_setup(
        args: Args,
        config: Config,
        lang_loader: syntax::Loader,
        workspace_trust: workspace::trust::WorkspaceTrust,
        setup: impl FnOnce(&mut view::handlers::Handlers, &editor_config::Config),
    ) -> Result<Self, Error> {
        #[cfg(feature = "integration")]
        setup_integration_logging();

        use view::editor::Action;

        let mut theme_parent_dirs = vec![loader::config_dir()];
        theme_parent_dirs.extend(loader::runtime_dirs().iter().cloned());
        let theme_loader = theme::Loader::new(loader::theme::Resources::new(theme_parent_dirs));

        #[cfg(all(not(windows), not(feature = "integration")))]
        let backend = TerminaBackend::new(terminal_config(&config))
            .context("failed to create terminal backend")?;
        #[cfg(all(windows, not(feature = "integration")))]
        let backend = CrosstermBackend::new(std::io::stdout(), terminal_config(&config));

        #[cfg(feature = "integration")]
        let backend = TestBackend::new(120, 150);

        let theme_mode = backend.get_theme_mode();
        let terminal = Terminal::new(backend)?;
        let area = Rect::from(terminal.size()?);
        let mut compositor = Compositor::new(area);
        let config = Arc::new(ArcSwap::from_pointee(config));
        let jobs = Jobs::new();
        let mut handlers =
            view::handlers::Handlers::new(&config.load().editor, jobs.editor_callback_sender());
        setup(&mut handlers, &config.load().editor);
        handlers::register_hooks();
        let mut editor = Editor::new(
            area,
            Arc::new(theme_loader),
            Arc::new(ArcSwap::from_pointee(lang_loader)),
            Arc::new(Map::new(Arc::clone(&config), |config: &Config| {
                &config.editor
            })),
            handlers,
            workspace_trust,
        );
        let presentation_hooks =
            handlers::bind_editor(&editor, jobs.sender(), compositor.prompt_sessions());
        editor
            .registers
            .set_clipboard_backend(Box::new(crate::clipboard::TerminalClipboard));
        let theme = Self::configured_theme(&editor, &config.load(), &terminal, theme_mode);
        let _ = editor.set_theme(theme);
        editor.debugger_mut().set_terminal_launcher(
            crate::terminal_launcher::ExternalTerminal::new(config.clone())?,
        )?;

        let keys = Box::new(Map::new(Arc::clone(&config), |config: &Config| {
            &config.keys
        }));
        let editor_view = Box::new(ui::EditorView::new(Keymaps::new(keys)));
        compositor.push(editor_view);

        if args.load_tutor {
            let path = loader::runtime_file(Path::new("tutor"));
            editor.open_scratch(&path, Action::VerticalSplit)?;
        } else if !args.files.is_empty() {
            let mut files_it = args.files.into_iter().peekable();

            // If the first file is a directory, skip it and open a picker
            if let Some((first, _)) = files_it.next_if(|(p, _)| p.is_dir()) {
                let picker = ui::file_picker(&editor, first);
                compositor.push(Box::new(overlaid(picker)));
            }

            // If there are any more files specified, open them
            if files_it.peek().is_some() {
                let mut nr_of_files = 0;
                for (file, pos) in files_it {
                    nr_of_files += 1;
                    if file.is_dir() {
                        return Err(anyhow::anyhow!(
                            "expected a path to file, but found a directory: {file:?}. (to open a directory pass it as first argument)"
                        ));
                    } else {
                        // If the user passes in either `--vsplit` or
                        // `--hsplit` as a command line argument, all the given
                        // files will be opened according to the selected
                        // option. If neither of those two arguments are passed
                        // in, just load the files normally.
                        let action = match args.split {
                            _ if nr_of_files == 1 => Action::VerticalSplit,
                            Some(Layout::Vertical) => Action::VerticalSplit,
                            Some(Layout::Horizontal) => Action::HorizontalSplit,
                            None => Action::Load,
                        };
                        let old_id = editor.document_id_by_path(&file);
                        let doc_id = match editor.open(&file, action) {
                            // Ignore irregular files during application init.
                            Err(DocumentOpenError::IrregularFile) => {
                                nr_of_files -= 1;
                                continue;
                            }
                            Err(err) => return Err(anyhow::anyhow!(err)),
                            // We can't open more than 1 buffer for 1 file, in this case we already have opened this file previously
                            Ok(doc_id) if old_id == Some(doc_id) => {
                                nr_of_files -= 1;
                                doc_id
                            }
                            Ok(doc_id) => doc_id,
                        };
                        // with Action::Load all documents have the same view
                        // NOTE: this isn't necessarily true anymore. If
                        // `--vsplit` or `--hsplit` are used, the file which is
                        // opened last is focused on.
                        let view_id = editor.tree.focus;
                        let doc = doc_mut!(editor, &doc_id);
                        let selection = pos
                            .into_iter()
                            .map(|coords| {
                                Range::point(pos_at_coords(doc.text().slice(..), coords, true))
                            })
                            .collect();
                        doc.set_selection(view_id, selection);
                    }
                }

                // if all files were invalid, replace with empty buffer
                if nr_of_files == 0 {
                    editor.new_file(Action::VerticalSplit);
                } else {
                    editor.set_status(format!(
                        "Loaded {} file{}.",
                        nr_of_files,
                        if nr_of_files == 1 { "" } else { "s" } // avoid "Loaded 1 files." grammo
                    ));
                    // align the view to center after all files are loaded,
                    // does not affect views without pos since it is at the top
                    let (view, doc) = current!(editor);
                    align_view(doc, view, Align::Center);
                }
            } else {
                editor.new_file(Action::VerticalSplit);
            }
        } else if stdin().is_terminal() || cfg!(feature = "integration") {
            editor.new_file_welcome();
        } else {
            editor
                .new_file_from_stdin(Action::VerticalSplit)
                .unwrap_or_else(|_| editor.new_file_welcome());
        }

        #[cfg(windows)]
        let signals = futures_util::stream::empty();
        #[cfg(not(windows))]
        let signals = Signals::new([
            signal::SIGTSTP,
            signal::SIGCONT,
            signal::SIGUSR1,
            signal::SIGTERM,
            signal::SIGINT,
        ])
        .context("build signal handler")?;

        let app = Self {
            compositor,
            terminal,
            render_state: render::RenderState::default(),
            editor,
            image_picker: None,
            config,
            config_updates: tokio::sync::mpsc::unbounded_channel(),
            signals,
            jobs,
            _presentation_hooks: presentation_hooks,
            lsp_progress: LspProgressMap::new(),
            theme_mode,
        };

        Ok(app)
    }

    /// Screen and cursor state exposed to the integration test harness.
    #[cfg(feature = "integration")]
    pub fn terminal_backend(&self) -> &TestBackend {
        self.terminal.backend()
    }

    /// Queue a completion for this application's editor and compositor.
    pub fn job_sender(&self) -> crate::job::JobSender {
        self.jobs.sender()
    }

    pub async fn event_loop<S>(&mut self, input_stream: &mut S)
    where
        S: Stream<Item = std::io::Result<TerminalEvent>> + Unpin,
    {
        self.render().await;

        loop {
            if !self.event_loop_until_idle(input_stream).await {
                break;
            }
        }
    }

    pub async fn event_loop_until_idle<S>(&mut self, input_stream: &mut S) -> bool
    where
        S: Stream<Item = std::io::Result<TerminalEvent>> + Unpin,
    {
        loop {
            if self.editor.should_close() {
                return false;
            }

            // One input event can enqueue several callbacks. Drain a bounded
            // batch before accepting more input so synchronous event hooks do
            // not spend every keystroke waiting for space in their own queue.
            if self.drain_ready_callbacks() {
                self.render().await;
                #[cfg(feature = "integration")]
                self.editor.reset_idle_timer();
                // Callbacks can close the editor as well as change its state.
                if self.editor.should_close() {
                    return false;
                }
            }

            use futures_util::StreamExt;

            // Keep callbacks and saves progressing even when terminal input is
            // continuously ready; input priority can fill the callback queue.
            tokio::select! {
                Some(signal) = self.signals.next() => {
                    if !self.handle_signals(signal).await {
                        return false;
                    };
                }
                Some(event) = input_stream.next() => {
                    self.handle_terminal_events(event).await;
                }
                Some(event) = self.config_updates.1.recv() => {
                    match event {
                        crate::config::ConfigEvent::Update(settings) => {
                            let old_editor_config = self.editor.config();
                            self.apply_editor_settings(*settings);
                            self.editor.refresh_config(&old_editor_config);
                        }
                        crate::config::ConfigEvent::Refresh => {
                            self.handle_config_events(ConfigEvent::Refresh);
                        }
                    }
                    self.render().await;
                }
                Some(callback) = self.jobs.callbacks.recv() => {
                    if let Some(job) = self.jobs.handle_callback(&mut self.editor, &mut self.compositor, Ok(Some(callback))) {
                        self.jobs.add(job);
                    }
                    self.render().await;
                }
                Some(callback) = self.jobs.wait_futures.next() => {
                    if let Some(job) = self.jobs.handle_callback(&mut self.editor, &mut self.compositor, callback) {
                        self.jobs.add(job);
                    }
                    self.render().await;
                }
                event = self.editor.wait_event() => {
                    let _idle_handled = self.handle_editor_event(event).await;

                    #[cfg(feature = "integration")]
                    {
                        // Don't report idle while a save is still in flight, or an assertion on the post-save document state (e.g. its path,
                        // set in `handle_document_write`) can run before the `DocumentSavedEvent` is processed. Slow file I/O on Windows
                        // (atomic_save's rename/fsync dance over the still-open temp file) makes this race observable.
                        // Initial syntax must also settle before assertions; its completion can
                        // schedule spelling checks. Both success and failure complete via jobs.
                        if _idle_handled
                            && !self.editor.has_pending_writes()
                            && !self.editor.documents().any(|doc| doc.is_syntax_pending())
                        {
                            return true;
                        }
                    }
                }
            }

            // for integration tests only, reset the idle timer after every
            // event to signal when test events are done processing
            #[cfg(feature = "integration")]
            {
                self.editor.reset_idle_timer();
            }
        }
    }

    pub fn handle_config_events(&mut self, config_event: ConfigEvent) {
        let old_editor_config = self.editor.config();

        match config_event {
            ConfigEvent::Refresh => self.refresh_config(),

            ConfigEvent::Update(editor_config) => {
                let terminal = self.config.load().terminal.clone();
                self.apply_editor_settings(EditorSettings {
                    editor: *editor_config,
                    terminal,
                });
            }
            ConfigEvent::ThemeChanged => {
                let _ = self.terminal.backend_mut().set_background_color(
                    self.editor
                        .theme
                        .try_get_exact("ui.background")
                        .and_then(|style| style.bg),
                );
                return;
            }
        }

        self.editor.refresh_config(&old_editor_config);
    }

    fn apply_editor_settings(&mut self, settings: EditorSettings) {
        let mut app_config = (**self.config.load()).clone();
        app_config.editor = settings.editor;
        app_config.terminal = settings.terminal;
        if let Err(err) = self
            .terminal
            .backend_mut()
            .reconfigure(terminal_config(&app_config))
        {
            self.editor.set_error(|| err.to_string());
        }
        self.config.store(Arc::new(app_config));
    }

    fn refresh_config(&mut self) {
        let mut refresh_config = || -> Result<(), Error> {
            let default_config = Config::load_default()
                .map_err(|err| anyhow::anyhow!("Failed to load config: {}", err))?;

            let lang_loader = self.editor.load_language_config(&default_config.editor)?;
            let theme = Self::configured_theme(
                &self.editor,
                &default_config,
                &self.terminal,
                self.theme_mode,
            );
            let _ = self.editor.apply_language_config(lang_loader, theme);

            self.terminal
                .backend_mut()
                .reconfigure(terminal_config(&default_config))?;
            // Store new config
            self.config.store(Arc::new(default_config));
            Ok(())
        };

        match refresh_config() {
            Ok(()) => self.editor.set_status("Config refreshed"),
            Err(err) => {
                self.editor.set_error(|| err.to_string());
            }
        }
    }

    /// Choose a configured theme compatible with this frontend.
    fn configured_theme(
        editor: &Editor,
        config: &Config,
        terminal: &Terminal,
        mode: Option<theme::Mode>,
    ) -> theme::Theme {
        let true_color = terminal.backend().supports_true_color()
            || config.terminal.true_color
            || crate::true_color();
        let theme_config = config.theme.clone().unwrap_or_default();
        let name = theme_config.choose(mode);
        editor
            .theme_loader
            .load(name)
            .map_err(|e| {
                log::warn!("failed to load theme `{}` - {}", name, e);
                e
            })
            .ok()
            .filter(|theme| {
                let colors_ok = true_color || theme.is_16_color();
                if !colors_ok {
                    log::warn!(
                        "loaded theme `{}` but cannot use it because true color \
                        support is not enabled",
                        theme.name()
                    );
                }
                colors_ok
            })
            .unwrap_or_else(|| editor.theme_loader.default_theme())
    }

    #[cfg(windows)]
    // no signal handling available on windows
    pub async fn handle_signals(&mut self, _signal: ()) -> bool {
        true
    }

    #[cfg(not(windows))]
    pub async fn handle_signals(&mut self, signal: i32) -> bool {
        match signal {
            signal::SIGTSTP => {
                self.restore_term().unwrap();

                // SAFETY:
                //
                // - mitos must have permissions to send signals to all processes in its signal
                //   group, either by already having the requisite permission, or by having the
                //   user's UID / EUID / SUID match that of the receiving process(es).
                let res = unsafe {
                    // A pid of 0 sends the signal to the entire process group, allowing the user to
                    // regain control of their terminal if the editor was spawned under another process
                    // (e.g. when running `git commit`).
                    //
                    // We have to send SIGSTOP (not SIGTSTP) to the entire process group, because,
                    // as mentioned above, the terminal will get stuck if `mitos` was spawned from
                    // an external process and that process waits for `mitos` to complete. This may
                    // be an issue with signal-hook-tokio, but the author of signal-hook believes it
                    // could be a tokio issue instead:
                    // https://github.com/vorner/signal-hook/issues/132
                    libc::kill(0, signal::SIGSTOP)
                };

                if res != 0 {
                    let err = std::io::Error::last_os_error();
                    eprintln!("{}", err);
                    let res = err.raw_os_error().unwrap_or(1);
                    std::process::exit(res);
                }
            }
            signal::SIGCONT => {
                // Copy/Paste from same issue from neovim:
                // https://github.com/neovim/neovim/issues/12322
                // https://github.com/neovim/neovim/pull/13084
                for retries in 1..=10 {
                    match self.terminal.backend_mut().claim() {
                        Ok(()) => break,
                        Err(err) if retries == 10 => panic!("Failed to claim terminal: {}", err),
                        Err(_) => continue,
                    }
                }

                // redraw the terminal
                let area = Rect::from(self.terminal.size().expect("failed to read terminal size"));
                self.compositor.resize(area);
                self.compositor.need_full_redraw();

                self.render().await;
            }
            signal::SIGUSR1 => {
                self.refresh_config();
                self.render().await;
            }
            signal::SIGTERM | signal::SIGINT => {
                self.restore_term().unwrap();
                return false;
            }
            _ => unreachable!(),
        }

        true
    }

    pub async fn handle_idle_timeout(&mut self) {
        let config = self.config.load();
        let mut cx = crate::compositor::Context {
            config: crate::config::Context {
                current: &config,
                updates: &self.config_updates.0,
            },
            editor: &mut self.editor,
            jobs: &mut self.jobs,
            scroll: None,
            image_picker: self.image_picker.as_ref(),
            is_cursor_owner: false,
        };
        let should_render = self.compositor.handle_event(&Event::IdleTimeout, &mut cx);
        if should_render || self.editor.needs_redraw {
            self.render().await;
        }
    }

    pub fn handle_document_write(&mut self, doc_save_event: DocumentSavedEventResult) {
        let doc_save_event = match doc_save_event {
            Ok(event) => event,
            Err(err) => {
                self.editor.set_error(|| err.to_string());
                return;
            }
        };

        if self.editor.document(doc_save_event.doc_id).is_none() {
            warn!(
                "received document saved event for non-existent doc id: {}",
                doc_save_event.doc_id
            );
            return;
        }
        self.editor.complete_document_write(&doc_save_event);

        let lines = doc_save_event.text.len_lines();
        let size = doc_save_event.text.len_bytes();

        enum Size {
            Bytes(u16),
            HumanReadable(f32, &'static str),
        }

        impl std::fmt::Display for Size {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                match self {
                    Self::Bytes(bytes) => write!(f, "{bytes}B"),
                    Self::HumanReadable(size, suffix) => write!(f, "{size:.1}{suffix}"),
                }
            }
        }

        let size = if size < 1024 {
            Size::Bytes(size as u16)
        } else {
            const SUFFIX: [&str; 4] = ["B", "KiB", "MiB", "GiB"];
            let mut size = size as f32;
            let mut i = 0;
            while i < SUFFIX.len() - 1 && size >= 1024.0 {
                size /= 1024.0;
                i += 1;
            }
            Size::HumanReadable(size, SUFFIX[i])
        };

        // TODO: fix being overwritten by lsp
        self.editor.set_status(format!(
            "'{}' written, {lines}L {size}",
            get_relative_path(&doc_save_event.path).to_string_lossy(),
        ));
    }

    #[inline(always)]
    pub async fn handle_editor_event(&mut self, event: EditorEvent) -> bool {
        log::debug!("received editor event: {:?}", event);

        match event {
            EditorEvent::DocumentSaved(event) => {
                self.handle_document_write(event);
                self.render().await;
            }
            EditorEvent::WorkspaceTrust(request) => {
                crate::handlers::workspace_trust::prompt(
                    &self.editor,
                    &mut self.compositor,
                    request,
                );
                self.render().await;
            }
            EditorEvent::ReloadConfirmation(request) => {
                crate::handlers::auto_reload::prompt_reload_modified(&mut self.compositor, request);
                self.render().await;
            }
            EditorEvent::Completion(update) => {
                crate::handlers::completion::apply_update(
                    &mut self.editor,
                    &mut self.compositor,
                    update,
                );
                self.render().await;
            }
            EditorEvent::Navigation(update) => {
                crate::handlers::navigation::show(&mut self.editor, &mut self.compositor, update);
                self.render().await;
            }
            EditorEvent::Hover(update) => {
                crate::handlers::hover::show(&mut self.editor, &mut self.compositor, update);
                self.render().await;
            }
            EditorEvent::BlameDetails(update) => {
                crate::ui::blame::show(
                    &mut self.editor,
                    &mut self.compositor,
                    update,
                    &self.config.load(),
                );
                self.render().await;
            }
            EditorEvent::SignatureHelp(update) => {
                crate::handlers::signature_help::show_signature_help(
                    &mut self.editor,
                    &mut self.compositor,
                    update,
                );
                self.render().await;
            }
            EditorEvent::ConfigEvent(event) => {
                self.handle_config_events(event);
                self.render().await;
            }
            EditorEvent::LanguageServerMessage((id, call)) => {
                self.handle_language_server_message(call, id).await;
                // limit render calls for fast language server messages
                self.editor.redraw().request();
            }
            EditorEvent::DebuggerEvent((id, payload)) => {
                let needs_render = self.editor.handle_debugger_message(id, payload).await;
                if needs_render {
                    self.render().await;
                }
            }
            EditorEvent::Redraw => {
                self.render().await;
            }
            EditorEvent::IdleTimer => {
                self.editor.clear_idle_timer();
                self.handle_idle_timeout().await;

                #[cfg(feature = "integration")]
                {
                    return true;
                }
            }
        }

        false
    }

    pub async fn handle_terminal_events(&mut self, event: std::io::Result<TerminalEvent>) {
        #[cfg(not(windows))]
        use termina::escape::csi;

        let config = self.config.load();
        let mut cx = crate::compositor::Context {
            config: crate::config::Context {
                current: &config,
                updates: &self.config_updates.0,
            },
            editor: &mut self.editor,
            jobs: &mut self.jobs,
            scroll: None,
            image_picker: self.image_picker.as_ref(),
            is_cursor_owner: false,
        };
        // Handle key events
        let should_redraw = match event.unwrap() {
            #[cfg(not(windows))]
            termina::Event::WindowResized(termina::WindowSize { rows, cols, .. }) => {
                self.terminal
                    .resize(Rect::new(0, 0, cols, rows))
                    .expect("Unable to resize terminal");

                let area = Rect::from(self.terminal.size().expect("failed to read terminal size"));

                self.compositor.resize(area);

                self.compositor
                    .handle_event(&Event::Resize(cols, rows), &mut cx)
            }
            #[cfg(not(windows))]
            // Ignore keyboard release events.
            termina::Event::Key(termina::event::KeyEvent {
                kind: termina::event::KeyEventKind::Release,
                ..
            }) => false,
            #[cfg(not(windows))]
            termina::Event::Csi(csi::Csi::Mode(csi::Mode::ReportTheme(mode))) => {
                let config = self.config.load();
                let mode = mode.into();
                let mode_changed = self.theme_mode.as_ref().is_none_or(|m| m != &mode);
                if mode_changed
                    && config
                        .theme
                        .as_ref()
                        .is_none_or(|theme| theme.is_adaptive())
                {
                    self.theme_mode = Some(mode);
                    let theme = Self::configured_theme(
                        &self.editor,
                        &config,
                        &self.terminal,
                        self.theme_mode,
                    );
                    let _ = self.editor.set_theme(theme);
                    true
                } else {
                    false
                }
            }
            #[cfg(windows)]
            TerminalEvent::Resize(width, height) => {
                self.terminal
                    .resize(Rect::new(0, 0, width, height))
                    .expect("Unable to resize terminal");

                let area = Rect::from(self.terminal.size().expect("failed to read terminal size"));

                self.compositor.resize(area);

                self.compositor
                    .handle_event(&Event::Resize(width, height), &mut cx)
            }
            #[cfg(windows)]
            // Ignore keyboard release events.
            crossterm::event::Event::Key(crossterm::event::KeyEvent {
                kind: crossterm::event::KeyEventKind::Release,
                ..
            }) => false,
            #[cfg(not(windows))]
            event if event.is_escape() => false,
            event => self.compositor.handle_event(&event.into(), &mut cx),
        };

        if should_redraw && !self.editor.should_close() {
            self.render().await;
        }
    }

    pub async fn handle_language_server_message(
        &mut self,
        call: lsp_client::Call,
        server_id: LanguageServerId,
    ) {
        use lsp_client::{Call, MethodCall, Notification};

        macro_rules! language_server {
            () => {
                match self.editor.language_server_by_id(server_id) {
                    Some(language_server) => language_server,
                    None => {
                        warn!("can't find language server with id `{}`", server_id);
                        return;
                    }
                }
            };
        }

        match call {
            Call::Notification(lsp_client::jsonrpc::Notification { method, params, .. }) => {
                let notification = match Notification::parse(&method, params) {
                    Ok(notification) => notification,
                    Err(lsp_client::Error::Unhandled) => {
                        info!("Ignoring Unhandled notification from Language Server");
                        return;
                    }
                    Err(err) => {
                        error!(
                            "Ignoring unknown notification from Language Server: {}",
                            err
                        );
                        return;
                    }
                };

                match notification {
                    Notification::Initialized => {
                        self.editor.handle_language_server_initialized(server_id);
                    }
                    Notification::PublishDiagnostics(params) => {
                        self.editor.handle_publish_diagnostics(server_id, params);
                    }
                    Notification::ShowMessage(params) => {
                        self.handle_show_message(params.typ, params.message);
                    }
                    Notification::LogMessage(params) => {
                        log::info!("window/logMessage: {:?}", params);
                    }
                    Notification::ProgressMessage(params)
                        if !self
                            .compositor
                            .has_component(std::any::type_name::<ui::Prompt>()) =>
                    {
                        let editor_view = self
                            .compositor
                            .find::<ui::EditorView>()
                            .expect("expected at least one EditorView");
                        let lsp::ProgressParams {
                            token,
                            value: lsp::ProgressParamsValue::WorkDone(work),
                        } = params;
                        let (title, message, percentage) = match &work {
                            lsp::WorkDoneProgress::Begin(lsp::WorkDoneProgressBegin {
                                title,
                                message,
                                percentage,
                                ..
                            }) => (Some(title), message, percentage),
                            lsp::WorkDoneProgress::Report(lsp::WorkDoneProgressReport {
                                message,
                                percentage,
                                ..
                            }) => (None, message, percentage),
                            lsp::WorkDoneProgress::End(lsp::WorkDoneProgressEnd { message }) => {
                                if message.is_some() {
                                    (None, message, &None)
                                } else {
                                    self.lsp_progress.end_progress(server_id, &token);
                                    if !self.lsp_progress.is_progressing(server_id) {
                                        editor_view.spinners_mut().get_or_create(server_id).stop();
                                        view::features::diagnostics::pull::request_all_document_diagnostics_for_language_server(
                                            &mut self.editor,
                                            server_id,
                                        );
                                    }
                                    self.editor.clear_status();

                                    // we want to render to clear any leftover spinners or messages
                                    return;
                                }
                            }
                        };

                        if self.editor.config().lsp.progress.enable {
                            let title =
                                title.or_else(|| self.lsp_progress.title(server_id, &token));
                            if title.is_some() || percentage.is_some() || message.is_some() {
                                use std::fmt::Write as _;
                                let mut status = format!("{}: ", language_server!().name());
                                if let Some(percentage) = percentage {
                                    write!(status, "{percentage:>2}% ").unwrap();
                                }
                                if let Some(title) = title {
                                    status.push_str(title);
                                }
                                if title.is_some() && message.is_some() {
                                    status.push_str(" ⋅ ");
                                }
                                if let Some(message) = message {
                                    status.push_str(message);
                                }
                                self.editor.set_status(status);
                            }
                        }

                        match work {
                            lsp::WorkDoneProgress::Begin(begin_status) => {
                                self.lsp_progress
                                    .begin(server_id, token.clone(), begin_status);
                            }
                            lsp::WorkDoneProgress::Report(report_status) => {
                                self.lsp_progress
                                    .update(server_id, token.clone(), report_status);
                            }
                            lsp::WorkDoneProgress::End(_) => {
                                self.lsp_progress.end_progress(server_id, &token);
                                if !self.lsp_progress.is_progressing(server_id) {
                                    editor_view.spinners_mut().get_or_create(server_id).stop();
                                    view::features::diagnostics::pull::request_all_document_diagnostics_for_language_server(
                                        &mut self.editor,
                                        server_id,
                                    );
                                };
                            }
                        }
                    }
                    Notification::ProgressMessage(_params) => {
                        // do nothing
                    }
                    Notification::Exit => {
                        let status =
                            format!("Language server exited: {}", language_server!().name());
                        self.editor.set_status(status);

                        self.editor.handle_language_server_exit(server_id);
                    }
                }
            }
            Call::MethodCall(lsp_client::jsonrpc::MethodCall {
                method, params, id, ..
            }) => {
                let reply = match MethodCall::parse(&method, params) {
                    Err(lsp_client::Error::Unhandled) => {
                        error!(
                            "Language Server: Method {} not found in request {}",
                            method, id
                        );
                        Err(lsp_client::jsonrpc::Error {
                            code: lsp_client::jsonrpc::ErrorCode::MethodNotFound,
                            message: format!("Method not found: {}", method),
                            data: None,
                        })
                    }
                    Err(err) => {
                        log::error!(
                            "Language Server: Received malformed method call {} in request {}: {}",
                            method,
                            id,
                            err
                        );
                        Err(lsp_client::jsonrpc::Error {
                            code: lsp_client::jsonrpc::ErrorCode::ParseError,
                            message: format!("Malformed method call: {}", method),
                            data: None,
                        })
                    }
                    Ok(MethodCall::WorkDoneProgressCreate(params)) => {
                        self.lsp_progress.create(server_id, params.token);

                        let editor_view = self
                            .compositor
                            .find::<ui::EditorView>()
                            .expect("expected at least one EditorView");
                        let spinner = editor_view.spinners_mut().get_or_create(server_id);
                        if spinner.is_stopped() {
                            spinner.start();
                        }

                        Ok(serde_json::Value::Null)
                    }
                    Ok(MethodCall::ApplyWorkspaceEdit(params)) => self
                        .editor
                        .handle_workspace_edit(server_id, params)
                        .map(|response| json!(response)),
                    Ok(MethodCall::WorkspaceFolders) => {
                        Ok(json!(&*language_server!().workspace_folders().await))
                    }
                    Ok(MethodCall::WorkspaceConfiguration(params)) => {
                        Ok(json!(language_server!().configuration(&params)))
                    }
                    Ok(MethodCall::RegisterCapability(params)) => {
                        self.editor
                            .register_language_server_capabilities(server_id, params);
                        Ok(serde_json::Value::Null)
                    }
                    Ok(MethodCall::UnregisterCapability(params)) => {
                        self.editor
                            .unregister_language_server_capabilities(server_id, params);
                        Ok(serde_json::Value::Null)
                    }
                    Ok(MethodCall::ShowDocument(params)) => {
                        let language_server = language_server!();
                        let offset_encoding = language_server.offset_encoding();

                        let result = self.handle_show_document(params, offset_encoding);
                        Ok(json!(result))
                    }
                    Ok(MethodCall::WorkspaceDiagnosticRefresh) => {
                        let server_id = language_server!().id();
                        view::features::diagnostics::pull::request_all_document_diagnostics_for_language_server(
                            &mut self.editor,
                            server_id,
                        );

                        Ok(serde_json::Value::Null)
                    }
                    Ok(MethodCall::CodeLensRefresh) => {
                        let server_id = language_server!().id();
                        view::features::code_lenses::refresh_for_language_server(
                            &mut self.editor,
                            server_id,
                        );
                        Ok(serde_json::Value::Null)
                    }
                    Ok(MethodCall::ShowMessageRequest(params)) => {
                        if let Some(actions) = params.actions.filter(|a| !a.is_empty()) {
                            let id = id.clone();
                            let select = ui::Select::new(
                                params.message,
                                actions,
                                (),
                                move |editor, action, event| {
                                    let reply = match event {
                                        ui::PromptEvent::Update => return,
                                        ui::PromptEvent::Validate => Some(action.clone()),
                                        ui::PromptEvent::Abort => None,
                                    };
                                    if let Some(language_server) =
                                        editor.language_server_by_id(server_id)
                                        && let Err(err) =
                                            language_server.reply(id.clone(), Ok(json!(reply)))
                                    {
                                        log::error!(
                                                "Failed to send reply to server '{}' request {id}: {err}",
                                                language_server.name()
                                            );
                                    }
                                },
                            );
                            self.compositor
                                .replace_or_push("lsp-show-message-request", select);
                            // Avoid sending a reply. The `Select` callback above sends the reply.
                            return;
                        } else {
                            self.handle_show_message(params.typ, params.message);
                            Ok(serde_json::Value::Null)
                        }
                    }
                };

                let language_server = language_server!();
                if let Err(err) = language_server.reply(id.clone(), reply) {
                    log::error!(
                        "Failed to send reply to server '{}' request {id}: {err}",
                        language_server.name()
                    );
                }
            }
            Call::Invalid { id } => log::error!("LSP invalid method call id={:?}", id),
        }
    }

    fn handle_show_message(&mut self, message_type: lsp::MessageType, message: String) {
        if self.config.load().editor.lsp.messages.enable {
            match message_type {
                lsp::MessageType::ERROR => self.editor.set_error(|| message),
                lsp::MessageType::WARNING => self.editor.set_warning(|| message),
                _ => self.editor.set_status(message),
            }
        }
    }

    fn handle_show_document(
        &mut self,
        params: lsp::ShowDocumentParams,
        offset_encoding: lsp_client::OffsetEncoding,
    ) -> lsp::ShowDocumentResult {
        if let lsp::ShowDocumentParams {
            external: Some(true),
            uri,
            ..
        } = params
        {
            self.jobs.callback(crate::open_external_url_callback(uri));
            return lsp::ShowDocumentResult { success: true };
        };

        let lsp::ShowDocumentParams {
            uri,
            selection,
            take_focus,
            ..
        } = params;

        let uri = match editor_core::Uri::try_from(uri) {
            Ok(uri) => uri,
            Err(err) => {
                log::error!("{err}");
                return lsp::ShowDocumentResult { success: false };
            }
        };
        // If `Uri` gets another variant other than `Path` this may not be valid.
        let path = uri.as_path().expect("URIs are valid paths");

        // Determine the focus strategy based on the current UI state and LSP request:
        // 1. If there is no pop-up overlay, jump directly (Replace).
        // 2. If there is a pop-up overlay, unless the LSP forces take_focus, only load in the background (Load) to prevent interruption of input.
        // Note: We assume layer_count() == 1 means only the EditorView is present (no popups/overlays).
        let action = if self.compositor.layer_count() == 1 {
            view::editor::Action::Replace
        } else {
            match take_focus {
                Some(true) => view::editor::Action::Replace,
                _ => view::editor::Action::Load,
            }
        };

        let doc_id = match self.editor.open(path, action) {
            Ok(id) => id,
            Err(err) => {
                log::error!("failed to open path: {:?}: {:?}", uri, err);
                return lsp::ShowDocumentResult { success: false };
            }
        };

        let doc = doc_mut!(self.editor, &doc_id);
        if let Some(range) = selection {
            // TODO: convert inside server
            if let Some(new_range) = lsp_range_to_range(doc.text(), range, offset_encoding) {
                let view = view_mut!(self.editor);

                // we flip the range so that the cursor sits on the start of the symbol
                // (for example start of the function).
                doc.set_selection(view.id, Selection::single(new_range.head, new_range.anchor));
                if action.align_view(view, doc.id()) {
                    align_view(doc, view, Align::Center);
                }
            } else {
                log::warn!("lsp position out of bounds - {:?}", range);
            };
        };
        lsp::ShowDocumentResult { success: true }
    }

    fn restore_term(&mut self) -> std::io::Result<()> {
        self.terminal.show_cursor().ok();
        self.terminal.backend_mut().restore()
    }

    #[cfg(all(not(feature = "integration"), not(windows)))]
    pub fn event_stream(
        &self,
    ) -> impl Stream<Item = std::io::Result<TerminalEvent>> + Unpin + use<> {
        use termina::{escape::csi, Terminal as _};
        let reader = self.terminal.backend().terminal().event_reader();
        termina::EventStream::new(reader, |event| {
            // Accept either non-escape sequences or theme mode updates.
            !event.is_escape()
                || matches!(
                    event,
                    termina::Event::Csi(csi::Csi::Mode(csi::Mode::ReportTheme(_)))
                )
        })
    }

    #[cfg(all(not(feature = "integration"), windows))]
    pub fn event_stream(
        &self,
    ) -> impl Stream<Item = std::io::Result<TerminalEvent>> + Unpin + use<> {
        crossterm::event::EventStream::new()
    }

    #[cfg(feature = "integration")]
    pub fn event_stream(
        &self,
    ) -> impl Stream<Item = std::io::Result<TerminalEvent>> + Unpin + use<> {
        use std::{
            pin::Pin,
            task::{Context, Poll},
        };

        /// A dummy stream that never polls as ready.
        pub struct DummyEventStream;

        impl Stream for DummyEventStream {
            type Item = std::io::Result<TerminalEvent>;

            fn poll_next(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
                Poll::Pending
            }
        }

        DummyEventStream
    }

    pub async fn run<S>(&mut self, input_stream: &mut S) -> Result<i32, Error>
    where
        S: Stream<Item = std::io::Result<TerminalEvent>> + Unpin,
    {
        self.terminal.backend_mut().claim()?;

        #[cfg(not(feature = "integration"))]
        {
            self.image_picker = Some(
                ratatui_image::picker::Picker::from_query_stdio().unwrap_or_else(|err| {
                    log::warn!(
                        "failed to detect terminal image capabilities, using halfblocks: {err}"
                    );
                    ratatui_image::picker::Picker::halfblocks()
                }),
            );
            log::debug!(
                "terminal image protocol: {:?}",
                self.image_picker
                    .as_ref()
                    .expect("image picker was just initialized")
                    .protocol_type()
            );
        }

        #[cfg(feature = "integration")]
        {
            self.image_picker = Some(ratatui_image::picker::Picker::halfblocks());
        }

        self.event_loop(input_stream).await;

        let close_errs = self.close().await;

        self.restore_term()?;

        for err in close_errs {
            self.editor.exit_code = 1;
            eprintln!("Error: {}", err);
        }

        Ok(self.editor.exit_code)
    }

    pub async fn close(&mut self) -> Vec<anyhow::Error> {
        // [NOTE] we intentionally do not return early for errors because we
        //        want to try to run as much cleanup as we can, regardless of
        //        errors along the way
        let mut errs = Vec::new();

        if let Err(err) = self
            .jobs
            .finish(&mut self.editor, Some(&mut self.compositor))
            .await
        {
            log::error!("Error executing job: {}", err);
            errs.push(err);
        };

        if let Err(err) = self.editor.flush_writes().await {
            log::error!("Error writing: {}", err);
            errs.push(err);
        }

        self.editor.close_language_servers(None).await;

        errs
    }
}

impl ui::menu::Item for lsp::MessageActionItem {
    type Data = ();
    fn format(&self, _data: &Self::Data) -> tui::widgets::Row<'_> {
        tui::widgets::Row::new([self.title.as_str()])
    }
}
