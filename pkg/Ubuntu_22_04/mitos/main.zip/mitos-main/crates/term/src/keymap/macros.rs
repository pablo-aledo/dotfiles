#[macro_export]
macro_rules! key {
    ($key:ident) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::$key,
            modifiers: ::ui_core::keyboard::KeyModifiers::NONE,
        }
    };
    ($($ch:tt)*) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::Char($($ch)*),
            modifiers: ::ui_core::keyboard::KeyModifiers::NONE,
        }
    };
}

#[macro_export]
macro_rules! shift {
    ($key:ident) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::$key,
            modifiers: ::ui_core::keyboard::KeyModifiers::SHIFT,
        }
    };
    ($($ch:tt)*) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::Char($($ch)*),
            modifiers: ::ui_core::keyboard::KeyModifiers::SHIFT,
        }
    };
}

#[macro_export]
macro_rules! ctrl {
    ($key:ident) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::$key,
            modifiers: ::ui_core::keyboard::KeyModifiers::CONTROL,
        }
    };
    ($($ch:tt)*) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::Char($($ch)*),
            modifiers: ::ui_core::keyboard::KeyModifiers::CONTROL,
        }
    };
}

#[macro_export]
macro_rules! alt {
    ($key:ident) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::$key,
            modifiers: ::ui_core::keyboard::KeyModifiers::ALT,
        }
    };
    ($($ch:tt)*) => {
        ::ui_core::input::KeyEvent {
            code: ::ui_core::keyboard::KeyCode::Char($($ch)*),
            modifiers: ::ui_core::keyboard::KeyModifiers::ALT,
        }
    };
}

/// Macro for defining a `KeyTrie`. Example:
///
/// ```
/// # use editor_core::hashmap;
/// # use term::keymap;
/// let normal_mode = keymap!({ "Normal mode"
///     "i" => insert_mode,
///     "g" => { "Goto"
///         "g" => goto_file_start,
///         "e" => goto_file_end,
///     },
///     "j" | "down" => move_line_down,
/// });
/// let keymap = normal_mode;
/// ```
#[macro_export]
macro_rules! keymap {
    (@trie $cmd:ident) => {
        $crate::keymap::KeyTrie::MappableCommand($crate::commands::MappableCommand::$cmd)
    };

    (@trie
        { $label:literal $(sticky=$sticky:literal)? $($($key:literal)|+ => $value:tt,)+ }
    ) => {
        keymap!({ $label $(sticky=$sticky)? $($($key)|+ => $value,)+ })
    };

    (@trie [$($cmd:ident),* $(,)?]) => {
        $crate::keymap::KeyTrie::sequence(vec![$($crate::commands::MappableCommand::$cmd),*])
    };

    (
        { $label:literal $(sticky=$sticky:literal)? $($($key:literal)|+ => $value:tt,)+ }
    ) => {
        // modified from the hashmap! macro
        {
            let _cap = hashmap!(@count $($($key),+),*);
            let mut _map = ::indexmap::IndexMap::with_capacity(_cap);
            $(
                $(
                    let _key = $key.parse::<::ui_core::input::KeyEvent>().unwrap();
                    let _duplicate = _map.insert(
                        _key,
                        keymap!(@trie $value)
                    );
                    assert!(_duplicate.is_none(), "Duplicate key found: {:?}", _duplicate.unwrap());
                )+
            )*
            let mut _node = $crate::keymap::KeyTrieNode::new($label, _map);
            $( _node.is_sticky = $sticky; )?
            $crate::keymap::KeyTrie::Node(_node)
        }
    };
}

pub use alt;
pub use ctrl;
pub use key;
pub use keymap;
pub use shift;
