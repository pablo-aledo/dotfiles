use anyhow::{Context, Error, Result};
use loader::VERSION_AND_GIT_HASH;
use term::application::Application;
use term::args::Args;
use term::config::{Config, ConfigLoadError};

fn setup_logging(verbosity: u64) -> Result<()> {
    let level = match verbosity {
        0 => log::LevelFilter::Warn,
        1 => log::LevelFilter::Info,
        2 => log::LevelFilter::Debug,
        _3_or_more => log::LevelFilter::Trace,
    };

    term::logging::init_file(level, &loader::log_file())?;

    Ok(())
}

fn main() -> Result<()> {
    if let Some(result) = term::run_debug_terminal_helper() {
        std::process::exit(result?);
    }
    let exit_code = main_impl()?;
    std::process::exit(exit_code);
}

#[tokio::main]
async fn main_impl() -> Result<i32> {
    let args = Args::parse_args().context("could not parse arguments")?;

    loader::initialize_config_file(args.config_file.clone());
    loader::initialize_log_file(args.log_file.clone());

    // Help has a higher priority and should be handled separately.
    if args.display_help {
        print!(
            "\
{} {}
{}
{}

USAGE:
    mitos [FLAGS] [files]...

ARGS:
    <files>...    Set the input file to use, position can also be specified via file[:row[:col]]

FLAGS:
    -h, --help                     Print help information
    --strict                       Bail on error for commands that can fail.
    --tutor                        Load the tutorial
    --health [CATEGORY]            Check for potential errors in editor setup
                                   CATEGORY can be a language or one of 'clipboard', 'languages',
                                   'all-languages' or 'all'. 'languages' is filtered according to
                                   user config, 'all-languages' and 'all' are not. If not specified,
                                   the default is the same as 'all', but with languages filtering.
    -g, --grammar {{fetch|build}}    Fetch or builds tree-sitter grammars listed in languages.toml.
    -c, --config <file>            Specify a file to use for configuration
    --migrate-config <file> --stdout
                                   Export migrated config to stdout without changing the file
    -v                             Increase logging verbosity each use for up to 3 times
    --log <file>                   Specify a file to use for logging
                                   (default file: {})
    -V, --version                  Print version information
    --vsplit                       Split all given files vertically into different windows
    --hsplit                       Split all given files horizontally into different windows
    -w, --working-dir <path>       Specify an initial working directory
    +[N]                           Open the first given file at line number N, or the last line, if
                                   N is not specified.
",
            env!("CARGO_PKG_NAME"),
            VERSION_AND_GIT_HASH,
            env!("CARGO_PKG_AUTHORS"),
            env!("CARGO_PKG_DESCRIPTION"),
            loader::default_log_file().display(),
        );
        std::process::exit(0);
    }

    if args.display_version {
        println!("mitos {}", VERSION_AND_GIT_HASH);
        std::process::exit(0);
    }

    if let Some(path) = &args.migrate_config {
        let source = std::fs::read_to_string(path)
            .with_context(|| format!("could not read config {}", path.display()))?;
        let output = loader::config::migration::source(&source)?.unwrap_or(source);
        use std::io::Write;
        if let Err(err) = std::io::stdout().lock().write_all(output.as_bytes())
            && err.kind() != std::io::ErrorKind::BrokenPipe
        {
            return Err(err.into());
        }
        return Ok(0);
    }

    if args.health {
        if let Err(err) = term::health::print_health(args.health_arg) {
            // Piping to for example `head -10` requires special handling:
            // https://stackoverflow.com/a/65760807/7115678
            if err.kind() != std::io::ErrorKind::BrokenPipe {
                return Err(err.into());
            }
        }

        std::process::exit(0);
    }

    if args.fetch_grammars {
        grammar_build::fetch_grammars(
            loader::grammar::get_grammar_configs()?,
            &loader::runtime_dirs()[0],
            args.strict,
        )?;
        return Ok(0);
    }

    if args.build_grammars {
        grammar_build::build_grammars(
            loader::grammar::get_grammar_configs()?,
            &loader::runtime_dirs()[0],
            None,
            args.strict,
        )?;
        return Ok(0);
    }

    setup_logging(args.verbosity).context("failed to initialize logging")?;

    // NOTE: Set the working directory early so the correct configuration is loaded. Be aware that
    // Application::new() depends on this logic so it must be updated if this changes.
    if let Some(path) = &args.working_directory {
        stdx::env::set_current_working_dir(path)?;
    } else if let Some((path, _)) = args.files.first().filter(|p| p.0.is_dir()) {
        // If the first file is a directory, it will be the working directory unless -w was specified
        stdx::env::set_current_working_dir(path)?;
    } else if let Err(err) = std::env::current_dir() {
        eprintln!("Couldn't determine the current working directory: {err}");
        eprintln!("Check that it still exists, or pass an initial directory with `--working-dir`");
        return Ok(1);
    }

    let config = match Config::load_default() {
        Ok(loaded) => loaded,
        Err(ConfigLoadError::Error(err)) if err.kind() == std::io::ErrorKind::NotFound => {
            Config::default()
        }
        Err(ConfigLoadError::Error(err)) => return Err(Error::new(err)),
        Err(ConfigLoadError::BadConfig(err)) => {
            eprintln!("Bad config: {}", err);
            eprintln!("Press <ENTER> to continue with default config");
            use std::io::Read;
            let _ = std::io::stdin().read(&mut []);
            Config::default()
        }
    };

    let workspace_trust = workspace::trust::WorkspaceTrust::new(
        (&config.editor.workspace_trust).into(),
        loader::workspace_trust_dir(),
    );

    let resources = loader::syntax::Resources::default();
    let lang_loader = language::loader::user_lang_loader(&workspace_trust, resources.clone())
        .unwrap_or_else(|err| {
            eprintln!("{}", err);
            eprintln!("Press <ENTER> to continue with default language config");
            use std::io::Read;
            // This waits for an enter press.
            let _ = std::io::stdin().read(&mut []);
            language::loader::default_lang_loader(resources)
        });

    // TODO: use the thread local executor to spawn the application task separately from the work pool
    let mut app = Application::new(args, config, lang_loader, workspace_trust)
        .context("unable to start Mitos")?;
    let mut events = app.event_stream();

    let exit_code = app.run(&mut events).await?;

    Ok(exit_code)
}
