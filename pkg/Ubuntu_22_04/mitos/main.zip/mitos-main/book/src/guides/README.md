# Guides

This section contains guides for adding new languages to Mitos: language and
grammar configuration, and the tree-sitter query files that drive highlighting,
power indentation, textobjects, symbol tags, and other features.
