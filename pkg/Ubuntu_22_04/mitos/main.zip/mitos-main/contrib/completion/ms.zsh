#compdef _ms ms
# Zsh completion script for Mitos editor

_ms() {
	_arguments -C \
		"-h[Prints help information]" \
		"--help[Prints help information]" \
		"--strict[Bail on error for commands that can fail]" \
		"-v[Increase logging verbosity]" \
		"-vv[Increase logging verbosity]" \
		"-vvv[Increase logging verbosity]" \
		"-V[Prints version information]" \
		"--version[Prints version information]" \
		"--tutor[Loads the tutorial]" \
		"--health[Checks for errors in editor setup]:language:->health" \
		"-g[Fetches or builds tree-sitter grammars]:action:->grammar" \
		"--grammar[Fetches or builds tree-sitter grammars]:action:->grammar" \
		"--vsplit[Splits all given files vertically]" \
		"--hsplit[Splits all given files horizontally]" \
		"-c[Specifies a file to use for configuration]" \
		"--config[Specifies a file to use for configuration]" \
		"-w[Specify initial working directory]" \
		"--working-dir[Specify initial working directory]" \
		"--migrate-config[Export migrated configuration (requires --stdout)]:config file:_files" \
		"--stdout[Print migrated configuration without changing the file]" \
		"--log[Specifies a file to use for logging]" \
		"*:file:_files"

	case "$state" in
	health)
		local languages=($(ms --health all-languages | tail -n '+2' | awk '{print $1}' | sed 's/\x1b\[[0-9;]*m//g;s/[✘✓]//g'))
		_values 'language' $languages
		;;
	grammar)
		_values 'action' fetch build
		;;
	esac
}
