from __future__ import annotations

from dataclasses import asdict, replace
from pathlib import Path

from claw_daw.cli.headless import HeadlessRunner
from claw_daw.genre_packs.acceptance import AcceptanceFailure
from claw_daw.genre_packs.v1 import get_pack_v1
from claw_daw.prompt.similarity import project_similarity
from claw_daw.quality_workflow import QualityWorkflowError, run_quality_workflow
from claw_daw.stylepacks.compile import compile_to_script, normalize_beatspec
from claw_daw.stylepacks.io import beatspec_to_dict, save_report_json
from claw_daw.audio.sanity import MixSanity, analyze_mix_sanity
from claw_daw.stylepacks.score import spectral_balance_score
from claw_daw.stylepacks.stylepacks_v1 import get_stylepack
from claw_daw.stylepacks.types import AttemptReport, BeatSpec


def _tweak_knobs_for_retry(spec: BeatSpec, attempt: int) -> BeatSpec:
    """If scoring is poor, adjust a few parameters deterministically."""

    knobs = dict(spec.knobs)

    # Increase humanization gradually.
    knobs["humanize_timing"] = int(knobs.get("humanize_timing", 0)) + 2
    knobs["humanize_velocity"] = int(knobs.get("humanize_velocity", 0)) + 2

    # Reduce lead density a bit (less busy highs).
    knobs["lead_density"] = max(0.10, float(knobs.get("lead_density", 0.4)) - 0.10)

    # If still failing later attempts, swap drum kit to change overall tone.
    if attempt >= 2:
        cur = str(knobs.get("drum_kit") or "trap_hard")
        cycle = ["trap_hard", "house_clean", "boombap_dusty", "gm_basic"]
        if cur in cycle:
            knobs["drum_kit"] = cycle[(cycle.index(cur) + 1) % len(cycle)]

    # Nudge drum density down if too busy.
    if attempt >= 1:
        knobs["drum_density"] = max(0.40, float(knobs.get("drum_density", 0.8)) - 0.05)

    return BeatSpec(
        name=spec.name,
        stylepack=spec.stylepack,
        seed=spec.seed,
        max_attempts=spec.max_attempts,
        length_bars=spec.length_bars,
        bpm=spec.bpm,
        swing_percent=spec.swing_percent,
        knobs=knobs,
        score_threshold=spec.score_threshold,
        max_similarity=spec.max_similarity,
    )


def _autofix_for_mix_sanity(spec: BeatSpec, sanity: MixSanity | None, attempt: int) -> BeatSpec:
    """Deterministic small mix/mastering fixes based on audio analysis.

    This is intentionally conservative: it tweaks a few stylepack knobs and
    optionally forces a mastering preset. It never uses randomness.
    """

    if sanity is None:
        return spec

    knobs = dict(spec.knobs)

    mean_db = float(sanity.metrics.get("mean_dbfs", 0.0))
    max_db = float(sanity.metrics.get("max_dbfs", 0.0))
    silence = float(sanity.metrics.get("silence_fraction", 0.0))

    # Mostly silent? Increase densities and choose a louder preset.
    if silence >= 0.50 or mean_db < -40.0:
        knobs["drum_density"] = min(1.0, float(knobs.get("drum_density", 0.8)) + 0.10)
        knobs["lead_density"] = min(1.0, float(knobs.get("lead_density", 0.4)) + 0.10)
        knobs["mastering_preset"] = "clean"

    # Too hot / near clipping? Back off brightness and choose the safer preset.
    if max_db >= -1.0 or mean_db > -10.0:
        knobs["lead_density"] = max(0.05, float(knobs.get("lead_density", 0.4)) - 0.10)
        knobs["drum_density"] = max(0.30, float(knobs.get("drum_density", 0.8)) - 0.05)
        knobs["mastering_preset"] = "clean"

    # If harsh highs, thin leads a bit and optionally switch to "lofi" later.
    if any("highs dominate" in r for r in sanity.reasons):
        knobs["lead_density"] = max(0.05, float(knobs.get("lead_density", 0.4)) - 0.10)
        knobs["mastering_preset"] = "clean"

    # If boomy lows, nudge drum density down slightly (often kick/808).
    if any("lows dominate" in r for r in sanity.reasons):
        knobs["drum_density"] = max(0.25, float(knobs.get("drum_density", 0.8)) - 0.05)
        if attempt >= 2:
            knobs["mastering_preset"] = "clean"

    return BeatSpec(
        name=spec.name,
        stylepack=spec.stylepack,
        seed=spec.seed,
        max_attempts=spec.max_attempts,
        length_bars=spec.length_bars,
        bpm=spec.bpm,
        swing_percent=spec.swing_percent,
        knobs=knobs,
        score_threshold=spec.score_threshold,
        max_similarity=spec.max_similarity,
    )


def run_stylepack(
    spec: BeatSpec,
    *,
    out_prefix: str,
    soundfont: str,
    base_dir: str | Path = ".",
    tools_dir: str = "tools",
    out_dir: str = "out",
    quality_preset: str = "edm_streaming",
    quality_presets_path: str = "tools/mix_presets.json",
    section_gain: bool = False,
) -> str:
    """Generate + score + iterate, then run gated quality export; write report."""

    base = Path(base_dir)
    outp = Path(out_dir)
    outp.mkdir(parents=True, exist_ok=True)

    spec = normalize_beatspec(spec)
    base_seed = int(spec.seed)
    sp = get_stylepack(spec.stylepack)
    pack = get_pack_v1(sp.pack)

    attempts: list[AttemptReport] = []
    attempt_specs: list[BeatSpec] = []

    prev_proj = None
    best_idx = None
    best_score = -1.0

    cur_spec = spec

    for attempt in range(int(spec.max_attempts)):
        attempt_seed = base_seed + attempt
        attempt_spec = replace(cur_spec, seed=attempt_seed, max_attempts=1)
        attempt_specs.append(attempt_spec)

        # compile (writes tools/<out_prefix>.txt)
        script_path = compile_to_script(attempt_spec, out_prefix=out_prefix, tools_dir=tools_dir)

        # render (fast path for scoring): preview only
        r = HeadlessRunner(soundfont=str(Path(soundfont).expanduser().resolve()), strict=True, dry_run=False)
        lines = Path(script_path).read_text(encoding="utf-8").splitlines()

        preview_only: list[str] = []
        for ln in lines:
            s = ln.strip()
            if s.startswith("export_mp3") or s.startswith("export_wav") or s.startswith("export_m4a"):
                continue
            preview_only.append(ln)

        r.run_lines(preview_only, base_dir=base)
        proj = r.require_project()

        # acceptance (genre pack)
        acceptance_ok = True
        acceptance_errors: list[str] = []
        try:
            pack.accept(proj)
        except AcceptanceFailure as e:
            acceptance_ok = False
            acceptance_errors = list(getattr(e, "errors", []) or [str(e)])

        # similarity to previous attempt
        sim = None
        if prev_proj is not None:
            sim = float(project_similarity(prev_proj, proj))

        prev_proj = proj

        # spectral score (preview preferred if available)
        preview = Path(out_dir) / f"{out_prefix}.preview.mp3"
        full = Path(out_dir) / f"{out_prefix}.mp3"
        audio_path = preview if preview.exists() else full

        spectral = None
        sanity: MixSanity | None = None
        score = None
        if audio_path.exists():
            ss = spectral_balance_score(str(audio_path))
            spectral = {"score": ss.score, "reasons": ss.reasons, "bands": ss.report}

            sanity = analyze_mix_sanity(str(audio_path))

            # Integrate as a gate: the final score is bounded by both.
            score = float(min(ss.score, sanity.score))

        attempts.append(
            AttemptReport(
                attempt=attempt,
                seed=attempt_seed,
                knobs=dict(attempt_spec.knobs),
                acceptance_ok=acceptance_ok,
                acceptance_errors=acceptance_errors,
                similarity_to_prev=sim,
                spectral=spectral,
                sanity=(sanity.to_dict() if sanity else None),
                score=score,
            )
        )

        # track best
        if score is not None and score > best_score and acceptance_ok:
            best_score = score
            best_idx = attempt

        # stop if good enough
        if acceptance_ok and score is not None and score >= float(spec.score_threshold):
            best_idx = attempt
            break

        # tweak and retry: first address obvious mix issues, then apply generic knob tweaks.
        cur_spec = _autofix_for_mix_sanity(cur_spec, sanity, attempt)
        cur_spec = _tweak_knobs_for_retry(cur_spec, attempt)

    qualified_idx: int | None = None
    if best_idx is not None and 0 <= best_idx < len(attempts):
        a = attempts[best_idx]
        if a.acceptance_ok and a.score is not None and a.score >= float(spec.score_threshold):
            qualified_idx = best_idx

    # mark chosen only when the attempt clears acceptance + score threshold
    if qualified_idx is not None:
        attempts[qualified_idx] = AttemptReport(**{**asdict(attempts[qualified_idx]), "chosen": True})  # type: ignore[arg-type]

    # Final render: rerun the chosen attempt script including full MP3 export.
    # Note: we render from the chosen attempt knobs directly so that any
    # auto-fixes (e.g. mastering preset overrides) are faithfully reproduced.
    quality_report: dict | None = None
    if qualified_idx is not None:
        final_spec = attempt_specs[qualified_idx]
        final_script = compile_to_script(final_spec, out_prefix=out_prefix, tools_dir=tools_dir)
        final_lines = Path(final_script).read_text(encoding="utf-8").splitlines()
        runnable: list[str] = []
        has_save = False
        for ln in final_lines:
            s = ln.strip()
            if s.startswith("export_"):
                continue
            if s.startswith("save_project "):
                has_save = True
            runnable.append(ln)
        if not has_save:
            runnable.append(f"save_project out/{out_prefix}.json")

        r = HeadlessRunner(soundfont=None, strict=True, dry_run=False)
        r.run_lines(runnable, base_dir=base)

        try:
            quality_report = run_quality_workflow(
                project_json=str(Path(out_dir) / f"{out_prefix}.json"),
                out_prefix=out_prefix,
                soundfont=soundfont,
                preset=quality_preset,
                presets_path=quality_presets_path,
                out_dir=out_dir,
                tools_dir=tools_dir,
                section_gain=section_gain,
            )
        except QualityWorkflowError as e:
            quality_report = e.report
            report = {
                "ok": False,
                "name": out_prefix,
                "stylepack": sp.name,
                "pack": pack.name,
                "seed_used": base_seed,
                "beatspec": beatspec_to_dict(spec),
                "attempts": [asdict(a) for a in attempts],
                "best_attempt": best_idx,
                "chosen_attempt": qualified_idx,
                "quality": quality_report,
            }
            report_path = save_report_json(Path(out_dir) / f"{out_prefix}.report.json", report)
            raise RuntimeError(f"stylepack quality workflow failed (see report: {report_path})") from e

    report = {
        "ok": qualified_idx is not None,
        "name": out_prefix,
        "stylepack": sp.name,
        "pack": pack.name,
        "seed_used": base_seed,
        "beatspec": beatspec_to_dict(spec),
        "attempts": [asdict(a) for a in attempts],
        "best_attempt": best_idx,
        "chosen_attempt": qualified_idx,
        "quality": quality_report,
    }

    report_path = save_report_json(Path(out_dir) / f"{out_prefix}.report.json", report)
    if qualified_idx is None:
        raise RuntimeError(
            "stylepack failed quality threshold: "
            f"score>={spec.score_threshold} and acceptance required (see report: {report_path})"
        )
    return report_path
