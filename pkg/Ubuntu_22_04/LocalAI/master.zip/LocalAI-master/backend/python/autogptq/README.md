# Creating a separate environment for the autogptq project

```
make autogptq
```
