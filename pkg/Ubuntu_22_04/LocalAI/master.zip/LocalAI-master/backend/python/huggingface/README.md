# Creating a separate environment for the huggingface project

```
make huggingface
```