# Creating a separate environment for the ttsvalle project

```
make ttsvalle
```