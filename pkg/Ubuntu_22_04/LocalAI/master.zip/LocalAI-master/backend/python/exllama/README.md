# Creating a separate environment for the exllama project

```
make exllama
```