# Creating a separate environment for the diffusers project

```
make diffusers
```