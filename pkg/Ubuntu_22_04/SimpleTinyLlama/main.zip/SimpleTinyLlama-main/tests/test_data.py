test_texts = [
    "",
    "foo",
    "quack",
    "Hello, World!",
    "The quick brown fox jumps over the lazy dog.",
    "SPHINX OF BLACK QUARTZ, JUDGE MY VOW!",
    "It is very rare to see hippos hiding in trees because they are very good at it.",
    "☃",
    "🤗",
    r"¯\_(ツ)_/¯",
    "⸜(｡˃ ᵕ ˂ )⸝♡"
    "𓆝 𓆟 𓆞 𓆝 𓆟",
    "H₂ + O₂ ⇌ 2H₂O",
    "读万卷书不如行万里路",
    "猿も木から落ちる",
    """
#include <stdio.h>

int main(){
    printf("Hello, World!");
    return EXIT_SUCCESS;
}
""",
    "Viele Grüße aus Köln und Düsseldorf :)",
]

