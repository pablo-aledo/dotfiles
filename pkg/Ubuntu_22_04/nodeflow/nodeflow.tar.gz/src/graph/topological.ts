import type { GraphNode, GraphEdge } from '../registry/types';

export class CycleError extends Error {
  cycle: string[];
  constructor(cycle: string[]) {
    super(`Graph contains a cycle: ${cycle.join(' → ')}`);
    this.name = 'CycleError';
    this.cycle = cycle;
  }
}

/**
 * Kahn's algorithm — returns node ids in execution order (sources first).
 * Throws CycleError if the graph is not a DAG.
 */
export function topologicalSort(
  nodes: GraphNode[],
  edges: GraphEdge[]
): string[] {
  const nodeIds = new Set(nodes.map((n) => n.id));

  // Build adjacency: source → [targets]
  const successors  = new Map<string, string[]>();
  const predecessors = new Map<string, string[]>();

  for (const id of nodeIds) {
    successors.set(id, []);
    predecessors.set(id, []);
  }

  for (const edge of edges) {
    const src = edge.source.node_id;
    const tgt = edge.target.node_id;
    if (!nodeIds.has(src) || !nodeIds.has(tgt)) continue;
    successors.get(src)!.push(tgt);
    predecessors.get(tgt)!.push(src);
  }

  // In-degree count
  const inDegree = new Map<string, number>();
  for (const id of nodeIds) {
    inDegree.set(id, predecessors.get(id)!.length);
  }

  // Start with nodes that have no predecessors
  const queue: string[] = [];
  for (const [id, deg] of inDegree) {
    if (deg === 0) queue.push(id);
  }
  queue.sort(); // deterministic order among independent nodes

  const result: string[] = [];

  while (queue.length > 0) {
    const id = queue.shift()!;
    result.push(id);

    for (const succ of successors.get(id) ?? []) {
      const newDeg = inDegree.get(succ)! - 1;
      inDegree.set(succ, newDeg);
      if (newDeg === 0) {
        queue.push(succ);
        queue.sort();
      }
    }
  }

  if (result.length !== nodeIds.size) {
    // Find the cycle for a helpful error message
    const remaining = [...nodeIds].filter((id) => !result.includes(id));
    throw new CycleError(remaining);
  }

  return result;
}

/**
 * Returns true if adding an edge from sourceNodeId → targetNodeId
 * would create a cycle. Use this before adding edges in the editor.
 */
export function wouldCreateCycle(
  nodes: GraphNode[],
  edges: GraphEdge[],
  sourceNodeId: string,
  targetNodeId: string
): boolean {
  // DFS from targetNodeId — if we can reach sourceNodeId, it's a cycle
  const successors = new Map<string, string[]>();
  for (const n of nodes) successors.set(n.id, []);
  for (const e of edges) {
    successors.get(e.source.node_id)?.push(e.target.node_id);
  }
  // Also include the hypothetical new edge
  successors.get(sourceNodeId)?.push(targetNodeId);

  const visited = new Set<string>();
  const stack   = [targetNodeId];

  while (stack.length > 0) {
    const current = stack.pop()!;
    if (current === sourceNodeId) return true;
    if (visited.has(current)) continue;
    visited.add(current);
    for (const next of successors.get(current) ?? []) {
      stack.push(next);
    }
  }

  return false;
}
