import { v4 as uuidv4 } from 'uuid';
import type {
  NodeRegistry,
  GraphEdge,
  SerializedGraph,
  SerializedNode,
} from '../registry/types';
import { topologicalSort, CycleError } from './topological';
import { validateAllEdges, validateRequiredConnections } from './typeChecker';

export interface ExportOptions {
  name: string;
  description?: string;
}

export type ExportResult =
  | { ok: true; graph: SerializedGraph }
  | { ok: false; errors: string[] };

export const EDITOR_VERSION = '0.1.0';
export const SCHEMA_VERSION = '1.0';

export function serializeGraph(
  registry: NodeRegistry,
  nodes: SerializedNode[],
  edges: GraphEdge[],
  options: ExportOptions
): ExportResult {
  const errors: string[] = [];

  // 1. Validate edge types
  const invalidEdges = validateAllEdges(registry, nodes, edges);
  for (const { edge, reason } of invalidEdges) {
    errors.push(`Edge ${edge.id}: ${reason}`);
  }

  // 2. Validate required connections
  const missingConnections = validateRequiredConnections(registry, nodes, edges);
  for (const { nodeLabel, inputLabel } of missingConnections) {
    errors.push(`"${nodeLabel}": required input "${inputLabel}" is not connected`);
  }

  // 3. Topological sort (also catches cycles)
  let executionOrder: string[];
  try {
    executionOrder = topologicalSort(nodes, edges);
  } catch (e) {
    if (e instanceof CycleError) {
      errors.push(`Graph contains a cycle: ${e.cycle.join(' → ')}`);
    } else {
      errors.push(String(e));
    }
    executionOrder = [];
  }

  if (errors.length > 0) {
    return { ok: false, errors };
  }

  // 4. Build node_schemas snapshot — only schemas actually used in this graph
  const usedSchemaIds = new Set(nodes.map((n) => n.schema_id));
  const nodeSchemas: SerializedGraph['node_schemas'] = {};

  for (const schemaId of usedSchemaIds) {
    const schema = registry.nodesBySchemaId.get(schemaId)!;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { schema_id, ...rest } = schema;
    nodeSchemas[schemaId] = rest;
  }

  // 5. Build types map (only types referenced in used schemas)
  const usedTypes = new Set<string>();
  for (const schemaId of usedSchemaIds) {
    const schema = registry.nodesBySchemaId.get(schemaId)!;
    for (const input of schema.inputs) usedTypes.add(input.type);
    for (const output of schema.outputs) usedTypes.add(output.type);
  }
  const types: SerializedGraph['types'] = {};
  for (const t of usedTypes) types[t] = {};

  // 6. Serialize nodes — keep position so the graph can be re-imported into the editor
  const serializedNodes = nodes;

  const now = new Date().toISOString();

  const graph: SerializedGraph = {
    meta: {
      id:             uuidv4(),
      name:           options.name,
      description:    options.description,
      schema_version: SCHEMA_VERSION,
      editor_version: EDITOR_VERSION,
      domain:         registry.domain,
      created_at:     now,
      exported_at:    now,
    },
    types,
    node_schemas:    nodeSchemas,
    nodes:           serializedNodes,
    edges,
    execution_order: executionOrder,
  };

  return { ok: true, graph };
}
