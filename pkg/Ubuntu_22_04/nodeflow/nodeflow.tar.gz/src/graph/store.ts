import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import {
  applyNodeChanges,
  applyEdgeChanges,
  type Node,
  type Edge,
  type NodeChange,
  type EdgeChange,
  type Connection,
} from 'reactflow';
import type {
  NodeRegistry,
  GraphNode,
  GraphEdge,
  InputValue,
  SerializedGraph,
} from '../registry/types';
import { checkEdgeCompatibility } from '../graph/typeChecker';
import { wouldCreateCycle } from '../graph/topological';
import { serializeGraph, type ExportOptions } from '../graph/toJson';

export type RFNodeData = GraphNode;

function makeRFEdge(edge: GraphEdge): Edge {
  return {
    id: edge.id,
    source: edge.source.node_id,
    sourceHandle: edge.source.output_id,
    target: edge.target.node_id,
    targetHandle: edge.target.input_id,
    type: 'default',
    style: { stroke: 'var(--edge-color)', strokeWidth: 2 },
    data: edge,
  };
}

function extractGraphEdge(rfEdge: Edge): GraphEdge {
  return rfEdge.data as GraphEdge;
}

interface GraphStore {
  registry: NodeRegistry | null;
  setRegistry: (r: NodeRegistry) => void;

  rfNodes: Node<RFNodeData>[];
  rfEdges: Edge[];

  selectedNodeId: string | null;
  setSelectedNodeId: (id: string | null) => void;

  // Toast callback — set by EditorCanvas, called by store on rejected connections
  _toastFn: ((msg: string) => void) | null;
  setToastFn: (fn: ((msg: string) => void) | null) => void;

  onNodesChange: (changes: NodeChange[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (connection: Connection) => void;

  addNode: (schemaId: string, position: { x: number; y: number }) => void;
  updateInputValue: (nodeId: string, inputId: string, value: InputValue) => void;
  updateNodeLabel: (nodeId: string, label: string) => void;
  deleteNode: (nodeId: string) => void;
  deleteEdge: (edgeId: string) => void;
  clearGraph: () => void;

  // Import a previously exported SerializedGraph
  importGraph: (graph: SerializedGraph) => void;

  getGraphNodes: () => GraphNode[];
  getGraphEdges: () => GraphEdge[];
  exportGraph: (options: ExportOptions) => ReturnType<typeof serializeGraph>;
}

export const useGraphStore = create<GraphStore>((set, get) => ({
  registry: null,
  setRegistry: (registry) => set({ registry }),

  rfNodes: [],
  rfEdges: [],
  selectedNodeId: null,
  setSelectedNodeId: (id) => set({ selectedNodeId: id }),

  _toastFn: null,
  setToastFn: (fn) => set({ _toastFn: fn }),

  onNodesChange: (changes) =>
    set((s) => ({ rfNodes: applyNodeChanges(changes, s.rfNodes) })),

  onEdgesChange: (changes) =>
    set((s) => ({ rfEdges: applyEdgeChanges(changes, s.rfEdges) })),

  onConnect: (connection) => {
    const { registry, rfNodes, rfEdges, _toastFn } = get();
    if (!registry || !connection.source || !connection.target ||
        !connection.sourceHandle || !connection.targetHandle) return;

    const graphNodes = rfNodes.map((n) => n.data as GraphNode);
    const graphEdges = rfEdges.map(extractGraphEdge);

    // 1. Type check
    const compat = checkEdgeCompatibility(
      registry, graphNodes,
      connection.source, connection.sourceHandle,
      connection.target, connection.targetHandle,
    );
    if (!compat.valid) {
      _toastFn?.(compat.reason ?? 'Conexión incompatible');
      return;
    }

    // 2. Cycle check
    if (wouldCreateCycle(graphNodes, graphEdges, connection.source, connection.target)) {
      _toastFn?.('La conexión crearía un ciclo');
      return;
    }

    // 3. Replace existing connection to same target input
    const filtered = rfEdges.filter(
      (e) => !(e.target === connection.target && e.targetHandle === connection.targetHandle)
    );

    const edge: GraphEdge = {
      id: `edge_${uuidv4().slice(0, 8)}`,
      source: { node_id: connection.source, output_id: connection.sourceHandle },
      target: { node_id: connection.target, input_id: connection.targetHandle },
    };

    set({ rfEdges: [...filtered, makeRFEdge(edge)] });
  },

  addNode: (schemaId, position) => {
    const { registry } = get();
    if (!registry) return;
    const schema = registry.nodesBySchemaId.get(schemaId);
    if (!schema) return;

    const input_values: Record<string, InputValue> = {};
    for (const input of schema.inputs) {
      if (input.kind !== 'handle') {
        input_values[input.id] = (input as { default: InputValue }).default;
      }
    }

    const graphNode: GraphNode = {
      id: `node_${uuidv4().slice(0, 8)}`,
      schema_id: schemaId,
      label: schema.label,
      position,
      input_values,
    };

    set((s) => ({
      rfNodes: [...s.rfNodes, {
        id: graphNode.id,
        type: 'genericNode',
        position,
        data: graphNode,
      }],
    }));
  },

  updateInputValue: (nodeId, inputId, value) =>
    set((s) => ({
      rfNodes: s.rfNodes.map((n) => {
        if (n.id !== nodeId) return n;
        return { ...n, data: { ...n.data, input_values: { ...n.data.input_values, [inputId]: value } } };
      }),
    })),

  updateNodeLabel: (nodeId, label) =>
    set((s) => ({
      rfNodes: s.rfNodes.map((n) =>
        n.id !== nodeId ? n : { ...n, data: { ...n.data, label } }
      ),
    })),

  deleteNode: (nodeId) =>
    set((s) => ({
      rfNodes: s.rfNodes.filter((n) => n.id !== nodeId),
      rfEdges: s.rfEdges.filter((e) => e.source !== nodeId && e.target !== nodeId),
      selectedNodeId: s.selectedNodeId === nodeId ? null : s.selectedNodeId,
    })),

  deleteEdge: (edgeId) =>
    set((s) => ({ rfEdges: s.rfEdges.filter((e) => e.id !== edgeId) })),

  clearGraph: () => set({ rfNodes: [], rfEdges: [], selectedNodeId: null }),

  importGraph: (graph) => {
    const { registry } = get();
    if (!registry) return;

    // Rebuild rfNodes from graph.nodes — positions come from the serialized graph
    // (position is present because we keep it during session; if absent, spread out)
    const rfNodes: Node<RFNodeData>[] = graph.nodes.map((node, i) => {
      const position = (node as GraphNode).position ?? {
        x: 120 + (i % 4) * 280,
        y: 100 + Math.floor(i / 4) * 200,
      };
      const graphNode: GraphNode = { ...node, position };
      return { id: node.id, type: 'genericNode', position, data: graphNode };
    });

    const rfEdges: Edge[] = graph.edges.map(makeRFEdge);

    set({ rfNodes, rfEdges, selectedNodeId: null });
  },

  getGraphNodes: () => get().rfNodes.map((n) => n.data as GraphNode),
  getGraphEdges: () => get().rfEdges.map(extractGraphEdge),

  exportGraph: (options) => {
    const { registry, getGraphNodes, getGraphEdges } = get();
    if (!registry) throw new Error('Registry not loaded');
    return serializeGraph(registry, getGraphNodes(), getGraphEdges(), options);
  },
}));
