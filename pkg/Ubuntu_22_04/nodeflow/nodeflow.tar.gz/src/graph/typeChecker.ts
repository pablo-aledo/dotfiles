import type { NodeRegistry, GraphNode, GraphEdge } from '../registry/types';

export interface TypeCheckResult {
  valid: boolean;
  reason?: string;
}

/**
 * Check whether a proposed connection is type-compatible.
 * "any" on either side bypasses the check.
 */
export function checkEdgeCompatibility(
  registry: NodeRegistry,
  nodes: GraphNode[],
  sourceNodeId: string,
  sourceOutputId: string,
  targetNodeId: string,
  targetInputId: string
): TypeCheckResult {
  const nodesById = new Map(nodes.map((n) => [n.id, n]));

  const sourceNode = nodesById.get(sourceNodeId);
  const targetNode = nodesById.get(targetNodeId);

  if (!sourceNode) return { valid: false, reason: `Source node "${sourceNodeId}" not found` };
  if (!targetNode) return { valid: false, reason: `Target node "${targetNodeId}" not found` };

  const sourceSchema = registry.nodesBySchemaId.get(sourceNode.schema_id);
  const targetSchema = registry.nodesBySchemaId.get(targetNode.schema_id);

  if (!sourceSchema) return { valid: false, reason: `Schema "${sourceNode.schema_id}" not found` };
  if (!targetSchema) return { valid: false, reason: `Schema "${targetNode.schema_id}" not found` };

  const output = sourceSchema.outputs.find((o) => o.id === sourceOutputId);
  const input  = targetSchema.inputs.find((i) => i.id === targetInputId);

  if (!output) return { valid: false, reason: `Output "${sourceOutputId}" not found on "${sourceNode.schema_id}"` };
  if (!input)  return { valid: false, reason: `Input "${targetInputId}" not found on "${targetNode.schema_id}"` };

  if (input.kind !== 'handle') {
    return { valid: false, reason: `Input "${targetInputId}" is not connectable (kind: ${input.kind})` };
  }

  // "any" bypasses type check on either side
  if (output.type === 'any' || input.type === 'any') {
    return { valid: true };
  }

  if (output.type !== input.type) {
    return {
      valid: false,
      reason: `Type mismatch: "${output.type}" → "${input.type}"`,
    };
  }

  return { valid: true };
}

/**
 * Validate all edges in a graph, returning a list of invalid ones.
 */
export function validateAllEdges(
  registry: NodeRegistry,
  nodes: GraphNode[],
  edges: GraphEdge[]
): Array<{ edge: GraphEdge; reason: string }> {
  const invalid: Array<{ edge: GraphEdge; reason: string }> = [];

  for (const edge of edges) {
    const result = checkEdgeCompatibility(
      registry,
      nodes,
      edge.source.node_id,
      edge.source.output_id,
      edge.target.node_id,
      edge.target.input_id
    );
    if (!result.valid) {
      invalid.push({ edge, reason: result.reason! });
    }
  }

  return invalid;
}

/**
 * Check that all required handle inputs on every node are connected.
 * Returns list of unconnected required inputs.
 */
export function validateRequiredConnections(
  registry: NodeRegistry,
  nodes: GraphNode[],
  edges: GraphEdge[]
): Array<{ nodeId: string; nodeLabel: string; inputId: string; inputLabel: string }> {
  const missing: Array<{
    nodeId: string;
    nodeLabel: string;
    inputId: string;
    inputLabel: string;
  }> = [];

  const connectedTargets = new Set(
    edges.map((e) => `${e.target.node_id}::${e.target.input_id}`)
  );

  for (const node of nodes) {
    const schema = registry.nodesBySchemaId.get(node.schema_id);
    if (!schema) continue;

    for (const input of schema.inputs) {
      if (input.kind === 'handle' && input.required) {
        const key = `${node.id}::${input.id}`;
        if (!connectedTargets.has(key)) {
          missing.push({
            nodeId:     node.id,
            nodeLabel:  node.label,
            inputId:    input.id,
            inputLabel: input.label,
          });
        }
      }
    }
  }

  return missing;
}
