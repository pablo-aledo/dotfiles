import { useEffect, useCallback, useRef, useState } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useReactFlow,
  ReactFlowProvider,
  type NodeTypes,
} from 'reactflow';
import 'reactflow/dist/style.css';

import { useGraphStore } from './graph/store';
import { loadRegistry } from './registry/loader';
import { GenericNode } from './components/GenericNode';
import { NodePalette } from './components/NodePalette';
import { Inspector } from './components/Inspector';
import { Toolbar } from './components/Toolbar';

const nodeTypes: NodeTypes = { genericNode: GenericNode };

// ── Inner component — has access to useReactFlow() ───────────────────────────
function EditorCanvas() {
  const { screenToFlowPosition } = useReactFlow();

  const rfNodes           = useGraphStore((s) => s.rfNodes);
  const rfEdges           = useGraphStore((s) => s.rfEdges);
  const onNodesChange     = useGraphStore((s) => s.onNodesChange);
  const onEdgesChange     = useGraphStore((s) => s.onEdgesChange);
  const onConnect         = useGraphStore((s) => s.onConnect);
  const addNode           = useGraphStore((s) => s.addNode);
  const setSelectedNodeId = useGraphStore((s) => s.setSelectedNodeId);

  // ── Connection rejection toast ─────────────────────────────────────────────
  const [toast, setToast]   = useState<string | null>(null);
  const toastTimer           = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  // Expose showToast to the store
  useEffect(() => {
    useGraphStore.getState().setToastFn(showToast);
    return () => useGraphStore.getState().setToastFn(null);
  }, [showToast]);

  // ── Drag-drop with correct viewport position ───────────────────────────────
  const onDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      const schemaId = e.dataTransfer.getData('application/nodeflow-schema');
      if (!schemaId) return;
      // screenToFlowPosition accounts for zoom + pan
      const position = screenToFlowPosition({ x: e.clientX, y: e.clientY });
      addNode(schemaId, position);
    },
    [addNode, screenToFlowPosition]
  );

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  }, []);

  const onPaneClick = useCallback(() => setSelectedNodeId(null), [setSelectedNodeId]);

  return (
    <div style={{ flex: 1, position: 'relative' }} onDrop={onDrop} onDragOver={onDragOver}>
      <ReactFlow
        nodes={rfNodes}
        edges={rfEdges}
        nodeTypes={nodeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onPaneClick={onPaneClick}
        fitView
        minZoom={0.25}
        maxZoom={2.5}
        deleteKeyCode="Delete"
        defaultEdgeOptions={{
          type: 'default',
          style: { stroke: 'var(--edge-color)', strokeWidth: 2 },
        }}
      >
        <Background color="var(--grid-color)" gap={20} size={1} />
        <Controls style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)' }} />
        <MiniMap
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)' }}
          nodeColor={miniMapColor}
        />
      </ReactFlow>

      {/* Empty state */}
      {rfNodes.length === 0 && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', pointerEvents: 'none', gap: 8,
        }}>
          <div style={{ fontSize: 36, opacity: 0.1 }}>⬡</div>
          <div style={{ fontSize: 13, color: 'var(--text-muted)', opacity: 0.5 }}>
            Arrastra nodos desde el panel izquierdo
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', opacity: 0.3 }}>
            o haz clic en cualquier nodo de la paleta
          </div>
        </div>
      )}

      {/* Connection rejection toast */}
      {toast && (
        <div style={{
          position: 'absolute', bottom: 24, left: '50%',
          transform: 'translateX(-50%)',
          background: '#1c2128', border: '1px solid var(--danger)',
          borderRadius: 6, padding: '8px 16px',
          fontSize: 12, color: 'var(--danger)',
          pointerEvents: 'none', zIndex: 9999,
          animation: 'fadeIn 0.15s ease',
          whiteSpace: 'nowrap',
          boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
        }}>
          ✕ {toast}
        </div>
      )}

      <style>{`@keyframes fadeIn { from { opacity:0; transform:translateX(-50%) translateY(6px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }`}</style>
    </div>
  );
}

// MiniMap color helper defined outside component to avoid re-creation
function miniMapColor(n: { data?: unknown }) {
  const registry = useGraphStore.getState().registry;
  const data = n.data as { schema_id?: string } | undefined;
  if (!data?.schema_id || !registry) return '#333';
  const schema = registry.nodesBySchemaId.get(data.schema_id);
  const cat    = schema ? registry.categoriesByCategoryId.get(schema.category) : undefined;
  return cat?.color ?? '#444';
}

// ── Root component — provides ReactFlowProvider ───────────────────────────────
export default function App() {
  const setRegistry = useGraphStore((s) => s.setRegistry);
  const registry    = useGraphStore((s) => s.registry);

  useEffect(() => {
    loadRegistry().then(setRegistry).catch(console.error);
  }, [setRegistry]);

  if (!registry) {
    return (
      <div style={{
        width: '100vw', height: '100vh', background: 'var(--canvas-bg)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <span style={{ fontSize: 14, color: 'var(--text-muted)' }}>Cargando registry…</span>
      </div>
    );
  }

  return (
    <ReactFlowProvider>
      <div style={{
        width: '100vw', height: '100vh', display: 'flex', flexDirection: 'column',
        background: 'var(--canvas-bg)', fontFamily: 'var(--font)',
      }}>
        <Toolbar />
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          <NodePalette />
          <EditorCanvas />
          <Inspector />
        </div>
      </div>
    </ReactFlowProvider>
  );
}
