import type {
  NodeRegistry,
  NodeSchema,
  InputDescriptor,
  OutputDescriptor,
  DropdownOption,
  Category,
} from './types';

// ─── Raw YAML shapes (before normalization) ───────────────────────────────────
// These mirror what js-yaml parses, so they're looser than our final types.

interface RawOption {
  value: string | number;
  label: string;
}

interface RawInput {
  id: string;
  label: string;
  type: string;
  kind: string;
  required?: boolean;
  description?: string;
  default?: unknown;
  placeholder?: string;
  multiline?: boolean;
  min_length?: number;
  max_length?: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  options?: Array<string | RawOption>;
  extensions?: string[];
}

interface RawOutput {
  id: string;
  label: string;
  type: string;
  description?: string;
}

interface RawNode {
  schema_id: string;
  label: string;
  category: string;
  description?: string;
  icon?: string;
  inputs?: RawInput[];
  outputs?: RawOutput[];
  metadata?: Record<string, unknown>;
}

interface RawType {
  id: string;
}

interface RawCategory {
  id: string;
  label: string;
  color?: string;
}

interface RawRegistry {
  version: string;
  domain: string;
  display_name?: string;
  types?: RawType[];
  categories?: RawCategory[];
  nodes?: RawNode[];
}

// ─── Normalization helpers ────────────────────────────────────────────────────

function normalizeOptions(raw: Array<string | RawOption>): DropdownOption[] {
  return raw.map((o) =>
    typeof o === 'string' ? { value: o, label: o } : o
  );
}

function normalizeInput(raw: RawInput): InputDescriptor {
  const base = {
    id: raw.id,
    label: raw.label,
    type: raw.type,
    kind: raw.kind as InputDescriptor['kind'],
    required: raw.required ?? (raw.kind !== 'handle' ? true : false),
    description: raw.description,
  };

  switch (raw.kind) {
    case 'handle':
      return { ...base, kind: 'handle' };

    case 'text':
      return {
        ...base,
        kind: 'text',
        default: (raw.default as string) ?? '',
        placeholder: raw.placeholder,
        multiline: raw.multiline,
        min_length: raw.min_length,
        max_length: raw.max_length,
      };

    case 'number':
      return {
        ...base,
        kind: 'number',
        default: (raw.default as number) ?? 0,
        min: raw.min,
        max: raw.max,
        step: raw.step ?? 1,
        unit: raw.unit,
      };

    case 'slider':
      return {
        ...base,
        kind: 'slider',
        default: (raw.default as number) ?? 0,
        min: raw.min ?? 0,
        max: raw.max ?? 1,
        step: raw.step ?? 0.01,
        unit: raw.unit,
      };

    case 'dropdown': {
      const options = normalizeOptions(
        (raw.options as Array<string | RawOption>) ?? []
      );
      return {
        ...base,
        kind: 'dropdown',
        default: (raw.default as string | number) ?? options[0]?.value ?? '',
        options,
      };
    }

    case 'toggle':
      return {
        ...base,
        kind: 'toggle',
        default: (raw.default as boolean) ?? false,
      };

    case 'color':
      return {
        ...base,
        kind: 'color',
        default: (raw.default as string) ?? '#ffffff',
      };

    case 'file':
      return {
        ...base,
        kind: 'file',
        default: raw.default as string | undefined,
        extensions: raw.extensions,
      };

    default:
      throw new Error(
        `Unknown input kind "${raw.kind}" on input "${raw.id}"`
      );
  }
}

function normalizeOutput(raw: RawOutput): OutputDescriptor {
  return {
    id: raw.id,
    label: raw.label,
    type: raw.type,
    description: raw.description,
  };
}

function normalizeNode(raw: RawNode): NodeSchema {
  return {
    schema_id: raw.schema_id,
    label: raw.label,
    category: raw.category,
    description: raw.description,
    icon: raw.icon,
    inputs: (raw.inputs ?? []).map(normalizeInput),
    outputs: (raw.outputs ?? []).map(normalizeOutput),
    metadata: raw.metadata ?? {},
  };
}

// ─── Validation ───────────────────────────────────────────────────────────────

function validateRegistry(_raw: RawRegistry, nodes: NodeSchema[], categories: Category[], types: string[]): void {
  const errors: string[] = [];
  const categoryIds = new Set(categories.map((c) => c.id));
  const typeIds = new Set(types);

  for (const node of nodes) {
    if (!categoryIds.has(node.category)) {
      errors.push(
        `Node "${node.schema_id}": unknown category "${node.category}"`
      );
    }

    for (const input of node.inputs) {
      if (input.kind === 'handle' && !typeIds.has(input.type) && input.type !== 'any') {
        errors.push(
          `Node "${node.schema_id}", input "${input.id}": unknown type "${input.type}"`
        );
      }
    }

    for (const output of node.outputs) {
      if (!typeIds.has(output.type) && output.type !== 'any') {
        errors.push(
          `Node "${node.schema_id}", output "${output.id}": unknown type "${output.type}"`
        );
      }
    }

    const inputIds = node.inputs.map((i) => i.id);
    const dupeInputs = inputIds.filter((id, i) => inputIds.indexOf(id) !== i);
    if (dupeInputs.length > 0) {
      errors.push(`Node "${node.schema_id}": duplicate input ids: ${dupeInputs.join(', ')}`);
    }

    const outputIds = node.outputs.map((o) => o.id);
    const dupeOutputs = outputIds.filter((id, i) => outputIds.indexOf(id) !== i);
    if (dupeOutputs.length > 0) {
      errors.push(`Node "${node.schema_id}": duplicate output ids: ${dupeOutputs.join(', ')}`);
    }
  }

  const schemaIds = nodes.map((n) => n.schema_id);
  const dupeSchemas = schemaIds.filter((id, i) => schemaIds.indexOf(id) !== i);
  if (dupeSchemas.length > 0) {
    errors.push(`Duplicate schema_ids: ${dupeSchemas.join(', ')}`);
  }

  if (errors.length > 0) {
    throw new Error(`Registry validation failed:\n${errors.map(e => `  • ${e}`).join('\n')}`);
  }
}

// ─── Public loader ────────────────────────────────────────────────────────────

/**
 * Parse a raw object (from js-yaml) into a validated NodeRegistry.
 * Throws with a descriptive message if the YAML is invalid.
 */
export function parseRegistry(raw: unknown): NodeRegistry {
  const r = raw as RawRegistry;

  if (!r.version) throw new Error('Registry missing "version" field');
  if (!r.domain)  throw new Error('Registry missing "domain" field');

  const types   = (r.types   ?? []).map((t) => t.id);
  const categories: Category[] = (r.categories ?? []).map((c) => ({
    id:    c.id,
    label: c.label,
    color: c.color,
  }));
  const nodes   = (r.nodes   ?? []).map(normalizeNode);

  validateRegistry(r, nodes, categories, types);

  const nodesBySchemaId       = new Map(nodes.map((n) => [n.schema_id, n]));
  const categoriesByCategoryId = new Map(categories.map((c) => [c.id, c]));

  return {
    version:      r.version,
    domain:       r.domain,
    display_name: r.display_name ?? r.domain,
    types,
    categories,
    nodes,
    nodesBySchemaId,
    categoriesByCategoryId,
  };
}

/**
 * Load and parse the registry YAML from /registry.yaml (Vite public dir).
 * Call this once at app startup.
 */
export async function loadRegistry(): Promise<NodeRegistry> {
  const [yamlModule, response] = await Promise.all([
    import('js-yaml'),
    fetch('/registry.yaml'),
  ]);

  if (!response.ok) {
    throw new Error(
      `Failed to load registry.yaml: ${response.status} ${response.statusText}`
    );
  }

  const text = await response.text();
  const raw  = yamlModule.load(text);
  return parseRegistry(raw);
}
