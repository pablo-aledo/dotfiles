// ─── Input kinds ─────────────────────────────────────────────────────────────

export type InputKind =
  | 'handle'     // pure connection, no UI control
  | 'text'       // string input, optional multiline
  | 'number'     // numeric input with min/max/step
  | 'slider'     // same as number but rendered as a slider
  | 'dropdown'   // fixed set of options
  | 'toggle'     // boolean
  | 'color'      // hex color picker
  | 'file';      // file path

// ─── Input descriptors ────────────────────────────────────────────────────────

interface InputBase {
  id: string;
  label: string;
  type: string;        // data type string e.g. "chord_list", "number"
  kind: InputKind;
  required: boolean;   // defaults to true
  description?: string;
}

export interface HandleInput extends InputBase {
  kind: 'handle';
}

export interface TextInput extends InputBase {
  kind: 'text';
  default: string;
  placeholder?: string;
  multiline?: boolean;
  min_length?: number;
  max_length?: number;
}

export interface NumberInput extends InputBase {
  kind: 'number';
  default: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
}

export interface SliderInput extends InputBase {
  kind: 'slider';
  default: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
}

export interface DropdownOption {
  value: string | number;
  label: string;
}

export interface DropdownInput extends InputBase {
  kind: 'dropdown';
  default: string | number;
  options: DropdownOption[];  // normalized from string[] | DropdownOption[]
}

export interface ToggleInput extends InputBase {
  kind: 'toggle';
  default: boolean;
}

export interface ColorInput extends InputBase {
  kind: 'color';
  default: string;  // hex
}

export interface FileInput extends InputBase {
  kind: 'file';
  default?: string;
  extensions?: string[];  // e.g. [".mid", ".wav"]
}

export type InputDescriptor =
  | HandleInput
  | TextInput
  | NumberInput
  | SliderInput
  | DropdownInput
  | ToggleInput
  | ColorInput
  | FileInput;

// ─── Output descriptor ────────────────────────────────────────────────────────

export interface OutputDescriptor {
  id: string;
  label: string;
  type: string;
  description?: string;
}

// ─── Node schema ──────────────────────────────────────────────────────────────

export interface NodeSchema {
  schema_id: string;
  label: string;
  category: string;
  description?: string;
  icon?: string;
  inputs: InputDescriptor[];
  outputs: OutputDescriptor[];
  metadata: Record<string, unknown>;  // free dict, passed through to JSON output
}

// ─── Category ─────────────────────────────────────────────────────────────────

export interface Category {
  id: string;
  label: string;
  color?: string;
}

// ─── Registry (parsed from YAML) ─────────────────────────────────────────────

export interface NodeRegistry {
  version: string;
  domain: string;
  display_name: string;
  types: string[];          // list of valid type ids
  categories: Category[];
  nodes: NodeSchema[];
  nodesBySchemaId: Map<string, NodeSchema>;
  categoriesByCategoryId: Map<string, Category>;
}

// ─── Input values (what the user sets in the inspector) ───────────────────────
// Only control inputs (not handles) have values here.

export type InputValue = string | number | boolean | null;
export type InputValues = Record<string, InputValue>;  // input_id → value

// ─── Graph types (runtime, in the editor) ─────────────────────────────────────

export interface GraphNode {
  id: string;
  schema_id: string;
  label: string;
  position: { x: number; y: number };
  input_values: InputValues;
}

export interface EdgeEndpoint {
  node_id: string;
  output_id?: string;  // set on source
  input_id?: string;   // set on target
}

export interface GraphEdge {
  id: string;
  source: { node_id: string; output_id: string };
  target: { node_id: string; input_id: string };
}

// ─── Serialized JSON output ───────────────────────────────────────────────────

export interface GraphMeta {
  id: string;
  name: string;
  description?: string;
  schema_version: string;
  editor_version: string;
  domain: string;
  created_at: string;
  exported_at: string;
}

export interface SerializedGraph {
  meta: GraphMeta;
  types: Record<string, Record<string, never>>;
  node_schemas: Record<string, Omit<NodeSchema, 'schema_id'>>;
  nodes: GraphNode[];   // position included — lets the editor re-import layout
  edges: GraphEdge[];
  execution_order: string[];
}
