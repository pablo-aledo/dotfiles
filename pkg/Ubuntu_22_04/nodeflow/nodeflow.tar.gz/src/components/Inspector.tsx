import { useGraphStore } from '../graph/store';
import { InputControl } from './controls/InputControl';

export function Inspector() {
  const registry      = useGraphStore((s) => s.registry);
  const selectedId    = useGraphStore((s) => s.selectedNodeId);
  const rfNodes       = useGraphStore((s) => s.rfNodes);
  const updateInput   = useGraphStore((s) => s.updateInputValue);
  const updateLabel   = useGraphStore((s) => s.updateNodeLabel);
  const deleteNode    = useGraphStore((s) => s.deleteNode);
  const setSelectedId = useGraphStore((s) => s.setSelectedNodeId);

  if (!registry || !selectedId) {
    return (
      <div style={{
        width: 240,
        flexShrink: 0,
        background: 'var(--panel-bg)',
        borderLeft: '1px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      }}>
        <span style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
          Selecciona un nodo para editarlo
        </span>
      </div>
    );
  }

  const rfNode = rfNodes.find((n) => n.id === selectedId);
  if (!rfNode) return null;

  const data   = rfNode.data;
  const schema = registry.nodesBySchemaId.get(data.schema_id);
  if (!schema) return null;

  const category    = registry.categoriesByCategoryId.get(schema.category);
  const accentColor = category?.color ?? '#7F77DD';

  const handleInputs  = schema.inputs.filter((i) => i.kind === 'handle');
  const controlInputs = schema.inputs.filter((i) => i.kind !== 'handle');

  return (
    <div style={{
      width: 240,
      flexShrink: 0,
      background: 'var(--panel-bg)',
      borderLeft: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        padding: '10px 12px',
        borderBottom: '1px solid var(--border)',
        background: accentColor + '11',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: accentColor }} />
            <span style={{ fontSize: 10, color: accentColor, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
              {category?.label ?? schema.category}
            </span>
          </div>
          <button
            onClick={() => setSelectedId(null)}
            style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 14, lineHeight: 1, padding: 2 }}
            title="Cerrar"
          >
            ×
          </button>
        </div>

        {/* Editable label */}
        <input
          type="text"
          value={data.label}
          onChange={(e) => updateLabel(data.id, e.target.value)}
          style={{
            width: '100%',
            background: 'transparent',
            border: 'none',
            borderBottom: '1px solid var(--ctrl-border)',
            color: 'var(--text-primary)',
            fontSize: 13,
            fontWeight: 600,
            padding: '2px 0',
            outline: 'none',
            boxSizing: 'border-box',
          }}
        />
        <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 3, fontFamily: 'monospace' }}>
          {data.schema_id}
        </div>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 14 }}>

        {/* Description */}
        {schema.description && (
          <p style={{ fontSize: 11, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
            {schema.description}
          </p>
        )}

        {/* Handle inputs (read-only, show connection info) */}
        {handleInputs.length > 0 && (
          <section>
            <SectionLabel>Entradas de conexión</SectionLabel>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {handleInputs.map((input) => (
                <div key={input.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{input.label}</span>
                  <span style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'monospace' }}>
                    {input.type} {!input.required && '?'}
                  </span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Control inputs */}
        {controlInputs.length > 0 && (
          <section>
            <SectionLabel>Parámetros</SectionLabel>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {controlInputs.map((input) => (
                <div key={input.id}>
                  <label style={{ fontSize: 11, color: 'var(--text-secondary)', fontWeight: 500, display: 'block', marginBottom: 4 }}>
                    {input.label}
                    {!input.required && <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}> (opcional)</span>}
                  </label>
                  {input.description && (
                    <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '0 0 4px', lineHeight: 1.4 }}>
                      {input.description}
                    </p>
                  )}
                  <InputControl
                    input={input}
                    value={data.input_values[input.id] ?? null}
                    onChange={(v) => updateInput(data.id, input.id, v)}
                  />
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Outputs */}
        {schema.outputs.length > 0 && (
          <section>
            <SectionLabel>Salidas</SectionLabel>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {schema.outputs.map((output) => (
                <div key={output.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{output.label}</span>
                  <span style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'monospace' }}>{output.type}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Metadata */}
        {Object.keys(schema.metadata).length > 0 && (
          <section>
            <SectionLabel>Metadata</SectionLabel>
            <pre style={{
              fontSize: 10,
              color: 'var(--text-muted)',
              background: 'var(--ctrl-bg)',
              border: '1px solid var(--ctrl-border)',
              borderRadius: 4,
              padding: '6px 8px',
              margin: 0,
              overflow: 'auto',
              lineHeight: 1.5,
            }}>
              {JSON.stringify(schema.metadata, null, 2)}
            </pre>
          </section>
        )}
      </div>

      {/* Footer actions */}
      <div style={{ padding: '8px 12px', borderTop: '1px solid var(--border)', display: 'flex', gap: 6 }}>
        <button
          onClick={() => {
            deleteNode(selectedId);
          }}
          style={{
            flex: 1,
            padding: '5px 0',
            background: 'transparent',
            border: '1px solid var(--danger)',
            borderRadius: 5,
            color: 'var(--danger)',
            fontSize: 11,
            cursor: 'pointer',
            fontWeight: 500,
          }}
        >
          Eliminar nodo
        </button>
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: 10,
      fontWeight: 700,
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '0.07em',
      marginBottom: 6,
    }}>
      {children}
    </div>
  );
}
