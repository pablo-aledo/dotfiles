import { useState } from 'react';
import { useGraphStore } from '../graph/store';

export function NodePalette() {
  const registry = useGraphStore((s) => s.registry);
  const addNode  = useGraphStore((s) => s.addNode);
  const [search, setSearch] = useState('');
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  if (!registry) return null;

  const query = search.toLowerCase().trim();
  const filtered = registry.nodes.filter(
    (n) =>
      !query ||
      n.label.toLowerCase().includes(query) ||
      n.schema_id.toLowerCase().includes(query) ||
      (n.description ?? '').toLowerCase().includes(query)
  );

  // Group by category, preserving category order from registry
  const groups = registry.categories
    .map((cat) => ({
      category: cat,
      nodes: filtered.filter((n) => n.category === cat.id),
    }))
    .filter((g) => g.nodes.length > 0);

  function handleDragStart(e: React.DragEvent, schemaId: string) {
    e.dataTransfer.setData('application/nodeflow-schema', schemaId);
    e.dataTransfer.effectAllowed = 'copy';
  }

  function handleClick(schemaId: string) {
    // Add at a sensible default position when not dragging
    addNode(schemaId, { x: 200 + Math.random() * 300, y: 100 + Math.random() * 200 });
  }

  function toggleCategory(id: string) {
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  return (
    <div
      style={{
        width: 220,
        flexShrink: 0,
        background: 'var(--panel-bg)',
        borderRight: '1px solid var(--border)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div style={{ padding: '12px 12px 8px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>
          {registry.display_name}
        </div>
        <input
          type="text"
          placeholder="Buscar nodos…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            width: '100%',
            background: 'var(--ctrl-bg)',
            border: '1px solid var(--ctrl-border)',
            borderRadius: 5,
            color: 'var(--text-primary)',
            fontSize: 12,
            padding: '5px 8px',
            boxSizing: 'border-box',
            outline: 'none',
          }}
        />
      </div>

      {/* Node list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
        {groups.length === 0 && (
          <div style={{ padding: '16px 12px', fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
            Sin resultados
          </div>
        )}
        {groups.map(({ category, nodes }) => {
          const isCollapsed = collapsed.has(category.id);
          return (
            <div key={category.id}>
              {/* Category header */}
              <div
                onClick={() => toggleCategory(category.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '5px 10px',
                  cursor: 'pointer',
                  userSelect: 'none',
                }}
              >
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: category.color ?? '#888', flexShrink: 0 }} />
                <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', flex: 1 }}>
                  {category.label}
                </span>
                <span style={{ fontSize: 10, color: 'var(--text-muted)', transform: isCollapsed ? 'rotate(-90deg)' : 'none', transition: 'transform 0.15s' }}>
                  ▾
                </span>
              </div>

              {/* Nodes in category */}
              {!isCollapsed && nodes.map((node) => (
                <div
                  key={node.schema_id}
                  draggable
                  onClick={() => handleClick(node.schema_id)}
                  onDragStart={(e) => handleDragStart(e, node.schema_id)}
                  title={node.description}
                  style={{
                    margin: '2px 8px',
                    padding: '6px 8px',
                    borderRadius: 5,
                    cursor: 'grab',
                    border: '1px solid transparent',
                    transition: 'background 0.1s, border-color 0.1s',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLDivElement).style.background = 'var(--node-hover-bg)';
                    (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--ctrl-border)';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLDivElement).style.background = 'transparent';
                    (e.currentTarget as HTMLDivElement).style.borderColor = 'transparent';
                  }}
                >
                  <div style={{ fontSize: 12, color: 'var(--text-primary)', fontWeight: 500 }}>
                    {node.label}
                  </div>
                  {node.description && (
                    <div style={{
                      fontSize: 10,
                      color: 'var(--text-muted)',
                      marginTop: 2,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}>
                      {node.description}
                    </div>
                  )}
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {/* Footer hint */}
      <div style={{ padding: '8px 12px', borderTop: '1px solid var(--border)', fontSize: 10, color: 'var(--text-muted)', textAlign: 'center' }}>
        clic o arrastra al canvas
      </div>
    </div>
  );
}
