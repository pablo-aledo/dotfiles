import type { InputDescriptor, InputValue } from '../../registry/types';

interface Props {
  input: InputDescriptor;
  value: InputValue;
  onChange: (value: InputValue) => void;
  disabled?: boolean;
}

export function InputControl({ input, value, onChange, disabled }: Props) {
  if (input.kind === 'handle') return null;

  const base: React.CSSProperties = {
    width: '100%',
    background: 'var(--ctrl-bg)',
    border: '1px solid var(--ctrl-border)',
    borderRadius: 4,
    color: 'var(--text-primary)',
    fontSize: 11,
    padding: '3px 6px',
    boxSizing: 'border-box',
    outline: 'none',
  };

  switch (input.kind) {
    case 'text':
      return input.multiline ? (
        <textarea
          style={{ ...base, resize: 'vertical', minHeight: 56, fontFamily: 'inherit' }}
          value={(value as string) ?? input.default}
          placeholder={input.placeholder}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
        />
      ) : (
        <input
          type="text"
          style={base}
          value={(value as string) ?? input.default}
          placeholder={input.placeholder}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
        />
      );

    case 'number':
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <input
            type="number"
            style={{ ...base, flex: 1 }}
            value={(value as number) ?? input.default}
            min={input.min}
            max={input.max}
            step={input.step}
            disabled={disabled}
            onChange={(e) => onChange(parseFloat(e.target.value))}
          />
          {input.unit && (
            <span style={{ fontSize: 10, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
              {input.unit}
            </span>
          )}
        </div>
      );

    case 'slider': {
      const v = (value as number) ?? input.default;
      
      return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{input.min}</span>
            <span style={{ fontSize: 11, color: 'var(--accent)', fontWeight: 600 }}>
              {v}{input.unit ? ` ${input.unit}` : ''}
            </span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{input.max}</span>
          </div>
          <input
            type="range"
            style={{ width: '100%', accentColor: 'var(--accent)', cursor: 'pointer' }}
            value={v}
            min={input.min}
            max={input.max}
            step={input.step}
            disabled={disabled}
            onChange={(e) => onChange(parseFloat(e.target.value))}
          />
        </div>
      );
    }

    case 'dropdown':
      return (
        <select
          style={{ ...base, cursor: 'pointer' }}
          value={(value as string | number) ?? input.default}
          disabled={disabled}
          onChange={(e) => {
            const raw = e.target.value;
            const opt = input.options.find((o) => String(o.value) === raw);
            onChange(opt ? opt.value : raw);
          }}
        >
          {input.options.map((opt) => (
            <option key={String(opt.value)} value={String(opt.value)}>
              {opt.label}
            </option>
          ))}
        </select>
      );

    case 'toggle':
      return (
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={(value as boolean) ?? input.default}
            disabled={disabled}
            onChange={(e) => onChange(e.target.checked)}
            style={{ accentColor: 'var(--accent)', width: 14, height: 14 }}
          />
          <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
            {(value as boolean) ?? input.default ? 'Sí' : 'No'}
          </span>
        </label>
      );

    case 'color':
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <input
            type="color"
            value={(value as string) ?? input.default}
            disabled={disabled}
            onChange={(e) => onChange(e.target.value)}
            style={{ width: 28, height: 24, border: 'none', background: 'none', cursor: 'pointer' }}
          />
          <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'monospace' }}>
            {(value as string) ?? input.default}
          </span>
        </div>
      );

    case 'file':
      return (
        <input
          type="text"
          style={base}
          value={(value as string) ?? input.default ?? ''}
          placeholder={input.extensions ? input.extensions.join(', ') : 'ruta al fichero'}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
        />
      );

    default:
      return null;
  }
}
