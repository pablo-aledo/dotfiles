import { memo, useState } from 'react';
import { Handle, Position, type NodeProps } from 'reactflow';
import type { RFNodeData } from '../graph/store';
import { useGraphStore } from '../graph/store';
import { InputControl } from './controls/InputControl';
import type { InputDescriptor } from '../registry/types';

// Handle size and positioning constants
const HANDLE_SIZE = 10;

function typeColor(type: string): string {
  const palette: Record<string, string> = {
    chord_list:   '#7F77DD',
    midi_data:    '#1D9E75',
    audio_buffer: '#D85A30',
    score:        '#378ADD',
    dict:         '#BA7517',
    number:       '#639922',
    string:       '#D4537E',
    list:         '#0F6E56',
    boolean:      '#993C1D',
    any:          '#888780',
  };
  return palette[type] ?? '#888780';
}

export const GenericNode = memo(({ data, selected }: NodeProps<RFNodeData>) => {
  const registry       = useGraphStore((s) => s.registry);
  const updateInput    = useGraphStore((s) => s.updateInputValue);
  const setSelected    = useGraphStore((s) => s.setSelectedNodeId);
  const [hovered, setHovered] = useState(false);

  if (!registry) return null;
  const schema = registry.nodesBySchemaId.get(data.schema_id);
  if (!schema) return null;

  const category    = registry.categoriesByCategoryId.get(schema.category);
  const accentColor = category?.color ?? '#7F77DD';

  const handleInputs  = schema.inputs.filter((i) => i.kind === 'handle');
  const controlInputs = schema.inputs.filter((i) => i.kind !== 'handle');
  const outputs       = schema.outputs;

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => setSelected(data.id)}
      style={{
        minWidth: 220,
        maxWidth: 260,
        background: 'var(--node-bg)',
        border: `1.5px solid ${selected ? accentColor : hovered ? 'var(--node-border-hover)' : 'var(--node-border)'}`,
        borderRadius: 8,
        boxShadow: selected
          ? `0 0 0 2px ${accentColor}33, 0 4px 20px rgba(0,0,0,0.35)`
          : hovered
          ? '0 4px 16px rgba(0,0,0,0.25)'
          : '0 2px 8px rgba(0,0,0,0.2)',
        transition: 'border-color 0.15s, box-shadow 0.15s',
        fontFamily: 'var(--font)',
        position: 'relative',
      }}
    >
      {/* Header */}
      <div
        style={{
          background: accentColor + '22',
          borderBottom: `1px solid ${accentColor}44`,
          borderRadius: '6px 6px 0 0',
          padding: '7px 10px 6px',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}
      >
        <div
          style={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            background: accentColor,
            flexShrink: 0,
          }}
        />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div
            style={{
              fontSize: 12,
              fontWeight: 600,
              color: 'var(--text-primary)',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {data.label}
          </div>
          {data.label !== schema.label && (
            <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>
              {schema.label}
            </div>
          )}
        </div>
        <div
          style={{
            fontSize: 9,
            color: accentColor,
            background: accentColor + '22',
            border: `1px solid ${accentColor}44`,
            borderRadius: 3,
            padding: '1px 4px',
            whiteSpace: 'nowrap',
            textTransform: 'uppercase',
            letterSpacing: '0.04em',
          }}
        >
          {category?.label ?? schema.category}
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '8px 10px', display: 'flex', flexDirection: 'column', gap: 6 }}>

        {/* Handle inputs (no control, just a label on the left) */}
        {handleInputs.map((input) => (
          <HandleRow
            key={input.id}
            input={input}
            nodeId={data.id}
            side="input"
          />
        ))}

        {/* Control inputs */}
        {controlInputs.map((input) => (
          <div key={input.id} style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <label
              style={{
                fontSize: 10,
                color: 'var(--text-secondary)',
                fontWeight: 500,
                letterSpacing: '0.02em',
              }}
            >
              {input.label}
              {!input.required && (
                <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}> (opcional)</span>
              )}
            </label>
            <InputControl
              input={input}
              value={data.input_values[input.id] ?? null}
              onChange={(v) => updateInput(data.id, input.id, v)}
            />
          </div>
        ))}

        {/* Outputs */}
        {outputs.length > 0 && (
          <div
            style={{
              borderTop: '1px solid var(--node-border)',
              marginTop: 2,
              paddingTop: 6,
              display: 'flex',
              flexDirection: 'column',
              gap: 4,
            }}
          >
            {outputs.map((output) => (
              <HandleRow
                key={output.id}
                input={{ ...output, kind: 'handle', required: false } as InputDescriptor}
                nodeId={data.id}
                side="output"
                type={output.type}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
});

GenericNode.displayName = 'GenericNode';

// ─── Handle row ───────────────────────────────────────────────────────────────

interface HandleRowProps {
  input: InputDescriptor;
  nodeId: string;
  side: 'input' | 'output';
  type?: string;
}

function HandleRow({ input, side, type }: HandleRowProps) {
  const dataType  = type ?? ('type' in input ? (input as { type: string }).type : 'any');
  const color     = typeColor(dataType);
  const isOutput  = side === 'output';

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: isOutput ? 'flex-end' : 'flex-start',
        gap: 5,
        position: 'relative',
        height: 20,
      }}
    >
      {/* Handle — ReactFlow positions it relative to the node edge */}
      <Handle
        type={isOutput ? 'source' : 'target'}
        position={isOutput ? Position.Right : Position.Left}
        id={input.id}
        style={{
          width: HANDLE_SIZE,
          height: HANDLE_SIZE,
          background: color,
          border: `2px solid var(--node-bg)`,
          borderRadius: '50%',
          cursor: 'crosshair',
          // pull handle flush to node edge
          [isOutput ? 'right' : 'left']: -HANDLE_SIZE / 2 - 1,
        }}
      />

      <span
        style={{
          fontSize: 10,
          color: 'var(--text-secondary)',
          [isOutput ? 'marginRight' : 'marginLeft']: 8,
        }}
      >
        {input.label}
      </span>

      {/* Type pill */}
      <span
        style={{
          fontSize: 9,
          color: color,
          background: color + '22',
          border: `1px solid ${color}44`,
          borderRadius: 3,
          padding: '0 4px',
          fontFamily: 'monospace',
          whiteSpace: 'nowrap',
        }}
      >
        {dataType}
      </span>
    </div>
  );
}
