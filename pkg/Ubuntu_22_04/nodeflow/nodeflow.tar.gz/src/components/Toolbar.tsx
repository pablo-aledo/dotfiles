import { useState, useRef } from 'react';
import { useGraphStore } from '../graph/store';
import type { SerializedGraph } from '../registry/types';

export function Toolbar() {
  const registry    = useGraphStore((s) => s.registry);
  const exportGraph = useGraphStore((s) => s.exportGraph);
  const importGraph = useGraphStore((s) => s.importGraph);
  const clearGraph  = useGraphStore((s) => s.clearGraph);
  const rfNodes     = useGraphStore((s) => s.rfNodes);
  const rfEdges     = useGraphStore((s) => s.rfEdges);

  const [graphName, setGraphName]         = useState('Mi pipeline');
  const [exportErrors, setExportErrors]   = useState<string[] | null>(null);
  const [importError, setImportError]     = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleExport() {
    setExportErrors(null);
    const result = exportGraph({ name: graphName });
    if (!result.ok) { setExportErrors(result.errors); return; }
    const blob = new Blob([JSON.stringify(result.graph, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `${graphName.replace(/\s+/g, '_').toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleImportClick() {
    setImportError(null);
    fileInputRef.current?.click();
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const graph = JSON.parse(ev.target?.result as string) as SerializedGraph;
        if (!graph.nodes || !graph.edges || !graph.meta) {
          throw new Error('El archivo no parece un grafo NodeFlow válido');
        }
        importGraph(graph);
        setGraphName(graph.meta.name);
      } catch (err) {
        setImportError(err instanceof Error ? err.message : 'Error al leer el archivo');
      }
    };
    reader.readAsText(file);
    // Reset so the same file can be re-imported
    e.target.value = '';
  }

  const banner = exportErrors ?? (importError ? [importError] : null);
  const bannerColor = importError && !exportErrors ? 'var(--warning)' : 'var(--danger)';

  return (
    <>
      <div style={{
        height: 44, background: 'var(--panel-bg)', borderBottom: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', padding: '0 14px', gap: 10, flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginRight: 4 }}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="4"  cy="9"  r="3" fill="var(--accent)" opacity="0.9"/>
            <circle cx="14" cy="4"  r="3" fill="var(--accent)" opacity="0.6"/>
            <circle cx="14" cy="14" r="3" fill="var(--accent)" opacity="0.6"/>
            <line x1="7" y1="8"  x2="11" y2="5"  stroke="var(--accent)" strokeWidth="1.5" strokeOpacity="0.5"/>
            <line x1="7" y1="10" x2="11" y2="13" stroke="var(--accent)" strokeWidth="1.5" strokeOpacity="0.5"/>
          </svg>
          <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>
            NodeFlow
          </span>
        </div>

        {registry && (
          <span style={{ fontSize: 10, color: 'var(--text-muted)', background: 'var(--ctrl-bg)', border: '1px solid var(--ctrl-border)', borderRadius: 4, padding: '2px 6px', marginRight: 4 }}>
            {registry.display_name}
          </span>
        )}

        {/* Editable graph name */}
        <input
          type="text"
          value={graphName}
          onChange={(e) => setGraphName(e.target.value)}
          style={{
            background: 'transparent', border: 'none',
            borderBottom: '1px solid var(--ctrl-border)',
            color: 'var(--text-primary)', fontSize: 13, fontWeight: 500,
            padding: '2px 4px', outline: 'none', width: 200,
          }}
          onFocus={(e) => (e.target.style.borderBottomColor = 'var(--accent)')}
          onBlur={(e)  => (e.target.style.borderBottomColor = 'var(--ctrl-border)')}
        />

        {/* Stats */}
        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginRight: 'auto' }}>
          {rfNodes.length} nodos · {rfEdges.length} conexiones
        </div>

        {/* Actions */}
        <input ref={fileInputRef} type="file" accept=".json" style={{ display: 'none' }} onChange={handleFileChange} />

        <Btn onClick={handleImportClick}>Importar JSON</Btn>

        {showClearConfirm ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 11, color: 'var(--danger)' }}>¿Limpiar todo?</span>
            <Btn onClick={() => { clearGraph(); setShowClearConfirm(false); }} variant="danger">Sí</Btn>
            <Btn onClick={() => setShowClearConfirm(false)}>No</Btn>
          </div>
        ) : (
          <Btn onClick={() => setShowClearConfirm(true)}>Limpiar</Btn>
        )}

        <Btn onClick={handleExport} variant="primary">Exportar JSON</Btn>
      </div>

      {/* Error / warning banner */}
      {banner && (
        <div style={{
          position: 'absolute', top: 44, left: 230, right: 254, zIndex: 200,
          background: 'var(--panel-bg)', border: `1px solid ${bannerColor}`,
          borderRadius: 6, padding: '8px 14px', margin: '0',
          boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: bannerColor, marginBottom: banner.length > 1 ? 4 : 0 }}>
                {exportErrors ? 'No se puede exportar:' : 'Error al importar:'}
              </div>
              {banner.map((err, i) => (
                <div key={i} style={{ fontSize: 11, color: bannerColor, opacity: 0.85 }}>• {err}</div>
              ))}
            </div>
            <button
              onClick={() => { setExportErrors(null); setImportError(null); }}
              style={{ background:'none', border:'none', color: bannerColor, cursor:'pointer', fontSize:16, padding:'0 0 0 12px', lineHeight:1 }}
            >×</button>
          </div>
        </div>
      )}
    </>
  );
}

function Btn({ children, onClick, variant }: { children: React.ReactNode; onClick: () => void; variant?: 'primary' | 'danger' }) {
  const [hov, setHov] = useState(false);
  const isPrimary = variant === 'primary';
  const isDanger  = variant === 'danger';
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        padding: '5px 12px', borderRadius: 5, fontSize: 12, fontWeight: 500, cursor: 'pointer',
        border: `1px solid ${isDanger ? 'var(--danger)' : isPrimary ? 'var(--accent)' : 'var(--ctrl-border)'}`,
        background: isPrimary ? (hov ? 'var(--accent-hover)' : 'var(--accent)')
                  : isDanger  ? (hov ? '#ff4d4d22' : 'transparent')
                  : (hov ? 'var(--node-hover-bg)' : 'transparent'),
        color: isPrimary ? '#fff' : isDanger ? 'var(--danger)' : 'var(--text-secondary)',
        transition: 'background 0.1s',
        whiteSpace: 'nowrap',
      }}
    >{children}</button>
  );
}
