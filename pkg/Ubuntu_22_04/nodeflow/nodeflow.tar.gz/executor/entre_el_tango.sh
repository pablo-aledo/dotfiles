#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# Pipeline generada por NodeFlow
# Grafo   : Entre el Tango y el Abismo
# Dominio : music_composition
# Exportado: 2026-04-26T11:32:00Z
# ─────────────────────────────────────────────────────────────────

set -euo pipefail

WORKDIR="./salida"
mkdir -p "$WORKDIR"

# Colores para el log
CYAN="\033[0;36m" ; GREEN="\033[0;32m" ; RED="\033[0;31m" ; RESET="\033[0m"

log()  { echo -e "${CYAN}▶ $*${RESET}"; }
ok()   { echo -e "${GREEN}✓ $*${RESET}"; }
fail() { echo -e "${RED}✗ $*${RESET}" >&2; exit 1; }

log "Iniciando pipeline: Entre el Tango y el Abismo"
log "Directorio de trabajo: $WORKDIR"

# ───────────────────────────────────────────────────────────────
# Paso 1/6: Plan de la obra
# Nodo  : node_001  (planning.theorist)
# Módulo: theorist.py
# ───────────────────────────────────────────────────────────────
log "Paso 1/6: Plan de la obra"

# Salida [theorist_json] → ./salida/plan_de_la_obra_node_001__theorist_json.theorist.json
# Salida [curves_json] → ./salida/plan_de_la_obra_node_001__curves_json.curves.json

python3 \
    theorist.py \
    'una pieza oscura entre el tango y el abismo, melancolía urbana' \
    --key \
    Am \
    --bars \
    32 \
    --arc \
    tragedy \
    --output \
    $WORKDIR/plan_de_la_obra_node_001__theorist_json.theorist.json \
    --export-json \
    $WORKDIR/plan_de_la_obra_node_001__curves_json.curves.json

ok "Paso 1 completado: Plan de la obra"

# ───────────────────────────────────────────────────────────────
# Paso 2/6: Progresión flamenca
# Nodo  : node_002  (harmony.chord_progression_generator)
# Módulo: chord_progression_generator.py
# ───────────────────────────────────────────────────────────────
log "Paso 2/6: Progresión flamenca"

# Salida [chord_json] → ./salida/progresión_flamenca_node_002__chord_json.chords.json
# Salida [chord_midi] → ./salida/progresión_flamenca_node_002__chord_midi.mid

python3 \
    chord_progression_generator.py \
    --from-theorist \
    $WORKDIR/plan_de_la_obra_node_001__theorist_json.theorist.json \
    --curves \
    $WORKDIR/plan_de_la_obra_node_001__curves_json.curves.json \
    --key \
    Am \
    --style \
    flamenco \
    --bars \
    16 \
    --complexity \
    0.7 \
    --candidates \
    3 \
    --output \
    $WORKDIR/progresión_flamenca_node_002__chord_json.chords.json

ok "Paso 2 completado: Progresión flamenca"

# ───────────────────────────────────────────────────────────────
# Paso 3/6: Melodía tanguera
# Nodo  : node_003  (melody.conditioned)
# Módulo: melody_conditioned_v5.py
# ───────────────────────────────────────────────────────────────
log "Paso 3/6: Melodía tanguera"

# Salida [midi_out] → ./salida/melodía_tanguera_node_003__midi_out.mid

python3 \
    melody_conditioned_v5.py \
    --chords-json \
    $WORKDIR/progresión_flamenca_node_002__chord_json.chords.json \
    --engine \
    chord_guided \
    --profile \
    tanguero \
    --key \
    Am \
    --bars \
    16 \
    --tempo \
    88 \
    --fix-avoid \
    --candidates \
    3 \
    --seed \
    1337 \
    --output \
    $WORKDIR/melodía_tanguera_node_003__midi_out.mid

ok "Paso 3 completado: Melodía tanguera"

# ───────────────────────────────────────────────────────────────
# Paso 4/6: Bajo walking
# Nodo  : node_004  (rhythm.bass_line_composer)
# Módulo: bass_line_composer.py
# ───────────────────────────────────────────────────────────────
log "Paso 4/6: Bajo walking"

# Salida [midi_out] → ./salida/bajo_walking_node_004__midi_out.mid

python3 \
    bass_line_composer.py \
    --chords-json \
    $WORKDIR/progresión_flamenca_node_002__chord_json.chords.json \
    --key \
    Am \
    --style \
    walking \
    --bars \
    16 \
    --tempo \
    88 \
    --tension \
    0.65 \
    --seed \
    42 \
    --output \
    $WORKDIR/bajo_walking_node_004__midi_out.mid

ok "Paso 4 completado: Bajo walking"

# ───────────────────────────────────────────────────────────────
# Paso 5/6: Mezcla melodía + bajo
# Nodo  : node_005  (utilities.midi_merge)
# Módulo: midi_merge.py
# ───────────────────────────────────────────────────────────────
log "Paso 5/6: Mezcla melodía + bajo"

# Salida [midi_out] → ./salida/mezcla_melodía__bajo_node_005__midi_out.mid

python3 \
    midi_merge.py \
    --output \
    $WORKDIR/mezcla_melodía__bajo_node_005__midi_out.mid \
    $WORKDIR/melodía_tanguera_node_003__midi_out.mid \
    $WORKDIR/bajo_walking_node_004__midi_out.mid

ok "Paso 5 completado: Mezcla melodía + bajo"

# ───────────────────────────────────────────────────────────────
# Paso 6/6: Orquestación final
# Nodo  : node_006  (orchestration.orchestrator)
# Módulo: orchestrator.py
# ───────────────────────────────────────────────────────────────
log "Paso 6/6: Orquestación final"

# Salida [midi_out] → ./salida/orquestación_final_node_006__midi_out.mid

python3 \
    orchestrator.py \
    --input \
    $WORKDIR/mezcla_melodía__bajo_node_005__midi_out.mid \
    --template \
    chamber \
    --output \
    $WORKDIR/orquestación_final_node_006__midi_out.mid

ok "Paso 6 completado: Orquestación final"

# ─────────────────────────────────────────────────────────────────
log "Pipeline completada."
ok "Todos los pasos ejecutados correctamente."

# Ficheros generados:
echo "  [Plan de la obra / theorist_json] ./salida/plan_de_la_obra_node_001__theorist_json.theorist.json"
echo "  [Plan de la obra / curves_json] ./salida/plan_de_la_obra_node_001__curves_json.curves.json"
echo "  [Progresión flamenca / chord_json] ./salida/progresión_flamenca_node_002__chord_json.chords.json"
echo "  [Progresión flamenca / chord_midi] ./salida/progresión_flamenca_node_002__chord_midi.mid"
echo "  [Melodía tanguera / midi_out] ./salida/melodía_tanguera_node_003__midi_out.mid"
echo "  [Bajo walking / midi_out] ./salida/bajo_walking_node_004__midi_out.mid"
echo "  [Mezcla melodía + bajo / midi_out] ./salida/mezcla_melodía__bajo_node_005__midi_out.mid"
echo "  [Orquestación final / midi_out] ./salida/orquestación_final_node_006__midi_out.mid"
