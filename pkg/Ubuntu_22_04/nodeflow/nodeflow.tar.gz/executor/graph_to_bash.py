#!/usr/bin/env python3
"""
graph_to_bash.py
================
Lee un JSON de grafo exportado por NodeFlow y genera un script bash
que ejecuta la pipeline en el orden correcto.

Uso:
    python graph_to_bash.py grafo.json [--output pipeline.sh] [--workdir ./run] [--python python3]

El script bash generado:
  - Ejecuta cada nodo en el orden topológico del grafo
  - Pasa los input_values como flags CLI
  - Resuelve los inputs de tipo handle conectando las salidas de nodos anteriores
  - Gestiona los ficheros intermedios en --workdir
  - Aborta con mensaje descriptivo si cualquier paso falla
"""

import json
import sys
import argparse
import textwrap
from pathlib import Path


# ── Extensiones por tipo de dato ──────────────────────────────────────────────
# Mapea el tipo de output a la extensión del fichero que genera el módulo.
# El executor usa esto para nombrar los ficheros intermedios.

TYPE_EXTENSIONS = {
    "midi_data":       ".mid",
    "chord_json":      ".chords.json",
    "chord_list":      ".chords.txt",
    "melody_json":     ".melody.json",
    "fingerprint_json":".fingerprint.json",
    "theorist_json":   ".theorist.json",
    "narrator_json":   ".narrator.json",
    "curves_json":     ".curves.json",
    "grammar_txt":     ".grammar.txt",
    "schedule_json":   ".schedule.json",
    "library_json":    ".library.json",
    "leitmotif_bank":  ".leitmotif_bank.json",
    "dataset_npz":     ".npz",
    "model_pt":        ".pt",
    "model_pkl":       ".pkl",
    "dict":            ".json",
    "string":          ".txt",
    "any":             ".out",
}

# ── Flags CLI por input_id ────────────────────────────────────────────────────
# Mapea el id de cada input a su flag CLI en el script Python correspondiente.
# Si un input_id no está aquí, se usa --<input_id> por defecto.

FLAG_OVERRIDES = {
    # inputs de control frecuentes con nombres especiales
    "chords_text":      "--chords",
    "chord_id":         "--id",
    "bar_start":        "--compas-inicio",
    "no_llm":           "--no-llm",
    "no_perc":          "--no-perc",
    "no_ks":            "--no-ks",
    "fix_avoid":        "--fix-avoid",
    "pitch_norm":       "--pitch-norm",
    "groove_diversity": "--groove-diversity",
    "from_step":        "--from",
    "until_step":       "--until",
    "tension_min":      "--tension-min",
    "tension_max":      "--tension-max",
    "tension_profile":  "--tension-profile",
    "motif_text":       "--motif-text",
    "phrase_type":      "--type",
    "cadence_ant":      "--cadences",   # special: paired with cadence_cons
    "voice_position":   "--voice-position",
    "adapt_mode":       "--adapt-mode",
    "acc_style":        "--acc-style",
    "voice_pos":        "--voice-position",
    "mutation_rate":    "--mutation-rate",
    "n_sections":       "--n-sections",
    "merge_bars":       "--merge-bars",
    "blend_preset":     "--blend-preset",
}

# Inputs que se manejan con lógica especial o se ignoran
SKIP_INPUTS = {
    "cadence_cons",   # se une con cadence_ant en --cadences <ant> <cons>
}

# Inputs de handle cuyo flag CLI se deduce por nombre del input
HANDLE_FLAG_OVERRIDES = {
    "midi_a":          "--input-a",
    "midi_b":          "--input-b",
    "midi_c":          "--input-c",
    "midi_d":          "--input-d",
    "midi_in":         "--input",
    "chord_in":        "--chords-midi",
    "chord_json_in":   "--chords-json",
    "chord_midi_in":   "--chords-midi",
    "melody_in":       "--melody-midi",
    "harmony_in":      "--harmony-midi",
    "content_in":      "--content",
    "style_in":        "--style-midi",
    "curves_in":       "--curves",
    "theorist_in":     "--from-theorist",
    "narrator_in":     "--from-narrator",
    "fingerprint_in":  "--fingerprint",
    "fingerprint_a":   "--fingerprint-a",
    "fingerprint_b":   "--fingerprint-b",
    "library_in":      "--library",
    "motif_in":        "--motif",
    "grammar_in":      "--grammar",
    "model_in":        "--model",
    "soprano_in":      "--soprano",
    "leitmotif_in":    "--leitmotif",
    "desired_in":      "--desired",
    "rejected_in":     "--rejected",
    "reference_in":    "--reference",
    "fragment_in":     "--input",
    "desired_in":      "--desired",
}


# ─────────────────────────────────────────────────────────────────────────────

def load_graph(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def node_slug(node: dict) -> str:
    """Nombre corto del nodo para usar en nombres de fichero."""
    label = node.get("label") or node["schema_id"].split(".")[-1]
    slug = label.lower().replace(" ", "_")
    # Remove non-alphanumeric except underscore
    slug = "".join(c for c in slug if c.isalnum() or c == "_")
    return f"{slug}_{node['id']}"


def output_file(node: dict, output_id: str, output_type: str, workdir: str) -> str:
    """Ruta al fichero de salida de un nodo concreto."""
    ext = TYPE_EXTENSIONS.get(output_type, ".out")
    slug = node_slug(node)
    return f"$WORKDIR/{slug}__{output_id}{ext}"


def shell_quote(value) -> str:
    """Escapa un valor para bash."""
    if isinstance(value, bool):
        return ""  # los boolean se tratan como flags sin valor
    if isinstance(value, (int, float)):
        return str(value)
    s = str(value)
    # Si contiene espacios o caracteres especiales, usar comillas
    if any(c in s for c in (' ', '"', "'", '$', '`', '\\', '!', '&', '|', ';', '<', '>')):
        s = s.replace("'", "'\\''")
        return f"'{s}'"
    return s


def control_flag(input_id: str, value) -> list[str]:
    """
    Convierte un input de control en fragmentos de flag CLI.
    Retorna una lista de strings para concatenar en el comando.
    """
    if input_id in SKIP_INPUTS:
        return []

    # Boolean: si True → solo el flag, si False → nada
    if isinstance(value, bool):
        if value:
            flag = FLAG_OVERRIDES.get(input_id, f"--{input_id.replace('_', '-')}")
            return [flag]
        return []

    # Valores vacíos o cero que indican "auto" → omitir
    if value == "" or value is None:
        return []
    if isinstance(value, (int, float)) and value == 0 and input_id in {
        "tempo", "bars", "chord_id", "length", "seed"
    }:
        return []

    flag = FLAG_OVERRIDES.get(input_id, f"--{input_id.replace('_', '-')}")
    return [flag, shell_quote(value)]


def build_command(
    node: dict,
    schema: dict,
    edge_outputs: dict,  # (source_node_id, output_id) → filepath
    python_bin: str,
) -> tuple[str, dict]:
    """
    Construye el comando bash para ejecutar un nodo.
    Retorna (comando_str, {output_id: filepath}).
    """
    meta = schema.get("metadata", {})
    module = meta.get("python_module", node["schema_id"].split(".")[-1])
    script = f"{module}.py"

    parts = [python_bin, script]

    schema_inputs = {i["id"]: i for i in schema.get("inputs", [])}
    schema_outputs = schema.get("outputs", [])

    # ── Resolver inputs de handle (ficheros de nodos anteriores) ────────────
    # Construimos un mapa edge_in: input_id → filepath
    connected_handles: dict[str, str] = {}
    for edge in edge_outputs.get("_edges_for_node", {}).get(node["id"], []):
        input_id = edge["target"]["input_id"]
        source_key = (edge["source"]["node_id"], edge["source"]["output_id"])
        if source_key in edge_outputs:
            connected_handles[input_id] = edge_outputs[source_key]

    # ── Inputs de handle conectados ────────────────────────────────────────
    # Caso especial: nodos con múltiples MIDI de entrada (merge, evolver…)
    midi_inputs_connected = []
    for input_id, filepath in connected_handles.items():
        schema_input = schema_inputs.get(input_id, {})
        if schema_input.get("kind") != "handle":
            continue

        # Detectar si es un input posicional (sin flag)
        if input_id in {"midi_a", "midi_b", "midi_c", "midi_d"} and \
           module in {"midi_merge", "evolver", "counterexample", "morpher",
                      "coherence_stitcher"}:
            midi_inputs_connected.append(filepath)
            continue

        flag = HANDLE_FLAG_OVERRIDES.get(input_id,
               f"--{input_id.replace('_', '-').replace('_in', '').replace('_midi', '-midi')}")
        parts += [flag, filepath]

    # Positional MIDI inputs (sin flag, van al final del comando)
    positional = midi_inputs_connected[:]

    # ── Input de descripción libre (primer argumento posicional en algunos) ─
    input_values = node.get("input_values", {})
    if "description" in input_values and module in {
        "theorist", "melody_generator", "chord_progression_generator",
        "bass_line_composer"
    }:
        desc = input_values.pop("description", "")
        if desc:
            parts.append(shell_quote(desc))

    # ── Inputs de control ────────────────────────────────────────────────────
    # Caso especial: --cadences necesita dos valores juntos
    cadence_ant = input_values.get("cadence_ant")
    cadence_cons = input_values.get("cadence_cons")
    if cadence_ant and cadence_cons:
        parts += ["--cadences", shell_quote(cadence_ant), shell_quote(cadence_cons)]

    for input_id, value in input_values.items():
        if input_id in connected_handles:
            continue  # ya resuelto como handle
        if input_id in {"cadence_ant", "cadence_cons"}:
            continue  # ya resueltos arriba
        schema_input = schema_inputs.get(input_id, {})
        if schema_input.get("kind") == "handle":
            continue  # handle sin conectar → opcional, omitir

        frags = control_flag(input_id, value)
        parts.extend(frags)

    # ── Output principal ─────────────────────────────────────────────────────
    # Calculamos la ruta de salida de cada output del nodo
    outputs_map: dict[str, str] = {}
    output_flags = []

    for out in schema_outputs:
        out_id = out["id"]
        out_type = out.get("type", "any")
        filepath = output_file(node, out_id, out_type, "$WORKDIR")
        outputs_map[out_id] = filepath

    # El --output principal es el primer output (si existe)
    if schema_outputs:
        primary = schema_outputs[0]
        primary_path = outputs_map[primary["id"]]
        output_flags = ["--output", primary_path]

    # Algunos módulos usan --export-json para salidas secundarias JSON
    if len(schema_outputs) > 1:
        secondary = schema_outputs[1]
        sec_type = secondary.get("type", "any")
        sec_path = outputs_map[secondary["id"]]
        if sec_type in {"chord_json", "dict", "melody_json", "theorist_json",
                        "narrator_json", "curves_json", "fingerprint_json"}:
            output_flags += ["--export-json", sec_path]

    parts.extend(output_flags)
    parts.extend(positional)

    cmd = " ".join(parts)
    return cmd, outputs_map


# ─────────────────────────────────────────────────────────────────────────────

def generate_bash(graph: dict, python_bin: str, workdir: str) -> str:
    meta      = graph.get("meta", {})
    schemas   = graph.get("node_schemas", {})
    nodes_raw = graph.get("nodes", [])
    edges_raw = graph.get("edges", [])
    order     = graph.get("execution_order", [])

    # Index nodes by id
    nodes_by_id = {n["id"]: n for n in nodes_raw}

    # Build edges index: node_id → list of edges targeting that node
    edges_for_node: dict[str, list] = {n["id"]: [] for n in nodes_raw}
    for edge in edges_raw:
        target_id = edge["target"]["node_id"]
        if target_id in edges_for_node:
            edges_for_node[target_id].append(edge)

    # edge_outputs: (source_node_id, output_id) → filepath
    # Populated as we process each node
    edge_outputs: dict[tuple, str] = {}
    edge_outputs["_edges_for_node"] = edges_for_node

    # ── Cabecera del script ──────────────────────────────────────────────────
    lines = [
        "#!/usr/bin/env bash",
        "# ─────────────────────────────────────────────────────────────────",
        f"# Pipeline generada por NodeFlow",
        f"# Grafo   : {meta.get('name', 'sin nombre')}",
        f"# Dominio : {meta.get('domain', '')}",
        f"# Exportado: {meta.get('exported_at', '')}",
        "# ─────────────────────────────────────────────────────────────────",
        "",
        "set -euo pipefail",
        "",
        f'WORKDIR="{workdir}"',
        'mkdir -p "$WORKDIR"',
        "",
        "# Colores para el log",
        'CYAN="\\033[0;36m" ; GREEN="\\033[0;32m" ; RED="\\033[0;31m" ; RESET="\\033[0m"',
        "",
        'log()  { echo -e "${CYAN}▶ $*${RESET}"; }',
        'ok()   { echo -e "${GREEN}✓ $*${RESET}"; }',
        'fail() { echo -e "${RED}✗ $*${RESET}" >&2; exit 1; }',
        "",
        'log "Iniciando pipeline: ' + meta.get("name", "NodeFlow") + '"',
        'log "Directorio de trabajo: $WORKDIR"',
        "",
    ]

    # ── Pasos en orden topológico ────────────────────────────────────────────
    for step_num, node_id in enumerate(order, 1):
        node = nodes_by_id.get(node_id)
        if not node:
            continue

        schema_id = node["schema_id"]
        schema    = schemas.get(schema_id, {})
        label     = node.get("label", schema_id)
        meta_s    = schema.get("metadata", {})
        module    = meta_s.get("python_module", schema_id.split(".")[-1])

        cmd, outputs_map = build_command(node, schema, edge_outputs, python_bin)

        # Registrar salidas para nodos posteriores
        for out_id, filepath in outputs_map.items():
            edge_outputs[(node_id, out_id)] = filepath

        # Sección del paso
        lines += [
            f"# {'─' * 63}",
            f"# Paso {step_num}/{len(order)}: {label}",
            f"# Nodo  : {node_id}  ({schema_id})",
            f"# Módulo: {module}.py",
            f"# {'─' * 63}",
            f'log "Paso {step_num}/{len(order)}: {label}"',
            "",
        ]

        # Mostrar salidas esperadas como comentarios
        for out_id, filepath in outputs_map.items():
            lines.append(f"# Salida [{out_id}] → {filepath.replace('$WORKDIR', workdir)}")
        lines.append("")

        # El comando real
        # Si es largo, lo partimos en líneas con \
        if len(cmd) > 80:
            # Partir por espacios respetando quoted strings
            cmd_parts = _split_cmd_parts(cmd)
            cmd_lines = [cmd_parts[0]]
            for part in cmd_parts[1:]:
                cmd_lines.append("    " + part)
            cmd_str = " \\\n".join(cmd_lines)
        else:
            cmd_str = cmd

        lines += [
            cmd_str,
            "",
            f'ok "Paso {step_num} completado: {label}"',
            "",
        ]

    # ── Cierre ───────────────────────────────────────────────────────────────
    lines += [
        "# ─────────────────────────────────────────────────────────────────",
        'log "Pipeline completada."',
        'ok "Todos los pasos ejecutados correctamente."',
        "",
        "# Ficheros generados:",
    ]

    # Listar todos los ficheros de salida finales
    for node_id in order:
        node = nodes_by_id.get(node_id)
        if not node:
            continue
        schema = schemas.get(node["schema_id"], {})
        label  = node.get("label", node["schema_id"])
        for out in schema.get("outputs", []):
            out_id = out["id"]
            key = (node_id, out_id)
            if key in edge_outputs:
                filepath = edge_outputs[key].replace("$WORKDIR", workdir)
                lines.append(f'echo "  [{label} / {out_id}] {filepath}"')

    lines.append("")
    return "\n".join(lines)


def _split_cmd_parts(cmd: str) -> list[str]:
    """
    Divide un comando en partes para formateo multilínea,
    respetando strings entrecomillados.
    """
    parts = []
    current = []
    in_single = False
    in_double = False

    for char in cmd:
        if char == "'" and not in_double:
            in_single = not in_single
            current.append(char)
        elif char == '"' and not in_single:
            in_double = not in_double
            current.append(char)
        elif char == ' ' and not in_single and not in_double:
            if current:
                parts.append("".join(current))
                current = []
        else:
            current.append(char)

    if current:
        parts.append("".join(current))

    return parts


# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Genera un script bash a partir de un JSON de grafo NodeFlow.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
            Ejemplos:
              python graph_to_bash.py mi_pipeline.json
              python graph_to_bash.py mi_pipeline.json --output run.sh --workdir ./salida
              python graph_to_bash.py mi_pipeline.json --python python
              bash run.sh
        """)
    )
    parser.add_argument(
        "graph",
        help="Ruta al JSON exportado por NodeFlow"
    )
    parser.add_argument(
        "--output", "-o",
        default=None,
        help="Fichero de salida (default: <nombre_grafo>.sh)"
    )
    parser.add_argument(
        "--workdir", "-w",
        default="./pipeline_output",
        help="Directorio de trabajo para ficheros intermedios (default: ./pipeline_output)"
    )
    parser.add_argument(
        "--python",
        default="python3",
        help="Intérprete de Python a usar (default: python3)"
    )
    args = parser.parse_args()

    # Cargar grafo
    try:
        graph = load_graph(args.graph)
    except FileNotFoundError:
        print(f"Error: no se encuentra el fichero '{args.graph}'", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error al parsear JSON: {e}", file=sys.stderr)
        sys.exit(1)

    # Validar estructura mínima
    for field in ("meta", "nodes", "edges", "execution_order", "node_schemas"):
        if field not in graph:
            print(f"Error: el JSON no tiene el campo '{field}'. ¿Es un grafo NodeFlow válido?",
                  file=sys.stderr)
            sys.exit(1)

    # Determinar nombre de salida
    if args.output:
        out_path = args.output
    else:
        graph_name = graph["meta"].get("name", "pipeline")
        slug = graph_name.lower().replace(" ", "_")
        slug = "".join(c for c in slug if c.isalnum() or c == "_")
        out_path = f"{slug}.sh"

    # Generar script
    script = generate_bash(graph, python_bin=args.python, workdir=args.workdir)

    # Escribir
    Path(out_path).write_text(script)
    Path(out_path).chmod(0o755)

    # Resumen
    n_nodes = len(graph.get("execution_order", []))
    print(f"✓ Script generado: {out_path}")
    print(f"  Nodos   : {n_nodes}")
    print(f"  Workdir : {args.workdir}")
    print(f"  Python  : {args.python}")
    print(f"")
    print(f"  Para ejecutar:")
    print(f"    bash {out_path}")


if __name__ == "__main__":
    main()
