import gguf  # noqa: F401

# TODO: add tests


def test_write_gguf() -> None:
    pass
