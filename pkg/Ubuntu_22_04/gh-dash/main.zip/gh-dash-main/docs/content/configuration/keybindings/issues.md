---
title: Issues
linkTitle: >-
  ![icon:circle-dot](lucide)&nbsp;Issues
weight: 2
summary: >-
  Documentation for defining commands in the Issues view of your GitHub dashboard.
schematize: keybindings.issues
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
