---
title: PRs
linkTitle: >-
  ![icon:git-pull-request](lucide)&nbsp;PRs
weight: 1
summary: >-
  Documentation for defining commands in the PRs view of your GitHub dashboard.
schematize: keybindings.prs
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
