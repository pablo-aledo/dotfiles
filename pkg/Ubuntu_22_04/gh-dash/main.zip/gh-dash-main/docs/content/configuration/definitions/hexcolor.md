---
title: Hex Color
summary: >-
  The schema for valid colors to use with your GitHub dashboard.
weight: 99
schematize: definitions.hexcolor
type: schematize
outputs:
  - Schematize
---
