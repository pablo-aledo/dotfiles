---
title: Theme
linkTitle: >-
  ![icon:palette](lucide)&nbsp;Theme
summary: >-
  Documentation for configuring your GitHub dashboard's theme.
weight: 7
schematize: theme
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
