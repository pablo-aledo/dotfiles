---
title: Keybindings
linkTitle: >-
  ![icon:keyboard](lucide)&nbsp;Keybindings
summary: Documentation for defining commands for your GitHub dashboard.
weight: 6
platen:
  menu:
    collapse_section: true
---
