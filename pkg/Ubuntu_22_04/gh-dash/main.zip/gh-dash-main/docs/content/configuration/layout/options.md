---
title: Valid Options
linkTitle: >-
  ![icon:check-check](lucide)&nbsp;Valid Options
summary: >-
  Documentation for the valid options of columns in your GitHub dashboard's layout.
weight: 99
schematize: layout.options
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
