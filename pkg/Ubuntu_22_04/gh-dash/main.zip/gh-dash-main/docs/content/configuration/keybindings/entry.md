---
title: Valid Keybindings
linkTitle: >-
  ![icon:check-check](lucide)&nbsp;Valid Keybindings
summary: >-
  Documentation for defining a valid keybinding in your GitHub dashboard.
weight: 99
schematize: keybindings.entry
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
