---
title: Defaults
linkTitle: >-
  ![icon:settings-2](lucide)&nbsp;Defaults
summary: >-
  Documentation for the `defaults` setting options for your GitHub dashboard.
weight: 4
schematize: defaults
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
