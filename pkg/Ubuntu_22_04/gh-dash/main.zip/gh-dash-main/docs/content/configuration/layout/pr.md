---
title: PR Layout
linkTitle: >-
  ![icon:git-pull-request](lucide)&nbsp;PR Layout
weight: 1
summary: >-
  Documentation for defining the layout of a PR section in your GitHub dashboard.
schematize: layout.pr
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
