---
title: Schema
linkTitle: >-
  ![icon:file-code-2](lucide)&nbsp;Schema
summary: >-
  Documentation and schema for the configuration of your GitHub dashboard.
weight: 1
schematize: gh-dash
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
