---
title: Issue Section
linkTitle: >-
  ![icon:circle-dot](lucide)&nbsp;Issue Section
summary: >-
  Documentation for configuring the issues sections of your GitHub dashboard.
weight: 3
schematize: issue-section
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
