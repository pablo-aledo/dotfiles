---
title: PR Section
linkTitle: >-
  ![icon:git-pull-request](lucide)&nbsp;PR Section
summary: >-
  Documentation for configuring the PR sections of your GitHub dashboard.
weight: 2
schematize: pr-section
outputs:
  - HTML
  - Schematize
---

{{% schematize %}}
