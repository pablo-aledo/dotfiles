---
title: Layout
linkTitle: >-
  ![icon:layout-dashboard](lucide)&nbsp;Layout
summary: Documentation for configuring your GitHub dashboard's layout.
weight: 5
platen:
  menu:
    collapse_section: true
---
