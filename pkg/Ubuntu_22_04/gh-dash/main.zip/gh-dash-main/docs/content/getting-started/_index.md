---
title:  Getting Started
weight: 1
summary: >-
  Get started using `gh-dash` to review and manage your GitHub work items.
platen:
  menu:
    flatten_section: true
---
