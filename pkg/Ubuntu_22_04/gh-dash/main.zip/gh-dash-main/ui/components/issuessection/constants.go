package issuessection

var (
	issueNumCommentsCellWidth = 6
)
