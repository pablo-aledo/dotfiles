package constants

import "github.com/dlvhdr/gh-dash/v4/config"

type InitMsg struct {
	Config config.Config
}
