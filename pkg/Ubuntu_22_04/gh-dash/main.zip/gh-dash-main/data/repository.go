package data

type Repository struct {
	Name          string
	NameWithOwner string
	IsArchived    bool
}
