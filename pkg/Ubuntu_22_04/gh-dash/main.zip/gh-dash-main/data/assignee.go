package data

type Assignees struct {
	Nodes []Assignee
}

type Assignee struct {
	Login string
}
