package main

import (
	"github.com/dlvhdr/gh-dash/v4/cmd"
)

func main() {
	cmd.Execute()
}
