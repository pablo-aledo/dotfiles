"""
program.py — Optimizador de hiperparámetros para scripts de entrenamiento.

Sustituye al binomio program.md + LLM con una estrategia de optimización
local, reproducible y fundamentada teóricamente.

Uso:
    python program.py \\
        --target abc_train.py \\
        --strategy random \\
        --cost-regex "val_bpb:\\s+([\\d.]+)" \\
        --config hyperparams.yaml \\
        --direction minimize \\
        --time-budget 3600 \\
        --results results.tsv

Estrategias disponibles:
    random    — Random search (sin dependencias externas)
    bayesian  — TPE via Optuna (requiere: pip install optuna)
"""

import argparse
import re
import subprocess
import sys
import time
from abc import ABC, abstractmethod
from pathlib import Path

import yaml


# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------

def load_config(path: str) -> dict:
    """Carga y valida el fichero de configuración YAML."""
    with open(path, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    if "variables" not in config:
        raise ValueError("El fichero de configuración debe tener una clave 'variables'.")

    for name, spec in config["variables"].items():
        if "type" not in spec:
            raise ValueError(f"Variable '{name}' no tiene 'type'.")
        vtype = spec["type"]
        if vtype in ("int", "float") and "range" not in spec:
            raise ValueError(f"Variable '{name}' de tipo '{vtype}' necesita 'range'.")
        if vtype == "categorical" and "values" not in spec:
            raise ValueError(f"Variable '{name}' de tipo 'categorical' necesita 'values'.")

    return config


# ---------------------------------------------------------------------------
# TargetPatcher — modifica el script objetivo
# ---------------------------------------------------------------------------

class TargetPatcher:
    """
    Reemplaza líneas de la forma:
        NOMBRE = <literal>
    al inicio de línea (sin comentarios previos, sin expresiones).

    Contrato con el usuario: las variables optimizables deben aparecer
    en el script target como literales simples al inicio de línea.
    """

    # Regex que captura: NOMBRE = valor_literal (opcional: comentario al final)
    # Solo coincide si NOMBRE está al inicio de línea (sin espacios previos)
    LINE_PATTERN = re.compile(
        r'^({name})\s*=\s*([^\n#]+?)(\s*#[^\n]*)?\s*$'
    )

    def __init__(self, target_path: str):
        self.path = Path(target_path)
        if not self.path.exists():
            raise FileNotFoundError(f"Script objetivo no encontrado: {target_path}")

    def patch(self, params: dict) -> None:
        """Aplica los parámetros propuestos al script objetivo."""
        content = self.path.read_text(encoding="utf-8")
        lines = content.splitlines(keepends=True)
        patched = []
        applied = {name: False for name in params}

        for line in lines:
            replaced = False
            for name, value in params.items():
                pattern = re.compile(
                    rf'^({re.escape(name)})\s*=\s*([^\n#]+?)(\s*#[^\n]*)?\s*$'
                )
                m = pattern.match(line.rstrip('\n').rstrip('\r'))
                if m:
                    comment = m.group(3) or ""
                    serialized = self._serialize(value)
                    new_line = f"{name} = {serialized}{comment}\n"
                    patched.append(new_line)
                    applied[name] = True
                    replaced = True
                    break
            if not replaced:
                patched.append(line)

        not_found = [name for name, found in applied.items() if not found]
        if not_found:
            raise ValueError(
                f"Variables no encontradas en el script target: {not_found}\n"
                f"Asegúrate de que aparecen como 'NOMBRE = <literal>' al inicio de línea."
            )

        self.path.write_text("".join(patched), encoding="utf-8")

    def _serialize(self, value) -> str:
        """Serializa un valor Python al formato correcto para el script."""
        if isinstance(value, bool):
            return "True" if value else "False"
        if isinstance(value, float):
            # Preservar notación científica para valores muy pequeños o grandes
            if abs(value) < 1e-3 or abs(value) >= 1e4:
                return f"{value:g}"
            return repr(value)
        if isinstance(value, str):
            return f'"{value}"'
        return repr(value)


# ---------------------------------------------------------------------------
# Runner — ejecuta el script objetivo
# ---------------------------------------------------------------------------

class Runner:
    """Ejecuta el script target y captura su output."""

    def __init__(self, target_path: str, timeout: float = 700):
        self.target_path = target_path
        self.timeout = timeout  # segundos, debe ser mayor que TIME_BUDGET del script

    def run(self) -> tuple[str, str, int]:
        """
        Ejecuta el script. Devuelve (stdout, stderr, returncode).
        Hace streaming del output a consola mientras ejecuta.
        """
        print(f"\n{'─' * 60}")
        print(f"Ejecutando: {self.target_path}")
        print(f"{'─' * 60}")

        stdout_lines = []
        stderr_lines = []

        try:
            process = subprocess.Popen(
                [sys.executable, self.target_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )

            # Streaming de stdout
            for line in process.stdout:
                print(line, end="", flush=True)
                stdout_lines.append(line)

            process.wait(timeout=self.timeout)
            stderr_lines = process.stderr.readlines()

            if process.returncode != 0:
                print("\n[STDERR]")
                print("".join(stderr_lines))

            return "".join(stdout_lines), "".join(stderr_lines), process.returncode

        except subprocess.TimeoutExpired:
            process.kill()
            print(f"\n⚠ Timeout ({self.timeout}s). Run terminado forzosamente.")
            return "".join(stdout_lines), "TIMEOUT", -1


# ---------------------------------------------------------------------------
# CostExtractor — extrae el coste del output
# ---------------------------------------------------------------------------

class CostExtractor:
    """Extrae el valor de coste del output del script usando una regex."""

    def __init__(self, pattern: str):
        try:
            self.regex = re.compile(pattern, re.MULTILINE)
        except re.error as e:
            raise ValueError(f"Regex de coste inválida: {e}")

    def extract(self, output: str) -> float | None:
        """
        Busca el patrón en el output. Devuelve el último match como float,
        o None si no encuentra ninguno (crash o formato inesperado).
        """
        matches = self.regex.findall(output)
        if not matches:
            return None
        try:
            return float(matches[-1])
        except ValueError:
            return None


# ---------------------------------------------------------------------------
# ResultsLogger — registra resultados en TSV
# ---------------------------------------------------------------------------

class ResultsLogger:
    """Mantiene el fichero results.tsv con el historial de experimentos."""

    HEADER = "experiment\tstrategy\tstatus\tcost\t{params}\n"

    def __init__(self, path: str, param_names: list[str], strategy_name: str):
        self.path = Path(path)
        self.param_names = param_names
        self.strategy_name = strategy_name
        self.experiment = 0
        self._init_file()

    def _init_file(self):
        if not self.path.exists():
            header = f"experiment\tstrategy\tstatus\tcost\t"
            header += "\t".join(self.param_names) + "\n"
            self.path.write_text(header, encoding="utf-8")

    def log(self, params: dict, cost: float | None, status: str):
        self.experiment += 1
        cost_str = f"{cost:.6f}" if cost is not None else "N/A"
        param_values = "\t".join(str(params.get(n, "N/A")) for n in self.param_names)
        line = f"{self.experiment}\t{self.strategy_name}\t{status}\t{cost_str}\t{param_values}\n"
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(line)
        print(f"\n→ Experimento {self.experiment}: cost={cost_str} status={status}")
        print(f"  Params: {params}")


# ---------------------------------------------------------------------------
# Estrategias
# ---------------------------------------------------------------------------

class Strategy(ABC):
    """Interfaz común para todas las estrategias de optimización."""

    def __init__(self, config: dict, direction: str):
        self.variables = config["variables"]
        self.direction = direction  # "minimize" o "maximize"

    @abstractmethod
    def suggest(self) -> dict:
        """Propone el siguiente conjunto de parámetros a evaluar."""
        ...

    @abstractmethod
    def update(self, params: dict, cost: float):
        """Registra el resultado de un experimento."""
        ...

    def _sample_variable(self, name: str, spec: dict, rng) -> object:
        """Muestrea una variable según su tipo y especificación."""
        vtype = spec["type"]

        if vtype == "int":
            low, high = spec["range"]
            return rng.randint(low, high)

        elif vtype == "float":
            low, high = spec["range"]
            if spec.get("scale") == "log":
                import math
                log_low, log_high = math.log(low), math.log(high)
                return math.exp(rng.uniform(log_low, log_high))
            return rng.uniform(low, high)

        elif vtype == "categorical":
            return rng.choice(spec["values"])

        elif vtype == "bool":
            return rng.choice([True, False])

        else:
            raise ValueError(f"Tipo de variable desconocido: '{vtype}' para '{name}'")


class RandomStrategy(Strategy):
    """
    Random search — muestrea el espacio de hiperparámetros uniformemente.
    Sin dependencias externas. Sorprendentemente competitivo cuando el
    número de evaluaciones es limitado.
    """

    def __init__(self, config: dict, direction: str, seed: int = 42):
        super().__init__(config, direction)
        import random
        self.rng = random.Random(seed)
        self._last_params = None

    def suggest(self) -> dict:
        params = {}
        for name, spec in self.variables.items():
            params[name] = self._sample_variable(name, spec, self.rng)
        self._last_params = params
        return params

    def update(self, params: dict, cost: float):
        # Random search no usa el historial para decidir — es su característica definitoria
        pass


class BayesianStrategy(Strategy):
    """
    TPE (Tree-structured Parzen Estimator) via Optuna.
    Construye un modelo probabilístico del espacio de búsqueda y concentra
    las evaluaciones en regiones prometedoras. Más eficiente que random
    a partir de ~20-30 evaluaciones.

    Requiere: pip install optuna
    """

    def __init__(self, config: dict, direction: str, seed: int = 42):
        try:
            import optuna
            optuna.logging.set_verbosity(optuna.logging.WARNING)
        except ImportError:
            raise ImportError(
                "La estrategia 'bayesian' requiere Optuna.\n"
                "Instálalo con: pip install optuna"
            )

        super().__init__(config, direction)
        self.optuna = optuna
        self.seed = seed
        self._study = optuna.create_study(
            direction=direction,
            sampler=optuna.samplers.TPESampler(seed=seed),
        )
        self._current_trial = None

    def suggest(self) -> dict:
        self._current_trial = self._study.ask()
        params = {}
        for name, spec in self.variables.items():
            params[name] = self._suggest_variable(name, spec)
        return params

    def _suggest_variable(self, name: str, spec: dict) -> object:
        trial = self._current_trial
        vtype = spec["type"]

        if vtype == "int":
            low, high = spec["range"]
            return trial.suggest_int(name, low, high)

        elif vtype == "float":
            low, high = spec["range"]
            log = spec.get("scale") == "log"
            return trial.suggest_float(name, low, high, log=log)

        elif vtype == "categorical":
            return trial.suggest_categorical(name, spec["values"])

        elif vtype == "bool":
            return trial.suggest_categorical(name, [True, False])

        else:
            raise ValueError(f"Tipo de variable desconocido: '{vtype}' para '{name}'")

    def update(self, params: dict, cost: float):
        if self._current_trial is not None:
            self._study.tell(self._current_trial, cost)
            self._current_trial = None

    def best(self) -> tuple[dict, float]:
        """Devuelve los mejores parámetros encontrados hasta ahora."""
        trial = self._study.best_trial
        return trial.params, trial.value


# ---------------------------------------------------------------------------
# Bucle principal
# ---------------------------------------------------------------------------

def make_strategy(name: str, config: dict, direction: str, seed: int) -> Strategy:
    strategies = {
        "random": RandomStrategy,
        "bayesian": BayesianStrategy,
    }
    if name not in strategies:
        raise ValueError(f"Estrategia desconocida: '{name}'. Opciones: {list(strategies)}")
    return strategies[name](config, direction, seed=seed)


def run_optimization(args):
    print(f"program.py — Optimizador de hiperparámetros")
    print(f"  Target:    {args.target}")
    print(f"  Estrategia: {args.strategy}")
    print(f"  Dirección: {args.direction}")
    print(f"  Presupuesto: {args.time_budget}s")
    print()

    # Inicialización
    config    = load_config(args.config)
    patcher   = TargetPatcher(args.target)
    runner    = Runner(args.target, timeout=args.run_timeout)
    extractor = CostExtractor(args.cost_regex)
    strategy  = make_strategy(args.strategy, config, args.direction, seed=args.seed)

    param_names = list(config["variables"].keys())
    logger = ResultsLogger(args.results, param_names, args.strategy)

    best_cost = None
    best_params = None
    start_time = time.time()
    experiment = 0

    print(f"Iniciando bucle de optimización. Ctrl+C para detener.\n")

    try:
        while True:
            elapsed = time.time() - start_time
            if elapsed >= args.time_budget:
                print(f"\nPresupuesto de tiempo agotado ({args.time_budget}s).")
                break

            experiment += 1
            print(f"\n{'═' * 60}")
            print(f"Experimento {experiment} — {elapsed:.0f}s / {args.time_budget}s")

            # 1. Proponer parámetros
            params = strategy.suggest()

            # 2. Parchear el script target
            try:
                patcher.patch(params)
            except ValueError as e:
                print(f"⚠ Error al parchear: {e}")
                logger.log(params, None, "patch_error")
                continue

            # 3. Ejecutar
            stdout, stderr, returncode = runner.run()

            # 4. Extraer coste
            cost = extractor.extract(stdout)

            if cost is None or returncode != 0:
                status = "crash" if returncode != 0 else "no_cost"
                print(f"⚠ Run fallido (returncode={returncode}, cost={cost})")
                logger.log(params, None, status)
                # Informar a la estrategia bayesiana del fallo con valor neutro
                if args.strategy == "bayesian" and cost is None:
                    strategy.update(params, float("inf") if args.direction == "minimize" else 0.0)
                continue

            # 5. Actualizar estrategia
            strategy.update(params, cost)

            # 6. Registrar
            is_best = (
                best_cost is None or
                (args.direction == "minimize" and cost < best_cost) or
                (args.direction == "maximize" and cost > best_cost)
            )
            status = "best" if is_best else "keep"
            logger.log(params, cost, status)

            if is_best:
                best_cost = cost
                best_params = params.copy()
                print(f"  ★ Nuevo mejor: {cost:.6f}")

    except KeyboardInterrupt:
        print("\n\nInterrumpido por el usuario.")

    # Resumen final
    print(f"\n{'═' * 60}")
    print(f"Optimización completada — {experiment} experimentos")
    if best_params:
        print(f"Mejor coste: {best_cost:.6f}")
        print(f"Mejores parámetros:")
        for k, v in best_params.items():
            print(f"  {k} = {v}")
        print(f"\nAplicando mejores parámetros al script target...")
        patcher.patch(best_params)
        print(f"✓ {args.target} actualizado con los mejores parámetros.")
    print(f"Resultados guardados en: {args.results}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Optimizador de hiperparámetros para scripts de entrenamiento.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--target", required=True,
        help="Script Python a optimizar (e.g. abc_train.py)"
    )
    parser.add_argument(
        "--strategy", required=True, choices=["random", "bayesian"],
        help="Estrategia de optimización"
    )
    parser.add_argument(
        "--cost-regex", required=True,
        help=r'Regex con un grupo capturante para extraer el coste (e.g. "val_bpb:\s+([\d.]+)")'
    )
    parser.add_argument(
        "--config", required=True,
        help="Fichero YAML con la especificación de variables (e.g. hyperparams.yaml)"
    )
    parser.add_argument(
        "--direction", choices=["minimize", "maximize"], default="minimize",
        help="Dirección de optimización (default: minimize)"
    )
    parser.add_argument(
        "--time-budget", type=float, default=3600,
        help="Presupuesto total en segundos (default: 3600)"
    )
    parser.add_argument(
        "--run-timeout", type=float, default=700,
        help="Timeout por run individual en segundos (default: 700)"
    )
    parser.add_argument(
        "--results", default="results.tsv",
        help="Fichero TSV de resultados (default: results.tsv)"
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Semilla aleatoria para reproducibilidad (default: 42)"
    )

    args = parser.parse_args()
    run_optimization(args)


if __name__ == "__main__":
    main()
