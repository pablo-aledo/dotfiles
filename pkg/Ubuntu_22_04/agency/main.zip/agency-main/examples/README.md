To run an example:

```shell
export OPENAI_API_KEY="<your key here>"
go run ./example_name
```
