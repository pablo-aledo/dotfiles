sudo mkfs.ext4 /dev/nvme1n1
sudo mount /dev/nvme1n1 /mnt/models
sudo chown -R ubuntu:ubuntu /mnt/models
