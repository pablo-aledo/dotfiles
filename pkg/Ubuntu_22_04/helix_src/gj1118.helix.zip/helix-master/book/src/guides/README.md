# Guides

This section contains guides for adding new language server configurations,
tree-sitter grammars, textobject and rainbow bracket queries, and other similar items.
