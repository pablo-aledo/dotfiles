#!/usr/bin/env sh

HELIX_RUNTIME=/usr/lib/helix/runtime exec /usr/lib/helix/hx "$@"
