Taken from https://github.com/Ripple-TS/ripple/tree/6ccf86deaf03d48b2ca325b61bb129601628f8c6/packages/tree-sitter/queries
