use futures_util::{stream::FuturesUnordered, FutureExt};
use helix_lsp::{
    block_on,
    lsp::{
        self, CodeAction, CodeActionKind, CodeActionOrCommand, CodeActionTriggerKind,
        DiagnosticSeverity, NumberOrString,
    },
    util::{diagnostic_to_lsp_diagnostic, lsp_range_to_range, range_to_lsp_range},
    Client, LanguageServerId, OffsetEncoding,
};

use tokio_stream::StreamExt;
use tui::{text::Span, widgets::Row};

use super::{align_view, push_jump, Align, Context, Editor};

use helix_core::{
    diagnostic::DiagnosticProvider, syntax::config::LanguageServerFeature,
    text_annotations::InlineAnnotation, text_folding::ropex::RopeSliceFoldExt, Language, Rope,
    Selection, Uri,
};
use helix_stdx::{path, Url};
use helix_view::{
    action::Action as CodeActionItem,
    document::{DocumentInlayHints, DocumentInlayHintsId},
    editor::Action,
    handlers::lsp::SignatureHelpInvoked,
    icons::ICONS,
    theme::Style,
    Document, DocumentId, View,
};

use crate::{
    compositor::{self, Component, Compositor},
    job::{Callback, Job},
    ui::{self, overlay::overlaid, FileLocation, Picker, Popup, PromptEvent},
};

use std::{
    collections::{HashMap, HashSet, VecDeque},
    fmt::Display,
    future::Future,
    path::Path,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc,
    },
    time::Duration,
};

/// Gets the first language server that is attached to a document which supports a specific feature.
/// If there is no configured language server that supports the feature, this displays a status message.
/// Using this macro in a context where the editor automatically queries the LSP
/// (instead of when the user explicitly does so via a keybind like `gd`)
/// will spam the "No configured language server supports \<feature>" status message confusingly.
#[macro_export]
macro_rules! language_server_with_feature {
    ($editor:expr, $doc:expr, $feature:expr) => {{
        let language_server = $doc.language_servers_with_feature($feature).next();
        match language_server {
            Some(language_server) => language_server,
            None => {
                $editor.set_error(format!(
                    "No configured language server supports {}",
                    $feature
                ));
                return;
            }
        }
    }};
}

/// A wrapper around `lsp::Location` that swaps out the LSP URI for `helix_core::Uri` and adds
/// the server's  offset encoding.
#[derive(Debug, Clone, PartialEq, Eq)]
struct Location {
    uri: Uri,
    range: lsp::Range,
    offset_encoding: OffsetEncoding,
}

fn lsp_location_to_location(
    location: lsp::Location,
    offset_encoding: OffsetEncoding,
) -> Option<Location> {
    let uri = match location.uri.try_into() {
        Ok(uri) => uri,
        Err(err) => {
            log::warn!("discarding invalid or unsupported URI: {err}");
            return None;
        }
    };
    Some(Location {
        uri,
        range: location.range,
        offset_encoding,
    })
}

struct SymbolInformationItem {
    location: Location,
    symbol: lsp::SymbolInformation,
}

struct DiagnosticStyles {
    hint: Style,
    info: Style,
    warning: Style,
    error: Style,
}

struct PickerDiagnostic {
    location: Location,
    diag: lsp::Diagnostic,
}

fn location_to_file_location(location: &Location) -> Option<FileLocation<'_>> {
    let path = location.uri.as_path()?;
    let line = Some((
        location.range.start.line as usize,
        location.range.end.line as usize,
    ));
    Some((path.into(), line))
}

fn jump_to_location(editor: &mut Editor, location: &Location, action: Action) {
    let (view, doc) = current!(editor);
    push_jump(view, doc);

    let Some(path) = location.uri.as_path() else {
        let err = format!("unable to convert URI to filepath: {:?}", location.uri);
        editor.set_error(err);
        return;
    };
    jump_to_position(
        editor,
        path,
        location.range,
        location.offset_encoding,
        action,
    );
}

fn jump_to_position(
    editor: &mut Editor,
    path: &Path,
    range: lsp::Range,
    offset_encoding: OffsetEncoding,
    action: Action,
) {
    let doc = match editor.open(path, action) {
        Ok(id) => doc_mut!(editor, &id),
        Err(err) => {
            let err = format!("failed to open path: {:?}: {:?}", path, err);
            editor.set_error(err);
            return;
        }
    };
    let view = view_mut!(editor);
    // TODO: convert inside server
    let new_range = if let Some(new_range) = lsp_range_to_range(doc.text(), range, offset_encoding)
    {
        new_range
    } else {
        log::warn!("lsp position out of bounds - {:?}", range);
        return;
    };
    // we flip the range so that the cursor sits on the start of the symbol
    // (for example start of the function).
    doc.set_selection(view.id, Selection::single(new_range.head, new_range.anchor));
    if action.align_view(view, doc.id()) {
        align_view(doc, view, Align::Center);
    }
}

pub(crate) fn display_symbol_kind(kind: lsp::SymbolKind) -> &'static str {
    match kind {
        lsp::SymbolKind::FILE => "file",
        lsp::SymbolKind::MODULE => "module",
        lsp::SymbolKind::NAMESPACE => "namespace",
        lsp::SymbolKind::PACKAGE => "package",
        lsp::SymbolKind::CLASS => "class",
        lsp::SymbolKind::METHOD => "method",
        lsp::SymbolKind::PROPERTY => "property",
        lsp::SymbolKind::FIELD => "field",
        lsp::SymbolKind::CONSTRUCTOR => "construct",
        lsp::SymbolKind::ENUM => "enum",
        lsp::SymbolKind::INTERFACE => "interface",
        lsp::SymbolKind::FUNCTION => "function",
        lsp::SymbolKind::VARIABLE => "variable",
        lsp::SymbolKind::CONSTANT => "constant",
        lsp::SymbolKind::STRING => "string",
        lsp::SymbolKind::NUMBER => "number",
        lsp::SymbolKind::BOOLEAN => "boolean",
        lsp::SymbolKind::ARRAY => "array",
        lsp::SymbolKind::OBJECT => "object",
        lsp::SymbolKind::KEY => "key",
        lsp::SymbolKind::NULL => "null",
        lsp::SymbolKind::ENUM_MEMBER => "enum_member",
        lsp::SymbolKind::STRUCT => "struct",
        lsp::SymbolKind::EVENT => "event",
        lsp::SymbolKind::OPERATOR => "operator",
        lsp::SymbolKind::TYPE_PARAMETER => "typeparam",
        _ => {
            log::warn!("Unknown symbol kind: {:?}", kind);
            ""
        }
    }
}

#[derive(Copy, Clone, PartialEq)]
enum DiagnosticsFormat {
    ShowSourcePath,
    HideSourcePath,
}

type DiagnosticsPicker = Picker<PickerDiagnostic, DiagnosticStyles>;

fn diag_picker(
    editor: &Editor,
    diagnostics: impl IntoIterator<Item = (Uri, Vec<(lsp::Diagnostic, DiagnosticProvider)>)>,
    format: DiagnosticsFormat,
) -> DiagnosticsPicker {
    // TODO: drop current_path comparison and instead use workspace: bool flag?

    // flatten the map to a vec of (url, diag) pairs
    let mut flat_diag = Vec::new();
    for (uri, diags) in diagnostics {
        flat_diag.reserve(diags.len());

        for (diag, provider) in diags {
            if let Some(ls) = provider
                .language_server_id()
                .and_then(|id| editor.language_server_by_id(id))
            {
                flat_diag.push(PickerDiagnostic {
                    location: Location {
                        uri: uri.clone(),
                        range: diag.range,
                        offset_encoding: ls.offset_encoding(),
                    },
                    diag,
                });
            }
        }
    }

    flat_diag.sort_by(|a, b| {
        a.diag
            .severity
            .unwrap_or(lsp::DiagnosticSeverity::HINT)
            .cmp(&b.diag.severity.unwrap_or(lsp::DiagnosticSeverity::HINT))
    });

    let styles = DiagnosticStyles {
        hint: editor.theme.get("hint"),
        info: editor.theme.get("info"),
        warning: editor.theme.get("warning"),
        error: editor.theme.get("error"),
    };

    let mut columns = vec![
        ui::PickerColumn::new(
            "severity",
            |item: &PickerDiagnostic, styles: &DiagnosticStyles| {
                let icons = ICONS.load();
                match item.diag.severity {
                    Some(DiagnosticSeverity::HINT) => {
                        Span::styled(format!("{} HINT", icons.diagnostic().hint()), styles.hint)
                    }
                    Some(DiagnosticSeverity::INFORMATION) => {
                        Span::styled(format!("{} INFO", icons.diagnostic().info()), styles.info)
                    }
                    Some(DiagnosticSeverity::WARNING) => Span::styled(
                        format!("{} WARN", icons.diagnostic().warning()),
                        styles.warning,
                    ),
                    Some(DiagnosticSeverity::ERROR) => Span::styled(
                        format!("{} ERROR", icons.diagnostic().error()),
                        styles.error,
                    ),
                    _ => Span::raw(""),
                }
                .into()
            },
        ),
        ui::PickerColumn::new("source", |item: &PickerDiagnostic, _| {
            item.diag.source.as_deref().unwrap_or("").into()
        }),
        ui::PickerColumn::new("message", |item: &PickerDiagnostic, _| {
            item.diag.message.as_str().into()
        }),
        ui::PickerColumn::new("code", |item: &PickerDiagnostic, _| {
            match item.diag.code.as_ref() {
                Some(NumberOrString::Number(n)) => n.to_string().into(),
                Some(NumberOrString::String(s)) => s.as_str().into(),
                None => "".into(),
            }
        }),
    ];
    let mut primary_column = 2; // message

    if format == DiagnosticsFormat::ShowSourcePath {
        columns.insert(
            // between message and code
            3,
            ui::PickerColumn::new("path", |item: &PickerDiagnostic, _| {
                if let Some(path) = item.location.uri.as_path() {
                    path::get_truncated_path(path)
                        .to_string_lossy()
                        .to_string()
                        .into()
                } else {
                    Default::default()
                }
            }),
        );
        primary_column += 1;
    }

    Picker::new(
        columns,
        primary_column,
        flat_diag,
        styles,
        move |cx, diag, action| {
            jump_to_location(cx.editor, &diag.location, action);
            let (view, doc) = current!(cx.editor);
            view.diagnostics_handler
                .immediately_show_diagnostic(doc, view.id);
        },
    )
    .with_preview(move |_editor, diag| location_to_file_location(&diag.location))
    .truncate_start(false)
}

pub fn symbol_picker(cx: &mut Context) {
    fn nested_to_flat(
        list: &mut Vec<SymbolInformationItem>,
        file: &lsp::TextDocumentIdentifier,
        uri: &Uri,
        symbol: lsp::DocumentSymbol,
        offset_encoding: OffsetEncoding,
    ) {
        #[allow(deprecated)]
        list.push(SymbolInformationItem {
            symbol: lsp::SymbolInformation {
                name: symbol.name,
                kind: symbol.kind,
                tags: symbol.tags,
                deprecated: symbol.deprecated,
                location: lsp::Location::new(file.uri.clone(), symbol.selection_range),
                container_name: None,
            },
            location: Location {
                uri: uri.clone(),
                range: symbol.selection_range,
                offset_encoding,
            },
        });
        for child in symbol.children.into_iter().flatten() {
            nested_to_flat(list, file, uri, child, offset_encoding);
        }
    }
    let doc = doc!(cx.editor);

    let mut seen_language_servers = HashSet::new();

    let mut futures: FuturesUnordered<_> = doc
        .language_servers_with_feature(LanguageServerFeature::DocumentSymbols)
        .filter(|ls| seen_language_servers.insert(ls.id()))
        .map(|language_server| {
            let request = language_server.document_symbols(doc.identifier()).unwrap();
            let offset_encoding = language_server.offset_encoding();
            let doc_id = doc.identifier();
            let doc_uri = doc
                .uri()
                .expect("docs with active language servers must be backed by paths");

            async move {
                let symbols = match request.await? {
                    Some(symbols) => symbols,
                    None => return anyhow::Ok(vec![]),
                };
                // lsp has two ways to represent symbols (flat/nested)
                // convert the nested variant to flat, so that we have a homogeneous list
                let symbols = match symbols {
                    lsp::DocumentSymbolResponse::Flat(symbols) => symbols
                        .into_iter()
                        .map(|symbol| SymbolInformationItem {
                            location: Location {
                                uri: doc_uri.clone(),
                                range: symbol.location.range,
                                offset_encoding,
                            },
                            symbol,
                        })
                        .collect(),
                    lsp::DocumentSymbolResponse::Nested(symbols) => {
                        let mut flat_symbols = Vec::new();
                        for symbol in symbols {
                            nested_to_flat(
                                &mut flat_symbols,
                                &doc_id,
                                &doc_uri,
                                symbol,
                                offset_encoding,
                            )
                        }
                        flat_symbols
                    }
                };
                Ok(symbols)
            }
        })
        .collect();

    if futures.is_empty() {
        cx.editor
            .set_error("No configured language server supports document symbols");
        return;
    }

    cx.jobs.callback(async move {
        let mut symbols = Vec::new();
        while let Some(response) = futures.next().await {
            match response {
                Ok(mut items) => symbols.append(&mut items),
                Err(err) => log::error!("Error requesting document symbols: {err}"),
            }
        }
        let call = move |editor: &mut Editor, compositor: &mut Compositor| {
            let columns = [
                ui::PickerColumn::new("kind", |item: &SymbolInformationItem, _| {
                    let icons = ICONS.load();
                    let name = display_symbol_kind(item.symbol.kind);

                    if let Some(icon) = icons.kind().get(name) {
                        if let Some(color) = icon.color() {
                            Span::styled(
                                format!("{}  {name}", icon.glyph()),
                                Style::default().fg(color),
                            )
                            .into()
                        } else {
                            format!("{}  {name}", icon.glyph()).into()
                        }
                    } else {
                        name.into()
                    }
                }),
                // Some symbols in the document symbol picker may have a URI that isn't
                // the current file. It should be rare though, so we concatenate that
                // URI in with the symbol name in this picker.
                ui::PickerColumn::new("name", |item: &SymbolInformationItem, _| {
                    item.symbol.name.as_str().into()
                }),
                ui::PickerColumn::new("container", |item: &SymbolInformationItem, _| {
                    item.symbol
                        .container_name
                        .as_deref()
                        .unwrap_or_default()
                        .into()
                }),
            ];

            let picker = Picker::new(
                columns,
                1, // name column
                symbols,
                (),
                move |cx, item, action| {
                    jump_to_location(cx.editor, &item.location, action);
                },
            )
            .with_preview(move |_editor, item| location_to_file_location(&item.location))
            .truncate_start(false)
            .with_title("Document Symbols");

            compositor.push(Box::new(overlaid(
                picker,
                editor.config().fullscreen_overlay,
            )))
        };

        Ok(Callback::EditorCompositor(Box::new(call)))
    });
}

pub fn workspace_symbol_picker(cx: &mut Context) {
    use crate::ui::picker::Injector;

    let doc = doc!(cx.editor);
    if doc
        .language_servers_with_feature(LanguageServerFeature::WorkspaceSymbols)
        .count()
        == 0
    {
        cx.editor
            .set_error("No configured language server supports workspace symbols");
        return;
    }

    let get_symbols = |pattern: &str, editor: &mut Editor, _data, injector: &Injector<_, _>| {
        let doc = doc!(editor);
        let mut seen_language_servers = HashSet::new();
        let mut futures: FuturesUnordered<_> = doc
            .language_servers_with_feature(LanguageServerFeature::WorkspaceSymbols)
            .filter(|ls| seen_language_servers.insert(ls.id()))
            .map(|language_server| {
                let request = language_server
                    .workspace_symbols(pattern.to_string())
                    .unwrap();
                let offset_encoding = language_server.offset_encoding();
                async move {
                    let symbols = request
                        .await?
                        .and_then(|resp| match resp {
                            lsp::WorkspaceSymbolResponse::Flat(symbols) => Some(symbols),
                            lsp::WorkspaceSymbolResponse::Nested(_) => None,
                        })
                        .unwrap_or_default();

                    let response: Vec<_> = symbols
                        .into_iter()
                        .filter_map(|symbol| {
                            let uri = match Uri::try_from(&symbol.location.uri) {
                                Ok(uri) => uri,
                                Err(err) => {
                                    log::warn!("discarding symbol with invalid URI: {err}");
                                    return None;
                                }
                            };
                            Some(SymbolInformationItem {
                                location: Location {
                                    uri,
                                    range: symbol.location.range,
                                    offset_encoding,
                                },
                                symbol,
                            })
                        })
                        .collect();

                    anyhow::Ok(response)
                }
            })
            .collect();

        if futures.is_empty() {
            editor.set_error("No configured language server supports workspace symbols");
        }

        let injector = injector.clone();
        async move {
            while let Some(response) = futures.next().await {
                match response {
                    Ok(items) => {
                        for item in items {
                            injector.push(item)?;
                        }
                    }
                    Err(err) => log::error!("Error requesting workspace symbols: {err}"),
                }
            }
            Ok(())
        }
        .boxed()
    };
    let columns = [
        ui::PickerColumn::new("kind", |item: &SymbolInformationItem, _| {
            let icons = ICONS.load();
            let name = display_symbol_kind(item.symbol.kind);

            if let Some(icon) = icons.kind().get(name) {
                if let Some(color) = icon.color() {
                    Span::styled(
                        format!("{}  {name}", icon.glyph()),
                        Style::default().fg(color),
                    )
                    .into()
                } else {
                    format!("{}  {name}", icon.glyph()).into()
                }
            } else {
                name.into()
            }
        }),
        ui::PickerColumn::new("name", |item: &SymbolInformationItem, _| {
            item.symbol.name.as_str().into()
        })
        .without_filtering(),
        ui::PickerColumn::new("container", |item: &SymbolInformationItem, _| {
            item.symbol
                .container_name
                .as_deref()
                .unwrap_or_default()
                .into()
        }),
        ui::PickerColumn::new("path", |item: &SymbolInformationItem, _| {
            if let Some(path) = item.location.uri.as_path() {
                path::get_relative_path(path)
                    .to_string_lossy()
                    .to_string()
                    .into()
            } else {
                item.symbol.location.uri.to_string().into()
            }
        }),
    ];

    let picker = Picker::new(
        columns,
        1, // name column
        [],
        (),
        move |cx, item, action| {
            jump_to_location(cx.editor, &item.location, action);
        },
    )
    .with_preview(|_editor, item| location_to_file_location(&item.location))
    .with_dynamic_query(get_symbols, None)
    .truncate_start(false)
    .with_title("Workspace Symbols");

    cx.push_layer(Box::new(overlaid(
        picker,
        cx.editor.config().fullscreen_overlay,
    )));
}

pub fn diagnostics_picker(cx: &mut Context) {
    let doc = doc!(cx.editor);
    if let Some(uri) = doc.uri() {
        let diagnostics = cx.editor.diagnostics.get(&uri).cloned().unwrap_or_default();
        let picker = diag_picker(
            cx.editor,
            [(uri, diagnostics)],
            DiagnosticsFormat::HideSourcePath,
        )
        .with_title("Diagnostics");
        cx.push_layer(Box::new(overlaid(
            picker,
            cx.editor.config().fullscreen_overlay,
        )));
    }
}

pub fn workspace_diagnostics_picker(cx: &mut Context) {
    // TODO not yet filtered by LanguageServerFeature, need to do something similar as Document::shown_diagnostics here for all open documents
    if cx.editor.config().lsp.workspace_diagnostics && workspace_diagnostics_collection(cx) {
        // The picker opens once all pull requests have settled (or timed out).
        return;
    }

    // No language server candidates (or a collection is already running): fall back to
    // the diagnostics that have been published so far.
    let diagnostics = cx.editor.diagnostics.clone();
    let picker = diag_picker(cx.editor, diagnostics, DiagnosticsFormat::ShowSourcePath)
        .with_title("Workspace Diagnostics");
    cx.push_layer(Box::new(overlaid(
        picker,
        cx.editor.config().fullscreen_overlay,
    )));
}

fn push_workspace_diagnostics_picker(editor: &mut Editor, compositor: &mut Compositor) {
    let fullscreen = editor.config().fullscreen_overlay;
    let picker = diag_picker(
        editor,
        editor.diagnostics.clone(),
        DiagnosticsFormat::ShowSourcePath,
    )
    .with_title("Workspace Diagnostics");
    compositor.push(Box::new(overlaid(picker, fullscreen)));
}

/// Maximum number of files diagnostics are pulled for in a single workspace
/// diagnostics collection.
const MAX_WORKSPACE_FILES: usize = 1000;
/// Files larger than this are skipped when collecting workspace diagnostics.
const MAX_WORKSPACE_FILE_BYTES: u64 = 2 * 1024 * 1024;
/// Maximum number of language server requests in flight at the same time while
/// collecting workspace diagnostics.
const WORKSPACE_DIAGNOSTICS_CONCURRENCY: usize = 32;
/// After this much time the diagnostics collected so far are shown, even when some
/// pull requests did not settle in time.
const WORKSPACE_DIAGNOSTICS_TIMEOUT: Duration = Duration::from_secs(30);

/// Set while workspace diagnostics are being collected.
static COLLECTING: AtomicBool = AtomicBool::new(false);

/// A diagnostics pull request sent to a language server on behalf of a file that is
/// not opened (or, for the workspace variant, of the whole workspace).
#[derive(Clone)]
enum WorkspaceDiagnosticsRequest {
    /// `textDocument/diagnostic` for a single file.
    Document {
        server: Arc<Client>,
        /// The file the request is for.
        uri: Uri,
        /// The file URI as it is sent over LSP.
        url: Url,
        identifier: Option<Arc<str>>,
    },
    /// `workspace/diagnostic` for the whole workspace.
    Workspace {
        server: Arc<Client>,
        identifier: Option<Arc<str>>,
    },
}

/// The result of either of the two pull diagnostics request kinds.
enum WorkspaceDiagnosticsResult {
    Document(lsp::DocumentDiagnosticReportResult),
    Workspace(lsp::WorkspaceDiagnosticReportResult),
}

impl WorkspaceDiagnosticsRequest {
    async fn execute(self) -> Result<WorkspaceDiagnosticsResult, helix_lsp::Error> {
        match self {
            Self::Document { server, url, .. } => server
                .text_document_diagnostic(lsp::TextDocumentIdentifier { uri: url }, None)
                .ok_or_else(|| {
                    helix_lsp::Error::Other(anyhow::anyhow!(
                        "server does not advertise a pull diagnostics provider"
                    ))
                })?
                .await
                .map(WorkspaceDiagnosticsResult::Document),
            Self::Workspace { server, .. } => server
                .workspace_diagnostics(Vec::new())
                .ok_or_else(|| {
                    helix_lsp::Error::Other(anyhow::anyhow!(
                        "server does not advertise workspace diagnostics support"
                    ))
                })?
                .await
                .map(WorkspaceDiagnosticsResult::Workspace),
        }
    }
}

/// Apply a full pulled diagnostics report for one file.
///
/// When the language server reports that a file without an open document has no
/// diagnostics anymore, the provider's diagnostics for that file are pruned
/// directly: `handle_lsp_diagnostics` retains such entries on empty publications
/// (so that they survive the empty republish some servers send after a document
/// close), but a pull response is authoritative and must clear them or stale
/// diagnostics would never disappear from the workspace diagnostics picker.
pub(crate) fn apply_pulled_diagnostics(
    editor: &mut Editor,
    provider: &DiagnosticProvider,
    uri: Uri,
    version: Option<i32>,
    items: Vec<lsp::Diagnostic>,
) {
    let file_is_open = uri
        .as_path()
        .is_some_and(|path| editor.document_id_by_path(path).is_some());
    if items.is_empty() && !file_is_open {
        editor.clear_diagnostics(provider, &uri);
    } else {
        editor.handle_lsp_diagnostics(provider, uri, version, items);
    }
}

/// Store the diagnostics of a settled pull request in the editor diagnostics map.
fn apply_workspace_diagnostics_response(
    editor: &mut Editor,
    request: WorkspaceDiagnosticsRequest,
    result: WorkspaceDiagnosticsResult,
) {
    match (request, result) {
        (
            WorkspaceDiagnosticsRequest::Document {
                server,
                uri,
                identifier,
                ..
            },
            WorkspaceDiagnosticsResult::Document(result),
        ) => {
            let provider = DiagnosticProvider::Lsp {
                server_id: server.id(),
                identifier,
            };
            let lsp::DocumentDiagnosticReportResult::Report(report) = result else {
                // Partial results are not supported.
                return;
            };
            let lsp::DocumentDiagnosticReport::Full(report) = report else {
                // The report was unchanged since some previous result id, but we do not
                // keep result ids for files without an open document.
                return;
            };
            apply_pulled_diagnostics(
                editor,
                &provider,
                uri,
                None,
                report.full_document_diagnostic_report.items,
            );
        }
        (
            WorkspaceDiagnosticsRequest::Workspace { server, identifier },
            WorkspaceDiagnosticsResult::Workspace(result),
        ) => {
            let provider = DiagnosticProvider::Lsp {
                server_id: server.id(),
                identifier,
            };
            let lsp::WorkspaceDiagnosticReportResult::Report(report) = result else {
                // Partial results are not supported.
                return;
            };
            for report in report.items {
                let lsp::WorkspaceDocumentDiagnosticReport::Full(report) = report else {
                    // The report was unchanged since some previous result id, but we do
                    // not keep result ids for files without an open document.
                    continue;
                };
                let Ok(uri) = helix_core::Uri::try_from(report.uri) else {
                    continue;
                };
                let version = report
                    .version
                    .and_then(|version| i32::try_from(version).ok());
                apply_pulled_diagnostics(
                    editor,
                    &provider,
                    uri,
                    version,
                    report.full_document_diagnostic_report.items,
                );
            }
        }
        _ => {
            // The response could not be matched with the request; ignore it.
        }
    }
}

/// Collect diagnostics for the workspace from the running language servers and open
/// the workspace diagnostics picker once the pull requests settle:
///
/// * A `workspace/diagnostic` request is sent to every running server advertising the
///   workspace pull diagnostics capability. These cover all files the server knows
///   about, whether they are open in helix or not.
/// * Otherwise `textDocument/diagnostic` requests are sent for every workspace file
///   (honoring the same ignore rules as the file picker) served by a running language
///   server that supports pull diagnostics but not workspace-level requests. For
///   this no documents are opened in helix; language servers compute the diagnostics
///   for such files from the file system.
///
/// Push-only servers (which only publish diagnostics for files that are open in
/// helix) don't have diagnostics pulled here; the diagnostics such servers last
/// published for a file remain in the picker even after the file closes.
///
/// Returns true if collection was scheduled, in which case the diagnostics picker is
/// shown once all pull requests settled (or after a timeout).
fn workspace_diagnostics_collection(cx: &mut Context) -> bool {
    use crate::filter_picker_entry;

    if COLLECTING.swap(true, Ordering::SeqCst) {
        // Another collection is under way; open the picker for what was collected so far.
        return false;
    }

    let root = doc!(cx.editor).workspace_root().to_path_buf();
    let file_picker_config = cx.editor.config().file_picker.clone();
    let loader = cx.editor.syn_loader.load_full();

    // The language servers running (and initialized) right now, by config name.
    let mut running_servers: HashMap<String, Vec<Arc<Client>>> = HashMap::new();
    for client in cx.editor.language_servers.iter_clients() {
        if client.is_initialized() {
            running_servers
                .entry(client.name().to_owned())
                .or_default()
                .push(client.clone());
        }
    }

    // Collect per language which running servers can serve pull requests for files of
    // that language, and (separately) the servers supporting the workspace level
    // request.
    let mut workspace_server_ids = HashSet::new();
    let mut language_servers: HashMap<Language, Vec<Arc<Client>>> = HashMap::new();
    let mut workspace_servers: Vec<Arc<Client>> = Vec::new();
    for language_config in loader.language_configs() {
        for lsp_features in &language_config.language_servers {
            if !lsp_features.has_feature(LanguageServerFeature::PullDiagnostics) {
                continue;
            }
            let Some(clients) = running_servers.get(lsp_features.name.as_str()) else {
                continue;
            };
            for client in clients {
                let Some(diagnostic_provider) = client.capabilities().diagnostic_provider.as_ref()
                else {
                    continue;
                };
                let options = match diagnostic_provider {
                    lsp::DiagnosticServerCapabilities::Options(options) => options,
                    lsp::DiagnosticServerCapabilities::RegistrationOptions(options) => {
                        &options.diagnostic_options
                    }
                };
                if options.workspace_diagnostics {
                    // A workspace level request covers all of the files this server
                    // knows about, so per file requests aren't needed.
                    if workspace_server_ids.insert(client.id()) {
                        workspace_servers.push(client.clone());
                    }
                } else {
                    language_servers
                        .entry(language_config.language())
                        .or_default()
                        .push(client.clone());
                }
            }
        }
    }
    let language_servers = Arc::new(language_servers);

    cx.jobs.callback(async move {
        // The walk is potentially slow (many files, ignore rule evaluation), so run it
        // on the blocking thread pool.
        let walked_files = {
            let language_servers = language_servers.clone();
            tokio::task::spawn_blocking(move || {
                let absolute_root = root.canonicalize().unwrap_or_else(|_| root.clone());
                let mut walk_builder = ignore::WalkBuilder::new(&root);
                walk_builder
                    .hidden(file_picker_config.hidden)
                    .parents(file_picker_config.parents)
                    .ignore(file_picker_config.ignore)
                    .follow_links(file_picker_config.follow_symlinks)
                    .git_ignore(file_picker_config.git_ignore)
                    .git_global(file_picker_config.git_global)
                    .git_exclude(file_picker_config.git_exclude)
                    .max_depth(file_picker_config.max_depth)
                    .filter_entry(move |entry| {
                        filter_picker_entry(
                            entry,
                            &absolute_root,
                            file_picker_config.deduplicate_links,
                        )
                    });
                walk_builder.add_custom_ignore_filename(helix_loader::config_dir().join("ignore"));
                walk_builder.add_custom_ignore_filename(".helix/ignore");

                let mut files = Vec::new();
                for entry in walk_builder.build() {
                    if files.len() >= MAX_WORKSPACE_FILES {
                        break;
                    }
                    let Ok(entry) = entry else { continue };
                    if !entry
                        .file_type()
                        .is_some_and(|file_type| file_type.is_file())
                    {
                        continue;
                    }
                    let Ok(metadata) = entry.metadata() else {
                        continue;
                    };
                    if metadata.len() > MAX_WORKSPACE_FILE_BYTES {
                        continue;
                    }
                    let path = entry.into_path();
                    let Some(language) = loader.language_for_filename(&path) else {
                        continue;
                    };
                    let Some(clients) = language_servers.get(&language) else {
                        continue;
                    };
                    files.push((path, clients.clone()));
                }
                files
            })
            .await
            .unwrap_or_default()
        };

        crate::job::dispatch_blocking(move |editor, compositor| {
            let mut requests: Vec<WorkspaceDiagnosticsRequest> = workspace_servers
                .into_iter()
                .map(|client| WorkspaceDiagnosticsRequest::Workspace {
                    identifier: pull_diagnostics_identifier(&client),
                    server: client,
                })
                .collect();

            let mut file_count = 0usize;
            for (path, clients) in walked_files {
                // Documents that are open have their pull diagnostics refreshed by the
                // regular engine, so skip them. Canonicalize first: document paths are
                // stored canonicalized, walk entries may not be.
                let path = helix_stdx::path::canonicalize(&path);
                if editor.document_id_by_path(&path).is_some() {
                    continue;
                }
                if file_count >= MAX_WORKSPACE_FILES {
                    break;
                }
                let uri = Uri::from(path);
                let Ok(url) = uri.to_url() else { continue };
                for client in clients {
                    requests.push(WorkspaceDiagnosticsRequest::Document {
                        identifier: pull_diagnostics_identifier(&client),
                        server: client.clone(),
                        uri: uri.clone(),
                        url: url.clone(),
                    });
                }
                file_count += 1;
            }

            if requests.is_empty() {
                COLLECTING.store(false, Ordering::SeqCst);
                editor
                    .set_status("No language server supports pull diagnostics for this workspace");
                push_workspace_diagnostics_picker(editor, compositor);
                return;
            }
            editor.set_status(format!(
                "Collecting workspace diagnostics ({file_count} files)..."
            ));

            tokio::spawn(async move {
                let deadline = tokio::time::Instant::now() + WORKSPACE_DIAGNOSTICS_TIMEOUT;
                let mut queue = requests;
                while !queue.is_empty() && tokio::time::Instant::now() < deadline {
                    let count = queue.len().min(WORKSPACE_DIAGNOSTICS_CONCURRENCY);
                    let mut batch: FuturesUnordered<_> = queue
                        .drain(..count)
                        .map(|request| async move {
                            let result = request.clone().execute().await;
                            (request, result)
                        })
                        .collect();

                    while let Ok(Some((request, result))) =
                        tokio::time::timeout_at(deadline, batch.next()).await
                    {
                        match result {
                            Ok(result) => {
                                crate::job::dispatch(move |editor, _| {
                                    apply_workspace_diagnostics_response(editor, request, result);
                                })
                                .await;
                            }
                            Err(err) => {
                                log::debug!("workspace diagnostics pull failed: {err}");
                            }
                        }
                    }
                }

                crate::job::dispatch(move |editor, compositor| {
                    COLLECTING.store(false, Ordering::SeqCst);
                    push_workspace_diagnostics_picker(editor, compositor);
                })
                .await;
            });
        });

        Ok(Callback::Editor(Box::new(|_| {})))
    });
    true
}

/// The identifier a language server advertises for its pull diagnostics provider, if
/// any.
fn pull_diagnostics_identifier(client: &Client) -> Option<Arc<str>> {
    match client.capabilities().diagnostic_provider.as_ref()? {
        lsp::DiagnosticServerCapabilities::Options(options) => options.identifier.clone(),
        lsp::DiagnosticServerCapabilities::RegistrationOptions(options) => {
            options.diagnostic_options.identifier.clone()
        }
    }
}

impl ui::menu::Item for CodeActionItem {
    type Data = ();
    fn format(&self, _data: &Self::Data) -> Row<'_> {
        self.title().into()
    }
}

pub fn code_action(cx: &mut Context) {
    code_action_inner(cx, false);
}

pub fn code_action_picker(cx: &mut Context) {
    code_action_inner(cx, true);
}

pub fn code_action_inner(cx: &mut Context, use_picker: bool) {
    let (view, doc) = current!(cx.editor);

    let selection_range = doc.selection(view.id).primary();

    let mut futures: FuturesUnordered<_> =
        code_actions_for_range(doc, selection_range, None, CodeActionTriggerKind::INVOKED)
            .into_iter()
            .map(|(request, ls_id)| async move {
                let Some(mut actions) = request.await? else {
                    return anyhow::Ok(Vec::new());
                };

                // remove disabled code actions
                actions.retain(|action| {
                    matches!(
                        action,
                        CodeActionOrCommand::Command(_)
                            | CodeActionOrCommand::CodeAction(CodeAction { disabled: None, .. })
                    )
                });

                Ok(actions
                    .into_iter()
                    .map(|lsp_item| CodeActionItem::lsp(ls_id, lsp_item))
                    .collect())
            })
            .collect();

    if futures.is_empty() {
        cx.editor
            .set_error("No configured language server supports code actions");
        return;
    }

    cx.jobs.callback(async move {
        let mut actions = Vec::new();

        while let Some(output) = futures.next().await {
            match output {
                Ok(mut items) => actions.append(&mut items),
                Err(err) => log::error!("while gathering code actions: {err}"),
            }
        }

        if use_picker {
            code_action_inner_picker(actions)
        } else {
            code_action_inner_menu(actions)
        }
    });
}

fn code_action_inner_menu(actions: Vec<CodeActionItem>) -> Result<Callback, anyhow::Error> {
    let call = move |editor: &mut Editor, compositor: &mut Compositor| {
        if actions.is_empty() {
            editor.set_error("No code actions available");
            return;
        }
        let mut picker = ui::Menu::new(actions, (), move |editor, action, event| {
            if event != PromptEvent::Validate {
                return;
            }

            let action = action.unwrap();

            action.execute(editor);
        });
        picker.move_down();

        let popup = Popup::new("code-action", picker).with_scrollbar(false);

        compositor.replace_or_push("code-action", popup);
    };

    Ok(Callback::EditorCompositor(Box::new(call)))
}

fn code_action_inner_picker(actions: Vec<CodeActionItem>) -> Result<Callback, anyhow::Error> {
    let call = move |editor: &mut Editor, compositor: &mut Compositor| {
        if actions.is_empty() {
            editor.set_error("No code actions available");
            return;
        }
        let columns = [ui::PickerColumn::new(
            "action",
            |item: &CodeActionItem, _| item.title().into(),
        )];

        let picker = ui::Picker::new(
            columns,
            0,
            actions,
            (),
            move |cx: &mut crate::compositor::Context, action, _| {
                action.execute(cx.editor);
            },
        )
        .with_title("Code Actions");
        compositor.push(Box::new(overlaid(
            picker,
            editor.config().fullscreen_overlay,
        )));
    };
    Ok(Callback::EditorCompositor(Box::new(call)))
}

// Extracting this to a type alias would require boxing this future
#[allow(clippy::type_complexity)]
pub(crate) fn code_actions_for_range(
    doc: &Document,
    range: helix_core::Range,
    only: Option<Vec<CodeActionKind>>,
    trigger_kind: CodeActionTriggerKind,
) -> Vec<(
    impl Future<Output = Result<Option<Vec<CodeActionOrCommand>>, helix_lsp::Error>>,
    LanguageServerId,
)> {
    let mut seen_language_servers = HashSet::new();

    doc.language_servers_with_feature(LanguageServerFeature::CodeAction)
        .filter(|ls| seen_language_servers.insert(ls.id()))
        // TODO this should probably already been filtered in something like "language_servers_with_feature"
        .filter_map(|language_server| {
            let offset_encoding = language_server.offset_encoding();
            let language_server_id = language_server.id();
            let lsp_range = range_to_lsp_range(doc.text(), range, offset_encoding);
            // Filter and convert overlapping diagnostics
            let code_action_context = lsp::CodeActionContext {
                diagnostics: doc
                    .diagnostics()
                    .iter()
                    .filter(|&diag| {
                        range.overlaps(&helix_core::Range::new(diag.range.start, diag.range.end))
                    })
                    .map(|diag| diagnostic_to_lsp_diagnostic(doc.text(), diag, offset_encoding))
                    .collect(),
                only: only.clone(),
                trigger_kind: Some(trigger_kind),
            };
            let code_action_request =
                language_server.code_actions(doc.identifier(), lsp_range, code_action_context)?;
            Some((code_action_request, language_server_id))
        })
        .collect::<Vec<_>>()
}

/// Build the job chain that runs a document's configured `code-actions-on-save`
/// kinds, in order, each against the latest document state, before running
/// `tail` (the auto-format / save job). Returns `tail` unchanged when nothing is
/// configured.
pub fn code_actions_on_save(
    cx: &compositor::Context,
    doc_id: DocumentId,
    tail: Option<Job>,
) -> Option<Job> {
    let kinds = doc!(cx.editor, &doc_id)
        .language_config()
        .and_then(|config| config.code_actions_on_save.clone());
    let Some(kinds) = kinds else {
        return tail;
    };
    let kinds: VecDeque<CodeActionKind> = kinds.into_iter().map(CodeActionKind::from).collect();
    code_action_on_save_step(doc_id, kinds, tail)
}

/// One link of the on-save chain: request the next kind's actions on the current
/// document, apply them, then recurse for the rest. Each link is built lazily (as
/// a `Followup`) so it reads the document after the previous link's edits, and
/// runs the configured kinds strictly in order.
fn code_action_on_save_step(
    doc_id: DocumentId,
    mut kinds: VecDeque<CodeActionKind>,
    tail: Option<Job>,
) -> Option<Job> {
    let Some(kind) = kinds.pop_front() else {
        // All kinds applied. Fall through to auto-format / save.
        return tail;
    };

    let build_request = move |editor: &mut Editor| -> Option<Job> {
        // The document could have been closed mid-chain
        if !editor.documents.contains_key(&doc_id) {
            return None;
        }
        let doc = doc!(editor, &doc_id);
        let version = doc.version();
        let full_range = helix_core::Range::new(0, doc.text().len_chars());
        let Some((request, ls_id)) = code_actions_for_range(
            doc,
            full_range,
            Some(vec![kind.clone()]),
            CodeActionTriggerKind::INVOKED,
        )
        .into_iter()
        .next() else {
            // No server offers this kind for the document: skip to the next.
            return code_action_on_save_step(doc_id, kinds, tail);
        };

        let future = async move {
            let actions = request.await?;
            let resolve = move |editor: &mut Editor| -> Option<Job> {
                resolve_and_apply_code_actions_of_kind(
                    editor, doc_id, version, ls_id, kind, kinds, tail, actions,
                )
            };
            Ok(Callback::Followup(Box::new(resolve)))
        };
        Some(Job::with_callback(future).wait_before_exiting())
    };

    Some(
        Job::with_callback(async move { Ok(Callback::Followup(Box::new(build_request))) })
            .wait_before_exiting(),
    )
}

/// An action matches a requested kind when its kind equals the request or is a
/// sub-kind (`source.fixAll.eslint` matches `source.fixAll`, per the LSP kind
/// hierarchy). Actions without a kind are skipped, so a server that ignores the
/// `only` filter can't slip an unrelated action into a save.
fn code_action_kind_matches(action: &CodeAction, requested: &CodeActionKind) -> bool {
    action.kind.as_ref().is_some_and(|kind| {
        let (kind, requested) = (kind.as_str(), requested.as_str());
        kind == requested
            || (kind.starts_with(requested) && kind[requested.len()..].starts_with('.'))
    })
}

/// One matching action, in server order: an edit ready to apply, or a  future
/// resolving the action's edit off the event loop.
///
/// Keeping one ordered list preserves apply order, which matters when a kind yields
/// several edits.
type ResolveFuture =
    std::pin::Pin<Box<dyn Future<Output = Result<lsp::CodeAction, helix_lsp::Error>> + Send>>;
enum ResolveStep {
    Ready(lsp::WorkspaceEdit),
    Resolve(ResolveFuture),
}

/// Resolve (off the event loop) and apply the actions matching `kind`, then
/// continue the on-save chain. The resolve is awaited in the returned job.
#[allow(clippy::too_many_arguments)]
fn resolve_and_apply_code_actions_of_kind(
    editor: &mut Editor,
    doc_id: DocumentId,
    version: i32,
    ls_id: LanguageServerId,
    kind: CodeActionKind,
    kinds: VecDeque<CodeActionKind>,
    tail: Option<Job>,
    actions: Option<Vec<CodeActionOrCommand>>,
) -> Option<Job> {
    // Build the matching actions, in order, while holding the language-server
    // borrow, resolving only those the server left incomplete.
    let prepared = (|| -> Option<(OffsetEncoding, Vec<ResolveStep>)> {
        let actions = actions?;
        if editor.documents.get(&doc_id)?.version() != version {
            log::debug!("code-actions-on-save: document changed, skipping {kind:?}");
            return None;
        }
        let ls = editor.language_server_by_id(ls_id)?;
        let steps = actions
            .iter()
            .filter_map(|action| match action {
                CodeActionOrCommand::CodeAction(ca) if ca.disabled.is_none() => Some(ca),
                _ => None,
            })
            .filter(|ca| code_action_kind_matches(ca, &kind))
            .filter_map(|ca| {
                // Resolve only when the server left out the edit or command.
                if ca.edit.is_none() || ca.command.is_none() {
                    if let Some(future) = ls.resolve_code_action(ca) {
                        return Some(ResolveStep::Resolve(Box::pin(future)));
                    }
                }
                ca.edit.clone().map(ResolveStep::Ready)
            })
            .collect();
        Some((ls.offset_encoding(), steps))
    })();
    let Some((offset_encoding, steps)) = prepared else {
        return code_action_on_save_step(doc_id, kinds, tail);
    };

    let future = async move {
        let mut edits = Vec::new();
        for step in steps {
            match step {
                ResolveStep::Ready(edit) => edits.push(edit),
                ResolveStep::Resolve(future) => match future.await {
                    Ok(resolved) => edits.extend(resolved.edit),
                    Err(err) => log::error!("code-actions-on-save: resolve failed: {err:?}"),
                },
            }
        }
        let apply = move |editor: &mut Editor| -> Option<Job> {
            // A plain :w runs this in the live event loop so the document can
            // change while resolving: re-check the version and skip rather than
            // applying a stale edit.
            if editor
                .documents
                .get(&doc_id)
                .is_some_and(|doc| doc.version() == version)
            {
                for edit in &edits {
                    if let Err(err) = editor.apply_workspace_edit(offset_encoding, edit) {
                        log::error!("code-actions-on-save: failed to apply edit: {err:?}");
                    }
                }
            } else {
                log::debug!("code-actions-on-save: document changed, skipping {kind:?}");
            }
            code_action_on_save_step(doc_id, kinds, tail)
        };
        Ok(Callback::Followup(Box::new(apply)))
    };
    Some(Job::with_callback(future).wait_before_exiting())
}

#[derive(Debug)]
pub struct ApplyEditError {
    pub kind: ApplyEditErrorKind,
    pub failed_change_idx: usize,
}

#[derive(Debug)]
pub enum ApplyEditErrorKind {
    DocumentChanged,
    FileNotFound,
    UnknownURISchema,
    IoError(std::io::Error),
    // TODO: check edits before applying and propagate failure
    // InvalidEdit,
}

impl Display for ApplyEditErrorKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ApplyEditErrorKind::DocumentChanged => f.write_str("document has changed"),
            ApplyEditErrorKind::FileNotFound => f.write_str("file not found"),
            ApplyEditErrorKind::UnknownURISchema => f.write_str("URI schema not supported"),
            ApplyEditErrorKind::IoError(err) => f.write_str(&format!("{err}")),
        }
    }
}

/// Precondition: `locations` should be non-empty.
fn goto_impl(
    title: &'static str,
    editor: &mut Editor,
    compositor: &mut Compositor,
    locations: Vec<Location>,
) {
    let cwdir = helix_stdx::env::current_working_dir();

    match locations.as_slice() {
        [location] => {
            jump_to_location(editor, location, Action::Replace);
        }
        [] => unreachable!("`locations` should be non-empty for `goto_impl`"),
        _locations => {
            let columns = [ui::PickerColumn::new(
                "location",
                |item: &Location, cwdir: &std::path::PathBuf| {
                    let path = if let Some(path) = item.uri.as_path() {
                        path.strip_prefix(cwdir).unwrap_or(path).to_string_lossy()
                    } else {
                        item.uri.to_string().into()
                    };

                    format!("{path}:{}", item.range.start.line + 1).into()
                },
            )];

            let picker = Picker::new(columns, 0, locations, cwdir, |cx, location, action| {
                jump_to_location(cx.editor, location, action)
            })
            .with_preview(|_editor, location| location_to_file_location(location))
            .with_title(title);
            compositor.push(Box::new(overlaid(
                picker,
                editor.config().fullscreen_overlay,
            )));
        }
    }
}

fn goto_single_impl<P, F>(cx: &mut Context, feature: LanguageServerFeature, request_provider: P)
where
    P: Fn(&Client, lsp::Position, lsp::TextDocumentIdentifier) -> Option<F>,
    F: Future<Output = helix_lsp::Result<Option<lsp::GotoDefinitionResponse>>> + 'static + Send,
{
    let (view, doc) = current_ref!(cx.editor);
    let mut futures: FuturesUnordered<_> = doc
        .language_servers_with_feature(feature)
        .map(|language_server| {
            let offset_encoding = language_server.offset_encoding();
            let pos = doc.position(view.id, offset_encoding);
            let future = request_provider(language_server, pos, doc.identifier()).unwrap();
            async move { anyhow::Ok((future.await?, offset_encoding)) }
        })
        .collect();

    cx.jobs.callback(async move {
        let mut locations = Vec::new();
        while let Some(response) = futures.next().await {
            match response {
                Ok((response, offset_encoding)) => match response {
                    Some(lsp::GotoDefinitionResponse::Scalar(lsp_location)) => {
                        locations.extend(lsp_location_to_location(lsp_location, offset_encoding));
                    }
                    Some(lsp::GotoDefinitionResponse::Array(lsp_locations)) => {
                        locations.extend(lsp_locations.into_iter().flat_map(|location| {
                            lsp_location_to_location(location, offset_encoding)
                        }));
                    }
                    Some(lsp::GotoDefinitionResponse::Link(lsp_locations)) => {
                        locations.extend(
                            lsp_locations
                                .into_iter()
                                .map(|location_link| {
                                    lsp::Location::new(
                                        location_link.target_uri,
                                        location_link.target_range,
                                    )
                                })
                                .flat_map(|location| {
                                    lsp_location_to_location(location, offset_encoding)
                                }),
                        );
                    }
                    None => (),
                },
                Err(err) => log::error!("Error requesting locations: {err}"),
            }
        }
        let call = move |editor: &mut Editor, compositor: &mut Compositor| {
            if locations.is_empty() {
                editor.set_error(match feature {
                    LanguageServerFeature::GotoDeclaration => "No declaration found.",
                    LanguageServerFeature::GotoDefinition => "No definition found.",
                    LanguageServerFeature::GotoTypeDefinition => "No type definition found.",
                    LanguageServerFeature::GotoImplementation => "No implementation found.",
                    _ => "No location found.",
                });
            } else {
                goto_impl("Goto Implementation", editor, compositor, locations);
            }
        };
        Ok(Callback::EditorCompositor(Box::new(call)))
    });
}

pub fn goto_declaration(cx: &mut Context) {
    goto_single_impl(
        cx,
        LanguageServerFeature::GotoDeclaration,
        |ls, pos, doc_id| ls.goto_declaration(doc_id, pos, None),
    );
}

pub fn goto_definition(cx: &mut Context) {
    goto_single_impl(
        cx,
        LanguageServerFeature::GotoDefinition,
        |ls, pos, doc_id| ls.goto_definition(doc_id, pos, None),
    );
}

pub fn goto_type_definition(cx: &mut Context) {
    goto_single_impl(
        cx,
        LanguageServerFeature::GotoTypeDefinition,
        |ls, pos, doc_id| ls.goto_type_definition(doc_id, pos, None),
    );
}

pub fn goto_implementation(cx: &mut Context) {
    goto_single_impl(
        cx,
        LanguageServerFeature::GotoImplementation,
        |ls, pos, doc_id| ls.goto_implementation(doc_id, pos, None),
    );
}

pub fn goto_reference(cx: &mut Context) {
    let config = cx.editor.config();
    let (view, doc) = current_ref!(cx.editor);

    let mut futures: FuturesUnordered<_> = doc
        .language_servers_with_feature(LanguageServerFeature::GotoReference)
        .map(|language_server| {
            let offset_encoding = language_server.offset_encoding();
            let pos = doc.position(view.id, offset_encoding);
            let future = language_server
                .goto_reference(
                    doc.identifier(),
                    pos,
                    config.lsp.goto_reference_include_declaration,
                    None,
                )
                .unwrap();
            async move { anyhow::Ok((future.await?, offset_encoding)) }
        })
        .collect();

    cx.jobs.callback(async move {
        let mut locations = Vec::new();
        while let Some(response) = futures.next().await {
            match response {
                Ok((lsp_locations, offset_encoding)) => locations.extend(
                    lsp_locations
                        .into_iter()
                        .flatten()
                        .flat_map(|location| lsp_location_to_location(location, offset_encoding)),
                ),
                Err(err) => log::error!("Error requesting references: {err}"),
            }
        }
        let call = move |editor: &mut Editor, compositor: &mut Compositor| {
            if locations.is_empty() {
                editor.set_error("No references found.");
            } else {
                goto_impl("Goto Reference", editor, compositor, locations);
            }
        };
        Ok(Callback::EditorCompositor(Box::new(call)))
    });
}

pub fn signature_help(cx: &mut Context) {
    cx.editor
        .handlers
        .trigger_signature_help(SignatureHelpInvoked::Manual, cx.editor)
}

enum HoverDisplay {
    Popup,
    File,
}

fn hover_impl(cx: &mut Context, hover_action: HoverDisplay) {
    use ui::lsp::hover::Hover;

    let (view, doc) = current!(cx.editor);
    if doc
        .language_servers_with_feature(LanguageServerFeature::Hover)
        .count()
        == 0
    {
        cx.editor
            .set_error("No configured language server supports hover");
        return;
    }

    let mut seen_language_servers = HashSet::new();
    let mut futures: FuturesUnordered<_> = doc
        .language_servers_with_feature(LanguageServerFeature::Hover)
        .filter(|ls| seen_language_servers.insert(ls.id()))
        .map(|language_server| {
            let server_name = language_server.name().to_string();
            // TODO: factor out a doc.position_identifier() that returns lsp::TextDocumentPositionIdentifier
            let pos = doc.position(view.id, language_server.offset_encoding());
            let request = language_server
                .text_document_hover(doc.identifier(), pos, None)
                .unwrap();

            async move { anyhow::Ok((server_name, request.await?)) }
        })
        .collect();

    cx.jobs.callback(async move {
        let mut hovers: Vec<(String, lsp::Hover)> = Vec::new();

        while let Some(response) = futures.next().await {
            match response {
                Ok((server_name, Some(hover))) => hovers.push((server_name, hover)),
                Ok(_) => (),
                Err(err) => log::error!("Error requesting hover: {err}"),
            }
        }

        let call = move |editor: &mut Editor, compositor: &mut Compositor| {
            if hovers.is_empty() {
                editor.set_status("No hover results available.");
                return;
            }

            let hover = Hover::new(hovers, editor.syn_loader.clone());

            match hover_action {
                HoverDisplay::Popup => {
                    let popup = Popup::new(Hover::ID, hover).auto_close(true);
                    compositor.replace_or_push(Hover::ID, popup);
                }
                HoverDisplay::File => {
                    editor.new_file_from_document(
                        Action::Replace,
                        Document::from(
                            Rope::from(hover.content_string()),
                            None,
                            Arc::clone(&editor.config),
                            Arc::clone(&editor.syn_loader),
                        ),
                    );
                    let hover_doc = doc_mut!(editor);

                    let _ = hover_doc
                        .set_language_by_language_id("markdown", &editor.syn_loader.load());
                }
            }
        };
        Ok(Callback::EditorCompositor(Box::new(call)))
    });
}

pub fn hover(cx: &mut Context) {
    hover_impl(cx, HoverDisplay::Popup)
}

pub fn goto_hover(cx: &mut Context) {
    hover_impl(cx, HoverDisplay::File)
}

pub fn rename_symbol(cx: &mut Context) {
    fn get_prefill_from_word_boundary(editor: &Editor) -> String {
        let (view, doc) = current_ref!(editor);
        let text = doc.text().slice(..);
        let primary_selection = doc.selection(view.id).primary();
        if primary_selection.len() > 1 {
            primary_selection
        } else {
            use helix_core::textobject::{textobject_word, TextObject};
            textobject_word(text, primary_selection, TextObject::Inside, 1, false)
        }
        .fragment(text)
        .into()
    }

    fn get_prefill_from_lsp_response(
        editor: &Editor,
        offset_encoding: OffsetEncoding,
        response: Option<lsp::PrepareRenameResponse>,
    ) -> Result<String, &'static str> {
        match response {
            Some(lsp::PrepareRenameResponse::Range(range)) => {
                let text = doc!(editor).text();

                Ok(lsp_range_to_range(text, range, offset_encoding)
                    .ok_or("lsp sent invalid selection range for rename")?
                    .fragment(text.slice(..))
                    .into())
            }
            Some(lsp::PrepareRenameResponse::RangeWithPlaceholder { placeholder, .. }) => {
                Ok(placeholder)
            }
            Some(lsp::PrepareRenameResponse::DefaultBehavior { .. }) => {
                Ok(get_prefill_from_word_boundary(editor))
            }
            None => Err("lsp did not respond to prepare rename request"),
        }
    }

    fn create_rename_prompt(
        editor: &Editor,
        prefill: String,
        history_register: Option<char>,
        language_server_id: Option<LanguageServerId>,
    ) -> Box<dyn Component> {
        match editor.config().cmdline.style {
            helix_view::editor::CmdlineStyle::Popup => {
                let cmdline = ui::CmdlinePopup::new(
                    "rename-to:".into(),
                    history_register,
                    ui::completers::none,
                    move |cx: &mut compositor::Context, input: &str, event: PromptEvent| {
                        if event != PromptEvent::Validate {
                            return;
                        }
                        let (view, doc) = current!(cx.editor);

                        let Some(language_server) = doc
                            .language_servers_with_feature(LanguageServerFeature::RenameSymbol)
                            .find(|ls| language_server_id.is_none_or(|id| id == ls.id()))
                        else {
                            cx.editor.set_error(
                                "No configured language server supports symbol renaming",
                            );
                            return;
                        };

                        let offset_encoding = language_server.offset_encoding();
                        let pos = doc.position(view.id, offset_encoding);
                        let future = language_server
                            .rename_symbol(doc.identifier(), pos, input.to_string())
                            .unwrap();

                        match block_on(future) {
                            Ok(edits) => {
                                let _ = cx.editor.apply_workspace_edit(
                                    offset_encoding,
                                    &edits.unwrap_or_default(),
                                );
                            }
                            Err(err) => cx.editor.set_error(err.to_string()),
                        }
                    },
                    helix_view::editor::CmdlineStyle::Popup,
                )
                .with_line(prefill, editor);

                Box::new(cmdline)
            }
            helix_view::editor::CmdlineStyle::Bottom => {
                let prompt = ui::Prompt::new(
                    "rename-to:".into(),
                    history_register,
                    ui::completers::none,
                    move |cx: &mut compositor::Context, input: &str, event: PromptEvent| {
                        if event != PromptEvent::Validate {
                            return;
                        }
                        let (view, doc) = current!(cx.editor);

                        let Some(language_server) = doc
                            .language_servers_with_feature(LanguageServerFeature::RenameSymbol)
                            .find(|ls| language_server_id.is_none_or(|id| id == ls.id()))
                        else {
                            cx.editor.set_error(
                                "No configured language server supports symbol renaming",
                            );
                            return;
                        };

                        let offset_encoding = language_server.offset_encoding();
                        let pos = doc.position(view.id, offset_encoding);
                        let future = language_server
                            .rename_symbol(doc.identifier(), pos, input.to_string())
                            .unwrap();

                        match block_on(future) {
                            Ok(edits) => {
                                let _ = cx.editor.apply_workspace_edit(
                                    offset_encoding,
                                    &edits.unwrap_or_default(),
                                );
                            }
                            Err(err) => cx.editor.set_error(err.to_string()),
                        }
                    },
                )
                .with_line(prefill, editor);

                Box::new(prompt)
            }
        }
    }

    let (view, doc) = current_ref!(cx.editor);
    let history_register = cx.register;

    if doc
        .language_servers_with_feature(LanguageServerFeature::RenameSymbol)
        .next()
        .is_none()
    {
        cx.editor
            .set_error("No configured language server supports symbol renaming");
        return;
    }

    let language_server_with_prepare_rename_support = doc
        .language_servers_with_feature(LanguageServerFeature::RenameSymbol)
        .find(|ls| {
            matches!(
                ls.capabilities().rename_provider,
                Some(lsp::OneOf::Right(lsp::RenameOptions {
                    prepare_provider: Some(true),
                    ..
                }))
            )
        });

    if let Some(language_server) = language_server_with_prepare_rename_support {
        let ls_id = language_server.id();
        let offset_encoding = language_server.offset_encoding();
        let pos = doc.position(view.id, offset_encoding);
        let future = language_server
            .prepare_rename(doc.identifier(), pos)
            .unwrap();
        cx.callback(
            future,
            move |editor, compositor, response: Option<lsp::PrepareRenameResponse>| {
                let prefill = match get_prefill_from_lsp_response(editor, offset_encoding, response)
                {
                    Ok(p) => p,
                    Err(e) => {
                        editor.set_error(e);
                        return;
                    }
                };

                let prompt = create_rename_prompt(editor, prefill, history_register, Some(ls_id));

                compositor.push(prompt);
            },
        );
    } else {
        let prefill = get_prefill_from_word_boundary(cx.editor);
        let prompt = create_rename_prompt(cx.editor, prefill, history_register, None);
        cx.push_layer(prompt);
    }
}

pub fn select_references_to_symbol_under_cursor(cx: &mut Context) {
    let (view, doc) = current!(cx.editor);
    let language_server =
        language_server_with_feature!(cx.editor, doc, LanguageServerFeature::DocumentHighlight);
    let offset_encoding = language_server.offset_encoding();
    let pos = doc.position(view.id, offset_encoding);
    let future = language_server
        .text_document_document_highlight(doc.identifier(), pos, None)
        .unwrap();

    cx.callback(
        future,
        move |editor, _compositor, response: Option<Vec<lsp::DocumentHighlight>>| {
            let document_highlights = match response {
                Some(highlights) if !highlights.is_empty() => highlights,
                _ => return,
            };
            let (view, doc) = current!(editor);
            let text = doc.text();
            let pos = doc.selection(view.id).primary().cursor(text.slice(..));

            // We must find the range that contains our primary cursor to prevent our primary cursor to move
            let mut primary_index = 0;
            let ranges = document_highlights
                .iter()
                .filter_map(|highlight| lsp_range_to_range(text, highlight.range, offset_encoding))
                .enumerate()
                .map(|(i, range)| {
                    if range.contains(pos) {
                        primary_index = i;
                    }
                    range
                })
                .collect();
            let selection = Selection::new(ranges, primary_index);
            doc.set_selection(view.id, selection);
        },
    );
}

pub fn compute_inlay_hints_for_all_views(editor: &mut Editor, jobs: &mut crate::job::Jobs) {
    if !editor.config().lsp.display_inlay_hints {
        return;
    }

    for (view, _) in editor.tree.views() {
        let doc = match editor.documents.get(&view.doc) {
            Some(doc) => doc,
            None => continue,
        };
        if let Some(callback) = compute_inlay_hints_for_view(view, doc) {
            jobs.callback(callback);
        }
    }
}

fn compute_inlay_hints_for_view(
    view: &View,
    doc: &Document,
) -> Option<std::pin::Pin<Box<impl Future<Output = Result<crate::job::Callback, anyhow::Error>>>>> {
    let view_id = view.id;
    let doc_id = view.doc;

    let language_server = doc
        .language_servers_with_feature(LanguageServerFeature::InlayHints)
        .next()?;

    let doc_text = doc.text();
    let annotations = &view.fold_annotations(doc);

    // Compute ~3 times the current view height of inlay hints, that way some scrolling
    // will not show half the view with hints and half without while still being faster
    // than computing all the hints for the full file (which could be dozens of time
    // longer than the view is).
    let view_height = view.inner_height(doc);
    let first_visible_line =
        doc_text.char_to_line(doc.view_offset(view_id).anchor.min(doc_text.len_chars()));
    let first_line = first_visible_line.saturating_sub(view_height);
    let last_line = doc_text.slice(..).nth_next_folded_line(
        annotations,
        first_visible_line,
        view_height.saturating_mul(2),
    );

    let new_doc_inlay_hints_id = DocumentInlayHintsId {
        first_line,
        last_line,
    };
    // Don't recompute the annotations in case nothing has changed about the view
    if !doc.inlay_hints_oudated
        && doc
            .inlay_hints(view_id)
            .is_some_and(|dih| dih.id == new_doc_inlay_hints_id)
    {
        return None;
    }

    let doc_slice = doc_text.slice(..);
    let first_char_in_range = doc_slice.line_to_char(first_line);
    let last_char_in_range = doc_slice.line_to_char(last_line);

    let range = helix_lsp::util::range_to_lsp_range(
        doc_text,
        helix_core::Range::new(first_char_in_range, last_char_in_range),
        language_server.offset_encoding(),
    );

    let offset_encoding = language_server.offset_encoding();

    let callback = super::make_job_callback(
        language_server.text_document_range_inlay_hints(doc.identifier(), range, None)?,
        move |editor, _compositor, response: Option<Vec<lsp::InlayHint>>| {
            // The config was modified or the window was closed while the request was in flight
            if !editor.config().lsp.display_inlay_hints || editor.tree.try_get(view_id).is_none() {
                return;
            }

            // Add annotations to relevant document, not the current one (it may have changed in between)
            let doc = match editor.documents.get_mut(&doc_id) {
                Some(doc) => doc,
                None => return,
            };

            // If we have neither hints nor an LSP, empty the inlay hints since they're now oudated
            let mut hints = match response {
                Some(hints) if !hints.is_empty() => hints,
                _ => {
                    doc.set_inlay_hints(
                        view_id,
                        DocumentInlayHints::empty_with_id(new_doc_inlay_hints_id),
                    );
                    doc.inlay_hints_oudated = false;
                    return;
                }
            };

            // Most language servers will already send them sorted but ensure this is the case to
            // avoid errors on our end.
            hints.sort_by_key(|inlay_hint| inlay_hint.position);

            let mut padding_before_inlay_hints = Vec::new();
            let mut type_inlay_hints = Vec::new();
            let mut parameter_inlay_hints = Vec::new();
            let mut other_inlay_hints = Vec::new();
            let mut padding_after_inlay_hints = Vec::new();

            let doc_text = doc.text();
            let inlay_hints_length_limit = doc.config.load().lsp.inlay_hints_length_limit;

            for hint in hints {
                let char_idx =
                    match helix_lsp::util::lsp_pos_to_pos(doc_text, hint.position, offset_encoding)
                    {
                        Some(pos) => pos,
                        // Skip inlay hints that have no "real" position
                        None => continue,
                    };

                let mut label = match hint.label {
                    lsp::InlayHintLabel::String(s) => s,
                    lsp::InlayHintLabel::LabelParts(parts) => parts
                        .into_iter()
                        .map(|p| p.value)
                        .collect::<Vec<_>>()
                        .join(""),
                };
                // Truncate the hint if too long
                if let Some(limit) = inlay_hints_length_limit {
                    // Limit on displayed width
                    use helix_core::unicode::{
                        segmentation::UnicodeSegmentation, width::UnicodeWidthStr,
                    };

                    let width = label.width();
                    let limit = limit.get().into();
                    if width > limit {
                        let mut floor_boundary = 0;
                        let mut acc = 0;
                        for (i, grapheme_cluster) in label.grapheme_indices(true) {
                            acc += grapheme_cluster.width();

                            if acc > limit {
                                floor_boundary = i;
                                break;
                            }
                        }

                        label.truncate(floor_boundary);
                        label.push('…');
                    }
                }

                let inlay_hints_vec = match hint.kind {
                    Some(lsp::InlayHintKind::TYPE) => &mut type_inlay_hints,
                    Some(lsp::InlayHintKind::PARAMETER) => &mut parameter_inlay_hints,
                    // We can't warn on unknown kind here since LSPs are free to set it or not, for
                    // example Rust Analyzer does not: every kind will be `None`.
                    _ => &mut other_inlay_hints,
                };

                if let Some(true) = hint.padding_left {
                    padding_before_inlay_hints.push(InlineAnnotation::new(char_idx, " "));
                }

                inlay_hints_vec.push(InlineAnnotation::new(char_idx, label));

                if let Some(true) = hint.padding_right {
                    padding_after_inlay_hints.push(InlineAnnotation::new(char_idx, " "));
                }
            }

            doc.set_inlay_hints(
                view_id,
                DocumentInlayHints {
                    id: new_doc_inlay_hints_id,
                    type_inlay_hints,
                    parameter_inlay_hints,
                    other_inlay_hints,
                    padding_before_inlay_hints,
                    padding_after_inlay_hints,
                },
            );
            doc.inlay_hints_oudated = false;
        },
    );

    Some(callback)
}
