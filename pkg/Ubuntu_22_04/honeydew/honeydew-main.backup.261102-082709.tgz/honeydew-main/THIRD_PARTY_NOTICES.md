# Third-party notices

This app includes the third-party software below, each under its own license.

The Honeydew logo (`assets/branding/`) is a derivative of "Melon" by afitrose, licensed as Free for commercial use WITH
ATTRIBUTION; see [`assets/branding/README.md`](assets/branding/README.md).

## Lemon Studio `os-flp` (FL Studio project files)

- Source: Lemon Studio by ItsAlphaNeon (<https://github.com/ItsAlphaNeon/Lemon-Studio>), `crates/os-flp`.
- Copyright (C) 2026 ItsAlphaNeon.
- License: GPL-3.0-or-later, the same license as Honeydew ([`LICENSE`](LICENSE)).
- Modified: the FLP container and event layer (`container.rs`, `event.rs`, `check.rs`, `error.rs`) lives in `src/flp/`,
  each file keeping its copyright and SPDX header and noting the change: `thiserror` derives replaced by plain
  `Display` impls, module paths moved. Honeydew's own mapping (`src/flp/import.rs`, `src/flp/export.rs`) follows the
  layout of Lemon Studio's project writer (event order, playlist and track record templates, the audio clip
  channel's sample settings, a new channel's key zone). `src/flp/mixer.rs` ports its new-mixer writer and Fruity
  Parametric EQ 2's saved state image (from `plugins/lemon-parametric-eq-2`), keeping the copyright and SPDX header.

## rusty_mp3 1.0.0 (MP3 export)

- Source: the `rusty_mp3` 1.0.0 crate from crates.io (<https://github.com/Remade-With-Rust/remade_ffmpeg_rs>,
  `crates/rusty_mp3`).
- Copyright 2026 Mata Network.
- License: Apache License 2.0, reproduced below. The crate ships no NOTICE file.
- Modified: a copy lives in `vendor/rusty_mp3`. Its debug environment variables (`MP3_*`, `RFF_MP3_XRPOW`) are no
  longer read, its `lab` module, examples and tests are left out, and one unused-variable warning is silenced. Each
  modified file starts with `Modified from rusty_mp3 1.0.0`, and each changed place is marked `Vendored (studio)`.

```text
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative
          Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and do
          not modify the License. You may add Your own attribution notices
          within Derivative Works that You distribute, alongside or as an
          addendum to the NOTICE text from the Work, provided that such
          additional attribution notices cannot be construed as modifying
          the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2026 Mata Network

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
```

## zvidlib-vorbis-encoder 0.5.0, zvidlib-core 0.5.0, zvidlib-vorbis-syntax 0.5.0 (OGG export)

- Source: the three crates from crates.io (<https://github.com/lsegal/zvidlib>), unmodified.
- Copyright (c) 2026 Loren Segal.
- License: MIT, reproduced below (the `LICENSE` file that `zvidlib-vorbis-encoder` and `zvidlib-core` each ship;
  `zvidlib-vorbis-syntax` names the same license).

```text
MIT License

Copyright (c) 2026 Loren Segal

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## libvorbis 1.3.7 (OGG export, through zvidlib-vorbis-encoder)

- zvidlib-vorbis-encoder's Vorbis encoder is a port of the encoder in Xiph.Org libvorbis 1.3.7
  (<https://xiph.org/vorbis/>), and its tables are generated from libvorbis's own. The crate's
  `THIRD_PARTY_NOTICES.md` carries this notice:

```text
Copyright (c) 2002-2020 Xiph.org Foundation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

- Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

- Neither the name of the Xiph.org Foundation nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

## ogg 0.8.0 (OGG export)

- Source: the `ogg` 0.8.0 crate from crates.io (<https://github.com/RustAudio/ogg>), unmodified.
- License: BSD 3-Clause, reproduced below. Its dependency `byteorder` 1.5.0 is used under the Unlicense, which asks
  for no notice.

```text
NOTE:
The full list of contributors can be obtained by looking
at the VCS log (originally, this crate was git versioned,
there you can do "git shortlog -sn" for this task).

License text
------------
Copyright (c) 2016-2017 est31 <MTest31@outlook.com> and contributors
Copyright (c) 2002-2015 Xiph.org Foundation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

- Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

- Neither the name of the Xiph.org Foundation nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

## Lemon Studio's plugin hosts (VST3, VST2 and CLAP plugins, desktop)

- Source: Lemon Studio (<https://github.com/ItsAlphaNeon/Lemon-Studio>) at commit
  `219ed4ee8bfb534b91282e3ef45ded438292eee8`: the crates `os-host`, `os-clap`, `os-vst3` and `os-vst2`, and parts of
  `os-engine`, `os-app` and `os-flp` (the plugin search and scanner, `src/plugins/scan.rs`; the X11 editor window,
  `src/plugins/window.rs`; FL Studio's plugin wrapper state, `src/flp/wrapper.rs`).
- Copyright (C) 2026 ItsAlphaNeon.
- License: GPL-3.0-or-later, the license of Honeydew itself ([`LICENSE`](LICENSE)); every file keeps its copyright and
  SPDX header.
- Modified: a copy lives in `vendor/lemon-studio`, whose `README.md` lists each change from upstream (the engine types
  reduced to what the hosts use; a MIDI hook for pitch bend, channel pressure and CCs, marked
  `Honeydew (vendored addition)`). The ported app files start with a `Modified for Honeydew` line.

## Lemon Studio's reverb and limiter (Lemon Reverb and Lemon Limiter)

- Source: Lemon Studio (<https://github.com/ItsAlphaNeon/Lemon-Studio>), at the commit `vendor/lemon-studio/README.md`
  pins (`eb1c13ee6108e30bedfdb21679c60bc30535da2b` at first): `crates/os-engine/src/effects/` (the reverb, the limiter's
  dynamics and their siblings), and the knob names and value texts of `plugins/lemon-reverb` and `plugins/lemon-limiter`
  (`src/params/lemon.rs`).
- Copyright (C) 2026 ItsAlphaNeon.
- License: GPL-3.0-or-later, the license of Honeydew itself ([`LICENSE`](LICENSE)); every file keeps its copyright and
  SPDX header.
- Modified: none in `vendor/lemon-studio/os-engine/src/effects/`, a copy of upstream's files
  (`tools/sync-lemon-effects.sh` updates them). `src/params/lemon.rs` starts with a `Modified for Honeydew` line.

## Lemon Studio's plugins (Lemon Trio, Lemon Sampler and Lemon Parametric EQ)

- Source: Lemon Studio (<https://github.com/ItsAlphaNeon/Lemon-Studio>), at the commit `vendor/lemon-studio/README.md`
  pins (`6e9c3b9d7c7cfa5a31dc2dc087358ba04eebc96e` at first): `plugins/lemon-3x-osc`, `plugins/lemon-sampler`,
  `plugins/lemon-parametric-eq-2`, the crates they use (`os-plugkit`, `os-ui`, `os-theme`, `os-hostlink`, `os-model`,
  `os-dsp`, `os-paths`) and four files of `os-engine`.
- Copyright (C) 2026 ItsAlphaNeon, and thacer13 for parts of `os-engine`.
- License: GPL-3.0-or-later, the license of Honeydew itself ([`LICENSE`](LICENSE)); every file keeps its copyright and
  SPDX header.
- Modified: a copy lives in `vendor/lemon-studio`; Honeydew's changes are `vendor/lemon-studio/honeydew.patch`, listed in
  that folder's `README.md` and marked `Honeydew (vendored change)` or `(vendored addition)` (the editors drawn into
  Honeydew's window on every platform, the browser build without threads or C++).

## nih-plug (the built-in plugins' framework)

- Source: <https://github.com/robbert-vdh/nih-plug>, commit `de421011f41a6d10fc8c7a6084e4f4dee0143683`, the core crate
  and its derive macros.
- License: ISC, reproduced below.
- Modified: a copy lives in `vendor/nih-plug` without its VST3 and standalone wrappers; in the browser build its
  background tasks run without a thread and it takes Lemon Studio's `lemon-web` editor window (`vendor/nih-plug/README.md`).

```text
ISC License

Copyright (c) 2022-2024 Robbert van der Helm

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
```

## The built-in plugins' fonts and icons

Lemon Studio's plugin editors draw with these (`vendor/lemon-studio/os-ui`):

- **Barlow** (Semi Condensed Regular and SemiBold, Condensed Medium): Copyright 2017 The Barlow Project Authors
  (<https://github.com/jpt/barlow>), SIL Open Font License 1.1 (`vendor/lemon-studio/os-ui/fonts/Barlow/OFL.txt`).
- **Cuprum**: Copyright (c) 2008-2010 by Jovanny Lemonad (<http://www.jovanny.ru>), SIL Open Font License 1.1
  (`vendor/lemon-studio/os-ui/fonts/Cuprum/OFL.txt`).
- **Tabler Icons**' shapes (`os-ui/src/tabler.rs`), under this license:

```text
MIT License

Copyright (c) 2020-2024 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Signalsmith Stretch (Lemon Sampler's time stretching, desktop and Android)

- Source: the `signalsmith-stretch` 0.1.3 crate from crates.io (<https://github.com/colinmarc/signalsmith-stretch-rs>,
  Copyright 2024 Colin Marc) and the Signalsmith Stretch library it compiles (Copyright (c) 2022 Geraint Luff /
  Signalsmith Audio Ltd.), unmodified.
- License: MIT, both; the text is the clap-sys section's below, with these copyright lines.

## vst3-sys (VST3 interfaces, through Lemon Studio's VST3 host)

- Source: <https://github.com/robbert-vdh/vst3-sys>, commit `b3ff4d775940f5b476b9d1cca02a90e07e1922a2`, unmodified.
- License: GPL-3.0 ([`LICENSE`](LICENSE)).

## clap-sys 0.5.0 (CLAP interfaces, through Lemon Studio's CLAP host)

- Source: the `clap-sys` 0.5.0 crate from crates.io (<https://github.com/micahrj/clap-sys>), unmodified.
- License: MIT or Apache-2.0, at the user's choice; the MIT text is reproduced below.

```text
Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

## Lemon Studio's VST 2 interface notice

Lemon Studio's VST 2 host is a clean-room interface with no Steinberg SDK; it ships this notice
(`vendor/lemon-studio/os-vst2/LICENSE-vst2sdk.txt`):

```text
Copyright 2020 Michael Fabian 'Xaymar' Dirks <info@xaymar.com>

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```
