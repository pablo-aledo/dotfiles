See the [Privacy](https://rust-analyzer.github.io/manual.html#privacy) section of the user manual.
