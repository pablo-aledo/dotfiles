---
name: Feature Request
about: Create a feature request for rust-analyzer.
title: ''
labels: 'C-feature'
assignees: ''

---
