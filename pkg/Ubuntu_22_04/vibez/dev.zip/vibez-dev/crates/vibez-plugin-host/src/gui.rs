use std::ffi::c_void;

use clap_sys::ext::gui::{
    clap_plugin_gui, clap_window, clap_window_handle, CLAP_EXT_GUI, CLAP_WINDOW_API_X11,
};
use clap_sys::plugin::clap_plugin;

use vibez_core::id::{EffectId, TrackId};

/// Identifies a specific plugin GUI (for use as HashMap key).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PluginGuiKey {
    Effect {
        track_id: TrackId,
        effect_id: EffectId,
    },
    Instrument {
        track_id: TrackId,
    },
}

/// A handle to a plugin's native GUI, kept on the UI thread.
pub enum PluginGuiHandle {
    Clap(ClapGuiHandle),
    Vst3(Vst3GuiHandle),
}

// Safety: GUI handles are only used from the UI thread.
// The raw pointers within point to plugin objects that remain valid
// for the plugin's lifetime and are only accessed from the main thread.
unsafe impl Send for PluginGuiHandle {}

impl PluginGuiHandle {
    /// Pump per-view host services (VST3 Linux IRunLoop). No-op for
    /// CLAP, whose timer/fd extensions are pumped by the CLAP host.
    pub fn service_runloop(&self) {
        if let PluginGuiHandle::Vst3(h) = self {
            h.service_runloop();
        }
    }

    /// CLAP plugin pointer for matching plugin-initiated resize
    /// requests; None for VST3.
    pub fn clap_plugin_ptr(&self) -> Option<usize> {
        match self {
            PluginGuiHandle::Clap(h) => Some(h.plugin_ptr as usize),
            PluginGuiHandle::Vst3(_) => None,
        }
    }

    /// Plugin-initiated resize request (VST3 IPlugFrame::resizeView).
    pub fn take_pending_resize(&self) -> Option<(u32, u32)> {
        match self {
            PluginGuiHandle::Clap(_) => None,
            PluginGuiHandle::Vst3(h) => h.frame.as_ref().and_then(|f| f.take_pending_resize()),
        }
    }

    /// Whether the plugin actually supports a GUI.
    pub fn has_gui(&self) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => !h.gui_ext.is_null(),
            PluginGuiHandle::Vst3(h) => !h.edit_controller.is_null(),
        }
    }

    /// Whether the plugin GUI supports live resizing by the host.
    pub fn can_resize(&self) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.can_resize(),
            PluginGuiHandle::Vst3(h) => h.can_resize(),
        }
    }

    /// Forward a host-window resize to the plugin GUI.
    pub fn set_size(&mut self, width: u32, height: u32) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.set_size(width, height),
            PluginGuiHandle::Vst3(h) => h.set_size(width, height),
        }
    }

    /// Query the preferred GUI size from the plugin.
    pub fn get_size(&self) -> Option<(u32, u32)> {
        match self {
            PluginGuiHandle::Clap(h) => h.get_size(),
            PluginGuiHandle::Vst3(h) => h.get_size(),
        }
    }

    /// Create the plugin GUI (call before attach/show).
    pub fn create_gui(&self) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.create_gui(),
            PluginGuiHandle::Vst3(_h) => _h.create_view(),
        }
    }

    /// Attach the plugin GUI to an X11 window.
    pub fn attach_to_x11(&self, window_id: u32) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.attach_to_x11(window_id),
            PluginGuiHandle::Vst3(h) => h.attach_to_x11(window_id),
        }
    }

    /// Show the plugin GUI.
    pub fn show(&self) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.show(),
            PluginGuiHandle::Vst3(_) => true, // VST3 shows on attach
        }
    }

    /// Hide the plugin GUI.
    pub fn hide(&self) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.hide(),
            PluginGuiHandle::Vst3(_) => true,
        }
    }

    /// Destroy the plugin GUI (call when closing window).
    pub fn destroy(&mut self) {
        match self {
            PluginGuiHandle::Clap(h) => h.destroy(),
            PluginGuiHandle::Vst3(h) => h.destroy(),
        }
    }

    pub fn is_open(&self) -> bool {
        match self {
            PluginGuiHandle::Clap(h) => h.open,
            PluginGuiHandle::Vst3(h) => h.open,
        }
    }
}

// ── CLAP GUI Handle ──

pub struct ClapGuiHandle {
    plugin_ptr: *const clap_plugin,
    gui_ext: *const clap_plugin_gui,
    pub open: bool,
}

unsafe impl Send for ClapGuiHandle {}

impl ClapGuiHandle {
    /// CLAP `clap_plugin_gui::can_resize`.
    pub fn can_resize(&self) -> bool {
        if self.gui_ext.is_null() {
            return false;
        }
        let gui = unsafe { &*self.gui_ext };
        match gui.can_resize {
            Some(f) => unsafe { f(self.plugin_ptr) },
            None => false,
        }
    }

    /// CLAP `clap_plugin_gui::set_size`.
    pub fn set_size(&mut self, width: u32, height: u32) -> bool {
        if self.gui_ext.is_null() {
            return false;
        }
        let gui = unsafe { &*self.gui_ext };
        match gui.set_size {
            Some(f) => unsafe { f(self.plugin_ptr, width, height) },
            None => false,
        }
    }

    /// Create a new CLAP GUI handle from a raw `*const c_void` pointer.
    /// This is the safe-to-call-from-anywhere entry point that avoids
    /// exposing `clap_plugin` types to crates that don't depend on `clap-sys`.
    ///
    /// # Safety
    /// `raw_ptr` must be a valid `*const clap_plugin` cast to `*const c_void`.
    pub unsafe fn from_raw(raw_ptr: *const c_void) -> Option<Self> {
        Self::new(raw_ptr as *const clap_plugin)
    }

    /// Create a new CLAP GUI handle by querying the plugin's GUI extension.
    ///
    /// # Safety
    /// `plugin_ptr` must be a valid CLAP plugin pointer that remains valid.
    pub unsafe fn new(plugin_ptr: *const clap_plugin) -> Option<Self> {
        if plugin_ptr.is_null() {
            eprintln!("vibez: ClapGuiHandle::new — plugin_ptr is null");
            return None;
        }
        let plugin_ref = &*plugin_ptr;
        let ext_ptr = (plugin_ref.get_extension.unwrap())(plugin_ptr, CLAP_EXT_GUI.as_ptr())
            as *const clap_plugin_gui;
        if ext_ptr.is_null() {
            eprintln!("vibez: ClapGuiHandle::new — plugin has no GUI extension");
            return None;
        }
        // Check if X11 is supported
        let gui = &*ext_ptr;
        let supported = (gui.is_api_supported.unwrap())(
            plugin_ptr,
            CLAP_WINDOW_API_X11.as_ptr(),
            false, // embedded, not floating
        );
        if !supported {
            eprintln!("vibez: ClapGuiHandle::new — X11 API not supported");
            return None;
        }
        eprintln!("vibez: ClapGuiHandle::new — GUI handle created OK");
        Some(Self {
            plugin_ptr,
            gui_ext: ext_ptr,
            open: false,
        })
    }

    fn get_size(&self) -> Option<(u32, u32)> {
        if self.gui_ext.is_null() {
            return None;
        }
        let mut w: u32 = 0;
        let mut h: u32 = 0;
        let gui = unsafe { &*self.gui_ext };
        let ok = unsafe { (gui.get_size.unwrap())(self.plugin_ptr, &mut w, &mut h) };
        if ok && w > 0 && h > 0 {
            Some((w, h))
        } else {
            None
        }
    }

    fn create_gui(&self) -> bool {
        if self.gui_ext.is_null() {
            return false;
        }
        let gui = unsafe { &*self.gui_ext };
        unsafe { (gui.create.unwrap())(self.plugin_ptr, CLAP_WINDOW_API_X11.as_ptr(), false) }
    }

    fn attach_to_x11(&self, window_id: u32) -> bool {
        if self.gui_ext.is_null() {
            return false;
        }
        let gui = unsafe { &*self.gui_ext };
        let window = clap_window {
            api: CLAP_WINDOW_API_X11.as_ptr(),
            specific: clap_window_handle {
                x11: window_id as clap_sys::ext::gui::clap_xwnd,
            },
        };
        unsafe { (gui.set_parent.unwrap())(self.plugin_ptr, &window) }
    }

    fn show(&self) -> bool {
        if self.gui_ext.is_null() {
            return false;
        }
        let gui = unsafe { &*self.gui_ext };
        if let Some(show_fn) = gui.show {
            unsafe { show_fn(self.plugin_ptr) }
        } else {
            true
        }
    }

    fn hide(&self) -> bool {
        if self.gui_ext.is_null() {
            return false;
        }
        let gui = unsafe { &*self.gui_ext };
        if let Some(hide_fn) = gui.hide {
            unsafe { hide_fn(self.plugin_ptr) }
        } else {
            true
        }
    }

    fn destroy(&mut self) {
        if self.gui_ext.is_null() || !self.open {
            return;
        }
        let gui = unsafe { &*self.gui_ext };
        unsafe { (gui.destroy.unwrap())(self.plugin_ptr) };
        self.open = false;
    }
}

// ── VST3 GUI Handle ──

/// VST3 IEditController IID: {DCD7BBE3-7742-448D-A874-AACC979C759E}
pub(crate) const IEDIT_CONTROLLER_IID: [u8; 16] = crate::vst3_tuid([
    0xDC, 0xD7, 0xBB, 0xE3, 0x77, 0x42, 0x44, 0x8D, 0xA8, 0x74, 0xAA, 0xCC, 0x97, 0x9C, 0x75, 0x9E,
]);

pub struct Vst3GuiHandle {
    /// IEditController COM pointer (own refcount, stays on UI thread).
    edit_controller: *mut c_void,
    /// IPlugView COM pointer (created on open, destroyed on close).
    plug_view: *mut c_void,
    /// Host IPlugFrame + Linux IRunLoop for this view. Alive from
    /// setFrame until after removed(); the window manager services
    /// its timers/fds every poll tick.
    frame: Option<crate::vst3_host::runloop::HostPlugFrame>,
    pub open: bool,
}

unsafe impl Send for Vst3GuiHandle {}

impl Vst3GuiHandle {
    /// Wrap the IEditController resolved at plugin load time
    /// (`Vst3PluginInstance::controller_ptr`). Dual-component plugins
    /// (JUCE) keep the controller as a separate object, so the GUI can
    /// no longer be reached by querying the component; the instance
    /// owns the resolution logic and hands the pointer here.
    ///
    /// # Safety
    /// `edit_controller` must be a valid IEditController COM pointer
    /// (or null, which returns None). Takes its own reference.
    pub unsafe fn new(edit_controller: *mut c_void) -> Option<Self> {
        if edit_controller.is_null() {
            eprintln!("vibez: Vst3GuiHandle::new — no edit controller (GUI unavailable)");
            return None;
        }
        // FUnknown::addRef - vtable[1]: hold our own reference; the
        // plugin instance keeps its own and releases it independently.
        type AddRefFn = unsafe extern "system" fn(*mut c_void) -> u32;
        let vtbl = *(edit_controller as *const *const *const c_void);
        let add_ref: AddRefFn = std::mem::transmute(*vtbl.add(1));
        add_ref(edit_controller);
        Some(Self {
            edit_controller,
            plug_view: std::ptr::null_mut(),
            frame: None,
            open: false,
        })
    }

    /// IPlugView::canResize - vtable [13]. kResultTrue (0) means yes.
    pub fn can_resize(&self) -> bool {
        if self.plug_view.is_null() {
            return false;
        }
        type CanResizeFn = unsafe extern "system" fn(*mut c_void) -> i32;
        let vtbl = unsafe { *(self.plug_view as *const *const *const c_void) };
        let can_resize: CanResizeFn = unsafe { std::mem::transmute(*vtbl.add(13)) };
        unsafe { can_resize(self.plug_view) == 0 }
    }

    /// IPlugView::onSize - vtable [10]. Rect uses left/top/right/bottom.
    pub fn set_size(&mut self, width: u32, height: u32) -> bool {
        if self.plug_view.is_null() {
            return false;
        }
        #[repr(C)]
        struct ViewRect {
            left: i32,
            top: i32,
            right: i32,
            bottom: i32,
        }
        type OnSizeFn = unsafe extern "system" fn(*mut c_void, *mut ViewRect) -> i32;
        let vtbl = unsafe { *(self.plug_view as *const *const *const c_void) };
        let on_size: OnSizeFn = unsafe { std::mem::transmute(*vtbl.add(10)) };
        let mut rect = ViewRect {
            left: 0,
            top: 0,
            right: width as i32,
            bottom: height as i32,
        };
        unsafe { on_size(self.plug_view, &mut rect) == 0 }
    }

    /// Pump this view's run loop (timers + fd handlers). JUCE editors
    /// paint and dispatch input exclusively from these callbacks.
    pub fn service_runloop(&self) {
        if let Some(frame) = &self.frame {
            frame.service();
        }
    }

    fn get_size(&self) -> Option<(u32, u32)> {
        if self.plug_view.is_null() {
            return None;
        }
        // IPlugView::getSize(rect) - vtable[9]
        // rect is ViewRect: { left: i32, top: i32, right: i32, bottom: i32 }
        #[repr(C)]
        struct ViewRect {
            left: i32,
            top: i32,
            right: i32,
            bottom: i32,
        }
        type GetSizeFn = unsafe extern "system" fn(*mut c_void, *mut ViewRect) -> i32;
        let vtbl = unsafe { *(self.plug_view as *const *const *const c_void) };
        let get_size: GetSizeFn = unsafe { std::mem::transmute(*vtbl.add(9)) };
        let mut rect = ViewRect {
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
        };
        let hr = unsafe { get_size(self.plug_view, &mut rect) };
        if hr == 0 {
            let w = (rect.right - rect.left).max(0) as u32;
            let h = (rect.bottom - rect.top).max(0) as u32;
            if w > 0 && h > 0 {
                return Some((w, h));
            }
        }
        None
    }

    fn create_view(&self) -> bool {
        if self.edit_controller.is_null() {
            return false;
        }
        // We create the view on open, not here
        true
    }

    fn attach_to_x11(&self, window_id: u32) -> bool {
        if self.plug_view.is_null() {
            return false;
        }
        // IPlugView::attached(parent, type) - vtable[4]
        type AttachedFn = unsafe extern "system" fn(*mut c_void, *mut c_void, *const u8) -> i32;
        let vtbl = unsafe { *(self.plug_view as *const *const *const c_void) };
        let attached: AttachedFn = unsafe { std::mem::transmute(*vtbl.add(4)) };
        let platform_type = b"X11EmbedWindowID\0";
        let hr = unsafe {
            attached(
                self.plug_view,
                window_id as usize as *mut c_void,
                platform_type.as_ptr(),
            )
        };
        hr == 0
    }

    fn destroy(&mut self) {
        if !self.plug_view.is_null() {
            // IPlugView::removed() - vtable[5]
            type RemovedFn = unsafe extern "system" fn(*mut c_void) -> i32;
            let vtbl = unsafe { *(self.plug_view as *const *const *const c_void) };
            let removed: RemovedFn = unsafe { std::mem::transmute(*vtbl.add(5)) };
            unsafe { removed(self.plug_view) };

            // Release IPlugView
            type ReleaseFn = unsafe extern "system" fn(*mut c_void) -> u32;
            let release: ReleaseFn = unsafe { std::mem::transmute(*vtbl.add(2)) };
            unsafe { release(self.plug_view) };
            self.plug_view = std::ptr::null_mut();
        }
        // Frame outlives removed(): plugins unregister their handlers
        // in removed() and need the run loop alive to do it.
        self.frame = None;
        self.open = false;
    }

    /// Create the IPlugView from IEditController and attach to window.
    /// Call this when opening the GUI for the first time.
    pub fn open_view(&mut self, window_id: u32) -> bool {
        if self.edit_controller.is_null() {
            eprintln!("vibez: open_view — edit_controller is null");
            return false;
        }

        // If we already have a plug_view, destroy it first
        if !self.plug_view.is_null() {
            self.destroy();
        }

        // IEditController::createView(name) -> IPlugView*
        // IEditController vtable: FUnknown[0-2] + IPluginBase[3-4] + IEditController[5-17]
        // createView is at index 17 in the vtable
        type CreateViewFn = unsafe extern "system" fn(*mut c_void, *const u8) -> *mut c_void;
        let vtbl = unsafe { *(self.edit_controller as *const *const *const c_void) };
        let create_view: CreateViewFn = unsafe { std::mem::transmute(*vtbl.add(17)) };
        let editor_name = b"editor\0";
        eprintln!("vibez: open_view — calling createView(\"editor\")");
        let view = unsafe { create_view(self.edit_controller, editor_name.as_ptr()) };
        if view.is_null() {
            eprintln!("vibez: open_view — createView returned null");
            return false;
        }
        eprintln!("vibez: open_view — got IPlugView OK");
        self.plug_view = view;

        // Check if X11 is supported: IPlugView::isPlatformTypeSupported(type) - vtable[3]
        type IsPlatformSupportedFn = unsafe extern "system" fn(*mut c_void, *const u8) -> i32;
        let view_vtbl = unsafe { *(self.plug_view as *const *const *const c_void) };
        let is_supported: IsPlatformSupportedFn = unsafe { std::mem::transmute(*view_vtbl.add(3)) };
        let platform_type = b"X11EmbedWindowID\0";
        let hr = unsafe { is_supported(self.plug_view, platform_type.as_ptr()) };
        eprintln!("vibez: open_view — isPlatformTypeSupported(X11) = {hr}");
        if hr != 0 {
            eprintln!("vibez: open_view — X11 embedding not supported by plugin");
            // Not supported, clean up
            type ReleaseFn = unsafe extern "system" fn(*mut c_void) -> u32;
            let release: ReleaseFn = unsafe { std::mem::transmute(*view_vtbl.add(2)) };
            unsafe { release(self.plug_view) };
            self.plug_view = std::ptr::null_mut();
            return false;
        }

        // Provide IPlugFrame/IRunLoop before attaching: JUCE queries
        // the run loop during attached() and a null frame leaves the
        // editor frozen (no repaints, no input).
        let frame = crate::vst3_host::runloop::HostPlugFrame::new();
        // IPlugView::setFrame(frame) - vtable[12]
        type SetFrameFn = unsafe extern "system" fn(*mut c_void, *mut c_void) -> i32;
        let set_frame: SetFrameFn = unsafe { std::mem::transmute(*view_vtbl.add(12)) };
        let hr = unsafe { set_frame(self.plug_view, frame.as_iplugframe()) };
        if hr != 0 {
            eprintln!("vibez: open_view — setFrame returned {hr} (continuing)");
        }
        self.frame = Some(frame);

        // Attach to X11 window
        eprintln!("vibez: open_view — attaching to X11 window {window_id}");
        if !self.attach_to_x11(window_id) {
            eprintln!("vibez: open_view — attach_to_x11 failed");
            type ReleaseFn = unsafe extern "system" fn(*mut c_void) -> u32;
            let release: ReleaseFn = unsafe { std::mem::transmute(*view_vtbl.add(2)) };
            unsafe { release(self.plug_view) };
            self.plug_view = std::ptr::null_mut();
            return false;
        }
        eprintln!("vibez: open_view — attached successfully");

        self.open = true;
        true
    }
}

impl Drop for Vst3GuiHandle {
    fn drop(&mut self) {
        self.destroy();
        if !self.edit_controller.is_null() {
            // Release IEditController
            type ReleaseFn = unsafe extern "system" fn(*mut c_void) -> u32;
            let vtbl = unsafe { *(self.edit_controller as *const *const *const c_void) };
            let release: ReleaseFn = unsafe { std::mem::transmute(*vtbl.add(2)) };
            unsafe { release(self.edit_controller) };
            self.edit_controller = std::ptr::null_mut();
        }
    }
}

#[cfg(test)]
mod iid_tests {
    /// See vst3_host::instance::tests — hand-written IIDs must match
    /// the SDK-generated constants or plugins reject queryInterface.
    #[test]
    fn ieditcontroller_iid_matches_sdk() {
        let sdk: Vec<u8> = vst3::Steinberg::Vst::IEditController_iid
            .iter()
            .map(|b| *b as u8)
            .collect();
        assert_eq!(super::IEDIT_CONTROLLER_IID.as_slice(), sdk.as_slice());
    }
}
