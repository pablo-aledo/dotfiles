//! Canonical project/runtime projection for Arrange and Section timelines.

use std::collections::HashSet;
use std::sync::Arc;

use vibez_core::id::{ClipId, TrackId};
use vibez_core::track::{ClipFades, ClipInfo, MediaSourceRef};
use vibez_project::{SectionInfo, TimelineAutomationInfo, TimelineInfo, TimelineLocation};

use crate::domains::perform::{Section, SectionStore};
use crate::state::{AppState, ArrangementTimeline, UiClip, UiNoteClip};

pub(super) fn timeline_info_from_ui(timeline: &ArrangementTimeline) -> TimelineInfo {
    let mut track_ids: Vec<_> = timeline.by_track.keys().copied().collect();
    track_ids.sort_by_key(|id| id.raw());
    let mut info = TimelineInfo::default();
    for track_id in track_ids {
        let content = &timeline.by_track[&track_id];
        info.clips.extend(content.clips.iter().map(|clip| ClipInfo {
            id: clip.id,
            track_id,
            name: clip.name.clone(),
            position: clip.position,
            source_offset: clip.source_offset,
            start_marker: Some(clip.start_marker),
            duration: clip.duration,
            source: clip.source.clone(),
            file_path: clip.source.as_ref().and_then(|source| match source {
                MediaSourceRef::LocalFile { path } => Some(path.clone()),
                _ => None,
            }),
            loop_enabled: clip.loop_enabled,
            loop_start: clip.loop_start,
            loop_end: clip.loop_end,
            gain_db: clip.gain_db,
            fades: clip.fades,
            playback_direction: clip.playback_direction,
            transient_markers: clip.transient_markers.clone(),
            warp_markers: clip.warp_markers.clone(),
            transpose: clip.transpose,
            original_bpm: clip.original_bpm,
            warped: clip.warped,
            warped_to_bpm: clip.warped_to_bpm,
        }));
        info.note_clips
            .extend(
                content
                    .note_clips
                    .iter()
                    .map(|clip| vibez_core::midi::NoteClipInfo {
                        id: clip.id,
                        track_id,
                        name: clip.name.clone(),
                        position_beats: clip.position_beats,
                        duration_beats: clip.duration_beats,
                        notes: clip.notes.clone(),
                        start_marker_beats: Some(clip.start_marker_beats),
                        loop_enabled: clip.loop_enabled,
                        loop_start_beats: clip.loop_start_beats,
                        loop_end_beats: clip.loop_end_beats,
                        groove_grid: clip.groove_grid,
                    }),
            );
        if !content.automation.is_empty() {
            info.automation.push(TimelineAutomationInfo {
                track_id,
                lanes: content.automation.clone(),
            });
        }
    }
    info
}

pub(super) fn section_info_from_ui(section: &Section) -> SectionInfo {
    SectionInfo {
        id: section.id,
        slot: section.slot,
        name: section.name.clone(),
        length_beats: section.length_beats,
        launch_quantization: section.launch_quantization,
        looping: section.looping,
        timeline: timeline_info_from_ui(&section.timeline),
    }
}

pub(super) fn section_store_from_project(sections: &[SectionInfo]) -> SectionStore {
    let mut store = SectionStore::default();
    for info in sections {
        store.insert(Section {
            id: info.id,
            slot: info.slot,
            name: info.name.clone(),
            length_beats: info.length_beats,
            launch_quantization: info.launch_quantization,
            looping: info.looping,
            timeline: Arc::new(timeline_without_audio(&info.timeline)),
        });
    }
    store
}

pub(super) fn timeline_without_audio(info: &TimelineInfo) -> ArrangementTimeline {
    let mut timeline = ArrangementTimeline::default();
    for automation in &info.automation {
        timeline.ensure(automation.track_id).automation = automation.lanes.clone();
    }
    for clip in &info.note_clips {
        timeline.ensure(clip.track_id).note_clips.push(UiNoteClip {
            id: clip.id,
            name: clip.name.clone(),
            position_beats: clip.position_beats,
            duration_beats: clip.duration_beats,
            notes: clip.notes.clone(),
            selected_notes: HashSet::new(),
            start_marker_beats: clip.resolved_start_marker_beats(),
            loop_enabled: clip.loop_enabled,
            loop_start_beats: clip.loop_start_beats,
            loop_end_beats: clip.loop_end_beats,
            groove_grid: clip.groove_grid,
        });
    }
    timeline
}

pub(super) fn runtime_timeline_mut(
    state: &mut AppState,
    location: TimelineLocation,
) -> Option<&mut Arc<ArrangementTimeline>> {
    match location {
        TimelineLocation::Arrange => Some(&mut state.arrangement.timeline),
        TimelineLocation::Section(id) => Arc::make_mut(&mut state.perform.sections)
            .by_id_mut(id)
            .map(|section| &mut section.timeline),
    }
}

pub(super) fn install_loaded_clip(
    timeline: &mut ArrangementTimeline,
    loaded: crate::message::LoadedClipData,
) {
    let source_offset = loaded.info.source_offset;
    let start_marker = loaded
        .info
        .resolved_start_marker(loaded.audio.num_frames() as u64);
    let identity_source_end = source_offset
        .saturating_add(loaded.info.duration)
        .min(loaded.audio.num_frames() as u64);
    let mut warp_markers = loaded.info.warp_markers;
    let identity_timeline_end = loaded
        .info
        .duration
        .min((loaded.audio.num_frames() as u64).saturating_sub(source_offset));
    warp_markers.sanitize_for_clip(
        source_offset,
        loaded.audio.num_frames() as u64,
        identity_timeline_end,
    );
    let source_end = warp_markers.source_end(identity_source_end);
    let mut transient_markers = loaded.info.transient_markers;
    transient_markers.retain_source_range(source_offset, source_end);
    timeline.ensure(loaded.info.track_id).clips.push(UiClip {
        id: loaded.info.id,
        name: loaded.info.name,
        audio: loaded.audio,
        source: loaded.info.source.clone(),
        position: loaded.info.position,
        source_offset,
        start_marker,
        duration: loaded.info.duration,
        loop_enabled: loaded.info.loop_enabled,
        loop_start: loaded.info.loop_start,
        loop_end: loaded.info.loop_end,
        gain_db: loaded.info.gain_db,
        fades: loaded.info.fades.clamped_to(loaded.info.duration),
        playback_direction: loaded.info.playback_direction,
        transient_markers,
        warp_markers,
        transpose: loaded.info.transpose,
        original_bpm: loaded.info.original_bpm,
        warped: loaded.info.warped,
        warped_to_bpm: loaded.info.warped_to_bpm,
        original_audio: loaded.original_audio,
    });
}

#[derive(Clone, Copy)]
struct LoadedCrossfadeCandidate {
    location: TimelineLocation,
    track_id: TrackId,
    id: ClipId,
    start: u64,
    duration: u64,
    fades: ClipFades,
}

impl LoadedCrossfadeCandidate {
    fn from_loaded(loaded: &crate::message::LoadedTimelineClip) -> Self {
        Self {
            location: loaded.location,
            track_id: loaded.info.track_id,
            id: loaded.info.id,
            start: loaded.info.position,
            duration: loaded.info.duration,
            fades: loaded.info.fades,
        }
    }
}

fn valid_crossfade_pair(
    outgoing: LoadedCrossfadeCandidate,
    incoming: LoadedCrossfadeCandidate,
) -> bool {
    let outgoing_end = outgoing.start.saturating_add(outgoing.duration);
    let incoming_end = incoming.start.saturating_add(incoming.duration);
    let overlap = outgoing_end.saturating_sub(incoming.start);
    outgoing.location == incoming.location
        && outgoing.track_id == incoming.track_id
        && outgoing.start < incoming.start
        && incoming.start < outgoing_end
        && outgoing_end <= incoming_end
        && outgoing.fades.crossfade_out_to() == Some(incoming.id)
        && incoming.fades.crossfade_in_from() == Some(outgoing.id)
        && outgoing.fades.fade_out_frames() == overlap
        && incoming.fades.fade_in_frames() == overlap
}

pub(super) fn sanitize_loaded_crossfades(clips: &mut [crate::message::LoadedTimelineClip]) {
    for loaded in clips.iter_mut() {
        loaded.clip.info.fades = loaded.clip.info.fades.clamped_to(loaded.clip.info.duration);
    }
    let snapshot: Vec<_> = clips
        .iter()
        .map(LoadedCrossfadeCandidate::from_loaded)
        .collect();
    for loaded in clips {
        let info = &loaded.info;
        let candidate = LoadedCrossfadeCandidate::from_loaded(loaded);
        let incoming_valid = info.fades.crossfade_in_from().is_none_or(|outgoing_id| {
            snapshot
                .iter()
                .find(|entry| entry.id == outgoing_id)
                .is_some_and(|outgoing| valid_crossfade_pair(*outgoing, candidate))
        });
        let outgoing_valid = info.fades.crossfade_out_to().is_none_or(|incoming_id| {
            snapshot
                .iter()
                .find(|entry| entry.id == incoming_id)
                .is_some_and(|incoming| valid_crossfade_pair(candidate, *incoming))
        });
        if !incoming_valid {
            loaded.clip.info.fades = loaded.clip.info.fades.unlink_fade_in();
        }
        if !outgoing_valid {
            loaded.clip.info.fades = loaded.clip.info.fades.unlink_fade_out();
        }
    }
}

pub(super) fn apply_timeline_sources(timeline: &mut ArrangementTimeline, saved: &TimelineInfo) {
    for saved_clip in &saved.clips {
        if let Some(clip) = timeline.get_mut(saved_clip.track_id).and_then(|content| {
            content
                .clips
                .iter_mut()
                .find(|clip| clip.id == saved_clip.id)
        }) {
            clip.source = saved_clip.source.clone();
        }
    }
}

pub(super) fn legacy_automation_for_track(
    project: &vibez_project::Project,
    track_id: vibez_core::id::TrackId,
) -> Vec<vibez_core::automation::AutomationLane> {
    project
        .arrange
        .automation
        .iter()
        .find(|automation| automation.track_id == track_id)
        .map(|automation| automation.lanes.clone())
        .or_else(|| {
            project
                .tracks
                .iter()
                .chain(project.master.iter())
                .chain(project.buses.iter())
                .find(|track| track.id == track_id)
                .map(|track| track.automation.clone())
        })
        .unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;
    use vibez_core::id::{ClipId, TrackId};
    use vibez_core::midi::MidiNote;

    fn loaded_audio_clip(
        location: TimelineLocation,
        track_id: TrackId,
        clip_id: ClipId,
        position: u64,
        duration: u64,
        fades: ClipFades,
    ) -> crate::message::LoadedTimelineClip {
        crate::message::LoadedTimelineClip {
            location,
            clip: crate::message::LoadedClipData {
                info: ClipInfo {
                    id: clip_id,
                    track_id,
                    name: "Clip".into(),
                    position,
                    source_offset: 0,
                    start_marker: None,
                    duration,
                    source: None,
                    file_path: None,
                    loop_enabled: false,
                    loop_start: 0,
                    loop_end: duration,
                    gain_db: Default::default(),
                    fades,
                    playback_direction: Default::default(),
                    transient_markers: Default::default(),
                    warp_markers: Default::default(),
                    transpose: Default::default(),
                    original_bpm: None,
                    warped: false,
                    warped_to_bpm: None,
                },
                audio: Arc::new(vibez_core::audio_buffer::DecodedAudio {
                    channels: vec![vec![0.0; duration as usize]],
                    sample_rate: 48_000,
                }),
                original_audio: None,
            },
        }
    }

    #[test]
    fn project_load_keeps_reciprocal_crossfades_and_repairs_stale_links() {
        let track_id = TrackId::new();
        let outgoing_id = ClipId::new();
        let incoming_id = ClipId::new();
        let outgoing = ClipFades::default().linked_fade_out(250, incoming_id, 1_000);
        let incoming = ClipFades::default().linked_fade_in(250, outgoing_id, 1_000);
        let mut valid = vec![
            loaded_audio_clip(
                TimelineLocation::Arrange,
                track_id,
                outgoing_id,
                0,
                1_000,
                outgoing,
            ),
            loaded_audio_clip(
                TimelineLocation::Arrange,
                track_id,
                incoming_id,
                750,
                1_000,
                incoming,
            ),
        ];
        sanitize_loaded_crossfades(&mut valid);
        assert_eq!(valid[0].info.fades.crossfade_out_to(), Some(incoming_id));
        assert_eq!(valid[1].info.fades.crossfade_in_from(), Some(outgoing_id));

        valid[1].clip.info.position = 1_100;
        sanitize_loaded_crossfades(&mut valid);
        assert!(valid[0].info.fades.crossfade_out_to().is_none());
        assert!(valid[1].info.fades.crossfade_in_from().is_none());
    }

    #[test]
    fn authored_section_midi_projects_to_document_and_back() {
        let track_id = TrackId::new();
        let mut section = Section::new(2);
        Arc::make_mut(&mut section.timeline)
            .ensure(track_id)
            .note_clips
            .push(UiNoteClip {
                id: ClipId::new(),
                name: "Kick Pattern".into(),
                position_beats: 0.0,
                duration_beats: 16.0,
                notes: vec![MidiNote {
                    pitch: 36,
                    velocity: 100,
                    start_beat: 0.0,
                    duration_beats: 0.25,
                }],
                selected_notes: [0].into_iter().collect(),
                start_marker_beats: 0.0,
                loop_enabled: true,
                loop_start_beats: 0.0,
                loop_end_beats: 4.0,
                groove_grid: vibez_core::perform::GrooveGrid::Sixteenth,
            });

        let info = section_info_from_ui(&section);
        let restored = section_store_from_project(&[info]);
        let clip = &restored.sections[0]
            .timeline
            .get(track_id)
            .expect("restored MIDI lane")
            .note_clips[0];

        assert_eq!(clip.name, "Kick Pattern");
        assert_eq!(clip.notes.len(), 1);
        assert_eq!(clip.notes[0].pitch, 36);
        assert!(clip.selected_notes.is_empty(), "selection is runtime-only");
    }
}
