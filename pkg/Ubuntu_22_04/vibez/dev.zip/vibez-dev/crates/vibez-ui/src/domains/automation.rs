//! Automation domain: lane and point editing.
//!
//! Lanes live in Arrange Timeline Content and mirror to the
//! engine as whole-lane upserts: every edit clones the lane's points
//! into a [`EngineCommand::SetAutomationLane`], so the allocation
//! happens here on the UI thread and the audio thread only swaps
//! vectors.

use std::collections::HashSet;
use std::sync::Arc;

use vibez_core::automation::{AutomationLane, AutomationPoint, AutomationTarget};
use vibez_core::id::{LaneId, TrackId};
use vibez_engine::commands::EngineCommand;

use super::EngineHandle;
use crate::state::{ProjectTrack, ProjectTracksState, TimelineEditorState};

/// Messages the automation domain handles.
#[derive(Debug, Clone)]
pub enum AutomationMsg {
    /// Show/hide the lane strip under a track (view-only).
    ToggleTrackLanes(TrackId),
    AddLane {
        track_id: TrackId,
        target: AutomationTarget,
    },
    RemoveLane {
        track_id: TrackId,
        lane_id: LaneId,
    },
    AddPoint {
        track_id: TrackId,
        lane_id: LaneId,
        beat: f64,
        value: f32,
    },
    /// Move an existing point (drag release). The point keeps beat
    /// order, so its index may change; selection follows it.
    MovePoint {
        track_id: TrackId,
        lane_id: LaneId,
        index: usize,
        beat: f64,
        value: f32,
    },
    RemovePoint {
        track_id: TrackId,
        lane_id: LaneId,
        index: usize,
    },
    SelectPoint {
        track_id: TrackId,
        lane_id: LaneId,
        index: Option<usize>,
    },
    /// Delete-key routing (higher priority than clip deletion when a
    /// point is selected).
    DeleteSelectedPoint,
    /// Set the curve of the segment leaving point `index` (drag
    /// release of an alt-drag; -1..1, 0 = linear).
    SetCurve {
        track_id: TrackId,
        lane_id: LaneId,
        index: usize,
        curve: f32,
    },
    /// Remove every point in a beat range (ctrl-drag erase).
    RemovePointsInRange {
        track_id: TrackId,
        lane_id: LaneId,
        start_beat: f64,
        end_beat: f64,
    },
    OpenLanePicker(TrackId),
    LanePickerQuery(String),
    CloseLanePicker,
    /// Return an overridden parameter to lane control (view/runtime only).
    ReenableAutomation {
        track_id: TrackId,
        target: AutomationTarget,
    },
}

impl AutomationMsg {
    /// Whether this message edits the project (drives the dirty flag).
    pub fn marks_dirty(&self) -> bool {
        !matches!(
            self,
            AutomationMsg::ToggleTrackLanes(_)
                | AutomationMsg::SelectPoint { .. }
                | AutomationMsg::OpenLanePicker(_)
                | AutomationMsg::LanePickerQuery(_)
                | AutomationMsg::CloseLanePicker
                | AutomationMsg::ReenableAutomation { .. }
        )
    }
}

/// Cross-domain effects requested by an automation update.
#[derive(Debug, Default, PartialEq)]
pub struct AutomationAction {
    /// Status bar text.
    pub status: Option<String>,
}

/// Automation domain slice.
#[derive(Debug, Default)]
pub struct AutomationState {
    /// Tracks whose lane strip is expanded.
    pub expanded: HashSet<TrackId>,
    /// The selected point: (track, lane, point index).
    pub selected: Option<(TrackId, LaneId, usize)>,
    /// The open add-lane picker, with its search query.
    pub picker: Option<(TrackId, String)>,
    /// Runtime parameters whose manual control currently wins over a lane.
    pub overridden: HashSet<(TrackId, AutomationTarget)>,
}

fn sync_lane(engine: &mut impl EngineHandle, track_id: TrackId, lane: &AutomationLane) {
    engine.send(EngineCommand::SetAutomationLane {
        track_id,
        lane: lane.clone(),
    });
}

/// The target's CURRENT (un-automated) value, normalized 0..1.
/// This seeds new lanes and draws the reference line. Track gain's
/// native range is 0..2 (see the arrangement domain clamp).
pub fn normalized_target_value(target: &AutomationTarget, track: &ProjectTrack) -> Option<f32> {
    match target {
        AutomationTarget::TrackGain => Some((track.gain / 2.0).clamp(0.0, 1.0)),
        AutomationTarget::TrackPan => Some(track.pan.clamp(0.0, 1.0)),
        AutomationTarget::TrackMute => Some(if track.mute { 1.0 } else { 0.0 }),
        AutomationTarget::TrackSwingOffset => Some(
            track
                .swing_offset
                .unwrap_or_default()
                .normalized()
                .clamp(0.0, 1.0),
        ),
        AutomationTarget::EffectParam {
            effect_id,
            param_index,
        } => {
            let effect = track.effects.iter().find(|e| e.id == *effect_id)?;
            let d = effect.descriptors.get(*param_index)?;
            let v = effect
                .params
                .get(*param_index)
                .copied()
                .unwrap_or(d.default);
            Some(((v - d.min) / (d.max - d.min).max(f32::EPSILON)).clamp(0.0, 1.0))
        }
        AutomationTarget::InstrumentParam { param_index } => {
            if !track.plugin_instrument_descriptors.is_empty() {
                let d = track.plugin_instrument_descriptors.get(*param_index)?;
                // Plugin values are not mirrored UI-side; use the default.
                Some(((d.default - d.min) / (d.max - d.min).max(f32::EPSILON)).clamp(0.0, 1.0))
            } else {
                let kind = track.instrument_kind?;
                let d = vibez_instruments::descriptors_for(kind).get(*param_index)?;
                let v = track
                    .instrument_params
                    .get(*param_index)
                    .copied()
                    .unwrap_or(d.default);
                Some(((v - d.min) / (d.max - d.min).max(f32::EPSILON)).clamp(0.0, 1.0))
            }
        }
        AutomationTarget::PluginParam { .. } => None,
        AutomationTarget::Send { bus_id } => Some(
            track
                .sends
                .iter()
                .find(|(b, _)| b == bus_id)
                .map(|(_, amount)| *amount)
                .unwrap_or(0.0)
                .clamp(0.0, 1.0),
        ),
    }
}

/// Descriptor for send lanes: native 0..1, off by default.
pub static SEND_DESCRIPTOR: vibez_core::effect::ParamDescriptor =
    vibez_core::effect::ParamDescriptor {
        name: "Send",
        min: 0.0,
        max: 1.0,
        default: 0.0,
        unit: "",
    };

pub static TRACK_SWING_OFFSET_DESCRIPTOR: vibez_core::effect::ParamDescriptor =
    vibez_core::effect::ParamDescriptor {
        name: "Track Swing",
        min: -25.0,
        max: 25.0,
        default: 0.0,
        unit: "%",
    };

/// The static descriptor behind a target, when one exists (effect
/// and instrument params). Gain/pan have implicit ranges.
pub fn target_descriptor(
    target: &AutomationTarget,
    track: &ProjectTrack,
) -> Option<&'static vibez_core::effect::ParamDescriptor> {
    match target {
        AutomationTarget::EffectParam {
            effect_id,
            param_index,
        } => track
            .effects
            .iter()
            .find(|e| e.id == *effect_id)?
            .descriptors
            .get(*param_index),
        AutomationTarget::InstrumentParam { param_index } => {
            if !track.plugin_instrument_descriptors.is_empty() {
                track.plugin_instrument_descriptors.get(*param_index)
            } else {
                vibez_instruments::descriptors_for(track.instrument_kind?).get(*param_index)
            }
        }
        AutomationTarget::Send { .. } => Some(&SEND_DESCRIPTOR),
        AutomationTarget::TrackSwingOffset => Some(&TRACK_SWING_OFFSET_DESCRIPTOR),
        _ => None,
    }
}

/// Human-readable name for a lane target, for lane headers and the
/// add-lane picker.
pub fn target_label(target: &AutomationTarget, track: &ProjectTrack) -> String {
    match target {
        AutomationTarget::TrackGain => "Volume".to_string(),
        AutomationTarget::TrackPan => "Pan".to_string(),
        AutomationTarget::TrackMute => "Track Mute".to_string(),
        AutomationTarget::TrackSwingOffset => "Track Swing".to_string(),
        AutomationTarget::EffectParam {
            effect_id,
            param_index,
        } => {
            let Some(effect) = track.effects.iter().find(|e| e.id == *effect_id) else {
                return "Missing effect".to_string();
            };
            let effect_name = effect
                .plugin_name
                .clone()
                .unwrap_or_else(|| format!("{:?}", effect.effect_type));
            match effect.descriptors.get(*param_index) {
                Some(d) => format!("{effect_name}: {}", d.name),
                None => format!("{effect_name}: P{param_index}"),
            }
        }
        AutomationTarget::InstrumentParam { param_index } => {
            let (name, descriptors) = if !track.plugin_instrument_descriptors.is_empty() {
                (
                    track.plugin_instrument_name.as_deref().unwrap_or("Plugin"),
                    track.plugin_instrument_descriptors,
                )
            } else {
                (
                    "Instrument",
                    track
                        .instrument_kind
                        .map(vibez_instruments::descriptors_for)
                        .unwrap_or(&[]),
                )
            };
            match descriptors.get(*param_index) {
                Some(d) => format!("{name}: {}", d.name),
                None => format!("{name} P{param_index}"),
            }
        }
        AutomationTarget::PluginParam { .. } => "Plugin param".to_string(),
        // The bus name isn't reachable from the owning track; the
        // caller-facing label fn below adds it when buses are known.
        AutomationTarget::Send { .. } => "Send".to_string(),
    }
}

/// [`target_label`], with bus names resolved for send lanes.
pub fn target_label_with_buses(
    target: &AutomationTarget,
    track: &ProjectTrack,
    buses: &[ProjectTrack],
) -> String {
    if let AutomationTarget::Send { bus_id } = target {
        if let Some(bus) = buses.iter().find(|b| b.id == *bus_id) {
            return format!("Send: {}", bus.name);
        }
        return "Send: (removed bus)".to_string();
    }
    target_label(target, track)
}

impl AutomationState {
    pub fn update(
        &mut self,
        msg: AutomationMsg,
        engine: &mut impl EngineHandle,
        project_tracks: &mut ProjectTracksState,
        editor: &mut TimelineEditorState,
    ) -> AutomationAction {
        let timeline = Arc::make_mut(&mut editor.timeline);
        let mut action = AutomationAction::default();
        match msg {
            AutomationMsg::ToggleTrackLanes(track_id) => {
                if !self.expanded.remove(&track_id) {
                    self.expanded.insert(track_id);
                }
            }
            AutomationMsg::AddLane { track_id, target } => {
                let Some(track) = project_tracks.find(track_id) else {
                    return action;
                };
                // A send lane needs its engine-side send entry to
                // exist before evaluation (the render path must not
                // allocate); mirror the current amount down.
                if let AutomationTarget::Send { bus_id } = target {
                    let amount = track
                        .sends
                        .iter()
                        .find(|(b, _)| *b == bus_id)
                        .map(|(_, a)| *a)
                        .unwrap_or(0.0);
                    engine.send(EngineCommand::SetSend {
                        track_id,
                        bus_id,
                        amount,
                    });
                }
                let content = timeline.ensure(track_id);
                if content.automation.iter().any(|l| l.target == target) {
                    action.status = Some("That parameter already has a lane".to_string());
                    return action;
                }
                let mut lane = AutomationLane::new(target);
                // Start where the knob already is.
                if let Some(value) = normalized_target_value(&target, track) {
                    lane.insert_point(AutomationPoint {
                        beat: 0.0,
                        value,
                        curve: 0.0,
                    });
                }
                sync_lane(engine, track_id, &lane);
                let label = target_label(&target, track);
                content.automation.push(lane);
                self.expanded.insert(track_id);
                self.picker = None;
                action.status = Some(format!("Added automation lane: {label}"));
            }
            AutomationMsg::RemoveLane { track_id, lane_id } => {
                let removed_target = timeline.get(track_id).and_then(|content| {
                    content
                        .automation
                        .iter()
                        .find(|lane| lane.id == lane_id)
                        .map(|lane| lane.target)
                });
                if let Some(content) = timeline.get_mut(track_id) {
                    content.automation.retain(|l| l.id != lane_id);
                }
                engine.send(EngineCommand::RemoveAutomationLane { track_id, lane_id });
                if let Some(target) = removed_target {
                    if self.overridden.remove(&(track_id, target)) {
                        engine.send(EngineCommand::SetAutomationOverride {
                            track_id,
                            target,
                            overridden: false,
                        });
                    }
                }
                if matches!(self.selected, Some((t, l, _)) if t == track_id && l == lane_id) {
                    self.selected = None;
                }
                action.status = Some("Removed automation lane".to_string());
            }
            AutomationMsg::AddPoint {
                track_id,
                lane_id,
                beat,
                value,
            } => {
                let Some(lane) = timeline
                    .get_mut(track_id)
                    .and_then(|content| content.automation.iter_mut().find(|l| l.id == lane_id))
                else {
                    return action;
                };
                let point = AutomationPoint {
                    beat: beat.max(0.0),
                    value: if lane.target.is_stepped() {
                        if value >= 0.5 {
                            1.0
                        } else {
                            0.0
                        }
                    } else {
                        value.clamp(0.0, 1.0)
                    },
                    curve: 0.0,
                };
                lane.insert_point(point);
                let index = lane
                    .points
                    .iter()
                    .position(|p| p.beat == point.beat)
                    .unwrap_or(0);
                let lane = lane.clone();
                sync_lane(engine, track_id, &lane);
                self.selected = Some((track_id, lane_id, index));
            }
            AutomationMsg::MovePoint {
                track_id,
                lane_id,
                index,
                beat,
                value,
            } => {
                let Some(lane) = timeline
                    .get_mut(track_id)
                    .and_then(|content| content.automation.iter_mut().find(|l| l.id == lane_id))
                else {
                    return action;
                };
                if index >= lane.points.len() {
                    return action;
                }
                let stepped = lane.target.is_stepped();
                let curve = if stepped {
                    0.0
                } else {
                    lane.points[index].curve
                };
                lane.points.remove(index);
                let point = AutomationPoint {
                    beat: beat.max(0.0),
                    value: if stepped {
                        if value >= 0.5 {
                            1.0
                        } else {
                            0.0
                        }
                    } else {
                        value.clamp(0.0, 1.0)
                    },
                    curve,
                };
                lane.insert_point(point);
                let new_index = lane
                    .points
                    .iter()
                    .position(|p| p.beat == point.beat)
                    .unwrap_or(0);
                let lane = lane.clone();
                sync_lane(engine, track_id, &lane);
                self.selected = Some((track_id, lane_id, new_index));
            }
            AutomationMsg::RemovePoint {
                track_id,
                lane_id,
                index,
            } => {
                let Some(lane) = timeline
                    .get_mut(track_id)
                    .and_then(|content| content.automation.iter_mut().find(|l| l.id == lane_id))
                else {
                    return action;
                };
                if index >= lane.points.len() {
                    return action;
                }
                lane.points.remove(index);
                let lane = lane.clone();
                sync_lane(engine, track_id, &lane);
                if matches!(self.selected, Some((t, l, i)) if t == track_id && l == lane_id && i == index)
                {
                    self.selected = None;
                }
            }
            AutomationMsg::SelectPoint {
                track_id,
                lane_id,
                index,
            } => {
                self.selected = index.map(|i| (track_id, lane_id, i));
            }
            AutomationMsg::SetCurve {
                track_id,
                lane_id,
                index,
                curve,
            } => {
                let Some(lane) = timeline
                    .get_mut(track_id)
                    .and_then(|content| content.automation.iter_mut().find(|l| l.id == lane_id))
                else {
                    return action;
                };
                if index >= lane.points.len() {
                    return action;
                }
                if lane.target.is_stepped() {
                    return action;
                }
                lane.points[index].curve = curve.clamp(-1.0, 1.0);
                let lane = lane.clone();
                sync_lane(engine, track_id, &lane);
            }
            AutomationMsg::RemovePointsInRange {
                track_id,
                lane_id,
                start_beat,
                end_beat,
            } => {
                let (lo, hi) = if start_beat <= end_beat {
                    (start_beat, end_beat)
                } else {
                    (end_beat, start_beat)
                };
                let Some(lane) = timeline
                    .get_mut(track_id)
                    .and_then(|content| content.automation.iter_mut().find(|l| l.id == lane_id))
                else {
                    return action;
                };
                let before = lane.points.len();
                lane.points.retain(|p| p.beat < lo || p.beat > hi);
                if lane.points.len() != before {
                    let lane = lane.clone();
                    sync_lane(engine, track_id, &lane);
                    if matches!(self.selected, Some((t, l, _)) if t == track_id && l == lane_id) {
                        self.selected = None;
                    }
                    action.status = Some(format!("Erased {} point(s)", before - lane.points.len()));
                }
            }
            AutomationMsg::OpenLanePicker(track_id) => {
                self.picker = Some((track_id, String::new()));
            }
            AutomationMsg::LanePickerQuery(query) => {
                if let Some((_, q)) = &mut self.picker {
                    *q = query;
                }
            }
            AutomationMsg::CloseLanePicker => {
                self.picker = None;
            }
            AutomationMsg::ReenableAutomation { track_id, target } => {
                self.overridden.remove(&(track_id, target));
                engine.send(EngineCommand::SetAutomationOverride {
                    track_id,
                    target,
                    overridden: false,
                });
                action.status = Some(format!(
                    "{} automation re-enabled",
                    project_tracks
                        .find(track_id)
                        .map(|track| target_label(&target, track))
                        .unwrap_or_else(|| "Parameter".to_string())
                ));
            }
            AutomationMsg::DeleteSelectedPoint => {
                if let Some((track_id, lane_id, index)) = self.selected.take() {
                    let Some(lane) = timeline.get_mut(track_id).and_then(|content| {
                        content
                            .automation
                            .iter_mut()
                            .find(|lane| lane.id == lane_id)
                    }) else {
                        return action;
                    };
                    if index < lane.points.len() {
                        lane.points.remove(index);
                        let lane = lane.clone();
                        sync_lane(engine, track_id, &lane);
                    }
                }
            }
        }
        action
    }

    pub fn set_override(&mut self, track_id: TrackId, target: AutomationTarget, overridden: bool) {
        if overridden {
            self.overridden.insert((track_id, target));
        } else {
            self.overridden.remove(&(track_id, target));
        }
    }

    pub fn is_overridden(&self, track_id: TrackId, target: AutomationTarget) -> bool {
        self.overridden.contains(&(track_id, target))
    }
}

#[cfg(test)]
mod tests {
    use super::super::test_support::RecordingEngine;
    use super::*;

    fn track() -> (ProjectTracksState, TimelineEditorState, TrackId) {
        let track = ProjectTrack::new(TrackId::new(), "T1".to_string(), 0);
        let track_id = track.id;
        let mut project_tracks = ProjectTracksState::default();
        project_tracks.tracks.push(track);
        let mut timeline = TimelineEditorState::default();
        timeline.ensure(track_id);
        (project_tracks, timeline, track_id)
    }

    #[test]
    fn add_lane_syncs_and_expands() {
        let mut a = AutomationState::default();
        let mut engine = RecordingEngine::default();
        let (mut tracks, mut timeline, tid) = track();
        a.update(
            AutomationMsg::AddLane {
                track_id: tid,
                target: AutomationTarget::TrackGain,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        assert_eq!(timeline.get(tid).unwrap().automation.len(), 1);
        assert!(a.expanded.contains(&tid));
        assert!(matches!(
            engine.0[0],
            EngineCommand::SetAutomationLane { .. }
        ));

        // Duplicate target refused.
        let action = a.update(
            AutomationMsg::AddLane {
                track_id: tid,
                target: AutomationTarget::TrackGain,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        assert_eq!(timeline.get(tid).unwrap().automation.len(), 1);
        assert!(action.status.unwrap().contains("already"));
    }

    #[test]
    fn point_lifecycle_add_move_delete() {
        let mut a = AutomationState::default();
        let mut engine = RecordingEngine::default();
        let (mut tracks, mut timeline, tid) = track();
        a.update(
            AutomationMsg::AddLane {
                track_id: tid,
                target: AutomationTarget::TrackGain,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let lane_id = timeline.get(tid).unwrap().automation[0].id;

        a.update(
            AutomationMsg::AddPoint {
                track_id: tid,
                lane_id,
                beat: 8.0,
                value: 0.25,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        a.update(
            AutomationMsg::AddPoint {
                track_id: tid,
                lane_id,
                beat: 0.0,
                value: 1.0,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let beats: Vec<f64> = timeline.get(tid).unwrap().automation[0]
            .points
            .iter()
            .map(|p| p.beat)
            .collect();
        assert_eq!(beats, vec![0.0, 8.0]);
        assert_eq!(a.selected, Some((tid, lane_id, 0)));

        // Drag point 0 past point 1: selection follows to the end.
        a.update(
            AutomationMsg::MovePoint {
                track_id: tid,
                lane_id,
                index: 0,
                beat: 16.0,
                value: 0.5,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let beats: Vec<f64> = timeline.get(tid).unwrap().automation[0]
            .points
            .iter()
            .map(|p| p.beat)
            .collect();
        assert_eq!(beats, vec![8.0, 16.0]);
        assert_eq!(a.selected, Some((tid, lane_id, 1)));

        // Delete key removes the selected point.
        a.update(
            AutomationMsg::DeleteSelectedPoint,
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        assert_eq!(timeline.get(tid).unwrap().automation[0].points.len(), 1);
        assert_eq!(a.selected, None);
    }

    #[test]
    fn track_mute_points_are_binary_and_curve_edits_are_ignored() {
        let mut automation = AutomationState::default();
        let mut engine = RecordingEngine::default();
        let (mut tracks, mut timeline, track_id) = track();
        automation.update(
            AutomationMsg::AddLane {
                track_id,
                target: AutomationTarget::TrackMute,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let lane_id = timeline.get(track_id).unwrap().automation[0].id;
        automation.update(
            AutomationMsg::AddPoint {
                track_id,
                lane_id,
                beat: 4.0,
                value: 0.7,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        automation.update(
            AutomationMsg::SetCurve {
                track_id,
                lane_id,
                index: 0,
                curve: 1.0,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );

        let lane = &timeline.get(track_id).unwrap().automation[0];
        assert_eq!(lane.value_at(4.0), Some(1.0));
        assert!(lane.points.iter().all(|point| point.curve == 0.0));
    }

    #[test]
    fn reenable_clears_visible_override_and_notifies_the_engine() {
        let mut automation = AutomationState::default();
        let mut engine = RecordingEngine::default();
        let (mut tracks, mut timeline, track_id) = track();
        automation.set_override(track_id, AutomationTarget::TrackMute, true);
        assert!(automation.is_overridden(track_id, AutomationTarget::TrackMute));

        automation.update(
            AutomationMsg::ReenableAutomation {
                track_id,
                target: AutomationTarget::TrackMute,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );

        assert!(!automation.is_overridden(track_id, AutomationTarget::TrackMute));
        assert!(matches!(
            engine.0.last(),
            Some(EngineCommand::SetAutomationOverride {
                track_id: event_track,
                target: AutomationTarget::TrackMute,
                overridden: false,
            }) if *event_track == track_id
        ));
    }

    #[test]
    fn remove_lane_clears_engine_and_selection() {
        let mut a = AutomationState::default();
        let mut engine = RecordingEngine::default();
        let (mut tracks, mut timeline, tid) = track();
        a.update(
            AutomationMsg::AddLane {
                track_id: tid,
                target: AutomationTarget::TrackPan,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let lane_id = timeline.get(tid).unwrap().automation[0].id;
        a.selected = Some((tid, lane_id, 0));
        a.update(
            AutomationMsg::RemoveLane {
                track_id: tid,
                lane_id,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        assert!(timeline.get(tid).unwrap().automation.is_empty());
        assert_eq!(a.selected, None);
        assert!(matches!(
            engine.0.last(),
            Some(EngineCommand::RemoveAutomationLane { .. })
        ));
    }

    #[test]
    fn values_clamp_to_unit_range() {
        let mut a = AutomationState::default();
        let mut engine = RecordingEngine::default();
        let (mut tracks, mut timeline, tid) = track();
        a.update(
            AutomationMsg::AddLane {
                track_id: tid,
                target: AutomationTarget::TrackGain,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let lane_id = timeline.get(tid).unwrap().automation[0].id;
        a.update(
            AutomationMsg::AddPoint {
                track_id: tid,
                lane_id,
                beat: -3.0,
                value: 7.0,
            },
            &mut engine,
            &mut tracks,
            &mut timeline,
        );
        let p = timeline.get(tid).unwrap().automation[0].points[0];
        assert_eq!(p.beat, 0.0);
        assert_eq!(p.value, 1.0);
    }
}
