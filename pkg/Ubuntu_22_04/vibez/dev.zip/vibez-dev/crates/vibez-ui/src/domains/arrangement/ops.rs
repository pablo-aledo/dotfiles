//! Multi-clip and range operations for Arrange Timeline Content.

use std::collections::HashSet;
use std::sync::Arc;

use vibez_core::id::{ClipId, TrackId};
use vibez_engine::commands::EngineCommand;

use super::{ArrangementAction, ArrangementCtx, EngineHandle};
use crate::state::{
    ArrangementMarquee, ArrangementMarqueeRect, ArrangementSelection, ProjectTracksState,
    TimelineEditorState, UiNoteClip,
};

impl TimelineEditorState {
    /// Resolve a rubber-band rectangle into a clip selection.
    ///
    /// A clip counts as caught when its span *overlaps* the box, matching
    /// how a marquee reads on screen. Range operations like
    /// [`Self::op_delete_clips_in_region`] deliberately demand full
    /// containment instead, because deleting a clip you only clipped the
    /// edge of would destroy material outside the selection.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn op_marquee_select(
        &mut self,
        ctx: ArrangementCtx,
        anchor_track: TrackId,
        start_beats: f64,
        end_beats: f64,
        top_y: f32,
        bottom_y: f32,
        track_ids: &[TrackId],
        additive: bool,
    ) -> ArrangementAction {
        // The first update of a gesture captures the selection it started
        // from, so shrinking an additive box hands back the clips it no
        // longer covers instead of accumulating them forever.
        let base = match self.marquee.take() {
            Some(marquee) => marquee.base,
            None if additive => self.selected_clips.clone(),
            None => HashSet::new(),
        };

        let mut selected = base.clone();
        let spb = ctx.samples_per_beat;
        for track_id in track_ids {
            let Some(content) = self.timeline.get(*track_id) else {
                continue;
            };
            if spb > 0.0 {
                for clip in &content.clips {
                    let clip_start = clip.position as f64 / spb;
                    let clip_end = (clip.position + clip.duration) as f64 / spb;
                    if clip_start < end_beats && clip_end > start_beats {
                        selected.insert(ArrangementSelection::AudioClip {
                            track_id: *track_id,
                            clip_id: clip.id,
                        });
                    }
                }
            }
            for clip in &content.note_clips {
                let clip_end = clip.position_beats + clip.duration_beats;
                if clip.position_beats < end_beats && clip_end > start_beats {
                    selected.insert(ArrangementSelection::NoteClip {
                        track_id: *track_id,
                        clip_id: clip.id,
                    });
                }
            }
        }

        self.selected_clips = selected;
        self.marquee = Some(ArrangementMarquee {
            rect: ArrangementMarqueeRect {
                start_beats,
                end_beats,
                top_y,
                bottom_y,
            },
            base,
        });

        // A box with horizontal extent also carries the time selection,
        // exactly as the single-lane region drag it replaces did. A purely
        // vertical drag has no range, so it leaves the old one alone.
        if end_beats > start_beats {
            self.selection_start_beats = start_beats;
            self.selection_end_beats = end_beats;
            self.time_selection_active = true;
            self.time_selection_track = Some(anchor_track);
        }
        self.selected_track = Some(anchor_track);

        ArrangementAction::default()
    }

    pub(super) fn op_delete_clips_in_region(
        &mut self,
        engine: &mut impl EngineHandle,
        ctx: ArrangementCtx,
        start_beats: f64,
        end_beats: f64,
        track_id: Option<TrackId>,
    ) -> ArrangementAction {
        let mut action = ArrangementAction::default();
        let target_track = track_id;
        let spb = ctx.samples_per_beat;
        // Preserve material outside the range. Splitting first turns
        // the selected span into whole clips that can be removed.
        let _ = self.op_split_clips_at_region(engine, ctx, start_beats, end_beats, track_id);
        // Collect clip IDs to remove
        let mut audio_removals: Vec<(TrackId, ClipId)> = Vec::new();
        let mut note_removals: Vec<(TrackId, ClipId)> = Vec::new();
        for (content_track_id, track) in &self.timeline.by_track {
            if let Some(tid) = target_track {
                if *content_track_id != tid {
                    continue;
                }
            }
            if spb > 0.0 {
                for clip in &track.clips {
                    let clip_start = clip.position as f64 / spb;
                    let clip_end = (clip.position + clip.duration) as f64 / spb;
                    if clip_start >= start_beats - 1e-9 && clip_end <= end_beats + 1e-9 {
                        audio_removals.push((*content_track_id, clip.id));
                    }
                }
            }
            for nc in &track.note_clips {
                let clip_end = nc.position_beats + nc.duration_beats;
                if nc.position_beats >= start_beats - 1e-9 && clip_end <= end_beats + 1e-9 {
                    note_removals.push((*content_track_id, nc.id));
                }
            }
        }
        for (tid, cid) in &audio_removals {
            engine.send(EngineCommand::RemoveClip(*tid, *cid));
            if let Some(track) = self.find_content_mut(*tid) {
                track.clips.retain(|c| c.id != *cid);
            }
        }
        for (tid, cid) in &note_removals {
            engine.send(EngineCommand::RemoveNoteClip(*tid, *cid));
            if let Some(track) = self.find_content_mut(*tid) {
                track.note_clips.retain(|c| c.id != *cid);
            }
        }
        self.selected_clips.clear();
        self.selected_note_clip = None;
        self.clear_time_selection();
        let count = audio_removals.len() + note_removals.len();
        action.status = Some(format!("Deleted {count} clips in region"));
        action
    }

    pub(super) fn op_split_clips_at_region(
        &mut self,
        engine: &mut impl EngineHandle,
        ctx: ArrangementCtx,
        start_beats: f64,
        end_beats: f64,
        track_id: Option<TrackId>,
    ) -> ArrangementAction {
        let mut action = ArrangementAction::default();
        let target_track = track_id;
        let spb = ctx.samples_per_beat;
        let mut split_count = 0u32;

        // Split at start boundary first, then end boundary.
        // After a split, new clips replace the original, so we
        // re-scan the track list between boundary passes.
        for boundary_beats in [start_beats, end_beats] {
            let boundary_sample = (boundary_beats * spb) as u64;

            // Collect audio splits for this boundary, limited to
            // the originating track when the selection was drawn
            // on a single lane.
            let audio_hits: Vec<(TrackId, ClipId)> = if spb > 0.0 {
                self.timeline
                    .by_track
                    .iter()
                    .filter(|(tid, _)| target_track.is_none_or(|target| **tid == target))
                    .flat_map(|(tid, content)| {
                        content.clips.iter().filter_map(|c| {
                            let cs = c.position as f64 / spb;
                            let ce = (c.position + c.duration) as f64 / spb;
                            if boundary_beats > cs && boundary_beats < ce {
                                Some((*tid, c.id))
                            } else {
                                None
                            }
                        })
                    })
                    .collect()
            } else {
                Vec::new()
            };

            let note_hits: Vec<(TrackId, ClipId)> = self
                .timeline
                .by_track
                .iter()
                .filter(|(tid, _)| target_track.is_none_or(|target| **tid == target))
                .flat_map(|(tid, content)| {
                    content.note_clips.iter().filter_map(|c| {
                        let ce = c.position_beats + c.duration_beats;
                        if boundary_beats > c.position_beats && boundary_beats < ce {
                            Some((*tid, c.id))
                        } else {
                            None
                        }
                    })
                })
                .collect();

            for (tid, cid) in audio_hits {
                let _ = self.op_split_audio_clip(engine, ctx, tid, cid, boundary_sample);
                split_count += 1;
            }
            for (tid, cid) in note_hits {
                let _ = self.op_split_note_clip(engine, ctx, tid, cid, boundary_beats);
                split_count += 1;
            }
        }

        if split_count > 0 {
            action.status = Some(format!("Split {split_count} clips at region boundaries"));
        }
        action
    }

    pub(super) fn op_create_clip_from_selection(
        &mut self,
        project_tracks: &ProjectTracksState,
        engine: &mut impl EngineHandle,
        ctx: ArrangementCtx,
    ) -> ArrangementAction {
        let mut action = ArrangementAction::default();
        if let Some(tid) = self.selected_track {
            if let Some(track) = project_tracks.find(tid) {
                if track.kind.is_midi() {
                    return self.op_create_note_clip_from_selection(
                        project_tracks,
                        engine,
                        ctx,
                        tid,
                    );
                } else {
                    action.status = Some("Select a time region on a MIDI track".to_string());
                }
            }
        } else {
            action.status = Some("No track selected".to_string());
        }
        action
    }

    pub(super) fn op_create_note_clip_from_selection(
        &mut self,
        project_tracks: &ProjectTracksState,
        engine: &mut impl EngineHandle,
        _ctx: ArrangementCtx,
        track_id: TrackId,
    ) -> ArrangementAction {
        let mut action = ArrangementAction::default();
        if !self.time_selection_active || self.selection_end_beats <= self.selection_start_beats {
            action.status = Some("No time selection active".to_string());
            return action;
        }
        if let Some(track) = project_tracks.find(track_id) {
            if !track.kind.is_midi() {
                action.status = Some("Can only create note clips on MIDI tracks".to_string());
                return action;
            }
        }
        let clip_id = ClipId::new();
        let position_beats = self.selection_start_beats;
        let duration_beats = self.selection_end_beats - self.selection_start_beats;
        let track = Arc::make_mut(&mut self.timeline).ensure(track_id);
        track.note_clips.push(UiNoteClip {
            id: clip_id,
            name: format!("Pattern {}", track.note_clips.len() + 1),
            position_beats,
            duration_beats,
            notes: Vec::new(),
            selected_notes: HashSet::new(),
            start_marker_beats: 0.0,
            loop_enabled: false,
            loop_start_beats: 0.0,
            loop_end_beats: 0.0,
            groove_grid: vibez_core::perform::GrooveGrid::Off,
        });
        engine.send(EngineCommand::AddNoteClip {
            start_marker_beats: 0.0,
            track_id,
            clip_id,
            position_beats,
            duration_beats,
            loop_enabled: false,
            loop_start_beats: 0.0,
            loop_end_beats: 0.0,
            groove_grid: vibez_core::perform::GrooveGrid::Off,
        });
        self.selected_note_clip = Some((track_id, clip_id));
        self.selected_clips.clear();
        self.selected_clips
            .insert(ArrangementSelection::NoteClip { track_id, clip_id });
        action.status = Some("Created note clip from selection".to_string());
        action
    }

    pub(super) fn op_join_selected_clips(
        &mut self,
        engine: &mut impl EngineHandle,
        ctx: ArrangementCtx,
    ) -> ArrangementAction {
        let mut action = ArrangementAction::default();
        let _ = ctx;
        let clips: Vec<_> = self.selected_clips.iter().copied().collect();
        if clips.len() < 2 {
            return action;
        }

        // Validate: all must be same type and same track
        let first_track = match clips[0] {
            ArrangementSelection::AudioClip { track_id, .. } => track_id,
            ArrangementSelection::NoteClip { track_id, .. } => track_id,
        };
        let all_audio = clips.iter().all(|s| {
                matches!(s, ArrangementSelection::AudioClip { track_id, .. } if *track_id == first_track)
            });
        let all_note = clips.iter().all(|s| {
                matches!(s, ArrangementSelection::NoteClip { track_id, .. } if *track_id == first_track)
            });

        if all_audio {
            action.status = self.join_audio_clips(first_track, &clips, engine);
        } else if all_note {
            action.status = self.join_note_clips(first_track, &clips, engine);
        } else {
            action.status = Some("Join requires same type and track".to_string());
        }
        action
    }

    pub(super) fn op_toggle_selected_clip_loop(
        &mut self,
        engine: &mut impl EngineHandle,
    ) -> ArrangementAction {
        let selections: Vec<_> = self.selected_clips.iter().copied().collect();
        let enable = selections.iter().any(|selection| match selection {
            ArrangementSelection::AudioClip { track_id, clip_id } => self
                .find_content(*track_id)
                .and_then(|t| t.clips.iter().find(|c| c.id == *clip_id))
                .is_some_and(|c| !c.loop_enabled),
            ArrangementSelection::NoteClip { track_id, clip_id } => self
                .find_content(*track_id)
                .and_then(|t| t.note_clips.iter().find(|c| c.id == *clip_id))
                .is_some_and(|c| !c.loop_enabled),
        });
        let mut changed = 0;
        for selection in selections {
            match selection {
                ArrangementSelection::AudioClip { track_id, clip_id } => {
                    let mut command = None;
                    if let Some(clip) = self
                        .find_content_mut(track_id)
                        .and_then(|t| t.clips.iter_mut().find(|c| c.id == clip_id))
                    {
                        let was_enabled = clip.loop_enabled;
                        if enable && !was_enabled {
                            clip.enable_loop_over_clip();
                        } else {
                            clip.loop_enabled = enable;
                        }
                        command = Some((clip.loop_start, clip.loop_end));
                        changed += 1;
                    }
                    if let Some((loop_start, loop_end)) = command {
                        engine.send(EngineCommand::SetClipLoop {
                            track_id,
                            clip_id,
                            enabled: enable,
                            loop_start,
                            loop_end,
                        });
                    }
                }
                ArrangementSelection::NoteClip { track_id, clip_id } => {
                    let mut command = None;
                    if let Some(clip) = self
                        .find_content_mut(track_id)
                        .and_then(|t| t.note_clips.iter_mut().find(|c| c.id == clip_id))
                    {
                        let was_enabled = clip.loop_enabled;
                        if enable && !was_enabled {
                            clip.enable_loop_over_clip();
                        } else {
                            clip.loop_enabled = enable;
                        }
                        command = Some((clip.loop_start_beats, clip.loop_end_beats));
                        changed += 1;
                    }
                    if let Some((loop_start_beats, loop_end_beats)) = command {
                        engine.send(EngineCommand::SetNoteClipLoop {
                            track_id,
                            clip_id,
                            enabled: enable,
                            loop_start_beats,
                            loop_end_beats,
                        });
                    }
                }
            }
        }
        ArrangementAction {
            status: (changed > 0).then(|| {
                format!(
                    "{} loop for {changed} clip{}",
                    if enable { "Enabled" } else { "Disabled" },
                    if changed == 1 { "" } else { "s" }
                )
            }),
            ..Default::default()
        }
    }

    pub(super) fn op_resize_selected_clips(
        &mut self,
        _project_tracks: &mut ProjectTracksState,
        engine: &mut impl EngineHandle,
        ctx: ArrangementCtx,
        anchor: ArrangementSelection,
        new_duration_beats: f64,
    ) -> ArrangementAction {
        if ctx.samples_per_beat <= 0.0 {
            return ArrangementAction::default();
        }
        let anchor_duration = match anchor {
            ArrangementSelection::AudioClip { track_id, clip_id } => self
                .find_content(track_id)
                .and_then(|t| t.clips.iter().find(|c| c.id == clip_id))
                .map(|c| c.duration as f64 / ctx.samples_per_beat),
            ArrangementSelection::NoteClip { track_id, clip_id } => self
                .find_content(track_id)
                .and_then(|t| t.note_clips.iter().find(|c| c.id == clip_id))
                .map(|c| c.duration_beats),
        };
        let Some(anchor_duration) = anchor_duration else {
            return ArrangementAction::default();
        };
        let delta = new_duration_beats - anchor_duration;
        let targets: Vec<_> = if self.selected_clips.contains(&anchor) {
            self.selected_clips.iter().copied().collect()
        } else {
            vec![anchor]
        };
        let mut max_end = None::<f64>;
        for target in targets {
            match target {
                ArrangementSelection::AudioClip { track_id, clip_id } => {
                    let old = self
                        .find_content(track_id)
                        .and_then(|t| t.clips.iter().find(|c| c.id == clip_id))
                        .map(|c| c.duration as f64 / ctx.samples_per_beat);
                    if let Some(old) = old {
                        let duration =
                            ((old + delta).max(0.25) * ctx.samples_per_beat).round() as u64;
                        let action = self.op_resize_audio_clip(
                            engine,
                            ctx,
                            track_id,
                            clip_id,
                            duration.max(1),
                        );
                        max_end = match (max_end, action.scroll_to_beat) {
                            (Some(a), Some(b)) => Some(a.max(b)),
                            (None, value) | (value, None) => value,
                        };
                    }
                }
                ArrangementSelection::NoteClip { track_id, clip_id } => {
                    let mut sync = None;
                    if let Some(clip) = self
                        .find_content_mut(track_id)
                        .and_then(|t| t.note_clips.iter_mut().find(|c| c.id == clip_id))
                    {
                        clip.duration_beats = (clip.duration_beats + delta).max(0.25);
                        clip.clamp_start_to_duration();
                        if clip.loop_enabled {
                            clip.clamp_loop_to_duration();
                        }
                        sync = Some(clip.clone());
                        max_end = Some(
                            max_end
                                .unwrap_or(0.0)
                                .max(clip.position_beats + clip.duration_beats),
                        );
                    }
                    if let Some(clip) = sync {
                        engine.send(EngineCommand::RemoveNoteClip(track_id, clip_id));
                        engine.send(EngineCommand::AddNoteClip {
                            start_marker_beats: clip.start_marker_beats,
                            track_id,
                            clip_id,
                            position_beats: clip.position_beats,
                            duration_beats: clip.duration_beats,
                            loop_enabled: clip.loop_enabled,
                            loop_start_beats: clip.loop_start_beats,
                            loop_end_beats: clip.loop_end_beats,
                            groove_grid: clip.groove_grid,
                        });
                        for note in clip.notes {
                            engine.send(EngineCommand::AddNote {
                                track_id,
                                clip_id,
                                note,
                            });
                        }
                    }
                }
            }
        }
        self.drag_resize_active = true;
        ArrangementAction {
            scroll_to_beat: max_end,
            ..Default::default()
        }
    }
}
