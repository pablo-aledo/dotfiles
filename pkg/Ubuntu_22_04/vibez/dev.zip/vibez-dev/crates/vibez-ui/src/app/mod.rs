use std::path::{Path, PathBuf};
use std::sync::Arc;

use iced::{Subscription, Task, Theme};

use crate::domains::browser::BrowserMsg;
use crate::domains::perform::PerformMsg;
use crate::domains::view::ViewMsg;
use rtrb::Consumer;
use vibez_audio_io::audio_host::{AudioBackend, AudioHost};
use vibez_audio_io::audio_stream::AudioOutputStream;
use vibez_core::constants::UI_TICK_MS;
use vibez_core::track::MediaSourceRef;
use vibez_dropbox::{
    load_app_key_with_env_override, DropboxCache, DropboxClient, DropboxEntry, DropboxSettings,
};
use vibez_engine::commands::EngineCommand;
use vibez_engine::engine::AudioEngine;
use vibez_engine::events::EngineEvent;
use vibez_plugin_host::gui::PluginGuiKey;

use crate::services::plugin_loader::{PluginInstrumentLoadResult, PluginLoadResult};

use crate::domains::audio_settings::AudioSettingsState;
use crate::icons;
use crate::message::{Message, ProjectLoadResult};
use crate::plugin_window::{PluginRawPtr, PluginWindowManager};
use crate::state::{AppState, AudioStreamHealth};
use crate::theme as th;
use crate::ui_settings::UiSettings;

pub(super) const RAW_AUDITION_PLAYING: &str = "RAW Audition playing";
pub(super) const WARP_AUDITION_PLAYING: &str = "WARP Audition playing";
pub(super) const WARP_AUDITION_PREPARING: &str = "Preparing WARP Audition";

struct App {
    state: AppState,
    edge_shortcuts: EdgeShortcutState,
    cmd_tx: crate::domains::EngineCommandQueue,
    event_rx: Option<Consumer<EngineEvent>>,
    /// Post-effects mono samples from the engine's spectrum tap,
    /// feeding the EQ analyser.
    spectrum_rx: Option<Consumer<f32>>,
    /// Track the engine tap currently points at, so tick can retarget
    /// it when the selection moves.
    spectrum_tap: Option<vibez_core::id::TrackId>,
    _stream: Option<AudioOutputStream>,
    input_bridge: Arc<vibez_audio_io::audio_input::AudioInputBridge>,
    /// Open only while one Audio Track is armed or explicitly monitors input.
    _input_stream: Option<vibez_audio_io::audio_input::AudioInputStream>,
    // Channels for receiving loaded plugins from background threads
    plugin_effect_rx: std::sync::mpsc::Receiver<PluginLoadResult>,
    plugin_effect_tx: std::sync::mpsc::Sender<PluginLoadResult>,
    plugin_instrument_rx: std::sync::mpsc::Receiver<PluginInstrumentLoadResult>,
    plugin_instrument_tx: std::sync::mpsc::Sender<PluginInstrumentLoadResult>,
    // Plugin GUI support
    plugin_window_manager: Option<PluginWindowManager>,
    plugin_gui_raw_ptrs: std::collections::HashMap<PluginGuiKey, PluginRawPtr>,
    /// Raw pointers for live state capture at save time, keyed like
    /// the GUI pointers. Entries live exactly as long as the device.
    plugin_state_ptrs: std::collections::HashMap<PluginGuiKey, vibez_plugin_host::PluginStatePtr>,
    /// Plugin preflight and render progress for the one active project export.
    export_job: Option<project_io::ExportJob>,
    export_render_progress: Option<Arc<std::sync::atomic::AtomicU8>>,
    export_plugin_return_rx:
        Option<std::sync::mpsc::Receiver<vibez_engine::render::OfflinePlugins>>,

    // Dropbox
    dropbox_settings: DropboxSettings,
    dropbox_cache: DropboxCache,
    dropbox_client: Option<Arc<DropboxClient>>,
    remote_materialization_request: tracked_request::TrackedRequest,
    remote_import_request: tracked_request::TrackedRequest,
    remote_audition_cache_lease: Option<vibez_dropbox::CacheLease>,
    pending_remote_audition: Option<DropboxEntry>,
    /// Generation for the whole Browser import pipeline (local and
    /// remote). Bumped on cancellation and project reset so an
    /// in-flight WARP preparation cannot land a clip afterwards.
    browser_import_request: tracked_request::TrackedRequest,
    /// Bumped on every refresh start and on disconnect, so catalog pages
    /// fetched for a previous connection are dropped instead of reconciled.
    remote_catalog_request: tracked_request::TrackedRequest,
    /// Cancellable preparation for the next resident Section launch.
    section_residency_request: tracked_request::TrackedRequest,
    /// Catalog changes accumulated since the last reconcile flush; applied in
    /// batches so each page does not re-sort the whole catalog in update().
    remote_catalog_pending: Vec<crate::remote_provider::RemoteChange>,

    // External MIDI input (USB keyboard, Ableton Push, virtual cable...).
    // Dropping the handle closes the port.
    midi_input: Option<vibez_audio_io::midi_input::MidiInputHandle>,
    /// Cached list of port names last seen by `list_midi_input_ports`.
    /// Populated when the user opens the MIDI picker; used so the UI
    /// can show a dropdown without re-scanning on every frame.
    midi_input_ports: Vec<String>,

    /// Multiplier iced applies to the whole logical coordinate space.
    /// It lives on the shell rather than in `AppState` because it
    /// describes the window the project is viewed through, not the
    /// project or the view layout, and nothing about it is undoable.
    interface_scale: f32,
    /// Debounce, revision, and in-flight coordination for project saves.
    save_runtime: save_runtime::SaveRuntime,
    // Undo / redo
}

pub fn run() -> iced::Result {
    // Raw 64x64 RGBA (assets/icon/vibez-64.rgba, generated from
    // assets/icon/vibez.svg) so the window icon needs no image
    // decoder in the dependency tree.
    let icon = iced::window::icon::from_rgba(
        include_bytes!("../../../../assets/icon/vibez-64.rgba").to_vec(),
        64,
        64,
    )
    .ok();
    iced::application(App::title, App::update, App::view)
        .theme(App::theme)
        .scale_factor(App::scale_factor)
        .antialiasing(true)
        .subscription(App::subscription)
        // Unsaved edits get a confirmation instead of a silent exit, so the
        // close request has to reach `update` rather than the window itself.
        .exit_on_close_request(false)
        .window({
            #[allow(unused_mut)]
            let mut settings = iced::window::Settings {
                icon,
                min_size: Some(iced::Size::new(900.0, 600.0)),
                ..Default::default()
            };
            // WM_CLASS / app_id: lets docks and taskbars match the
            // window to a vibez.desktop entry instead of guessing.
            // The field only exists in the Linux settings variant.
            #[cfg(target_os = "linux")]
            {
                settings.platform_specific.application_id = "vibez".to_string();
            }
            settings
        })
        .window_size((1400.0, 900.0))
        .font(icons::ICON_FONT_BYTES)
        .font(crate::typography::PLEX_SANS_CONDENSED_MEDIUM_BYTES)
        .font(crate::typography::PLEX_SANS_CONDENSED_SEMIBOLD_BYTES)
        .font(crate::typography::PLEX_MONO_MEDIUM_BYTES)
        .font(crate::typography::PLEX_MONO_SEMIBOLD_BYTES)
        .run_with(App::new)
}

mod actions;
mod audio_recording;
mod audio_settings;
mod audio_take_finalization;
mod audio_tasks;
mod bounce;
mod capture;
mod drum_rack_preparation;
mod engine_events;
mod keyboard;
mod local_watcher;
mod menu_lifecycle;
mod tasks;
mod tracked_request;

pub(crate) use audio_tasks::*;
use drum_rack_preparation::*;
pub(crate) use keyboard::*;
use tasks::*;
mod dropbox_io;
mod media;
mod media_import;
mod plugins;
mod project_io;
mod project_replay;
mod project_sections;
mod save_runtime;
mod section_record;
mod timeline_results;
mod transient_markers;
mod update;
mod update_media;
mod update_policy;
mod update_project;
mod update_remote;
mod update_timeline;
mod update_view;
mod views_about;
mod views_arrangement;
mod views_audio_clip;
mod views_automation;
mod views_browser;
mod views_browser_audition;
mod views_browser_places;
mod views_browser_remote;
mod views_browser_style;
mod views_clip_swing;
mod views_close_confirm;
mod views_detail;
mod views_devices;
mod views_file_menu;
mod views_mixer;
mod views_overlays;
mod views_perform;
mod views_perform_instrument;
mod views_perform_pads;
mod views_perform_playhead;
mod views_perform_record;
mod views_perform_sections;
mod views_settings;
mod views_settings_appearance;
mod views_settings_audio;
mod views_settings_dropbox;
mod views_settings_perform;
mod views_settings_project;
mod views_settings_updates;
mod views_shell;
mod views_transient_analysis;
mod views_transport;
mod window_policy;

#[cfg(test)]
mod project_format_v1_tests;

impl App {
    fn new() -> (Self, Task<Message>) {
        let (mut engine, cmd_tx, event_rx) = AudioEngine::new();
        let spectrum_rx = engine.take_spectrum_consumer();
        let ui_settings = UiSettings::load();
        // Read before the settings are picked apart below, and clamped
        // here rather than at the render site so a hand-edited ui.json
        // cannot open the window at an unusable size.
        let interface_scale = ui_settings.clamped_interface_scale();
        let recent_project_paths =
            crate::ui_settings::normalize_recent_projects(ui_settings.recent_project_paths.clone());

        let preferred_audio_backend = if ui_settings.audio_backend.is_available() {
            ui_settings.audio_backend
        } else {
            AudioBackend::System
        };
        let audio_backend_preferences = ui_settings.resolved_audio_device_preferences();
        let preferred_audio_output = audio_backend_preferences
            .for_backend(preferred_audio_backend)
            .output_name
            .clone();
        let requested_sample_rate = ui_settings.audio_sample_rate;
        let requested_buffer_size = ui_settings.audio_buffer_size;
        let audio_settings::InitialAudioOutput {
            stream: output_stream,
            sample_rate,
            active_output_name,
            active_backend,
            health: audio_stream_health,
            status: initial_audio_status,
        } = audio_settings::initialize_audio_output(
            engine,
            preferred_audio_backend,
            preferred_audio_output.clone(),
            requested_sample_rate,
            requested_buffer_size,
        );
        // If a saved backend cannot open any output, startup deliberately
        // falls back to the native host. Keep Settings and on-demand input on
        // that same active host instead of presenting one backend while the
        // engine silently runs another.
        let settings_audio_backend = active_backend.unwrap_or(preferred_audio_backend);
        let active_preferences = audio_backend_preferences.for_backend(settings_audio_backend);
        let preferred_audio_input = active_preferences.input_name.clone();
        let preferred_audio_output = active_preferences.output_name.clone();
        let (audio_catalog, catalog_error) =
            match AudioHost::new(settings_audio_backend).and_then(|host| host.catalog()) {
                Ok(catalog) => (catalog, None),
                Err(error) => {
                    eprintln!("vibez: failed to scan audio devices: {error}");
                    (Default::default(), Some(error.to_string()))
                }
            };
        let input_bridge = output_stream.input_bridge();

        let dropbox_settings = DropboxSettings::load();
        let dropbox_cache = DropboxCache::with_policy(vibez_dropbox::MediaCachePolicy {
            budget_bytes: ui_settings.media_cache_budget_bytes,
            automatic_eviction: ui_settings.media_cache_automatic_eviction,
        });
        let resolved_key = load_app_key_with_env_override(&dropbox_settings);
        let dropbox_client = match (&resolved_key, &dropbox_settings.tokens) {
            (Some(key), Some(tokens)) => {
                Some(Arc::new(DropboxClient::new(key.clone(), tokens.clone())))
            }
            _ => None,
        };
        let remote_ui_state = crate::state::RemoteUiState {
            connected: dropbox_client.is_some(),
            account_email: dropbox_settings.account_email.clone(),
            app_key_input: dropbox_settings.app_key.clone().unwrap_or_default(),
            has_app_key: resolved_key.is_some(),
            catalog_state: crate::state::RemoteCatalogState::Loading,
            cache_budget_bytes: ui_settings.media_cache_budget_bytes,
            cache_automatic_eviction: ui_settings.media_cache_automatic_eviction,
            ..Default::default()
        };

        let mut state = AppState {
            transport: crate::state::TransportState {
                sample_rate,
                ..Default::default()
            },
            audio_stream_health,
            audio_settings: AudioSettingsState {
                backend: settings_audio_backend,
                active_backend,
                catalog: audio_catalog,
                backend_preferences: audio_backend_preferences,
                preferred_input_name: preferred_audio_input,
                preferred_output_name: preferred_audio_output,
                active_output_name,
                sample_rate,
                buffer_size: requested_buffer_size,
                catalog_error,
            },
            auto_warp_on_import: ui_settings.auto_warp_on_import,
            warp_confidence_threshold: ui_settings.warp_confidence_threshold,
            confirm_project_track_deletion: ui_settings.confirm_project_track_deletion,
            auto_save_enabled: ui_settings.auto_save_enabled,
            update_check: crate::update_check::UpdateCheckState {
                enabled: ui_settings.check_for_updates,
                last_check_unix: ui_settings.last_update_check_unix,
                ..Default::default()
            },
            project: crate::state::ProjectState {
                recent_project_paths,
                ..Default::default()
            },
            view: crate::state::ViewState {
                perform_surface_width: ui_settings.perform_surface_width,
                detail_panel_height: ui_settings.detail_panel_height,
                ..Default::default()
            },
            browser: crate::state::BrowserState {
                open: ui_settings.sample_browser_open,
                dock_width: ui_settings.sample_browser_width.clamp(
                    crate::state::BROWSER_DOCK_MIN_WIDTH,
                    crate::state::BROWSER_DOCK_MAX_WIDTH,
                ),
                audition_enabled: ui_settings.audition_enabled,
                audition_gain: ui_settings.audition_gain.clamp(0.0, 2.0),
                roots: ui_settings.sample_library_roots,
                remote: remote_ui_state,
                ..Default::default()
            },
            ..Default::default()
        };
        if let Some(status) = initial_audio_status {
            state.status_text = status;
        }
        state.perform.input_mapping = ui_settings.perform_input_mapping.clone();
        state
            .perform
            .set_fixed_computer_velocity(ui_settings.fixed_computer_velocity);
        state
            .perform
            .set_track_mute_quantization(ui_settings.track_mute_quantization);

        // Themes: scan the user's .vzt collection, then restore the
        // saved selection (built-in name or user theme name).
        let (user_themes, theme_warnings) = crate::themes::scan_user_themes();
        for warning in theme_warnings {
            eprintln!("vibez: theme scan: {warning}");
        }
        state.user_themes = user_themes;
        if let Some(name) = &ui_settings.theme {
            let palette = crate::themes::builtin_by_name(name).or_else(|| {
                state
                    .user_themes
                    .iter()
                    .find(|t| t.palette.name == *name)
                    .map(|t| t.palette.clone())
            });
            if let Some(palette) = palette {
                th::set_theme(palette);
                state.current_theme_name = name.clone();
            }
        }

        let (plugin_effect_tx, plugin_effect_rx) = std::sync::mpsc::channel();
        let (plugin_instrument_tx, plugin_instrument_rx) = std::sync::mpsc::channel();

        // Register the UI thread (process main thread) as the CLAP "main thread".
        // JUCE-based CLAP plugins require GUI calls on this thread.
        vibez_plugin_host::set_clap_main_thread();

        let plugin_window_manager = PluginWindowManager::new();

        // Auto-connect to the preferred MIDI input if the saved name
        // matches one currently visible, else to the first available
        // port. Silent on failure: the user can still work without
        // MIDI, and Settings → Audio lets them pick manually later.
        let midi_input = auto_open_midi_input(ui_settings.preferred_midi_input.as_deref());

        let mut app = Self {
            state,
            edge_shortcuts: EdgeShortcutState::default(),
            cmd_tx: crate::domains::EngineCommandQueue::new(cmd_tx),
            event_rx: Some(event_rx),
            spectrum_rx,
            spectrum_tap: None,
            _stream: Some(output_stream),
            input_bridge,
            _input_stream: None,
            plugin_effect_rx,
            plugin_effect_tx,
            plugin_instrument_rx,
            plugin_instrument_tx,
            plugin_window_manager,
            plugin_gui_raw_ptrs: std::collections::HashMap::new(),
            plugin_state_ptrs: std::collections::HashMap::new(),
            export_job: None,
            export_render_progress: None,
            export_plugin_return_rx: None,
            dropbox_settings,
            dropbox_cache,
            dropbox_client,
            remote_materialization_request: Default::default(),
            remote_import_request: Default::default(),
            remote_audition_cache_lease: None,
            pending_remote_audition: None,
            browser_import_request: Default::default(),
            remote_catalog_request: Default::default(),
            section_residency_request: Default::default(),
            remote_catalog_pending: Vec::new(),
            midi_input,
            midi_input_ports: Vec::new(),
            interface_scale,
            save_runtime: save_runtime::SaveRuntime::default(),
        };

        // Inform the engine of the actual hardware clock and project tempo.
        app.send_command(EngineCommand::SetSampleRate(
            app.state.transport.sample_rate,
        ));
        app.send_command(EngineCommand::SetBpm(app.state.transport.bpm));
        app.send_command(EngineCommand::SetAuditionGain(
            app.state.browser.audition_gain,
        ));

        // Console model: the master bus carries its channel EQ from
        // the first frame.
        app.ensure_master_eq();

        let roots = app.state.browser.roots.clone();
        let local_startup_task = Task::batch(roots.into_iter().map(|root| {
            let revision = app.state.browser.begin_root_scan(&root, false);
            Task::perform(scan_sample_root_async(root.clone()), move |result| {
                Message::Browser(BrowserMsg::LocalRootCatalogReconciled {
                    root: root.clone(),
                    revision,
                    result,
                })
            })
        }));
        let remote_startup_task =
            dropbox_io::remote_catalog_startup_task(app.dropbox_cache.clone());
        let plugin_catalog_startup_task = if app.state.plugin_settings.cache_needs_refresh() {
            Task::done(Message::ScanPlugins)
        } else {
            Task::none()
        };

        // Staged Project Media copies are content-addressed and shared, so
        // saves and aborted imports never delete them eagerly; this sweep
        // is the cache policy that reclaims entries old enough that no
        // live session can still reference them.
        std::thread::spawn(|| {
            vibez_project::project_format_v1::sweep_stale_staging(std::time::Duration::from_secs(
                7 * 24 * 60 * 60,
            ));
        });

        // `vibez <project.vzp>` opens a project straight from the
        // command line (also how file-manager associations launch
        // us). Legacy `.vibez` files load the same way.
        // Release check. Off the UI thread via Task::perform, at most
        // once a day, and skipped entirely when the user opted out so
        // that "off" means no traffic rather than a discarded result.
        let update_check_task = if crate::update_check::should_check(
            app.state.update_check.enabled,
            app.state.update_check.last_check_unix,
            crate::update_check::now_unix(),
        ) && app.state.update_check.begin_check()
        {
            Task::perform(
                crate::update_check::fetch_latest_tag(),
                Message::UpdateCheckCompleted,
            )
        } else {
            Task::none()
        };

        let open_task = std::env::args()
            .nth(1)
            .map(std::path::PathBuf::from)
            .filter(|p| p.is_file())
            .map(|p| Task::done(Message::ProjectOpenPathSelected(Some(p))))
            .unwrap_or_else(Task::none);
        // `window::Settings` has no maximized field in iced 0.13. The
        // initial task runs after the first window exists, so ask the window
        // manager to maximize that concrete window instead of merely opening
        // at a large hard-coded size.
        let maximize_window_task =
            iced::window::get_latest().and_then(|id| iced::window::maximize(id, true));

        (
            app,
            Task::batch([
                local_startup_task,
                remote_startup_task,
                plugin_catalog_startup_task,
                update_check_task,
                open_task,
                maximize_window_task,
            ]),
        )
    }

    /// Find a theme by name: built-ins first, then the scanned user
    /// collection.
    pub(crate) fn resolve_theme(&self, name: &str) -> Option<crate::theme::ThemePalette> {
        crate::themes::builtin_by_name(name).or_else(|| {
            self.state
                .user_themes
                .iter()
                .find(|t| t.palette.name == name)
                .map(|t| t.palette.clone())
        })
    }

    fn send_command(&mut self, cmd: EngineCommand) {
        crate::domains::EngineHandle::send(&mut self.cmd_tx, cmd);
    }

    fn mark_project_dirty(&mut self) {
        self.state.project.dirty = true;
        self.save_runtime.project_changed(
            self.state.auto_save_enabled,
            self.state.project.current_path.is_some(),
            std::time::Instant::now(),
        );
    }

    pub(super) fn active_editor_pixels_per_beat(&self) -> f32 {
        let editor = self.state.active_timeline_editor();
        if let Some((track_id, clip_id)) = editor.selected_note_clip {
            if let Some(duration) =
                self.state
                    .active_timeline_content(track_id)
                    .and_then(|content| {
                        content
                            .note_clips
                            .iter()
                            .find(|clip| clip.id == clip_id)
                            .map(|clip| clip.duration_beats)
                    })
            {
                return crate::timeline_geometry::TimelineGeometry::fitted(
                    duration,
                    self.state.view.window_width,
                    52.0,
                )
                .pixels_per_beat();
            }
        }
        if self.state.view.workspace == crate::state::Workspace::Perform
            && self.state.perform.selected_section.is_some()
        {
            return self
                .state
                .perform
                .section_editor
                .viewport()
                .geometry()
                .pixels_per_beat();
        }
        crate::timeline_geometry::TimelineGeometry::from_zoom(
            self.state.view.zoom_level,
            self.state.view.scroll_offset_beats,
        )
        .pixels_per_beat()
    }

    /// Auto-scroll the arrangement when a clip's right edge nears the visible boundary.
    /// Called from resize/move handlers so the view follows the drag.
    fn auto_scroll_to_beat(&mut self, clip_end_beat: f64) {
        // Conservative estimate of canvas width (window minus track headers)
        let canvas_width = 1400.0_f32;
        let geometry = crate::timeline_geometry::TimelineGeometry::from_zoom(
            self.state.view.zoom_level,
            self.state.view.scroll_offset_beats,
        );
        let visible_beats = geometry.visible_beats(canvas_width);
        let visible_end = self.state.view.scroll_offset_beats + visible_beats;
        let margin = 2.0_f64;

        if clip_end_beat > visible_end - margin {
            let delta = clip_end_beat - visible_end + margin * 2.0;
            let total = self.state.total_beats();
            self.state.view.scroll_offset_beats =
                (self.state.view.scroll_offset_beats + delta).clamp(0.0, total);
        }
        // Also scroll left when dragging toward the left edge
        if clip_end_beat < self.state.view.scroll_offset_beats + margin
            && self.state.view.scroll_offset_beats > 0.0
        {
            let delta = self.state.view.scroll_offset_beats + margin - clip_end_beat;
            self.state.view.scroll_offset_beats =
                (self.state.view.scroll_offset_beats - delta).max(0.0);
        }
    }

    /// Re-evaluated by iced after every update, so the title tracks the open
    /// project and its dirty flag without anything having to push it.
    fn title(&self) -> String {
        window_policy::window_title(
            self.state.project.current_path.as_deref(),
            self.state.project.dirty,
        )
    }

    fn theme(&self) -> Theme {
        th::vibez_theme()
    }

    /// Scale of the logical coordinate space the whole interface is
    /// laid out in. iced re-lays-out on change, and widgets keep
    /// working in logical units, so canvases (timeline, piano roll,
    /// meters) receive already-descaled cursor positions and need no
    /// per-widget adjustment.
    fn scale_factor(&self) -> f64 {
        self.interface_scale as f64
    }

    fn subscription(&self) -> Subscription<Message> {
        Subscription::batch([
            iced::time::every(std::time::Duration::from_millis(UI_TICK_MS)).map(|_| Message::Tick),
            local_watcher::subscription(self.state.browser.roots.clone()),
            iced::event::listen_with(|event, _status, _id| match event {
                iced::Event::Keyboard(event) => keyboard_input_message(event, _status),
                iced::Event::Mouse(iced::mouse::Event::CursorMoved { position }) => {
                    Some(Message::View(ViewMsg::CursorMoved(position.x, position.y)))
                }
                iced::Event::Mouse(iced::mouse::Event::ButtonReleased(
                    iced::mouse::Button::Left,
                )) => Some(Message::View(ViewMsg::MouseReleased)),
                iced::Event::Window(iced::window::Event::Resized(size)) => Some(Message::View(
                    ViewMsg::WindowResized(size.width, size.height),
                )),
                iced::Event::Window(iced::window::Event::Unfocused) => {
                    Some(Message::Perform(PerformMsg::WindowUnfocused))
                }
                iced::Event::Window(iced::window::Event::CloseRequested) => {
                    Some(Message::WindowCloseRequested)
                }
                _ => None,
            }),
        ])
    }
}
