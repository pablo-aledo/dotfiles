//! Split out of app.rs; inherent methods on [`super::App`].

use iced::widget::{
    button, canvas, column, container, horizontal_space, mouse_area, row, scrollable, text,
};
use iced::{Color, Element, Length, Theme};

use vibez_core::id::TrackId;
use vibez_core::track::MediaSourceRef;
use vibez_plugin_host::gui::PluginGuiKey;

use crate::domains::browser::BrowserMsg;
use crate::icons;
use crate::message::{DrumPadParam, Message};
use crate::state::UiTrack;
use crate::theme as th;
use crate::widgets::effect_slot::view_effect_slot;

use super::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DrumPadVisualState {
    Idle,
    Selected,
    Firing,
}

fn drum_pad_visual_state(selected: bool, firing: bool) -> DrumPadVisualState {
    if firing {
        DrumPadVisualState::Firing
    } else if selected {
        DrumPadVisualState::Selected
    } else {
        DrumPadVisualState::Idle
    }
}

impl App {
    /// Build the device chain for the detail panel.
    pub(super) fn view_device_chain<'a>(
        &'a self,
        track_id: TrackId,
        track: &'a UiTrack,
        track_color: Color,
    ) -> Element<'a, Message> {
        // Header: track name + right-click hint
        let track_label = text(format!("{} — Devices", track.name))
            .size(13)
            .color(th::text());

        let hint_label = text("Right-click to add").size(10).color(th::text_muted());

        let header = row![track_label, horizontal_space(), hint_label]
            .spacing(8)
            .align_y(iced::Alignment::Center);

        // Device cards
        let mut devices_row = row![].spacing(6);

        // Instrument device card (branched by kind)
        if track.has_instrument {
            if track.plugin_instrument_name.is_some() {
                // External plugin instrument — clickable card
                let card = self.view_plugin_instrument_device(track_id, track, track_color);
                devices_row = devices_row.push(card);
            } else {
                match track.instrument_kind {
                    Some(vibez_core::midi::InstrumentKind::Sampler) => {
                        let card = self.view_sampler_device(track_id, track, track_color);
                        devices_row = devices_row.push(card);
                    }
                    Some(vibez_core::midi::InstrumentKind::DrumRack) => {
                        let card = self.view_drum_rack_device(track_id, track, track_color);
                        devices_row = devices_row.push(card);
                    }
                    _ => {
                        let synth_card = self.view_synth_device(track_id, track, track_color);
                        devices_row = devices_row.push(synth_card);
                    }
                }
            }
        } else if track.kind.is_midi() {
            let placeholder = self.view_add_instrument_placeholder();
            devices_row = devices_row.push(placeholder);
        }

        // Effect cards
        for effect in &track.effects {
            let custom = if effect.effect_type == vibez_core::effect::EffectType::Eq
                && effect.plugin_ref.is_none()
            {
                Some(self.eq_device_body(track_id, effect))
            } else {
                None
            };
            let slot = view_effect_slot(track_id, effect, track_color, custom);
            devices_row = devices_row.push(slot);
        }

        // Horizontal only: the panel is now a fixed-height strip the
        // cards fit exactly, Ableton-style.
        let scrollable_devices =
            scrollable(devices_row).direction(scrollable::Direction::Horizontal(
                scrollable::Scrollbar::new()
                    .width(5)
                    .scroller_width(5)
                    .spacing(2),
            ));

        let content = column![header, scrollable_devices]
            .spacing(6)
            .padding(8)
            .width(Length::Fill);

        // Wrap in mouse_area for right-click context menu
        mouse_area(content)
            .on_right_press(Message::Devices(
                crate::domains::devices::DevicesMsg::ShowContextMenu {
                    x: self.state.view.cursor_x,
                    y: self.state.view.cursor_y,
                    track_id,
                },
            ))
            .into()
    }

    /// Channel EQ card body: response display over the live analyser
    /// on the left, four color-coded band columns on the right. The
    /// analyser follows the selected track, which is exactly the
    /// track whose device chain is on screen.
    fn eq_device_body<'a>(
        &'a self,
        track_id: TrackId,
        effect: &'a crate::state::UiEffect,
    ) -> (Element<'a, Message>, f32) {
        use crate::widgets::effect_knob::{format_value, EffectKnobWidget};
        use crate::widgets::eq_display::EqDisplayWidget;

        const DISPLAY_W: f32 = 380.0;
        const BAND_COL_W: f32 = 50.0;

        let display = EqDisplayWidget {
            track_id,
            effect_id: effect.id,
            params: effect.params.clone(),
            descriptors: effect.descriptors,
            bypass: effect.bypass,
            sample_rate: self.state.transport.sample_rate as f32,
            spectrum: self.state.spectrum.bins.clone(),
            spectrum_active: self.state.spectrum.active,
        };
        let display_canvas: Element<'a, Message> = canvas(display)
            .width(Length::Fixed(DISPLAY_W))
            .height(Length::Fill)
            .into();

        // Band columns, left to right along the frequency axis:
        // (label, gain idx, freq idx, third idx, bell?, color)
        let bands: [(&str, usize, usize, usize, bool, Color); 4] = [
            ("LF", 0, 1, 2, true, th::eq_lf()),
            ("LMF", 3, 4, 5, false, th::eq_lmf()),
            ("HMF", 6, 7, 8, false, th::eq_hmf()),
            ("HF", 9, 10, 11, true, th::eq_hf()),
        ];

        let knob_color = if effect.bypass {
            th::text_muted()
        } else {
            th::text_dim()
        };
        let mut band_row = row![].spacing(4);
        for (label, gain_i, freq_i, third_i, is_bell, color) in bands {
            let band_color = if effect.bypass { knob_color } else { color };
            let knob = |i: usize, size: f32| -> Element<'a, Message> {
                let d = &effect.descriptors[i];
                let w = EffectKnobWidget::new(
                    track_id,
                    effect.id,
                    i,
                    effect.params.get(i).copied().unwrap_or(d.default),
                    d.min,
                    d.max,
                    d.default,
                    band_color,
                );
                canvas(w)
                    .width(Length::Fixed(size))
                    .height(Length::Fixed(size))
                    .into()
            };
            let gain_v = effect.params.get(gain_i).copied().unwrap_or(0.0);
            let freq_v = effect.params.get(freq_i).copied().unwrap_or(0.0);

            let mut col = column![
                text(label).size(9).color(band_color),
                knob(gain_i, 28.0),
                text(format!("{gain_v:+.1}")).size(8).color(th::text_dim()),
                knob(freq_i, 24.0),
                text(format_value(freq_v, "Hz"))
                    .size(8)
                    .color(th::text_dim()),
            ]
            .spacing(2)
            .width(Length::Fixed(BAND_COL_W))
            .align_x(iced::Alignment::Center);

            if is_bell {
                let bell_on = effect.params.get(third_i).copied().unwrap_or(0.0) >= 0.5;
                let bell = button(text("BELL").size(6).color(if bell_on {
                    th::bg_dark()
                } else {
                    th::text_dim()
                }))
                .on_press(Message::set_effect_param(
                    track_id,
                    effect.id,
                    third_i,
                    if bell_on { 0.0 } else { 1.0 },
                ))
                .padding([3, 6])
                .style(move |_theme: &Theme, _status| button::Style {
                    background: Some(if bell_on {
                        band_color.into()
                    } else {
                        th::bg_elevated().into()
                    }),
                    text_color: if bell_on {
                        th::bg_dark()
                    } else {
                        th::text_dim()
                    },
                    border: iced::Border {
                        color: th::border(),
                        width: 1.0,
                        radius: 2.0.into(),
                    },
                    ..Default::default()
                });
                col = col.push(bell);
            } else {
                let q_v = effect.params.get(third_i).copied().unwrap_or(0.7);
                col = col.push(
                    row![
                        text("Q").size(8).color(th::text_dim()),
                        knob(third_i, 20.0),
                        text(format!("{q_v:.2}")).size(8).color(th::text_dim()),
                    ]
                    .spacing(2)
                    .align_y(iced::Alignment::Center),
                );
            }
            band_row = band_row.push(col);
        }

        let body: Element<'a, Message> = row![
            display_canvas,
            Self::device_divider(),
            container(band_row).padding([0, 2]),
        ]
        .spacing(8)
        .align_y(iced::Alignment::Center)
        .into();

        // padding (20) + display + divider + bands + spacing
        let card_w = DISPLAY_W + 4.0 * (BAND_COL_W + 4.0) + 48.0;
        (body, card_w)
    }

    // ── Shared device card helpers ──────────────────────────────────

    /// Dark title bar used by all device cards.
    pub(super) fn device_title_bar<'a>(
        content: impl Into<Element<'a, Message>>,
    ) -> iced::widget::Container<'a, Message> {
        container(content)
            .padding([4, 6])
            .width(Length::Fill)
            .style(|_theme: &Theme| container::Style {
                background: Some(th::bg_surface().into()),
                ..Default::default()
            })
    }

    /// Standard device title row: colored dot, name, optional remove.
    pub(super) fn device_title_row(
        name: &str,
        track_color: Color,
        remove: Option<Message>,
    ) -> iced::widget::Row<'_, Message> {
        let dot = text("\u{25CF}").size(8).color(track_color);
        let name = text(name.to_string()).size(11).color(th::text());
        let mut r = row![dot, name].spacing(5).align_y(iced::Alignment::Center);
        if let Some(msg) = remove {
            let remove_btn: Element<'_, Message> =
                Self::device_icon_btn(icons::X, th::text_dim(), th::danger(), msg).into();
            r = r.push(horizontal_space().width(Length::Fixed(12.0)));
            r = r.push(remove_btn);
        }
        r
    }

    /// Labeled section inside a device body, Ableton-style: a tiny
    /// uppercase header above the section's controls.
    pub(super) fn device_section<'a>(
        label: &'static str,
        content: Element<'a, Message>,
    ) -> Element<'a, Message> {
        column![text(label).size(8).color(th::text_muted()), content]
            .spacing(6)
            .align_x(iced::Alignment::Start)
            .into()
    }

    /// Thin vertical rule separating device sections.
    pub(super) fn device_divider() -> Element<'static, Message> {
        container(text(""))
            .width(Length::Fixed(1.0))
            .height(Length::Fixed(th::DEVICE_BODY_H - 12.0))
            .style(|_theme: &Theme| container::Style {
                background: Some(th::divider().into()),
                ..Default::default()
            })
            .into()
    }

    /// Standard device body: fixed rack height so every card in the
    /// chain lines up like a hardware rack, consistent padding.
    pub(super) fn device_body(content: Element<'_, Message>) -> Element<'_, Message> {
        container(content)
            .padding([8, 10])
            .height(Length::Fixed(th::DEVICE_BODY_H))
            .into()
    }

    /// Wrap card content in the standard device card container.
    pub(super) fn device_card(content: iced::widget::Column<'_, Message>) -> Element<'_, Message> {
        container(content)
            .style(|_theme: &Theme| container::Style {
                background: Some(th::bg_elevated().into()),
                border: iced::Border {
                    color: th::border(),
                    width: 1.0,
                    radius: 4.0.into(),
                },
                ..Default::default()
            })
            .into()
    }

    /// Small icon-only button for device card actions.
    pub(super) fn device_icon_btn(
        icon_char: char,
        color: Color,
        hover_color: Color,
        msg: Message,
    ) -> iced::widget::Button<'static, Message> {
        button(icons::icon(icon_char).size(12).color(color))
            .on_press(msg)
            .padding([3, 5])
            .style(move |_theme: &Theme, status| {
                let (bg, tc) = match status {
                    button::Status::Hovered => (Some(th::bg_hover().into()), hover_color),
                    button::Status::Pressed => (Some(th::bg_dark().into()), hover_color),
                    _ => (None, color),
                };
                button::Style {
                    background: bg,
                    text_color: tc,
                    border: iced::Border {
                        radius: 3.0.into(),
                        ..Default::default()
                    },
                    ..Default::default()
                }
            })
    }

    /// Device card for an external plugin instrument.
    pub(super) fn view_plugin_instrument_device<'a>(
        &'a self,
        track_id: TrackId,
        track: &'a UiTrack,
        track_color: Color,
    ) -> Element<'a, Message> {
        let dot = text("\u{25CF}").size(9).color(track_color);
        let plugin_name = track.plugin_instrument_name.as_deref().unwrap_or("Plugin");

        let name_section =
            container(text(plugin_name).size(11).color(th::text())).width(Length::Fill);

        // Edit button for plugins with a native GUI
        let edit_btn: Option<iced::widget::Button<'_, Message>> = if track.has_plugin_instrument_gui
        {
            let gui_key = PluginGuiKey::Instrument { track_id };
            Some(
                button(text("Edit").size(9).color(th::text_dim()))
                    .on_press(Message::OpenPluginGui(gui_key))
                    .padding([2, 5])
                    .style(|_theme: &Theme, status| {
                        let (bg, tc) = match status {
                            button::Status::Hovered => (Some(th::bg_hover().into()), th::accent()),
                            _ => (None, th::text_dim()),
                        };
                        button::Style {
                            background: bg,
                            text_color: tc,
                            border: iced::Border {
                                color: th::border(),
                                width: 1.0,
                                radius: 3.0.into(),
                            },
                            ..Default::default()
                        }
                    }),
            )
        } else {
            None
        };

        let remove: Element<'a, Message> = Self::device_icon_btn(
            icons::X,
            th::text_dim(),
            th::danger(),
            Message::remove_track_instrument(track_id),
        )
        .into();

        let mut title_row = row![dot, name_section]
            .spacing(4)
            .align_y(iced::Alignment::Center);
        if let Some(eb) = edit_btn {
            title_row = title_row.push(eb);
        }
        title_row = title_row.push(remove);

        let title = Self::device_title_bar(title_row);

        Self::device_card(column![title].width(Length::Fixed(200.0)))
    }

    /// Synth device card for instrument tracks.
    pub(super) fn view_synth_device<'a>(
        &'a self,
        track_id: TrackId,
        track: &'a UiTrack,
        track_color: Color,
    ) -> Element<'a, Message> {
        use crate::widgets::effect_knob::{format_value, param_column, EffectKnobWidget};
        let title = Self::device_title_bar(Self::device_title_row(
            "Synth",
            track_color,
            Some(Message::remove_track_instrument(track_id)),
        ));

        let descriptors = vibez_instruments::synth::SYNTH_PARAMS;
        let value_of = |i: usize| {
            track
                .instrument_params
                .get(i)
                .copied()
                .unwrap_or(descriptors[i].default)
        };
        let knob = |i: usize, label: &str| {
            param_column(
                EffectKnobWidget::for_instrument(
                    track_id,
                    i,
                    value_of(i),
                    descriptors[i].min,
                    descriptors[i].max,
                    descriptors[i].default,
                    track_color,
                ),
                label.to_string(),
                format_value(value_of(i), descriptors[i].unit),
            )
        };

        // OSC section: 2x2 waveform selector grid.
        let wave_value = value_of(0).round() as usize;
        let wave_btn = |i: usize, label: &'static str| {
            let active = wave_value == i;
            button(
                text(label)
                    .size(9)
                    .width(Length::Fixed(30.0))
                    .align_x(iced::Alignment::Center)
                    .color(if active {
                        th::bg_dark()
                    } else {
                        th::text_dim()
                    }),
            )
            .on_press(Message::set_instrument_param(track_id, 0, i as f32))
            .padding([3, 4])
            .style(move |_theme: &Theme, _status| button::Style {
                background: Some(if active { th::accent() } else { th::bg_dark() }.into()),
                text_color: if active {
                    th::bg_dark()
                } else {
                    th::text_dim()
                },
                border: iced::Border {
                    color: if active { th::accent() } else { th::border() },
                    width: 1.0,
                    radius: 3.0.into(),
                },
                ..Default::default()
            })
        };
        let scope: Element<'a, Message> = canvas(crate::widgets::mini_waveform::OscScope {
            waveform_index: wave_value,
            color: track_color,
        })
        .width(Length::Fixed(66.0))
        .height(Length::Fixed(38.0))
        .into();
        let osc = column![
            scope,
            row![wave_btn(0, "Sin"), wave_btn(1, "Saw")].spacing(3),
            row![wave_btn(2, "Sqr"), wave_btn(3, "Tri")].spacing(3),
        ]
        .spacing(3)
        .align_x(iced::Alignment::Center);

        let adsr: Element<'a, Message> = canvas(crate::widgets::mini_waveform::AdsrScope {
            attack: value_of(1),
            decay: value_of(2),
            sustain: value_of(3),
            release: value_of(4),
            color: track_color,
        })
        .width(Length::Fixed(240.0))
        .height(Length::Fixed(34.0))
        .into();
        let envelope = column![
            adsr,
            row![
                knob(1, "Attack"),
                knob(2, "Decay"),
                knob(3, "Sustain"),
                knob(4, "Release")
            ]
            .spacing(6)
        ]
        .spacing(5)
        .align_x(iced::Alignment::Center);

        let body = row![
            Self::device_section("OSC", osc.into()),
            Self::device_divider(),
            Self::device_section("ENVELOPE", envelope.into()),
            Self::device_divider(),
            Self::device_section(
                "FILTER",
                row![knob(5, "Cutoff"), knob(6, "Res")].spacing(6).into()
            ),
            Self::device_divider(),
            Self::device_section("OUT", knob(7, "Volume")),
        ]
        .spacing(10)
        .align_y(iced::Alignment::Start);

        // OSC 66 + envelope 240 + filter 118 + out 56 + chrome.
        Self::device_card(
            column![title, Self::device_body(body.into())].width(Length::Fixed(570.0)),
        )
    }

    /// Sampler device card.
    pub(super) fn view_sampler_device<'a>(
        &'a self,
        track_id: TrackId,
        track: &'a UiTrack,
        track_color: Color,
    ) -> Element<'a, Message> {
        use crate::widgets::effect_knob::{format_value, param_column, EffectKnobWidget};
        let title = Self::device_title_bar(Self::device_title_row(
            "Sampler",
            track_color,
            Some(Message::remove_track_instrument(track_id)),
        ));

        let descriptors = vibez_instruments::sampler::SAMPLER_PARAMS;
        let value_of = |i: usize| {
            track
                .instrument_params
                .get(i)
                .copied()
                .unwrap_or(descriptors[i].default)
        };
        let knob = |i: usize, label: &str| {
            param_column(
                EffectKnobWidget::for_instrument(
                    track_id,
                    i,
                    value_of(i),
                    descriptors[i].min,
                    descriptors[i].max,
                    descriptors[i].default,
                    track_color,
                ),
                label.to_string(),
                format_value(value_of(i), descriptors[i].unit),
            )
        };

        // Long file names must not blow the section open; the
        // waveform display defines the section width.
        let sample_label = match &track.sample_name {
            Some(name) => {
                let display = if name.chars().count() > 24 {
                    let head: String = name.chars().take(21).collect();
                    format!("{head}...")
                } else {
                    name.clone()
                };
                text(display).size(10).color(th::text())
            }
            None => text("No Sample").size(10).color(th::text_muted()),
        };
        let load_btn = button(text("Load").size(9).color(th::text()))
            .on_press(Message::LoadSamplerSample(track_id))
            .padding([2, 8])
            .style(|_theme: &Theme, status| {
                let bg = match status {
                    button::Status::Hovered => th::bg_hover(),
                    _ => th::bg_dark(),
                };
                button::Style {
                    background: Some(bg.into()),
                    border: iced::Border {
                        color: th::border(),
                        width: 1.0,
                        radius: 3.0.into(),
                    },
                    text_color: th::text(),
                    ..Default::default()
                }
            });
        let waveform: Element<'a, Message> = canvas(crate::widgets::mini_waveform::MiniWaveform {
            audio: track.sample_audio.clone(),
            color: track_color,
            region: None,
        })
        .width(Length::Fixed(190.0))
        .height(Length::Fixed(56.0))
        .into();
        let sample = column![
            waveform,
            row![sample_label, load_btn]
                .spacing(8)
                .align_y(iced::Alignment::Center)
        ]
        .spacing(5)
        .width(Length::Fixed(190.0))
        .align_x(iced::Alignment::Start);

        let adsr: Element<'a, Message> = canvas(crate::widgets::mini_waveform::AdsrScope {
            attack: value_of(1),
            decay: value_of(2),
            sustain: value_of(3),
            release: value_of(4),
            color: track_color,
        })
        .width(Length::Fixed(240.0))
        .height(Length::Fixed(34.0))
        .into();
        let envelope = column![
            adsr,
            row![
                knob(1, "Attack"),
                knob(2, "Decay"),
                knob(3, "Sustain"),
                knob(4, "Release")
            ]
            .spacing(6)
        ]
        .spacing(5)
        .align_x(iced::Alignment::Center);

        let body = row![
            Self::device_section("SAMPLE", sample.into()),
            Self::device_divider(),
            Self::device_section("TUNE", knob(0, "Root")),
            Self::device_divider(),
            Self::device_section("ENVELOPE", envelope.into()),
        ]
        .spacing(10)
        .align_y(iced::Alignment::Start);

        // Width = sample 190 + tune 56 + envelope 240 + dividers,
        // spacing, padding. Fixed so the Fill title strip and card
        // background actually render (Fill inside a shrink column
        // collapses in iced).
        let card = Self::device_card(
            column![title, Self::device_body(body.into())].width(Length::Fixed(560.0)),
        );
        let drop_target = matches!(
            self.state.browser.drag_target,
            Some(crate::state::BrowserDropTarget::Sampler { track_id: target }) if target == track_id
        );
        let card = container(card).style(move |_theme: &Theme| container::Style {
            border: iced::Border {
                color: if drop_target {
                    th::accent()
                } else {
                    iced::Color::TRANSPARENT
                },
                width: if drop_target { 2.0 } else { 0.0 },
                radius: 0.0.into(),
            },
            ..Default::default()
        });
        // The whole card accepts browser drops, like drum pads.
        mouse_area(card)
            .on_enter(Message::Browser(BrowserMsg::DragHoverSampler { track_id }))
            .on_exit(Message::Browser(BrowserMsg::ClearDragTarget))
            .on_release(Message::DropSampleOnSampler { track_id })
            .into()
    }

    pub(super) fn view_drum_rack_device<'a>(
        &'a self,
        track_id: TrackId,
        track: &'a UiTrack,
        track_color: Color,
    ) -> Element<'a, Message> {
        use crate::widgets::effect_knob::{param_column, EffectKnobWidget};
        let selected_pad = track
            .selected_drum_pad
            .min(track.drum_rack_pads.len().saturating_sub(1));
        let bank_size = vibez_core::track::DRUM_RACK_BANK_SIZE;
        let bank_count = vibez_core::track::DRUM_RACK_BANK_COUNT;
        let selected_bank = (selected_pad / bank_size).min(bank_count.saturating_sub(1));
        let bank_start = selected_bank * bank_size;
        let title = Self::device_title_bar(Self::device_title_row(
            "Drum Rack",
            track_color,
            Some(Message::remove_track_instrument(track_id)),
        ));

        let activity_now = std::time::Instant::now();
        let earlier_bank_firing = (0..selected_bank).any(|bank| {
            self.state
                .view
                .drum_pad_bank_is_flashing(track_id, bank, activity_now)
        });
        let later_bank_firing = ((selected_bank + 1)..bank_count).any(|bank| {
            self.state
                .view
                .drum_pad_bank_is_flashing(track_id, bank, activity_now)
        });
        let mut grid = column![].spacing(4);
        for row_index in 0..4 {
            let mut pad_row = row![].spacing(4);
            for col_index in 0..4 {
                let pad_index = bank_start + row_index * 4 + col_index;
                let pad = &track.drum_rack_pads[pad_index];
                let pad_pitch = vibez_core::track::drum_rack_pad_pitch(pad_index)
                    .expect("Drum Rack UI renders only valid pad slots");
                let visual_state = drum_pad_visual_state(
                    selected_pad == pad_index,
                    self.state
                        .view
                        .drum_pad_is_flashing(track_id, pad_pitch, activity_now),
                );
                let firing = visual_state == DrumPadVisualState::Firing;
                let selected = visual_state == DrumPadVisualState::Selected;
                let drop_target = matches!(
                    self.state.browser.drag_target,
                    Some(crate::state::BrowserDropTarget::DrumRackPad {
                        track_id: target_track,
                        pad_index: target_pad,
                    }) if target_track == track_id && target_pad == pad_index
                );
                // Hard-truncated single line: wrapping names change
                // the tile height and blow the card's height budget
                // (clipped knobs, dogfood screenshot 2026-07-06).
                let label = pad
                    .name
                    .as_deref()
                    .map(|name| {
                        let short: String = name.chars().take(6).collect();
                        if name.chars().count() > 6 {
                            format!("{short}..")
                        } else {
                            short
                        }
                    })
                    .unwrap_or_else(|| format!("Pad {}", pad_index + 1));
                // Use container + mouse_area so press events reach us and
                // drag-drop works. iced Button would capture ButtonPressed
                // and hide it from mouse_area.
                let pad_note = crate::widgets::piano_roll::pitch_name(pad_pitch);
                let pad_body = container(
                    column![
                        text(format!("{:02}  {pad_note}", pad_index + 1))
                            .size(9)
                            .color(if firing {
                                th::bg_dark()
                            } else if selected {
                                th::accent()
                            } else {
                                th::text_dim()
                            }),
                        text(label).size(8).color(if firing {
                            th::bg_dark()
                        } else if selected {
                            th::accent()
                        } else {
                            th::text()
                        })
                    ]
                    .spacing(2)
                    .align_x(iced::Alignment::Center),
                )
                .padding([3, 4])
                .width(Length::Fixed(52.0))
                .height(Length::Fixed(30.0))
                .style(move |_theme: &Theme| container::Style {
                    background: Some(
                        if firing {
                            th::accent()
                        } else if drop_target || selected {
                            th::accent_dim()
                        } else {
                            th::bg_dark()
                        }
                        .into(),
                    ),
                    text_color: Some(if firing { th::bg_dark() } else { th::text() }),
                    border: iced::Border {
                        color: if firing || drop_target {
                            th::accent()
                        } else if selected {
                            th::accent_dim()
                        } else {
                            th::border()
                        },
                        width: if firing || drop_target { 2.0 } else { 1.0 },
                        radius: 0.0.into(),
                    },
                    ..Default::default()
                });
                // on_release handler selects the pad when no drag is active,
                // otherwise routes through DropSampleOnDrumPad.
                let pad_cell: Element<'a, Message> = mouse_area(pad_body)
                    .on_enter(Message::Browser(BrowserMsg::DragHoverDrumRackPad {
                        track_id,
                        pad_index,
                    }))
                    .on_exit(Message::Browser(BrowserMsg::ClearDragTarget))
                    .on_release(Message::DropSampleOnDrumPad {
                        track_id,
                        pad_index,
                    })
                    .into();
                pad_row = pad_row.push(pad_cell);
            }
            grid = grid.push(pad_row);
        }

        let bank_button = |icon: char, bank: Option<usize>, firing: bool| {
            button(icons::icon(icon).size(9).color(if firing {
                th::accent()
            } else {
                th::text_dim()
            }))
            .on_press_maybe(bank.map(|bank| {
                Message::Devices(crate::domains::devices::DevicesMsg::SelectDrumRackBank(
                    track_id, bank,
                ))
            }))
            .padding([1, 7])
            .style(move |_theme: &Theme, status| button::Style {
                background: Some(
                    if firing {
                        th::accent_dim()
                    } else if matches!(status, button::Status::Hovered | button::Status::Pressed) {
                        th::bg_hover()
                    } else {
                        th::bg_dark()
                    }
                    .into(),
                ),
                text_color: if firing { th::accent() } else { th::text_dim() },
                border: iced::Border {
                    color: if firing { th::accent() } else { th::border() },
                    width: 1.0,
                    radius: 2.0.into(),
                },
                ..Default::default()
            })
        };
        let bank_navigation = row![
            text(format!("BANK {} / {bank_count}", selected_bank + 1))
                .size(9)
                .color(th::text_muted()),
            horizontal_space(),
            bank_button(
                icons::CHEVRON_LEFT,
                selected_bank.checked_sub(1),
                earlier_bank_firing
            ),
            bank_button(
                icons::CHEVRON_RIGHT,
                (selected_bank + 1 < bank_count).then_some(selected_bank + 1),
                later_bank_firing
            ),
        ]
        .spacing(4)
        .align_y(iced::Alignment::Center);

        let selected_name = track.drum_rack_pads[selected_pad]
            .name
            .clone()
            .unwrap_or_else(|| "No sample loaded".to_string());
        let source_hint = track.drum_rack_pads[selected_pad]
            .source
            .as_ref()
            .map(MediaSourceRef::display_name)
            .unwrap_or_else(|| "Use the browser or Load".to_string());
        let selected_pad_state = &track.drum_rack_pads[selected_pad];

        let load_btn = button(text("Load").size(9).color(th::text()))
            .on_press(Message::LoadDrumRackPadSample(track_id, selected_pad))
            .padding([2, 8])
            .style(|_theme: &Theme, status| {
                let bg = match status {
                    button::Status::Hovered => th::bg_hover(),
                    _ => th::bg_dark(),
                };
                button::Style {
                    background: Some(bg.into()),
                    border: iced::Border {
                        color: th::border(),
                        width: 1.0,
                        radius: 3.0.into(),
                    },
                    text_color: th::text(),
                    ..Default::default()
                }
            });

        let clear_btn = button(text("Clear").size(9).color(th::text_dim()))
            .on_press(Message::clear_drum_rack_pad(track_id, selected_pad))
            .padding([2, 8])
            .style(|_theme: &Theme, status| {
                let bg = match status {
                    button::Status::Hovered | button::Status::Pressed => {
                        Some(th::bg_hover().into())
                    }
                    _ => Some(th::bg_dark().into()),
                };
                button::Style {
                    background: bg,
                    border: iced::Border {
                        color: th::border(),
                        width: 1.0,
                        radius: 3.0.into(),
                    },
                    text_color: th::text_dim(),
                    ..Default::default()
                }
            });

        let footer = column![
            text(truncate_end(&selected_name, 22))
                .size(10)
                .color(th::text()),
            text(truncate_end(&source_hint, 26))
                .size(9)
                .color(th::text_dim()),
            row![load_btn, clear_btn]
                .spacing(6)
                .align_y(iced::Alignment::Center)
        ]
        .spacing(4);

        let drum_params = [
            (
                "Gain",
                format!("{:.2}", selected_pad_state.gain),
                selected_pad_state.gain,
                0.0,
                2.0,
                1.0,
                DrumPadParam::Gain,
            ),
            (
                "Pan",
                format!("{:.2}", selected_pad_state.pan),
                selected_pad_state.pan,
                -1.0,
                1.0,
                0.0,
                DrumPadParam::Pan,
            ),
            (
                "Start",
                format!("{:.0}%", selected_pad_state.start * 100.0),
                selected_pad_state.start,
                0.0,
                1.0,
                0.0,
                DrumPadParam::Start,
            ),
            (
                "End",
                format!("{:.0}%", selected_pad_state.end * 100.0),
                selected_pad_state.end,
                0.0,
                1.0,
                1.0,
                DrumPadParam::End,
            ),
            (
                "Fade In",
                format!("{:.0}ms", selected_pad_state.fade_in_ms),
                selected_pad_state.fade_in_ms,
                0.0,
                vibez_core::track::DRUM_PAD_MAX_FADE_MS,
                vibez_core::track::DRUM_PAD_DEFAULT_FADE_MS,
                DrumPadParam::FadeIn,
            ),
            (
                "Fade Out",
                format!("{:.0}ms", selected_pad_state.fade_out_ms),
                selected_pad_state.fade_out_ms,
                0.0,
                vibez_core::track::DRUM_PAD_MAX_FADE_MS,
                vibez_core::track::DRUM_PAD_DEFAULT_FADE_MS,
                DrumPadParam::FadeOut,
            ),
            (
                "Coarse",
                format!("{}st", selected_pad_state.coarse_tune),
                selected_pad_state.coarse_tune as f32,
                -24.0,
                24.0,
                0.0,
                DrumPadParam::CoarseTune,
            ),
            (
                "Fine",
                format!("{:.0}ct", selected_pad_state.fine_tune),
                selected_pad_state.fine_tune,
                -100.0,
                100.0,
                0.0,
                DrumPadParam::FineTune,
            ),
        ];

        let mut knob_row = row![].spacing(6);
        for (label_text, value_text, value, min, max, default, param) in drum_params.iter() {
            let knob = EffectKnobWidget::for_drum_pad(
                track_id,
                selected_pad,
                *param,
                *value,
                *min,
                *max,
                *default,
                track_color,
            );
            knob_row = knob_row.push(param_column(
                knob,
                label_text.to_string(),
                value_text.clone(),
            ));
        }

        let one_shot_active = selected_pad_state.one_shot;
        let one_shot_btn = button(text("One-shot").size(9).color(if one_shot_active {
            th::accent()
        } else {
            th::text_dim()
        }))
        .on_press(Message::Devices(
            crate::domains::devices::DevicesMsg::SetDrumPadOneShot {
                track_id,
                pad_index: selected_pad,
                one_shot: !one_shot_active,
            },
        ))
        .padding([2, 6])
        .style(move |_theme: &Theme, _status| button::Style {
            background: Some(
                if one_shot_active {
                    th::accent_dim()
                } else {
                    th::bg_dark()
                }
                .into(),
            ),
            text_color: if one_shot_active {
                th::accent()
            } else {
                th::text_dim()
            },
            border: iced::Border {
                color: if one_shot_active {
                    th::accent_dim()
                } else {
                    th::border()
                },
                width: 1.0,
                radius: 3.0.into(),
            },
            ..Default::default()
        });

        let mut choke_row = row![text("Choke").size(9).color(th::text_dim())]
            .spacing(2)
            .align_y(iced::Alignment::Center);
        for (group, label) in [
            (None, "Off"),
            (Some(1), "1"),
            (Some(2), "2"),
            (Some(3), "3"),
            (Some(4), "4"),
        ] {
            let active = selected_pad_state.choke_group == group;
            let btn = button(text(label).size(9).color(if active {
                th::accent()
            } else {
                th::text_dim()
            }))
            .on_press(Message::Devices(
                crate::domains::devices::DevicesMsg::SetDrumPadChokeGroup {
                    track_id,
                    pad_index: selected_pad,
                    choke_group: group,
                },
            ))
            .padding([2, 6])
            .style(move |_theme: &Theme, _status| button::Style {
                background: Some(
                    if active {
                        th::accent_dim()
                    } else {
                        th::bg_dark()
                    }
                    .into(),
                ),
                text_color: if active { th::accent() } else { th::text_dim() },
                border: iced::Border {
                    color: if active {
                        th::accent_dim()
                    } else {
                        th::border()
                    },
                    width: 1.0,
                    radius: 3.0.into(),
                },
                ..Default::default()
            });
            choke_row = choke_row.push(btn);
        }

        let pad_wave: Element<'a, Message> = canvas(crate::widgets::mini_waveform::MiniWaveform {
            audio: track.drum_rack_pads[selected_pad].audio.clone(),
            color: track_color,
            region: Some((selected_pad_state.start, selected_pad_state.end)),
        })
        .width(Length::Fixed(190.0))
        .height(Length::Fixed(40.0))
        .into();
        let editor = column![
            row![footer, pad_wave]
                .spacing(10)
                .align_y(iced::Alignment::Center),
            knob_row,
            row![one_shot_btn, choke_row]
                .spacing(8)
                .align_y(iced::Alignment::Center)
        ]
        .spacing(6);

        // Pads and the selected pad's editor sit side by side. The rack owns
        // four banks but renders one fixed 4x4 surface at a time, so adding
        // pads never changes the device card's footprint.
        let pads_view: Element<'a, Message> = column![bank_navigation, grid]
            .spacing(5)
            .width(Length::Fixed(232.0))
            .into();

        let body = row![
            Self::device_section("PADS", pads_view),
            Self::device_divider(),
            Self::device_section("PAD", editor.into()),
        ]
        .spacing(10)
        .align_y(iced::Alignment::Start);

        // Pads + eight full-size pad controls + chrome. Keep the card wide
        // enough that adding controls never compresses either section.
        Self::device_card(
            column![title, Self::device_body(body.into())].width(Length::Fixed(780.0)),
        )
    }

    /// Placeholder card for MIDI tracks with no instrument attached.
    pub(super) fn view_add_instrument_placeholder(&self) -> Element<'_, Message> {
        let title = Self::device_title_bar(text("No Instrument").size(11).color(th::text_dim()));
        let body = container(text("Right-click to add").size(9).color(th::text_muted()))
            .padding([8, 6])
            .width(Length::Fill);

        Self::device_card(
            column![title, body]
                .width(Length::Fixed(120.0))
                .align_x(iced::Alignment::Center),
        )
    }
}

#[cfg(test)]
mod drum_pad_visual_tests {
    use super::*;

    #[test]
    fn firing_has_precedence_over_selection() {
        assert_eq!(
            drum_pad_visual_state(true, true),
            DrumPadVisualState::Firing
        );
        assert_eq!(
            drum_pad_visual_state(true, false),
            DrumPadVisualState::Selected
        );
        assert_eq!(
            drum_pad_visual_state(false, false),
            DrumPadVisualState::Idle
        );
    }
}
