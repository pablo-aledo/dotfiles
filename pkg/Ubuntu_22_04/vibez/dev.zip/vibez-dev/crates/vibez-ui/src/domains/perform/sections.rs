use std::collections::HashMap;
use std::sync::Arc;

use vibez_core::id::{ClipId, LaneId, SectionId, TrackId};
use vibez_engine::playback_source::{
    EngineClip, EngineNoteClip, PreparedPlaybackSource, PreparedSectionPlaybackSource,
};
use vibez_project::SectionLaunchQuantization;

use crate::domains::timeline_editor::TimelineEditorAdapter;
use crate::state::{
    ArrangementTimeline, ResolvedTimeline, ResolvedTimelineMut, TimelineEditorState,
};
use crate::timeline_geometry::TimelineViewport;

pub const DEFAULT_SECTION_LENGTH_BEATS: f64 = 16.0;
pub const MIN_SECTION_LENGTH_BEATS: f64 = 4.0;
pub const MAX_SECTION_LENGTH_BEATS: f64 = 1024.0;

/// Runtime-only editor adapter for the selected Section.
///
/// Persisted Section content remains in [`Section::timeline`]. Selection and
/// pointer interaction state stay outside the canonical Section store.
/// Per-Section navigation state stays here across selection changes and
/// canonical project reloads. The application owns the one clipboard shared
/// with Arrange.
#[derive(Debug, Default)]
pub struct SectionTimelineEditor {
    editor: TimelineEditorState,
    active_section: Option<SectionId>,
    viewport: TimelineViewport,
    viewports: HashMap<SectionId, TimelineViewport>,
    edit_cursors: HashMap<SectionId, f64>,
}

impl SectionTimelineEditor {
    pub fn load(
        &mut self,
        section_id: SectionId,
        timeline: Arc<ArrangementTimeline>,
        selected_track: Option<TrackId>,
    ) {
        self.store_active_viewport();
        self.active_section = Some(section_id);
        self.viewport = self.viewports.get(&section_id).copied().unwrap_or_default();
        self.edit_cursors.entry(section_id).or_insert(0.0);
        self.editor = TimelineEditorState {
            timeline,
            selected_track,
            ..TimelineEditorState::default()
        };
    }

    pub fn clear(&mut self) {
        self.store_active_viewport();
        self.active_section = None;
        self.viewport = TimelineViewport::default();
        self.editor = TimelineEditorState::default();
    }

    pub fn editor(&self) -> &TimelineEditorState {
        &self.editor
    }

    pub fn editor_mut(&mut self) -> &mut TimelineEditorState {
        &mut self.editor
    }

    pub const fn viewport(&self) -> &TimelineViewport {
        &self.viewport
    }

    pub fn viewport_mut(&mut self) -> &mut TimelineViewport {
        &mut self.viewport
    }

    pub fn edit_cursor_beats(&self) -> f64 {
        self.active_section
            .and_then(|section_id| self.edit_cursors.get(&section_id).copied())
            .unwrap_or(0.0)
    }

    pub fn place_edit_cursor(&mut self, beat: f64) {
        if let Some(section_id) = self.active_section {
            self.edit_cursors.insert(section_id, beat.max(0.0));
        }
        self.editor.time_selection_active = false;
    }

    pub fn remove_viewport(&mut self, section_id: SectionId) {
        self.viewports.remove(&section_id);
        self.edit_cursors.remove(&section_id);
        if self.active_section == Some(section_id) {
            self.active_section = None;
            self.viewport = TimelineViewport::default();
        }
    }

    fn store_active_viewport(&mut self) {
        if let Some(section_id) = self.active_section {
            self.viewports.insert(section_id, self.viewport);
        }
    }
}

impl TimelineEditorAdapter for SectionTimelineEditor {
    fn resolve_timeline(&self) -> ResolvedTimeline<'_> {
        ResolvedTimeline {
            editor: &self.editor,
        }
    }

    fn resolve_timeline_mut(&mut self) -> ResolvedTimelineMut<'_> {
        ResolvedTimelineMut {
            editor: &mut self.editor,
        }
    }
}

#[derive(Debug, Clone)]
pub struct Section {
    pub id: SectionId,
    pub slot: u16,
    pub name: String,
    pub length_beats: f64,
    pub launch_quantization: SectionLaunchQuantization,
    pub looping: bool,
    pub timeline: Arc<ArrangementTimeline>,
}

impl Section {
    pub fn new(slot: u16) -> Self {
        Self {
            id: SectionId::new(),
            slot,
            name: format!("Section {:02}", slot + 1),
            length_beats: DEFAULT_SECTION_LENGTH_BEATS,
            launch_quantization: SectionLaunchQuantization::default(),
            looping: true,
            timeline: Arc::new(ArrangementTimeline::default()),
        }
    }

    pub fn duplicate_to(&self, slot: u16) -> Self {
        let mut timeline = self.timeline.as_ref().clone();
        for content in timeline.by_track.values_mut() {
            for clip in &mut content.clips {
                clip.id = ClipId::new();
            }
            for clip in &mut content.note_clips {
                clip.id = ClipId::new();
                clip.selected_notes.clear();
            }
            for lane in &mut content.automation {
                lane.id = LaneId::new();
            }
        }
        Self {
            id: SectionId::new(),
            slot,
            name: format!("{} Copy", self.name),
            length_beats: self.length_beats,
            launch_quantization: self.launch_quantization,
            looping: self.looping,
            timeline: Arc::new(timeline),
        }
    }

    /// Whether a beat is active inside this Section's non-destructive
    /// playable boundary. Timeline content outside the boundary remains stored.
    pub fn contains_playable_beat(&self, beat: f64) -> bool {
        beat >= 0.0 && beat < self.length_beats
    }

    /// Resolve this Section into the engine's resident playback-source seam.
    /// Every Project Track receives a source, including empty sources that
    /// express intentional silence without resetting the shared channel.
    pub fn prepare_playback_source(
        &self,
        project_tracks: &[crate::state::ProjectTrack],
    ) -> PreparedSectionPlaybackSource {
        let track_ids: Vec<_> = project_tracks.iter().map(|track| track.id).collect();
        self.prepare_playback_source_for_tracks(&track_ids)
    }

    pub fn prepare_playback_source_for_tracks(
        &self,
        project_track_ids: &[TrackId],
    ) -> PreparedSectionPlaybackSource {
        let tracks = project_track_ids
            .iter()
            .map(|track_id| {
                let content = self.timeline.get(*track_id);
                let clips = content
                    .into_iter()
                    .flat_map(|content| content.clips.iter())
                    .map(|clip| EngineClip {
                        id: clip.id,
                        audio: Arc::clone(&clip.audio),
                        position: clip.position,
                        source_offset: clip.source_offset,
                        start_marker: clip.start_marker,
                        duration: clip.duration,
                        loop_enabled: clip.loop_enabled,
                        loop_start: clip.loop_start,
                        loop_end: clip.loop_end,
                        linear_gain: clip.gain_db.linear(),
                        fades: clip.fades.clamped_to(clip.duration),
                        playback_direction: clip.playback_direction,
                        warp_markers: clip.warp_markers.clone(),
                    })
                    .collect();
                let note_clips = content
                    .into_iter()
                    .flat_map(|content| content.note_clips.iter())
                    .map(|clip| {
                        EngineNoteClip::new(
                            clip.id,
                            clip.position_beats,
                            clip.duration_beats,
                            clip.notes.clone(),
                            clip.start_marker_beats,
                            clip.loop_enabled,
                            clip.loop_start_beats,
                            clip.loop_end_beats,
                            clip.groove_grid,
                        )
                    })
                    .collect();
                let automation = content
                    .map(|content| content.automation.clone())
                    .unwrap_or_default();
                (
                    *track_id,
                    PreparedPlaybackSource::new(clips, note_clips, automation),
                )
            })
            .collect();
        PreparedSectionPlaybackSource::new(self.id, self.length_beats, self.looping, tracks)
    }
}

#[derive(Debug, Clone, Default)]
pub struct SectionStore {
    pub sections: Vec<Section>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TimelineContentLocation {
    Arrange,
    Section { slot: u16, name: String },
}

impl SectionStore {
    pub fn at_slot(&self, slot: u16) -> Option<&Section> {
        self.sections.iter().find(|section| section.slot == slot)
    }

    pub fn by_id(&self, id: SectionId) -> Option<&Section> {
        self.sections.iter().find(|section| section.id == id)
    }

    pub fn by_id_mut(&mut self, id: SectionId) -> Option<&mut Section> {
        self.sections.iter_mut().find(|section| section.id == id)
    }

    pub fn insert(&mut self, section: Section) {
        debug_assert!(self.at_slot(section.slot).is_none());
        self.sections.push(section);
        self.sections.sort_by_key(|section| section.slot);
    }

    pub fn remove(&mut self, id: SectionId) -> Option<Section> {
        let index = self.sections.iter().position(|section| section.id == id)?;
        Some(self.sections.remove(index))
    }

    pub fn remove_track(&mut self, track_id: TrackId) {
        for section in &mut self.sections {
            Arc::make_mut(&mut section.timeline).remove(track_id);
        }
    }

    pub fn track_content_locations(
        &self,
        arrangement: &ArrangementTimeline,
        track_id: TrackId,
    ) -> Vec<TimelineContentLocation> {
        let has_content = |timeline: &ArrangementTimeline| {
            timeline.get(track_id).is_some_and(|content| {
                !content.clips.is_empty()
                    || !content.note_clips.is_empty()
                    || !content.automation.is_empty()
            })
        };
        let mut locations = Vec::new();
        if has_content(arrangement) {
            locations.push(TimelineContentLocation::Arrange);
        }
        locations.extend(
            self.sections
                .iter()
                .filter(|section| has_content(&section.timeline))
                .map(|section| TimelineContentLocation::Section {
                    slot: section.slot,
                    name: section.name.clone(),
                }),
        );
        locations
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::domains::timeline_editor::conformance::assert_timeline_editor_conformance;
    use crate::state::{ArrangementState, TrackTimelineContent, UiClip, UiNoteClip};

    #[test]
    fn section_playback_keeps_audio_clip_gain() {
        let track_id = TrackId::new();
        let mut section = Section::new(0);
        let gain_db = vibez_core::track::ClipGainDb::new(-6.0).unwrap();
        Arc::make_mut(&mut section.timeline)
            .ensure(track_id)
            .clips
            .push(UiClip {
                id: ClipId::new(),
                name: "Loop".into(),
                audio: Arc::new(vibez_core::audio_buffer::DecodedAudio {
                    channels: vec![vec![1.0; 64]],
                    sample_rate: 48_000,
                }),
                source: None,
                position: 0,
                source_offset: 0,
                start_marker: 0,
                duration: 64,
                loop_enabled: false,
                loop_start: 0,
                loop_end: 64,
                gain_db,
                fades: Default::default(),
                playback_direction: Default::default(),
                transient_markers: Default::default(),
                warp_markers: Default::default(),
                transpose: Default::default(),
                original_bpm: None,
                warped: false,
                warped_to_bpm: None,
                original_audio: None,
            });

        let prepared = section.prepare_playback_source_for_tracks(&[track_id]);
        assert_eq!(prepared.tracks()[0].source.clips.len(), 1);
        assert!(
            (prepared.tracks()[0].source.clips[0].linear_gain - gain_db.linear()).abs()
                < f32::EPSILON
        );
    }

    #[test]
    fn section_playback_keeps_audio_clip_reverse_direction() {
        let track_id = TrackId::new();
        let clip_id = ClipId::new();
        let mut section = Section::new(0);
        Arc::make_mut(&mut section.timeline)
            .ensure(track_id)
            .clips
            .push(UiClip {
                id: clip_id,
                name: "Reverse loop".into(),
                audio: Arc::new(vibez_core::audio_buffer::DecodedAudio {
                    channels: vec![vec![1.0, 2.0, 3.0, 4.0]],
                    sample_rate: 48_000,
                }),
                source: None,
                position: 0,
                source_offset: 0,
                start_marker: 0,
                duration: 4,
                loop_enabled: false,
                loop_start: 0,
                loop_end: 4,
                gain_db: Default::default(),
                fades: Default::default(),
                playback_direction: vibez_core::track::ClipPlaybackDirection::Reverse,
                transient_markers: Default::default(),
                warp_markers: Default::default(),
                transpose: Default::default(),
                original_bpm: None,
                warped: false,
                warped_to_bpm: None,
                original_audio: None,
            });

        let prepared = section.prepare_playback_source_for_tracks(&[track_id]);
        let mut output = vec![0.0; 4];
        assert!(prepared.tracks()[0]
            .source
            .render_audio(&mut output, 0, 4, 1, None));
        assert_eq!(output, vec![4.0, 3.0, 2.0, 1.0]);
    }

    #[test]
    fn duplicate_remints_every_editable_identity() {
        let track_id = TrackId::new();
        let mut source = Section::new(0);
        let note_id = ClipId::new();
        let lane = vibez_core::automation::AutomationLane::new(
            vibez_core::automation::AutomationTarget::TrackGain,
        );
        let original_lane_id = lane.id;
        Arc::make_mut(&mut source.timeline).by_track.insert(
            track_id,
            TrackTimelineContent {
                note_clips: vec![UiNoteClip {
                    id: note_id,
                    name: "Pattern".into(),
                    position_beats: 0.0,
                    duration_beats: 4.0,
                    notes: Vec::new(),
                    selected_notes: [0].into_iter().collect(),
                    start_marker_beats: 0.0,
                    loop_enabled: false,
                    loop_start_beats: 0.0,
                    loop_end_beats: 0.0,
                    groove_grid: vibez_core::perform::GrooveGrid::Sixteenth,
                }],
                automation: vec![lane],
                ..TrackTimelineContent::default()
            },
        );

        let duplicate = source.duplicate_to(7);

        assert_ne!(duplicate.id, source.id);
        assert_ne!(
            duplicate.timeline.get(track_id).unwrap().note_clips[0].id,
            note_id
        );
        assert_ne!(
            duplicate.timeline.get(track_id).unwrap().automation[0].id,
            original_lane_id
        );
        assert!(duplicate.timeline.get(track_id).unwrap().note_clips[0]
            .selected_notes
            .is_empty());
    }

    #[test]
    fn section_adapter_satisfies_the_shared_editor_contract() {
        assert_timeline_editor_conformance(SectionTimelineEditor::default());
    }

    #[test]
    fn arrange_and_section_adapters_never_share_timeline_mutations() {
        let track_id = TrackId::new();
        let mut arrange = ArrangementState::default();
        let mut section = SectionTimelineEditor::default();
        section.load(
            SectionId::new(),
            Arc::new(ArrangementTimeline::default()),
            Some(track_id),
        );

        Arc::make_mut(&mut section.editor_mut().timeline)
            .ensure(track_id)
            .note_clips
            .push(UiNoteClip {
                id: ClipId::new(),
                name: "Section Pattern".into(),
                position_beats: 0.0,
                duration_beats: 4.0,
                notes: Vec::new(),
                selected_notes: Default::default(),
                start_marker_beats: 0.0,
                loop_enabled: false,
                loop_start_beats: 0.0,
                loop_end_beats: 0.0,
                groove_grid: vibez_core::perform::GrooveGrid::Off,
            });

        assert!(arrange.editor.timeline.get(track_id).is_none());
        assert_eq!(
            section
                .editor()
                .timeline
                .get(track_id)
                .expect("Section track content")
                .note_clips
                .len(),
            1
        );

        Arc::make_mut(&mut arrange.editor.timeline)
            .ensure(track_id)
            .note_clips
            .push(UiNoteClip {
                id: ClipId::new(),
                name: "Arrange Pattern".into(),
                position_beats: 8.0,
                duration_beats: 4.0,
                notes: Vec::new(),
                selected_notes: Default::default(),
                start_marker_beats: 0.0,
                loop_enabled: false,
                loop_start_beats: 0.0,
                loop_end_beats: 0.0,
                groove_grid: vibez_core::perform::GrooveGrid::Off,
            });
        let section_clip = &section.editor().timeline.get(track_id).unwrap().note_clips[0];
        assert_eq!(section_clip.name, "Section Pattern");
        assert_eq!(section_clip.position_beats, 0.0);
    }

    #[test]
    fn every_section_restores_its_independent_runtime_viewport() {
        let first = SectionId::new();
        let second = SectionId::new();
        let mut editor = SectionTimelineEditor::default();

        editor.load(first, Arc::new(ArrangementTimeline::default()), None);
        editor.viewport_mut().zoom_level = 4.0;
        editor.viewport_mut().scroll_offset_beats = 12.0;
        editor.place_edit_cursor(9.0);
        editor.load(second, Arc::new(ArrangementTimeline::default()), None);
        assert_eq!(editor.viewport().zoom_level, 2.0);
        assert_eq!(editor.viewport().scroll_offset_beats, 0.0);
        assert_eq!(editor.edit_cursor_beats(), 0.0);
        editor.place_edit_cursor(3.0);

        editor.load(first, Arc::new(ArrangementTimeline::default()), None);
        assert_eq!(editor.viewport().zoom_level, 4.0);
        assert_eq!(editor.viewport().scroll_offset_beats, 12.0);
        assert_eq!(editor.edit_cursor_beats(), 9.0);
        editor.load(second, Arc::new(ArrangementTimeline::default()), None);
        assert_eq!(editor.edit_cursor_beats(), 3.0);
    }

    #[test]
    fn section_edit_cursor_survives_reload_and_is_remembered_per_section() {
        let first_id = SectionId::new();
        let second_id = SectionId::new();
        let first_timeline = Arc::new(ArrangementTimeline::default());
        let second_timeline = Arc::new(ArrangementTimeline::default());
        let mut editor = SectionTimelineEditor::default();

        editor.load(first_id, Arc::clone(&first_timeline), None);
        editor.place_edit_cursor(12.0);
        editor.load(first_id, Arc::clone(&first_timeline), None);
        assert_eq!(
            editor.edit_cursor_beats(),
            12.0,
            "undo, redo, and project replay reload the selected Section"
        );

        editor.load(second_id, Arc::clone(&second_timeline), None);
        editor.place_edit_cursor(3.0);
        editor.load(first_id, first_timeline, None);
        assert_eq!(editor.edit_cursor_beats(), 12.0);
        editor.load(second_id, second_timeline, None);
        assert_eq!(editor.edit_cursor_beats(), 3.0);
    }

    #[test]
    fn shortening_only_changes_the_playable_boundary() {
        let track_id = TrackId::new();
        let mut section = Section::new(0);
        let hidden_clip = UiNoteClip {
            id: ClipId::new(),
            name: "Fill".into(),
            position_beats: 12.0,
            duration_beats: 4.0,
            notes: Vec::new(),
            selected_notes: Default::default(),
            start_marker_beats: 0.0,
            loop_enabled: false,
            loop_start_beats: 0.0,
            loop_end_beats: 0.0,
            groove_grid: vibez_core::perform::GrooveGrid::Off,
        };
        Arc::make_mut(&mut section.timeline)
            .ensure(track_id)
            .note_clips
            .push(hidden_clip.clone());

        section.length_beats = 8.0;
        assert!(!section.contains_playable_beat(hidden_clip.position_beats));
        assert_eq!(
            section.timeline.get(track_id).unwrap().note_clips[0].id,
            hidden_clip.id
        );

        section.length_beats = 16.0;
        assert!(section.contains_playable_beat(hidden_clip.position_beats));
        assert_eq!(
            section.timeline.get(track_id).unwrap().note_clips[0].id,
            hidden_clip.id
        );
    }

    #[test]
    fn playback_adapter_prepares_every_project_track_for_intentional_silence() {
        let populated_id = TrackId::new();
        let silent_id = TrackId::new();
        let mut section = Section::new(0);
        Arc::make_mut(&mut section.timeline)
            .ensure(populated_id)
            .note_clips
            .push(UiNoteClip {
                id: ClipId::new(),
                name: "Pattern".into(),
                position_beats: 0.0,
                duration_beats: 4.0,
                notes: Vec::new(),
                selected_notes: Default::default(),
                start_marker_beats: 0.0,
                loop_enabled: false,
                loop_start_beats: 0.0,
                loop_end_beats: 0.0,
                groove_grid: vibez_core::perform::GrooveGrid::Off,
            });
        let tracks = [
            crate::state::ProjectTrack::new(populated_id, "Drums".into(), 0),
            crate::state::ProjectTrack::new(silent_id, "Bass".into(), 1),
        ];

        let prepared = section.prepare_playback_source(&tracks);

        assert_eq!(prepared.section_id, section.id);
        assert_eq!(prepared.tracks().len(), 2);
        assert_eq!(prepared.tracks()[0].track_id, populated_id);
        assert_eq!(prepared.tracks()[0].source.note_clips.len(), 1);
        assert_eq!(prepared.tracks()[1].track_id, silent_id);
        assert!(prepared.tracks()[1].source.clips.is_empty());
        assert!(prepared.tracks()[1].source.note_clips.is_empty());
        assert!(prepared.tracks()[1].source.automation.is_empty());
    }

    #[test]
    fn content_locations_include_arrange_and_every_affected_section() {
        let track_id = TrackId::new();
        let mut arrange = ArrangementTimeline::default();
        arrange
            .ensure(track_id)
            .automation
            .push(vibez_core::automation::AutomationLane::new(
                vibez_core::automation::AutomationTarget::TrackGain,
            ));
        let mut first = Section::new(0);
        first.name = "Verse".into();
        Arc::make_mut(&mut first.timeline)
            .ensure(track_id)
            .automation
            .push(vibez_core::automation::AutomationLane::new(
                vibez_core::automation::AutomationTarget::TrackPan,
            ));
        let mut second = Section::new(5);
        second.name = "Fill".into();
        Arc::make_mut(&mut second.timeline)
            .ensure(track_id)
            .automation
            .push(vibez_core::automation::AutomationLane::new(
                vibez_core::automation::AutomationTarget::TrackGain,
            ));
        let sections = SectionStore {
            sections: vec![first, second],
        };

        assert_eq!(
            sections.track_content_locations(&arrange, track_id),
            [
                TimelineContentLocation::Arrange,
                TimelineContentLocation::Section {
                    slot: 0,
                    name: "Verse".into()
                },
                TimelineContentLocation::Section {
                    slot: 5,
                    name: "Fill".into()
                }
            ]
        );
    }
}
