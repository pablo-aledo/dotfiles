This CMake project checks that Fluidsynth can be imported through `find_package` and link properly.
