https://google.github.io/comprehensive-rust/
https://rust-unofficial.github.io/too-many-lists/index.html
https://doc.rust-lang.org/book/
https://doc.rust-lang.org/rust-by-example/
