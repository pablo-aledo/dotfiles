My wiki
=======

Contains some installation information or other stuff.

External links:

* [albertz/Coding-Game-Intro](https://github.com/albertz/Coding-Game-Intro)
* [albertz/errordb](https://github.com/albertz/errordb)
* [albertz/backup_system](https://github.com/albertz/backup_system)
