# Coding for kids

This is just some resource collection.
Maybe I will add some own comments or experiences later.
See also [coding in general](coding.md).


# Links

* [mytechnotalent / Python-For-Kids](https://github.com/mytechnotalent/Python-For-Kids), [HN discussion](https://news.ycombinator.com/item?id=24633199)
* [My own 'coding for dummies'](http://www.az2000.de/docs/coding_for_dummies/).
  German, pseudo code + object pascal later, on the example of [my Robot2 project](https://github.com/albertz/Robot2).
* [My PyOverheadGame project](https://github.com/albertz/PyOverheadGame),
  as an educational Python game.
* [albertz / Coding-Game-Intro](https://github.com/albertz/Coding-Game-Intro)
