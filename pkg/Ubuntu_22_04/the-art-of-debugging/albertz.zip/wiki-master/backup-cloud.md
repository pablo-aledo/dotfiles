See [backup software](backup-software.md).

# Backup cloud storage

* [rsync.net](https://www.rsync.net).
  [Special cheap support for Borg](https://www.rsync.net/products/borg.html).
* Dropbox
* Google Drive
