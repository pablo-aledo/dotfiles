This is supposed to be a log of (interesting) personal projects
(mostly software projects, but not necessarily restricted to such).
I keep this list / log because just the raw list of GitHub repos is maybe not a good overview.

Maybe I will later reorganize this...
(E.g. directory with individual files per project / entry, more like a blog.)

This is not supposed to be complete...

* 2021, Jan. [Mouse scroll wheel acceleration, implemented in user space](https://github.com/albertz/mouse-scroll-wheel-acceleration-userspace)

* [PyTorch-to-RETURNN](https://github.com/rwth-i6/pytorch-to-returnn)

* [RETURNN](https://github.com/rwth-i6/returnn)
  ([tutorial slides](https://www-i6.informatik.rwth-aachen.de/publications/download/1154/Zeyer--2020.pdf))

* [OpenLieroX](https://github.com/albertz/openlierox)

* [PyCParser](https://github.com/albertz/PyCParser)

* [RandomFtpGrabber](https://github.com/albertz/RandomFtpGrabber)

* [Music player](https://github.com/albertz/music-player) ([core](https://github.com/albertz/music-player-core))

* [Python better_exchook](https://github.com/albertz/py_better_exchook)

* [PyOverheadGame](https://github.com/albertz/PyOverheadGame)

* [Background ZMQ IPython/Jupyter kernel](https://github.com/albertz/background-zmq-ipython)

* [timecapture - captures your current topmost application and the URL/file with timestamps](https://github.com/albertz/timecapture)

* [ParseOggVorbis - C++ OGG Vorbis decoder](https://github.com/albertz/ParseOggVorbis)

* [drink kiosk](https://github.com/rwth-i6/drink-kiosk)

* [Commander Genius - Commander Keen compatible clone](https://github.com/gerstrong/Commander-Genius)

* [PictureSlider - MacOSX picture screen saver](https://github.com/albertz/PictureSlider)
