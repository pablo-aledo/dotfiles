Moved to [Methodology](./methodology)
