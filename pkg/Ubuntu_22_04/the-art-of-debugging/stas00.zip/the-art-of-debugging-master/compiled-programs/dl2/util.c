#include <stdio.h>

int util_a()
{
    printf("Inside util_a()\n");
    return 0;
}

int util_b()
{
    printf("Inside util_b()\n");
    return 0;
}
