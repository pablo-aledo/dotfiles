#include <stdio.h>

int util_a()
{
    printf("Inside util_a()\n");
    return 0;
}
