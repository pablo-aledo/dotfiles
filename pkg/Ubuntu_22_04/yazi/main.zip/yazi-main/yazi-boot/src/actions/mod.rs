#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(actions clear_cache debug version);
