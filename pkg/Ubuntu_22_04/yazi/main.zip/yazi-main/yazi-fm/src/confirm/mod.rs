yazi_macro::mod_flat!(buttons confirm content list);
