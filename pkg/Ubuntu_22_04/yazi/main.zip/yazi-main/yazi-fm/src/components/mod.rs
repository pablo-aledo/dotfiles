#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(preview progress);
