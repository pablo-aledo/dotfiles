yazi_macro::mod_flat!(bindings layout);
