#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(
	config file files filter finder folder iter lives mode preview selected tab tabs
	tasks yanked
);

type CtxRef<'lua> = mlua::UserDataRef<'lua, crate::Ctx>;
