#![allow(clippy::if_same_then_else)]

yazi_macro::mod_flat!(files filter folder sorter stage step);
