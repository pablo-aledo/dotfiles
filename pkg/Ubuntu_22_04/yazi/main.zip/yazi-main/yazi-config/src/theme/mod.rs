yazi_macro::mod_flat!(filetype flavor icons is theme);
