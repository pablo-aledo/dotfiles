yazi_macro::mod_flat!(manager mouse ratio sorting);
