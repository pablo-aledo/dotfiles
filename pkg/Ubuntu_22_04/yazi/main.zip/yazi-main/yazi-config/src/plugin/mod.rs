yazi_macro::mod_flat!(fetcher plugin preloader previewer);

pub const MAX_PREWORKERS: u8 = 32;
