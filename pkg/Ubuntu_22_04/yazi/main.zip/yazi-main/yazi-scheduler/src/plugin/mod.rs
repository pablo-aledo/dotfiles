#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(op plugin);
