#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(
	body bulk bye cd custom delete hey hi hover move_ rename tab trash yank
);
