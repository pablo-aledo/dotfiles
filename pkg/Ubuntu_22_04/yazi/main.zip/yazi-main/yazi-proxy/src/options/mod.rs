yazi_macro::mod_flat!(notify open process search);
