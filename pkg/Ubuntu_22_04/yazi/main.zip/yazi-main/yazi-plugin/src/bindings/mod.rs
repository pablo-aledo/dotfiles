#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(bindings icon input mouse permit position range window);
