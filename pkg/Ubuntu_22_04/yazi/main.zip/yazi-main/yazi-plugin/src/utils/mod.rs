#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(
	app cache call image layer log preview sync target text time user utils
);
