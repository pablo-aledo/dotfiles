#![allow(clippy::module_inception)]

yazi_macro::mod_flat!(bar border clear constraint elements gauge layout line list padding position rect span style table text);
