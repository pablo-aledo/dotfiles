yazi_macro::mod_flat!(arrow cancel inspect open_with process_exec toggle);
