yazi_macro::mod_flat!(
	backspace backward close complete delete escape forward insert kill move_ paste redo
	show type_ undo visual yank
);
