yazi_macro::mod_pub!(commands);

yazi_macro::mod_flat!(message notify);

pub const NOTIFY_BORDER: u16 = 2;
pub const NOTIFY_SPACING: u16 = 1;
