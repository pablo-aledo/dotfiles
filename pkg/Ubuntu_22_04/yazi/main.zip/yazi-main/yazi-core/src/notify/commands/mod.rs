yazi_macro::mod_flat!(push tick);
