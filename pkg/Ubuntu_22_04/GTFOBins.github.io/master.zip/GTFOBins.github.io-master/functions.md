---
layout: page
title: Functions
---

A binary may support one or more of the following functions:

{% include functions_description.html %}
