---
functions:
  shell:
    - code: sash
  suid:
    - code: ./sash
  sudo:
    - code: sudo sash
---
