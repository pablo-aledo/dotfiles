---
functions:
  sudo:
    - code: sudo sudo /bin/sh
---
