---
functions:
  sudo:
    - code: sudo su
---
