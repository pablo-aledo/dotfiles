---
functions:
  shell:
    - code: task execute /bin/sh
  sudo:
    - code: sudo task execute /bin/sh
---
