---
functions:
  sudo:
    - code: sudo ksu -q -e /bin/sh
---
