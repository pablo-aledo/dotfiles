---
functions:
  shell:
    - code: ansible-test shell
  sudo:
    - code: sudo ansible-test shell
---
