---
functions:
  shell:
    - code: torify /bin/sh
  sudo:
    - code: sudo torify /bin/sh
---
