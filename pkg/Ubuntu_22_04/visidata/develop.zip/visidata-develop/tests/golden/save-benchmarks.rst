==========  ==========================  =======  ==============================================  ==========  =======  =========
Date        Customer                    SKU      Item                                              Quantity     Unit  Paid
==========  ==========================  =======  ==============================================  ==========  =======  =========
2018-07-03  Robert Armstrong            FOOD213  BFF Oh My Gravy! Beef & Salmon 2.8oz                     4    12.95  $51.8
2018-07-03  Kyle Kennedy                FOOD121  Food, Adult Cat - 3.5 oz                                 1     4.22  $4.22
2018-07-05  Douglas "Dougie" Powers     FOOD121  Food, Adult Cat 3.5 oz                                   1     4.22  $4.22
2018-07-06  桜 高橋 (Sakura Takahashi)  FOOD122  Food, Senior Wet Cat - 3 oz                             12     1.29  157¥
2018-07-10  David Attenborough          NSCT201  Food, Salamander                                        30     0.05  $1.5
2018-07-10  Susan Ashworth              CAT060   Cat, Korat (Felis catus)                                 1   720.42  $720.42
2018-07-10  Susan Ashworth              FOOD130  Food, Kitten 3kg                                         1    14.94  $14.94
2018-07-13  Wil Wheaton                 NSCT523  Monster, Rust (Monstrus gygaxus)                         1    39.95  $39.95
2018-07-13  Robert Armstrong            FOOD216  BFF Oh My Gravy! Chicken & Shrimp 2.8oz                  4    12.95  $51.8
2018-07-17  Robert Armstrong            FOOD217  BFF Oh My Gravy! Duck & Tuna 2.8oz                       4    12.95  $51.8
2018-07-17  Helen Halestorm             LAGO342  Rabbit (Oryctolagus cuniculus)                           2    32.94  $65.88
2018-07-18  桜 高橋 (Sakura Takahashi)  FOOD122  Food, Senior Wet Cat - 3 oz                              6     1.29  157¥
2018-07-19  Rubeus Hagrid               FOOD170  Food, Dog - 5kg                                          5    44.95  $224.75
2018-07-20  Jon Arbuckle                FOOD167  Food, Premium Wet Cat - 3.5 oz                          50     3.95  $197.5
2018-07-23  Robert Armstrong            FOOD215  BFF Oh My Gravy! Lamb & Tuna 2.8oz                       4    12.95  $51.8
2018-07-23  Douglas "Dougie" Powers     TOY235   Laser Pointer                                            1    16.12  $16.12
2018-07-24  桜 高橋 (Sakura Takahashi)  FOOD122  Food, Senior Wet Cat - 3 oz                              3     1.29  157¥
2018-07-26  Douglas "Dougie" Powers     FOOD420  Food, Shark - 10 kg                                      1    15.7   $15.7
2018-07-27  桜 高橋 (Sakura Takahashi)  FOOD122  Food, Senior Wet Cat - 3 oz                              3     1.29  157¥
2018-07-30  桜 高橋 (Sakura Takahashi)  RETURN   Food, Senior Wet Cat - 3 oz                              1     1.29  157¥
2018-07-31  Rubeus Hagrid               CAT060   Food, Dragon - 50kg                                      5   720.42  $3602.1
2018-08-01  David Attenborough          FOOD360  Food, Rhinocerous - 50kg                                 4     5.72  $22.88
2018-08-02  Susan Ashworth              CAT110   Cat, Maine Coon (Felix catus)                            1  1309.68  $1309.68
2018-08-02  Susan Ashworth              FOOD130  Food, Kitten 3kg                                         3    14.94  $44.82
2018-08-06  Robert Armstrong            FOOD212  BFF Oh My Gravy! Beef & Chicken 2.8oz                    4    12.95  $51.8
2018-08-07  Juan Johnson                REPT082  Kingsnake, California (Lampropeltis getula)              1    89.95  $89.95
2018-08-07  Juan Johnson                RDNT443  Mouse, Pinky (Mus musculus)                              1     1.49  $1.49
2018-08-10  Robert Armstrong            FOOD211  BFF Oh My Gravy! Chicken & Turkey 2.8oz                  4    12.95  $51.8
2018-08-13  Monica Johnson              RDNT443  Mouse, Pinky (Mus musculus)                              1     1.49  $1.49
2018-08-13  María Fernández             FOOD146  Forti Diet Prohealth Mouse/Rat 3lbs                      2     2     $4.0
2018-08-15  Mr. Praline                 RETURN   Parrot, Norwegian Blue (Mopsitta tanta)                  1  2300     -$2300.0
2018-08-15  Kyle Kennedy                FOOD121  Food, Adult Cat - 3.5 oz                                 2     4.22  $8.44
2018-08-16  Helen Halestorm             RETURN   Rabbit (Oryctolagus cuniculus)                           6     0     $0.0
2018-08-16  Kyle Kennedy                DOG010   Dog, Golden Retriever (Canis lupus familiaris)           1  2495.99  $2495.99
2018-08-16  Michael Smith               BIRD160  Parakeet, Blue (Melopsittacus undulatus)                 1    29.95  $31.85
2018-08-17  Rubeus Hagrid               NSCT201  Food, Spider                                             5     0.05  $0.25
2018-08-20  Kyle Kennedy                RETURN   Dog, Golden Retriever (Canis lupus familiaris)           1  1247.99  -$1247.99
2018-08-20  מרוסיה ניסנהולץ אבולעפיה    GOAT224  Goat, American Pygmy (Capra hircus)                      1   499     $160.51
2018-08-20  Monica Johnson              NSCT201  Crickets, Adult Live (Gryllus assimilis)                30     0.05  $1.5
2018-08-20  David Attenborough          NSCT084  Food, Pangolin                                          30     0.17  $5.10
2018-08-21  Robert Armstrong            FOOD214  BFF Oh My Gravy! Duck & Salmon 2.8oz                     4    12.95  $51.8
2018-08-22  David Attenborough          BIRD160  Food, Quoll                                              1    29.95  $29.95
2018-08-22  Jon Arbuckle                FOOD170  Food, Adult Dog - 5kg                                    1    44.95  $44.95
2018-08-22  מרוסיה ניסנהולץ             SFTY052  Fire Extinguisher, kitchen-rated                         1    61.7   $61.70
2018-08-24  Robert Armstrong            FOOD218  BFF Oh My Gravy! Chicken & Salmon 2.8oz                  4    12.95  $51.8
2018-08-27  Monica Johnson              NSCT443  Mealworms, Large (Tenebrio molitor) 100ct                1     1.99  $1.99
2018-08-28  Susan Ashworth              CAT020   Cat, Scottish Fold (Felis catus)                         1  1964.53  $1964.53
2018-08-28  Susan Ashworth              FOOD130  Food, Kitten 3kg                                         2    14.94  $29.88
2018-08-29  Robert Armstrong            FOOD219  BFF Oh My Gravy! Chicken & Pumpkin 2.8oz                 4    12.95  $51.8
2018-08-31  Robert Armstrong            FOOD219  BFF Oh My Gravy! Chicken & Pumpkin 2.8oz               144    12.95  $1864.8
2018-08-31  Juan Johnson                REPT217  Lizard, Spinytail (Uromastyx ornatus)                    1    99.95  $99.95
==========  ==========================  =======  ==============================================  ==========  =======  =========