---
eleventyNavigation:
  key: Editing Contents
  order: 6
Update: 2018-08-19
Version: VisiData 1.3.1
---



## How to edit cells

For a summary of all editing commands, see the [man page](/man#edit).

Command                    Operation
--------                   ----------
 `e`                       edit contents of **current cell**
`ge` *text*                set contents of **current column for selected rows** to *text*
`g*` *regex*/*subst*       replace matching *regex* in **current column for selected rows** with *subst*
`g=` *expr*                evaluate Python *expr* over each selected row and set **current column** to the result

## note!

Modifications made to rows on derived sheets will be reflected on the source sheets.  This includes the Frequency Table: editing the key column there will change all instances on the source sheet, and if that sheet is derived from another source sheet, it will be reflected there, and so on.

This does not apply to adding or deleting rows, only changes to existing rows.

## Commands while editing

While in editing mode, or anytime VisiData expects input (with e.g. `=`, `;`), typical readline commands become available:

Command             Operation
--------            ----------
`Enter`             accepts input
`Ctrl+C`/`Esc`      aborts input
`Ctrl+O`            opens external $EDITOR to edit contents
`Ctrl+R`            reloads initial value
`Ctrl+A`/`Ctrl+E`   moves to beginning/end of line
`Backspace`         deletes previous character
`Up`/`Down`         sets contents to previous/next in history
`Tab`/`Shift-Tab`   autocompletes input (when available)

---

## How to rename columns

Command     Operation
--------    ----------
  `^`       edits name of **current** column
 `g^`       sets names of **all unnamed visible** columns to contents of **selected** rows (or **current** row)
 `z^`       sets name of **current** column to contents of **current** cell
`gz^`       sets name of **current** column to combined contents of **current** column for **selected** rows

In most cases, `^` is the preferred command. Examples which demo `^` can be seen in [Columns](/docs/columns#derived) and [Group](/docs/group#frequency).

###### How to set the header in an Excel sheet?

For most filetypes (e.g. csv, tsv, xls(x)) the loaders assume that the dataset's first `options.header` rows contain the column names.

If the Excel file has multiple sheets with varying number of header rows:

1. Pass `--header=0` while loading the file.

~~~
vd file.xlsx --header=0
~~~

2. For each sheet, press `s` or `t` to select the rows which represent the header rows.
3. Press `g^` to set the names of the headers to the contents of selected rows.

###### How to rename columns using the Columns sheet

1. Press `Shift+C` to open the **Columns sheet**.
2. Within the **name** column, move the cursor to the row which represents the source sheet.
3. Type `e` and then input *the new column name*. Press `Enter`.
4. Press `q` to return to the source sheet and see the renamed column.

---
