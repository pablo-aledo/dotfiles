from visidata.main import vd_cli
from visidata import vd

vd_cli()
