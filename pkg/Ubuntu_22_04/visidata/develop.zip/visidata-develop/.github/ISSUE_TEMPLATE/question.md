---
name: Question
about: Ask a question you have about VisiData.
title: '[question]'
labels: question
assignees: ''

---

If you think your question would benefit from input from anyone in the community (e.g. 'How do I X in VisiData') consider [opening a Discussion instead](https://github.com/saulpw/visidata/discussions/new/choose).

If you think it would benefit from a more synchronised back-and-forth with Saul, consider joining us in libera.chat (#visidata) or [discord](https://bluebird.sh/chat).

