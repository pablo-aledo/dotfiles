## Puzzle 2

With your help, Sarah was able to call the private investigator that afternoon, and brought them up to speed.  The investigator went to the cleaners directly to see if they could get any more information about the unclaimed rug.

While they were out, Sarah said, "I tried cleaning the rug myself, but there was this snail on it that always seemed to leave a trail of slime behind it.  I spent a few hours cleaning it, and the next day the slime trail was back."

When the investigator returned, they said, "Apparently, this cleaner had a special projects program, where they outsourced challenging cleaning projects to industrious contractors.  As they're right across the street from Noah's, they usually talked about the project over coffee and bagels at Noah's before handing off the item to be cleaned.  The contractors would pick up the tab and expense it, along with their cleaning supplies.

"So this rug was apparently one of those special projects.  The claim ticket said '2017 spec {cleanerinits}'.  '2017' is the year the item was brought in, and '{cleanerinits}' is the initials of the contractor.

"But they stopped outsourcing a few years ago, and don't have contact information for any of these workers anymore."

Sarah first seemed hopeless, and then looked at the [:onclick open-noahs-database]USB drive[/] you had just put back in her hand.  She said, "I know it's a long shot, but is there any chance you could find their phone number?"
