## Puzzle 1

Sarah brought over one of the cashiers.  She said, "Joe here says that one of our customers is a skilled private investigator."

Joe nodded, "They came in awhile ago and showed me their business card, and that's what it said. Skilled Private Investigator. And their phone number was their last name spelled out.  I didn't know what that meant, but apparently before there were smartphones, people had to remember phone numbers or write them down.  If you wanted a phone number that was easy-to-remember, you could get a number that spelled something using the letters printed on the phone buttons: like 2 has "ABC", and 3 "DEF", etc.  And I guess this person had done that, so if you dialed the numbers corresponding to the letters in their name, it would call their phone number!

"I thought that was pretty cool.  But I don't remember their name, or anything else about them for that matter.  I couldn't even tell you if they were male or female."

Sarah said, "This person seems like they are clever and skilled at investigation.  I'd like to hire them to help me find Noah's rug before the Hanukkah dinner.  I don't know how to contact them, but apparently they shop here at Noah's Market."

She nodded at the [:onclick open-noahs-database]USB drive[/] in your hand.

"Can you find this private investigator's phone number?"
