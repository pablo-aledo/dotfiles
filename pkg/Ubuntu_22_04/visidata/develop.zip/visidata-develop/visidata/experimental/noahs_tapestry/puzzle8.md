## Puzzle 8

"Oh that damned woman!  She moved in, clogged my bathtub, spilled oatmeal all over the kitchen, and then just vanished one night without leaving so much as a note.  Well except she did leave behind that tapestry.  We spent much of our time together cleaning one filthy area, only to reveal a snake hiding in the branches!

"I left it on my wall hoping she would come back for it, but eventually I accepted that I had to move on.

"I don't have any storage here, and it didn't seem right to sell it, so I gave it to my sister {clue8a}.  She wound up getting a newer and more expensive rug, so she gave it to an acquaintance of hers who collects all sorts of junk.  Apparently he owns an entire set of Noah's collectibles!  He probably still has the rug, even.

"My sister is away for the holidays, but I can have her call you in a few weeks."

The family dinner is tonight!  Can you find the collector's phone number in time?
