## Puzzle 6

"Why yes, I did have that rug for a little while in my living room!  My cats can't see a thing but they sure chased after the squirrel on it like it was dancing in front of their noses.

"It was a nice rug and they were surely going to ruin it, so I gave it to my cousin, who was moving into a new place that had wood floors.

"She refused to buy a new rug for herself--she said they were way too expensive.  She's always been very frugal, and she clips every coupon and shops every sale at Noah's Market.  In fact I like to tease her that Noah actually loses money whenever she comes in the store.

"I think she's been taking it too far lately though.  Once the subway fare increased, she stopped coming to visit me.  And she's really slow to respond to my texts.  I hope she remembers to invite me to the family reunion next year."

Can you find her cousin's phone number?
