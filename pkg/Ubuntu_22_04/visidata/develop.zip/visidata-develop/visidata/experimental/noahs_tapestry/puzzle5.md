## Puzzle 5

"Yes, I did have that tapestry for a little bit.  I even cleaned a blotchy section that turned out to be a friendly koala.

"But it was still really dirty, so when I was going through a Marie Kondo phase, I decided it wasn't sparking joy anymore.

"I listed it on Freecycle, and a woman {clue5a} came to pick it up.  She was wearing a 'Noah's Market' sweatshirt, and it was just covered in cat hair.  When I suggested that a clowder of cats might ruin such a fine tapestry, she looked at me funny.  She said "I only have ten or eleven cats, and anyway they are getting quite old now, so I doubt they'd care about some old rug."

"It took her 20 minutes to stuff the tapestry into some plastic bags she brought because it was raining.  I spent the evening cleaning my apartment."

What's the phone number of the woman from Freecycle?
