## Puzzle 7

"Oh that tapestry, with the colorful toucan on it!  I'll tell you what happened to it.

"One day, I was at Noah's Market, and I was just about to leave when someone behind me said 'Miss!  You dropped something!'

"Well I turned around and sure enough this cute guy was holding something I had bought.  He said 'I got almost exactly the same thing!' We laughed about it and wound up swapping items because he had wanted the color I got.  We had a moment when our eyes met and my heart stopped for a second.  I asked him to get some food with me and we spent the rest of the day together.

"Before long I moved into his place.  It didn't last long though, as I soon discovered this man was not the gentleman I thought he was.  I moved out only a few months later, late at night and in quite a hurry.

"I realized the next day that I'd left that tapestry hanging on his wall.  But the tapestry had come to represent our relationship, and I wanted nothing more to do with him, so I let it go.  For all I know, he still has it."

Can you figure out her ex-boyfriend's phone number?
