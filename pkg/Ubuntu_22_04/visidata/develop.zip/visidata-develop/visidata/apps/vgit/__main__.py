from .main import vgit_cli

vgit_cli()
