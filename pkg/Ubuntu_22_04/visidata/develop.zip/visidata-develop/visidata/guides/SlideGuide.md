# The Slide Guide

The key bindings are based on the vi movement keys (hjkl).

## How to move columns

- {help.commands.slide_left}
- {help.commands.slide_right}

- {help.commands.slide_leftmost}
- {help.commands.slide_rightmost}

- {help.commands.slide_left_n}
- {help.commands.slide_right_n}

## How to move rows

- {help.commands.slide_down}
- {help.commands.slide_up}

- {help.commands.slide_bottom}
- {help.commands.slide_top}

- {help.commands.slide_down_n}
- {help.commands.slide_up_n}

