#!/usr/bin/sh
clang2py msm_kgsl.h -o msm_kgsl.py