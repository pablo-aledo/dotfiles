#!/bin/bash
codesign --force --entitlements entitlements.xml -s "Taylor Swift Child" /opt/homebrew/Cellar/python@3.9/3.9.1_1/Frameworks/Python.framework/Versions/3.9/Resources/Python.app/Contents/MacOS/Python

