package subfolder3

// SubfolderInterface for testing purposes
type SubfolderInterface interface {
	SubfolderFunction(bool, int) bool
}
