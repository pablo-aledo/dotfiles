package renderingoptions

// Test is for testing purposes
type Test struct {
	integer int
}

func (t *Test) function() {

}
