package parenthesizedtypedeclarations

type (
	//Foo is a test interface for testing purposes
	Foo interface {
		Foo()
	}
	//Bar is a test interface for testing purposes
	Bar interface {
		Bar()
	}
)
