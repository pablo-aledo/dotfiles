package subfolder

type test2 interface {
	TestInterfaceAsField
	test()
}

// TestInterfaceAsField testing interface
type TestInterfaceAsField interface {
}
