<style global>
  @tailwind base;
  @tailwind components;
  @tailwind utilities;
</style>
