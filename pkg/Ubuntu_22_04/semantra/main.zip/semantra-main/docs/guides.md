# Guides

The following how-to guides show how to accomplish specific tasks with Semantra:

- [Using other models with Semantra](guide_models.md)
- [Using OpenAI with Semantra](guide_openai.md)
