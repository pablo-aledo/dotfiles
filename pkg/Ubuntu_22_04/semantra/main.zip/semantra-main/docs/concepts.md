# Concepts

Below are some explainers that clarify how Semantra works.

- [Embeddings](concept_embeddings.md)
- [Windows](concept_windows.md)
