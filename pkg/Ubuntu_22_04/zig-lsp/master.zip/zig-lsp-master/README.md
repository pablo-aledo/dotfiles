# zig-lsp
A simple unofficial language server for the zig programming language.
