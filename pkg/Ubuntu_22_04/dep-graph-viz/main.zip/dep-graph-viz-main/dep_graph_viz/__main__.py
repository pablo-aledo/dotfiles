from dep_graph_viz import main

if __name__ == "__main__":
	import fire
	fire.Fire(main)