TrueVision TGA (a.k.a. Targa) 2.0 conformance suite

Official format specification, sample images and utilitiesriginally been publicly
available, free of charge and under no specific licensing terms, from TrueVision,
Inc.'s  FTP server at the following URL:

ftp://ftp.truevision.com/pub/TGA.File.Format.Spec/PC.Version/

All of the material contained here is therefore copyright to TrueVision, Inc.,
unless otherwise stated.

But has been removed in the proceedings of Pinnacle Systems' acquisition of
TrueVision, Inc., as outdated. However, a back-up of these files is available
here:

https://web.archive.org/web/20111012172805/http://googlesites.inequation.org/tgautilities
