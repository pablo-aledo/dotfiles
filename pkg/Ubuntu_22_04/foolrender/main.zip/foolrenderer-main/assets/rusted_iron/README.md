# Rusted Iron PBR Metal Material Alt

## Description

Upstream: https://freepbr.com/materials/rusted-iron-pbr-metal-material-alt/

The original texture is encoded in PNG format. The current texture has been converted to TGA format.

## License Information

Brian is the author of these assets for the purpose of copyright. All rights reserved.
Licensed under the [About page](https://freepbr.com/about-free-pbr/) of the asset publishing site freepbr.com.
