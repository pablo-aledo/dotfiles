# Cut Fish

## Description

Upstream: https://sketchfab.com/3d-models/cut-fish-c9bcb782e5ef4d37bd8671f1f82a0fbc

This model has been imported and re-exported from Blender to adjust the position and convert all faces to triangles. The textures has been converted to TGA format.

## License Information

[![CC BY-NC](https://i.creativecommons.org/l/by-nc/4.0/88x31.png)](https://creativecommons.org/licenses/by-nc/4.0/)

[Suushimi](https://sketchfab.com/Suushimi) is the author of these assets for the purpose of copyright. All rights reserved.
Licensed under the [Creative Commons Attribution-NonCommercial 4.0 International License](https://creativecommons.org/licenses/by-nc/4.0/).
