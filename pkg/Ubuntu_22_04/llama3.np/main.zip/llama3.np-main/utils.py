import numpy as np


def load_parameters(model_path):
    return np.load(model_path)
