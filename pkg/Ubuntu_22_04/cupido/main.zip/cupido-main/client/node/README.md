# Node client for cupido

## npm

https://www.npmjs.com/package/cupido-client

## api documentation

[src/index.ts](src/index.ts)
