#!/bin/sh

echo "What's your favorite shell?"

gum choose "Posix" "Bash" "Zsh" "Fish" "Elvish"
