Background
==========


The pages below provide background information on scientific approaches to web data collection and processing, corpus linguistics, digital humanities, and natural language processing.


.. toctree::
    :maxdepth: 2

    compendium
    sources
    corpus-data

