pub mod config;
pub mod external;
pub mod vscode;

pub use config::{Snippet, SnippetsConfig};
