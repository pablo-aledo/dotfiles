//! Shared client for sem-cloud.
//!
//! This crate is the single source of truth for talking to the sem-cloud API:
//! credentials, repo resolution + caching, routing eligibility, and the metered
//! graph endpoints (impact / context / entities / history). Both the `sem` CLI
//! and the `sem-mcp` server depend on it so an authenticated agent session and
//! an authenticated CLI session route to the cloud identically.
//!
//! Presentation (colored terminal output, MCP JSON envelopes, the login flow)
//! lives in each frontend, not here.

use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use std::time::Duration;

use serde::{Deserialize, Serialize};

pub const DEFAULT_ENDPOINT: &str = "https://sem-cloud.fly.dev";
const API_TIMEOUT_SECS: u64 = 10;
const REPO_CACHE_TTL_SECS: i64 = 86400; // 24 hours

// ─── Credentials ──────────────────────────────────────────────────────────

#[derive(Serialize, Deserialize, Clone)]
pub struct CloudCredentials {
    pub api_key: String,
    #[serde(default = "default_endpoint")]
    pub endpoint: String,
}

pub fn default_endpoint() -> String {
    DEFAULT_ENDPOINT.into()
}

pub fn credentials_path() -> Option<PathBuf> {
    let home = std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()?;
    Some(PathBuf::from(home).join(".sem").join("credentials.json"))
}

pub fn save_credentials(creds: &CloudCredentials) -> Result<PathBuf, Box<dyn std::error::Error>> {
    let path = credentials_path().ok_or("Could not determine home directory")?;
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let json = serde_json::to_string_pretty(creds)?;
    fs::write(&path, json)?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600))?;
    }

    Ok(path)
}

/// Load stored cloud credentials, if any.
pub fn load_credentials() -> Option<CloudCredentials> {
    let path = credentials_path()?;
    let content = fs::read_to_string(path).ok()?;
    serde_json::from_str(&content).ok()
}

// ─── Cloud API Response Types ────────────────────────────────────────────

// Response types: all fields are deserialized from JSON but not all are
// directly read by Rust code (some are passed through to output).
#[allow(dead_code)]
#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudEntityBrief {
    pub id: String,
    pub name: String,
    pub entity_type: String,
    pub file_path: String,
    #[serde(default)]
    pub start_line: Option<usize>,
    #[serde(default)]
    pub end_line: Option<usize>,
    #[serde(default)]
    pub parent_id: Option<String>,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudImpactResponse {
    pub dependencies: Vec<CloudEntityBrief>,
    pub dependents: Vec<CloudEntityBrief>,
    #[serde(default)]
    pub transitive_impact: Vec<CloudEntityBrief>,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudContextEntry {
    pub entity_id: String,
    pub name: String,
    pub entity_type: String,
    pub file_path: String,
    pub role: String,
    #[serde(default)]
    pub content: String,
    #[serde(default)]
    pub estimated_tokens: usize,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudContextResponse {
    pub tokens_used: usize,
    #[serde(default)]
    pub truncated: bool,
    pub entries: Vec<CloudContextEntry>,
}

#[allow(dead_code)]
#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudRepoResponse {
    pub id: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub clone_url: String,
    #[serde(default)]
    pub default_branch: String,
    #[serde(default)]
    pub status: String,
    #[serde(default)]
    pub entity_count: Option<usize>,
    #[serde(default)]
    pub file_count: Option<usize>,
}

/// One cross-repo dependency edge: an entity in one of your repos that depends
/// on an entity in another of your repos. Cloud-only (the local CLI sees one
/// repo at a time; only the cloud holds the graph across all your repos).
#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudCrossRepoEdge {
    pub from_repo_id: String,
    pub from_entity_id: String,
    pub to_repo_id: String,
    pub to_entity_id: String,
    #[serde(default)]
    pub ref_type: String,
}

/// One repo on the account, as reported by `GET /v1/repos`. This is the
/// authoritative server-side view; `~/.sem/repos.json` is only this machine's
/// best-effort mirror of it.
#[derive(Deserialize, Debug, Clone)]
#[serde(rename_all = "camelCase")]
pub struct CloudRepoInfo {
    pub id: String,
    pub name: String,
    pub clone_url: String,
    #[serde(default)]
    pub default_branch: Option<String>,
    pub status: String,
    #[serde(default)]
    pub entity_count: Option<u64>,
    #[serde(default)]
    pub file_count: Option<u64>,
    #[serde(default)]
    pub last_commit_sha: Option<String>,
    #[serde(default)]
    pub last_indexed_at: Option<String>,
    #[serde(default)]
    pub error_message: Option<String>,
    #[serde(default)]
    pub created_at: Option<String>,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudCrossDepsResponse {
    pub edges: Vec<CloudCrossRepoEdge>,
    #[serde(default)]
    pub total: usize,
    #[serde(default)]
    pub query_ms: u64,
}

#[allow(dead_code)]
#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudEntitiesResponse {
    pub entities: Vec<CloudEntityBrief>,
    #[serde(default)]
    pub total: usize,
}

#[allow(dead_code)]
#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudHistoryEntry {
    #[serde(default)]
    pub entity_id: String,
    pub entity_name: String,
    #[serde(default)]
    pub entity_type: String,
    #[serde(default)]
    pub file_path: String,
    pub change_type: String,
    pub commit_sha: String,
    #[serde(default)]
    pub commit_author: Option<String>,
    #[serde(default)]
    pub commit_message: Option<String>,
    #[serde(default)]
    pub created_at: String,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct CloudHistoryResponse {
    pub changes: Vec<CloudHistoryEntry>,
}

// ─── Repo Cache ──────────────────────────────────────────────────────────

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct RepoCacheEntry {
    pub repo_id: String,
    pub status: String,
    pub checked_at: String,
    #[serde(default)]
    pub entity_count: Option<usize>,
}

/// Below this entity count, the local SQLite cache answers graph queries
/// faster than a network round trip — stay local. (Measured: 4.6k entities
/// load in ~18ms locally vs ~90ms+ for one HTTPS request; 147k entities
/// take ~500ms locally vs ~115-190ms via cloud.)
const CLOUD_MIN_ENTITIES: usize = 20_000;

/// Look up the cached entity count for a remote, if known.
/// Only trusts counts from fully indexed repos within the cache TTL — a
/// repo registered while still indexing reports 0 entities, and treating
/// that as "small" would permanently route it away from the cloud.
fn cached_entity_count(remote_url: &str) -> Option<usize> {
    let normalized = normalize_remote_url(remote_url);
    let cache = load_repo_cache()?;
    let entry = cache.get(&normalized)?;
    if entry.status != "ready" || cache_entry_expired(entry) {
        return None;
    }
    entry.entity_count
}

/// True when the repo is known to be small enough that local graph queries
/// beat the network. Unknown size → not provably small → try cloud.
pub fn known_small_repo(remote_url: &str) -> bool {
    cached_entity_count(remote_url).is_some_and(|n| n < CLOUD_MIN_ENTITIES)
}

fn repo_cache_path() -> Option<PathBuf> {
    let home = std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()?;
    Some(PathBuf::from(home).join(".sem").join("repos.json"))
}

/// Overwrite this machine's repo-cache entries with the authoritative
/// server-side state. Fixes stale entries (a repo registered while still
/// indexing stays "pending, 0 entities" here forever unless refreshed, and
/// that stale count mis-routes the local-vs-cloud decision). Best-effort.
pub fn reconcile_repo_cache(repos: &[CloudRepoInfo]) {
    let mut cache = load_repo_cache().unwrap_or_default();
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs().to_string())
        .unwrap_or_default();
    for repo in repos {
        cache.insert(
            normalize_remote_url(&repo.clone_url),
            RepoCacheEntry {
                repo_id: repo.id.clone(),
                status: repo.status.clone(),
                checked_at: now.clone(),
                entity_count: repo.entity_count.map(|n| n as usize),
            },
        );
    }
    save_repo_cache(&cache);
}

pub fn load_repo_cache() -> Option<HashMap<String, RepoCacheEntry>> {
    let path = repo_cache_path()?;
    let content = fs::read_to_string(path).ok()?;
    serde_json::from_str(&content).ok()
}

fn save_repo_cache(cache: &HashMap<String, RepoCacheEntry>) {
    let Some(path) = repo_cache_path() else {
        return;
    };
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let _ = fs::write(
        path,
        serde_json::to_string_pretty(cache).unwrap_or_default(),
    );
}

fn current_timestamp() -> String {
    // Simple ISO 8601 timestamp without external deps
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    format!("{secs}")
}

fn cache_entry_expired(entry: &RepoCacheEntry) -> bool {
    let checked: i64 = entry.checked_at.parse().unwrap_or(0);
    let now: i64 = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64;
    now - checked > REPO_CACHE_TTL_SECS
}

// ─── URL Normalization ───────────────────────────────────────────────────

/// Normalize a git remote URL for matching against cloud repos.
/// Strips trailing `.git`, converts SSH `git@host:user/repo` to `https://host/user/repo`.
pub fn normalize_remote_url(url: &str) -> String {
    let mut normalized = url.to_string();

    // SSH → HTTPS: git@github.com:user/repo → https://github.com/user/repo
    if normalized.starts_with("git@") {
        if let Some(rest) = normalized.strip_prefix("git@") {
            normalized = rest.replacen(':', "/", 1);
            normalized = format!("https://{normalized}");
        }
    }

    // ssh://git@github.com/user/repo → https://github.com/user/repo
    if normalized.starts_with("ssh://git@") {
        normalized = normalized.replacen("ssh://git@", "https://", 1);
    }

    // Strip trailing .git
    if normalized.ends_with(".git") {
        normalized.truncate(normalized.len() - 4);
    }

    // Strip trailing slash
    if normalized.ends_with('/') {
        normalized.truncate(normalized.len() - 1);
    }

    normalized
}

/// True when the user has explicitly opted in to syncing private repos to the
/// cloud (set `SEM_SYNC_PRIVATE=1`). Off by default so private code is never
/// uploaded without consent.
fn private_sync_opted_in() -> bool {
    std::env::var("SEM_SYNC_PRIVATE").is_ok_and(|v| !v.is_empty() && v != "0")
}

/// Parse the GitHub `owner`/`repo` from a remote URL, if it is a github.com
/// remote. Returns `None` for non-GitHub or unparseable remotes.
fn github_owner_repo(remote_url: &str) -> Option<(String, String)> {
    let normalized = normalize_remote_url(remote_url);
    let rest = normalized.split("github.com/").nth(1)?;
    let mut parts = rest.split('/').filter(|s| !s.is_empty());
    let owner = parts.next()?;
    let repo = parts.next()?;
    Some((owner.to_string(), repo.to_string()))
}

// ─── CloudClient ─────────────────────────────────────────────────────────

pub struct CloudClient {
    creds: CloudCredentials,
    agent: ureq::Agent,
}

/// Returns true if the user has set SEM_LOCAL=1 to force local computation.
pub fn is_local_forced() -> bool {
    std::env::var("SEM_LOCAL").ok().is_some_and(|v| v == "1")
}

impl CloudClient {
    /// Create a CloudClient from stored credentials.
    /// Returns None if not logged in, or if SEM_LOCAL=1 is set.
    pub fn from_credentials() -> Option<Self> {
        if is_local_forced() {
            return None;
        }
        let creds = load_credentials()?;
        let agent = ureq::AgentBuilder::new()
            .timeout(Duration::from_secs(API_TIMEOUT_SECS))
            .build();
        Some(Self { creds, agent })
    }

    fn api_url(&self, path: &str) -> String {
        format!("{}{}", self.creds.endpoint, path)
    }

    fn auth_header(&self) -> String {
        format!("Bearer {}", self.creds.api_key)
    }

    // ── Repo resolution ──

    /// Look up a repo by its remote URL. Returns the repo_id.
    fn resolve_repo(&self, remote_url: &str) -> Result<String, Box<dyn std::error::Error>> {
        let normalized = normalize_remote_url(remote_url);

        // Check cache first. Entries that aren't "ready" yet (still cloning
        // or indexing) are re-fetched every time so status and entity count
        // converge once the server finishes.
        if let Some(cache) = load_repo_cache() {
            if let Some(entry) = cache.get(&normalized) {
                if entry.status == "ready" && !cache_entry_expired(entry) {
                    return Ok(entry.repo_id.clone());
                }
            }
        }

        // Call API: GET /v1/repos
        let resp: Vec<CloudRepoResponse> = self
            .agent
            .get(&self.api_url("/v1/repos"))
            .set("Authorization", &self.auth_header())
            .call()?
            .into_json()?;

        for repo in &resp {
            let repo_normalized = normalize_remote_url(&repo.clone_url);
            if repo_normalized == normalized {
                // Cache it
                let mut cache = load_repo_cache().unwrap_or_default();
                cache.insert(
                    normalized,
                    RepoCacheEntry {
                        repo_id: repo.id.clone(),
                        status: repo.status.clone(),
                        checked_at: current_timestamp(),
                        entity_count: repo.entity_count,
                    },
                );
                save_repo_cache(&cache);
                return Ok(repo.id.clone());
            }
        }

        Err("repo not found".into())
    }

    /// Register a new repo with the cloud. Returns the repo response.
    fn register_repo(
        &self,
        remote_url: &str,
    ) -> Result<CloudRepoResponse, Box<dyn std::error::Error>> {
        let resp: CloudRepoResponse = self
            .agent
            .post(&self.api_url("/v1/repos"))
            .set("Authorization", &self.auth_header())
            .send_json(serde_json::json!({ "cloneUrl": remote_url }))?
            .into_json()?;
        Ok(resp)
    }

    /// Best-effort check that a repo is public, via the unauthenticated GitHub
    /// API. Returns true only when GitHub confirms `private: false`; private,
    /// missing, non-GitHub, or unreachable repos all return false, so we never
    /// auto-sync a private codebase to the cloud.
    fn repo_is_public(&self, remote_url: &str) -> bool {
        let Some((owner, repo)) = github_owner_repo(remote_url) else {
            return false;
        };
        match self
            .agent
            .get(&format!("https://api.github.com/repos/{owner}/{repo}"))
            .set("User-Agent", "sem-cli")
            .set("Accept", "application/vnd.github+json")
            .call()
        {
            Ok(resp) => resp
                .into_json::<serde_json::Value>()
                .ok()
                .and_then(|v| v.get("private").and_then(|p| p.as_bool()))
                .map(|private| !private)
                .unwrap_or(false),
            Err(_) => false,
        }
    }

    /// Resolve repo, or register if not found. Returns repo_id only if status is "ready".
    pub fn ensure_repo(&self, remote_url: &str) -> Result<String, Box<dyn std::error::Error>> {
        match self.resolve_repo(remote_url) {
            Ok(id) => Ok(id),
            Err(_) => {
                // Privacy default: only auto-register repos GitHub confirms are
                // public. A private repo is synced to the cloud only when the
                // user opts in via SEM_SYNC_PRIVATE, so private code is never
                // uploaded silently. Already-registered repos resolve above and
                // skip this check.
                if !private_sync_opted_in() && !self.repo_is_public(remote_url) {
                    return Err("private repo not synced (set SEM_SYNC_PRIVATE=1 to opt in)".into());
                }
                let repo = self.register_repo(remote_url)?;
                let normalized = normalize_remote_url(remote_url);
                let mut cache = load_repo_cache().unwrap_or_default();
                cache.insert(
                    normalized,
                    RepoCacheEntry {
                        repo_id: repo.id.clone(),
                        status: repo.status.clone(),
                        checked_at: current_timestamp(),
                        entity_count: repo.entity_count,
                    },
                );
                save_repo_cache(&cache);

                if repo.status == "ready" {
                    Ok(repo.id)
                } else {
                    Err(format!("repo status is '{}', not ready yet", repo.status).into())
                }
            }
        }
    }

    // ── Per-command API methods ──

    pub fn impact(
        &self,
        repo_id: &str,
        entity: &str,
        file: &str,
    ) -> Result<CloudImpactResponse, Box<dyn std::error::Error>> {
        let resp = self
            .agent
            .post(&self.api_url(&format!("/v1/repos/{repo_id}/impact")))
            .set("Authorization", &self.auth_header())
            .send_json(serde_json::json!({
                "targetEntity": entity,
                "targetFile": file,
            }))?
            .into_json()?;
        Ok(resp)
    }

    pub fn context(
        &self,
        repo_id: &str,
        entity: &str,
        file: &str,
        budget: usize,
    ) -> Result<CloudContextResponse, Box<dyn std::error::Error>> {
        let resp = self
            .agent
            .post(&self.api_url(&format!("/v1/repos/{repo_id}/context")))
            .set("Authorization", &self.auth_header())
            .send_json(serde_json::json!({
                "targetEntity": entity,
                "targetFile": file,
                "tokenBudget": budget,
            }))?
            .into_json()?;
        Ok(resp)
    }

    pub fn entities(
        &self,
        repo_id: &str,
        file_path_filter: Option<&str>,
    ) -> Result<CloudEntitiesResponse, Box<dyn std::error::Error>> {
        // Server default limit is 100; request everything for whole-repo
        // listings, brief (no content) to keep the payload small.
        let mut url = format!("/v1/repos/{repo_id}/entities?limit=1000000&brief=true");
        if let Some(fp) = file_path_filter {
            url.push_str(&format!("&filePath={}", urlencoding_encode(fp)));
        }
        let resp: CloudEntitiesResponse = self
            .agent
            .get(&self.api_url(&url))
            .set("Authorization", &self.auth_header())
            .call()?
            .into_json()?;
        Ok(resp)
    }

    pub fn history(
        &self,
        repo_id: &str,
        file: Option<&str>,
        limit: usize,
    ) -> Result<CloudHistoryResponse, Box<dyn std::error::Error>> {
        // Server filters by entityId/filePath only; entity-name filtering
        // happens client-side. days=3650 ≈ full history.
        let mut url = format!("/v1/repos/{repo_id}/analytics/history?days=3650");
        if let Some(f) = file {
            url.push_str(&format!("&filePath={}", urlencoding_encode(f)));
        }
        if limit > 0 {
            url.push_str(&format!("&limit={limit}"));
        }
        let resp = self
            .agent
            .get(&self.api_url(&url))
            .set("Authorization", &self.auth_header())
            .call()?
            .into_json()?;
        Ok(resp)
    }

    /// List every repo indexed on the account (`GET /v1/repos`) — the
    /// authoritative server-side inventory: status, entity/file counts,
    /// indexed commit, and any indexing error.
    pub fn list_repos(&self) -> Result<Vec<CloudRepoInfo>, Box<dyn std::error::Error>> {
        let resp: Vec<CloudRepoInfo> = self
            .agent
            .get(&self.api_url("/v1/repos"))
            .set("Authorization", &self.auth_header())
            .call()?
            .into_json()?;
        Ok(resp)
    }

    /// Cross-repo dependency edges across all of your indexed repos. This is
    /// cloud-only: it answers "what in my other repos depends on this," which a
    /// single-repo local graph can't see.
    pub fn cross_deps(&self) -> Result<CloudCrossDepsResponse, Box<dyn std::error::Error>> {
        let resp: CloudCrossDepsResponse = self
            .agent
            .get(&self.api_url("/v1/cross-deps"))
            .set("Authorization", &self.auth_header())
            .call()?
            .into_json()?;
        Ok(resp)
    }
}

/// Minimal percent-encoding for query parameters (no external dep).
fn urlencoding_encode(s: &str) -> String {
    let mut result = String::with_capacity(s.len());
    for byte in s.bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                result.push(byte as char);
            }
            _ => {
                result.push_str(&format!("%{:02X}", byte));
            }
        }
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn github_owner_repo_parses_remote_forms() {
        for url in [
            "https://github.com/Ataraxy-Labs/sem",
            "https://github.com/Ataraxy-Labs/sem.git",
            "git@github.com:Ataraxy-Labs/sem.git",
            "ssh://git@github.com/Ataraxy-Labs/sem",
        ] {
            assert_eq!(
                github_owner_repo(url),
                Some(("Ataraxy-Labs".to_string(), "sem".to_string())),
                "failed for {url}"
            );
        }
        // Non-GitHub or unparseable remotes are not auto-synced.
        assert_eq!(github_owner_repo("https://gitlab.com/a/b"), None);
        assert_eq!(github_owner_repo("not a url"), None);
    }

    #[test]
    fn normalize_remote_url_canonicalizes_forms() {
        assert_eq!(
            normalize_remote_url("git@github.com:user/repo.git"),
            "https://github.com/user/repo"
        );
        assert_eq!(
            normalize_remote_url("https://github.com/user/repo/"),
            "https://github.com/user/repo"
        );
    }
}
