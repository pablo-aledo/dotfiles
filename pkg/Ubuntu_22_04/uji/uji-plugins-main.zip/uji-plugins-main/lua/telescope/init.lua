
local M = {}

local configured_editor = nil

local function editor()
  return configured_editor
    or os.getenv("UJI_EDITOR")
    or os.getenv("VISUAL")
    or os.getenv("EDITOR")
end

local function quoted(path)
  if uji.os.platform == "windows" then
    return '"' .. path .. '"'
  end
  return "'" .. (path:gsub("'", "'\\''")) .. "'"
end

function M.open(path)
  local cmd = editor()
  if not cmd or cmd == "" then
    uji.notify("no editor: set $EDITOR, or pass editor = \"nvim\" to telescope.setup")
    return
  end
  uji.ui.exec(cmd .. " " .. quoted(path))
end

local LISTERS = {
  { "rg", "--files", "--hidden", "--glob", "!.git", "." },
  { "git", "ls-files", "--cached", "--others", "--exclude-standard" },
  { "find", ".", "-type", "f", "-not", "-path", "*/.git/*", unix = true },
}

local function searched(pattern)
  return { "rg", "--line-number", "--no-heading", "--smart-case", "-e", pattern, "." }
end

local function collect(cmd, limit, on_done)
  local lines, job = {}, nil
  job = uji.job.start({
    cmd = cmd,
    on_stdout = function(line)
      if limit and #lines >= limit then return end
      lines[#lines + 1] = (line:gsub("^%.[/\\]", ""))
      if limit and #lines >= limit then job.stop() end
    end,
    on_exit = function(code) on_done(lines, code) end,
  })
  job.close()
end

local function listed(index, on_done)
  local cmd = LISTERS[index]
  if not cmd then
    on_done({})
  elseif cmd.unix and uji.os.platform == "windows" then
    listed(index + 1, on_done)
  else
    collect(cmd, nil, function(files, code)
      if #files == 0 and code ~= 0 then
        listed(index + 1, on_done)
      else
        on_done(files)
      end
    end)
  end
end

function M.files(on_done)
  listed(1, on_done)
end

local function pick(title, items, on_choice, preview)
  if #items == 0 then
    uji.notify("nothing to pick")
    return
  end
  uji.ui.pick({ title = title, items = items, preview = preview }, function(choice)
    if choice then on_choice(choice) end
  end)
end

-- Live search: each settled keystroke re-runs ripgrep. `show` is tied to the
-- query that asked for it, so a slow search cannot overwrite a newer one.
local function live_grep()
  uji.ui.pick({
    title = "Search",
    on_query = function(query, show)
      if query == "" then
        show({})
        return
      end
      collect(searched(query), 200, show)
    end,
  }, function(choice)
    if choice then M.open(choice:match("^([^:]+):") or choice) end
  end)
end

local function find()
  M.files(function(files) pick("Open file", files, M.open) end)
end

-- Search the whole transcript, not only what you typed: the thing you are
-- looking for is often in a tool result or a reply.
local function history()
  local items, full = {}, {}
  for _, message in ipairs(uji.session.messages()) do
    local text = (message.text or ""):gsub("%s+", " ")
    if text ~= "" then
      local label = message.type .. ": " .. text
      items[#items + 1] = label
      full[label] = message.text
    end
  end
  pick("Session history", items, function(label)
    uji.input.set(full[label] or label)
  end, function(label)
    local body = full[label] or label
    local lines = {}
    for line in body:gmatch("[^\n]+") do lines[#lines + 1] = line end
    return lines
  end)
end

function M.setup(opts)
  opts = opts or {}
  configured_editor = opts.editor

  uji.action.add("telescope_find", find)
  uji.action.add("telescope_history", history)
  uji.action.add("telescope_search", live_grep)

  if opts.keys ~= false then
    uji.keymap.add("normal", "<C-p>", "telescope_find")
    uji.keymap.add("normal", "<C-r>", "telescope_history")
    uji.keymap.add("normal", "<C-f>", "telescope_search")
  end
end

return M
