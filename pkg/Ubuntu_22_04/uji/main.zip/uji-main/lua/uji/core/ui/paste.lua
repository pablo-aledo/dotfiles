local class = require("uji.core.class")
local list = require("uji.utils.list")
local text = require("ito").text

local Pastes = class()

function Pastes:init(theme)
    self.theme = theme
    self:clear()
end

function Pastes:clear()
    self.entries = {}
    self.counter = 0
    self.pasted = 0
    self.attached = 0
end

function Pastes:add(entry)
    self.counter = self.counter + 1
    entry.id = self.counter
    self.entries[#self.entries + 1] = entry
    return entry.marker
end

function Pastes:stash(value)
    local tokens = self.theme.tokens
    local limits, words = tokens.limits, tokens.text
    local lines = #text.lines(value)
    local chars = text.length(value)
    if lines <= limits.paste_lines and chars <= limits.paste_chars then
        return value
    end
    self.pasted = self.pasted + 1
    local marker
    if lines > limits.paste_lines then
        marker = string.format(words.pasted_lines, self.pasted, lines)
    else
        marker = string.format(words.pasted_chars, self.pasted, chars)
    end
    return self:add({ marker = marker, content = value })
end

function Pastes:attach(image)
    self.attached = self.attached + 1
    local marker = string.format(self.theme.tokens.text.image, self.attached)
    return self:add({ marker = marker, image = image })
end

function Pastes:images(value)
    local found = {}
    for _, entry in ipairs(self.entries) do
        if entry.image and value:find(entry.marker, 1, true) then
            found[#found + 1] = entry.image
        end
    end
    return found
end

function Pastes:expand(value)
    for _, entry in ipairs(self.entries) do
        if entry.content then
            local from, to = value:find(entry.marker, 1, true)
            while from do
                value = value:sub(1, from - 1) .. entry.content .. value:sub(to + 1)
                from, to = value:find(entry.marker, from + #entry.content, true)
            end
        end
    end
    return value
end

function Pastes:marker_ending_at(value)
    for _, entry in ipairs(self.entries) do
        if value:sub(-#entry.marker) == entry.marker then
            return entry.id, #entry.marker
        end
    end
end

function Pastes:forget(id)
    for index, entry in ipairs(self.entries) do
        if entry.id == id then
            table.remove(self.entries, index)
            return
        end
    end
end

function Pastes:prune(value)
    self.entries = list.filtered(self.entries, function(entry)
        return value:find(entry.marker, 1, true) ~= nil
    end)
end

Pastes.clean = function(value)
    value = value:gsub("\r\n", "\n"):gsub("\r", "\n"):gsub("\t", "    ")
    return (value:gsub("%c", function(char)
        if char == "\n" then
            return char
        end
        return ""
    end))
end

Pastes.single_line = function(value)
    return (text.trim(Pastes.clean(value)):gsub("\n", " "))
end

return Pastes
