local class = require("uji.core.class")
local compactor = require("uji.core.agent.compactor")
local context = require("uji.core.context")
local event = require("uji.core.event")
local Files = require("uji.core.system.files")
local images = require("uji.core.images")
local ito = require("ito")
local list = require("uji.utils.list")
local model = require("uji.core.model")
local notices = require("uji.core.notices")
local process = require("uji.core.system.process")
local sys = require("uji.sys")
local task = require("uji.core.task")
local title = require("uji.core.agent.title")
local tool = require("uji.core.tool")
local view = require("uji.core.agent.view")

local APPROVAL_TIMEOUT = 300
local KEEP_CEILING_FRACTION = 4
local STOPPED = "error: uji stopped before this tool returned a result"
local WHILE_RUNNING = "error: interrupted by the user while this tool ran"
local BEFORE_RUNNING = "error: interrupted by the user before this tool ran"
local UNFINISHED = "the turn ended without an answer"

local function listing(arguments)
    local keys = {}
    for key in pairs(arguments) do
        keys[#keys + 1] = key
    end
    if #keys == 0 then
        return sys.json.encode(arguments)
    end
    table.sort(keys)
    local lines = {}
    for index, key in ipairs(keys) do
        local value = arguments[key]
        lines[index] = key .. ": " .. (type(value) == "string" and value or sys.json.encode(value))
    end
    return table.concat(lines, "\n")
end

local function decision_of(answer)
    if type(answer) ~= "table" then
        return nil
    end
    if type(answer.deny) == "string" then
        return { deny = answer.deny }
    end
    if answer.allow == true then
        return { allow = true }
    end
    if type(answer.ask) == "string" then
        return { ask = true, title = answer.ask }
    end
    if answer.ask == true then
        return { ask = true }
    end
end

local function loop_provider()
    local provider = model.current.provider
    return provider and provider.loop and provider or nil
end

local Agent = class()

function Agent:init(session)
    self.session = session
    self.ctx = { session = session }
    self.queue = {}
    self.state = "idle"
    self.compaction = nil
    self.confirm = function()
        return false
    end
    ito.observable(self)
end

function Agent:working()
    return self.state == "working"
end

function Agent:elapsed()
    return self.started and sys.os.clock() - self.started or nil
end

function Agent:compacting()
    return self.compaction ~= nil
end

function Agent:compaction_elapsed()
    return self.compaction and sys.os.clock() - self.compaction.started or nil
end

function Agent:compaction_started(count)
    self.compaction = { started = sys.os.clock(), messages = count }
    event.emit("status_changed", {})
    return self.compaction
end

function Agent:compaction_finished()
    self.compaction = nil
    event.emit("status_changed", {})
end

function Agent:begin()
    self.state = "working"
    self.started = sys.os.clock()
    event.emit("status_changed", {})
end

function Agent:finish(turn)
    self.state = "idle"
    self.started = nil
    self.task = nil
    self.turn = nil
    self.running = nil
    self.compaction = nil
    event.emit("tool_progress", {})
    event.emit("status_changed", {})
    if turn then
        event.emit("turn_finished", {})
    end
end

function Agent:append(message)
    local _, err = self.session:append(message)
    if err then
        notices.push(err)
    end
end

function Agent:clear_stream()
    event.emit("stream_cleared", {})
end

function Agent:delta(kind, text)
    event.emit("stream_delta", { kind = kind, text = text })
end

function Agent:sync_queue()
    event.emit("queue_changed", { count = #self.queue })
    event.emit("status_changed", {})
end

local function said(text, attached)
    return { type = "user", text = text, images = images.checked(attached) }
end

function Agent:enqueue(text, attached)
    self.queue = list.appended(self.queue, { text = text, images = attached })
    self:sync_queue()
end

function Agent:queued()
    return #self.queue > 0
end

function Agent:steer()
    local queued = self.queue[1]
    if not queued then
        return nil
    end
    self.queue = list.removed(self.queue, 1)
    self:clear_stream()
    local message = said(queued.text, queued.images)
    self:append(message)
    self:sync_queue()
    return message
end

function Agent:send_queued()
    local queued = self.queue[1]
    if queued then
        self.queue = list.removed(self.queue, 1)
        self:sync_queue()
        self:submit(queued.text, queued.images)
    end
end

function Agent:repair()
    for _, call in ipairs(self.session:unanswered_calls()) do
        self:answer(call, STOPPED)
    end
end

function Agent:prompt(text)
    local ok, base = pcall(function()
        return require("uji.core.prompt").system({ directory = self.session.directory, os = sys.os.platform })
    end)
    if not ok then
        notices.push("uji.core.prompt: " .. tostring(base))
        base = ""
    end
    local system, turn = context.gather(base or "")
    system = event.fold("before_turn", { text = text, system = system }, "system")
    return system, turn
end

function Agent:submit(text, attached)
    if self:working() then
        return self:enqueue(text, attached)
    end
    if self:compact_if_needed() then
        return self:enqueue(text, attached)
    end
    event.emit("message_submitted", { text = text })
    local sent = said(text, attached)
    self:append(sent)
    self:maybe_title(text)
    self:open(text, { text = text, images = sent.images })
end

function Agent:open(text, prompt)
    local system, turn = self:prompt(text)
    local gathered = {}
    for index, message in ipairs(turn) do
        self:append(message)
        gathered[index] = message.text
    end
    self:start(system, prompt or { text = table.concat(gathered, "\n\n") })
end

function Agent:wake()
    if not self:working() then
        self:open("")
    end
end

function Agent:start(system, prompt)
    local provider = loop_provider()
    local Loop = provider and provider.loop or require("uji.core.loop")
    local opts = {
        system = system,
        prompt = prompt,
        messages = view.build(self.session:entries()),
        tools = tool.specs(self.tools),
        model = model.current.model,
        effort = model.current.effort,
        reasoning = model.current.reasoning,
        max_output = model.max_output(),
        cache = model.retention(),
    }
    local turn = { calls = {}, answered = {} }
    self:begin()
    self.turn = turn
    self.task = task.spawn_in(self.ctx, function()
        local ok, err = pcall(function()
            turn.loop = Loop(self, opts)
            turn.loop:run()
        end)
        if self.turn == turn then
            self:failed("loop: " .. (ok and UNFINISHED or sys.message(err)))
        end
    end)
end

function Agent:failed(message)
    self:clear_stream()
    self:append({ type = "error", text = message })
    self:finish(true)
end

function Agent:restarted(attempt, of, wait, reason)
    self:clear_stream()
    notices.push(string.format("request failed (%s), retrying in %ds (%d/%d)", reason, math.max(wait, 1), attempt, of))
end

function Agent:compacted(spent, count)
    if spent then
        self.session:add_cost(spent)
    end
    notices.push("context filled up mid-turn; compacted to continue")
    event.emit("session_compacted", { count = count })
end

function Agent:usage(spent)
    self.session:add_usage(spent)
    event.emit("status_changed", {})
end

function Agent:assistant_step(message)
    self:clear_stream()
    self:append(message)
    if self.turn and #message.tool_calls > 0 then
        self.turn.calls = message.tool_calls
        self.turn.answered = {}
    end
end

function Agent:tool_running(call)
    if self.turn then
        self.turn.running = call
    end
end

local function outcome(value)
    if type(value) == "string" then
        return { text = value }
    end
    if type(value) ~= "table" or type(value.text) ~= "string" then
        return nil
    end
    local attached, problem = images.checked(value.images)
    return {
        text = problem and value.text .. "\n[" .. problem .. "]" or value.text,
        images = attached,
        diff = value.diff,
        summary = value.summary,
    }
end

function Agent:answer(call, value)
    local result = outcome(value) or { text = tostring(value) }
    self:append({
        type = "tool",
        tool_call_id = call.id,
        name = call.name,
        content = sys.lossy(result.text),
        images = result.images,
        diff = result.diff,
        summary = result.summary,
    })
end

function Agent:tool_result(call, value)
    event.emit("tool_progress", {})
    self:answer(call, value)
    if self.turn then
        self.turn.answered[call.id] = true
        self.turn.running = nil
        self.turn.cancel_tool = nil
    end
end

function Agent:done(message)
    self:clear_stream()
    self:append(message)
    self:finish(true)
    self:send_queued()
end

function Agent:after_tool(name, content)
    local ok, folded = pcall(event.fold, "after_tool", { name = name, content = content }, "content")
    if not ok or type(folded) ~= "string" then
        notices.push("after_tool left no content: " .. tostring(ok and "handlers returned a " .. type(folded) or folded))
        return content
    end
    return folded
end

function Agent:verdict(name, entry, args, subject)
    local ok = true
    if subject == nil then
        ok, subject = pcall(tool.subject, entry, name, args)
    end
    if not ok then
        notices.push(name .. " subject: " .. sys.message(subject))
        return { ask = true }
    end
    local subjects = { subject }
    if entry and entry.path then
        subjects[2] = Files(self.session.directory):resolve(subject)
    end
    local policy = tool.compiled()
    local action, message
    ok, action, message = pcall(policy.evaluate, policy, name, subjects, entry and entry.policy)
    if not ok then
        notices.push(name .. " policy: " .. sys.message(action))
        return { ask = true }
    end
    if action == "allow" then
        return { allow = true }
    elseif action == "deny" then
        return { deny = message or "denied by policy" }
    end
    return { ask = true }
end

function Agent:question(name, entry, args)
    local question = entry and entry.display.question or ("Would you like to run `" .. name .. "`?")
    local ok, detail = pcall(tool.detail, entry, args)
    if not ok or detail == nil then
        detail = listing(args)
    end
    local preview = entry and entry.display.preview
    if not preview then
        return question, detail
    end
    local shown, diff = pcall(preview, args)
    return question, detail, shown and diff or nil
end

function Agent:approve(name, args, subject)
    if tool.disabled[name] then
        return { deny = name .. " is disabled" }
    end
    local entry = tool.described(name)
    local verdict = self:verdict(name, entry, args, subject)
    local decision = decision_of(event.ask("before_tool", { name = name, arguments = args })) or verdict
    if decision.allow then
        return { allow = true, arguments = args }
    end
    if decision.deny then
        return { deny = decision.deny }
    end
    local question, detail, preview = self:question(name, entry, args)
    local answer = self.confirm({
        title = decision.title or question,
        body = detail,
        preview = preview,
        timeout = APPROVAL_TIMEOUT,
    })
    if answer == nil then
        return { deny = "timed out waiting for confirmation" }
    end
    if answer then
        return { allow = true, arguments = args }
    end
    return { deny = "user denied" }
end

function Agent:resolve(name, args)
    local entry = tool.get(name)
    if not entry or not entry.resolve then
        return args
    end
    local ok, resolved, problem = pcall(entry.resolve, args)
    if not ok then
        return nil, "error: " .. sys.message(resolved)
    end
    if not resolved then
        return nil, problem or "error: " .. name .. " resolve returned no arguments"
    end
    return resolved
end

function Agent:run_tool(call, args)
    local entry = tool.get(call.name)
    event.emit("tool_started", { name = call.name })
    local promise = sys.promise()
    local ctx = {
        done = function(value)
            promise:resolve(value)
        end,
        progress = function(line)
            event.emit("tool_progress", { name = call.name, line = line })
        end,
    }
    local ok, result = pcall(entry.run, args, ctx)
    if not ok then
        return { text = "error: " .. sys.message(result) }
    end
    local finished = outcome(result)
    if finished then
        return finished
    end
    if type(result) == "function" then
        if self.turn then
            self.turn.cancel_tool = result
        end
    elseif result ~= nil then
        return {
            text = "error: "
                .. call.name
                .. " returned a "
                .. type(result)
                .. "; run returns its result, a function that cancels it, or nothing",
        }
    end
    local value = promise:await()
    return outcome(value) or { text = tostring(value) }
end

function Agent:budget()
    return model.budget()
end

function Agent:keep_recent()
    local budget = self:budget()
    local room = budget and model.usable(budget) or self.session:used_tokens()
    return math.max(math.min(context.compaction.keep_recent, math.floor(room / KEEP_CEILING_FRACTION)), 1)
end

function Agent:keep_recent_now()
    local used = self.session:used_tokens()
    return math.max(math.min(self:keep_recent(), math.floor(used / KEEP_CEILING_FRACTION)), 1)
end

function Agent:fold(messages)
    local budget = self:budget()
    if not budget then
        return nil
    end
    local compaction = self:compaction_started()
    local folded = compactor.fold(messages, budget, self:keep_recent(), compaction)
    self:compaction_finished()
    return folded
end

function Agent:compact_if_needed()
    if self.skipped_compaction then
        self.skipped_compaction = nil
        return false
    end
    if not context.compaction.enabled or loop_provider() then
        return false
    end
    local budget = self:budget()
    if not budget or self.session:used_tokens() < model.usable(budget) then
        return false
    end
    if self:compact(self:keep_recent()) then
        return true
    end
    notices.push(string.format("context is over the %d token budget but the latest turn cannot be compacted", model.usable(budget)))
    return false
end

function Agent:compact(keep)
    local provider = loop_provider()
    if provider then
        return false, provider.name .. " keeps its own context"
    end
    if self:working() then
        return false, "a turn is running"
    end
    local stored = self.session:entries()
    local cut = view.find_cut(stored, keep or self:keep_recent_now())
    if not cut then
        return false, "nothing to compact yet"
    end
    local first = stored[cut.from].message
    local previous, carried, earlier = nil, {}, {}
    local start = cut.from
    if first.type == "compaction" then
        previous, carried = first.summary, first.files or {}
        start = cut.from + 1
    end
    for index = start, cut.compacted do
        earlier[#earlier + 1] = stored[index].message
    end
    local compaction = self:compaction_started(cut.span)
    self:begin()
    self.task = task.spawn_in(self.ctx, function()
        local files = view.merge_files(view.files_touched(earlier), carried)
        local ok, done = pcall(compactor.generate, earlier, previous)
        if compaction.cancelled then
            return
        end
        self:compaction_finished()
        if ok and done then
            if done.usage then
                self.session:add_cost(done.usage)
            end
            self:append({ type = "compaction", summary = done.summary, through = cut.through, files = files })
            notices.push("compacted " .. cut.span .. " earlier messages")
            event.emit("session_compacted", { count = cut.span })
        else
            notices.push("could not compact; sending the full context")
        end
        self:finish(false)
        self:send_queued()
    end)
    return true
end

function Agent:maybe_title(first)
    if not self.session:untitled() or #self.session:entries() ~= 1 then
        return
    end
    task.spawn_in(self.ctx, function()
        local titled = title.generate(first)
        if not titled then
            return
        end
        if titled.usage then
            self.session:add_cost(titled.usage)
        end
        self:set_title(titled.title)
    end)
end

function Agent:set_title(text)
    local ok, err = pcall(self.session.rename, self.session, text)
    if not ok then
        notices.push("could not save the session title: " .. tostring(err))
        return
    end
    event.emit("session_titled", { title = text })
    event.emit("status_changed", {})
end

function Agent:interrupt()
    if self.shell then
        self.shell.cancelled = true
        self.shell.proc:kill()
        return true
    end
    if self.compaction and not self.turn then
        self.compaction.cancelled = true
        self.skipped_compaction = self:queued()
        if self.task then
            self.task:cancel()
        end
        self:finish(false)
        self:send_queued()
        return true
    end
    if not self.task then
        return false
    end
    local turn = self.turn
    self.task:cancel()
    self.task = nil
    if self.asking then
        pcall(self.asking.close, self.asking)
        self.asking = nil
    end
    if turn and turn.cancel_tool then
        local ok, err = pcall(turn.cancel_tool)
        if not ok then
            notices.push(sys.message(err))
        end
    end
    if turn and turn.loop and turn.loop.interrupt then
        local ok, err = pcall(turn.loop.interrupt, turn.loop)
        if not ok then
            notices.push(sys.message(err))
        end
    end
    self:clear_stream()
    for _, call in ipairs(turn and turn.calls or {}) do
        if not turn.answered[call.id] then
            local content = turn.running == call and WHILE_RUNNING or BEFORE_RUNNING
            self:answer(call, self:after_tool(call.name, content))
        end
    end
    self:append({ type = "error", text = "interrupted" })
    self:finish(true)
    self:send_queued()
    return true
end

function Agent:run_shell(command)
    if self.shell then
        notices.push("a command is already running")
        return
    end
    local spec = process.interactive(command)
    spec.cwd = self.session.directory
    local proc, err = process.spawn(spec)
    if not proc then
        self:append({ type = "shell", command = command, output = "spawn: " .. tostring(err), code = -1 })
        return
    end
    local name = "! " .. command
    local running = { proc = proc, command = command }
    self.shell = running
    event.emit("scroll_to_bottom", {})
    event.emit("tool_progress", { name = name, line = "" })
    event.emit("shell_started", { command = command })
    task.spawn_in(self.ctx, function()
        local capture = process.Capture()
        for line in proc:lines() do
            capture:push(line)
            event.emit("tool_progress", { name = name, line = line })
        end
        local exit = proc:wait()
        local code = running.cancelled and 130 or exit.code or -1
        local output = capture:finish()
        if running.cancelled then
            if output ~= "" then
                output = output .. "\n"
            end
            output = output .. "… interrupted"
        end
        self.shell = nil
        self:append({ type = "shell", command = command, output = output, code = code })
        event.emit("tool_progress", { owner = name })
        event.emit("shell_finished", { command = command, code = code })
    end)
end

return Agent
