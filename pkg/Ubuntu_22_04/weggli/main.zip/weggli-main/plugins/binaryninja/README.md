# Weggli Binary Ninja Plugin

The plugin requires Rust (https://www.rust-lang.org/tools/install) version <= 1.60.0, see https://github.com/googleprojectzero/weggli/issues/68
