package common

type ErrMsg struct {
	Err error
}
