package constants

const (
	SearchingFileTreeWidth = 50
	OpenFileTreeWidth      = 26
)
