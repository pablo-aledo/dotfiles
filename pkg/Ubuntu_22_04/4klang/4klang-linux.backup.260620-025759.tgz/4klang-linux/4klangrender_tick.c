/*
 * 4klang Linux Renderer — modo tick a tick (v2, compatible con ret 4 stdcall)
 */
#include <stdio.h>
#include <string.h>

/* La función usa stdcall: limpia ella misma 4 bytes de pila (ret 4).
   En Linux 32-bit con gcc -m32, declarar como stdcall para que el compilador
   no limpie la pila también. */
extern void __attribute__((stdcall)) __4klang_render(void *buf);
extern int  __4klang_current_tick;

#ifndef SAMPLE_RATE
#define SAMPLE_RATE        44100
#endif
#ifndef BPM
#define BPM                100
#endif
#ifndef MAX_PATTERNS
#define MAX_PATTERNS       62
#endif
#ifndef PATTERN_SIZE_SHIFT
#define PATTERN_SIZE_SHIFT 4
#endif
#define PATTERN_SIZE       (1 << PATTERN_SIZE_SHIFT)
#define MAX_TICKS          (MAX_PATTERNS * PATTERN_SIZE)
#define SAMPLES_PER_TICK   (SAMPLE_RATE * 4 * 60 / (BPM * 16))

static float tickbuf[SAMPLES_PER_TICK * 2];

int main(int argc, char **argv)
{
    FILE *out = (argc > 1) ? fopen(argv[1], "wb") : stdout;
    if (!out) { perror(argv[1]); return 1; }

    __4klang_current_tick = 0;
    fprintf(stderr, "4klang tick | BPM=%d ticks=%d spf=%d\n",
            BPM, MAX_TICKS, SAMPLES_PER_TICK);

    for (int tick = 0; tick < MAX_TICKS; tick++) {
        fprintf(stderr, "\rTick %d/%d ", tick + 1, MAX_TICKS);
        __4klang_render(tickbuf);
        fwrite(tickbuf, sizeof(float) * 2, SAMPLES_PER_TICK, out);
    }
    fprintf(stderr, "\nListo.\n");

    if (argc > 1) fclose(out);
    return 0;
}
