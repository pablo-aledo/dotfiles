#!/bin/bash
# patch_inc_for_linux.sh <input.inc> [output.inc]
# Activa AUTHORING y SINGLE_TICK_RENDERING en un .inc generado por el VSTi de Windows.
# Necesario para usar 4klangrender_tick.
INPUT="${1:?Uso: $0 input.inc [output.inc]}"
OUTPUT="${2:-4klang_tick.inc}"
sed -e 's/;%define SINGLE_TICK_RENDERING/%define SINGLE_TICK_RENDERING/' \
    -e 's/;%define AUTHORING/%define AUTHORING/' \
    "$INPUT" > "$OUTPUT"
echo "Escrito: $OUTPUT (AUTHORING + SINGLE_TICK_RENDERING activados)"
