#!/usr/bin/env python3
"""
Convierte la salida raw float32 stereo de 4klangrender a WAV.
Uso: python3 raw_to_wav.py input.raw output.wav
     ./4klangrender | python3 raw_to_wav.py - output.wav
"""
import sys, struct, wave

def convert(infile, outfile):
    if infile == '-':
        raw = sys.stdin.buffer.read()
    else:
        with open(infile, 'rb') as f:
            raw = f.read()

    n = len(raw) // 4
    samples_f = struct.unpack(f'{n}f', raw[:n*4])

    # Clip + convertir a 16-bit PCM
    samples_i16 = [max(-32768, min(32767, int(s * 32767))) for s in samples_f]

    with wave.open(outfile, 'wb') as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(44100)
        w.writeframes(struct.pack(f'{len(samples_i16)}h', *samples_i16))

    frames = len(samples_i16) // 2
    print(f"Escrito: {outfile} ({frames} frames, {frames/44100:.2f}s)", file=sys.stderr)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    convert(sys.argv[1], sys.argv[2])
