/*
 * 4klang Linux Renderer — modo completo
 * Llama a __4klang_render() una sola vez y escribe PCM float32 stereo a stdout.
 * Uso: ./4klangrender | sox -t raw -b 32 -e float -r 44100 -c 2 - -d
 *      ./4klangrender | sox -t raw -b 32 -e float -r 44100 -c 2 - out.wav
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Declarada en 4klang.asm — renderiza toda la canción al buffer */
extern void __attribute__((stdcall)) __4klang_render(void *buf);

/* Estos defines deben coincidir con los del 4klang.inc activo */
#ifndef SAMPLE_RATE
#define SAMPLE_RATE        44100
#endif
#ifndef BPM
#define BPM                100
#endif
#ifndef MAX_PATTERNS
#define MAX_PATTERNS       62
#endif
#ifndef PATTERN_SIZE_SHIFT
#define PATTERN_SIZE_SHIFT 4
#endif
#define PATTERN_SIZE       (1 << PATTERN_SIZE_SHIFT)
#define MAX_TICKS          (MAX_PATTERNS * PATTERN_SIZE)
#define SAMPLES_PER_TICK   (SAMPLE_RATE * 4 * 60 / (BPM * 16))
#define MAX_SAMPLES        (SAMPLES_PER_TICK * MAX_TICKS)

/* Buffer estático: stereo float32 para toda la canción */
static float outbuf[MAX_SAMPLES * 2];

int main(int argc, char **argv)
{
    float duration = (float)MAX_SAMPLES / SAMPLE_RATE;
    fprintf(stderr, "4klang | BPM=%d ticks=%d samples=%d (%.1fs)\n",
            BPM, MAX_TICKS, MAX_SAMPLES, duration);

    __4klang_render(outbuf);

    if (argc > 1) {
        /* Guardar a archivo */
        FILE *f = fopen(argv[1], "wb");
        if (!f) { perror(argv[1]); return 1; }
        fwrite(outbuf, sizeof(float) * 2, MAX_SAMPLES, f);
        fclose(f);
        fprintf(stderr, "Escrito: %s\n", argv[1]);
    } else {
        /* Stream a stdout (para sox) */
        fwrite(outbuf, sizeof(float) * 2, MAX_SAMPLES, stdout);
    }
    return 0;
}
