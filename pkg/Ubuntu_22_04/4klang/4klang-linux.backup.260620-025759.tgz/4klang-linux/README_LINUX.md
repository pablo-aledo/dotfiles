# 4klang — Port Linux

Port del sintetizador [4klang](https://github.com/hzdgopher/4klang) para Linux x86/x86-64.

## Requisitos

```bash
sudo apt install yasm gcc-multilib sox   # sox es opcional (solo para playback directo)
```

## Archivos del port

| Archivo | Descripción |
|---|---|
| `4klang.asm` | Núcleo del sintetizador (parchado para Linux) |
| `4klang.inc` | Datos de canción + configuración (viene del VSTi o se edita a mano) |
| `4klangrender.c` | Renderer modo completo (toda la canción de una llamada) |
| `4klangrender_tick.c` | Renderer tick a tick (requiere AUTHORING en el .inc) |
| `patch_inc_for_linux.sh` | Activa AUTHORING+SINGLE_TICK en un .inc del VSTi |
| `raw_to_wav.py` | Convierte salida raw float32 a WAV (sin dependencia de sox) |

## Diferencias con el repo original

### Bugs corregidos
- **`__4klang_current_tick resd 0` → `resd 1`**: El `.bss` reservaba 0 bytes para
  el contador de tick, causando corrupción de memoria en tick 4 al usar
  `SINGLE_TICK_RENDERING`. Ahora reserva 1 dword correctamente.

### Añadidos
- **`section .note.GNU-stack`** al final del `.asm`: elimina el warning del linker
  sobre pila ejecutable implícita.

## Uso rápido

### 1. Compilar con el .inc de ejemplo (canción vacía/default)

```bash
make
./4klangrender | sox -t raw -b 32 -e float -r 44100 -c 2 - -d
# o sin sox:
./4klangrender output.raw
python3 raw_to_wav.py output.raw output.wav
```

### 2. Usar tu propia canción desde el VSTi de Windows

El VSTi genera un `.asm` y un `.inc` al grabar. Copia el `.inc` aquí y compila:

```bash
cp mi_cancion.inc 4klang.inc
make
./4klangrender mi_cancion.raw
python3 raw_to_wav.py mi_cancion.raw mi_cancion.wav
```

### 3. Modo tick a tick (para sincronización con video)

```bash
# Activar AUTHORING + SINGLE_TICK_RENDERING en el .inc
./patch_inc_for_linux.sh 4klang.inc 4klang_tick.inc
cp 4klang_tick.inc 4klang.inc

make tick
./4klangrender_tick | sox -t raw -b 32 -e float -r 44100 -c 2 - -d
```

## Integrar en tu propia intro Linux

```c
extern void __4klang_render(void *buf);

float audio[MAX_SAMPLES * 2];  // stereo float32
__4klang_render(audio);
// audio[] ahora contiene la canción completa (L,R,L,R,...)
```

Compilar:
```bash
yasm -m x86 -f elf32 -o 4klang.o 4klang.asm
gcc -m32 -no-pie mi_intro.o 4klang.o -o mi_intro
```

## Limitaciones conocidas

- **32-bit únicamente**: el ASM es x86 puro (usa FPU x87 y `pushad`/`popad`).
  En Linux de 64 bits compila con `-m32` y necesita `gcc-multilib`.
- **No hay VSTi en Linux**: el plugin `.dll` es Windows only. Para componer,
  usa el VSTi en Windows (o Wine) y copia el `.inc` resultante.
- El **plugin GUI** (Go4kVSTi) no se porta aquí; solo el core del sintetizador.
