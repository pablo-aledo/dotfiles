---
name: Feature request
about: Suggest an idea to improve termscp
title: "[Feature Request] - FEATURE_TITLE"
labels: "new feature"
assignees: veeso

---

## Description

Put here a brief introduction to your suggestion.

### Changes

The following changes to the application are expected

- ...

## Implementation

Provide any kind of suggestion you propose on how to implement the feature.
If you have none, delete this section.
