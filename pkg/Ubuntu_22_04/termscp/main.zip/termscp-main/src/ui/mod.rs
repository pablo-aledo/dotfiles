//! ## Ui
//!
//! `ui` is the module which provides all the functionalities related to the UI

// Modules
pub mod activities;
pub mod context;
pub(crate) mod store;
