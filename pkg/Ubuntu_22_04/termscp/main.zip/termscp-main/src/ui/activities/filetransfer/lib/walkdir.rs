#[derive(Debug, Default)]
pub struct WalkdirStates {
    pub aborted: bool,
}
