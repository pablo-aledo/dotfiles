//! ## FileTransferActivity
//!
//! `filetransfer_activiy` is the module which implements the Filetransfer activity, which is the main activity afterall

pub(crate) mod browser;
pub(crate) mod transfer;
pub(crate) mod walkdir;
