# Security Policy

## Supported Versions

Only latst version of termscp has the latest security updates.
Because of that, **you should always consider updating termscp to the latest version**.

## Reporting a Vulnerability

If you have any security vulnerability or concern to report, please open an issue using the `Security report` template.
