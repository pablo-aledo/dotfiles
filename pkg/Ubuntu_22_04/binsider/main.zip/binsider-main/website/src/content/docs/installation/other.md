---
title: Other methods
sidebar:
  order: 7
---

[![Packaging status](https://repology.org/badge/vertical-allrepos/binsider.svg)](https://repology.org/project/binsider/versions)

Feel free to package `binsider` for your favorite distribution! ✨

:::tip

If `binsider` is not yet packaged for your platform, you can build it from source. See the [build from source](/installation/build-from-source) guide for instructions.

:::
