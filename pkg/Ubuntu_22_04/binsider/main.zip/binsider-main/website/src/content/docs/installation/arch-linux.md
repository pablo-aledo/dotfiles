---
title: Arch Linux
sidebar:
  order: 2
---

`binsider` can be installed from the [official repositories](https://archlinux.org/packages/extra/x86_64/binsider/) using [`pacman`](https://wiki.archlinux.org/title/pacman) on Arch Linux:

```bash
pacman -S binsider
```
