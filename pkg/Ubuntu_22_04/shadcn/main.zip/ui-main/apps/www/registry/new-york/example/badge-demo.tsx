import { Badge } from "@/registry/new-york/ui/badge"

export default function BadgeDemo() {
  return <Badge>Badge</Badge>
}
