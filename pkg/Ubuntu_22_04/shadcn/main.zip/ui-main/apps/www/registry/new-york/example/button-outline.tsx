import { Button } from "@/registry/new-york/ui/button"

export default function ButtonOutline() {
  return <Button variant="outline">Outline</Button>
}
