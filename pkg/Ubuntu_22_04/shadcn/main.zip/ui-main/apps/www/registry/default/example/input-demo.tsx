import { Input } from "@/registry/default/ui/input"

export default function InputDemo() {
  return <Input type="email" placeholder="Email" />
}
