import { Badge } from "@/registry/new-york/ui/badge"

export default function BadgeDestructive() {
  return <Badge variant="destructive">Destructive</Badge>
}
