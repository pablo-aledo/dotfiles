import { Button } from "@/registry/new-york/ui/button"

export default function ButtonSecondary() {
  return <Button variant="secondary">Secondary</Button>
}
