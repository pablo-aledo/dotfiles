import { Button } from "@/registry/new-york/ui/button"

export default function ButtonDestructive() {
  return <Button variant="destructive">Destructive</Button>
}
