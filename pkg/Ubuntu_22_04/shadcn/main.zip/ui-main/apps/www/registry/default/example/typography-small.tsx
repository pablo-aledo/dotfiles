export default function TypographySmall() {
  return (
    <small className="text-sm font-medium leading-none">Email address</small>
  )
}
