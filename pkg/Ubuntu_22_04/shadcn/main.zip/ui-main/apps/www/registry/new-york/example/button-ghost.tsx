import { Button } from "@/registry/new-york/ui/button"

export default function ButtonGhost() {
  return <Button variant="ghost">Ghost</Button>
}
