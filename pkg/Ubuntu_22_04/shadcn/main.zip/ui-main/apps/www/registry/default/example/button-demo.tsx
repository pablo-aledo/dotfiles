import { Button } from "@/registry/default/ui/button"

export default function ButtonDemo() {
  return <Button>Button</Button>
}
