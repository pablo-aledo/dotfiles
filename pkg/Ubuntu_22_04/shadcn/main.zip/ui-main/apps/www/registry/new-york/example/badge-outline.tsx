import { Badge } from "@/registry/new-york/ui/badge"

export default function BadgeOutline() {
  return <Badge variant="outline">Outline</Badge>
}
