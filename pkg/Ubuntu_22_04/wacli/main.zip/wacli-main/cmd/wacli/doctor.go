package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	appPkg "github.com/openclaw/wacli/internal/app"
	"github.com/openclaw/wacli/internal/lock"
	"github.com/openclaw/wacli/internal/out"
	"github.com/openclaw/wacli/internal/store"
	"github.com/spf13/cobra"
)

func parseLockOwnerPID(lockInfo string) int {
	for _, line := range strings.Split(lockInfo, "\n") {
		line = strings.TrimSpace(line)
		if !strings.HasPrefix(line, "pid=") {
			continue
		}
		pid, err := strconv.Atoi(strings.TrimSpace(strings.TrimPrefix(line, "pid=")))
		if err == nil && pid > 0 {
			return pid
		}
	}
	return 0
}

func doctorConnectionState(authed, connected, lockHeld, connect, sessionRevoked bool) string {
	switch {
	case sessionRevoked:
		return "logged_out"
	case connected:
		return "connected"
	case authed && lockHeld && !connect:
		return "locked_by_other_process"
	default:
		return "disconnected"
	}
}

type doctorStoreStats struct {
	StatsKnown     bool   `json:"-"`
	Messages       int64  `json:"messages"`
	Chats          int64  `json:"chats"`
	Contacts       int64  `json:"contacts"`
	Groups         int64  `json:"groups"`
	LastSyncAt     string `json:"last_sync_at,omitempty"`
	LastActivityAt string `json:"last_activity_at,omitempty"`
}

func (s doctorStoreStats) MarshalJSON() ([]byte, error) {
	type storeStatsJSON struct {
		Messages       *int64 `json:"messages,omitempty"`
		Chats          *int64 `json:"chats,omitempty"`
		Contacts       *int64 `json:"contacts,omitempty"`
		Groups         *int64 `json:"groups,omitempty"`
		LastSyncAt     string `json:"last_sync_at,omitempty"`
		LastActivityAt string `json:"last_activity_at,omitempty"`
	}
	out := storeStatsJSON{
		LastSyncAt:     s.LastSyncAt,
		LastActivityAt: s.LastActivityAt,
	}
	if s.StatsKnown {
		out.Messages = &s.Messages
		out.Chats = &s.Chats
		out.Contacts = &s.Contacts
		out.Groups = &s.Groups
	}
	return json.Marshal(out)
}

type doctorReport struct {
	StoreDir        string            `json:"store_dir"`
	LockHeld        bool              `json:"lock_held"`
	LockInfo        string            `json:"lock_info,omitempty"`
	LockOwnerPID    int               `json:"lock_owner_pid,omitempty"`
	Authed          bool              `json:"authenticated"`
	SessionRevoked  bool              `json:"session_revoked"`
	LinkedJID       string            `json:"linked_jid,omitempty"`
	Connected       bool              `json:"connected"`
	ConnectionState string            `json:"connection_state"`
	FTSEnabled      bool              `json:"fts_enabled"`
	Store           *doctorStoreStats `json:"store,omitempty"`
	StoreError      string            `json:"store_error,omitempty"`
}

func doctorStoreStatsFromStoreStats(stats store.StoreStats) doctorStoreStats {
	out := doctorStoreStats{
		StatsKnown: true,
		Messages:   stats.Messages,
		Chats:      stats.Chats,
		Contacts:   stats.Contacts,
		Groups:     stats.Groups,
	}
	if stats.LastMessageTS > 0 {
		out.LastSyncAt = time.Unix(stats.LastMessageTS, 0).UTC().Format(time.RFC3339)
	}
	return out
}

func writeDoctorReport(w io.Writer, rep doctorReport) {
	tw := newTableWriter(w)
	fmt.Fprintf(tw, "STORE\t%s\n", sanitize(rep.StoreDir))
	fmt.Fprintf(tw, "LOCKED\t%v\n", rep.LockHeld)
	if rep.LockHeld && rep.LockInfo != "" {
		fmt.Fprintf(tw, "LOCK_INFO\t%s\n", sanitize(rep.LockInfo))
	}
	if rep.LockOwnerPID > 0 {
		fmt.Fprintf(tw, "LOCK_OWNER_PID\t%d\n", rep.LockOwnerPID)
	}
	fmt.Fprintf(tw, "AUTHENTICATED\t%v\n", rep.Authed)
	fmt.Fprintf(tw, "SESSION_REVOKED\t%v\n", rep.SessionRevoked)
	if rep.LinkedJID != "" {
		fmt.Fprintf(tw, "LINKED_JID\t%s\n", sanitize(rep.LinkedJID))
	}
	fmt.Fprintf(tw, "CONNECTED\t%v\n", rep.Connected)
	fmt.Fprintf(tw, "CONNECTION_STATE\t%s\n", sanitize(rep.ConnectionState))
	fmt.Fprintf(tw, "FTS5\t%v\n", rep.FTSEnabled)
	if rep.Store != nil {
		if rep.Store.StatsKnown {
			fmt.Fprintf(tw, "MESSAGES\t%d\n", rep.Store.Messages)
			fmt.Fprintf(tw, "CHATS\t%d\n", rep.Store.Chats)
			fmt.Fprintf(tw, "CONTACTS\t%d\n", rep.Store.Contacts)
			fmt.Fprintf(tw, "GROUPS\t%d\n", rep.Store.Groups)
		}
		if rep.Store.LastSyncAt != "" {
			fmt.Fprintf(tw, "LAST_SYNC\t%s\n", rep.Store.LastSyncAt)
		}
		if rep.Store.LastActivityAt != "" {
			fmt.Fprintf(tw, "LAST_ACTIVITY\t%s\n", rep.Store.LastActivityAt)
		}
	}
	_ = tw.Flush()
}

func newDoctorCmd(flags *rootFlags) *cobra.Command {
	var connect bool

	cmd := &cobra.Command{
		Use:   "doctor",
		Short: "Diagnostics for store/auth/search",
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := withTimeout(context.Background(), flags)
			defer cancel()

			storeDir, err := resolveStoreDir(flags)
			if err != nil {
				return err
			}

			var lockHeld bool
			var lockInfo string
			if flags.isReadOnly() {
				if connect {
					return flags.requireWritable()
				}
				if held, info, err := lock.Probe(storeDir); err == nil {
					lockHeld = held
					lockInfo = info
				} else {
					lockHeld = true
					lockInfo = readDoctorLockInfo(storeDir)
				}
			} else {
				if lk, err := lock.Acquire(storeDir); err == nil {
					_ = lk.Release()
				} else {
					lockHeld = true
					lockInfo = readDoctorLockInfo(storeDir)
				}
			}

			var storeErr string
			var db *store.DB
			var a *appPkg.App
			var closeFn func()
			if flags.isReadOnly() {
				dbPath := filepath.Join(storeDir, "wacli.db")
				roDB, err := store.OpenReadOnly(dbPath)
				if err != nil {
					storeErr = err.Error()
				} else {
					db = roDB
					closeFn = func() { _ = roDB.Close() }
				}
			} else {
				appInstance, lk, err := newApp(ctx, flags, connect, true)
				if err != nil {
					storeErr = err.Error()
				} else {
					a = appInstance
					db = appInstance.DB()
					closeFn = func() { closeApp(appInstance, lk) }
				}
			}
			if closeFn != nil {
				defer closeFn()
			}

			var authed bool
			var connected bool
			var linkedJID string
			if flags.isReadOnly() {
				if roAuthed, roLinkedJID, err := readOnlyAuthStatus(storeDir); err == nil {
					authed = roAuthed
					linkedJID = roLinkedJID
				}
			} else if a != nil {
				if err := a.OpenWA(); err == nil {
					authed = a.WA().IsAuthed()
					if authed {
						linkedJID = a.WA().LinkedJID()
					}
				}
				if connect && authed {
					if err := a.Connect(ctx, false, nil); err == nil {
						connected = true
					}
				}
			}
			sessionRevoked, sessionStateErr := appPkg.SessionRevoked(storeDir)
			if sessionStateErr != nil && storeErr == "" {
				storeErr = sessionStateErr.Error()
			}
			if sessionRevoked {
				authed = false
				connected = false
				linkedJID = ""
			}
			lockOwnerPID := parseLockOwnerPID(lockInfo)

			var stats *doctorStoreStats
			var lastActivityAt string
			if hb := appPkg.ReadHeartbeat(storeDir); !hb.IsZero() {
				lastActivityAt = hb.UTC().Format(time.RFC3339)
			}
			if db != nil {
				if raw, err := db.Stats(); err == nil {
					converted := doctorStoreStatsFromStoreStats(raw)
					stats = &converted
				} else if storeErr == "" {
					storeErr = err.Error()
				}
			}
			if lastActivityAt != "" {
				if stats == nil {
					stats = &doctorStoreStats{}
				}
				stats.LastActivityAt = lastActivityAt
			}

			rep := doctorReport{
				StoreDir:        storeDir,
				LockHeld:        lockHeld,
				LockInfo:        lockInfo,
				LockOwnerPID:    lockOwnerPID,
				Authed:          authed,
				SessionRevoked:  sessionRevoked,
				LinkedJID:       linkedJID,
				Connected:       connected,
				ConnectionState: doctorConnectionState(authed, connected, lockHeld, connect, sessionRevoked),
				FTSEnabled:      db != nil && db.HasFTS(),
				Store:           stats,
				StoreError:      storeErr,
			}

			if flags.asJSON {
				return out.WriteJSON(os.Stdout, rep)
			}

			writeDoctorReport(os.Stdout, rep)

			if rep.StoreError != "" {
				fmt.Fprintf(os.Stdout, "\nERROR: store could not be opened: %s\n", sanitize(rep.StoreError))
				fmt.Fprintln(os.Stdout, "Tip: check that the store directory exists and is not corrupted.")
			}
			if rep.LockHeld {
				fmt.Fprintln(os.Stdout, "\nTip: stop the running `wacli sync` before running write operations.")
			}
			return nil
		},
	}

	cmd.Flags().BoolVar(&connect, "connect", false, "try connecting to WhatsApp (requires store lock)")
	return cmd
}

func readDoctorLockInfo(storeDir string) string {
	b, err := os.ReadFile(filepath.Join(storeDir, "LOCK"))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}
