package store

import (
	"database/sql"
	"errors"
	"reflect"
	"testing"
	"time"
)

func TestHistoricalLIDJIDsFindsChatAndMessageColumns(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	group := "120363000000@g.us"
	for _, jid := range []string{pn, lid, group} {
		if err := db.UpsertChat(jid, "dm", jid, base); err != nil {
			t.Fatalf("UpsertChat %s: %v", jid, err)
		}
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:   lid,
		MsgID:     "lid-chat",
		SenderJID: lid,
		Timestamp: base,
		Text:      "lid chat",
	}); err != nil {
		t.Fatalf("UpsertMessage lid chat: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:         group,
		MsgID:           "group-sender",
		SenderJID:       lid,
		Timestamp:       base,
		Text:            "group sender",
		QuotedMsgID:     "quoted",
		QuotedSenderJID: lid,
	}); err != nil {
		t.Fatalf("UpsertMessage group sender: %v", err)
	}
	if err := db.UpsertPoll(Poll{
		ChatJID:   lid,
		MsgID:     "lid-poll",
		SenderJID: lid,
		Question:  "LID?",
		Options:   []string{"yes", "no"},
		CreatedAt: base,
	}); err != nil {
		t.Fatalf("UpsertPoll lid: %v", err)
	}
	if err := db.UpsertPollVote(PollVote{
		ChatJID:   group,
		PollMsgID: "group-poll",
		VoterJID:  lid,
		VoteMsgID: "lid-vote",
		Selected:  []string{"yes"},
		VotedAt:   base,
	}); err != nil {
		t.Fatalf("UpsertPollVote lid: %v", err)
	}

	got, err := db.HistoricalLIDJIDs()
	if err != nil {
		t.Fatalf("HistoricalLIDJIDs: %v", err)
	}
	if want := []string{lid}; !reflect.DeepEqual(got, want) {
		t.Fatalf("HistoricalLIDJIDs = %#v, want %#v", got, want)
	}
}

func TestHistoricalLIDJIDsFindsGroupIdentities(t *testing.T) {
	db := openTestDB(t)
	lid := "999123456789@lid"
	group := "120363000000@g.us"
	if err := db.UpsertGroup(group, "Project", lid, time.Time{}); err != nil {
		t.Fatalf("UpsertGroup: %v", err)
	}
	if err := db.ReplaceGroupParticipants(group, []GroupParticipant{{
		GroupJID: group,
		UserJID:  lid,
		Role:     "admin",
	}}); err != nil {
		t.Fatalf("ReplaceGroupParticipants: %v", err)
	}

	got, err := db.HistoricalLIDJIDs()
	if err != nil {
		t.Fatalf("HistoricalLIDJIDs: %v", err)
	}
	if want := []string{lid}; !reflect.DeepEqual(got, want) {
		t.Fatalf("HistoricalLIDJIDs = %#v, want %#v", got, want)
	}
}

func TestHistoricalLIDJIDsFindsPurgeLedgerOnlyIdentity(t *testing.T) {
	db := openTestDB(t)
	lid := "888123456789@lid"
	if _, err := db.sql.Exec(`
		INSERT INTO message_payload_purges(chat_jid, msg_id, purged_at, deleted_at, deletion_reason)
		VALUES(?, 'mid', 3, 2, 'whatsapp-revoke')
	`, lid); err != nil {
		t.Fatal(err)
	}
	got, err := db.HistoricalLIDJIDs()
	if err != nil {
		t.Fatal(err)
	}
	if want := []string{lid}; !reflect.DeepEqual(got, want) {
		t.Fatalf("HistoricalLIDJIDs = %#v, want %#v", got, want)
	}
}

func TestMigrateLIDToPNMergesChatsAndMessages(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	group := "120363000000@g.us"
	if err := db.UpsertChat(pn, "dm", "Alice", base); err != nil {
		t.Fatalf("UpsertChat pn: %v", err)
	}
	if err := db.UpsertChat(lid, "unknown", lid, base.Add(10*time.Second)); err != nil {
		t.Fatalf("UpsertChat lid: %v", err)
	}
	if err := db.SetChatUnreadCount(pn, 2); err != nil {
		t.Fatalf("SetChatUnreadCount pn: %v", err)
	}
	if err := db.SetChatUnreadCount(lid, 3); err != nil {
		t.Fatalf("SetChatUnreadCount lid: %v", err)
	}
	if err := db.UpsertChat(group, "group", "Project", base); err != nil {
		t.Fatalf("UpsertChat group: %v", err)
	}

	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:   pn,
		MsgID:     "dupe",
		SenderJID: "",
		Timestamp: base,
	}); err != nil {
		t.Fatalf("UpsertMessage pn dupe: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:    lid,
		ChatName:   "Alice LID",
		MsgID:      "dupe",
		SenderJID:  lid,
		SenderName: "Alice",
		Timestamp:  base.Add(5 * time.Second),
		Text:       "from lid",
	}); err != nil {
		t.Fatalf("UpsertMessage lid dupe: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:         lid,
		ChatName:        "Alice LID",
		MsgID:           "lid-only",
		SenderJID:       lid,
		SenderName:      "Alice",
		Timestamp:       base.Add(6 * time.Second),
		Text:            "only on lid",
		QuotedMsgID:     "quoted-lid-only",
		QuotedSenderJID: lid,
	}); err != nil {
		t.Fatalf("UpsertMessage lid only: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:         group,
		MsgID:           "group",
		SenderJID:       lid,
		Timestamp:       base.Add(7 * time.Second),
		Text:            "group message",
		QuotedMsgID:     "quoted-group",
		QuotedSenderJID: lid,
	}); err != nil {
		t.Fatalf("UpsertMessage group: %v", err)
	}
	if err := db.UpsertPoll(Poll{
		ChatJID:         lid,
		MsgID:           "poll",
		SenderJID:       lid,
		Question:        "Dinner?",
		Options:         []string{"yes", "no"},
		SelectableCount: 1,
		CreatedAt:       base.Add(8 * time.Second),
	}); err != nil {
		t.Fatalf("UpsertPoll lid: %v", err)
	}
	if err := db.UpsertPoll(Poll{
		ChatJID:         pn,
		MsgID:           "poll",
		SenderJID:       pn,
		Question:        "Dinner?",
		Options:         []string{"yes", "no", "maybe"},
		SelectableCount: 1,
		CreatedAt:       base.Add(9 * time.Second),
	}); err != nil {
		t.Fatalf("UpsertPoll pn: %v", err)
	}
	if err := db.UpsertPoll(Poll{
		ChatJID:         group,
		MsgID:           "group-poll",
		SenderJID:       lid,
		Question:        "Group?",
		Options:         []string{"yes", "no"},
		SelectableCount: 1,
		CreatedAt:       base.Add(8 * time.Second),
	}); err != nil {
		t.Fatalf("UpsertPoll group: %v", err)
	}
	if err := db.UpsertPollVote(PollVote{
		ChatJID:   lid,
		PollMsgID: "poll",
		VoterJID:  lid,
		VoteMsgID: "older-vote",
		Selected:  []string{"yes"},
		VotedAt:   base.Add(8 * time.Second),
	}); err != nil {
		t.Fatalf("UpsertPollVote lid: %v", err)
	}
	if err := db.UpsertPollVote(PollVote{
		ChatJID:   pn,
		PollMsgID: "poll",
		VoterJID:  pn,
		VoteMsgID: "newer-vote",
		Selected:  []string{"no"},
		VotedAt:   base.Add(9 * time.Second),
	}); err != nil {
		t.Fatalf("UpsertPollVote pn: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}
	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN idempotent: %v", err)
	}

	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM chats WHERE jid = ?", lid); got != 0 {
		t.Fatalf("lid chat rows = %d, want 0", got)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM messages WHERE chat_jid = ?", lid); got != 0 {
		t.Fatalf("lid chat message rows = %d, want 0", got)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM messages WHERE sender_jid = ?", lid); got != 0 {
		t.Fatalf("lid sender rows = %d, want 0", got)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM messages WHERE quoted_sender_jid = ?", lid); got != 0 {
		t.Fatalf("lid quoted sender rows = %d, want 0", got)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM polls WHERE chat_jid = ? OR (sender_jid = ? AND chat_jid NOT GLOB '*@g.us')", lid, lid); got != 0 {
		t.Fatalf("lid poll rows = %d, want 0", got)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM poll_votes WHERE chat_jid = ? OR voter_jid = ?", lid, lid); got != 0 {
		t.Fatalf("lid poll vote rows = %d, want 0", got)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM messages WHERE chat_jid = ?", pn); got != 2 {
		t.Fatalf("pn message rows = %d, want 2", got)
	}

	chat, err := db.GetChat(pn)
	if err != nil {
		t.Fatalf("GetChat pn: %v", err)
	}
	if chat.Name != "Alice" {
		t.Fatalf("merged chat name = %q, want Alice", chat.Name)
	}
	if !chat.LastMessageTS.Equal(base.Add(10 * time.Second)) {
		t.Fatalf("merged chat timestamp = %s, want %s", chat.LastMessageTS, base.Add(10*time.Second))
	}
	if !chat.Unread || chat.UnreadCount != 5 {
		t.Fatalf("merged chat unread state = %+v, want unread count 5", chat)
	}

	dupe, err := db.GetMessage(pn, "dupe")
	if err != nil {
		t.Fatalf("GetMessage dupe: %v", err)
	}
	if dupe.Text != "from lid" {
		t.Fatalf("merged duplicate text = %q, want from lid", dupe.Text)
	}
	if dupe.SenderJID != pn {
		t.Fatalf("merged duplicate sender = %q, want %q", dupe.SenderJID, pn)
	}
	if !dupe.Timestamp.Equal(base.Add(5 * time.Second)) {
		t.Fatalf("merged duplicate timestamp = %s, want %s", dupe.Timestamp, base.Add(5*time.Second))
	}
	lidOnly, err := db.GetMessage(pn, "lid-only")
	if err != nil {
		t.Fatalf("GetMessage lid-only: %v", err)
	}
	if lidOnly.QuotedMsgID != "quoted-lid-only" || lidOnly.QuotedSenderJID != pn {
		t.Fatalf("lid-only quoted metadata = id %q sender %q", lidOnly.QuotedMsgID, lidOnly.QuotedSenderJID)
	}

	groupMsg, err := db.GetMessage(group, "group")
	if err != nil {
		t.Fatalf("GetMessage group: %v", err)
	}
	if groupMsg.SenderJID != pn {
		t.Fatalf("group sender = %q, want %q", groupMsg.SenderJID, pn)
	}
	if groupMsg.QuotedMsgID != "quoted-group" || groupMsg.QuotedSenderJID != pn {
		t.Fatalf("group quoted metadata = id %q sender %q", groupMsg.QuotedMsgID, groupMsg.QuotedSenderJID)
	}

	poll, err := db.GetPoll(pn, "poll")
	if err != nil {
		t.Fatalf("GetPoll migrated: %v", err)
	}
	if poll.SenderJID != pn {
		t.Fatalf("migrated poll sender = %q, want %q", poll.SenderJID, pn)
	}
	if !reflect.DeepEqual(poll.Options, []string{"yes", "no", "maybe"}) {
		t.Fatalf("migrated poll options = %#v, want yes/no/maybe", poll.Options)
	}
	groupPoll, err := db.GetPoll(group, "group-poll")
	if err != nil {
		t.Fatalf("GetPoll group: %v", err)
	}
	if groupPoll.SenderJID != lid {
		t.Fatalf("group poll sender = %q, want %q", groupPoll.SenderJID, lid)
	}
	votes, err := db.ListPollVotes(pn, "poll")
	if err != nil {
		t.Fatalf("ListPollVotes migrated: %v", err)
	}
	if len(votes) != 1 || votes[0].VoterJID != pn || votes[0].VoteMsgID != "newer-vote" || !reflect.DeepEqual(votes[0].Selected, []string{"no"}) {
		t.Fatalf("migrated votes = %+v", votes)
	}

	lids, err := db.HistoricalLIDJIDs()
	if err != nil {
		t.Fatalf("HistoricalLIDJIDs after migrate: %v", err)
	}
	if len(lids) != 0 {
		t.Fatalf("HistoricalLIDJIDs after migrate = %#v, want none", lids)
	}
}

func TestMigrateLIDToPNMergesGroupIdentities(t *testing.T) {
	db := openTestDB(t)
	lid := "999123456789@lid"
	pn := "15551234567@s.whatsapp.net"
	group := "120363000000@g.us"
	if err := db.UpsertGroup(group, "Project", lid, time.Time{}); err != nil {
		t.Fatalf("UpsertGroup: %v", err)
	}
	if _, err := db.sql.Exec(`
		INSERT INTO group_participants(group_jid, user_jid, role, updated_at)
		VALUES (?, ?, 'member', 1), (?, ?, 'admin', 2)
	`, group, pn, group, lid); err != nil {
		t.Fatalf("insert participants: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}
	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN idempotent: %v", err)
	}

	groups, err := db.ListGroups("Project", 1)
	if err != nil {
		t.Fatalf("ListGroups: %v", err)
	}
	if len(groups) != 1 || groups[0].OwnerJID != pn {
		t.Fatalf("groups = %+v, want owner %q", groups, pn)
	}
	if got := countRows(t, db.sql, "SELECT COUNT(*) FROM group_participants WHERE group_jid = ?", group); got != 1 {
		t.Fatalf("participant rows = %d, want 1", got)
	}
	var userJID, role string
	var updatedAt int64
	if err := db.sql.QueryRow(`
		SELECT user_jid, role, updated_at
		FROM group_participants
		WHERE group_jid = ?
	`, group).Scan(&userJID, &role, &updatedAt); err != nil {
		t.Fatalf("query participant: %v", err)
	}
	if userJID != pn || role != "admin" || updatedAt != 2 {
		t.Fatalf("participant = (%q, %q, %d), want (%q, admin, 2)", userJID, role, updatedAt, pn)
	}
}

func TestMigrateLIDToPNPreservesButtons(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	if err := db.UpsertChat(lid, "dm", "Alice", base); err != nil {
		t.Fatalf("UpsertChat lid: %v", err)
	}

	want := []Button{
		{Type: "url", DisplayText: "Buy flights", URL: "https://example.com/flights"},
		{Type: "quick_reply", DisplayText: "No thanks", ID: "no"},
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:   lid,
		MsgID:     "tmpl1",
		SenderJID: lid,
		Timestamp: base,
		Text:      "Check our deals",
		Buttons:   want,
	}); err != nil {
		t.Fatalf("UpsertMessage: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}

	msg, err := db.GetMessage(pn, "tmpl1")
	if err != nil {
		t.Fatalf("GetMessage after migration: %v", err)
	}
	if len(msg.Buttons) != len(want) {
		t.Fatalf("expected %d buttons after migration, got %d: %+v", len(want), len(msg.Buttons), msg.Buttons)
	}
	for i, b := range want {
		got := msg.Buttons[i]
		if got.Type != b.Type || got.DisplayText != b.DisplayText || got.ID != b.ID || got.URL != b.URL {
			t.Fatalf("button[%d]: got %+v, want %+v", i, got, b)
		}
	}
}

func TestMigrateLIDToPNPreservesDeletedMessagePayload(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	if err := db.UpsertChat(lid, "dm", "Alice", base); err != nil {
		t.Fatalf("UpsertChat lid: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:         lid,
		MsgID:           "deleted-reply",
		SenderJID:       lid,
		Timestamp:       base,
		QuotedMsgID:     "quoted",
		QuotedSenderJID: lid,
		Text:            "retained reply",
		MediaType:       "document",
		Filename:        "proof.pdf",
		DeletedForMe:    true,
	}); err != nil {
		t.Fatalf("UpsertMessage: %v", err)
	}
	if _, err := db.sql.Exec(`UPDATE messages SET quoted_msg_id = ?, quoted_sender_jid = ? WHERE chat_jid = ? AND msg_id = ?`, "quoted", lid, lid, "deleted-reply"); err != nil {
		t.Fatalf("seed legacy quoted metadata: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}

	msg, err := db.GetMessage(pn, "deleted-reply")
	if err != nil {
		t.Fatalf("GetMessage after migration: %v", err)
	}
	if !msg.DeletedForMe {
		t.Fatalf("DeletedForMe = false")
	}
	if msg.QuotedMsgID != "quoted" || msg.QuotedSenderJID != pn {
		t.Fatalf("deleted quoted metadata = id %q sender %q", msg.QuotedMsgID, msg.QuotedSenderJID)
	}
	if msg.Text != "retained reply" || msg.MediaType != "document" || msg.Filename != "proof.pdf" {
		t.Fatalf("deleted payload = %+v", msg)
	}
	if msg.DeletedAt == nil || msg.DeletionReason != MessageDeletionReasonWhatsAppDeleteForMe {
		t.Fatalf("deleted tombstone = %v %q", msg.DeletedAt, msg.DeletionReason)
	}
}

func TestMigrateLIDToPNPreservesPayloadPurgeSuppression(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	for _, chat := range []string{pn, lid} {
		if err := db.UpsertChat(chat, "dm", "Alice", base); err != nil {
			t.Fatal(err)
		}
	}
	for _, id := range []string{"purged-lid", "purged-pn", "ledger-lid", "ledger-pn"} {
		if err := db.UpsertMessage(UpsertMessageParams{ChatJID: pn, MsgID: id, Timestamp: base, Text: "pn payload"}); err != nil {
			t.Fatal(err)
		}
		if err := db.UpsertMessage(UpsertMessageParams{ChatJID: lid, MsgID: id, Timestamp: base, Text: "lid payload"}); err != nil {
			t.Fatal(err)
		}
	}
	if err := db.MarkMessageRevoked(lid, "purged-lid"); err != nil {
		t.Fatal(err)
	}
	if err := db.PurgeMessage(lid, "purged-lid"); err != nil {
		t.Fatal(err)
	}
	if err := db.MarkMessageRevoked(pn, "purged-pn"); err != nil {
		t.Fatal(err)
	}
	if err := db.PurgeMessage(pn, "purged-pn"); err != nil {
		t.Fatal(err)
	}
	if err := db.MarkMessageRevoked(lid, "ledger-lid"); err != nil {
		t.Fatal(err)
	}
	if err := db.PurgeMessage(lid, "ledger-lid"); err != nil {
		t.Fatal(err)
	}
	if err := db.MarkMessageRevoked(pn, "ledger-pn"); err != nil {
		t.Fatal(err)
	}
	if err := db.PurgeMessage(pn, "ledger-pn"); err != nil {
		t.Fatal(err)
	}
	if _, err := db.sql.Exec(`DELETE FROM messages WHERE (chat_jid = ? AND msg_id = ?) OR (chat_jid = ? AND msg_id = ?)`, lid, "ledger-lid", pn, "ledger-pn"); err != nil {
		t.Fatal(err)
	}
	if err := db.UpsertPoll(Poll{ChatJID: pn, MsgID: "ledger-lid", Question: "destination-only secret", Options: []string{"secret"}, CreatedAt: base}); err != nil {
		t.Fatal(err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatal(err)
	}
	for _, id := range []string{"purged-lid", "purged-pn", "ledger-lid"} {
		msg, err := db.GetMessage(pn, id)
		if err != nil {
			t.Fatal(err)
		}
		if msg.PayloadPurgedAt == nil || msg.Text != "" {
			t.Fatalf("%s purge suppression after LID migration = %+v", id, msg)
		}
	}
	var messageCount, purgeCount int
	if err := db.sql.QueryRow(`SELECT count(*) FROM messages WHERE chat_jid = ? AND msg_id = ?`, pn, "ledger-pn").Scan(&messageCount); err != nil {
		t.Fatal(err)
	}
	if err := db.sql.QueryRow(`SELECT count(*) FROM message_payload_purges WHERE chat_jid = ? AND msg_id = ?`, pn, "ledger-pn").Scan(&purgeCount); err != nil {
		t.Fatal(err)
	}
	if messageCount != 0 || purgeCount != 1 {
		t.Fatalf("destination-ledger suppression counts: messages=%d purges=%d", messageCount, purgeCount)
	}
	if got := countRows(t, db.sql, `SELECT count(*) FROM polls WHERE msg_id = 'ledger-lid'`); got != 0 {
		t.Fatalf("destination-only purged poll rows = %d", got)
	}
}

func TestMigrateLIDToPNPreservesEditedState(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	if err := db.UpsertChat(pn, "dm", "Alice", base); err != nil {
		t.Fatalf("UpsertChat pn: %v", err)
	}
	if err := db.UpsertChat(lid, "dm", "Alice", base); err != nil {
		t.Fatalf("UpsertChat lid: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:     pn,
		MsgID:       "mid",
		SenderJID:   pn,
		Timestamp:   base,
		Text:        "original",
		DisplayText: "original",
	}); err != nil {
		t.Fatalf("UpsertMessage pn original: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:     lid,
		MsgID:       "mid",
		SenderJID:   lid,
		Timestamp:   base.Add(time.Minute),
		Text:        "edited",
		DisplayText: "edited",
		Edited:      true,
	}); err != nil {
		t.Fatalf("UpsertMessage lid edited: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}

	msg, err := db.GetMessage(pn, "mid")
	if err != nil {
		t.Fatalf("GetMessage after migration: %v", err)
	}
	if msg.Text != "edited" || msg.DisplayText != "edited" {
		t.Fatalf("migration lost edited body: %+v", msg)
	}
	if !msg.Timestamp.Equal(base) {
		t.Fatalf("timestamp = %s, want original timestamp", msg.Timestamp)
	}

	var edited, editedTS int64
	if err := db.sql.QueryRow(`SELECT edited, edited_ts FROM messages WHERE chat_jid = ? AND msg_id = ?`, pn, "mid").Scan(&edited, &editedTS); err != nil {
		t.Fatalf("query edited metadata: %v", err)
	}
	if edited != 1 || editedTS != base.Add(time.Minute).Unix() {
		t.Fatalf("edited metadata = (%d, %d), want (1, %d)", edited, editedTS, base.Add(time.Minute).Unix())
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID:     pn,
		MsgID:       "mid",
		SenderJID:   pn,
		Timestamp:   base,
		Text:        "original again",
		DisplayText: "original again",
	}); err != nil {
		t.Fatalf("UpsertMessage original after migration: %v", err)
	}
	msg, err = db.GetMessage(pn, "mid")
	if err != nil {
		t.Fatalf("GetMessage after original: %v", err)
	}
	if msg.Text != "edited" {
		t.Fatalf("original upsert clobbered migrated edit: %q", msg.Text)
	}
}

func TestMigrateLIDToPNMovesMessageLocations(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	if err := db.UpsertChat(lid, "unknown", lid, base); err != nil {
		t.Fatalf("UpsertChat lid: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID: lid, MsgID: "LOC-1", Timestamp: base, MediaType: "location",
		DisplayText: "Sent location",
	}); err != nil {
		t.Fatalf("UpsertMessage: %v", err)
	}
	if err := db.UpsertMessageLocation(MessageLocation{
		ChatJID: lid, MsgID: "LOC-1", Latitude: 51.4779, Longitude: -0.0015, Name: "Head office",
	}); err != nil {
		t.Fatalf("UpsertMessageLocation: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}

	moved, err := db.GetMessageLocation(pn, "LOC-1")
	if err != nil {
		t.Fatalf("GetMessageLocation pn: %v", err)
	}
	if moved.Latitude != 51.4779 || moved.Longitude != -0.0015 {
		t.Fatalf("coordinates = %v,%v", moved.Latitude, moved.Longitude)
	}
	if moved.Name != "Head office" {
		t.Fatalf("name = %q", moved.Name)
	}
	if _, err := db.GetMessageLocation(lid, "LOC-1"); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("lid location retained: err = %v", err)
	}
}

func TestMigrateLIDToPNDropsPurgedMessageLocations(t *testing.T) {
	db := openTestDB(t)
	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)

	pn := "15551234567@s.whatsapp.net"
	lid := "999123456789@lid"
	if err := db.UpsertChat(lid, "unknown", lid, base); err != nil {
		t.Fatalf("UpsertChat lid: %v", err)
	}
	if err := db.UpsertMessage(UpsertMessageParams{
		ChatJID: lid, MsgID: "LOC-1", Timestamp: base, MediaType: "location",
		DisplayText: "Sent location",
	}); err != nil {
		t.Fatalf("UpsertMessage: %v", err)
	}
	if err := db.UpsertMessageLocation(MessageLocation{
		ChatJID: lid, MsgID: "LOC-1", Latitude: 51.4779, Longitude: -0.0015,
	}); err != nil {
		t.Fatalf("UpsertMessageLocation: %v", err)
	}
	if err := db.MarkMessageRevoked(lid, "LOC-1"); err != nil {
		t.Fatalf("MarkMessageRevoked: %v", err)
	}
	if err := db.PurgeMessage(lid, "LOC-1"); err != nil {
		t.Fatalf("PurgeMessage: %v", err)
	}

	if err := db.MigrateLIDToPN(lid, pn); err != nil {
		t.Fatalf("MigrateLIDToPN: %v", err)
	}

	if _, err := db.GetMessageLocation(pn, "LOC-1"); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("purged coordinates resurfaced under the phone identity: err = %v", err)
	}
}
