package store

import (
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	_ "github.com/mattn/go-sqlite3"
	"github.com/openclaw/wacli/internal/fsutil"
	"github.com/openclaw/wacli/internal/sqliteutil"
	"github.com/openclaw/wacli/internal/store/storedb"
)

type DB struct {
	path       string
	sql        *sql.DB
	q          *storedb.Queries
	ftsEnabled bool
}

func Open(path string) (*DB, error) {
	return open(path, false)
}

func OpenReadOnly(path string) (*DB, error) {
	return open(path, true)
}

func open(path string, readOnly bool) (*DB, error) {
	if strings.TrimSpace(path) == "" {
		return nil, fmt.Errorf("db path is required")
	}
	// Reject paths that could inject SQLite URI parameters (#59).
	if strings.ContainsAny(path, "?#") {
		return nil, fmt.Errorf("db path must not contain '?' or '#'")
	}
	if readOnly {
		if _, err := os.Stat(path); err != nil {
			return nil, err
		}
	} else if err := fsutil.EnsurePrivateDir(filepath.Dir(path)); err != nil {
		return nil, fmt.Errorf("create db directory: %w", err)
	}

	db, err := sql.Open("sqlite3", sqliteURI(path, readOnly))
	if err != nil {
		return nil, fmt.Errorf("open sqlite: %w", err)
	}

	s := &DB{path: path, sql: db, q: storedb.New(db)}
	if readOnly {
		if err := s.validateReadable(); err != nil {
			_ = db.Close()
			return nil, fmt.Errorf("open read-only sqlite: %w", err)
		}
		s.ftsEnabled = s.detectMessagesFTS()
		return s, nil
	}
	if err := s.init(); err != nil {
		_ = db.Close()
		return nil, err
	}
	if err := sqliteutil.ChmodFiles(path, 0o600); err != nil {
		_ = db.Close()
		return nil, err
	}
	return s, nil
}

func (d *DB) validateReadable() error {
	var n int
	return d.sql.QueryRow("SELECT count(*) FROM sqlite_master").Scan(&n)
}

func sqliteURI(path string, readOnly bool) string {
	params := "_foreign_keys=on&_busy_timeout=5000"
	if readOnly {
		params += "&mode=ro&_query_only=1"
		if !sqliteSidecarsExist(path) {
			params += "&immutable=1"
		}
	}
	return sqliteutil.FileURI(path, params)
}

func sqliteSidecarsExist(path string) bool {
	for _, suffix := range []string{"-journal", "-wal", "-shm"} {
		if _, err := os.Stat(path + suffix); err == nil {
			return true
		}
	}
	return false
}

func (d *DB) Close() error {
	if d == nil || d.sql == nil {
		return nil
	}
	return d.sql.Close()
}

func (d *DB) init() error {
	// Pragmas: keep consistent for writers/readers.
	_, _ = d.sql.Exec("PRAGMA journal_mode=WAL;")
	_, _ = d.sql.Exec("PRAGMA synchronous=NORMAL;")
	_, _ = d.sql.Exec("PRAGMA temp_store=MEMORY;")
	_, _ = d.sql.Exec("PRAGMA foreign_keys=ON;")

	if err := d.ensureSchema(); err != nil {
		return err
	}

	// Detect FTS5 availability independently of migration state. The migration
	// sets ftsEnabled only on first run; subsequent opens skip the migration.
	if !d.ftsEnabled {
		d.ftsEnabled = d.detectMessagesFTS()
	}

	return nil
}

func (d *DB) detectMessagesFTS() bool {
	ok, err := d.tableExists("messages_fts")
	if err != nil || !ok {
		return false
	}
	hasDisplayText, err := d.tableHasColumn("messages_fts", "display_text")
	if err != nil || !hasDisplayText {
		return false
	}
	// One row is enough: a build without FTS5 fails as soon as the table is
	// read. count(*) would walk the whole index on every open, a cost that
	// grows with the archive and that every command pays.
	var rowid int64
	err = d.sql.QueryRow("SELECT rowid FROM messages_fts LIMIT 1").Scan(&rowid)
	return err == nil || errors.Is(err, sql.ErrNoRows)
}
