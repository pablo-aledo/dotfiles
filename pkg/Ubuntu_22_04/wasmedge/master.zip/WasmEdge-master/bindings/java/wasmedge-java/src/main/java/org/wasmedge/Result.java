package org.wasmedge;

/**
 * Result class.
 */
public class Result {
}
