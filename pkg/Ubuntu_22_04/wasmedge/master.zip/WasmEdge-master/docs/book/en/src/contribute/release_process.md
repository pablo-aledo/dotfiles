# WasmEdge Release Process

> This part has been moved to <https://wasmedge.org/docs/contribute/release>. Please use our new docs.
