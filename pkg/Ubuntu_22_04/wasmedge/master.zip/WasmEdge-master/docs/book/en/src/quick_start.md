# Quick Start

> This part has been moved to <https://wasmedge.org/docs/category/getting-started-with-wasmedge>. Please use our new docs.