# Command interface

This part part has moved to <https://wasmedge.org/docs/develop/rust/command>. Please use our docs.
