# Using WasmEdge in Docker

> This part has been moved to <https://wasmedge.org/docs/develop/deploy/kubernetes/docker-slim>. Please use our new docs.