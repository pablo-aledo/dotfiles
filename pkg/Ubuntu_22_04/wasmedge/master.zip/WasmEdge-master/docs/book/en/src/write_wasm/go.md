# Go

> This part has been moved to  <https://wasmedge.org/docs/develop/go/hello_world>. Please use our new docs.
