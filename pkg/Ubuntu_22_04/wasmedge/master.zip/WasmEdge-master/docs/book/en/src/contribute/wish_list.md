# Wish list

> This part has been moved to <https://wasmedge.org/docs/contribute/overview#ideas-for-contributions>. Please use our new docs.
