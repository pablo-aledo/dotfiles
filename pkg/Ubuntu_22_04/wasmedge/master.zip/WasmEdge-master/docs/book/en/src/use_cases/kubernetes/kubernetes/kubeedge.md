# Create a crun demo for KubeEdge

This docs has moved to <https://wasmedge.org/docs/develop/deploy/kubernetes/kubedge>. Please use our new docs.
