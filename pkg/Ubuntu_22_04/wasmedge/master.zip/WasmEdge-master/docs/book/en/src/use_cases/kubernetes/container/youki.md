# youki

> This part has been moved to  <https://wasmedge.org/docs/develop/deploy/oci-runtime/youki>. Please use our new docs.
