# SuperEdge

> This part has been moved to  <https://wasmedge.org/docs/develop/deploy/kubernetes/superedge>. Please use our new docs.
