# Embed a standalone WASM app

> This part has been moved to  <https://wasmedge.org/docs/embed/go/app>. Please use our new docs.
