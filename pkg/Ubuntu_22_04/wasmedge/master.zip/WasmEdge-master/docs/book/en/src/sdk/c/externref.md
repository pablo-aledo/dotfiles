# Customized External References

> This part has been moved to  <https://wasmedge.org/docs/embed/c/externref>. Please use our new docs.
