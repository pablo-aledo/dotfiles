# Use WasmEdge Library in Programming Languages

> This doc has been moved to <https://wasmedge.org/docs/embed/overview>. Please use our new docs.
