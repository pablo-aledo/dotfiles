# Installer Guide

> This part has been moved to <https://wasmedge.org/docs/contribute/installer>. Please use our new docs.
