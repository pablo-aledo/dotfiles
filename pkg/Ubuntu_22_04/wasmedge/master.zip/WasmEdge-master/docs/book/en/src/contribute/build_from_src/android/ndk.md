# Call WasmEdge functions from an NDK native app

> *This part has moved to <https://wasmedge.org/docs/contribute/source/os/android/ndk>. Please use our new docs.*
