# Contribution Steps

> This part has been moved to  <https://wasmedge.org/docs/contribute/>. Please use our new docs.
