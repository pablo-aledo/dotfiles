# Quick Start with JavaScript on WasmEdge

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/hello_world>. Please use our new docs.
