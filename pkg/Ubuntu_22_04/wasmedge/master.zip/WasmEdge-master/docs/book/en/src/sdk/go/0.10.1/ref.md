# WasmEdge Go v0.10.1 API references

> This part has been moved to  <https://wasmedge.org/docs/embed/go/reference/0.10.x>. Please use our new docs.
