# Build WasmEdge With WasmEdge-Process Plug-in

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/plugin/process>. Please use our new docs.
