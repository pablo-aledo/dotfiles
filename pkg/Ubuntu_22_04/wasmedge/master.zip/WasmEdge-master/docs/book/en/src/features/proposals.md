# Supported WASM And WASI Proposals

> This part has been moved to <https://wasmedge.org/docs/start/wasmedge/extensions/proposals>. Please use our new docs.