# Supported Platforms

> This part has been moved to <https://wasmedge.org/docs/start/wasmedge/features#cross-platform>. Please use our new docs.
