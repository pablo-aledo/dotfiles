# Use the WasmEdge Library

> This part has been moved to  <https://wasmedge.org/docs/embed/c/library>. Please use our new docs.
