# TensorFlow

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/tensorflow>. Please use our new docs.
