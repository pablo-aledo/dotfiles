# Upgrade to WasmEdge 0.11.0

> This part has been moved to  <https://wasmedge.org/docs/embed/c/reference/upgrade_to_0.11.0>. Please use our new docs.
