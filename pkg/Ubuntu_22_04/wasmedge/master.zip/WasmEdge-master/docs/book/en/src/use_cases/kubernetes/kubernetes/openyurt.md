# OpenYurt + containerd + crun

This part has been moved to <https://wasmedge.org/docs/develop/deploy/kubernetes/openyurt>. Please use our new docs.
