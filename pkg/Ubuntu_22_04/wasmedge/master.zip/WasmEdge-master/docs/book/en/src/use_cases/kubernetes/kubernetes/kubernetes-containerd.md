# Kubernetes + containerd

> This part has been moved to <https://wasmedge.org/docs/develop/deploy/kubernetes/kubernetes-containerd-crun>. Please use or new docs