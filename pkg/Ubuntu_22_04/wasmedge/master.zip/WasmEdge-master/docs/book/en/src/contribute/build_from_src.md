# Build WasmEdge from source

> This part has been moved to <https://wasmedge.org/docs/contribute/source/build_from_src>. Please use our new docs.
