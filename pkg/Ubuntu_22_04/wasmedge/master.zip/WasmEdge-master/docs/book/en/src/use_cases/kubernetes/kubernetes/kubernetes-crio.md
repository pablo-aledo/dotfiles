# Kubernetes + CRI-O

This doc has move to <https://wasmedge.org/docs/develop/deploy/kubernetes/kubernetes-cri-o>. Please use our new docs.
