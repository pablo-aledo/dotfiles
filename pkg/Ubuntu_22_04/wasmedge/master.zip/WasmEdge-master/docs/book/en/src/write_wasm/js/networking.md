# HTTP and networking apps

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/networking>. Please use our new docs.
