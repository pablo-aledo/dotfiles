# Serverless platforms

> This part has been moved to <https://wasmedge.org/docs/category/use-cases>. Please use our new docs.
