# WasmEdge C 0.12.0 API Documentation

> This part has been moved to  <https://wasmedge.org/docs/embed/c/reference/0.12.x>. Please use our new docs.
