# Build WasmEdge for Android

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/android/build>. Please use our new docs.
