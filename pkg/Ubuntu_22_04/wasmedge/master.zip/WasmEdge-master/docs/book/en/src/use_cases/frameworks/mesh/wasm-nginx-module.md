# wasm-nginx-module

> This part has been moved to <https://wasmedge.org/docs/embed/use-case/wasm-nginx>. Please use our new docs.