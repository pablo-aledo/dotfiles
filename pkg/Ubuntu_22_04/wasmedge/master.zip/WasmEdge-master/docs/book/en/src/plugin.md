# Develop WasmEdge Plug-in

> This Part has been moved to <https://wasmedge.org/docs/contribute/plugin/intro>, Please use our new docs..
