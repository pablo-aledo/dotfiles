# Tensorflow

This  part has moved to <https://wasmedge.org/docs/embed/go/ai>. Please use our new docs.
