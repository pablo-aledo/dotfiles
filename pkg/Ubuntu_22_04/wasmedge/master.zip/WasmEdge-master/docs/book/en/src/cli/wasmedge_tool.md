# `wasmedge run` CLI

> This part has been moved to <https://wasmedge.org/docs/start/build-and-run/run>. Please use our new docs.
