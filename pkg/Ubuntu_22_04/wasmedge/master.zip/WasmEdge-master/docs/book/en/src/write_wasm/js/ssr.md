# React SSR

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/ssr>. Please use our new docs.
