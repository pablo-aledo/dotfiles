# Pass complex parameters to Wasm functions

> This part has been moved to  <https://wasmedge.org/docs/embed/go/passing_data>. Please use pur new docs.
