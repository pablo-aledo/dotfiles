# Develop WasmEdge Plug-in in C++ API

This part has been moved to <https://wasmedge.org/docs/contribute/plugin/develop_plugin_cpp>. Please use our new docs.
