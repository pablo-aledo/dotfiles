# Host Functions

> This part has been moved to  <https://wasmedge.org/docs/embed/c/host_function>. Please use our new docs.
