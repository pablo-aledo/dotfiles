# Upgrade to WasmEdge 0.12.0

Thias part has moved to <https://wasmedge.org/docs/embed/c/reference/upgrade_to_0.12.0>. Please use our new docs.
