# Embed a bindgen function

> This part has been moved to  <https://wasmedge.org/docs/embed/go/bindgen>. Please use our new docs.
