# System modules

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/modules>. Please use our new docs.
