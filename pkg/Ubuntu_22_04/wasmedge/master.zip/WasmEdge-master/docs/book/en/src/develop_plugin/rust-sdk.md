# Develop Plugin Rust SDK with witc

> This part has been moved to <https://wasmedge.org/docs/contribute/plugin/develop_plugin_rustsdk/>. Please use our new docs.
