# WasmEdge Go SDK

> This part has been moved to <https://wasmedge.org/docs/embed/go/intro>. Please use our new doc.
