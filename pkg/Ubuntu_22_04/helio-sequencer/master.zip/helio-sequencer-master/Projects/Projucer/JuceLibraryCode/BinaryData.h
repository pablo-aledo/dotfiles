/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#pragma once

namespace BinaryData
{
    extern const char*   annotation_svg;
    const int            annotation_svgSize = 309;

    extern const char*   apply_svg;
    const int            apply_svgSize = 271;

    extern const char*   arpeggiate_svg;
    const int            arpeggiate_svgSize = 252;

    extern const char*   audioPlugin_svg;
    const int            audioPlugin_svgSize = 436;

    extern const char*   automationTrack_svg;
    const int            automationTrack_svgSize = 916;

    extern const char*   back_svg;
    const int            back_svgSize = 294;

    extern const char*   bottomBar_svg;
    const int            bottomBar_svgSize = 198;

    extern const char*   browse_svg;
    const int            browse_svgSize = 252;

    extern const char*   chordBuilder_svg;
    const int            chordBuilder_svgSize = 829;

    extern const char*   cleanup_svg;
    const int            cleanup_svgSize = 324;

    extern const char*   close_svg;
    const int            close_svgSize = 400;

    extern const char*   colour_svg;
    const int            colour_svgSize = 480;

    extern const char*   commit_svg;
    const int            commit_svgSize = 235;

    extern const char*   console_svg;
    const int            console_svgSize = 441;

    extern const char*   copy_svg;
    const int            copy_svgSize = 1250;

    extern const char*   create_svg;
    const int            create_svgSize = 339;

    extern const char*   cropTool_svg;
    const int            cropTool_svgSize = 143;

    extern const char*   cursorTool_svg;
    const int            cursorTool_svgSize = 267;

    extern const char*   cut_svg;
    const int            cut_svgSize = 503;

    extern const char*   cutterTool_svg;
    const int            cutterTool_svgSize = 437;

    extern const char*   down_svg;
    const int            down_svgSize = 291;

    extern const char*   dragTool_svg;
    const int            dragTool_svgSize = 672;

    extern const char*   drawTool_svg;
    const int            drawTool_svgSize = 734;

    extern const char*   ellipsis_svg;
    const int            ellipsis_svgSize = 458;

    extern const char*   expand_svg;
    const int            expand_svgSize = 339;

    extern const char*   fail_svg;
    const int            fail_svgSize = 400;

    extern const char*   forward_svg;
    const int            forward_svgSize = 296;

    extern const char*   github_svg;
    const int            github_svgSize = 1559;

    extern const char*   helio_svg;
    const int            helio_svgSize = 950;

    extern const char*   instrument_svg;
    const int            instrument_svgSize = 1617;

    extern const char*   instrumentNode_svg;
    const int            instrumentNode_svgSize = 601;

    extern const char*   inverseDown_svg;
    const int            inverseDown_svgSize = 307;

    extern const char*   inverseUp_svg;
    const int            inverseUp_svgSize = 305;

    extern const char*   inversion_svg;
    const int            inversion_svgSize = 527;

    extern const char*   legato_svg;
    const int            legato_svgSize = 361;

    extern const char*   list_svg;
    const int            list_svgSize = 528;

    extern const char*   local_svg;
    const int            local_svgSize = 495;

    extern const char*   lockZoom_svg;
    const int            lockZoom_svgSize = 250;

    extern const char*   meter_svg;
    const int            meter_svgSize = 221;

    extern const char*   metronome_svg;
    const int            metronome_svgSize = 556;

    extern const char*   mute_svg;
    const int            mute_svgSize = 707;

    extern const char*   orchestraPit_svg;
    const int            orchestraPit_svgSize = 1617;

    extern const char*   paint_svg;
    const int            paint_svgSize = 288;

    extern const char*   paste_svg;
    const int            paste_svgSize = 1578;

    extern const char*   patterns_svg;
    const int            patterns_svgSize = 134;

    extern const char*   pause_svg;
    const int            pause_svgSize = 297;

    extern const char*   piano_svg;
    const int            piano_svgSize = 321;

    extern const char*   pianoTrack_svg;
    const int            pianoTrack_svgSize = 745;

    extern const char*   play_svg;
    const int            play_svgSize = 219;

    extern const char*   progressIndicator_svg;
    const int            progressIndicator_svgSize = 2388;

    extern const char*   project_svg;
    const int            project_svgSize = 1390;

    extern const char*   pull_svg;
    const int            pull_svgSize = 334;

    extern const char*   push_svg;
    const int            push_svgSize = 199;

    extern const char*   record_svg;
    const int            record_svgSize = 143;

    extern const char*   redo_svg;
    const int            redo_svgSize = 266;

    extern const char*   refactor_svg;
    const int            refactor_svgSize = 981;

    extern const char*   remote_svg;
    const int            remote_svgSize = 351;

    extern const char*   remove_svg;
    const int            remove_svgSize = 370;

    extern const char*   render_svg;
    const int            render_svgSize = 2029;

    extern const char*   reprise_svg;
    const int            reprise_svgSize = 199;

    extern const char*   reset_svg;
    const int            reset_svgSize = 435;

    extern const char*   retrograde_svg;
    const int            retrograde_svgSize = 317;

    extern const char*   revision_svg;
    const int            revision_svgSize = 584;

    extern const char*   routing_svg;
    const int            routing_svgSize = 601;

    extern const char*   selectionTool_svg;
    const int            selectionTool_svgSize = 1265;

    extern const char*   selection_svg;
    const int            selection_svgSize = 1140;

    extern const char*   selectAll_svg;
    const int            selectAll_svgSize = 1351;

    extern const char*   selectNone_svg;
    const int            selectNone_svgSize = 1460;

    extern const char*   settings_svg;
    const int            settings_svgSize = 1058;

    extern const char*   snap_svg;
    const int            snap_svgSize = 541;

    extern const char*   staccato_svg;
    const int            staccato_svgSize = 208;

    extern const char*   stop_svg;
    const int            stop_svgSize = 227;

    extern const char*   stretchLeft_svg;
    const int            stretchLeft_svgSize = 294;

    extern const char*   stretchRight_svg;
    const int            stretchRight_svgSize = 296;

    extern const char*   submenu_svg;
    const int            submenu_svgSize = 296;

    extern const char*   success_svg;
    const int            success_svgSize = 271;

    extern const char*   tag_svg;
    const int            tag_svgSize = 407;

    extern const char*   timelineNext_svg;
    const int            timelineNext_svgSize = 322;

    extern const char*   timelinePrevious_svg;
    const int            timelinePrevious_svgSize = 260;

    extern const char*   toggleOff_svg;
    const int            toggleOff_svgSize = 600;

    extern const char*   toggleOn_svg;
    const int            toggleOn_svgSize = 441;

    extern const char*   trackGroup_svg;
    const int            trackGroup_svgSize = 227;

    extern const char*   undo_svg;
    const int            undo_svgSize = 252;

    extern const char*   unmute_svg;
    const int            unmute_svgSize = 1401;

    extern const char*   up_svg;
    const int            up_svgSize = 294;

    extern const char*   versionControl_svg;
    const int            versionControl_svgSize = 847;

    extern const char*   volume_svg;
    const int            volume_svgSize = 179;

    extern const char*   volumePanel_svg;
    const int            volumePanel_svgSize = 250;

    extern const char*   zoomIn_svg;
    const int            zoomIn_svgSize = 623;

    extern const char*   zoomOut_svg;
    const int            zoomOut_svgSize = 537;

    extern const char*   zoomToFit_svg;
    const int            zoomToFit_svgSize = 498;

    extern const char*   noise_png;
    const int            noise_pngSize = 149;

    extern const char*   stripes_png;
    const int            stripes_pngSize = 162;

    extern const char*   copyingCursor_gif;
    const int            copyingCursor_gifSize = 119;

    extern const char*   erasingCursor_gif;
    const int            erasingCursor_gifSize = 116;

    extern const char*   builtInMetronome1_wav;
    const int            builtInMetronome1_wavSize = 15472;

    extern const char*   builtInMetronome2_wav;
    const int            builtInMetronome2_wavSize = 15420;

    extern const char*   builtInMetronome3_wav;
    const int            builtInMetronome3_wavSize = 15420;

    extern const char*   builtInMetronome4_wav;
    const int            builtInMetronome4_wavSize = 15420;

    extern const char*   emptyProject_json;
    const int            emptyProject_jsonSize = 885;

    extern const char*   exampleProject_json;
    const int            exampleProject_jsonSize = 3285;

    extern const char*   logov2_png;
    const int            logov2_pngSize = 7326;

    extern const char*   logov2mac_png;
    const int            logov2mac_pngSize = 18403;

    extern const char*   arpeggiators_json;
    const int            arpeggiators_jsonSize = 64;

    extern const char*   chords_json;
    const int            chords_jsonSize = 768;

    extern const char*   colourSchemes_json;
    const int            colourSchemes_jsonSize = 3866;

    extern const char*   hotkeySchemes_json;
    const int            hotkeySchemes_jsonSize = 16633;

    extern const char*   keyboardMappings_json;
    const int            keyboardMappings_jsonSize = 792;

    extern const char*   meters_json;
    const int            meters_jsonSize = 933;

    extern const char*   scales_json;
    const int            scales_jsonSize = 10616;

    extern const char*   temperaments_json;
    const int            temperaments_jsonSize = 2856;

    extern const char*   translations_json;
    const int            translations_jsonSize = 95572;

    // Number of elements in the namedResourceList and originalFileNames arrays.
    const int namedResourceListSize = 112;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Points to the start of a list of resource filenames.
    extern const char* originalFilenames[];

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes);

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding original, non-mangled filename (or a null pointer if the name isn't found).
    const char* getNamedResourceOriginalFilename (const char* resourceNameUTF8);
}
