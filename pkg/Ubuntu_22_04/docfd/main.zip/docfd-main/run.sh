./_build/default/bin/docfd.exe "$@"
