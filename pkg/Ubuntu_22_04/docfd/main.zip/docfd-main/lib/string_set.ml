include CCSet.Make (String)
