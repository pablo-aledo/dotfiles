let ( let* ) = Option.bind

let ( let+ ) x y = Option.map y x
