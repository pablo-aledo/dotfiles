include CCMap.Make (Char)
