include CCMap.Make (String)
