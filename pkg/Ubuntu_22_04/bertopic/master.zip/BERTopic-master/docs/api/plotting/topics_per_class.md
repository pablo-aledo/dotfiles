# `Topics per Class`

::: bertopic.plotting._topics_per_class.visualize_topics_per_class
