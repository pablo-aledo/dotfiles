# `Distribution`

::: bertopic.plotting._distribution.visualize_distribution
