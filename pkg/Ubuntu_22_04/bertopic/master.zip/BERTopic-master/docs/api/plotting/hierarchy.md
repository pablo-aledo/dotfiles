# `Hierarchy`

::: bertopic.plotting._hierarchy.visualize_hierarchy
