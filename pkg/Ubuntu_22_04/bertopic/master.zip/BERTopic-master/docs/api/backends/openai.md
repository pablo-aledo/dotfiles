# `OpenAIBackend`

::: bertopic.backend._openai.OpenAIBackend
