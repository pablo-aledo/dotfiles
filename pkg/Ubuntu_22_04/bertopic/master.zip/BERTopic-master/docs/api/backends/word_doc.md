# `WordDocEmbedder`

::: bertopic.backend._word_doc.WordDocEmbedder
