# `CohereBackend`

::: bertopic.backend._cohere.CohereBackend
