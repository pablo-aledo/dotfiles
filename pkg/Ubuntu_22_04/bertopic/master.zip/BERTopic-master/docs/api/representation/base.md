# `BaseRepresentation`

::: bertopic.representation._base.BaseRepresentation
