# `Cohere`

::: bertopic.representation._cohere.Cohere
