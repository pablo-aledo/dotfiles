# `ZeroShotClassification`

::: bertopic.representation._zeroshot.ZeroShotClassification
