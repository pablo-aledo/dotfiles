# `PartOfSpeech`

::: bertopic.representation._pos.PartOfSpeech
