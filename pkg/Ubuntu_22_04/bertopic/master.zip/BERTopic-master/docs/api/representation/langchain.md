# `LangChain`

::: bertopic.representation._langchain.LangChain
