# `OpenAI`

::: bertopic.representation.OpenAI
