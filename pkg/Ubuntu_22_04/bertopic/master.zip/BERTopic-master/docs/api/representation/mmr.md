# `MaximalMarginalRelevance`

::: bertopic.representation._mmr.MaximalMarginalRelevance
