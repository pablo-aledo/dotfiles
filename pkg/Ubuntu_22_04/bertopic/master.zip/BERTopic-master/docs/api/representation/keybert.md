# `KeyBERTInspired`

::: bertopic.representation._keybert.KeyBERTInspired
