# `TextGeneration`

::: bertopic.representation._textgeneration.TextGeneration
