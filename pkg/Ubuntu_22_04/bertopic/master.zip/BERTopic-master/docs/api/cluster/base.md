# `BaseCluster`

::: bertopic.cluster._base.BaseCluster
