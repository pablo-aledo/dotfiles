# `OnlineCountVectorizer`

::: bertopic.vectorizers.OnlineCountVectorizer
