This directory contains mostly future work on an improved analysis backend. Only a fractions of this code is being used. For the current analysis backend implementation, See `src/analysis.zig`.
