def hello_world() -> str:
    return "Hello world from package F!"
