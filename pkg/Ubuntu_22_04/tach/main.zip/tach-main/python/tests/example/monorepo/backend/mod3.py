from __future__ import annotations

from mod2 import y

y
