from __future__ import annotations

from tach.logging.logger import LogDataModel, logger

__all__ = ["logger", "LogDataModel"]
