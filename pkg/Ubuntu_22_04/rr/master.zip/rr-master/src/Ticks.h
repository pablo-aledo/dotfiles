/* -*- Mode: C++; tab-width: 8; c-basic-offset: 2; indent-tabs-mode: nil; -*- */

#ifndef RR_TICKS_H_
#define RR_TICKS_H_

#include <stdint.h>

namespace rr {

typedef int64_t Ticks;

} // namespace rr

#endif /* RR_TICKS_H_ */
