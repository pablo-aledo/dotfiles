# Screenshots

### Status View
![Screenshot](./grv-status-view.png)

### Commit Graph
![Screenshot](./grv-commit-graph.png)

### Fancy Diff Format
![Screenshot](./grv-fancy-diff.png)

### Modify Repository
![Screenshot](./grv-available-actions.png)

### Vertical Split
![Screenshot](./grv-commit-views.png)

### Custom tab comprised of all views currently available in GRV
![Screenshot](./grv-custom-view.png)

### Classic Theme
![Screenshot](./grv-classic-theme.png)

### Old Demo
![Demo](./grv.gif)
