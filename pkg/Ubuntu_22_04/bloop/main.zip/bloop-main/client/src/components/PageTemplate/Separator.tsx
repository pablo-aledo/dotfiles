const Separator = () => {
  return <div className="mx-3 w-px h-3 bg-bg-border-hover" />;
};

export default Separator;
