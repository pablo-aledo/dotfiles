const ThreeDotsLoader = () => {
  return (
    <div className="h-[1.5em]">
      <div className="three-dots-loader" />
    </div>
  );
};

export default ThreeDotsLoader;
