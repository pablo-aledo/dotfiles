export const EMAIL_REGEX = /^[\w-.+]+@([\w-]+\.)+[\w-]{2,8}$/;
