pub enum CursorType {
    Bar,
    BlinkingBar,
    Block,
}
