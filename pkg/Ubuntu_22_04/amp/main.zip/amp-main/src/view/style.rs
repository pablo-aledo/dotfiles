#[derive(Copy, Clone, Debug, PartialEq, Default)]
pub enum Style {
    #[default]
    Default,
    Bold,
    Inverted,
    Italic,
}
