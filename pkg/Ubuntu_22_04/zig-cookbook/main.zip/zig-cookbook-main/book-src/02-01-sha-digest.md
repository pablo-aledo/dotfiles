## Calculate SHA-256 digest of a file

There are many crypto algorithm implementations in std, `sha256`, `md5` are supported out of box.

```zig
{{#include ../src/02-01.zig }}
```
