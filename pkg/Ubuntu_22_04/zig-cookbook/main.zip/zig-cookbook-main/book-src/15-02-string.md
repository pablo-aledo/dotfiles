# String Parsing

## String to number/enum

```zig
{{#include ../src/15-02.zig }}
```
