from .parser import parse_profile

__all__ = ["parse_profile"]
