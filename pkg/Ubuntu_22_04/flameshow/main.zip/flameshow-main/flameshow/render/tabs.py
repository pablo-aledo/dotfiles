from textual.widgets import Tabs


class SampleTabs(Tabs, can_focus=False):
    pass
