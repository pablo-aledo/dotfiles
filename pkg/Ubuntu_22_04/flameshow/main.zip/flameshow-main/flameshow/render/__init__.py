from .app import FlameshowApp

__all__ = ["FlameshowApp"]
