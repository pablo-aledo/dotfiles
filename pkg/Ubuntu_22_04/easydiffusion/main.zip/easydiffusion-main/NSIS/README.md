Scripts to be used with the Nullsoft Scriptable Installation System
