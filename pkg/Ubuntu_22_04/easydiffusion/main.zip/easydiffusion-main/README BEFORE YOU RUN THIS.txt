Hi there,

What you have downloaded is meant for the developers of this project, not for users.

If you only want to use the Stable Diffusion UI, you've downloaded the wrong file.
Please download and follow the instructions at https://github.com/easydiffusion/easydiffusion#installation

Thanks