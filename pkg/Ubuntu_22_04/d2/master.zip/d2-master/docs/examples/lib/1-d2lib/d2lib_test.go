package main

import (
	"testing"
)

func TestMain_(t *testing.T) {
	main()
}
