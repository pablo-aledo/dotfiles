#### Features 🚀

#### Improvements 🧹

#### Bugfixes ⛑️

---

For the latest d2.js changes, see separate [changelog](https://github.com/terrastruct/d2/blob/master/d2js/js/CHANGELOG.md).
