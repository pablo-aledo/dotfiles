//go:build dev
// +build dev

package d2cli

func init() {
	devMode = true
}
