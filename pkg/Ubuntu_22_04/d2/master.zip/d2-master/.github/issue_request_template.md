<!-- Please title the issue with a scope prefix like cli: improve performance. -->
<!-- Please add screenshots or screencasts for ui/autolayout issues. -->
