// Package d2compiler implements a parser, compiler and autoformatter for the Terrastruct d2
// diagramming language.
package d2compiler
