var setTimeout = function(f) {f()};
const elk = new ELK();
