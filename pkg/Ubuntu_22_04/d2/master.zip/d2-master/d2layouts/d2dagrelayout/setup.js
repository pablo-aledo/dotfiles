var g = new dagre.graphlib.Graph({ compound: true, multigraph: true });
g.setDefaultNodeLabel(function () {
  return {};
});
g.setDefaultEdgeLabel(function () {
  return {};
});
