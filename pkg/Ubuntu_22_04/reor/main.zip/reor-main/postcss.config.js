module.exports = {
  plugins: [
    require("tailwindcss"),
    require("autoprefixer"),
    // Other PostCSS plugins you want to use, if any
  ],
};
