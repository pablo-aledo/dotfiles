use regex::Regex;
use std::borrow::Cow;
use std::collections::BTreeMap;
use std::sync::OnceLock;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct SvgDomNode {
    pub(crate) name: String,
    pub(crate) attrs: BTreeMap<String, String>,
    pub(crate) text: Option<String>,
    pub(crate) children: Vec<SvgDomNode>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum DomMode {
    Strict,
    Structure,
    Parity,
    ParityRoot,
}

impl DomMode {
    pub(crate) fn parse(s: &str) -> Self {
        match s {
            "strict" => Self::Strict,
            "parity" => Self::Parity,
            "parity-root" | "parity_root" => Self::ParityRoot,
            _ => Self::Structure,
        }
    }
}

fn round_f64(v: f64, decimals: u32) -> f64 {
    let p = 10_f64.powi(decimals as i32);
    (v * p).round() / p
}

fn normalize_data_points_base64_json(s: &str, decimals: u32) -> Option<String> {
    use base64::Engine as _;

    fn round_json_numbers(value: &mut serde_json::Value, decimals: u32) {
        match value {
            serde_json::Value::Number(n) => {
                let Some(v) = n.as_f64() else {
                    return;
                };
                let r = round_f64(v, decimals);
                if let Some(new_n) = serde_json::Number::from_f64(r) {
                    *n = new_n;
                }
            }
            serde_json::Value::Array(arr) => {
                for v in arr {
                    round_json_numbers(v, decimals);
                }
            }
            serde_json::Value::Object(map) => {
                for (_, v) in map.iter_mut() {
                    round_json_numbers(v, decimals);
                }
            }
            _ => {}
        }
    }

    let bytes = base64::engine::general_purpose::STANDARD
        .decode(s.as_bytes())
        .ok()?;
    let mut json = serde_json::from_slice::<serde_json::Value>(&bytes).ok()?;
    round_json_numbers(&mut json, decimals);
    let out = serde_json::to_string(&json).ok()?;
    Some(base64::engine::general_purpose::STANDARD.encode(out.as_bytes()))
}

fn re_num() -> &'static Regex {
    static ONCE: OnceLock<Regex> = OnceLock::new();
    ONCE.get_or_init(|| Regex::new(r"-?(?:\d+\.\d+|\d+\.|\.\d+|\d+)(?:[eE][+-]?\d+)?").unwrap())
}

fn normalize_numeric_tokens(s: &str, decimals: u32) -> String {
    re_num()
        .replace_all(s, |caps: &regex::Captures<'_>| {
            let raw = caps.get(0).map(|m| m.as_str()).unwrap_or_default();
            let Ok(v) = raw.parse::<f64>() else {
                return raw.to_string();
            };
            let r = round_f64(v, decimals);
            let r = if r == 0.0 { 0.0 } else { r };
            let mut out = format!("{r}");
            if out.contains('.') {
                while out.ends_with('0') {
                    out.pop();
                }
                if out.ends_with('.') {
                    out.pop();
                }
            }
            out
        })
        .to_string()
}

fn normalize_numeric_tokens_mode(s: &str, decimals: u32, mode: DomMode) -> String {
    match mode {
        DomMode::Strict | DomMode::Parity | DomMode::ParityRoot => {
            normalize_numeric_tokens(s, decimals)
        }
        DomMode::Structure => re_num().replace_all(s, "<n>").to_string(),
    }
}

fn extract_style_prop_value(style: &str, prop_name: &str) -> Option<String> {
    let target = prop_name.trim().to_ascii_lowercase();
    if target.is_empty() {
        return None;
    }

    for decl in style.split(';') {
        let decl = decl.trim();
        if decl.is_empty() {
            continue;
        }
        let (k, v) = decl.split_once(':')?;
        if k.trim().to_ascii_lowercase() != target {
            continue;
        }
        let v = v.trim();
        if v.is_empty() {
            return None;
        }
        return Some(v.to_string());
    }
    None
}

fn normalize_style_font_size_for_parity(style: &str, decimals: u32) -> Option<String> {
    let v = extract_style_prop_value(style, "font-size")?;
    let v = normalize_numeric_tokens(&v, decimals);
    Some(format!("font-size:{v}"))
}

fn normalize_svg_root_style_parity_root(style: &str, decimals: u32) -> String {
    // Root `style` includes `max-width: <n>px`, which is sensitive to tiny FP drift across
    // targets/platforms (e.g. 1/64px). To keep CI parity stable while still tracking meaningful
    // regressions, snap `max-width` to a small pixel lattice.
    let step = 1.0 / 4.0; // 0.25px: collapses common subpixel drift across platforms.
    let eps = 1e-9; // Avoid float edge cases at exact step boundaries.
    // Biased snapping: use a threshold slightly above the midpoint between lattice steps so
    // values that drift just above the midpoint (common on some platforms) still normalize to the
    // lower step. This is more robust than pure `round` (midpoint splits) and less lossy than
    // always flooring (boundary splits around exact step values).
    //
    // Threshold interpretation:
    // - `0.5` would be true "round to nearest".
    // - `> 0.5` biases toward the lower step.
    // With `step=0.125`, `0.62` corresponds to ~0.015px above the midpoint, matching typical
    // 1/64px drift seen in CI for Mermaid root viewport values.
    let frac_threshold = 0.62;

    let re = {
        static ONCE: OnceLock<Regex> = OnceLock::new();
        ONCE.get_or_init(|| Regex::new(r#"max-width:\s*([0-9.]+)px"#).unwrap())
    };

    re.replace_all(style, |caps: &regex::Captures<'_>| {
        let raw = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
        let Ok(v) = raw.parse::<f64>() else {
            return caps
                .get(0)
                .map(|m| m.as_str())
                .unwrap_or_default()
                .to_string();
        };
        // Snap to the lattice with a slight bias toward the lower bucket to avoid platform
        // drift flipping the signature across the midpoint.
        let q = (v / step) + eps;
        let base = q.floor();
        let frac = q - base;
        let snapped = if frac >= frac_threshold {
            (base + 1.0) * step
        } else {
            base * step
        };
        let snapped = round_f64(snapped, decimals);
        let snapped = if snapped == 0.0 { 0.0 } else { snapped };
        let mut out = format!("{snapped}");
        if out.contains('.') {
            while out.ends_with('0') {
                out.pop();
            }
            if out.ends_with('.') {
                out.pop();
            }
        }
        format!("max-width: {out}px")
    })
    .to_string()
}

fn normalize_svg_root_viewbox_parity_root(view_box: &str, decimals: u32) -> String {
    // Root `viewBox` is affected by label measurements and can drift by tiny fractions across
    // platforms (commonly 1/64px). Snap to a small lattice to keep CI parity stable while still
    // tracking meaningful viewport changes.
    let step = 1.0 / 4.0; // 0.25px: collapses common subpixel drift across platforms.
    let eps = 1e-9;
    let frac_threshold = 0.62;

    let parts: Vec<&str> = view_box
        .split(|c: char| c.is_whitespace() || c == ',')
        .filter(|t| !t.is_empty())
        .collect();
    if parts.len() != 4 {
        return normalize_numeric_tokens(view_box, decimals);
    }

    let mut out_parts: Vec<String> = Vec::with_capacity(4);
    for (idx, p) in parts.into_iter().enumerate() {
        let Ok(v) = p.parse::<f64>() else {
            return normalize_numeric_tokens(view_box, decimals);
        };

        // In parity-root comparisons we mainly care about the viewport size (w/h). The origin
        // (x/y) is frequently affected by transform-list rounding and platform-specific `getBBox`
        // behavior, and tends to create noisy diffs that don't correlate with meaningful
        // regressions. Mask x/y to keep CI stable while still tracking size changes.
        if idx == 0 || idx == 1 {
            out_parts.push("<n>".to_string());
            continue;
        }

        // Snap w/h with the same biased lattice as `max-width`.
        let q = (v / step) + eps;
        let base = q.floor();
        let frac = q - base;
        let snapped = if frac >= frac_threshold {
            (base + 1.0) * step
        } else {
            base * step
        };

        let snapped = round_f64(snapped, decimals);
        let snapped = if snapped == 0.0 { 0.0 } else { snapped };
        let mut s = format!("{snapped}");
        if s.contains('.') {
            while s.ends_with('0') {
                s.pop();
            }
            if s.ends_with('.') {
                s.pop();
            }
        }
        out_parts.push(s);
    }

    out_parts.join(" ")
}

fn normalize_attr_whitespace_strict(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut prev_space = true;
    for ch in s.chars() {
        if ch.is_whitespace() {
            if !prev_space {
                out.push(' ');
                prev_space = true;
            }
        } else {
            out.push(ch);
            prev_space = false;
        }
    }
    out.trim().to_string()
}

fn normalize_transform_attr(s: &str) -> String {
    // SVG transform lists allow arbitrary whitespace and optional commas between numeric
    // arguments. For DOM comparisons we treat whitespace around commas as non-semantic.
    //
    // Examples that should compare equal:
    // - `translate(1,2)` vs `translate(1, 2)`
    // - `translate(1 ,  2)` vs `translate(1,2)`
    // - `matrix(1 0 0 1 0 0)` (whitespace separators must be preserved, just normalized)
    let mut out = String::with_capacity(s.len());
    let mut pending_space = false;
    let mut it = s.chars().peekable();
    while let Some(ch) = it.next() {
        if ch.is_whitespace() {
            pending_space = true;
            continue;
        }
        if ch == '(' {
            if out.ends_with(' ') {
                out.pop();
            }
            out.push('(');
            pending_space = false;
            while it.peek().is_some_and(|c| c.is_whitespace()) {
                it.next();
            }
            continue;
        }
        if ch == ')' {
            if out.ends_with(' ') {
                out.pop();
            }
            out.push(')');
            pending_space = false;
            continue;
        }
        if ch == ',' {
            if out.ends_with(' ') {
                out.pop();
            }
            out.push(',');
            pending_space = false;
            while it.peek().is_some_and(|c| c.is_whitespace()) {
                it.next();
            }
            continue;
        }
        if pending_space {
            if !out.is_empty() && !out.ends_with(' ') {
                out.push(' ');
            }
            pending_space = false;
        }
        out.push(ch);
    }
    out.trim().to_string()
}

fn is_identifier_like_attr(key: &str) -> bool {
    matches!(
        key,
        "id" | "data-id"
            | "href"
            | "xlink:href"
            | "title"
            | "aria-labelledby"
            | "aria-describedby"
            | "aria-label"
            | "aria-roledescription"
    )
}

fn re_trailing_counter() -> &'static Regex {
    static ONCE: OnceLock<Regex> = OnceLock::new();
    ONCE.get_or_init(|| Regex::new(r"([_-])\d+$").unwrap())
}

fn re_mermaid_generate_id() -> &'static Regex {
    static ONCE: OnceLock<Regex> = OnceLock::new();
    ONCE.get_or_init(|| Regex::new(r"id-[a-z0-9]+-\d+").unwrap())
}

fn re_mermaid_generate_id_capture() -> &'static Regex {
    static ONCE: OnceLock<Regex> = OnceLock::new();
    ONCE.get_or_init(|| Regex::new(r"id-[a-z0-9]+-(\d+)").unwrap())
}

fn re_gitgraph_dynamic_commit_id() -> &'static Regex {
    static ONCE: OnceLock<Regex> = OnceLock::new();
    ONCE.get_or_init(|| Regex::new(r"\b(\d+)-[0-9a-f]{7}\b").unwrap())
}

fn normalize_gitgraph_dynamic_commit_ids(s: &str) -> String {
    re_gitgraph_dynamic_commit_id()
        .replace_all(s, "$1-<dynamic>")
        .to_string()
}

fn normalize_identifier_tokens(s: &str) -> String {
    let s = re_mermaid_generate_id()
        .replace_all(s, "id-<id>-<n>")
        .to_string();
    re_trailing_counter().replace(&s, "$1<n>").to_string()
}

fn normalize_mermaid_generated_id_only(s: &str) -> String {
    re_mermaid_generate_id_capture()
        .replace_all(s, "id-<id>-$1")
        .to_string()
}

fn normalize_class_list(s: &str, mode: DomMode) -> String {
    let mut parts: Vec<String> = s
        .split_whitespace()
        .map(|t| {
            if mode != DomMode::Strict && t.starts_with("width-") {
                let suffix = &t["width-".len()..];
                if suffix.parse::<f64>().is_ok() {
                    return "width-<n>".to_string();
                }
            }
            t.to_string()
        })
        .collect();
    parts.sort_unstable();
    parts.dedup();
    parts.join(" ")
}

fn is_geometry_attr(name: &str) -> bool {
    matches!(
        name,
        "transform"
            | "d"
            | "points"
            | "x"
            | "y"
            | "x1"
            | "y1"
            | "x2"
            | "y2"
            | "cx"
            | "cy"
            | "r"
            | "rx"
            | "ry"
            | "width"
            | "height"
    )
}

fn build_node(n: roxmltree::Node<'_, '_>, mode: DomMode, decimals: u32) -> SvgDomNode {
    let mut attrs: BTreeMap<String, String> = BTreeMap::new();

    fn is_block_diagram(n: roxmltree::Node<'_, '_>) -> bool {
        for a in n.ancestors() {
            if a.is_element() && a.tag_name().name() == "svg" {
                return a
                    .attribute("aria-roledescription")
                    .is_some_and(|v| v == "block");
            }
        }
        false
    }

    fn is_architecture_diagram(n: roxmltree::Node<'_, '_>) -> bool {
        for a in n.ancestors() {
            if a.is_element() && a.tag_name().name() == "svg" {
                return a
                    .attribute("aria-roledescription")
                    .is_some_and(|v| v == "architecture");
            }
        }
        false
    }

    fn architecture_diagram_id(n: roxmltree::Node<'_, '_>) -> Option<String> {
        for a in n.ancestors() {
            if a.is_element()
                && a.tag_name().name() == "svg"
                && a.attribute("aria-roledescription")
                    .is_some_and(|v| v == "architecture")
            {
                return a.attribute("id").map(str::to_string);
            }
        }
        None
    }

    fn normalize_architecture_scoped_dom_id(n: roxmltree::Node<'_, '_>, val: &str) -> String {
        let Some(diagram_id) = architecture_diagram_id(n) else {
            return val.to_string();
        };
        for kind in ["service", "node", "group"] {
            let prefix = format!("{diagram_id}-{kind}-");
            if let Some(rest) = val.strip_prefix(&prefix) {
                return format!("{kind}-{rest}");
            }
        }
        val.to_string()
    }

    fn is_sankey_diagram(n: roxmltree::Node<'_, '_>) -> bool {
        for a in n.ancestors() {
            if a.is_element() && a.tag_name().name() == "svg" {
                return a
                    .attribute("aria-roledescription")
                    .is_some_and(|v| v == "sankey");
            }
        }
        false
    }

    fn sankey_diagram_id(n: roxmltree::Node<'_, '_>) -> Option<String> {
        for a in n.ancestors() {
            if a.is_element()
                && a.tag_name().name() == "svg"
                && a.attribute("aria-roledescription")
                    .is_some_and(|v| v == "sankey")
            {
                return a.attribute("id").map(str::to_string);
            }
        }
        None
    }

    fn normalize_sankey_scoped_dom_value(n: roxmltree::Node<'_, '_>, val: &str) -> String {
        let Some(diagram_id) = sankey_diagram_id(n) else {
            return val.to_string();
        };
        let node_prefix = format!("{diagram_id}-node-");
        let gradient_prefix = format!("{diagram_id}-linearGradient-");
        val.replace(&node_prefix, "node-")
            .replace(&gradient_prefix, "linearGradient-")
    }

    if n.is_element() {
        fn is_mindmap_diagram(n: roxmltree::Node<'_, '_>) -> bool {
            for a in n.ancestors() {
                if a.is_element() && a.tag_name().name() == "svg" {
                    return a
                        .attribute("class")
                        .is_some_and(|c| c.split_whitespace().any(|t| t == "mindmapDiagram"));
                }
            }
            false
        }

        fn is_architecture_icon_content(n: roxmltree::Node<'_, '_>) -> bool {
            let mut svg_count = 0;
            for a in n.ancestors() {
                if a.is_element() && a.tag_name().name() == "svg" {
                    svg_count += 1;
                    if svg_count >= 2 {
                        break;
                    }
                }
            }
            if svg_count < 2 {
                return false;
            }
            n.ancestors().any(|a| {
                a.is_element()
                    && a.tag_name().name() == "g"
                    && a.attribute("class").is_some_and(|c| {
                        c.split_whitespace().any(|t| {
                            t == "architecture-service"
                                || t == "architecture-groups"
                                || t == "architecture-group"
                        })
                    })
            })
        }

        fn has_class_token(n: roxmltree::Node<'_, '_>, token: &str) -> bool {
            n.attribute("class")
                .is_some_and(|c| c.split_whitespace().any(|t| t == token))
        }

        fn is_architecture_edge_arrow(n: roxmltree::Node<'_, '_>) -> bool {
            if !(n.tag_name().name() == "polygon" && has_class_token(n, "arrow")) {
                return false;
            }

            let mut in_architecture_svg = false;
            let mut in_architecture_edges = false;
            for a in n.ancestors() {
                if !a.is_element() {
                    continue;
                }
                if a.tag_name().name() == "svg"
                    && a.attribute("aria-roledescription")
                        .is_some_and(|v| v == "architecture")
                {
                    in_architecture_svg = true;
                }
                if a.tag_name().name() == "g" && has_class_token(a, "architecture-edges") {
                    in_architecture_edges = true;
                }
            }

            in_architecture_svg && in_architecture_edges
        }

        fn is_architecture_service_node_bkg_path(n: roxmltree::Node<'_, '_>) -> bool {
            n.tag_name().name() == "path"
                && has_class_token(n, "node-bkg")
                && n.ancestors().any(|a| {
                    a.is_element()
                        && a.tag_name().name() == "g"
                        && has_class_token(a, "architecture-service")
                })
        }

        fn is_xychart_bar_data_label_text(n: roxmltree::Node<'_, '_>) -> bool {
            if !(n.is_element() && n.tag_name().name() == "text") {
                return false;
            }
            let mut has_plot = false;
            let mut has_bar_plot = false;
            for a in n.ancestors() {
                if !(a.is_element() && a.tag_name().name() == "g") {
                    continue;
                }
                let Some(class) = a.attribute("class") else {
                    continue;
                };
                for token in class.split_whitespace() {
                    if token == "plot" {
                        has_plot = true;
                    } else if token.starts_with("bar-plot-") {
                        has_bar_plot = true;
                    }
                }
            }
            has_plot && has_bar_plot
        }

        fn is_quadrantchart_data_point_circle(n: roxmltree::Node<'_, '_>) -> bool {
            if !(n.is_element() && n.tag_name().name() == "circle") {
                return false;
            }

            let mut in_quadrantchart_svg = false;
            let mut in_data_point = false;
            for a in n.ancestors() {
                if !a.is_element() {
                    continue;
                }
                if a.tag_name().name() == "svg"
                    && a.attribute("aria-roledescription")
                        .is_some_and(|v| v == "quadrantChart")
                {
                    in_quadrantchart_svg = true;
                }
                if a.tag_name().name() == "g" && has_class_token(a, "data-point") {
                    in_data_point = true;
                }
            }

            in_quadrantchart_svg && in_data_point
        }

        fn is_invalid_svg_token(value: &str) -> bool {
            let lower = value.trim().to_ascii_lowercase();
            lower.contains("nan") || lower.contains("undefined") || lower.contains("infinity")
        }

        fn normalize_quadrantchart_default_point_color(
            key: &str,
            value: &str,
            n: roxmltree::Node<'_, '_>,
            mode: DomMode,
        ) -> Option<String> {
            if !matches!(mode, DomMode::Parity | DomMode::ParityRoot) {
                return None;
            }
            if !matches!(key, "fill" | "stroke") || !is_quadrantchart_data_point_circle(n) {
                return None;
            }
            let value = value.trim();
            if is_invalid_svg_token(value) || value == "rgb(185, 185, 255)" {
                Some("<quadrant-point-default-color>".to_string())
            } else {
                None
            }
        }

        for a in n.attributes() {
            let key = a.name().to_string();
            let mut val = a.value().to_string();

            if let Some(normalized) =
                normalize_quadrantchart_default_point_color(&key, &val, n, mode)
            {
                attrs.insert(key, normalized);
                continue;
            }

            if key == "transform" {
                val = normalize_transform_attr(&val);
                if matches!(mode, DomMode::Parity | DomMode::ParityRoot) {
                    let lower = val.to_ascii_lowercase();
                    // Upstream Mermaid can emit invalid transforms for certain edge-label corner
                    // cases (e.g. blank labels): `translate(undefined,NaN)`. Treat these as
                    // non-semantic in parity modes so we don't fail DOM comparisons on upstream
                    // renderer quirks.
                    if lower.contains("undefined") || lower.contains("nan") {
                        continue;
                    }
                }
            }

            if mode == DomMode::Strict && matches!(key.as_str(), "d" | "points") {
                val = normalize_attr_whitespace_strict(&val);
            }

            if matches!(mode, DomMode::Parity | DomMode::ParityRoot)
                && key == "font-size"
                && is_xychart_bar_data_label_text(n)
            {
                val = normalize_numeric_tokens_mode(&val, decimals, DomMode::Structure);
                attrs.insert(key, val);
                continue;
            }

            // `data-points` is a base64-encoded JSON payload (Mermaid uses `btoa(JSON.stringify(...))`).
            // In strict mode we want stable, precision-controlled DOM comparisons, so we normalize the
            // *decoded* JSON numbers and then re-encode. Importantly, we must not run generic numeric
            // token normalization on the base64 string itself (it can corrupt the payload).
            if mode == DomMode::Strict && key == "data-points" {
                if let Some(normalized) = normalize_data_points_base64_json(&val, decimals) {
                    val = normalized;
                }
                attrs.insert(key, val);
                continue;
            }

            let mut normalized_geom = false;
            if mode != DomMode::Strict {
                if key == "data-points" {
                    val = "<data-points>".to_string();
                    normalized_geom = true;
                }
                if key == "transform" && is_architecture_edge_arrow(n) {
                    // Mermaid Architecture emits edge arrowheads as translated polygons, so
                    // upstream diagonal arrows can point away from their edge segment. Merman
                    // rotates those standalone polygons from actual routed geometry; parity
                    // modes should treat that as a visual-geometry delta, not a DOM regression.
                    val = "<geom>".to_string();
                    normalized_geom = true;
                }
                if key == "d" || key == "points" {
                    if mode == DomMode::Structure {
                        val = "<geom>".to_string();
                        normalized_geom = true;
                    } else if matches!(mode, DomMode::Parity | DomMode::ParityRoot) {
                        if key == "d" && n.tag_name().name() == "path" && is_mindmap_diagram(n) {
                            // Mindmap node/edge paths are highly layout-dependent. Treat them as
                            // geometry noise in parity mode to focus checks on DOM structure and
                            // semantic attributes.
                            val = "<geom>".to_string();
                            normalized_geom = true;
                        } else if key == "d" && is_architecture_service_node_bkg_path(n) {
                            // Architecture fallback service background paths differ between
                            // historical fixtures and Mermaid 11.15's current `svgDraw.ts`
                            // spelling. The path is pure geometry; root gates still compare the
                            // rendered viewport separately.
                            val = "<architecture-node-bkg>".to_string();
                            normalized_geom = true;
                        } else if key == "d"
                            && n.tag_name().name() == "path"
                            && n.attribute("class")
                                .is_some_and(|c| c.split_whitespace().any(|t| t == "relation"))
                        {
                            // Edge routing geometry differs across layout engines; treat edge path `d`
                            // as geometry noise in parity mode.
                            val = "<geom>".to_string();
                            normalized_geom = true;
                        } else if key == "d"
                            && n.tag_name().name() == "path"
                            && n.attribute("class").is_some_and(|c| {
                                c.split_whitespace().any(|t| t == "relationshipLine")
                            })
                        {
                            // Mermaid ER relationship routes are layout-engine-dependent (notably
                            // when `layout=elk` is enabled). Treat the `d` payload as geometry
                            // noise in parity mode so comparisons focus on DOM structure and
                            // semantic attributes.
                            val = "<geom>".to_string();
                            normalized_geom = true;
                        } else {
                            // Keep command letters but treat numeric payload as geometry noise.
                            // This enables parity checks to catch path/points structure changes while
                            // ignoring layout-specific numeric drift.
                            let v = val.replace(',', " ");
                            let v = normalize_numeric_tokens_mode(&v, decimals, DomMode::Structure);
                            val = v.chars().filter(|c| !c.is_whitespace()).collect();
                            normalized_geom = true;
                        }
                    }
                }
                if key == "style" || key == "viewBox" {
                    if n.tag_name().name() == "svg" && mode != DomMode::ParityRoot {
                        continue;
                    }
                    if key == "style" {
                        if n.tag_name().name() == "svg" && mode == DomMode::ParityRoot {
                        } else if matches!(mode, DomMode::Parity | DomMode::ParityRoot)
                            && matches!(n.tag_name().name(), "text" | "tspan")
                        {
                            let Some(filtered) =
                                normalize_style_font_size_for_parity(&val, decimals)
                            else {
                                continue;
                            };
                            val = filtered;
                        } else {
                            continue;
                        }
                    }
                }
            }

            if key == "class" {
                val = normalize_class_list(&val, mode);
                val = normalize_gitgraph_dynamic_commit_ids(&val);
            }
            if matches!(
                mode,
                DomMode::Strict | DomMode::Structure | DomMode::Parity | DomMode::ParityRoot
            ) && key == "id"
                && is_architecture_icon_content(n)
                && (val.starts_with("IconifyId") || val.len() <= 2)
            {
                val = "<icon-id>".to_string();
            }
            if matches!(mode, DomMode::Parity | DomMode::ParityRoot)
                && key == "id"
                && is_architecture_diagram(n)
                && !is_architecture_icon_content(n)
            {
                val = normalize_architecture_scoped_dom_id(n, &val);
            }
            if matches!(
                mode,
                DomMode::Structure | DomMode::Parity | DomMode::ParityRoot
            ) && is_sankey_diagram(n)
            {
                val = normalize_sankey_scoped_dom_value(n, &val);
            }
            if mode == DomMode::Structure && is_identifier_like_attr(&key) {
                val = normalize_identifier_tokens(&val);
            } else if matches!(mode, DomMode::Parity | DomMode::ParityRoot)
                && is_identifier_like_attr(&key)
            {
                val = normalize_mermaid_generated_id_only(&val);
            } else if mode == DomMode::Strict && is_identifier_like_attr(&key) {
                if is_block_diagram(n) {
                    val = normalize_mermaid_generated_id_only(&val);
                }
                // In strict mode, keep identifier-like attributes byte-for-byte (aside from XML
                // escaping). Applying numeric token normalization here is unsafe, as it can
                // accidentally rewrite IDs like `flowchart-A-0` into `flowchart-A0` by treating
                // `-0` as a number.
            } else if !normalized_geom
                && matches!(mode, DomMode::Parity | DomMode::ParityRoot)
                && is_geometry_attr(&key)
                && !(mode == DomMode::ParityRoot
                    && n.tag_name().name() == "svg"
                    && (key == "width" || key == "height"))
            {
                val = normalize_numeric_tokens_mode(&val, decimals, DomMode::Structure);
            } else {
                val = normalize_numeric_tokens_mode(&val, decimals, mode);
            }

            if key == "style" && mode == DomMode::ParityRoot && n.tag_name().name() == "svg" {
                val = normalize_svg_root_style_parity_root(&val, decimals);
            }
            if key == "viewBox" && mode == DomMode::ParityRoot && n.tag_name().name() == "svg" {
                val = normalize_svg_root_viewbox_parity_root(&val, decimals);
            }

            attrs.insert(key, val);
        }
    }

    fn normalize_text_node_text(t: &str) -> Option<String> {
        let t = t.split_whitespace().collect::<Vec<_>>().join(" ");
        if t.is_empty() { None } else { Some(t) }
    }

    let mut text: Option<String> = None;
    let mut children: Vec<SvgDomNode> = Vec::new();

    if mode == DomMode::Strict {
        // In strict mode we must preserve mixed-content text (e.g. `foo<br />bar`), where
        // `roxmltree::Node::text()` would only return the first text segment.
        let has_element_child = n.children().any(|c| c.is_element());
        if has_element_child {
            for c in n.children() {
                if c.is_element() {
                    children.push(build_node(c, mode, decimals));
                } else if c.is_text() {
                    if let Some(t) = c.text().and_then(normalize_text_node_text) {
                        children.push(SvgDomNode {
                            name: "#text".to_string(),
                            attrs: BTreeMap::new(),
                            text: Some(t),
                            children: Vec::new(),
                        });
                    }
                }
            }
        } else {
            text = n.text().and_then(normalize_text_node_text);
            for c in n.children().filter(|c| c.is_element()) {
                children.push(build_node(c, mode, decimals));
            }
        }
    } else {
        // Non-strict modes treat text as non-semantic and only track element structure.
        for c in n.children().filter(|c| c.is_element()) {
            children.push(build_node(c, mode, decimals));
        }
        if matches!(mode, DomMode::Parity | DomMode::ParityRoot)
            && n.is_element()
            && n.tag_name().name() == "text"
            && is_architecture_diagram(n)
        {
            // Mermaid's `createText()` emits `<text><tspan>...</tspan>...</text>` where the number
            // of `tspan` lines depends on runtime font measurement and layout geometry (e.g. edge
            // label width derived from endpoint distance). In parity comparisons we treat this as
            // layout-dependent noise for Architecture diagrams to avoid spurious DOM diffs.
            children.clear();
        }
    }

    if n.is_element() && n.tag_name().name() == "style" {
        // Stylesheets are large and may differ in whitespace, ordering, and numeric precision
        // even when the effective rendering is unchanged. Treat them as non-semantic for DOM
        // comparisons, including strict mode (we track DOM structure separately from CSS parity).
        text = None;
    }

    if mode != DomMode::Strict {
        fn is_cluster_class_token(c: &str) -> bool {
            c == "cluster" || c.ends_with("-cluster") || c.ends_with("_cluster")
        }

        fn find_first_attr<'a>(n: &'a SvgDomNode, tag: &str, attr: &str) -> Option<&'a str> {
            if n.name == tag {
                if let Some(v) = n.attrs.get(attr) {
                    return Some(v.as_str());
                }
            }
            for c in &n.children {
                if let Some(v) = find_first_attr(c, tag, attr) {
                    return Some(v);
                }
            }
            None
        }

        fn count_tag(n: &SvgDomNode, tag: &str) -> usize {
            let mut out = 0usize;
            if n.name == tag {
                out += 1;
            }
            for c in &n.children {
                out += count_tag(c, tag);
            }
            out
        }

        fn min_tspan_dy(n: &SvgDomNode) -> Option<f64> {
            let mut best: Option<f64> = None;
            if n.name == "tspan" {
                if let Some(dy) = n.attrs.get("dy").and_then(|s| s.parse::<f64>().ok()) {
                    best = Some(best.map(|v| v.min(dy)).unwrap_or(dy));
                }
            }
            for c in &n.children {
                if let Some(v) = min_tspan_dy(c) {
                    best = Some(best.map(|b| b.min(v)).unwrap_or(v));
                }
            }
            best
        }

        fn find_first_cluster_id(n: &SvgDomNode) -> Option<&str> {
            if n.name == "g" {
                if let Some(class) = n.attrs.get("class") {
                    if class.split_whitespace().any(is_cluster_class_token) {
                        if let Some(id) = n.attrs.get("id") {
                            return Some(id.as_str());
                        }
                    }
                }
            }
            for c in &n.children {
                if let Some(id) = find_first_cluster_id(c) {
                    return Some(id);
                }
            }
            None
        }

        fn sort_hint(n: &SvgDomNode) -> &str {
            fn find_first_path_id(n: &SvgDomNode) -> Option<&str> {
                if n.name == "path" {
                    if let Some(id) = n.attrs.get("id") {
                        return Some(id.as_str());
                    }
                }
                for c in &n.children {
                    if let Some(id) = find_first_path_id(c) {
                        return Some(id);
                    }
                }
                None
            }

            if let Some(id) = n.attrs.get("id") {
                return id.as_str();
            }
            if let Some(id) = n.attrs.get("data-id") {
                return id.as_str();
            }
            if n.name == "text" {
                for c in &n.children {
                    if c.name != "tspan" {
                        continue;
                    }
                    if let Some(dy) = c.attrs.get("dy") {
                        return dy.as_str();
                    }
                }
            }
            if n.name == "g" {
                // Mermaid often emits anonymous wrapper `<g>` elements (notably in edge groups)
                // without `id`/`class`. In parity modes we sort children to make DOM comparisons
                // deterministic. If we can't derive a stable hint, wrappers can be re-ordered based
                // on incidental content differences (e.g. label wrapping changes the `tspan`
                // structure), causing spurious diffs. Prefer the first descendant edge path id as
                // a stable semantic key.
                if !n.attrs.contains_key("id") && !n.attrs.contains_key("data-id") {
                    if let Some(id) = find_first_path_id(n) {
                        return id;
                    }
                }

                fn find_first_data_id(n: &SvgDomNode) -> Option<&str> {
                    if let Some(id) = n.attrs.get("data-id") {
                        return Some(id.as_str());
                    }
                    for c in &n.children {
                        if let Some(id) = find_first_data_id(c) {
                            return Some(id);
                        }
                    }
                    None
                }

                if let Some(class) = n.attrs.get("class") {
                    if class.split_whitespace().any(|c| c == "root") {
                        if let Some(id) = find_first_cluster_id(n) {
                            return id;
                        }
                    }
                    if class.split_whitespace().any(|c| c == "edgeLabel") {
                        if let Some(id) = find_first_data_id(n) {
                            return id;
                        }
                    }
                }
            }
            ""
        }

        if matches!(mode, DomMode::Parity | DomMode::ParityRoot)
            && n.tag_name().name() == "g"
            && children.iter().any(|c| {
                c.name == "rect"
                    && c.attrs.get("class").is_some_and(|class| {
                        let mut has_actor = false;
                        let mut has_bottom = false;
                        for token in class.split_whitespace() {
                            has_actor |= token == "actor";
                            has_bottom |= token == "actor-bottom";
                        }
                        has_actor && has_bottom
                    })
            })
            && children.iter().any(|c| c.name == "switch")
        {
            // Mermaid Sequence calls the async KaTeX actor-label renderer from a synchronous
            // footer actor path. Exported SVGs can therefore contain missing or half-populated
            // bottom actor `<switch>` labels depending on timing. Treat those footer switches as
            // non-semantic in parity modes; top actor labels still compare normally.
            children.retain(|c| c.name != "switch");
        }

        fn is_ishikawa_nonsemantic_wrapper(n: &SvgDomNode) -> bool {
            if n.name != "g" {
                return false;
            }
            n.attrs.get("class").is_some_and(|class| {
                class.split_whitespace().any(|token| {
                    matches!(
                        token,
                        "ishikawa-pair" | "ishikawa-label-group" | "ishikawa-sub-group"
                    )
                })
            })
        }

        fn flatten_ishikawa_nonsemantic_wrappers(children: &mut Vec<SvgDomNode>) {
            let mut flattened = Vec::with_capacity(children.len());
            for mut child in std::mem::take(children) {
                flatten_ishikawa_nonsemantic_wrappers(&mut child.children);
                if is_ishikawa_nonsemantic_wrapper(&child) {
                    flattened.extend(child.children);
                } else {
                    flattened.push(child);
                }
            }
            *children = flattened;
        }

        if matches!(mode, DomMode::Parity | DomMode::ParityRoot) {
            flatten_ishikawa_nonsemantic_wrappers(&mut children);
        }

        children.sort_by(|a, b| {
            let aclass = a.attrs.get("class").map(|s| s.as_str()).unwrap_or("");
            let bclass = b.attrs.get("class").map(|s| s.as_str()).unwrap_or("");
            let ahint = sort_hint(a);
            let bhint = sort_hint(b);
            let a_is_c4_shape_group =
                a.name == "g" && aclass.split_whitespace().any(|c| c == "person-man");
            let b_is_c4_shape_group =
                b.name == "g" && bclass.split_whitespace().any(|c| c == "person-man");
            a.name
                .cmp(&b.name)
                .then_with(|| ahint.cmp(bhint))
                .then_with(|| aclass.cmp(bclass))
                .then_with(|| a.attrs.cmp(&b.attrs))
                .then_with(|| {
                    if !(a_is_c4_shape_group && b_is_c4_shape_group) {
                        return std::cmp::Ordering::Equal;
                    }
                    let a_fill = find_first_attr(a, "rect", "fill").unwrap_or("");
                    let b_fill = find_first_attr(b, "rect", "fill").unwrap_or("");
                    a_fill.cmp(b_fill)
                })
                .then_with(|| {
                    if !(a_is_c4_shape_group && b_is_c4_shape_group) {
                        return std::cmp::Ordering::Equal;
                    }
                    let a_len = find_first_attr(a, "text", "textLength").unwrap_or("");
                    let b_len = find_first_attr(b, "text", "textLength").unwrap_or("");
                    a_len.cmp(b_len)
                })
                .then_with(|| {
                    if a.name != "g" || b.name != "g" || !aclass.is_empty() || !bclass.is_empty() {
                        return std::cmp::Ordering::Equal;
                    }
                    let at = count_tag(a, "tspan");
                    let bt = count_tag(b, "tspan");
                    at.cmp(&bt)
                })
                .then_with(|| {
                    if a.name != "g" || b.name != "g" || !aclass.is_empty() || !bclass.is_empty() {
                        return std::cmp::Ordering::Equal;
                    }
                    let ady = min_tspan_dy(a).unwrap_or(0.0);
                    let bdy = min_tspan_dy(b).unwrap_or(0.0);
                    ady.partial_cmp(&bdy).unwrap_or(std::cmp::Ordering::Equal)
                })
        });
    }

    SvgDomNode {
        name: n.tag_name().name().to_string(),
        attrs,
        text,
        children,
    }
}

pub(crate) fn normalize_xml_entities(svg: &str) -> Cow<'_, str> {
    // Mermaid SVG output (especially `<foreignObject>` XHTML) can contain HTML-ish constructs
    // that are valid in a browser DOM, but not valid XML:
    //
    // - HTML entity references like `&nbsp;` (not predefined in XML), and
    // - void elements like `<img ...>` without a self-closing slash (`/>`).
    //
    // Normalize the most common cases so we can parse and compare DOM trees deterministically.
    // This only affects DOM comparison and report parsing; it does not change SVG rendering.
    if !(svg.contains("&nbsp;")
        || svg.contains("&#160;")
        || svg.contains("&#xA0;")
        || svg.contains("<img"))
    {
        return Cow::Borrowed(svg);
    }

    fn normalize_unclosed_img_tags(s: &str) -> String {
        fn re_unquoted_attr_value() -> &'static Regex {
            static ONCE: OnceLock<Regex> = OnceLock::new();
            // In HTML it is legal to omit quotes for attribute values (e.g. `src=x`), but
            // `roxmltree` parses XML and requires quotes. Normalize the common case we see in
            // Mermaid's `<foreignObject>` XHTML.
            ONCE.get_or_init(|| Regex::new(r#"(\s[\w:-]+)=([^\s"'<>]+)"#).unwrap())
        }

        let mut out = String::with_capacity(s.len());
        let mut idx = 0usize;
        while let Some(rel) = s[idx..].find("<img") {
            let start = idx + rel;
            out.push_str(&s[idx..start]);
            let Some(gt_rel) = s[start..].find('>') else {
                out.push_str(&s[start..]);
                return out;
            };
            let end = start + gt_rel;

            // Include the closing `>` for easier normalization.
            let tag_full = &s[start..=end];
            let mut tag_norm = re_unquoted_attr_value()
                .replace_all(tag_full, r#"$1="$2""#)
                .to_string();

            // Ensure the void tag is self-closed so the surrounding SVG becomes valid XML.
            if tag_norm.ends_with('>') {
                let inner = tag_norm[..tag_norm.len() - 1].trim_end();
                if !inner.ends_with('/') {
                    tag_norm.pop();
                    tag_norm.push_str("/>");
                }
            }

            out.push_str(&tag_norm);
            idx = end + 1;
        }
        out.push_str(&s[idx..]);
        out
    }

    let mut out = svg.to_string();
    if out.contains("&nbsp;") || out.contains("&#160;") || out.contains("&#xA0;") {
        out = out.replace("&nbsp;", " ");
        out = out.replace("&#160;", " ").replace("&#xA0;", " ");
    }
    if out.contains("<img") {
        out = normalize_unclosed_img_tags(&out);
    }
    Cow::Owned(out)
}

pub(crate) fn dom_signature(svg: &str, mode: DomMode, decimals: u32) -> Result<SvgDomNode, String> {
    let svg = normalize_xml_entities(svg);
    let doc = roxmltree::Document::parse(svg.as_ref()).map_err(|e| e.to_string())?;
    let root = doc
        .descendants()
        .find(|n| n.has_tag_name("svg"))
        .ok_or_else(|| "missing <svg> root".to_string())?;
    Ok(build_node(root, mode, decimals))
}

fn escape_xml_text(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for ch in s.chars() {
        match ch {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            _ => out.push(ch),
        }
    }
    out
}

fn escape_xml_attr(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for ch in s.chars() {
        match ch {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            _ => out.push(ch),
        }
    }
    out
}

fn write_indent(out: &mut String, depth: usize) {
    for _ in 0..depth {
        out.push_str("  ");
    }
}

fn write_canonical_node(out: &mut String, n: &SvgDomNode, depth: usize) {
    if n.name == "#text" {
        let Some(t) = n.text.as_deref().filter(|t| !t.is_empty()) else {
            return;
        };
        write_indent(out, depth);
        out.push_str(&escape_xml_text(t));
        out.push('\n');
        return;
    }

    write_indent(out, depth);
    out.push('<');
    out.push_str(&n.name);

    for (k, v) in &n.attrs {
        out.push(' ');
        out.push_str(k);
        out.push_str("=\"");
        out.push_str(&escape_xml_attr(v));
        out.push('"');
    }

    let has_children = !n.children.is_empty();
    let has_text = n.text.as_ref().is_some_and(|t| !t.is_empty());

    if !has_children && !has_text {
        out.push_str("/>\n");
        return;
    }

    out.push('>');

    if has_text {
        out.push_str(&escape_xml_text(n.text.as_deref().unwrap_or_default()));
    }

    if has_children {
        out.push('\n');
        for c in &n.children {
            write_canonical_node(out, c, depth + 1);
        }
        write_indent(out, depth);
    }

    out.push_str("</");
    out.push_str(&n.name);
    out.push_str(">\n");
}

pub(crate) fn canonical_xml(svg: &str, mode: DomMode, decimals: u32) -> Result<String, String> {
    let dom = dom_signature(svg, mode, decimals)?;
    let mut out = String::new();
    write_canonical_node(&mut out, &dom, 0);
    Ok(out)
}

fn truncate(s: &str, max_len: usize) -> String {
    if s.len() <= max_len {
        return s.to_string();
    }
    let mut out = s
        .chars()
        .take(max_len.saturating_sub(1))
        .collect::<String>();
    out.push('…');
    out
}

pub(crate) fn dom_diff_path(
    upstream: &SvgDomNode,
    local: &SvgDomNode,
    path: &mut Vec<String>,
) -> Option<String> {
    if upstream.name != local.name {
        return Some(format!(
            "{}: element name mismatch upstream={} local={}",
            path.join("/"),
            upstream.name,
            local.name
        ));
    }

    if upstream.attrs != local.attrs {
        for (k, v_up) in &upstream.attrs {
            match local.attrs.get(k) {
                None => return Some(format!("{}: missing attr `{k}`", path.join("/"))),
                Some(v_lo) if v_lo != v_up => {
                    return Some(format!(
                        "{}: attr `{k}` mismatch upstream=`{}` local=`{}`",
                        path.join("/"),
                        truncate(v_up, 120),
                        truncate(v_lo, 120)
                    ));
                }
                _ => {}
            }
        }
        for k in local.attrs.keys() {
            if !upstream.attrs.contains_key(k) {
                return Some(format!("{}: extra attr `{k}`", path.join("/")));
            }
        }
    }

    if upstream.text != local.text {
        return Some(format!(
            "{}: text mismatch upstream=`{}` local=`{}`",
            path.join("/"),
            truncate(upstream.text.as_deref().unwrap_or(""), 120),
            truncate(local.text.as_deref().unwrap_or(""), 120)
        ));
    }

    let n = upstream.children.len().min(local.children.len());
    for i in 0..n {
        path.push(format!("{}[{}]", upstream.children[i].name, i));
        if let Some(d) = dom_diff_path(&upstream.children[i], &local.children[i], path) {
            return Some(d);
        }
        path.pop();
    }

    if upstream.children.len() != local.children.len() {
        return Some(format!(
            "{}: child count mismatch upstream={} local={}",
            path.join("/"),
            upstream.children.len(),
            local.children.len()
        ));
    }

    None
}

pub(crate) fn dom_diff(upstream: &SvgDomNode, local: &SvgDomNode) -> Option<String> {
    let mut path = vec![upstream.name.clone()];
    dom_diff_path(upstream, local, &mut path)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strict_does_not_normalize_numbers_inside_identifier_like_attrs() {
        let svg = r#"<svg id="flowchart-A-0" aria-label="foo-0 bar" aria-roledescription="flowchart-v2"><g id="id-abc-0"/></svg>"#;
        let dom = dom_signature(svg, DomMode::Strict, 3).unwrap();
        assert_eq!(
            dom.attrs.get("id").map(|s| s.as_str()),
            Some("flowchart-A-0")
        );
        assert_eq!(
            dom.attrs.get("aria-label").map(|s| s.as_str()),
            Some("foo-0 bar")
        );
        assert_eq!(
            dom.attrs.get("aria-roledescription").map(|s| s.as_str()),
            Some("flowchart-v2")
        );
        assert_eq!(dom.children.len(), 1);
        assert_eq!(
            dom.children[0].attrs.get("id").map(|s| s.as_str()),
            Some("id-abc-0")
        );
    }

    #[test]
    fn strict_normalizes_block_generated_ids_only() {
        let svg = r#"<svg aria-roledescription="block"><g id="id-abc123def456-1"/><g id="flowchart-A-0"/></svg>"#;
        let dom = dom_signature(svg, DomMode::Strict, 3).unwrap();
        assert_eq!(
            dom.children[0].attrs.get("id").map(|s| s.as_str()),
            Some("id-<id>-1")
        );
        assert_eq!(
            dom.children[1].attrs.get("id").map(|s| s.as_str()),
            Some("flowchart-A-0")
        );
    }

    #[test]
    fn strict_preserves_mixed_content_text_segments() {
        let svg = r#"<svg xmlns="http://www.w3.org/2000/svg"><foreignObject><div xmlns="http://www.w3.org/1999/xhtml"><p>This is a<br />multiline string</p></div></foreignObject></svg>"#;
        let dom = dom_signature(svg, DomMode::Strict, 3).unwrap();

        let p = dom
            .children
            .iter()
            .find(|n| n.name == "foreignObject")
            .and_then(|fo| fo.children.iter().find(|n| n.name == "div"))
            .and_then(|div| div.children.iter().find(|n| n.name == "p"))
            .expect("p exists");

        assert_eq!(p.children.len(), 3);
        assert_eq!(p.children[0].name, "#text");
        assert_eq!(p.children[0].text.as_deref(), Some("This is a"));
        assert_eq!(p.children[1].name, "br");
        assert_eq!(p.children[2].name, "#text");
        assert_eq!(p.children[2].text.as_deref(), Some("multiline string"));

        let xml = canonical_xml(svg, DomMode::Strict, 3).unwrap();
        assert!(xml.contains("This is a"));
        assert!(xml.contains("multiline string"));
    }

    #[test]
    fn parity_keeps_path_commands_but_masks_numbers() {
        let svg = r#"<svg width="100" height="100" viewBox="0 0 100 100"><path d="M 10 20 L 30 40"/></svg>"#;
        let dom = dom_signature(svg, DomMode::Parity, 3).unwrap();
        assert!(!dom.attrs.contains_key("viewBox"));
        assert_eq!(dom.children.len(), 1);
        assert_eq!(dom.children[0].name, "path");
        assert_eq!(
            dom.children[0].attrs.get("d").map(|s| s.as_str()),
            Some("M<n><n>L<n><n>")
        );
    }

    #[test]
    fn parity_root_keeps_svg_root_viewbox_and_style() {
        let svg = r#"<svg width="100%" viewBox="0 -5.9759 600 405.9759" style="max-width: 600px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let dom = dom_signature(svg, DomMode::ParityRoot, 3).unwrap();
        assert_eq!(dom.attrs.get("width").map(|s| s.as_str()), Some("100%"));
        assert_eq!(
            dom.attrs.get("viewBox").map(|s| s.as_str()),
            Some("<n> <n> 600 406")
        );
        assert_eq!(
            dom.attrs.get("style").map(|s| s.as_str()),
            Some("max-width: 600px; background-color: white;")
        );
    }

    #[test]
    fn parity_root_snaps_svg_root_style_max_width() {
        let a = r#"<svg width="100%" viewBox="0 0 560.391 10" style="max-width: 560.391px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let b = r#"<svg width="100%" viewBox="0 0 560.375 10" style="max-width: 560.375px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let dom_a = dom_signature(a, DomMode::ParityRoot, 3).unwrap();
        let dom_b = dom_signature(b, DomMode::ParityRoot, 3).unwrap();
        assert_eq!(dom_a.attrs.get("style"), dom_b.attrs.get("style"));
        assert_eq!(
            dom_a.attrs.get("style").map(|s| s.as_str()),
            Some("max-width: 560.25px; background-color: white;")
        );
    }

    #[test]
    fn parity_root_snaps_svg_root_style_max_width_is_midpoint_stable() {
        // Values that straddle the midpoint between steps should still normalize to the same
        // signature to avoid platform-specific CI failures.
        let a = r#"<svg width="100%" viewBox="0 0 502.172 10" style="max-width: 502.172px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let b = r#"<svg width="100%" viewBox="0 0 502.188 10" style="max-width: 502.188px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let dom_a = dom_signature(a, DomMode::ParityRoot, 3).unwrap();
        let dom_b = dom_signature(b, DomMode::ParityRoot, 3).unwrap();
        assert_eq!(dom_a.attrs.get("style"), dom_b.attrs.get("style"));
        assert_eq!(
            dom_a.attrs.get("style").map(|s| s.as_str()),
            Some("max-width: 502.25px; background-color: white;")
        );
    }

    #[test]
    fn parity_root_snaps_svg_root_viewbox_numbers() {
        let a = r#"<svg width="100%" viewBox="0 0 560.391 10.016" style="max-width: 560.391px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let b = r#"<svg width="100%" viewBox="0 0 560.375 10" style="max-width: 560.375px; background-color: white;"><path d="M 10 20 L 30 40"/></svg>"#;
        let dom_a = dom_signature(a, DomMode::ParityRoot, 3).unwrap();
        let dom_b = dom_signature(b, DomMode::ParityRoot, 3).unwrap();
        assert_eq!(dom_a.attrs.get("viewBox"), dom_b.attrs.get("viewBox"));
        assert_eq!(
            dom_a.attrs.get("viewBox").map(|s| s.as_str()),
            Some("<n> <n> 560.25 10")
        );
    }

    #[test]
    fn parity_keeps_style_font_size_on_text_nodes() {
        let a = r#"<svg><text style="text-anchor: middle; font-size: 16px; font-weight: 400;">Hi</text></svg>"#;
        let b = r#"<svg><text style="text-anchor: middle; font-size: 18px; font-weight: 400;">Hi</text></svg>"#;
        let dom_a = dom_signature(a, DomMode::Parity, 3).unwrap();
        let dom_b = dom_signature(b, DomMode::Parity, 3).unwrap();
        let text_a = &dom_a.children[0];
        let text_b = &dom_b.children[0];
        assert_eq!(text_a.name, "text");
        assert_eq!(text_b.name, "text");
        assert_eq!(
            text_a.attrs.get("style").map(|s| s.as_str()),
            Some("font-size:16px")
        );
        assert_eq!(
            text_b.attrs.get("style").map(|s| s.as_str()),
            Some("font-size:18px")
        );
        assert_ne!(dom_a, dom_b);
    }

    #[test]
    fn parity_masks_relation_path_as_geom() {
        let svg = r#"<svg><path class="relation" d="M0,0L1,1"/></svg>"#;
        let dom = dom_signature(svg, DomMode::Parity, 3).unwrap();
        assert_eq!(
            dom.children[0].attrs.get("d").map(|s| s.as_str()),
            Some("<geom>")
        );
    }

    #[test]
    fn structure_normalizes_identifier_tokens_and_ignores_text() {
        let svg = r#"<svg><g id="foo_12"><text> hi   there </text></g></svg>"#;
        let dom = dom_signature(svg, DomMode::Structure, 3).unwrap();
        assert_eq!(
            dom.children[0].attrs.get("id").map(|s| s.as_str()),
            Some("foo_<n>")
        );
        assert_eq!(dom.children[0].children[0].text, None);
    }

    #[test]
    fn structure_masks_architecture_icon_internal_ids() {
        let svg = r#"<svg xmlns="http://www.w3.org/2000/svg"><g class="architecture-service"><g><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><g><ellipse id="IconifyIddeadbeef" cx="5" cy="5" rx="4" ry="4"/></g></svg></g></g></svg>"#;
        let dom = dom_signature(svg, DomMode::Structure, 3).unwrap();
        fn find_ellipse_id(n: &SvgDomNode) -> Option<&str> {
            if n.name == "ellipse" {
                return n.attrs.get("id").map(|s| s.as_str());
            }
            for c in &n.children {
                if let Some(id) = find_ellipse_id(c) {
                    return Some(id);
                }
            }
            None
        }

        assert_eq!(find_ellipse_id(&dom), Some("<icon-id>"));
    }

    #[test]
    fn parity_masks_architecture_edge_arrow_transform_as_geom() {
        let svg = r#"<svg aria-roledescription="architecture"><g class="architecture-edges"><g><path class="edge" d="M 0,0 L 10,10"/><polygon class="arrow" points="0,0 10,0 5,10" transform="translate(1,2) rotate(45,5,10)"/></g></g></svg>"#;
        let dom = dom_signature(svg, DomMode::Parity, 3).unwrap();
        let arrow = &dom.children[0].children[0].children[1];

        assert_eq!(
            arrow.attrs.get("transform").map(|s| s.as_str()),
            Some("<geom>")
        );
    }

    #[test]
    fn parity_normalizes_architecture_diagram_scoped_dom_ids() {
        let prefixed = r#"<svg id="diag" aria-roledescription="architecture"><g class="architecture-services"><g id="diag-service-api"><g><path id="diag-node-api" class="node-bkg" d="M0,80 V5 Q0,0 5,0 H75 Q80,0 80,5 V80 Z"/></g></g></g><g class="architecture-groups"><rect id="diag-group-core" class="node-bkg" x="0" y="0" width="80" height="80"/></g></svg>"#;
        let bare = r#"<svg id="diag" aria-roledescription="architecture"><g class="architecture-services"><g id="service-api"><g><path id="node-api" class="node-bkg" d="M0,80 V5 Q0,0 5,0 H75 Q80,0 80,5 V80 Z"/></g></g></g><g class="architecture-groups"><rect id="group-core" class="node-bkg" x="0" y="0" width="80" height="80"/></g></svg>"#;

        let prefixed_dom = dom_signature(prefixed, DomMode::Parity, 3).unwrap();
        let bare_dom = dom_signature(bare, DomMode::Parity, 3).unwrap();

        assert_eq!(prefixed_dom, bare_dom);
    }

    #[test]
    fn parity_normalizes_sankey_diagram_scoped_dom_ids() {
        let prefixed = r##"<svg id="diag" aria-roledescription="sankey"><defs><linearGradient id="diag-linearGradient-5"><stop offset="0%" stop-color="#000"/></linearGradient></defs><g class="nodes"><g class="node" id="diag-node-1"/></g><g class="links"><path stroke="url(#diag-linearGradient-5)"/></g></svg>"##;
        let bare = r##"<svg id="diag" aria-roledescription="sankey"><defs><linearGradient id="linearGradient-5"><stop offset="0%" stop-color="#000"/></linearGradient></defs><g class="nodes"><g class="node" id="node-1"/></g><g class="links"><path stroke="url(#linearGradient-5)"/></g></svg>"##;

        let prefixed_dom = dom_signature(prefixed, DomMode::Parity, 3).unwrap();
        let bare_dom = dom_signature(bare, DomMode::Parity, 3).unwrap();

        assert_eq!(prefixed_dom, bare_dom);
    }

    #[test]
    fn parity_normalizes_architecture_service_background_path_spelling() {
        let old_path = r#"<svg aria-roledescription="architecture"><g class="architecture-services"><g class="architecture-service"><g><path class="node-bkg" id="node-api" d="M0 80 v-80 q0,-5 5,-5 h80 q5,0 5,5 v80 H0 Z"/></g></g></g></svg>"#;
        let new_path = r#"<svg aria-roledescription="architecture"><g class="architecture-services"><g class="architecture-service"><g><path class="node-bkg" id="node-api" d="M0,80 V5 Q0,0 5,0 H75 Q80,0 80,5 V80 Z"/></g></g></g></svg>"#;

        let old_dom = dom_signature(old_path, DomMode::Parity, 3).unwrap();
        let new_dom = dom_signature(new_path, DomMode::Parity, 3).unwrap();

        assert_eq!(old_dom, new_dom);
    }

    #[test]
    fn parity_normalizes_quadrantchart_invalid_default_point_color() {
        let upstream = r#"<svg aria-roledescription="quadrantChart"><g class="data-points"><g class="data-point"><circle cx="1" cy="2" r="5" fill="hsl(240, 100%, NaN%)" stroke="hsl(240, 100%, NaN%)"/></g></g></svg>"#;
        let local = r#"<svg aria-roledescription="quadrantChart"><g class="data-points"><g class="data-point"><circle cx="1" cy="2" r="5" fill="rgb(185, 185, 255)" stroke="rgb(185, 185, 255)"/></g></g></svg>"#;

        let upstream_dom = dom_signature(upstream, DomMode::Parity, 3).unwrap();
        let local_dom = dom_signature(local, DomMode::Parity, 3).unwrap();

        assert_eq!(upstream_dom, local_dom);

        let upstream_strict = dom_signature(upstream, DomMode::Strict, 3).unwrap();
        let local_strict = dom_signature(local, DomMode::Strict, 3).unwrap();

        assert_ne!(upstream_strict, local_strict);
    }

    #[test]
    fn non_strict_sorts_children_deterministically() {
        let a = r#"<svg><g id="b"/><g id="a"/></svg>"#;
        let b = r#"<svg><g id="a"/><g id="b"/></svg>"#;
        let sig_a = dom_signature(a, DomMode::Parity, 3).unwrap();
        let sig_b = dom_signature(b, DomMode::Parity, 3).unwrap();
        assert_eq!(sig_a, sig_b);
    }

    #[test]
    fn parity_masks_geometry_attrs_as_n() {
        let svg = r#"<svg><rect x="12.3" y="4.56" width="7" height="8"/></svg>"#;
        let dom = dom_signature(svg, DomMode::Parity, 3).unwrap();
        let rect = &dom.children[0];
        assert_eq!(rect.attrs.get("x").map(|s| s.as_str()), Some("<n>"));
        assert_eq!(rect.attrs.get("y").map(|s| s.as_str()), Some("<n>"));
        assert_eq!(rect.attrs.get("width").map(|s| s.as_str()), Some("<n>"));
        assert_eq!(rect.attrs.get("height").map(|s| s.as_str()), Some("<n>"));
    }
}
