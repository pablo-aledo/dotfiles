use super::super::super::charset::GraphCharset;
use super::super::super::layout::{CanvasCoord, GraphLayout, GridCoord, NodeLayout};
use super::super::super::model::{AsciiGraphEdge, GraphDirection, GraphEdgeArrow};
use super::super::cell::edge_line_char;
use super::super::path::{
    Port, StepDirection, merge_grid_path, route_grid_path_with_ports, step_direction,
};
use super::{
    PlannedRouteCell, PlannedRouteSegment, RoutePlan, edge_arrow_cell_in_segment,
    edge_line_cell_in_segment, planned_label_on_canvas_lines, route_cell_in_segment,
    route_turn_char,
};

#[derive(Debug, Clone, Copy)]
pub(super) struct GridRouteOptions {
    start_port: Option<Port>,
    end_port: Option<Port>,
    segment: PlannedRouteSegment,
}

impl GridRouteOptions {
    pub(super) fn direct() -> Self {
        Self {
            start_port: None,
            end_port: None,
            segment: PlannedRouteSegment::Direct,
        }
    }

    pub(super) fn with_ports(start_port: Option<Port>, end_port: Option<Port>) -> Self {
        Self {
            start_port,
            end_port,
            segment: PlannedRouteSegment::Direct,
        }
    }

    pub(super) fn with_segment(mut self, segment: PlannedRouteSegment) -> Self {
        self.segment = segment;
        self
    }
}

pub(super) fn plan_left_right_grid_path_route(
    graph_layout: &GraphLayout,
    from: &NodeLayout,
    to: &NodeLayout,
    edge: &AsciiGraphEdge,
    charset: &GraphCharset,
) -> Option<RoutePlan> {
    plan_left_right_grid_path_route_with_options(
        graph_layout,
        from,
        to,
        edge,
        charset,
        GridRouteOptions::direct(),
    )
}

pub(super) fn plan_left_right_grid_path_route_with_ports(
    graph_layout: &GraphLayout,
    from: &NodeLayout,
    to: &NodeLayout,
    edge: &AsciiGraphEdge,
    charset: &GraphCharset,
    start_port: Option<Port>,
    end_port: Option<Port>,
) -> Option<RoutePlan> {
    plan_left_right_grid_path_route_with_options(
        graph_layout,
        from,
        to,
        edge,
        charset,
        GridRouteOptions::with_ports(start_port, end_port),
    )
}

pub(super) fn plan_left_right_grid_path_route_with_options(
    graph_layout: &GraphLayout,
    from: &NodeLayout,
    to: &NodeLayout,
    edge: &AsciiGraphEdge,
    charset: &GraphCharset,
    options: GridRouteOptions,
) -> Option<RoutePlan> {
    let (path, start_port, end_port) = route_grid_path_with_ports(
        &graph_layout.nodes,
        from,
        to,
        options.start_port,
        options.end_port,
    )?;
    if path.len() < 2 {
        return None;
    }

    let path = merge_grid_path(path);
    let segment = options.segment;
    let (mut cells, lines_drawn, line_dirs) =
        plan_grid_path(graph_layout, &path, edge, charset, segment);
    if lines_drawn.is_empty() || line_dirs.is_empty() {
        return None;
    }
    plan_grid_corners(&mut cells, graph_layout, &path, charset, segment);
    plan_grid_box_start(
        &mut cells,
        lines_drawn[0].as_slice(),
        start_port,
        charset,
        segment,
    );
    plan_grid_arrow_head(
        &mut cells,
        lines_drawn.last().map(Vec::as_slice).unwrap_or_default(),
        *line_dirs.last().unwrap_or(&end_port.step_fallback()),
        edge,
        charset,
        segment,
    );
    let labels = planned_label_on_canvas_lines(edge.label.as_deref(), &lines_drawn)
        .into_iter()
        .collect();

    Some(RoutePlan { cells, labels })
}

fn plan_grid_path(
    graph_layout: &GraphLayout,
    path: &[GridCoord],
    edge: &AsciiGraphEdge,
    charset: &GraphCharset,
    segment: PlannedRouteSegment,
) -> (
    Vec<PlannedRouteCell>,
    Vec<Vec<CanvasCoord>>,
    Vec<StepDirection>,
) {
    let mut cells = Vec::new();
    let mut lines_drawn = Vec::new();
    let mut line_dirs = Vec::new();

    for path_segment in path.windows(2) {
        let direction = step_direction(path_segment[0], path_segment[1]);
        let (line_cells, line) = plan_grid_line(
            graph_layout.grid_to_canvas(path_segment[0]),
            graph_layout.grid_to_canvas(path_segment[1]),
            direction,
            edge,
            charset,
            segment,
        );
        cells.extend(line_cells);
        if !line.is_empty() {
            lines_drawn.push(line);
            line_dirs.push(direction);
        }
    }

    (cells, lines_drawn, line_dirs)
}

fn plan_grid_line(
    from: CanvasCoord,
    to: CanvasCoord,
    direction: StepDirection,
    edge: &AsciiGraphEdge,
    charset: &GraphCharset,
    segment: PlannedRouteSegment,
) -> (Vec<PlannedRouteCell>, Vec<CanvasCoord>) {
    let mut cells = Vec::new();
    let mut drawn = Vec::new();
    match direction {
        StepDirection::Right => {
            let line = edge_line_char(edge, charset, GraphDirection::LeftRight);
            for x in (from.x + 1)..to.x {
                cells.push(route_cell_in_segment(x, from.y, line, segment));
                drawn.push(CanvasCoord { x, y: from.y });
            }
        }
        StepDirection::Left => {
            let line = edge_line_char(edge, charset, GraphDirection::LeftRight);
            for x in ((to.x + 1)..from.x).rev() {
                cells.push(route_cell_in_segment(x, from.y, line, segment));
                drawn.push(CanvasCoord { x, y: from.y });
            }
        }
        StepDirection::Down => {
            let line = edge_line_char(edge, charset, GraphDirection::TopDown);
            for y in (from.y + 1)..to.y {
                cells.push(route_cell_in_segment(from.x, y, line, segment));
                drawn.push(CanvasCoord { x: from.x, y });
            }
        }
        StepDirection::Up => {
            let line = edge_line_char(edge, charset, GraphDirection::TopDown);
            for y in ((to.y + 1)..from.y).rev() {
                cells.push(route_cell_in_segment(from.x, y, line, segment));
                drawn.push(CanvasCoord { x: from.x, y });
            }
        }
    }
    (cells, drawn)
}

fn plan_grid_corners(
    cells: &mut Vec<PlannedRouteCell>,
    graph_layout: &GraphLayout,
    path: &[GridCoord],
    charset: &GraphCharset,
    segment: PlannedRouteSegment,
) {
    for index in 1..path.len().saturating_sub(1) {
        let previous = step_direction(path[index - 1], path[index]);
        let next = step_direction(path[index], path[index + 1]);
        let coord = graph_layout.grid_to_canvas(path[index]);
        cells.push(route_cell_in_segment(
            coord.x,
            coord.y,
            route_turn_char(previous, next, charset),
            segment,
        ));
    }
}

fn plan_grid_box_start(
    cells: &mut Vec<PlannedRouteCell>,
    first_line: &[CanvasCoord],
    start_port: Port,
    charset: &GraphCharset,
    segment: PlannedRouteSegment,
) {
    if !charset.unicode {
        return;
    }
    let Some(from) = first_line.first().copied() else {
        return;
    };

    let cell = match start_port.step_fallback() {
        StepDirection::Up => {
            edge_line_cell_in_segment(from.x, from.y + 1, charset.up_connector, segment)
        }
        StepDirection::Down => edge_line_cell_in_segment(
            from.x,
            from.y.saturating_sub(1),
            charset.down_connector,
            segment,
        ),
        StepDirection::Left => {
            edge_line_cell_in_segment(from.x + 1, from.y, charset.left_connector, segment)
        }
        StepDirection::Right => edge_line_cell_in_segment(
            from.x.saturating_sub(1),
            from.y,
            charset.right_connector,
            segment,
        ),
    };
    cells.push(cell);
}

fn plan_grid_arrow_head(
    cells: &mut Vec<PlannedRouteCell>,
    last_line: &[CanvasCoord],
    fallback: StepDirection,
    edge: &AsciiGraphEdge,
    charset: &GraphCharset,
    segment: PlannedRouteSegment,
) {
    if edge.arrow == GraphEdgeArrow::Open {
        return;
    }
    let Some(last) = last_line.last().copied() else {
        return;
    };
    let direction = last_line
        .first()
        .and_then(|first| canvas_line_direction(*first, last))
        .unwrap_or(fallback);
    let ch = match direction {
        StepDirection::Up => charset.arrow_up,
        StepDirection::Down => charset.arrow_down,
        StepDirection::Left => charset.arrow_left,
        StepDirection::Right => charset.arrow_right,
    };
    cells.push(edge_arrow_cell_in_segment(last.x, last.y, ch, segment));
}

fn canvas_line_direction(from: CanvasCoord, to: CanvasCoord) -> Option<StepDirection> {
    if from.x == to.x {
        if from.y < to.y {
            Some(StepDirection::Down)
        } else if from.y > to.y {
            Some(StepDirection::Up)
        } else {
            None
        }
    } else if from.x < to.x {
        Some(StepDirection::Right)
    } else {
        Some(StepDirection::Left)
    }
}
