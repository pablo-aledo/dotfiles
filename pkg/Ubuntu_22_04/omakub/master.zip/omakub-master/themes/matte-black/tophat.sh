#!/bin/bash

gsettings set org.gnome.shell.extensions.tophat meter-fg-color "#1e1e1e"
