#!/bin/bash

OMAKUB_THEME_COLOR="orange"
OMAKUB_THEME_BACKGROUND="matte-black/background.jpg"
source $OMAKUB_PATH/themes/set-gnome-theme.sh
