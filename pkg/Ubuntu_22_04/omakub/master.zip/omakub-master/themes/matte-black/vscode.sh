#!/bin/bash

VSC_THEME="Matte Black Theme"
VSC_EXTENSION="CleanThemes.matte-black-theme"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
