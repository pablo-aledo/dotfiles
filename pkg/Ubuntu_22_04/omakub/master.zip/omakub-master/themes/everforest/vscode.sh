#!/bin/bash

VSC_THEME="Everforest Dark"
VSC_EXTENSION="sainnhe.everforest"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
