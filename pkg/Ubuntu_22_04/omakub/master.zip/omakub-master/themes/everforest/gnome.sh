#!/bin/bash

OMAKUB_THEME_COLOR="bark"
OMAKUB_THEME_BACKGROUND="everforest/background.jpg"
source $OMAKUB_PATH/themes/set-gnome-theme.sh
