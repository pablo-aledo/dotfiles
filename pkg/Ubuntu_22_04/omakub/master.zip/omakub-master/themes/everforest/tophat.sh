#!/bin/bash

gsettings set org.gnome.shell.extensions.tophat meter-fg-color "#78ab50"
