#!/bin/bash

gsettings set org.gnome.shell.extensions.tophat meter-fg-color "#e92020"
