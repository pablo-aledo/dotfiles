#!/bin/bash

VSC_THEME="Rosé Pine Dawn"
VSC_EXTENSION="mvllow.rose-pine"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
