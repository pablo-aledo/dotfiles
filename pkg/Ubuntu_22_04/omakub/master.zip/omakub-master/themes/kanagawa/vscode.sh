#!/bin/bash

VSC_THEME="Kanagawa"
VSC_EXTENSION="qufiwefefwoyn.kanagawa"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
