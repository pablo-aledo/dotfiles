#!/bin/bash

VSC_THEME="Catppuccin Macchiato"
VSC_EXTENSION="Catppuccin.catppuccin-vsc"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
