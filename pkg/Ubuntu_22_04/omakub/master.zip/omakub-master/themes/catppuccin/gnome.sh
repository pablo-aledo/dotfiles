#!/bin/bash

OMAKUB_THEME_COLOR="magenta"
OMAKUB_THEME_BACKGROUND="catppuccin/background.png"
source $OMAKUB_PATH/themes/set-gnome-theme.sh
