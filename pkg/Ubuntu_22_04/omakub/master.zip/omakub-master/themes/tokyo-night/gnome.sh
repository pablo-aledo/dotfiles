#!/bin/bash

OMAKUB_THEME_COLOR="purple"
OMAKUB_THEME_BACKGROUND="tokyo-night/background.jpg"
source $OMAKUB_PATH/themes/set-gnome-theme.sh
