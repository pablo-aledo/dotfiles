#!/bin/bash

VSC_THEME="Tokyo Night"
VSC_EXTENSION="enkia.tokyo-night"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
