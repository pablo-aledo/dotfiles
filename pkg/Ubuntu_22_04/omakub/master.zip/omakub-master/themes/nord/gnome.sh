#!/bin/bash

OMAKUB_THEME_COLOR="blue"
OMAKUB_THEME_BACKGROUND="nord/background.png"
source $OMAKUB_PATH/themes/set-gnome-theme.sh
