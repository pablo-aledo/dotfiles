#!/bin/bash

VSC_THEME="Nord"
VSC_EXTENSION="arcticicestudio.nord-visual-studio-code"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
