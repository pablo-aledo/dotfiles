#!/bin/bash

VSC_THEME="Gruvbox Dark Medium"
VSC_EXTENSION="jdinhlife.gruvbox"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
