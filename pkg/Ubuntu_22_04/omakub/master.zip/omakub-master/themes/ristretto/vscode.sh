#!/bin/bash

VSC_THEME="Monokai Pro (Filter Ristretto)"
VSC_EXTENSION="monokai.theme-monokai-pro-vscode"
source $OMAKUB_PATH/themes/set-vscode-theme.sh
