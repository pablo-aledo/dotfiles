#!/bin/bash

OMAKUB_THEME_COLOR="grey"
OMAKUB_THEME_BACKGROUND="ristretto/background.jpg"
source $OMAKUB_PATH/themes/set-gnome-theme.sh
