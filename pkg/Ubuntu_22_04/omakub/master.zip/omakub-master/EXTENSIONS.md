# [Dark and light mode theme switch](https://github.com/florentdestremau/omakub-darkmode-switch)

Select a dark and light theme of your choice to be applied automatically when switching the gnome light/dark mode.

