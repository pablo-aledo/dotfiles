#!/bin/bash

sudo apt remove -y flameshot
