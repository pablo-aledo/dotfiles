#!/bin/bash

sudo apt remove typora -y
rm -rf ~/.config/Typora
