#!/bin/bash

sudo snap remove pinta
