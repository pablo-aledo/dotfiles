#!/bin/bash

flatpak uninstall -y flathub org.libretro.RetroArch
