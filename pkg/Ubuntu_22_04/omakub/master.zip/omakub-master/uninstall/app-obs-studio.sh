#!/bin/bash

sudo apt remove -y obs-studio
