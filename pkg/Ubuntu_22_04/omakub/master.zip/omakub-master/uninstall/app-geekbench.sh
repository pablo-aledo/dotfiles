#!/bin/bash

sudo rm -rf /usr/local/geekbench6
sudo rm -rf /usr/local/bin/geekbench6
