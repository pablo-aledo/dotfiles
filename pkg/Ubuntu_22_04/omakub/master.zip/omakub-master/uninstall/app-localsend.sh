#!/bin/bash

sudo apt remove -y localsend
