#!/bin/bash

sudo rm /opt/cursor.appimage
sudo rm /usr/share/applications/cursor.desktop
