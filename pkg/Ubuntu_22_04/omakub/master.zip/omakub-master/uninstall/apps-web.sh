#!/bin/bash

rm ~/.local/share/applications/WhatsApp.desktop
rm ~/.local/share/applications/Basecamp.desktop
rm ~/.local/share/applications/HEY.desktop
