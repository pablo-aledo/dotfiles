#!/bin/bash

sudo apt remove --purge -y emacs emacs-gtk
sudo rm -rf ~/.config/emacs
sudo rm -rf ~/.emacs.d
sudo rm -rf ~/.config/doom
