#!/bin/bash

sudo apt remove --purge -y signal-desktop
