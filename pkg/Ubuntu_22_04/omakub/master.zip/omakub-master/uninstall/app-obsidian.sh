#!/bin/bash

flatpak uninstall -y flathub md.obsidian.Obsidian
