#!/bin/bash

sudo apt remove -y openjdk-8-jdk minecraft-launcher
