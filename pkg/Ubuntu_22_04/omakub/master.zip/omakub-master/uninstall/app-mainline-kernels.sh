#!/bin/bash

sudo apt remove -y mainline
