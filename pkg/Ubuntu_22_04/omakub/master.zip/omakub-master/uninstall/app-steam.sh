#!/bin/bash

sudo apt remove -y steam steam-launcher
