#!/bin/bash

rm -rf ~/.local/zed.app
rm -rf ~/.local/bin/zed
rm -rf ~/.local/share/applications/dev.zed.Zed.desktop
rm -rf ~/.config/zed
