#!/bin/bash

sudo snap remove rubymine
