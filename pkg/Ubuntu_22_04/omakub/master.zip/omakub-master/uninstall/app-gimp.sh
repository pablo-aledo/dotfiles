#!/bin/bash

sudo flatpak remove -y org.gimp.GIMP
