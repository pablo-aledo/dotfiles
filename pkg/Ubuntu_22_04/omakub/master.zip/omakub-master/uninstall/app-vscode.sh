#!/bin/bash

sudo apt purge -y remove code
rm -rf ~/.config/Code/User
