#!/bin/bash

sudo apt remove -y fastfetch
