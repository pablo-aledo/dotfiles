#!/bin/bash

flatpak uninstall -y flathub org.audacityteam.Audacity
