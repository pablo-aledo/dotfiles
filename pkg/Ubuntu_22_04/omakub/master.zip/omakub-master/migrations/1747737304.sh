#!/bin/bash

# Ensure btop themes folder is available
mkdir -p ~/.config/btop/themes
