#!/bin/bash

source $OMAKUB_PATH/install/desktop/app-wl-clipboard.sh
