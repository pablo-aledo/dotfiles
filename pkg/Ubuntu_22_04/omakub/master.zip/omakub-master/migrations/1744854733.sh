#!/bin/bash

source $OMAKUB_PATH/install/desktop/set-alacritty-default.sh

nautilus -q
