#!/bin/bash

curl -fsSL https://tailscale.com/install.sh | sh
