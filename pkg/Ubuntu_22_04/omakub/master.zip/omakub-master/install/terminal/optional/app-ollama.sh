#!/bin/bash

curl -fsSL https://ollama.com/install.sh | sh
