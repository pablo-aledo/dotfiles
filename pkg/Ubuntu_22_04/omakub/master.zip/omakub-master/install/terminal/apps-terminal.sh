#!/bin/bash

sudo apt install -y fzf ripgrep bat eza zoxide plocate apache2-utils fd-find tldr
