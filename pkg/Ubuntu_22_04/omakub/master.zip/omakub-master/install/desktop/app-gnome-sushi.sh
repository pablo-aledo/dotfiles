#!/bin/bash

# Gives you previews in the file manager when pressing space
sudo apt install -y gnome-sushi
