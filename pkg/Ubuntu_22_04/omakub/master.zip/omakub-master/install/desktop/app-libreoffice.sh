#!/bin/bash

# Work with Word, Excel, Powerpoint files
sudo apt install -y libreoffice
