#!/bin/bash

source ~/.local/share/omakub/themes/tokyo-night/gnome.sh
source ~/.local/share/omakub/themes/tokyo-night/tophat.sh
