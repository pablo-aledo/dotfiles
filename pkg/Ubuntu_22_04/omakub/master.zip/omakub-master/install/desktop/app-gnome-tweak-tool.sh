#!/bin/bash

sudo apt install -y gnome-tweak-tool
