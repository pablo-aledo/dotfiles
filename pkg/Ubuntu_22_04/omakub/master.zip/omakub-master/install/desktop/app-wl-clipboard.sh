#!/bin/bash

# Provides a system clipboard interface for Neovim under Wayland
sudo apt install wl-clipboard
