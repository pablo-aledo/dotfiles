#!/bin/bash

sudo apt install -y xournalpp
