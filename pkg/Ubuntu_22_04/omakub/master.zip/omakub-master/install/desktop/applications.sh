#!/bin/bash

for script in ~/.local/share/omakub/applications/*.sh; do source $script; done
