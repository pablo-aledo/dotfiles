#!/bin/bash

flatpak install -y flathub org.audacityteam.Audacity
