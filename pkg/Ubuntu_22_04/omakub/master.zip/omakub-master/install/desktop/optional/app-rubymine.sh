#!/bin/bash

sudo snap install rubymine --classic
