#!/bin/bash

# Sync files across machines using https://dropbox.com
sudo apt install -y nautilus-dropbox >/dev/null
