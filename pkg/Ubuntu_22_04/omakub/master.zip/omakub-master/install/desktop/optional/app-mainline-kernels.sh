#!/bin/bash

sudo add-apt-repository -y ppa:cappelikan/ppa
sudo apt update -y
sudo apt install -y mainline
