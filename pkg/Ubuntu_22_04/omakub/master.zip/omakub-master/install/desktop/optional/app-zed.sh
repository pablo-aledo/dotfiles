#!/bin/bash

curl https://zed.dev/install.sh | sh
