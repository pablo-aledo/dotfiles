#!/bin/bash

flatpak install -y flathub org.libretro.RetroArch
