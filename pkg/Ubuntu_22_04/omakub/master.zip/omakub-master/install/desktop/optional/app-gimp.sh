#!/bin/bash

sudo flatpak install -y org.gimp.GIMP
