#!/bin/bash

# OBS Studio is a screen recording application that allows you to capture both display and webcam in the same recording
sudo apt install -y obs-studio
