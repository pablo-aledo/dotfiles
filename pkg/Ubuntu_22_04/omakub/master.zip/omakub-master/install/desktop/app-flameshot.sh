#!/bin/bash

# Flameshot is a nice step-up over the default Gnome screenshot tool
sudo apt install -y flameshot
