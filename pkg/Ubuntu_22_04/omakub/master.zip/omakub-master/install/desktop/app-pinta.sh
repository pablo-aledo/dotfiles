#!/bin/bash

# FIXME: Get this out of snap
sudo snap install pinta
