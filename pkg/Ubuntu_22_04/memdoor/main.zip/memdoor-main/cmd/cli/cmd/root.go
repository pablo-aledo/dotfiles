package cmd

import (
	"fmt"
	"golang.org/x/term"
	"os"
	"strings"

	"github.com/spf13/cobra"
)

var (
	gatewayAddr   string
	verbose       bool
	workspaceSlug string
)

// noWorkspaceTopLevels is the allowlist of top-level subcommands that
// do NOT require -w/--workspace. Everything else does — that's the
// uniform contract enforced by the PersistentPreRunE below.
//
// Why these are exempt:
//
//   - auth: login/logout/whoami runs before a workspace is even known
//   - gateway: starts/stops the daemon process, gateway-wide
//   - doctor: system diagnostics, gateway-wide
//   - setup: bootstraps the install before any workspace exists
//   - mcp: the person's MCP servers; every call names its project directory
//   - version: prints the binary version, no API call
//   - logs: queries the gateway-wide event log, not workspace-scoped
//
// Every other top-level command (channels, messages, agent, sessions,
// cron, secrets, rag, users, …) talks to a
// workspace-scoped API and MUST receive an explicit workspace.
var noWorkspaceTopLevels = map[string]bool{
	// The headless doors set the machine up themselves (firstRunReady in
	// their RunE): the gate must not fire first. Live 2026-10-11: on a GitHub
	// runner that had never seen Memdoor, `memdoor run` died at this gate
	// with "nothing is set up on this machine yet" before it could set it up.
	"run":       true,
	"workflow":  true,
	"connect":   true, // a provider is the gateway's (providers.json); the GitHub action connects its local model first
	"providers": true,
	"cron":      true,
	"resume":    true,
	"remote":    true,
	"peers":     true,
	"auth":      true,
	"gateway":   true,
	"doctor":    true,
	"setup":     true,
	"version":   true,
	"logs":      true,
	"billing":   true, // the billing service serves every workspace; it belongs to none
	"workspace": true, // `workspace which` resolves before any -w; `workspace use` sets it
	"ask":       true, // `ask --all` / `--workspaces <list>` runs without a single resolved workspace; the no-flag path validates inside the handler
	// savings reads ~/.memdoor/savings.jsonl, a machine-local ledger with no
	// workspace in it; requiring one failed outside a pinned directory
	// (onboarding walk, 2026-09-27).
	"savings": true,
	// meter reads ~/.memdoor/meter.jsonl, the same kind of machine-local
	// ledger; on a box with no pinned project it refused to print it
	// (production host, 2026-10-25).
	"meter":     true,
	"uninstall": true, // tears down the install; running pre-setup must work
	"upgrade":   true, // swaps the memdoor binary; orthogonal to any workspace
	"claude":    true, // `claude hook install` writes settings.json (no workspace); `claude hook capture` + `claude import` resolve opportunistically and validate in their own RunE
	// THE SIGN-IN CANNOT REQUIRE WHAT THE SIGN-IN CREATES (paid onboarding
	// walk, 2026-09-27). `memdoor login` is the FIRST command a person
	// runs after paying, in whatever directory they happen to be in, and it
	// answered "no workspace resolved for \"account\"" with four ways to fix a
	// problem they do not have — the workspace is named after the account this
	// very command is about to create. Exempt for the same reason as `auth`.
	"account": true,
	"login":   true, // the same sign-in under its short name
	"logout":  true, // forgetting a sign-in needs no workspace either
}

var rootCmd = &cobra.Command{
	Use:   "memdoor",
	Short: "Memdoor — the gateway that owns your agents' work; the window, the shell, the phone and CI are doors onto it",
	// WHAT A STRANGER READS FIRST (onboarding walk, 2026-09-27; realigned
	// 2026-10-23 to the daemon). Every line below is something they will
	// actually type.
	Long: `Memdoor is a gateway, a small daemon that owns the work of coding agents: it
runs the turns in your project on your own key, keeps the conversations, the
schedules and the workflow runs, and asks you only at a gate. The window, a
headless run, your phone, your editor and CI are doors onto the same gateway,
so a run started from one is finished from another. On a box that stays on, it
keeps working when every laptop is closed.

On this machine:
  export OPENROUTER_API_KEY=sk-or-...    # or ANTHROPIC_API_KEY, OPENAI_API_KEY, …; or memdoor connect
  cd <your-project> && memdoor           # the first run starts the gateway here and opens the window

On a box you can ssh to (a VPS, a Mac mini, Cloud Shell), with nothing installed there:
  memdoor --gateway ssh://you@box               # installs memdoor on the box, starts its gateway, opens the window on it
  memdoor --gateway ssh://you@box connect openrouter   # your key, kept on the box; every turn there runs on it
  memdoor --gateway ssh://you@box run "…"       # a turn there from a script or CI; --dir names a project on the box
  memdoor --gateway ssh://you@box remote --last # the link that opens that run on your phone; the box holds it

Workflows: say the steps in the window and it writes them as files in the repo;
memdoor workflow run <name> reruns them with no one watching, and a gate waits
for your yes. Pro (memdoor login) is what memdoor.ai hosts: workflow state across
machines, and the relay for a gateway kept to localhost.`,
	// SilenceUsage stops cobra from dumping the full --help block
	// after every RunE error. Subcommands inherit this — routine
	// errors ("not authenticated", "no LLM key") print just the
	// message instead of pages of usage noise.
	SilenceUsage: true,
	// THE BARE NAME IS THE WINDOW (Greg, 2026-10-21: "Why not memdoor
	// directly?"): like claude, codex, aider and pi, `memdoor` at a terminal
	// opens the window in the current directory; `memdoor tui` stays. In a
	// pipe or CI there is no window to open, so the help is printed and
	// `memdoor run` is the door.
	// (Wired in init below: naming runTUI here is an initialization cycle.)
	Args: cobra.NoArgs,
	// SilenceErrors stops cobra from printing the "Error: …" line
	// itself; Execute() below prints the error exactly once with our
	// own format. Without this, missing-flag errors and similar were
	// printed twice.
	SilenceErrors: true,
}

// projectDirFlag is --dir, one flag for every command that works in a
// project: the window, run, workflow, cron add, peers add.
var projectDirFlag string

func init() {
	rootCmd.PersistentFlags().StringVar(&projectDirFlag, "dir", "", "the project directory: here by default; on a gateway elsewhere (--gateway, or a peer), the directory on that machine")
	rootCmd.RunE = func(cmd *cobra.Command, args []string) error {
		if term.IsTerminal(int(os.Stdin.Fd())) && term.IsTerminal(int(os.Stdout.Fd())) {
			return runTUI(tuiOptions{dir: projectDirFlag})
		}
		return cmd.Help()
	}
}

func Execute() {
	// assignCommandGroups runs after every per-command init() has
	// registered against rootCmd, so it can safely walk Commands()
	// and tag each one with its GroupID for the --help layout.
	assignCommandGroups()
	hideNonCodingCommands()
	err := rootCmd.Execute()
	closeSSHDoor() // the tunnel ends with the command, on every path that returns here
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

// THIS IS A CODING AGENT (Greg, 2026-09-27: "this is coding agent only",
// "less is more"). The binary grew commands for every epoch it has lived
// through — a creator funnel, workspace administration, an operator's billing
// service — and a solo developer who installed a coding agent should not have
// to read past them to find `tui`.
//
// Nothing is removed: every command below still runs, exactly as before, and is
// still in its own `--help`. They are only left out of the top-level listing.
var notCodingCommands = []string{
	// The creator funnel and workspace administration.
	"users",
	// Multi-party plumbing the window drives for you.
	"channels", "messages", "sessions",
	// Operator and recovery surfaces.
	"billing",
	// The gateway's own sign-in, by hand: `memdoor login` sets it up
	// for a person; scripts keep `auth token` / `login-direct` / `whoami`
	// (2026-10-03: three sign-in families, two identities, one broken flow).
	"auth",
	// A capability the agent reaches through a tool, not the person through
	// a command: the browser. A schedule is a door (memdoor cron add), listed.
	"chrome",
}

func hideNonCodingCommands() {
	hide := make(map[string]bool, len(notCodingCommands))
	for _, n := range notCodingCommands {
		hide[n] = true
	}
	for _, c := range rootCmd.Commands() {
		if hide[c.Name()] {
			c.Hidden = true
		}
	}
}

// requireWorkspaceSlug runs before every subcommand. It runs the
// resolution chain (flag → env → .memdoor/workspace walk-up → config
// default) and writes the result back into the package-level
// workspaceSlug var so every existing command's RunE keeps working
// unchanged. Allowlisted top-level commands (see noWorkspaceTopLevels)
// are skipped entirely — they may run with no workspace at all.
func requireWorkspaceSlug(cmd *cobra.Command, _ []string) error {
	// Walk up to the top-level subcommand. cmd.Name() for
	// "workspace use" returns "use"; we want "workspace".
	top := cmd
	for top.Parent() != nil && top.Parent() != rootCmd {
		top = top.Parent()
	}
	if top == rootCmd {
		// The bare name is the window: it resolves the workspace exactly as
		// `tui` does (pinned, env, the only one), and a machine with none is
		// the window's own first run. Without this, `memdoor` at a terminal
		// opened nothing and said "no workspace resolved" (2026-10-21).
		if slug, source, ok := resolveWorkspaceSlug(); ok {
			workspaceSlug = slug
			logResolvedWorkspace(slug, source)
		} else if only, single := soleWorkspace(); single {
			workspaceSlug = only
		}
		return nil
	}
	if noWorkspaceTopLevels[top.Name()] {
		// Even for exempt commands, run resolution so subcommands
		// like `workspace which` see the same answer the rest of the
		// CLI would. Don't fail when nothing resolves.
		if slug, source, ok := resolveWorkspaceSlug(); ok {
			workspaceSlug = slug
			logResolvedWorkspace(slug, source)
		} else if only, single := soleWorkspace(); single {
			// The one workspace there is, on this machine or on the
			// gateway --gateway names: a fresh laptop's `memdoor --gateway
			// <box> run "…"` was refused by the box with "workspace is
			// required" (the ssh door, 2026-10-23).
			workspaceSlug = only
		}
		return nil
	}
	// `model check` asks a model whether it can run a coder turn and reads the
	// reports in ~/.memdoor/model-checks.json. No workspace is involved, and the
	// person most likely to run it — someone deciding which model to pin before
	// they have set anything up — has none (battle test, 2026-09-27). The rest
	// of `model` shows an agent's ladder, which IS workspace-scoped.
	if top.Name() == "model" && cmd.Name() == "check" {
		if slug, source, ok := resolveWorkspaceSlug(); ok {
			workspaceSlug = slug
			logResolvedWorkspace(slug, source)
		}
		return nil
	}
	slug, source, ok := resolveWorkspaceSlug()
	if !ok {
		// The only workspace on the machine is the default one: a question
		// with a single possible answer is not a question (workspace_discovery.go).
		if only, single := soleWorkspace(); single {
			slug, source, ok = only, workspaceSource{kind: "only workspace"}, true
		}
	}
	if !ok && (top.Name() == "tui" || top.Name() == "acp") && len(listAllWorkspaceSlugs()) == 0 {
		// A machine with no workspace at all is a first run: the TUI sets
		// it up itself (tui_firstrun.go) instead of sending a stranger to
		// `memdoor setup` (stranger walk, 2026-10-08).
		return nil
	}
	if !ok {
		return noWorkspaceErrorMessage(top.Name())
	}
	workspaceSlug = slug
	logResolvedWorkspace(slug, source)
	return nil
}

// logResolvedWorkspace emits one stderr line in verbose mode when the
// workspace came from anywhere other than the explicit -w flag. The
// flag case is silent because the user already typed the slug — they
// don't need to be told which workspace they targeted.
func logResolvedWorkspace(slug string, source workspaceSource) {
	if !verbose || source.kind == "flag" {
		return
	}
	fmt.Fprintf(os.Stderr, "memdoor: workspace %q (from %s)\n", slug, source)
}

func init() {
	// MEMDOOR_GATEWAY is documented as the address the CLI talks to and was
	// read by nothing: the flag's default won, so a gateway on another port was
	// unreachable (onboarding walk, 2026-09-27). The flag still wins when given.
	defaultGateway := "http://localhost:18789"
	if v := strings.TrimSpace(os.Getenv("MEMDOOR_GATEWAY")); v != "" {
		defaultGateway = v
	}
	rootCmd.PersistentFlags().StringVar(&gatewayAddr, "gateway", defaultGateway, "Gateway address (or MEMDOOR_GATEWAY): a URL, host:port, a bare host or IP (http, port 18789), or ssh://[user@]box[:port] for a gateway reached through ssh")
	rootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", false, "Enable verbose output")
	rootCmd.PersistentFlags().StringVarP(&workspaceSlug, "workspace", "w", "", "Workspace slug. Optional — overrides auto-discovery (env $MEMDOOR_WORKSPACE → .memdoor/workspace walked up from cwd → ~/.memdoor/config.json). Run 'memdoor workspace which' to see what would resolve.")
	// Wired here (not on the rootCmd literal) to avoid an init cycle:
	// the closure references rootCmd to detect the top-level subcommand.
	rootCmd.PersistentPreRunE = func(cmd *cobra.Command, args []string) error {
		if isSSHAddr(gatewayAddr) {
			local, err := openSSHDoor(gatewayAddr)
			if err != nil {
				return err
			}
			gatewayAddr = local
		}
		gatewayAddr = canonicalGatewayAddr(gatewayAddr)
		return requireWorkspaceSlug(cmd, args)
	}
	// After a command succeeds, print a consistent "what to do next" line
	// (see suggest.go). Cobra runs PersistentPostRunE only on RunE success.
	rootCmd.PersistentPostRunE = printNextStep
}
