package cmd

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"memdoor/pkg/shared"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"memdoor/cmd/tui/ui"
	"memdoor/gateway/client"
	"memdoor/gateway/protocol"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/gorilla/websocket"
	qrterminal "github.com/mdp/qrterminal/v3"
	"golang.org/x/crypto/hkdf"
)

// REMOTE CONTROL (Greg, 2026-09-28: "remote control"): /remote gives this
// conversation a link and a QR code to open it on another device, and the
// TUI runs the terminal side of the relay while the conversation is open.
//
// The link is <relay host>/r/<id>#k=<key>. The id names the conversation to
// the relay; the key encrypts everything that passes through it, and it sits
// after "#", the part of a link a browser never sends to a server — so the
// relay carries the session but cannot read it.
//
// TWO RELAYS. A gateway on another machine (a box that stays on, reached
// as --gateway <box>) is its own relay: the link is on that gateway, the
// terminal dials its /api/relay with the gateway's own token, and a phone
// that reaches the box reaches the daemon the way the laptop does. No
// memdoor.ai account, no plan (Greg, 2026-10-23: "a phone can connect to
// daemon", "no pro story"). A gateway on this machine sits behind the
// laptop's NAT, so its link goes through memdoor.ai, the outbound tunnel a
// phone reaches without port forwarding, with the memdoor.ai account token.
// Either way the conversation's event feed and the posted turns stay on the
// gateway this TUI talks to (remoteSession.Gateway and Token).

// remoteURL is where the link points and where the terminal's relay socket
// dials: the public relay host. Overridable so a local gateway can be
// tested end to end.
func remoteURL() string {
	// Only memdoor.ai or this machine (a self-hosted relay): the account
	// token and the session go there.
	if v := strings.TrimSpace(os.Getenv("MEMDOOR_REMOTE_URL")); v != "" && shared.AccountHostTrusted(v) {
		return strings.TrimRight(v, "/")
	}
	return "https://memdoor.ai"
}

// remoteRelayReconnectWait is the pause between reconnect attempts: the
// gateway being down must not spin the laptop awake.
const remoteRelayReconnectWait = 5 * time.Second

// remoteFrameMax is the largest frame the terminal reads from the relay: the
// relay's own cap (gateway/remote_relay.go, remoteRelayMaxFrame). A browser
// sends keys and short turns; nothing honest comes near it.
const remoteFrameMax = 4 << 20

// The two directions of the relay, bound into every frame as AES-GCM
// additional data: a frame sealed for one direction never opens in the other,
// so a reflected frame is rejected whatever its nonce.
const (
	remoteToBrowser  = "t2b"
	remoteToTerminal = "b2t"
)

// remoteHKDFSalt domain-separates this product's keys: the link key derives
// the AEAD key under info "session" and the browser's proof under
// "browser-auth". web/src/remoteCrypto.ts uses the same labels.
const remoteHKDFSalt = "memdoor/remote-control/v1"

// remoteLink is one conversation's remote identity, kept on this machine so
// the relay client can find it (~/.memdoor/remote.json).
type remoteLink struct {
	ChannelID string    `json:"channel_id"`
	ID        string    `json:"id"`
	Key       string    `json:"key"`
	Created   time.Time `json:"created"`
}

func remoteLinksPath() string {
	return shared.MemdoorHome("remote.json")
}

func loadRemoteLinks() map[string]remoteLink {
	links := map[string]remoteLink{}
	if b, err := os.ReadFile(remoteLinksPath()); err == nil {
		_ = json.Unmarshal(b, &links)
	}
	return links
}

func randomToken(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

// remoteLinkFor returns the conversation's link, making one the first time.
// "off" forgets it, so the old link and key stop meaning anything.
func remoteLinkFor(channelID string, off bool) (remoteLink, bool, error) {
	links := loadRemoteLinks()
	if off {
		_, had := links[channelID]
		delete(links, channelID)
		return remoteLink{}, had, saveRemoteLinks(links)
	}
	if l, ok := links[channelID]; ok {
		return l, true, nil
	}
	id, err := randomToken(12)
	if err != nil {
		return remoteLink{}, false, err
	}
	key, err := randomToken(32) // 256-bit key
	if err != nil {
		return remoteLink{}, false, err
	}
	l := remoteLink{ChannelID: channelID, ID: id, Key: key, Created: time.Now()}
	links[channelID] = l
	return l, false, saveRemoteLinks(links)
}

func saveRemoteLinks(links map[string]remoteLink) error {
	b, err := json.MarshalIndent(links, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(remoteLinksPath()), 0o700); err != nil {
		return err
	}
	return os.WriteFile(remoteLinksPath(), b, 0o600) // it holds keys: owner only
}

// url is the link on the relay host base.
func (l remoteLink) url(base string) string {
	return strings.TrimRight(base, "/") + "/r/" + l.ID + "#k=" + l.Key
}

// viewURL is the watch-only link (/remote view): after #v= it carries the
// session key and the relay proof, both derived from the link key, and not
// the link key itself. A page holding it reads every frame and joins the
// relay, and cannot derive the write key a turn must be sealed with.
// liveURL is the watch link as a bare page: ?live=1 before the fragment
// (the page draws the terminal alone, for a stream or an OBS source).
func liveURL(view string) string {
	if i := strings.Index(view, "#"); i >= 0 {
		return view[:i] + "?live=1" + view[i:]
	}
	return view + "?live=1"
}

func (l remoteLink) viewURL(base string) (string, error) {
	tok, err := remoteViewToken(l.Key)
	if err != nil {
		return "", err
	}
	return strings.TrimRight(base, "/") + "/r/" + l.ID + "#v=" + tok, nil
}

// qrText draws a link as a QR code in half-block characters.
func qrText(link string) string {
	var buf bytes.Buffer
	qrterminal.GenerateHalfBlock(link, qrterminal.L, &buf)
	return strings.TrimRight(buf.String(), "\n")
}

// remoteSession is what a conversation's relay needs from the TUI: where the
// gateway is, the credential it holds, the conversation, and how a turn is
// posted (the page's own poster, so a phone's turn is an ordinary turn).
type remoteSession struct {
	Gateway   string
	Token     string
	Workspace string
	ChannelID string
	// ChannelName and Dir: what a phone's turn is posted with (the
	// conversation's name for the index, the project it runs in), for the
	// gateway that hosts the link (remote_host.go).
	ChannelName string
	Dir         func() string
	// Account is the memdoor.ai account token: the relay host's credential
	// for /api/relay, distinct from the local gateway's.
	Account string
	// Relay, RelayToken and RelayWhy are settled by resolved(): where the
	// link lives, what the terminal dials it with, and when it is
	// memdoor.ai, why the gateway itself could not be.
	Relay, RelayToken, RelayWhy string
	Post                        func(text string) error
	// History reads the conversation's last turns from the gateway.
	History func() []ui.Message
	// TTY builds the TUI for this conversation, for the page's terminal view.
	TTY func() tea.Model
}

// direct reports whether the conversation's gateway is on another machine:
// then that gateway is the relay, as it stands.
func (s remoteSession) direct() bool {
	return strings.TrimSpace(s.Gateway) != "" && !shared.IsLoopbackURL(s.Gateway)
}

// remoteListen is the gateway's own address, from its /health.
type remoteListen struct {
	Host      string   `json:"host"`
	Port      int      `json:"port"`
	Addresses []string `json:"addresses"`
}

// gatewayListen asks the gateway where it listens. An unanswered question
// is no address.
func gatewayListen(gateway string) (remoteListen, bool) {
	c := &http.Client{Timeout: 2 * time.Second}
	resp, err := c.Get(strings.TrimRight(gateway, "/") + "/health")
	if err != nil {
		return remoteListen{}, false
	}
	defer resp.Body.Close()
	var body struct {
		Listen *remoteListen `json:"listen"`
	}
	if resp.StatusCode != http.StatusOK || json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&body) != nil || body.Listen == nil {
		return remoteListen{}, false
	}
	return *body.Listen, true
}

// resolved settles where this conversation's link lives, once: on the
// gateway itself whenever a phone could reach it, through memdoor.ai only
// when it could not (Greg, 2026-10-23: "/remote should not go through
// memdoor.ai anymore unless it's needed").
//
//   - a gateway on another machine: that gateway, as the window reaches it;
//   - a gateway reached through this machine's loopback (its own, or the end
//     of an ssh tunnel) that listens beyond localhost: the box's name through
//     the ssh door, else the first address the gateway names;
//   - a gateway on localhost alone: memdoor.ai, and RelayWhy says so.
func (s remoteSession) resolved() remoteSession {
	if s.Relay != "" {
		return s
	}
	gw := strings.TrimRight(strings.TrimSpace(s.Gateway), "/")
	if s.direct() {
		s.Relay, s.RelayToken = gw, s.Token
		return s
	}
	hosted := func(why string) remoteSession {
		s.Relay, s.RelayToken, s.RelayWhy = remoteURL(), s.Account, why
		return s
	}
	if gw == "" {
		return hosted("")
	}
	l, ok := gatewayListen(gw)
	if !ok {
		return hosted("")
	}
	if len(l.Addresses) == 0 {
		if sshDoorUp != nil {
			return hosted("the gateway on " + sshDoorHost() + " listens on localhost alone; there, memdoor gateway install --host 0.0.0.0 (or MEMDOOR_HOST=0.0.0.0) gives your phone a direct door")
		}
		return hosted("the gateway on this machine listens on localhost alone; MEMDOOR_HOST=0.0.0.0 before the next start (or memdoor gateway --host 0.0.0.0) gives your phone a direct door on this network")
	}
	host := l.Addresses[0]
	if sshDoorUp != nil {
		host = sshDoorHost()
	}
	s.Relay, s.RelayToken = "http://"+net.JoinHostPort(host, strconv.Itoa(l.Port)), s.Token
	return s
}

// hosted reports whether the link goes through memdoor.ai.
func (s remoteSession) hosted() bool { return s.resolved().Relay == remoteURL() }

// relayBase is where the link points and the terminal dials.
func (s remoteSession) relayBase() string { return s.resolved().Relay }

// relayToken is the credential the relay takes: the gateway's own token on
// the gateway's relay, the memdoor.ai account token on the hosted one.
func (s remoteSession) relayToken() string { return s.resolved().RelayToken }

// tuiRemote answers /remote and /remote off for one conversation, and keeps
// the relay running while the link exists.
func tuiRemote(unresolved remoteSession) func(arg string) (string, error) {
	return func(arg string) (string, error) {
		// Settled on every call: a gateway restarted on the network since
		// the last /remote moves the link onto itself.
		s := unresolved.resolved()
		if remoteHostedHere {
			return "Remote control is on: this is the phone's own view of the conversation, hosted by the gateway.", nil
		}
		if strings.TrimSpace(arg) == "off" {
			stopRemote(s.ChannelID)
			unhostRemoteOnGateway(s)
			_, had, err := remoteLinkFor(s.ChannelID, true)
			if err != nil {
				return "", err
			}
			if !had {
				return "Remote control was not on for this conversation.", nil
			}
			return "Remote control is off: the old link and its key no longer open this conversation.", nil
		}
		if s.hosted() {
			if s.Account == "" {
				return "", errors.New("remote control needs a memdoor.ai account: run `memdoor login you@example.com` first, then try /remote again")
			}
			// On the hosted relay remote is Pro: say so here, in the window,
			// instead of handing out a link the relay will refuse (the relay's own
			// check stays the authority). A self-hosted relay is never asked.
			if !shared.IsLoopbackURL(remoteURL()) && remoteNeedsPro() {
				return "", errRemoteIsPro
			}
		}
		// The link the gateway already hosts, from any window; else this
		// machine's, made now if needed, and handed to the gateway. A
		// gateway that cannot host it leaves the relay to this window.
		l, existing := s.hostedLink()
		if !existing {
			var err error
			if l, existing, err = remoteLinkFor(s.ChannelID, false); err != nil {
				return "", err
			}
		}
		held, err := hostRemoteOnGateway(s, l)
		if err != nil {
			return "", err
		}
		if !held {
			startRemote(s, l)
		}
		base := s.relayBase()
		view, err := l.viewURL(base)
		if err != nil {
			return "", err
		}
		if strings.TrimSpace(arg) == "view" {
			return fmt.Sprintf("A watch-only link to this conversation — whoever opens it sees the terminal and cannot type, up to 200 at once:\n\n%s\n\n%s\n\n"+
				"For a stream or a projector, the terminal alone: %s\n\n"+
				"/remote off revokes it, with the full link.", view, qrText(view), liveURL(view)), nil
		}
		lead := "Remote control for this conversation — open the link or scan the code:"
		if existing {
			lead = "Remote control is on for this conversation — the same link as before:"
		}
		carrier := "the relay only carries what it cannot read"
		why := ""
		if !s.hosted() {
			lead = "Remote control for this conversation, on your gateway at " + relayHostOf(base) + " — open the link or scan the code from a phone that reaches that machine:"
			if existing {
				lead = "Remote control is on for this conversation, on your gateway at " + relayHostOf(base) + " — the same link as before:"
			}
			carrier = "the gateway only carries what it cannot read"
		} else if s.RelayWhy != "" {
			why = "\n\nThrough memdoor.ai: " + s.RelayWhy + "."
		}
		if held {
			why += "\n\nYour gateway holds this link: it works with this window closed, and comes back when the gateway restarts."
		}
		return fmt.Sprintf("%s\n\n%s\n\n%s\n\nWatch only (sees, cannot type): %s\n\n"+
			"The key after # never leaves your devices; %s. "+
			"/remote off revokes both links.%s", lead, l.url(base), qrText(l.url(base)), view, carrier, why), nil
	}
}

// resumeRemote restarts the relay for a conversation that already has a
// link (a resumed conversation, a relaunched TUI): the link on the phone
// keeps working without typing /remote again.
func resumeRemote(s remoteSession) {
	if remoteHostedHere {
		return
	}
	if _, hosted := s.hostedLink(); hosted {
		return // the gateway holds it; this window is only a window
	}
	if l, ok := loadRemoteLinks()[s.ChannelID]; ok {
		if held, err := hostRemoteOnGateway(s.resolved(), l); !held && err == nil {
			startRemote(s.resolved(), l)
		}
	}
}

// remoteRelayTurn is a browser's turn: text to post, an answer to a pending
// question, a cancel of the running turn, or a request for the conversation
// so far (the page sends it each time its socket opens).
type remoteRelayTurn struct {
	Text       string `json:"text,omitempty"`
	QuestionID string `json:"question_id,omitempty"`
	Answer     string `json:"answer,omitempty"`
	Cancel     bool   `json:"cancel,omitempty"`
	History    bool   `json:"history,omitempty"`
	// The terminal view (tui_remote_tty.go): start or resize the phone's
	// TUI, and the keys typed into it.
	TTY   *remoteTTYSize `json:"tty,omitempty"`
	TTYIn string         `json:"tty_in,omitempty"`
	// Watch asks for the screen so far, addressed to the page that asked
	// (its random id): a page that opens late sees what the others see.
	Watch string `json:"watch,omitempty"`
}

// A page that opens mid-conversation is sent its last turns, so it does not
// start blank. Long replies are cut: the phone needs the gist, not the file.
const (
	remoteHistoryLimit   = 20
	remoteHistoryTextMax = 8000
	remoteHistoryWait    = 2 * time.Second
)

// remoteHistoryStream is the event stream the page reads history from
// (web/src/remoteTranscript.ts).
const remoteHistoryStream = "history"

type remoteHistoryLine struct {
	Role string `json:"role"` // "user" | "assistant"
	Text string `json:"text"`
}

// remoteHistoryEvent is the conversation so far as one agent-event-shaped
// frame: {"stream":"history","data":{"messages":[{role,text}…]}}.
func remoteHistoryEvent(msgs []ui.Message) ([]byte, error) {
	lines := make([]remoteHistoryLine, 0, len(msgs))
	for _, m := range msgs {
		text := m.Content
		if r := []rune(text); len(r) > remoteHistoryTextMax {
			text = string(r[:remoteHistoryTextMax]) + "…"
		}
		lines = append(lines, remoteHistoryLine{Role: m.Role, Text: text})
	}
	return json.Marshal(map[string]any{
		"stream": remoteHistoryStream,
		"data":   map[string]any{"messages": lines},
	})
}

// remoteRelayEndKind tells the relay the link was revoked (gateway/remote_relay.go).
const remoteRelayEndKind = "end"

// remoteRelayWire is one frame as it crosses the relay socket; the gateway
// forwards it verbatim. Payload is base64url(nonce ‖ AES-GCM ciphertext).
type remoteRelayWire struct {
	Kind    string `json:"kind"` // "event" (terminal -> browser) | "turn" (browser -> terminal)
	Payload string `json:"payload"`
}

// remoteSessionKey derives the AES-256 key from the link key.
func remoteSessionKey(key string) ([]byte, error) {
	prk := hkdf.Extract(sha256.New, []byte(key), []byte(remoteHKDFSalt))
	k := make([]byte, 32)
	if _, err := io.ReadFull(hkdf.Expand(sha256.New, prk, []byte("session")), k); err != nil {
		return nil, err
	}
	return k, nil
}

// remoteBrowserProof is what a browser shows the relay to join the session:
// an HKDF subkey of the link key under its own label, so it proves the key
// without revealing it or the AEAD key. The terminal registers
// remoteBrowserVerifier (its sha256) when it attaches.
func remoteBrowserProof(key string) (string, error) {
	prk := hkdf.Extract(sha256.New, []byte(key), []byte(remoteHKDFSalt))
	proof := make([]byte, 32)
	if _, err := io.ReadFull(hkdf.Expand(sha256.New, prk, []byte("browser-auth")), proof); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(proof), nil
}

// remoteBrowserVerifier is the value the terminal sends as ?verifier= on
// /api/relay: base64url(sha256(proof)).
func remoteBrowserVerifier(key string) (string, error) {
	proof, err := remoteBrowserProof(key)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256([]byte(proof))
	return base64.RawURLEncoding.EncodeToString(sum[:]), nil
}

// remoteWriteAEAD is the cipher a DRIVING frame from a page is sealed with:
// a turn, an answer, a stop, a key, a resize. Its key is an HKDF subkey of
// the link key under "write", which a view-only link (remoteViewToken) does
// not carry and cannot derive, so the terminal can tell a page that may
// drive from one that may only watch.
func remoteWriteAEAD(key string) (cipher.AEAD, error) {
	prk := hkdf.Extract(sha256.New, []byte(key), []byte(remoteHKDFSalt))
	k := make([]byte, 32)
	if _, err := io.ReadFull(hkdf.Expand(sha256.New, prk, []byte("write")), k); err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(k)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

// remoteViewToken is what follows #v= in a view-only link:
// base64url(session key ‖ browser proof), 64 bytes. Enough to read and to
// join; not enough to write.
func remoteViewToken(key string) (string, error) {
	sk, err := remoteSessionKey(key)
	if err != nil {
		return "", err
	}
	proof, err := remoteBrowserProof(key)
	if err != nil {
		return "", err
	}
	raw, err := base64.RawURLEncoding.DecodeString(proof)
	if err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(append(sk, raw...)), nil
}

// remoteAEAD is the session's AES-GCM cipher.
func remoteAEAD(key string) (cipher.AEAD, error) {
	k, err := remoteSessionKey(key)
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(k)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

// remoteSeal encrypts one payload for a direction under a fresh random
// nonce, carried in front of the ciphertext. A random 96-bit nonce per frame
// needs no state shared between the ends, survives dropped frames and
// reconnects, and never repeats in practice.
func remoteSeal(aead cipher.AEAD, dir string, plain []byte) (string, error) {
	nonce := make([]byte, aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	return remoteSealWithNonce(aead, dir, nonce, plain), nil
}

func remoteSealWithNonce(aead cipher.AEAD, dir string, nonce, plain []byte) string {
	return base64.RawURLEncoding.EncodeToString(aead.Seal(append([]byte(nil), nonce...), nonce, plain, []byte(dir)))
}

// remoteOpen decrypts a payload sealed for dir.
func remoteOpen(aead cipher.AEAD, dir, payload string) ([]byte, error) {
	raw, err := base64.RawURLEncoding.DecodeString(payload)
	if err != nil {
		return nil, err
	}
	if len(raw) < aead.NonceSize() {
		return nil, errors.New("remote frame too short")
	}
	return aead.Open(nil, raw[:aead.NonceSize()], raw[aead.NonceSize():], []byte(dir))
}

// remoteRelays are the relays running in this process, one per conversation.
var remoteRelays = struct {
	sync.Mutex
	byChannel map[string]*remoteRelay
}{byChannel: map[string]*remoteRelay{}}

func startRemote(s remoteSession, l remoteLink) {
	remoteRelays.Lock()
	defer remoteRelays.Unlock()
	if r, ok := remoteRelays.byChannel[s.ChannelID]; ok {
		if r.link.Key == l.Key {
			return
		}
		r.Close()
	}
	r := newRemoteRelay(s, l)
	remoteRelays.byChannel[s.ChannelID] = r
	go r.run()
}

// remoteHeldHere reports whether this process runs the relay for the
// conversation: the gateway could not take the link, so the window hosts.
func remoteHeldHere(channelID string) bool {
	remoteRelays.Lock()
	defer remoteRelays.Unlock()
	_, ok := remoteRelays.byChannel[channelID]
	return ok
}

// stopRemote revokes a conversation's link (/remote off): the relay is told
// to end the session, so pages on the old link close and say so.
func stopRemote(channelID string) {
	remoteRelays.Lock()
	defer remoteRelays.Unlock()
	if r, ok := remoteRelays.byChannel[channelID]; ok {
		r.revoked.Store(true)
		r.Close()
		delete(remoteRelays.byChannel, channelID)
	}
}

// remoteRelay is the terminal side of one conversation's relay. It follows
// the conversation's agent events on its own gateway websocket (the one the
// TUI screen uses is the TUI's), seals each for the browser, and turns the
// browser's frames into posted turns, answers and cancels.
type remoteRelay struct {
	s      remoteSession
	link   remoteLink
	events chan []byte
	ttyOut chan []byte
	closed chan struct{}
	once   sync.Once

	ttyMu sync.Mutex
	tty   *remoteTTY

	// revoked: closed by /remote off, not by the TUI quitting. The relay is
	// told to end the session; a TUI that quits leaves it, so the link works
	// again when the conversation is reopened.
	revoked atomic.Bool
}

func newRemoteRelay(s remoteSession, l remoteLink) *remoteRelay {
	return &remoteRelay{s: s, link: l, events: make(chan []byte, 256), ttyOut: make(chan []byte, 16), closed: make(chan struct{})}
}

// Close stops the relay: no reconnect, no more frames either way.
func (r *remoteRelay) Close() {
	r.once.Do(func() {
		close(r.closed)
		r.stopTTY()
	})
}

func (r *remoteRelay) run() {
	feed, err := r.follow()
	if err != nil {
		return
	}
	defer feed.Close()
	for {
		err := r.attach(feed)
		if err == nil || errors.Is(err, errRemoteIsPro) || errors.Is(err, errRemoteSessionGone) {
			// A plan refusal does not change in five seconds: stop, rather
			// than ask billing every five seconds for nothing (review,
			// 2026-10-04).
			return
		}
		select {
		case <-r.closed:
			return
		case <-time.After(remoteRelayReconnectWait):
		}
	}
}

// follow subscribes to the conversation's agent events. The client
// reconnects on its own when the gateway restarts.
func (r *remoteRelay) follow() (*client.Client, error) {
	opts := client.DefaultOptions()
	opts.EnableLogging = false
	opts.Workspace = r.s.Workspace
	opts.Channel = r.s.ChannelID
	opts.Token = r.s.Token
	c := client.New(r.s.Gateway, "", opts)
	c.OnMessage(protocol.MessageTypeAgentEvent, func(msg protocol.Message) error {
		b, err := json.Marshal(msg.Data)
		if err != nil {
			return nil
		}
		select {
		case r.events <- b:
		default: // no browser reading and the buffer is full: the phone misses a frame, the turn does not stall
		}
		return nil
	})
	for {
		if err := c.Connect(); err == nil {
			c.Listen()
			return c, nil
		}
		select {
		case <-r.closed:
			return nil, errors.New("closed")
		case <-time.After(remoteRelayReconnectWait):
		}
	}
}

// attach holds one relay socket until it breaks (error: reconnect) or the
// relay is closed (nil).
func (r *remoteRelay) attach(feed *client.Client) error {
	verifier, err := remoteBrowserVerifier(r.link.Key)
	if err != nil {
		return err
	}
	aead, err := remoteAEAD(r.link.Key)
	if err != nil {
		return err
	}
	wsURL, err := remoteWSURL(r.s.relayBase())
	if err != nil {
		return err
	}
	wsURL += "?" + url.Values{"id": {r.link.ID}, "verifier": {verifier}}.Encode()
	// The token rides the header, as on /ws, so it stays out of access logs.
	conn, resp, err := websocket.DefaultDialer.Dial(wsURL, http.Header{"Authorization": {"Bearer " + r.s.relayToken()}})
	if err != nil {
		// The relay says why in its body (remote is Pro on the hosted relay);
		// pass that sentence on instead of "bad handshake".
		if resp != nil && resp.StatusCode == http.StatusPaymentRequired {
			io.Copy(io.Discard, io.LimitReader(resp.Body, 512))
			return errRemoteIsPro
		}
		if resp != nil && resp.StatusCode == http.StatusUnauthorized {
			io.Copy(io.Discard, io.LimitReader(resp.Body, 512))
			return errRemoteSessionGone
		}
		return err
	}
	defer conn.Close()
	conn.SetReadLimit(remoteFrameMax)

	writeAEAD, err := remoteWriteAEAD(r.link.Key)
	if err != nil {
		return err
	}
	readerDone := make(chan struct{})
	go func() {
		defer close(readerDone)
		for {
			_, raw, err := conn.ReadMessage()
			if err != nil {
				return
			}
			var wire remoteRelayWire
			if json.Unmarshal(raw, &wire) != nil || wire.Kind != "turn" {
				continue
			}
			// Sealed with the write key: the full link, which may drive.
			// Sealed with the session key only: a view-only link, which may
			// read. Neither: not this link's, dropped.
			drive := true
			plain, err := remoteOpen(writeAEAD, remoteToTerminal, wire.Payload)
			if err != nil {
				drive = false
				if plain, err = remoteOpen(aead, remoteToTerminal, wire.Payload); err != nil {
					continue
				}
			}
			var turn remoteRelayTurn
			if json.Unmarshal(plain, &turn) == nil {
				r.handle(feed, turn, drive)
			}
		}
	}()

	for {
		select {
		case <-r.closed:
			if r.revoked.Load() {
				_ = conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
				_ = conn.WriteJSON(remoteRelayWire{Kind: remoteRelayEndKind})
			}
			return nil
		case <-readerDone:
			return errors.New("relay socket closed")
		case ev := <-r.events:
			if err := sendRemoteEvent(conn, aead, ev); err != nil {
				return err
			}
		case ev := <-r.ttyOut:
			if err := sendRemoteEvent(conn, aead, ev); err != nil {
				return err
			}
		}
	}
}

// sendRemoteEvent seals one event for the browser and writes it. Only a
// failed write is an error: the socket is gone.
func sendRemoteEvent(conn *websocket.Conn, aead cipher.AEAD, ev []byte) error {
	payload, err := remoteSeal(aead, remoteToBrowser, ev)
	if err != nil {
		return nil
	}
	raw, err := json.Marshal(remoteRelayWire{Kind: "event", Payload: payload})
	if err != nil {
		return nil
	}
	_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	return conn.WriteMessage(websocket.TextMessage, raw)
}

// handle acts on one browser turn: a cancel interrupts the running turn, an
// answer unblocks a pending question, text is posted as the next turn.
func (r *remoteRelay) handle(feed *client.Client, t remoteRelayTurn, drive bool) {
	if !drive {
		// A view-only page may ask to see; everything else is driving. Its
		// asking starts the terminal when none runs yet, at a stream's size:
		// an audience used to wait until someone opened the full link
		// (2026-10-24). A driving page that opens later resizes it.
		switch {
		case t.History:
			r.sendHistory()
		case t.Watch != "":
			r.ttyMu.Lock()
			none := r.tty == nil
			r.ttyMu.Unlock()
			if none {
				r.ttyScreen(remoteTTYSize{Cols: remoteWatchCols, Rows: remoteWatchRows})
			}
			r.ttyReplay(t.Watch)
		}
		return
	}
	switch {
	case t.Cancel:
		_ = feed.SendMessage(protocol.Message{Type: protocol.MessageTypeCancel})
	case t.QuestionID != "":
		_ = feed.SendAnswer(t.QuestionID, t.Answer)
	case t.History:
		r.sendHistory()
	case t.Watch != "":
		r.ttyReplay(t.Watch)
	case t.TTY != nil:
		r.ttyScreen(*t.TTY)
	case t.TTYIn != "":
		r.ttyType(t.TTYIn)
	case strings.TrimSpace(t.Text) != "" && r.s.Post != nil:
		_ = r.s.Post(t.Text)
	}
}

// sendHistory queues the conversation so far for the browser. It waits a
// little for room: unlike a live delta, a dropped history leaves the page blank.
func (r *remoteRelay) sendHistory() {
	if r.s.History == nil {
		return
	}
	b, err := remoteHistoryEvent(r.s.History())
	if err != nil {
		return
	}
	select {
	case r.events <- b:
	case <-r.closed:
	case <-time.After(remoteHistoryWait):
	}
}

// remoteWSURL is the relay host's /api/relay socket: wss on an https host,
// ws on a plain-http one (a gateway on a box, tests).
func remoteWSURL(base string) (string, error) {
	u, err := url.Parse(base)
	if err != nil || u.Host == "" {
		return "", fmt.Errorf("remote relay host %q is not a URL", base)
	}
	switch strings.ToLower(u.Scheme) {
	case "https", "wss":
		u.Scheme = "wss"
	case "http", "ws":
		u.Scheme = "ws"
	default:
		return "", fmt.Errorf("remote relay host %q has no http(s) scheme", base)
	}
	u.Path = "/api/relay"
	return u.String(), nil
}

// errRemoteIsPro is what a free account hears about remote control on the
// hosted relay — the same sentence the relay answers with (gateway
// remote_relay_auth.go).
// errRemoteSessionGone: the relay refused the terminal's token; retrying
// every five seconds would not change that (a hosted link whose session
// expired: /remote in a window hands over a fresh one).
var errRemoteSessionGone = errors.New("the relay refused this session: /remote again from a window")

var errRemoteIsPro = errors.New("remote control is a Pro feature on memdoor.ai: memdoor account subscribe, then /remote again")

// remoteNeedsPro reports whether the signed-in account is on the free plan.
// An unanswered question is not a refusal: the relay decides then.
func remoteNeedsPro() bool {
	var me meAnswer
	if err := brokerCall(http.MethodGet, "/v1/me", nil, &me); err != nil {
		return false
	}
	return strings.EqualFold(strings.TrimSpace(me.Plan), "free") || strings.TrimSpace(me.Plan) == ""
}

// relayHostOf is the host a link is on, for the line that names it.
func relayHostOf(base string) string {
	if u, err := url.Parse(base); err == nil && u.Host != "" {
		return u.Host
	}
	return base
}
