### Question
You are given a positive integer N and two strings S and T, each of length N and consisting of lowercase English letters.
Determine whether it is possible to make S identical to T by repeating the operation below any number of times (possibly zero). If it is possible, also find the minimum number of operations required.

- Choose two lowercase English letters x, y and replace every occurrence of x in S with y.

Input

The input is given from Standard Input in the following format:
N
S
T

Output

If it is possible to make S identical to T, print the minimum number of operations required. Otherwise, print -1.

Constraints


- 1\leq N \leq 2\times 10^5
- N is an integer.
- Each of S and T is a string of length N, consisting of lowercase English letters.

Sample Input 1

6
afbfda
bkckbb

Sample Output 1

4

By performing the operation four times in the following way, you can make S identical to T:

- Choose x= b and y= c. S becomes afcfda.
- Choose x= a and y= b. S becomes bfcfdb.
- Choose x= f and y= k. S becomes bkckdb.
- Choose x= d and y= b. S becomes bkckbb, which is identical to T.

It cannot be done with fewer than four operations, so the minimum number of operations required is 4.

Sample Input 2

4
abac
abac

Sample Output 2

0

S and T are already identical, so no operations are required.

Sample Input 3

4
abac
abrc

Sample Output 3

-1

No matter how you repeat the operation, it is impossible to make S identical to T.

Sample Input 4

4
abac
bcba

Sample Output 4

4

### Format: Read the inputs from stdin solve the problem and write the answer to stdout (do not directly test on the sample inputs). Enclose your code within delimiters as follows. Ensure that when the python program runs, it reads the inputs, runs the algorithm and writes output to STDOUT.

