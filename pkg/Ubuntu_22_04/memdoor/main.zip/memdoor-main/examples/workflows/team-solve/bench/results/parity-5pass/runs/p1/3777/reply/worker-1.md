### CODE
```python
from typing import List

class Solution:
    def maxProduct(self, nums: List[int], k: int, limit: int) -> int:
        n = len(nums)
        max_val = max(nums) if n else 0
        offset = max_val * ((n + 1) // 2)

        if abs(k) > offset:
            return -1

        size = 2 * offset + 1
        mask = (1 << size) - 1
        target = 1 << (offset + k)

        # Positive-product DP:
        # pos_even[p] / pos_odd[p] are bitsets of achievable alternating sums
        # for non-empty subsequences using only positive numbers, with product p
        # and even/odd length.
        pos_even = [0] * (limit + 1)
        pos_odd = [0] * (limit + 1)

        # Zero-product feasibility DP:
        # no_zero_even includes the empty subsequence (sum 0).
        no_zero_even = 1 << offset
        no_zero_odd = 0
        has_zero_even = 0
        has_zero_odd = 0

        for x in nums:
            if x == 0:
                ne, no, he, ho = no_zero_even, no_zero_odd, has_zero_even, has_zero_odd

                # Taking a zero flips parity and makes the product zero.
                has_zero_even = (he | no | ho) & mask
                has_zero_odd = (ho | ne | he) & mask
                # no_zero_even and no_zero_odd only skip this zero.
            else:
                ne, no, he, ho = no_zero_even, no_zero_odd, has_zero_even, has_zero_odd

                # Sum-only DP for zero-product feasibility. This intentionally
                # keeps positive prefixes even if their product exceeds limit.
                no_zero_even = (ne | (no >> x)) & mask
                no_zero_odd = (no | (ne << x)) & mask
                has_zero_even = (he | (ho >> x)) & mask
                has_zero_odd = (ho | (he << x)) & mask

                # Positive-product DP only stores products <= limit.
                if x <= limit:
                    old_even = pos_even.copy()
                    old_odd = pos_odd.copy()

                    # Start a new subsequence [x].
                    pos_odd[x] |= (1 << (offset + x)) & mask

                    maxp = limit // x
                    pe = pos_even
                    po = pos_odd
                    m = mask
                    xx = x

                    for p in range(1, maxp + 1):
                        np = p * xx

                        b = old_even[p]
                        if b:
                            # Even length -> next sign is plus.
                            po[np] |= (b << xx) & m

                        b = old_odd[p]
                        if b:
                            # Odd length -> next sign is minus.
                            pe[np] |= b >> xx

        # Prefer any positive product over zero.
        for p in range(limit, 0, -1):
            if (pos_even[p] & target) or (pos_odd[p] & target):
                return p

        # Otherwise, zero product is valid if achievable.
        if (has_zero_even & target) or (has_zero_odd & target):
            return 0

        return -1
```

### NOTES
- **Solution split:** Separate positive-product subsequences (no zeros) from zero-product subsequences (at least one zero). Any positive product is better than 0, so scan positive products first; return 0 only if a zero-product subsequence can hit k.
- **Sum bound:** For a subsequence of length m, plus terms are ceil(m/2), minus terms floor(m/2). With nums[i] in [0,12], |alt sum| <= max(nums)*ceil(n/2). Use this as bitset offset; if abs(k) > offset return -1.
- **Bitset encoding:** bit i represents sum i-offset. Adding x is left shift by x; subtracting x is right shift by x. Mask to 2*offset+1 bits after left shifts/ORs.
- **Positive DP:** `pos_even[p]` and `pos_odd[p]` are bitsets of sums for non-empty positive-only subsequences with product p and even/odd length. For each x>0, snapshot both lists. Start [x] in `pos_odd[x]` at sum x. For p=1..limit//x, extend old even p to odd p*x with +x, and old odd p to even p*x with -x. Snapshot is essential for x=1 and for not reusing the same element.
- **Product cap safety:** Positive products are nondecreasing (values >=1). If a prefix product exceeds limit, no extension can become valid positive, so discarding over-limit positive states is safe.
- **Zero DP:** Four bitsets: `no_zero_even/odd` (no zero selected; `no_zero_even` includes empty sum 0) and `has_zero_even/odd`. For x>0, update like a sum-only parity DP: even -> odd with +x, odd -> even with -x, for both no-zero and has-zero families. This keeps over-limit positive prefixes, needed because a later zero can make product 0. For x==0, taking zero flips parity and moves to has-zero: `has_zero_even = old_has_even | old_no_odd | old_has_odd`, `has_zero_odd = old_has_odd | old_no_even | old_has_even`; no-zero states only skip.
- **Final answer:** Scan p from limit down to 1; first p with target bit in either parity is max positive product. Else if target bit in `has_zero_even` or `has_zero_odd`, return 0. Else -1.
- **Edge cases:** all zeros gives offset 0 and returns 0 for k=0; x>limit is ignored by positive DP but still processed by zero DP; empty subsequence exists only in `no_zero_even` and is never returned; product 1 and repeated ones handled by snapshot; limit small cases work.
- **Complexity:** Bitset length at most 1801 bits. Positive loop cost sum over x>0 of limit//x, at most 750k iterations for n=150, limit=5000, each with small big-int shifts. Memory is two lists of limit+1 ints plus four bitsets, a few MB worst case.
- **Verification:** Examples 1-3 produce 6, -1, 9. A brute-force mask enumeration for small n (all subsequences, compute alternating sum and product) matches the DP on random small arrays including zeros and limit constraints.

### NEXT
none

### STATUS
solved
