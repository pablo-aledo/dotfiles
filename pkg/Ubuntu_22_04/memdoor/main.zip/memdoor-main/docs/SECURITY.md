# Where your data goes

The page for a security reviewer: every host the `memdoor` binary can name,
what it is, and when — if ever — it is contacted. `gateway/egress_test.go`
fails the build when the binary names a host this page does not list, so
the table is complete by construction (2026-10-02).

Memdoor is one static binary running on the developer's machine. Files,
sessions, memory, the index of the project and every command the agent runs
stay on that machine. What leaves is what a model has to read — the prompt
and the excerpts the agent chose — and it goes to exactly one of three
places, chosen by configuration, never mixed:

| Mode | Set by | Where prompts go | Nothing else is contacted? |
|---|---|---|---|
| **Your company's AI gateway** | `AI_GATEWAY_BASE_URL` + `AI_GATEWAY_TOKEN` (or any `*_AI_GATEWAY_TOKEN`: a personal or service-account token) + `MEMDOOR_MODEL` = the provider slug | `POST <base>/v1/responses` on that gateway (the OpenAI Responses shape; `AI_GATEWAY_API=chat` for chat/completions) | **Yes.** Nothing but the gateway. Comes before any vendor key. |
| **Your company's vendor key** | `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `XAI_API_KEY`, `BASETEN_API_KEY`, `GROQ_API_KEY` or `DEEPSEEK_API_KEY` (+ `*_BASE_URL` for a proxy in front) | That vendor, or the proxy in front of it | **Yes.** No OpenRouter, no memdoor.ai (it never sees a model request), no catalogue, no web search. `MEMDOOR_VENDOR_HEADERS` adds attribution headers to every request. |
| Your own OpenRouter key | `OPENROUTER_API_KEY` | OpenRouter, with `data_collection: deny` and hosts that train on inputs excluded; a `:free` model is the exception, pinned or the one an account with no credit answers on (`allow`, warned at the pin or the connect) | OpenRouter also serves the model catalogue and web search. |
| A provider you connected | `memdoor connect`, kept in `~/.memdoor/providers.json` | That provider | Used when no key above is set, or when you pin one of its models. A host that lists apps (Vercel AI Gateway, LLM Gateway, EUrouter, Requesty) gets the same app headers as OpenRouter, Google its `x-goog-api-client`; the rest see only the User-Agent (`pkg/attribution`). |
| Your ChatGPT plan | `memdoor connect chatgpt` (Sign in with ChatGPT, in the browser; the tokens kept encrypted in `~/.memdoor/chatgpt-login.json`) | OpenAI's Responses API, with your plan's bearer token, `store: false` | Used like a connected provider. No API key, no client secret; `memdoor connect --remove chatgpt` signs out. |

The hosted gateway changes nothing about whose key a prompt is sent on: it never
supplies a model key. No memdoor.ai call carries a prompt in the clear (the hosts table below
lists them; the remote-control relay is sealed end to end).

## Every host the binary names

| Host | What | Contacted when |
|---|---|---|
| *(your gateway's host)* | The company's own AI gateway — not a literal in the binary; it comes from `AI_GATEWAY_BASE_URL` | Company-gateway mode, every model call |
| *(a box of yours, over ssh)* | The ssh door: `--gateway ssh://you@box` runs your own `ssh`, with its keys and config, to tunnel to the gateway on that box; over the same connection it reads the login that gateway generated for itself (`~/.memdoor/local-login` there). Not a literal in the binary | Only when you name the box, for the length of the command; nothing goes anywhere else |
| `api.anthropic.com` | Anthropic's Messages API | Company-key mode with `ANTHROPIC_API_KEY`; `ANTHROPIC_BASE_URL` replaces it with the company gateway |
| `auth.openai.com` | Sign in with ChatGPT: the authorize page (opened in your browser), the token endpoint, the signing keys (JWKS) | Only during `memdoor connect chatgpt`, and when the plan's access token is renewed (hourly, with the refresh token) |
| `api.openai.com` | OpenAI's Responses API on an `OPENAI_API_KEY` (since 2026-10-10; the chat endpoint refuses the gpt-6 models with tools); a signed-in ChatGPT plan's Responses requests and its model list | Company-key mode with `OPENAI_API_KEY`; `OPENAI_BASE_URL` replaces it. A ChatGPT plan: every model call. Also a row in the built-in model table (`pkg/domain/models.go`), never a call by itself |
| `generativelanguage.googleapis.com` | Gemini's OpenAI-compatible endpoint | Company-key mode with `GEMINI_API_KEY`; `GEMINI_BASE_URL` replaces it |
| `accounts.google.com`, `oauth2.googleapis.com`, `www.googleapis.com` | Sign in with Google on the web sign-in page: the consent page (the browser goes there), the token endpoint, the signing keys (JWKS) | Only on a gateway with `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` set (memdoor.ai has them), and only while someone clicks that button. Never from the CLI or a model call |
| `github.com`, `api.github.com` | Sign in with GitHub on the web sign-in page: the authorize page, the token endpoint, the signed-in user's name and verified e-mail | Only on a gateway with `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET` set, and only while someone clicks that button. `github.com` is also the address of the source and the install one-liners in `--help` text, never a call by itself |
| `api.x.ai` | xAI's Grok API (OpenAI-compatible) | Company-key mode with `XAI_API_KEY`; `XAI_BASE_URL` replaces it |
| `inference.baseten.co` | Baseten's inference API (OpenAI-compatible) | Company-key mode with `BASETEN_API_KEY`; `BASETEN_BASE_URL` replaces it |
| `api.groq.com` | Groq's inference API (OpenAI-compatible) | Company-key mode with `GROQ_API_KEY`; `GROQ_BASE_URL` replaces it |
| `api.deepseek.com` | DeepSeek's API (OpenAI-compatible) | Company-key mode with `DEEPSEEK_API_KEY`; `DEEPSEEK_BASE_URL` replaces it |
| `openrouter.ai` | Chat on your own OpenRouter key (each request names the app — `X-Title: Memdoor`, `HTTP-Referer: https://memdoor.ai` — for OpenRouter's apps page; never the person. Every request to every provider carries `User-Agent: Memdoor/<version> (+https://memdoor.ai)`; which other hosts read an app header is `pkg/attribution`, researched in docs/features/PROVIDERS.md); its model catalogue (`/model`, `/api/models`); web search; the decisions endpoint on a decision key; Sign in with OpenRouter (`memdoor connect openrouter-login`, `/connect`): the browser opens `openrouter.ai/auth`, and one POST to `/api/v1/auth/keys` exchanges the code for the person's own key; `/api/v1/key` (on that key, when the engine is chosen) says whether the account has credit, a free one answering on a `:free` model | Only with `OPENROUTER_API_KEY` (or `OPEN_ROUTER_API_KEY`) set and no company key, or when the person signs in with OpenRouter. Never in company-key mode (`byok_catalog.go` refuses without a key) |
| `memdoor.ai` | Billing and sign-in (`memdoor login`, `memdoor account`), the `/remote` relay for a gateway kept to localhost (sealed end to end), the hosted workflow state (`/state`, hosted gateway: a run's task names, statuses and outputs' names, never your code), `/share` links, the upgrade check (`memdoor upgrade`), opt-in telemetry | Sign-in, account status, `/remote`, `/share`, `memdoor upgrade`: only when you run them. Telemetry: only with `MEMDOOR_TELEMETRY_ENABLED=1` (default off). Also appears as e-mail addresses (`hello@`, `noreply@`) in the seat-request and billing code that runs on memdoor.ai itself |
| `api.typesafe.ai` | The decision model, direct | Only with `MEMDOOR_SYSTEMONE_API_KEY` set on the gateway (self-service decisions) |
| `models.dev` | The public model catalogue (context window and output cap per model), read when a provider's own list states no window | At most once a day, outside company-key mode only; kept in `~/.memdoor/models-dev.json`, which a company-key gateway reads without contacting the host. Carries no prompt |
| `registry.modelcontextprotocol.io` | The MCP server registry | Only `/mcp search` |
| `mcp.linear.app` | An example URL in the `/mcp` panel's help text | Never contacted by the binary; shown as an example |
| `ai-gateway.example.com` | The prefilled example in `memdoor connect`'s base-URL prompt | Never contacted; replaced by what you type |
| `api.stripe.com`, `api.resend.com` | Stripe, transactional e-mail | Only the `memdoor-billing` service on memdoor.ai; never from a developer's machine |

**The decision model is a hosted model.** Jev, by TypeSafe, answers the typed
questions (is this search hit relevant, is this turn still making progress)
with a probability; what it is asked about — the search hit, the file section,
the log lines being judged — leaves the machine to it, through OpenRouter on
your OpenRouter key or directly on a decision key. On a vendor key or a company
gateway alone it is **off**: nothing is judged off-machine, every read returns
unjudged, the agent works without the savings. `memdoor connect typesafe` turns
it on with a key of your own.

## Attribution headers

`MEMDOOR_ATTRIBUTION="user=…;team=…"` and `MEMDOOR_ATTRIBUTION_HEADERS=
"user=X-Email;team=X-Team"` put the person's fields on every vendor and
gateway request under the names the company's gateway expects; the
project's directory name and the conversation's session id travel the
same way (`X-Memdoor-Project`, `X-Memdoor-Session` unless renamed). No
prompt content is in them; they go only to the model endpoint.

## Providers you add

`memdoor connect` keeps a provider in `~/.memdoor/providers.json` (0600,
the directory 0700). The credential is stored as given — a literal, the
NAME of an environment variable, or `!command` — so a secret in your
company's tooling is never copied onto disk. The gateway probes a provider
(its model list, one small call) before keeping it, and contacts a provider
you added only when a model of its is pinned or its list is read. A local
runtime (`memdoor connect local`: Ollama, llama.cpp, janis, LM Studio on
this machine or on the box) is kept with no credential at all, and its
requests carry none; they go to the address you gave, normally localhost.

## Where the gateway listens

On this machine and on its network, port 18789, since 2026-10-23: a phone
on the same network reaches a `/remote` link on the gateway itself, with no
relay in between. Every door takes a token; `/health` and the sealed relay
pages are the only unauthenticated ones; the first account can only be made
from the machine itself (a request from the network is refused). It speaks
plain HTTP, so it belongs on a network you trust, or behind ssh, Tailscale or
a reverse proxy. `MEMDOOR_HOST=localhost` (or `--host localhost`) keeps it to
this machine, and a company preset can set that.

For a `/remote` link the gateway's own process is the terminal end of the
relay (since 2026-10-23), so the link outlives the window that made it. What
that takes is kept in `~/.memdoor/remote-hosted.json` on the gateway's
machine, mode 0600, and nowhere else: the link's id and key, the gateway
session token of the person who turned it on (the gateway follows and posts
as them), and where the link lives. `/remote off` deletes the entry.

## No "yolo" mode

Memdoor's default is always-auto. `MEMDOOR_APPROVE=changes` (or the
workspace setting `approve`) makes every command, file write and MCP tool
call wait for the person's yes in the terminal; no answer in five minutes
is a no. Reads never ask. `gateway/approval.go`. Rules that refuse a
call outright (`memdoor guards`: never `.env`, never `git push`) are in
[Boundaries](/docs/boundaries).

## What a company reviewer can check

- Set the three variables, start `memdoor gateway`, and read its first lines:
  `your company's <vendor> key serves this gateway; nothing else is
  contacted`. Then `memdoor logs query --regex "LLM request"` shows every
  model call with the model and the message count, and nothing to any other
  host appears in the log.
- `MEMDOOR_VENDOR=off` is the only way out of company-key mode, and it is
  an environment variable the company's preset controls. The same preset can
  set `MEMDOOR_APPROVE=changes`, which wins over the workspace setting.
- The decision model, the catalogue and web search are not degraded
  silently: the agent reads more instead (as without a decision key or an
  OpenRouter key), the
  catalogue is the one model the key names, and `web_search` answers that it
  has no key.
- `go test ./gateway/ -run TestEveryHostTheBinaryNamesIsDocumented` is the
  proof this table is complete for the build in hand.
