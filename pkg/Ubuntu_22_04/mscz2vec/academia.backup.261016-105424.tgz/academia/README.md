# Academia Mutopia

Recurso educativo interactivo sobre el ecosistema mutopia: fundamentos musicales y técnicos
de sus herramientas y cómo se encadenan en un flujo creativo.

**Uso:** abrir `index.html` en un navegador moderno (Chrome, Firefox, Edge, Safari).
No necesita servidor, conexión ni dependencias: todo (audio incluido) funciona desde `file://`.

## Contenido

| Fichero | Qué enseña | Herramientas cuya lógica se ejecuta en el navegador |
|---|---|---|
| `index.html` | Mapa interactivo del flujo, 11 recetas que lo recorren (3 de ellas, las cadenas más frecuentes del informe de flujos), 14 ideas transversales, atlas de las 169 herramientas con su papel en las recetas reales | — |
| `01-sonido.html` | Altura, serie armónica, aditiva, FM, Karplus-Strong, problema inverso, cadena de efectos, Mahalanobis, transcripción | genopatch (GA), audio_effects (orden de la cadena), audio_reference_scorer |
| `02-representacion.html` | Evento MIDI, 6 tokenizaciones, partitura.yaml, piano roll y chroma, vectores | music_transformer/remi/clara/piano_autocomplete/anticipation (tokens), midi2yaml, corpus_explorer (10 dims), analyzer nearest/diff |
| `03-armonia.html` | Modos, Krumhansl-Schmuckler, grados y funciones, progresiones, n-gramas, cadencias, expectativa, armonía negativa, pivote | chord_table (catálogo real de 101 entradas), chord_copilot (add-k), cadence_designer (12 tipos), leadsheet_realizer |
| `04-voces.html` | SATB, paralelas, corrección, contrapunto de Fux | voice_leader (DP), harmony_checker, counterpoint `_species1_csp` (H1–H6 + P1) |
| `05-melodia.html` | Contorno y crítica, transformaciones motívicas, periodo, Markov | melody_critic (port literal), variation_engine, leitmotif_analyst (juego inverso), phrase_builder |
| `06-ritmo.html` | Arquetipos de batería, síncopa, bajo como voz, cambio de compás | drummer `STYLE_ARCHETYPES` (literal), metric_analyzer (LHL, nPVI), bass_line_composer, meter_adapter |
| `07-forma.html` | Arcos narrativos, curvas, clímax áureo, verificación del plan, SSM | narrator `build_arc_curves` (literal), tension_designer, climax_engineer, silence_designer, arc_supervisor, harvester |
| `08-interpretacion.html` | Reglas de interpretación, tempo global, color orquestal, tocabilidad, transposición | performer, tempo_designer, orchestral_colorist `EMOTION_PALETTES` (literal), playability_auditor `INSTRUMENT_DB`, part_extractor |
| `09-maquinas.html` | Paradigmas, temperatura/top-p, genético, Re-Pair, difusión DDIM, morphing, familias neuronales | evolver/counterexample, grammar_composer (Re-Pair), diffusion_composer (DDIM x₀), morpher |
| `10-practica.html` | Dificultad, simplificación, digitación, plan de estudio, ejercicios, oído | practice_tutor, combined_simplifier, fingering (Viterbi), piano_duo_analyzer, etude_generator, ear_trainer |
| `11-flujos.html` | Cómo se encadenan las herramientas en 274 recetas reales: 9 arquetipos de cadena, el embudo de `midi_merge`, construir frente a inspeccionar, parámetros que no se exploran, medir frente a corregir | midi_merge y el grafo de flujos (datos de `assets/flujos.js`) |
| `taller.html` | El flujo completo: intención → plan → armonía → melodía → textura → expresión → crítica (con botón para aplicar las correcciones y volver a medir) → exportación (MIDI, curves.json, partitura.yaml, receta.sh) | theorist (léxico), narrator, chord_progression_generator, melody_conditioned, drummer, climax_engineer, performer |

## Estructura técnica

- `assets/core.js`: teoría musical, motor Web Audio (instrumentos y percusión sintetizados), secuenciador,
  piano roll, teclado, pentagrama, editor de curvas, escritor SMF (MIDI), quizzes y progreso (localStorage).
- `assets/composer.js`: mini-pipeline compositivo compartido por las lecciones 07, 08, 10 y el taller.
- `assets/tools.js`: catálogo generado a partir de `mutopia_compendio.pdf` y de los docstrings de cada script.
- `assets/chord_table.js`: el `TABLE` de `chord_table.py`.
- `assets/flujos.js`: datos de `informe_flujos_mutopia.html` ya normalizados (274 pipelines): por script, nº de pipelines,
  nº en que entra en la cadena que produce la obra, rol, subcomandos, parámetro dominante y compañeros; arquetipos de
  cadena, transiciones frecuentes y scripts sin uso. Lo lee `index.html` (atlas, recetas e ideas).
- `build/gen_flujos.py` y `build/check_flujos.py`: generan y verifican `flujos.js` (ver abajo).

## Datos de flujos (informe_flujos_mutopia.html)

El informe se integra como datos, no como página: así la academia sigue funcionando desde `file://`.

```
python build/gen_flujos.py  ruta/informe_flujos_mutopia.html    # escribe assets/flujos.js
python build/check_flujos.py ruta/informe_flujos_mutopia.html   # 17 comprobaciones; código 1 si alguna falla
```

La comprobación reproduce los totales del informe (274 pipelines, 174 piezas, 5.638 invocaciones, 71 scripts con uso y
98 sin uso sobre 169), recuenta de forma independiente los pipelines de cada script y exige que todos los nombres que
cita `flujos.js` existan en el catálogo.

Roles que muestra el atlas (se calculan con la fracción de pipelines en que el script forma parte de la cadena que
produce la obra): **cadena** (≥ 50 %), **a veces** (> 0 y < 50 %), **fuera** (0 %: se ejecuta, pero su salida no entra en
la obra) y **sin uso** (no aparece en ninguna receta). Salvedades que la interfaz repite en cada ficha: las aristas se
infieren de las recetas `.sh` (lo que viaja por flags o se lee a mano no se ve) y los conteos reflejan cómo se
diseñaron los lotes de reconstrucción, no preferencias libres de composición.

Comprobado: las 101 progresiones de `chord_table.py` resuelven igual en Python y en la academia
(4.920 acordes, 12 tónicas); el `melody_critic.py` real puntúa un MIDI exportado por el taller con el mismo valor que el port
en JavaScript, y `harmonic_analyzer.py` reconoce su armonía.

## Discrepancias entre el compendio, el código y el informe de flujos

- El catálogo (`tools.js`) tenía 163 entradas y el directorio 169 scripts: faltaban `fidelity_meter`, `form_analyzer`,
  `melody_selector`, `midi2plan`, `midi_doctor` y `suite_index` (la academia no los explicaba; `midi_doctor` está en 50
  pipelines). Se han añadido a partir de sus docstrings; no figuran en el compendio.
- El informe cuenta herramienta + subcomando (`analyzer compare`, `drummer add`, `midi_doctor fix`…): 75 entradas que
  son 73 scripts. Dos no son scripts del directorio: `fix_meta` (en 200 pipelines) y `seleccionar_pista_melodia` (en 50);
  se conservan en `flujos.js` como `noScript` y no tienen ficha.
- Las 9 categorías del informe (función) y las 12 etapas de la academia (momento del flujo) son ejes casi
  ortogonales: p. ej. los 18 scripts de «Transformación» caen en 7 etapas. No se ha forzado una tabla 1:1; cada script
  conserva su etapa del catálogo y el informe aporta el rol. El cruce está en `flujos.js` (`catCruce`).

- El compendio habla de 154 herramientas y de 70 progresiones en chord_table; el directorio tiene 163 scripts
  y el catálogo 101 entradas. El compendio cita `motif_table_v2.py`; el fichero es `motif_table.py`.
