# autoresearch-abc

Investigación autónoma de modelos de lenguaje para generación de música en formato ABC,
guiada opcionalmente por un modelo de preferencias musicales personal.

Basado en [autoresearch](https://github.com/karpathy/autoresearch) de Karpathy,
adaptado para corpus ABC en lugar de texto general, y con integración de
`preference_trainer.py` como reward model en la fase 2.

---

## Requisitos

- Python 3.10+
- [uv](https://astral.sh/uv) (gestor de paquetes)
- `abc2midi` (para fase 2)
- Claude Code (para el bucle autónomo de experimentación)
- GPU opcional — funciona en CPU

---

## Instalación

### 1. uv

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 2. abc2midi

```bash
sudo apt install abcmidi
```

### 3. Claude Code

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Requiere cuenta Claude Pro, Max, Team, Enterprise o Console.
El plan gratuito no incluye acceso a Claude Code.

### 4. Dependencias Python

Las instala `uv` automáticamente al primer `uv run`. Necesitas el `pyproject.toml`
del proyecto original (autoresearch) en el directorio de trabajo.

---

## Ficheros del proyecto

| Fichero | Descripción |
|---|---|
| `abc_prepare.py` | Preparación del corpus y tokenizador BPE. No modificar. |
| `abc_train.py` | Modelo GPT, bucle de entrenamiento, evaluación. El agente lo modifica. |
| `abc_program.md` | Instrucciones para el agente Claude Code. |
| `preference_trainer.py` | Modelo de preferencias musicales (fase 2). |
| `generate.py` | Generación de piezas ABC desde checkpoint y reproducción. |
| `pyproject.toml` | Dependencias del proyecto (del zip original de autoresearch). |

---

## Preparación del corpus

Coloca tus ficheros `.abc` en una carpeta (p.ej. `./mnt/`):

```bash
python abc_prepare.py --abc-dir ./mnt/
```

Esto crea en `~/.cache/autoresearch-abc/`:
- `data/train.txt` y `data/val.txt` — corpus dividido 95/5
- `tokenizer/tokenizer.pkl` — tokenizador BPE (vocab 512)

Solo hay que ejecutarlo una vez.

---

## Flujo de trabajo

El proceso tiene dos fases controladas por la variable `PHASE` en `abc_train.py`.

### Fase 1 — Solo lenguaje (`PHASE = 1`)

El modelo aprende la sintaxis ABC optimizando únicamente `val_bpb`
(bits por byte, menor es mejor). No se usan preferencias.

**Condición de avance:** `validity_ratio >= 0.5` en dos experimentos consecutivos
(fracción de muestras generadas que son ABC sintácticamente válido).

### Fase 2 — Lenguaje + preferencias (`PHASE = 2`)

Se activa cambiando `PHASE = 2` en `abc_train.py`. Al final de cada experimento:

1. Genera `PREF_EVAL_SAMPLES` piezas ABC por muestreo autoregresivo
2. Filtra las sintácticamente válidas
3. Las convierte a MIDI con `abc2midi`
4. Las evalúa con `preference_trainer.py eval --json`
5. Calcula `combined_score = (1 - PREF_WEIGHT) * (1/val_bpb) + PREF_WEIGHT * (pref_score/5)`

**Métrica de decisión en fase 2:** `combined_score` — mayor es mejor.

---

## Ejecución manual (sin agente)

### Inicializar git

```bash
git init
git add abc_prepare.py abc_train.py abc_program.md
git commit -m "baseline"
```

### Ejecutar un experimento

```bash
uv run abc_train.py
```

Al terminar imprime:

```
---
phase:            1
val_bpb:          3.091522
pref_score:       N/A
validity_ratio:   N/A
combined_score:   N/A
training_seconds: 300.0
total_tokens_M:   8.511
num_params_M:     0.197
depth:            2
model_dim:        64
```

### Extraer métricas de un log

```bash
grep "^phase:\|^val_bpb:\|^pref_score:\|^validity_ratio:\|^combined_score:" run.log
```

---

## Ejecución autónoma con Claude Code

### Entrenar el modelo de preferencias (necesario para fase 2)

```bash
python preference_trainer.py index ./mnt/ --extended-features
python preference_trainer.py train corpus.npz --rounds 30 --mode contrast \
    --soundfont /ruta/a/TimbreOfHeaven.sf2
```

Anota ~30 pares de piezas (20-30 min). Genera `prefs.prefs.json`.

### Arrancar el agente

```bash
cd /ruta/a/tu/proyecto
claude
```

Prompt inicial:

```
Lee abc_program.md y arranquemos una nueva sesión. Haz el setup primero.
```

El agente crea una rama `autoresearch/<tag>`, inicializa `results.tsv`,
y ejecuta el bucle de experimentación de forma indefinida —
modifica hiperparámetros, hace commits, registra resultados,
y avanza de fase cuando se cumple la condición.

### Seguimiento mientras corre

```bash
cat results.tsv          # tabla de resultados acumulados
tail -f run.log          # log del experimento en curso
git log --oneline        # historial de experimentos
```

---

## Generar y escuchar música

Al terminar cada run se guarda `model_checkpoint.pt`. Puedes generar piezas
en cualquier momento, incluso mientras el agente está entrenando en otra terminal.

```bash
# Generar 1 pieza y reproducirla
uv run generate.py --play

# Generar 5 piezas, solo las sintácticamente válidas
uv run generate.py --n 5 --only-valid

# Temperatura más baja = más predecible, menos errores de sintaxis
uv run generate.py --n 3 --temp 0.7

# Escuchar una pieza aleatoria del corpus original (sin modelo)
ls mnt/*.abc | shuf -n 1 | xargs -I{} abc2midi {} -o /tmp/sample.mid && timidity /tmp/sample.mid
```

Las piezas se guardan en `./generated/` como `.abc` y `.mid`.

**Nota:** en fase 1 temprana la mayoría de muestras serán inválidas — usa `--only-valid`
para filtrarlas. A medida que `val_bpb` baja el output mejora y empieza a sonar
como melodías reales del corpus.

### Opciones de generate.py

| Opción | Defecto | Descripción |
|---|---|---|
| `--checkpoint` | `model_checkpoint.pt` | Ruta al checkpoint |
| `--n` | `1` | Número de piezas a generar |
| `--temp` | `0.85` | Temperatura de muestreo |
| `--max-tokens` | `256` | Longitud máxima en tokens |
| `--only-valid` | — | Solo guardar piezas ABC válidas |
| `--out-dir` | `./generated` | Directorio de salida |
| `--play` | — | Reproducir la primera pieza válida |
| `--no-midi` | — | No convertir a MIDI |

---

## Hiperparámetros principales (abc_train.py)

| Variable | Defecto CPU | Descripción |
|---|---|---|
| `PHASE` | `1` | Fase activa (1 o 2) |
| `DEPTH` | `2` | Número de capas transformer |
| `ASPECT_RATIO` | `32` | model_dim = DEPTH × ASPECT_RATIO |
| `HEAD_DIM` | `32` | Dimensión por cabeza de atención |
| `TOTAL_BATCH_SIZE` | `1024` | Tokens por paso de optimización |
| `DEVICE_BATCH_SIZE` | `2` | Batch size por forward pass |
| `LR` | `3e-4` | Learning rate AdamW |
| `PREF_WEIGHT` | `0.3` | Peso de pref_score en combined_score |
| `PREF_TEMPERATURE` | `0.85` | Temperatura de muestreo ABC |
| `PREF_EVAL_SAMPLES` | `20` | Muestras a evaluar en fase 2 |

**Restricción importante:** `TOTAL_BATCH_SIZE` debe ser múltiplo de
`DEVICE_BATCH_SIZE × MAX_SEQ_LEN`. Con los defaults: múltiplo de `2 × 512 = 1024`.
Valores válidos: 1024, 2048, 4096, etc.

---

## Notas para CPU (sin GPU)

La versión incluida usa `F.scaled_dot_product_attention` de PyTorch en lugar
de Flash Attention 3, y AdamW en lugar de Muon. Funciona en cualquier máquina.

Con un T14 Gen 3 (Intel integrado) y los defaults:
- ~32ms por paso
- ~8500 pasos en 5 minutos
- ~8.5M tokens procesados por experimento

Empieza con modelos pequeños (`DEPTH=2`, `ASPECT_RATIO=32`) y sube gradualmente.

---

## Estructura de results.tsv

```
commit  phase  val_bpb  pref_score  validity_ratio  combined_score  memory_gb  status  description
```

Ejemplo:

```
a1b2c3d  1  3.091  N/A  N/A    N/A    —  keep     baseline
b2c3d4e  1  2.840  N/A  N/A    N/A    —  keep     depth=4 dim=128
c3d4e5f  1  2.710  N/A  N/A    N/A    —  keep     LR=1e-3
d4e5f6g  2  2.690  N/A  0.420  N/A    —  keep     diagnóstico validity
e5f6g7h  2  2.650  N/A  0.520  N/A    —  keep     validity>=0.5 primera vez
f6g7h8i  2  2.620  N/A  0.560  N/A    —  keep     validity>=0.5 → avanzar fase 2
g7h8i9j  2  2.600  2.4  0.580  0.952  —  keep     FASE 2 activada
```
