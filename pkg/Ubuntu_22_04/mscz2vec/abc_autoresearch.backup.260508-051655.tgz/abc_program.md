# autoresearch-abc

Investigación autónoma de modelos de lenguaje para generación de música en formato ABC,
con guía opcional de un modelo de preferencias musicales (`preference_trainer.py`).

El proceso tiene **dos fases explícitas** controladas por la variable `PHASE` en `abc_train.py`.

---

## Setup

Para iniciar un experimento, trabaja con el usuario para:

1. **Acordar un tag de sesión**: proponer un tag basado en la fecha (e.g. `abc_may5`).
   La rama `autoresearch/<tag>` no debe existir — es una sesión nueva.
2. **Crear la rama**: `git checkout -b autoresearch/<tag>` desde master.
3. **Leer los ficheros en scope**:
   - `abc_prepare.py` — preparación del corpus y tokenizador. **No modificar**.
   - `abc_train.py` — modelo, optimizador, bucle de entrenamiento. **Tú lo modificas**.
   - `abc_program.md` — estas instrucciones.
4. **Verificar datos**: comprobar que `~/.cache/autoresearch-abc/` contiene `data/train.txt`,
   `data/val.txt` y `tokenizer/tokenizer.pkl`. Si no, decirle al usuario:
   ```
   python abc_prepare.py --abc-dir ./abc/
   ```
5. **Verificar fase inicial**: confirmar que `PHASE = 1` en `abc_train.py`. Si no, corregirlo.
6. **Verificar modelo de preferencias** (informativo, no bloqueante): anotar si existe
   `prefs.prefs.json`. Se necesitará cuando llegue la fase 2.
7. **Inicializar results.tsv** con solo la cabecera.
8. **Confirmar y arrancar**.

---

## Las dos fases

### FASE 1 — Solo val_bpb (`PHASE = 1`)

**Objetivo**: que el modelo aprenda la sintaxis ABC y genere piezas válidas.

- La variable `PHASE = 1` está activa en `abc_train.py`.
- No se generan muestras ni se evalúan preferencias — la evaluación al final es
  únicamente `val_bpb` (igual que el autoresearch original).
- **Métrica de decisión**: `val_bpb` — MENOR es mejor.
- **Condición de avance a fase 2**: cuando en **dos experimentos consecutivos**
  `validity_ratio >= 0.5` (ver más abajo cómo medirlo).

Para medir `validity_ratio` en fase 1 sin activar el pipeline completo, puedes
añadir ocasionalmente un experimento de diagnóstico cambiando temporalmente
`PHASE = 2` sin modelo de preferencias — `pref_score` saldrá `N/A` pero
`validity_ratio` se calculará. Regresa a `PHASE = 1` para el experimento siguiente
si la condición de avance no se cumple aún.

### FASE 2 — val_bpb + pref_score (`PHASE = 2`)

**Objetivo**: que el modelo genere música que además se ajuste a tus preferencias.

- Cambiar `PHASE = 2` en `abc_train.py` cuando se cumpla la condición de avance.
- Al terminar el entrenamiento, el script genera `PREF_EVAL_SAMPLES` piezas ABC,
  las convierte a MIDI con `abc2midi`, y las evalúa con `preference_trainer eval --json`.
- **Métrica de decisión**: `combined_score` — MAYOR es mejor.
- **Requiere** que exista el modelo de preferencias (`prefs.prefs.json` u otro
  fichero `.prefs.*.json`). Si no existe, `pref_score` saldrá `N/A` y el agente
  debe usar solo `val_bpb` hasta que el usuario entrene el modelo.

---

## Métricas por fase

**Fase 1** — resumen al final del run:
```
phase:            1
val_bpb:          0.XXXXXX   ← MENOR es mejor
pref_score:       N/A
validity_ratio:   N/A
combined_score:   N/A
```

**Fase 2** — resumen al final del run:
```
phase:            2
val_bpb:          0.XXXXXX   ← MENOR es mejor (calidad lingüística)
pref_score:       X.XXXX     ← 0-5, MAYOR es mejor (calidad musical subjetiva)
validity_ratio:   0.XXX      ← fracción de muestras ABC válidas generadas
combined_score:   X.XXXXXX   ← métrica compuesta, MAYOR es mejor
```

**Notas sobre combined_score:**
- `combined_score = (1 - PREF_WEIGHT) * (1/val_bpb) + PREF_WEIGHT * (pref_score/5)`
- Un `pref_score` alto con `val_bpb` muy alto es sospechoso — puede ser degeneración.
- Si el modelo de preferencias tiene pocos ejemplos (< 20), considera `PREF_WEIGHT = 0.1`.

---

## Extracción de resultados

```bash
grep "^phase:\|^val_bpb:\|^pref_score:\|^validity_ratio:\|^combined_score:" run.log
```

Si el grep está vacío → crash. Ver stack trace:
```bash
tail -n 50 run.log
```

---

## Registro en results.tsv

Columnas (tab-separated, NO comas):

```
commit  phase  val_bpb  pref_score  validity_ratio  combined_score  memory_gb  status  description
```

Ejemplo de sesión completa con transición de fase:

```
commit   phase  val_bpb   pref_score  validity_ratio  combined_score  memory_gb  status   description
a1b2c3d  1      1.420000  N/A         N/A             N/A             2.1        keep     baseline fase1
b2c3d4e  1      1.310000  N/A         N/A             N/A             2.1        keep     depth=6
c3d4e5f  1      1.250000  N/A         N/A             N/A             2.1        keep     LR x0.5
d4e5f6g  2      1.230000  N/A         0.420           N/A             2.1        keep     diagnóstico validity
e5f6g7h  1      1.210000  N/A         N/A             N/A             2.1        keep     batch más pequeño
f6g7h8i  2      1.195000  N/A         0.560           N/A             2.1        keep     diagnóstico: validity>=0.5 primera vez
g7h8i9j  2      1.188000  N/A         0.580           N/A             2.2        keep     diagnóstico: validity>=0.5 segunda vez → avanzar a fase 2
h8i9j0k  2      1.182000  2.40        0.600           0.952           2.2        keep     FASE 2 activada con prefs
i9j0k1l  2      1.175000  2.65        0.630           0.961           2.2        keep     temperatura 0.75
j0k1l2m  2      1.180000  2.20        0.580           0.941           2.1        discard  LR x2, pref_score baja
```

---

## Bucle de experimentos

BUCLE INFINITO:

1. Ver estado git: rama/commit actual y fase activa (`grep "^PHASE" abc_train.py`)
2. Modificar `abc_train.py` con la idea experimental
3. `git commit`
4. Ejecutar: `uv run abc_train.py > run.log 2>&1`
5. Extraer métricas: `grep "^phase:\|^val_bpb:\|^pref_score:\|^validity_ratio:\|^combined_score:" run.log`
6. Si grep vacío → crash. Intentar fix. Si no es fácil → log "crash", continuar.
7. Registrar en results.tsv
8. **Regla de avance de fase**: si estás en fase 1 y acabas de ver `validity_ratio >= 0.5`
   por segunda vez consecutiva (en experimentos de diagnóstico) → cambiar `PHASE = 2`
   en `abc_train.py` para el siguiente experimento. Anotar el cambio en la descripción.
9. **Regla de keep/discard**:
   - Fase 1 (experimentos normales): `val_bpb` mejoró → keep; si no → discard + `git reset --hard HEAD~1`
   - Fase 1 (diagnósticos de validity): siempre keep si no crashea; son informativos
   - Fase 2: `combined_score` mejoró → keep; si no → discard + `git reset --hard HEAD~1`

**Timeout**: si un run supera 10 minutos → kill, tratar como crash.

**NUNCA PARAR**: una vez iniciado el bucle, no preguntar al usuario si continuar.
El usuario puede estar durmiendo. Continúa indefinidamente hasta que te interrumpan.

---

## Ideas de experimentos por fase

### Fase 1 — Mejorar val_bpb

- **Baseline primero**: ejecutar sin cambios para establecer la referencia.
- Buscar el `DEPTH` óptimo: probar 3, 4, 5, 6, 8
- Ajustar `TOTAL_BATCH_SIZE`: con corpus ABC pequeño, `2**13` o `2**14` puede
  dar más pasos de gradiente y convergencia más rápida
- Probar `WINDOW_PATTERN = "L"` vs `"SSSL"` — secuencias cortas pueden no
  beneficiarse de la ventana deslizante
- Explorar `HEAD_DIM`: 32 o 64 (el modelo es pequeño, no necesita 128)
- Ajustar `MATRIX_LR` entre 0.02 y 0.08
- Experimentar con `WARMDOWN_RATIO`: con pocos datos, más cooldown puede ayudar

**Cuándo hacer diagnósticos de validity** (con `PHASE = 2` sin prefs):
- Cada 5-8 experimentos de fase 1 para ver si el modelo ya genera ABC válido
- Si `validity_ratio < 0.2`: el modelo no ha visto suficientes épocas o es demasiado pequeño
- Si `validity_ratio` entre 0.2–0.5: la estructura básica emerge, optimizar val_bpb
- Si `validity_ratio >= 0.5` dos veces seguidas: pasar permanentemente a fase 2

### Fase 2 — Mejorar combined_score

- **Primera ejecución**: establecer baseline de fase 2 con los mejores parámetros de fase 1
- Ajustar `PREF_TEMPERATURE`: 0.6–0.7 para coherencia, 0.85–1.0 para variedad
- Subir `PREF_EVAL_SAMPLES` a 50 para estimación más robusta del pref_score
- Explorar `PREF_WEIGHT`: 0.2 si la señal de preferencias es débil, 0.4–0.5 si es fuerte
- Continuar mejorando val_bpb — sigue siendo el 70% de la métrica con PREF_WEIGHT=0.3
- Probar distintos seeds (`torch.manual_seed`) si el modelo parece atascado
