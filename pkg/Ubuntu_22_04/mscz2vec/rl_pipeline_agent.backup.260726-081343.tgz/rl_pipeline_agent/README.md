# rl_pipeline_agent — Agente RL para orquestación del pipeline de composición

Implementación de la especificación `rl_pipeline_agent_spec.md`: un entorno de
Reinforcement Learning en el que un agente aprende a **secuenciar llamadas a las
herramientas CLI del toolkit de composición** y a **elegir sus parámetros**, para
producir una obra completa a partir de un plan inicial (`narrator_plan.json`),
optimizando una recompensa compuesta por `arc_supervisor.py` (ajuste al arco
emocional) y un proveedor de evaluación intercambiable (`quality_scorer.py` /
`preference_trainer.py`).

## Estructura

```
rl_pipeline_agent/
├── manifest/
│   ├── state_schema.json     # vocabulario de estado (§2) — única fuente de verdad
│   └── tools.json            # ToolSpec declarativos (§4-5.1)
├── engine/
│   ├── predicates.py         # eval_predicate() — 9 operadores + param (§3)
│   ├── params.py             # resolución de rango/derived/wired + build_command
│   ├── renderers.py          # render_X() por parámetro complejo (curve)
│   ├── effects.py            # effects_X() por herramienta (produces)
│   ├── manifest_loader.py    # carga + valida manifest contra schema
│   └── eval_providers.py     # EvalProvider + fallback (§5.4.1)
├── env/
│   ├── pipeline_env.py       # PipelineEnv(gymnasium.Env) — §5
│   ├── action_mask.py        # compute_mask()
│   └── reward.py             # w_arc*arc + w_eval*eval (§5.4)
├── training/
│   ├── train_ppo.py          # PPO con action masking (implementación propia, §1)
│   └── config.yaml
└── tests/                    # tests de aceptación Fases 1-4
```

## Principios de diseño cumplidos

- **Extensible sin reescritura**: añadir una herramienta o parámetro = editar
  `manifest/tools.json` (datos declarativos). El código del entorno, el
  intérprete de predicados y la política no se tocan.
- **Precondiciones duras explícitas** (`requires`) vía máscara de acción, no
  aprendidas por ensayo-error.
- **Parámetros semánticos normalizados**: el agente emite valores 0..1; una
  función `render()` por parámetro complejo los traduce a la sintaxis real de la
  CLI. Dependencias parámetro↔parámetro vía `requires_local` (mismo lenguaje de
  predicados, contexto `local_params`).
- **Efectos función de los parámetros** (`produces`), no un dict fijo.
- **Reward terminal** con `arc_supervisor` (siempre disponible) + proveedor de
  evaluación intercambiable con fallback declarativo.

## Espacio de acción

`Tuple(Discrete(N_TOOL_SLOTS), Box(0,1,MAX_PARAMS))`. El discrete se enmascara
vía `env.action_masks()`. No se usa `sb3-contrib.MaskablePPO` porque éste no
soporta espacios `Tuple`; se implementa una **versión propia equivalente de PPO
con action masking** sobre los logits del head discreto (PyTorch), cumpliendo el
"o implementación equivalente" de §1.

## Pipeline real cubierto por el manifest (v1)

`narrator` (plan semilla) → `melody_generator` → `bass_line_composer`
(`--export-combined`) → `reharmonizer` → `drummer add` → `orchestrator` →
`performer` → `quality_scorer` (terminal). Cada herramienta avanza un puntero
`current_midi`; las tools sin `--output` resuelven su salida por glob declarativo
(`output_resolve`).

## Uso

```bash
# tests (Fases 1-4)
python -m pytest rl_pipeline_agent/tests/ -q

# entrenamiento + baseline + eval (produce MIDIs en rl_output/)
python -m rl_pipeline_agent.training.train_ppo

# sólo baseline aleatorio-dentro-de-máscara
python -m rl_pipeline_agent.training.train_ppo --baseline-only

# política heurística/experta sin entrenar (calidad alta inmediata)
python -m rl_pipeline_agent.training.train_ppo \
  --config rl_pipeline_agent/training/config_heuristic.yaml --heuristic

# con evaluación humana interactiva (bloquea — requiere flag explícito)
python -m rl_pipeline_agent.training.train_ppo --allow-blocking-eval
```

## Modo corpus (opcional)

Pasando `corpus: <ruta>` en el config (o `--corpus PATH` por CLI), el sistema
pre-construye una sola vez (cacheado en `rl_pipeline_agent/_corpus/`) tres
artefactos que inyecta en las herramientas pertinentes:

- **`qs.qcache`** → `quality_scorer --corpus --use-cache`: activa la dimensión
  `corpus` (pasa de 0.5 "no_corpus" a una puntuación real de similitud al
  corpus, p. ej. 0.98). Construcción ~25s, reuso ~0.7s.
- **`corpus.npz`** → `preference_trainer eval --corpus`: percentil/vecinos en
  la evaluación (queda pre-indexado para cuando se entrene un modelo con
  `preference_trainer.py train`, que requiere ratings humanos).
- **`drum_library.json`** → `drummer add --library`: grooves aprendidos del
  corpus, percusión más rica y realista. Construcción ~16s.

Evaluación con un corpus de 564 MIDIs (15 MB): la política heurística pasa de
**reward 0.717 → 0.755 (+5.3%)**, con el `quality_scorer` absoluto subiendo de
0.65 a 0.71 (la dimensión `corpus` de 0.5 a 0.98 y `arc` de 0.86 a 0.88).

Las salidas musicales se guardan en `rl_output/`:
`rand_*`, `tr_*` (rollout de entrenamiento), `ppo_*` (eval final),
`heur_*` (política heurística/experta sin entrenar), `summary.json`,
`heuristic_summary.json`, `ppo_policy.pt`, y **`tool_usage_report.txt` / `.json`**.

## Informe de uso de herramientas (para evaluador humano)

`tool_usage_report.py` agrega los logs de todos los episodios (`*.episode.json`)
y produce un informe legible que responde a: ¿qué herramientas y parámetros
producen las obras mejor valoradas?

```bash
python -m rl_pipeline_agent.training.tool_usage_report [--top N] [--json] [--out FILE]
```

Incluye: ranking de obras por reward, frecuencia de cada herramienta (global
y entre el top-K, con reward medio cuando se usa), parámetros más frecuentes
por herramienta con su reward medio asociado, y secuencias (cadenas de tools)
más exitosas. Ejemplo de salida útil: `drummer` con `style=rock_straight,
feel=supportive, variation=0.30` aparece en episodios con reward medio 0.697;
`reharmonizer` y `orchestrator` bajan el reward medio a ~0.55 (sobre-orquestación).

Cada episodio guarda además su log completo en `rl_output/<ep>_r<reward>.episode.json`
(cmd exacto + parámetros resueltos por step) para inspección individual.

## Decisiones de implementación (desviaciones documentadas)

- **Observación**: en lugar de los 20 dims de `analyzer.py --level full` por step
  (§5.3), v1 usa un vector fijo `flags + scalars + one-hot(categoricals) +
  qs_dims(5) + step(2)`. Motivo: llamar a `analyzer` en cada step × miles de
  episodios es inviable; la observación sigue siendo fija e independiente del
  manifest. La migración a features de `analyzer` queda como v2.
- **Reward intermedio**: solo terminal (§1). El delta de `quality_scorer --fast`
  por step queda como mejora opcional.
- **`output_resolve`**: campo declarativo extra en `ToolSpec` (modest, no rompe
  el esquema) para resolver la salida de tools sin `--output` (p.ej.
  `reharmonizer` escribe `<base>.rehar_*.mid`).

## Plan de fases (§9)

- Fase 1 (motor de manifest): ✅ `test_predicates.py`, `test_manifest_loader.py`
- Fase 2 (params + comando): ✅ `test_param_resolution.py`
- Fase 3 (entorno): ✅ `test_env_smoke.py`
- Fase 4 (reward + providers): ✅ `test_eval_providers.py`
- Fase 5 (entrenamiento): `train_ppo.py` — comparativa baseline vs PPO
- Fase 6 (manifest completo): extensión de `tools.json` al resto del toolkit
