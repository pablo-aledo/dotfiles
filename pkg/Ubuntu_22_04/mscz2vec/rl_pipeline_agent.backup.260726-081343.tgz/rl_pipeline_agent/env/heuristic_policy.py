"""Política heurística/experta — sin entrenamiento (§5.4.1 "política placeholder").

Codifica conocimiento de dominio obvio: secuencia el pipeline completo de
enriquecimiento en el orden correcto y elige parámetros curados coherentes con
el arco narrativo del plan. Produce salidas de calidad sin un largo proceso de
entrenamiento, y sirve como baseline fuerte y como bootstrap para
preference_trainer.

Uso: heuristic_action(env) -> (tool_id, params_vec) dentro de un bucle de step.
"""
from __future__ import annotations
import numpy as np

# Orden preferido: melodía → armonía → bajo → ritmo → orquestación →
# interpretación → evaluación. La máscara garantiza que solo se eligen pasos
# válidos; el orden impone coherencia (p.ej. drummer antes que orchestrator,
# porque orchestrator establece tiene_ritmo y bloquearía drummer).
PREFERRED_ORDER = [
    "melody_generator",
    "reharmonizer",
    "bass_line_composer",
    "drummer",
    "orchestrator",
    "performer",
    "quality_scorer",
]

# Mapeo arco → parámetros curados (valores semánticos; se convierten a 0..1).
ARC_PRESETS = {
    "hero": {
        "melody_generator": {"engine": "hybrid", "profile": "heroic", "contour": "arch"},
        "reharmonizer":     {"strategy": "diatonic", "complexity": 0.55, "acc_style": "arpeggio"},
        "bass_line_composer": {"style": "walking", "approach_prob": 0.5, "swing": 0.0},
        "drummer":          {"style": "rock_straight", "feel": "supportive", "variation": 0.3},
        "orchestrator":     {"template": "full", "tempo_humanize": 0.3},
        "performer":        {"style": "romantico", "intensity": 0.6},
    },
    "mystery": {
        "melody_generator": {"engine": "hybrid", "profile": "mysterious", "contour": "wave"},
        "reharmonizer":     {"strategy": "modal_interchange", "complexity": 0.7, "acc_style": "block"},
        "bass_line_composer": {"style": "ostinato", "approach_prob": 0.4, "swing": 0.1},
        "drummer":          {"style": "latin_clave", "feel": "independent", "variation": 0.4},
        "orchestrator":     {"template": "full", "tempo_humanize": 0.2},
        "performer":        {"style": "romantico", "intensity": 0.45},
    },
    "romance": {
        "melody_generator": {"engine": "hybrid", "profile": "melancholic", "contour": "wave"},
        "reharmonizer":     {"strategy": "impressionist", "complexity": 0.5, "acc_style": "arpeggio"},
        "bass_line_composer": {"style": "walking", "approach_prob": 0.5, "swing": 0.2},
        "drummer":          {"style": "jazz_ride", "feel": "supportive", "variation": 0.25},
        "orchestrator":     {"template": "strings_only", "tempo_humanize": 0.4},
        "performer":        {"style": "romantico", "intensity": 0.7},
    },
    "tragedy": {
        "melody_generator": {"engine": "hybrid", "profile": "tense", "contour": "descending"},
        "reharmonizer":     {"strategy": "chromatic_med", "complexity": 0.75, "acc_style": "block"},
        "bass_line_composer": {"style": "ostinato", "approach_prob": 0.6, "swing": 0.0},
        "drummer":          {"style": "rock_straight", "feel": "contrasting", "variation": 0.5},
        "orchestrator":     {"template": "full", "tempo_humanize": 0.2},
        "performer":        {"style": "romantico", "intensity": 0.8},
    },
    "meditation": {
        "melody_generator": {"engine": "hybrid", "profile": "serene", "contour": "plateau"},
        "reharmonizer":     {"strategy": "diatonic", "complexity": 0.35, "acc_style": "block"},
        "bass_line_composer": {"style": "pedal", "approach_prob": 0.3, "swing": 0.0},
        "drummer":          {"style": "jazz_ride", "feel": "supportive", "variation": 0.15},
        "orchestrator":     {"template": "chamber", "tempo_humanize": 0.3},
        "performer":        {"style": "romantico", "intensity": 0.4},
    },
    "sonata": {
        "melody_generator": {"engine": "hybrid", "profile": "heroic", "contour": "arch"},
        "reharmonizer":     {"strategy": "baroque", "complexity": 0.6, "acc_style": "arpeggio"},
        "bass_line_composer": {"style": "classical", "approach_prob": 0.5, "swing": 0.0},
        "drummer":          {"style": "rock_straight", "feel": "supportive", "variation": 0.3},
        "orchestrator":     {"template": "full", "tempo_humanize": 0.3},
        "performer":        {"style": "romantico", "intensity": 0.65},
    },
}
# Mapeo arco → LISTA de variantes de preset (la política estocástica muestrea
# una por episodio). Cada variante es coherente con el carácter del arco pero
# explora diferentes motores/perfiles/contornos/estilos de bajo y percusión.
ARC_PRESET_VARIANTS = {
    "hero": [
        {"melody_generator": {"engine": "hybrid", "profile": "heroic", "contour": "arch"},
         "bass_line_composer": {"style": "walking", "approach_prob": 0.5, "swing": 0.0},
         "drummer":          {"style": "rock_straight", "feel": "supportive", "variation": 0.3},
         "performer":        {"style": "romantico", "intensity": 0.6},
         "counterpoint":     {"species": "5", "voice_position": "below"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "triunfo"},
         "chord_pattern_voicer": {"pattern": "arpeggio-up"},
         "playability_auditor": {"profile": "estandar"},
         "completer":        {"mode": "extend", "strategy": "blend", "bars": 8},
         "style_transfer":   {"strength": 0.5, "transfer_dims": "harmony"},
         "variation_engine": {"variation": "V01"},
         "modulator":        {"param": "density", "curve": "arc", "intensity": 0.5},
         "theme_transformer": {"style": "dorian_heroic"}},
        {"melody_generator": {"engine": "grammar", "profile": "triumphant", "contour": "ascending"},
         "bass_line_composer": {"style": "pedal", "approach_prob": 0.4, "swing": 0.0},
         "drummer":          {"style": "rock_straight", "feel": "contrasting", "variation": 0.45},
         "performer":        {"style": "romantico", "intensity": 0.75},
         "counterpoint":     {"species": "1", "voice_position": "above"},
         "tempo_designer":   {"shape": "linear", "final_rit": 6},
         "orchestral_colorist": {"emotion": "esperanza"},
         "chord_pattern_voicer": {"pattern": "bombo-caja"},
         "playability_auditor": {"profile": "tolerante"},
         "completer":        {"mode": "develop", "strategy": "evolve", "bars": 8},
         "style_transfer":   {"strength": 0.6, "transfer_dims": "emotion"},
         "variation_engine": {"variation": "V04"},
         "modulator":        {"param": "register", "curve": "sigmoid", "intensity": 0.6},
         "theme_transformer": {"style": "heroic_minor"}},
        {"melody_generator": {"engine": "hybrid", "profile": "heroic", "contour": "plateau"},
         "bass_line_composer": {"style": "ostinato", "approach_prob": 0.6, "swing": 0.0},
         "drummer":          {"style": "funk_16th", "feel": "independent", "variation": 0.4},
         "performer":        {"style": "clasico", "intensity": 0.55},
         "counterpoint":     {"species": "3", "voice_position": "auto"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "tension"},
         "chord_pattern_voicer": {"pattern": "alberti"},
         "playability_auditor": {"profile": "estandar"},
         "completer":        {"mode": "coda", "strategy": "phrase", "bars": 4}},
    ],
    "romance": [
        {"melody_generator": {"engine": "hybrid", "profile": "melancholic", "contour": "wave"},
         "bass_line_composer": {"style": "walking", "approach_prob": 0.5, "swing": 0.2},
         "drummer":          {"style": "jazz_ride", "feel": "supportive", "variation": 0.25},
         "performer":        {"style": "romantico", "intensity": 0.7},
         "counterpoint":     {"species": "5", "voice_position": "below"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "melancolia"},
         "chord_pattern_voicer": {"pattern": "arpeggio-down"},
         "playability_auditor": {"profile": "tolerante"},
         "completer":        {"mode": "develop", "strategy": "contour", "bars": 8}},
        {"melody_generator": {"engine": "grammar", "profile": "serene", "contour": "descending"},
         "bass_line_composer": {"style": "pedal", "approach_prob": 0.3, "swing": 0.1},
         "drummer":          {"style": "brushes", "feel": "supportive", "variation": 0.2},
         "performer":        {"style": "romantico", "intensity": 0.55},
         "counterpoint":     {"species": "1", "voice_position": "above"},
         "tempo_designer":   {"shape": "linear", "final_rit": 6},
         "orchestral_colorist": {"emotion": "fragilidad"},
         "chord_pattern_voicer": {"pattern": "block"},
         "playability_auditor": {"profile": "estricto"},
         "completer":        {"mode": "coda", "strategy": "phrase", "bars": 4}},
    ],
    "mystery": [
        {"melody_generator": {"engine": "hybrid", "profile": "mysterious", "contour": "wave"},
         "bass_line_composer": {"style": "ostinato", "approach_prob": 0.4, "swing": 0.1},
         "drummer":          {"style": "latin_clave", "feel": "independent", "variation": 0.4},
         "performer":        {"style": "romantico", "intensity": 0.45},
         "counterpoint":     {"species": "2", "voice_position": "below"},
         "tempo_designer":   {"shape": "step", "final_rit": 2},
         "orchestral_colorist": {"emotion": "angustia"},
         "chord_pattern_voicer": {"pattern": "arpeggio-updown"},
         "playability_auditor": {"profile": "tolerante"},
         "completer":        {"mode": "extend", "strategy": "narrative", "bars": 8}},
        {"melody_generator": {"engine": "search", "profile": "tense", "contour": "inverted"},
         "bass_line_composer": {"style": "pedal", "approach_prob": 0.5, "swing": 0.0},
         "drummer":          {"style": "shuffle", "feel": "contrasting", "variation": 0.35},
         "performer":        {"style": "romantico", "intensity": 0.5},
         "counterpoint":     {"species": "4", "voice_position": "auto"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "tension"},
         "chord_pattern_voicer": {"pattern": "block"},
         "playability_auditor": {"profile": "estandar"},
         "completer":        {"mode": "develop", "strategy": "variation", "bars": 8}},
    ],
    "tragedy": [
        {"melody_generator": {"engine": "hybrid", "profile": "tense", "contour": "descending"},
         "bass_line_composer": {"style": "ostinato", "approach_prob": 0.6, "swing": 0.0},
         "drummer":          {"style": "rock_straight", "feel": "contrasting", "variation": 0.5},
         "performer":        {"style": "romantico", "intensity": 0.8},
         "counterpoint":     {"species": "5", "voice_position": "below"},
         "tempo_designer":   {"shape": "step", "final_rit": 6},
         "orchestral_colorist": {"emotion": "angustia"},
         "chord_pattern_voicer": {"pattern": "block"},
         "playability_auditor": {"profile": "tolerante"},
         "completer":        {"mode": "recapitulate", "strategy": "evolve", "bars": 8}},
        {"melody_generator": {"engine": "grammar", "profile": "melancholic", "contour": "descending"},
         "bass_line_composer": {"style": "walking", "approach_prob": 0.4, "swing": 0.1},
         "drummer":          {"style": "jazz_ride", "feel": "independent", "variation": 0.4},
         "performer":        {"style": "romantico", "intensity": 0.65},
         "counterpoint":     {"species": "2", "voice_position": "above"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "melancolia"},
         "chord_pattern_voicer": {"pattern": "arpeggio-down"},
         "playability_auditor": {"profile": "estandar"},
         "completer":        {"mode": "coda", "strategy": "phrase", "bars": 4}},
    ],
    "meditation": [
        {"melody_generator": {"engine": "hybrid", "profile": "serene", "contour": "plateau"},
         "bass_line_composer": {"style": "pedal", "approach_prob": 0.3, "swing": 0.0},
         "drummer":          {"style": "jazz_ride", "feel": "supportive", "variation": 0.15},
         "performer":        {"style": "romantico", "intensity": 0.4},
         "counterpoint":     {"species": "1", "voice_position": "above"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "serenidad"},
         "chord_pattern_voicer": {"pattern": "arpeggio-down"},
         "playability_auditor": {"profile": "estricto"},
         "completer":        {"mode": "coda", "strategy": "phrase", "bars": 4}},
        {"melody_generator": {"engine": "markov", "profile": "serene", "contour": "wave"},
         "bass_line_composer": {"style": "pedal", "approach_prob": 0.2, "swing": 0.15},
         "drummer":          {"style": "brushes", "feel": "supportive", "variation": 0.1},
         "performer":        {"style": "clasico", "intensity": 0.35},
         "counterpoint":     {"species": "1", "voice_position": "below"},
         "tempo_designer":   {"shape": "linear", "final_rit": 6},
         "orchestral_colorist": {"emotion": "calidez"},
         "chord_pattern_voicer": {"pattern": "block"},
         "playability_auditor": {"profile": "tolerante"},
         "completer":        {"mode": "extend", "strategy": "contour", "bars": 4}},
    ],
    "sonata": [
        {"melody_generator": {"engine": "hybrid", "profile": "heroic", "contour": "arch"},
         "bass_line_composer": {"style": "classical", "approach_prob": 0.5, "swing": 0.0},
         "drummer":          {"style": "rock_straight", "feel": "supportive", "variation": 0.3},
         "performer":        {"style": "romantico", "intensity": 0.65},
         "counterpoint":     {"species": "4", "voice_position": "below"},
         "tempo_designer":   {"shape": "smooth", "final_rit": 4},
         "orchestral_colorist": {"emotion": "triunfo"},
         "chord_pattern_voicer": {"pattern": "alberti"},
         "playability_auditor": {"profile": "estandar"},
         "completer":        {"mode": "develop", "strategy": "phrase", "bars": 8}},
        {"melody_generator": {"engine": "grammar", "profile": "triumphant", "contour": "arch"},
         "bass_line_composer": {"style": "walking", "approach_prob": 0.5, "swing": 0.0},
         "drummer":          {"style": "waltz", "feel": "supportive", "variation": 0.25},
         "performer":        {"style": "clasico", "intensity": 0.6},
         "counterpoint":     {"species": "1", "voice_position": "above"},
         "tempo_designer":   {"shape": "linear", "final_rit": 6},
         "orchestral_colorist": {"emotion": "esperanza"},
         "chord_pattern_voicer": {"pattern": "arpeggio-up"},
         "playability_auditor": {"profile": "tolerante"},
         "completer":        {"mode": "coda", "strategy": "evolve", "bars": 4}},
    ],
}

# Variantes de cadena (orden de tools). La máscara garantiza validez.
# Incluye las nuevas herramientas de Fase 6: counterpoint, completer,
# tempo_designer, orchestral_colorist, chord_pattern_voicer,
# playability_auditor — en combinaciones coherentes.
ORDER_VARIANTS = [
    ["melody_generator", "bass_line_composer", "drummer", "performer", "quality_scorer"],
    ["melody_generator", "reharmonizer", "bass_line_composer", "performer", "quality_scorer"],
    ["melody_generator", "bass_line_composer", "drummer", "performer", "quality_scorer"],
    ["melody_generator", "bass_line_composer", "orchestrator", "performer", "quality_scorer"],
    ["melody_generator", "bass_line_composer", "drummer", "performer", "quality_scorer"],
    # --- cadenas con herramientas nuevas (Fase 6) ---
    ["melody_generator", "counterpoint", "bass_line_composer", "performer", "quality_scorer"],
    ["melody_generator", "reharmonizer", "bass_line_composer", "chord_pattern_voicer", "performer", "quality_scorer"],
    ["melody_generator", "bass_line_composer", "drummer", "tempo_designer", "performer", "quality_scorer"],
    ["melody_generator", "orchestral_colorist", "bass_line_composer", "performer", "quality_scorer"],
    ["melody_generator", "counterpoint", "bass_line_composer", "drummer", "performer", "playability_auditor", "quality_scorer"],
    ["melody_generator", "reharmonizer", "bass_line_composer", "orchestral_colorist", "performer", "quality_scorer"],
    ["melody_generator", "completer", "bass_line_composer", "drummer", "performer", "quality_scorer"],
    # --- cadenas con herramientas de transformación (Fase 6+) ---
    ["melody_generator", "style_transfer", "bass_line_composer", "performer", "quality_scorer"],
    ["melody_generator", "theme_transformer", "bass_line_composer", "drummer", "performer", "quality_scorer"],
    ["melody_generator", "variation_engine", "bass_line_composer", "performer", "quality_scorer"],
    ["melody_generator", "bass_line_composer", "modulator", "performer", "quality_scorer"],
    ["melody_generator", "style_transfer", "counterpoint", "bass_line_composer", "performer", "quality_scorer"],
]

DEFAULT_PRESET = ARC_PRESET_VARIANTS["hero"][0]


def _categorical_raw(opts: list, desired: str) -> float:
    idx = opts.index(desired) if desired in opts else 0
    return idx / max(1, len(opts) - 1)


def _float_raw(low: float, high: float, desired: float) -> float:
    if high <= low:
        return 0.0
    return max(0.0, min(1.0, (desired - low) / (high - low)))


def _param_raw(pspec, desired) -> float:
    if pspec.type == "categorical":
        return _categorical_raw(list(pspec.range), desired)
    if pspec.type == "int":
        low, high = pspec.range[0], pspec.range[1]
        return _float_raw(float(low), float(high), float(desired))
    if pspec.type in ("float", "curve"):
        low, high = pspec.range[0], pspec.range[1]
        return _float_raw(float(low), float(high), float(desired))
    return 0.5


def _jitter(rng: np.random.Generator, low: float, high: float, desired: float,
            span: float = 0.15) -> float:
    """Añade jitter uniforme de ±span alrededor de `desired`, acotado al rango."""
    d = desired + rng.uniform(-span, span)
    return max(low, min(high, d))


def sample_episode_config(arc: str, rng: np.random.Generator,
                           vary_order: bool = True) -> tuple[dict, list]:
    """Muestrea (preset, order) estocásticos coherentes con el arco."""
    variants = ARC_PRESET_VARIANTS.get(arc, ARC_PRESET_VARIANTS["hero"])
    preset = dict(variants[rng.integers(len(variants))])  # copia
    order = ORDER_VARIANTS[rng.integers(len(ORDER_VARIANTS))] if vary_order \
        else PREFERRED_ORDER
    # jitter en parámetros continuos para que ni siquiera dos episodios con el
    # mismo preset sean idénticos
    for tname, params in preset.items():
        for k, v in params.items():
            if isinstance(v, float):
                # acota jitter al rango [0,1] para intensidad/variation/etc.
                params[k] = float(max(0.0, min(1.0, v + rng.uniform(-0.1, 0.1))))
    return preset, order


def heuristic_action(env, arc: str = "hero", max_params: int | None = None,
                      order: list | None = None, rng: np.random.Generator | None = None,
                      preset_override: dict | None = None):
    """Elige el siguiente tool (primero en `order` con máscara válida y no
    usado aún en este episodio) y construye el vector de parámetros curados."""
    if max_params is None:
        max_params = env.max_params
    if order is None:
        order = PREFERRED_ORDER
    mask = env.action_masks()
    preset = preset_override if preset_override is not None \
        else ARC_PRESETS.get(arc, DEFAULT_PRESET)

    # herramientas ya usadas en este episodio (evita repetir)
    used = set(getattr(env, "_heur_used_tools", set()))

    tool = None
    for name in order:
        if name in used:
            continue
        for i, t in enumerate(env.tools_by_id):
            if t.name == name and i < len(mask) and mask[i]:
                tool = t
                break
        if tool is not None:
            break
    if tool is None:
        # si todo el order ya se usó, tomar cualquiera válido no usado
        for i, m in enumerate(mask):
            if m and env.tools_by_id[i].name not in used:
                tool = env.tools_by_id[i]
                break
    if tool is None:
        valid = [i for i, m in enumerate(mask) if m]
        tool = env.tools_by_id[valid[0]] if valid else env.tools_by_id[0]

    curated = preset.get(tool.name, {})
    vec = np.full(max_params, 0.5, dtype=np.float32)
    ai = 0
    for pspec in tool.params:
        if pspec.source != "agent":
            continue
        if pspec.name in curated:
            vec[ai] = _param_raw(pspec, curated[pspec.name])
        ai += 1
    tool_id = env.tools_by_id.index(tool)
    return (tool_id, vec)
