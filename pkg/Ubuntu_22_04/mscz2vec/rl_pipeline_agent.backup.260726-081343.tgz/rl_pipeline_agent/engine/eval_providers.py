"""Proveedores de evaluación intercambiables (§5.4.1).

- QualityScorerProvider: llama a quality_scorer.py
- PreferenceTrainerProvider: llama a preference_trainer.py eval
- HumanProvider: rating por terminal (blocking)
- WeightedProvider: combina los disponibles
- resolve_eval_provider: resuelve config.yaml con fallback
"""
from __future__ import annotations
import json
import logging
import os
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import Protocol

log = logging.getLogger("rl_pipeline.eval")


class EvalProviderUnavailableError(Exception):
    pass


class EvalProvider(Protocol):
    blocking: bool

    def is_available(self, ctx: dict) -> bool: ...
    def score(self, midi_path: str, ctx: dict) -> float: ...


# --------------- QualityScorerProvider ---------------
class QualityScorerProvider:
    blocking = False

    def __init__(self, cfg: dict, root: str = "."):
        self.cfg = cfg
        self.root = Path(root)
        self.script = self.root / "quality_scorer.py"
        self.corpus = cfg.get("quality_scorer_corpus")
        self.cache = cfg.get("quality_scorer_cache")
        self.weights = cfg.get("quality_scorer_weights")

    def is_available(self, ctx: dict) -> bool:
        return self.script.exists()

    def score(self, midi_path: str, ctx: dict) -> float:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            out_json = f.name
        try:
            cmd = ["python", str(self.script), midi_path, "--out-json", out_json,
                   "--no-color", "--fast"]
            if ctx.get("plan_path"):
                cmd += ["--plan", ctx["plan_path"]]
            if self.corpus:
                cmd += ["--corpus", str(self.corpus)]
            if self.cache:
                cmd += ["--use-cache", str(self.cache)]
            if self.weights:
                cmd += shlex.split(f"--weights {self.weights}")
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
            if r.returncode != 0 and not Path(out_json).exists():
                log.warning("quality_scorer failed: %s", r.stderr[-400:])
                return 0.0
            data = json.loads(Path(out_json).read_text())
            return float(data.get("score", {}).get("absolute", 0.0))
        except Exception as e:
            log.warning("quality_scorer exception: %s", e)
            return 0.0
        finally:
            try:
                os.unlink(out_json)
            except OSError:
                pass


# --------------- PreferenceTrainerProvider ---------------
class PreferenceTrainerProvider:
    blocking = False

    def __init__(self, cfg: dict, root: str = "."):
        self.cfg = cfg
        self.root = Path(root)
        self.script = self.root / "preference_trainer.py"
        self.model = cfg.get("preference_trainer_model", "prefs")
        self.model_type = cfg.get("preference_trainer_model_type", "linear")

    def _model_file(self) -> Path:
        return self.root / f"{self.model}.{self.model_type}.json"

    def is_available(self, ctx: dict) -> bool:
        return self.script.exists() and self._model_file().exists()

    def score(self, midi_path: str, ctx: dict) -> float:
        try:
            cmd = ["python", str(self.script), "eval", midi_path,
                   "--model", self.model, "--model-type", self.model_type, "--json"]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=180,
                               cwd=str(self.root))
            if r.returncode != 0:
                log.warning("preference_trainer failed: %s", r.stderr[-400:])
                return 0.0
            # la tool imprime JSON al final de stdout
            out = r.stdout.strip()
            # encontrar la primera línea que parsea como JSON
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("{"):
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if "score" in data:
                        return float(data["score"])
                    if "preference" in data:
                        return float(data["preference"])
            # intentar parsear todo
            try:
                data = json.loads(out)
                return float(data.get("score", data.get("preference", 0.0)))
            except Exception:
                pass
            return 0.0
        except Exception as e:
            log.warning("preference_trainer exception: %s", e)
            return 0.0


# --------------- HumanProvider ---------------
class HumanProvider:
    blocking = True

    def is_available(self, ctx: dict) -> bool:
        # siempre "disponible" como recurso, pero bloquea — solo se activa con
        # --allow-blocking-eval en el entrypoint.
        return True

    def score(self, midi_path: str, ctx: dict) -> float:
        print(f"\n[HUMAN EVAL] Reproduce: {midi_path}")
        while True:
            try:
                r = input("Rating 1-5 (enter=3): ").strip()
                r = float(r) if r else 3.0
                if 1.0 <= r <= 5.0:
                    return (r - 1.0) / 4.0
            except (ValueError, EOFError):
                return 0.5
            print("  introduce un número entre 1 y 5")


# --------------- WeightedProvider ---------------
class WeightedProvider:
    def __init__(self, members: list[tuple[EvalProvider, float]]):
        self.members = members
        self.blocking = any(getattr(m, "blocking", False) for m, _ in members)

    def is_available(self, ctx: dict) -> bool:
        return any(m.is_available(ctx) for m, _ in self.members)

    def score(self, midi_path: str, ctx: dict) -> float:
        avail = [(m, w) for m, w in self.members if m.is_available(ctx)]
        excluded = [type(m).__name__ for m, w in self.members if not m.is_available(ctx)]
        if excluded:
            log.warning("WeightedProvider excluye (no disponibles): %s", excluded)
        if not avail:
            raise EvalProviderUnavailableError("WeightedProvider: ningún miembro disponible")
        tot = sum(w for _, w in avail)
        s = 0.0
        for m, w in avail:
            sc = m.score(midi_path, ctx)
            s += (w / tot) * sc
        return s


# --------------- resolve_eval_provider ---------------
def resolve_eval_provider(cfg: dict, root: str = ".", allow_blocking: bool = False) -> EvalProvider:
    qs = QualityScorerProvider(cfg, root=root)
    pt = PreferenceTrainerProvider(cfg, root=root)
    hu = HumanProvider()
    members = cfg.get("weighted", {})
    weighted = WeightedProvider([
        (qs, float(members.get("quality_scorer", 0.6))),
        (pt, float(members.get("preference_trainer", 0.4))),
    ])
    candidates = {
        "human": hu,
        "quality_scorer": qs,
        "preference_trainer": pt,
        "weighted": weighted,
    }
    requested_name = cfg["eval_mode"]
    requested = candidates[requested_name]
    if getattr(requested, "blocking", False) and not allow_blocking:
        raise EvalProviderUnavailableError(
            f"eval_mode '{requested_name}' es blocking pero no se pasó --allow-blocking-eval")
    if requested.is_available({}):
        return requested
    for name in cfg.get("fallback_order", ["quality_scorer"]):
        alt = candidates[name]
        if getattr(alt, "blocking", False) and not allow_blocking:
            continue
        if alt.is_available({}):
            log.warning("eval_mode '%s' no disponible — usando fallback '%s'",
                        requested_name, name)
            return alt
    raise EvalProviderUnavailableError(
        "Ningún proveedor de evaluación disponible (revisa modelos entrenados / config.yaml)")
