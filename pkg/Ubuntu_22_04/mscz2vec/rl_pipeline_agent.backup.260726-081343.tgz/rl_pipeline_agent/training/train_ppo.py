"""train_ppo.py — entrenamiento PPO con action masking sobre PipelineEnv.

Implementación propia (no sb3-contrib) porque el espacio de acción es
Tuple(Discrete, Box) y MaskablePPO no soporta Tuple. La máscara se aplica
sobre los logits del head discreto (§1: "MaskablePPO o implementación
equivalente de action masking").

Uso:
    python -m rl_pipeline_agent.training.train_ppo [--config CONFIG]
            [--allow-blocking-eval] [--episodes N] [--baseline-only]
"""
from __future__ import annotations
import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml

# --- registrar effects/renderers/state_fns por importación ---
from ..engine import effects as _effects        # noqa: F401
from ..engine import renderers as _renderers    # noqa: F401
from ..engine import params as _params          # noqa: F401
from ..engine.manifest_loader import Manifest
from ..engine.eval_providers import (
    resolve_eval_provider, EvalProviderUnavailableError)
from ..env.pipeline_env import PipelineEnv
from ..env.heuristic_policy import heuristic_action, sample_episode_config

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s %(message)s")
log = logging.getLogger("rl_pipeline.train")

HERE = Path(__file__).resolve().parent
PKG = HERE.parent


# ------------------ red de política ------------------
class PolicyNet(nn.Module):
    def __init__(self, obs_dim, n_tools, max_params, hidden=128):
        super().__init__()
        self.n_tools = n_tools
        self.max_params = max_params
        self.trunk = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
        )
        self.tool_head = nn.Linear(hidden, n_tools)
        self.param_mean = nn.Linear(hidden, max_params)
        self.value_head = nn.Linear(hidden, 1)
        self.log_std = nn.Parameter(torch.zeros(max_params))

    def tool_logits(self, obs, mask):
        h = self.trunk(obs)
        logits = self.tool_head(h)
        neg = torch.finfo(logits.dtype).min
        logits = logits.masked_fill(~mask, neg)
        return logits, h


def make_env(cfg, root, eval_provider, plan_path, curves_path, sections, output_root, prefix):
    plan_cfg = cfg.get("plan", {})
    work = Path(cfg["training"]["work_root"])
    if not work.is_absolute():
        work = root / work
    work.mkdir(parents=True, exist_ok=True)
    plan_path = work / "plan.json"
    curves_path = work / "plan.curves.json"
    if plan_path.exists() and curves_path.exists():
        log.info("plan reusado: %s", plan_path)
    else:
        out_base = work / "plan"
        cmd = ["python", str(root / "narrator.py"),
               "--arc", plan_cfg.get("arc", "hero"),
               "--bars", str(plan_cfg.get("bars", 16)),
               "--key", plan_cfg.get("key", "C"),
               "--tempo", str(plan_cfg.get("tempo", 120)),
               "--sections", plan_cfg.get("sections", "A:8,B:8"),
               "--output", str(out_base), "--export-curves", "--export-yaml", "--no-gui"]
        log.info("generando plan: %s", " ".join(cmd))
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120, cwd=str(root))
        if r.returncode != 0:
            log.error("narrator falló:\n%s", r.stderr[-800:])
            raise RuntimeError("narrator falló")
        if not plan_path.exists():
            cands = list(work.glob("plan*.json"))
            if cands:
                plan_path = cands[0]
        if not curves_path.exists():
            cs = list(work.glob("plan*.curves.json")) or list(work.glob("*.curves.json"))
            if cs:
                curves_path = cs[0]
    try:
        pd = json.loads(Path(plan_path).read_text())
        secs = [int(s["bars"]) for s in pd.get("sections", [])]
        if not secs:
            secs = [int(pd.get("n_bars", 16)) // 2] * 2
    except Exception:
        secs = [8, 8]
    return str(plan_path), str(curves_path), secs


# ------------------ corpus setup ------------------
def prepare_corpus(cfg, root):
    """Pre-construye (una vez, cacheado) los artefactos derivados del corpus:
      - qs.qcache           : caché de vectores para quality_scorer --corpus
      - corpus.npz          : índice para preference_trainer eval --corpus
      - drum_library.json   : grooves aprendidos para drummer --library
    Devuelve un dict con las rutas (o claves ausentes si la herramienta falla).
    """
    import subprocess
    corpus_path = cfg.get("corpus")
    if not corpus_path:
        return {}
    corpus_path = Path(corpus_path)
    if not corpus_path.is_absolute():
        corpus_path = root / corpus_path
    if not corpus_path.exists():
        log.warning("corpus '%s' no existe — modo sin corpus", corpus_path)
        return {}
    cache_dir = root / "rl_pipeline_agent" / "_corpus"
    cache_dir.mkdir(parents=True, exist_ok=True)
    out = {"corpus_path": str(corpus_path)}
    # 1) quality_scorer cache
    qcache = cache_dir / "qs.qcache"
    if not qcache.exists():
        log.info("[corpus] construyendo qs.qcache (~25s)…")
        anchor = next(corpus_path.glob("*.mid"), None)
        if anchor:
            cmd = ["python", str(root / "quality_scorer.py"), str(anchor),
                   "--corpus", str(corpus_path), "--save-cache", str(qcache),
                   "--no-color", "--fast"]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800,
                               cwd=str(root))
            if r.returncode != 0 or not qcache.exists():
                log.warning("[corpus] quality_scorer cache falló: %s",
                            r.stderr[-300:])
    if qcache.exists():
        out["qs_cache"] = str(qcache)
    # 2) preference_trainer index
    npz = cache_dir / "corpus.npz"
    if not npz.exists():
        log.info("[corpus] indexando corpus.npz para preference_trainer (~23s)…")
        cmd = ["python", str(root / "preference_trainer.py"), "index",
               str(corpus_path), "--output", str(npz)]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800,
                           cwd=str(root))
        if r.returncode != 0 or not npz.exists():
            log.warning("[corpus] preference_trainer index falló: %s",
                        r.stderr[-300:])
    if npz.exists():
        out["pt_corpus"] = str(npz)
    # 3) drummer learned grooves
    drum_lib = cache_dir / "drum_library.json"
    if not drum_lib.exists():
        log.info("[corpus] aprendiendo grooves drum_library.json (~16s)…")
        cmd = ["python", str(root / "drummer.py"), "learn", str(corpus_path),
               "--output", str(drum_lib), "--clusters", "16"]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800,
                           cwd=str(root))
        if r.returncode != 0 or not drum_lib.exists():
            log.warning("[corpus] drummer learn falló: %s", r.stderr[-300:])
    if drum_lib.exists():
        out["drum_library_path"] = str(drum_lib)
    log.info("[corpus] artefactos listos: %s", list(out.keys()))
    return out


# ------------------ plan seed ------------------
def build_plan_if_needed(cfg, root):
    import subprocess
    plan_cfg = cfg.get("plan", {})
    work = Path(cfg["training"]["work_root"])
    if not work.is_absolute():
        work = root / work
    work.mkdir(parents=True, exist_ok=True)
    plan_path = work / "plan.json"
    curves_path = work / "plan.curves.json"
    if plan_path.exists() and curves_path.exists():
        log.info("plan reusado: %s", plan_path)
    else:
        out_base = work / "plan"
        cmd = ["python", str(root / "narrator.py"),
               "--arc", plan_cfg.get("arc", "hero"),
               "--bars", str(plan_cfg.get("bars", 16)),
               "--key", plan_cfg.get("key", "C"),
               "--tempo", str(plan_cfg.get("tempo", 120)),
               "--sections", plan_cfg.get("sections", "A:8,B:8"),
               "--output", str(out_base), "--export-curves", "--export-yaml", "--no-gui"]
        log.info("generando plan: %s", " ".join(cmd))
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120, cwd=str(root))
        if r.returncode != 0:
            log.error("narrator falló:\n%s", r.stderr[-800:])
            raise RuntimeError("narrator falló")
        if not plan_path.exists():
            cands = list(work.glob("plan*.json"))
            if cands:
                plan_path = cands[0]
        if not curves_path.exists():
            cs = list(work.glob("plan*.curves.json")) or list(work.glob("*.curves.json"))
            if cs:
                curves_path = cs[0]
    try:
        pd = json.loads(Path(plan_path).read_text())
        secs = [int(s["bars"]) for s in pd.get("sections", [])]
        if not secs:
            secs = [int(pd.get("n_bars", 16)) // 2] * 2
    except Exception:
        secs = [8, 8]
    return str(plan_path), str(curves_path), secs


def build_plan_pool(cfg, root, arcs):
    """Genera (cacheado) un plan por arco en <work_root>/_plans/<arc>/.
    Devuelve {arc: (plan_path, curves_path, sections_bars)}. Variar también la
    tonalidad por arco para diversidad armónica."""
    import subprocess
    work = Path(cfg["training"]["work_root"])
    if not work.is_absolute():
        work = root / work
    pool = {}
    arc_keys = {
        "hero": "C", "romance": "Dm", "mystery": "F#m", "tragedy": "Bm",
        "meditation": "G", "sonata": "D",
    }
    bars = str(cfg.get("plan", {}).get("bars", 32))
    tempo = str(cfg.get("plan", {}).get("tempo", 120))
    sections = cfg.get("plan", {}).get("sections", "A:8,B:8,C:8,A:8")
    for arc in arcs:
        pdir = work / "_plans" / arc
        pdir.mkdir(parents=True, exist_ok=True)
        plan_path = pdir / "plan.json"
        curves_path = pdir / "plan.curves.json"
        if not (plan_path.exists() and curves_path.exists()):
            cmd = ["python", str(root / "narrator.py"),
                   "--arc", arc, "--bars", bars, "--key", arc_keys.get(arc, "C"),
                   "--tempo", tempo, "--sections", sections,
                   "--output", str(pdir / "plan"), "--export-curves", "--export-yaml",
                   "--no-gui"]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=120,
                               cwd=str(root))
            if r.returncode != 0:
                log.warning("narrator falló para arco %s: %s", arc, r.stderr[-200:])
                continue
        if not (plan_path.exists() and curves_path.exists()):
            continue
        try:
            pd = json.loads(plan_path.read_text())
            secs = [int(s["bars"]) for s in pd.get("sections", [])] or [8, 8]
        except Exception:
            secs = [8, 8]
        pool[arc] = (str(plan_path), str(curves_path), secs)
    return pool


def make_env(cfg, root, eval_provider, plan_path, curves_path, sections,
             output_root, prefix, corpus_artifacts=None):
    manifest = Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "manifest" / "tools.json",
        effects_registry=_effects.EFFECTS,
        renderers_registry=_renderers.RENDERERS,
    )
    work_root = Path(cfg["training"]["work_root"])
    if not work_root.is_absolute():
        work_root = root / work_root
    env = PipelineEnv(
        manifest=manifest, cfg=cfg, eval_provider=eval_provider,
        plan_path=plan_path, curves_path=curves_path, sections_bars=sections,
        work_root=str(work_root), output_root=output_root,
        episode_id_prefix=prefix, save_outputs=True,
    )
    # inyectar artefactos del corpus en el ctx del entorno
    if corpus_artifacts:
        env._corpus_artifacts = dict(corpus_artifacts)
        # se aplican en reset() vía _seed_state_from_plan → ctx
    return env


# ------------------ rollout ------------------
def run_episode(env, policy=None, device="cpu", greedy=False, rng=None):
    """Captura por step: obs, máscara válida para esa acción, n_agent, logp, value."""
    obs, _ = env.reset()
    traj = []
    done = False
    while not done:
        mask_now = np.asarray(env.action_masks(), dtype=bool)
        obs_t = torch.as_tensor(obs, dtype=torch.float32, device=device)[None, :]
        mask_t = torch.as_tensor(mask_now, dtype=torch.bool, device=device)[None, :]
        if policy is not None:
            with torch.no_grad():
                logits, h = policy.tool_logits(obs_t, mask_t)
                dist = torch.distributions.Categorical(logits=logits)
                tool_id = int(dist.probs.argmax(-1)) if greedy else int(dist.sample())
                logp_tool = float(dist.log_prob(torch.tensor(tool_id, device=device)))
                mean = policy.param_mean(h).squeeze(0)
                std = policy.log_std.exp()
                z = mean + std * torch.randn_like(mean)
                x = torch.sigmoid(z).clamp(1e-5, 1 - 1e-5)
                value = float(policy.value_head(h).squeeze().item())
                action_params = x.detach().cpu().numpy().astype(np.float32)
        else:
            if rng is None:
                rng = np.random.default_rng()
            tool_id, action_params = env.sample_masked_action(rng)
            logp_tool = 0.0
            value = 0.0
        n_agent = env.tools_by_id[tool_id].n_agent_params
        action = (tool_id, action_params)
        obs, reward, done, _, info = env.step(action)
        traj.append({
            "obs": obs, "mask": mask_now, "tool_id": tool_id,
            "params": action_params, "logp": logp_tool, "value": value,
            "reward": float(reward), "done": done, "n_agent": n_agent,
        })
    final_reward = traj[-1]["reward"] if traj else 0.0
    return traj, final_reward, env.episode_log


def compute_returns(traj, gamma):
    T = len(traj)
    returns = np.zeros(T, dtype=np.float32)
    g = 0.0
    for t in reversed(range(T)):
        r = traj[t]["reward"]
        not_done = 0.0 if traj[t]["done"] else 1.0
        g = r + gamma * g * not_done
        returns[t] = g
    advs = returns - np.asarray([tr["value"] for tr in traj], dtype=np.float32)
    return returns, advs


def ppo_update(policy, opt, batch, device, clip, epochs, ent_coef, vf_coef):
    obs = torch.as_tensor(np.stack([b["obs"] for b in batch]), dtype=torch.float32, device=device)
    masks = torch.as_tensor(np.stack([b["mask"] for b in batch]), dtype=torch.bool, device=device)
    tool_ids = torch.as_tensor([b["tool_id"] for b in batch], dtype=torch.long, device=device)
    params = torch.as_tensor(np.stack([b["params"] for b in batch]), dtype=torch.float32, device=device)
    n_agents = torch.as_tensor([b["n_agent"] for b in batch], dtype=torch.long, device=device)
    old_logp = torch.as_tensor([b["logp"] for b in batch], dtype=torch.float32, device=device)
    returns = torch.as_tensor([b["return"] for b in batch], dtype=torch.float32, device=device)
    advs = torch.as_tensor([b["adv"] for b in batch], dtype=torch.float32, device=device)
    if advs.numel() > 1:
        advs = (advs - advs.mean()) / (advs.std() + 1e-8)

    logits, h = policy.tool_logits(obs, masks)
    dist = torch.distributions.Categorical(logits=logits)
    logp_tool = dist.log_prob(tool_ids)
    mean = policy.param_mean(h)
    std = policy.log_std.exp()
    z = torch.logit(params.clamp(1e-5, 1 - 1e-5))
    nmax = int(n_agents.max().item())
    if nmax > 0:
        m_sel = mean[:, :nmax]
        s_sel = std[:nmax]
        z_sel = z[:, :nmax]
        lp = torch.distributions.Normal(m_sel, s_sel).log_prob(z_sel)
        col_mask = (torch.arange(nmax, device=device)[None, :] < n_agents[:, None]).float()
        logp_param = (lp * col_mask).sum(-1)
    else:
        logp_param = torch.zeros(obs.shape[0], device=device)
    logp = logp_tool + logp_param
    values = policy.value_head(h).squeeze(-1)

    ratio = torch.exp(logp - old_logp)
    surr1 = ratio * advs
    surr2 = torch.clamp(ratio, 1 - clip, 1 + clip) * advs
    pg_loss = -torch.min(surr1, surr2).mean()
    v_loss = F.mse_loss(values, returns)
    ent = dist.entropy().mean()
    loss = pg_loss + vf_coef * v_loss - ent_coef * ent
    opt.zero_grad()
    loss.backward()
    nn.utils.clip_grad_norm_(policy.parameters(), 0.5)
    opt.step()
    return {"pg": pg_loss.item(), "v": v_loss.item(), "ent": ent.item(),
            "loss": loss.item()}


def _write_summary(out_root, cfg, base_rewards, ppo_rewards, plan_path,
                   train_rewards=None, delta=None):
    summ = {
        "baseline_mean": float(np.mean(base_rewards)) if base_rewards else None,
        "baseline_rewards": [float(r) for r in base_rewards],
        "ppo_mean": float(np.mean(ppo_rewards)) if ppo_rewards is not None else None,
        "ppo_rewards": [float(r) for r in ppo_rewards] if ppo_rewards is not None else None,
        "train_rewards": [float(r) for r in train_rewards] if train_rewards else None,
        "delta": delta,
        "plan_path": plan_path,
    }
    (out_root / "summary.json").write_text(json.dumps(summ, indent=2))
    log.info("summary escrito en %s/summary.json", out_root)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(HERE / "config.yaml"))
    ap.add_argument("--allow-blocking-eval", action="store_true")
    ap.add_argument("--episodes", type=int, default=None)
    ap.add_argument("--baseline-only", action="store_true")
    ap.add_argument("--no-train", action="store_true")
    ap.add_argument("--heuristic", action="store_true",
                   help="Ejecuta la política heurística/experta (sin entrenar)")
    ap.add_argument("--corpus", default=None,
                   help="Ruta a un corpus de MIDIs (mejora quality_scorer/drummer)")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config))
    if args.corpus:
        cfg["corpus"] = args.corpus
    root = Path(cfg.get("root_dir", ".."))
    if not root.is_absolute():
        root = (HERE / root).resolve()
    cfg["root_dir"] = str(root)
    out_root = root / cfg["training"]["output_root"]
    out_root.mkdir(parents=True, exist_ok=True)

    plan_path, curves_path, sections = build_plan_if_needed(cfg, root)
    log.info("plan: %s | curves: %s | sections: %s", plan_path, curves_path, sections)

    # corpus: pre-construir artefactos (cacheado) e inyectar paths en cfg
    corpus_artifacts = prepare_corpus(cfg, root)
    if corpus_artifacts.get("corpus_path"):
        cfg["quality_scorer_corpus"] = corpus_artifacts["corpus_path"]
    if corpus_artifacts.get("qs_cache"):
        cfg["quality_scorer_cache"] = corpus_artifacts["qs_cache"]

    # resolver eval provider (mergeando cfg de reward + cfg raíz)
    reward_cfg = dict(cfg.get("reward", {}))
    for k in ("preference_trainer_model", "preference_trainer_model_type",
              "quality_scorer_corpus", "quality_scorer_cache",
              "quality_scorer_weights"):
        if k in cfg:
            reward_cfg[k] = cfg[k]
    try:
        eval_provider = resolve_eval_provider(reward_cfg, root=str(root),
                                              allow_blocking=args.allow_blocking_eval)
    except EvalProviderUnavailableError as e:
        log.error("eval provider: %s", e)
        sys.exit(2)
    log.info("eval provider: %s", type(eval_provider).__name__)

    # inyectar pesos recalibrados del quality_scorer en el ctx del entorno
    if cfg.get("quality_scorer_weights"):
        corpus_artifacts["qs_weights"] = cfg["quality_scorer_weights"]
    env = make_env(cfg, root, eval_provider, plan_path, curves_path, sections,
                   out_root, prefix="rand_", corpus_artifacts=corpus_artifacts)
    seed = int(cfg.get("training", {}).get("seed", 42))
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    device = "cpu"

    if args.heuristic:
        return run_heuristic(env, cfg, root, plan_path, out_root,
                             corpus_artifacts=corpus_artifacts)

    # ------------------ baseline aleatorio ------------------

    # ------------------ baseline aleatorio ------------------
    n_base = int(cfg["training"].get("eval_episodes", 6))
    log.info("=== Baseline aleatorio-dentro-de-máscara (%d episodios) ===", n_base)
    base_rewards = []
    for i in range(n_base):
        _, R, elog = run_episode(env, policy=None, device=device, rng=rng)
        base_rewards.append(R)
        log.info("  [%d] reward=%.3f failed=%s midi=%s", i, R, elog.get("failed"),
                 elog.get("saved_midi", elog.get("final_midi")))
    log.info("baseline mean reward: %.4f (std %.4f)",
             float(np.mean(base_rewards)), float(np.std(base_rewards)))

    if args.baseline_only or args.no_train:
        _write_summary(out_root, cfg, base_rewards, None, plan_path)
        return 0

    # ------------------ entrenamiento PPO ------------------
    obs_dim = env.observation_space.shape[0]
    policy = PolicyNet(obs_dim, env.n_tool_slots, env.max_params)
    opt = torch.optim.Adam(policy.parameters(), lr=float(cfg["training"].get("lr", 8e-4)))
    total_eps = args.episodes or int(cfg["training"].get("total_episodes", 32))
    rollout_eps = int(cfg["training"].get("rollout_episodes", 8))
    clip = float(cfg["training"].get("clip", 0.2))
    epochs = int(cfg["training"].get("epochs", 6))
    ent_coef = float(cfg["training"].get("ent_coef", 0.01))
    vf_coef = float(cfg["training"].get("vf_coef", 0.5))

    env.episode_id_prefix = "tr_"
    update = 0
    done_eps = 0
    train_rewards_all = []
    while done_eps < total_eps:
        batch_eps = min(rollout_eps, total_eps - done_eps)
        batch = []
        ep_rewards = []
        for _ in range(batch_eps):
            traj, R, _ = run_episode(env, policy, device=device, rng=rng)
            returns, advs = compute_returns(traj, 0.99)
            for t, tr in enumerate(traj):
                batch.append({
                    "obs": tr["obs"], "mask": tr["mask"], "tool_id": tr["tool_id"],
                    "params": tr["params"], "logp": tr["logp"], "value": tr["value"],
                    "return": returns[t], "adv": advs[t], "n_agent": tr["n_agent"],
                })
            ep_rewards.append(R)
            train_rewards_all.append(R)
        for _ in range(epochs):
            stats = ppo_update(policy, opt, batch, device, clip, 1, ent_coef, vf_coef)
        update += 1
        done_eps += batch_eps
        log.info("update %d | eps=%d | meanR=%.4f | pg=%.4f v=%.4f ent=%.4f",
                 update, done_eps, float(np.mean(ep_rewards)),
                 stats["pg"], stats["v"], stats["ent"])

    torch.save(policy.state_dict(), out_root / "ppo_policy.pt")

    # ------------------ eval policy entrenada ------------------
    env.episode_id_prefix = "ppo_"
    n_eval = int(cfg["training"].get("eval_episodes", 6))
    log.info("=== Eval política entrenada (%d episodios, greedy=False) ===", n_eval)
    ppo_rewards = []
    for i in range(n_eval):
        _, R, elog = run_episode(env, policy=policy, device=device, greedy=False, rng=rng)
        ppo_rewards.append(R)
        log.info("  [%d] reward=%.3f midi=%s", i, R,
                 elog.get("saved_midi", elog.get("final_midi")))
    log.info("ppo mean reward:      %.4f (std %.4f)",
             float(np.mean(ppo_rewards)), float(np.std(ppo_rewards)))
    log.info("baseline mean reward: %.4f", float(np.mean(base_rewards)))
    delta = float(np.mean(ppo_rewards) - np.mean(base_rewards))
    log.info("delta (ppo - baseline): %+.4f  →  %s", delta,
             "MEJORA" if delta > 0 else "sin mejora")

    _write_summary(out_root, cfg, base_rewards, ppo_rewards, plan_path,
                   train_rewards=train_rewards_all, delta=delta)
    return 0


def run_heuristic(env, cfg, root, plan_path, out_root, corpus_artifacts=None):
    """Política heurística estocástica: muestrea arco/plan/preset/orden por
    episodio para producir obras diversas sin entrenamiento."""
    import json as _json
    hcfg = cfg.get("heuristic", {})
    n_eps = int(hcfg.get("episodes", 8))
    candidates = int(hcfg.get("candidates", 3))
    per_section = bool(hcfg.get("per_section", False))
    vary_order = bool(hcfg.get("vary_order", True))
    arcs = hcfg.get("arcs", ["hero"])
    seed = int(cfg.get("training", {}).get("seed", 42))
    rng = np.random.default_rng(seed)

    # pool de planes: un plan por arco (cacheado en work_root/_plans/)
    plan_pool = build_plan_pool(cfg, root, arcs)
    if not plan_pool:
        log.error("no se pudo construir ningún plan del pool"); return 1
    log.info("plan pool: %s", list(plan_pool.keys()))
    env.episode_id_prefix = "heur_"
    log.info("=== Política heurística estocástica — %d episodios, arcos=%s, candidates=%d, vary_order=%s ===",
             n_eps, list(plan_pool.keys()), candidates, vary_order)
    rewards = []
    for i in range(n_eps):
        arc = list(plan_pool)[rng.integers(len(plan_pool))]
        p, c, secs = plan_pool[arc]
        env.configure_plan(p, c, secs)
        env.set_episode_rng(rng)
        env.reset()
        env.ctx["candidates"] = candidates
        env.ctx["per_section"] = per_section
        preset, order_ep = sample_episode_config(arc, rng, vary_order=vary_order)
        done = False
        steps = 0
        last_info = {}
        while not done:
            action = heuristic_action(env, arc=arc, max_params=env.max_params,
                                      order=order_ep, rng=rng, preset_override=preset)
            obs, r, done, _, last_info = env.step(action)
            steps += 1
            if steps > 12:
                break
        R = float(r) if not last_info.get("failed") else -1.0
        rewards.append(R)
        seq = [s["tool"] for s in env.episode_log["steps"]]
        log.info("  [%d] arc=%-11s reward=%.3f steps=%d seq=%s",
                 i, arc, R, steps, " → ".join(seq))
    log.info("heur mean reward: %.4f (std %.4f)", float(np.mean(rewards)), float(np.std(rewards)))
    summ = {"heuristic_mean": float(np.mean(rewards)),
            "heuristic_rewards": rewards, "arcs": list(plan_pool.keys()),
            "plan_pool": {k: v[0] for k, v in plan_pool.items()},
            "candidates": candidates, "vary_order": vary_order}
    Path(out_root / "heuristic_summary.json").write_text(_json.dumps(summ, indent=2))
    log.info("summary escrito en %s/heuristic_summary.json", out_root)
    return 0


if __name__ == "__main__":
    sys.exit(main())
