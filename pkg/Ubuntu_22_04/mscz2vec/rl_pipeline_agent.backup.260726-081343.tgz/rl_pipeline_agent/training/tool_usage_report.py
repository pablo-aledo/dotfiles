"""tool_usage_report.py — informe para evaluador humano.

Agrega los logs de los episodios (episode.json en rl_output/) y produce un
informe legible de:
  - ranking de obras por reward
  - frecuencia de uso de cada herramienta (global y entre el top-K)
  - parámetros más frecuentes por herramienta (con su rango y reward medio)
  - secuencias (cadenas de tools) más exitosas

Uso:
    python -m rl_pipeline_agent.training.tool_usage_report [--rl-output DIR] [--top N]
"""
from __future__ import annotations
import argparse
import json
import logging
import statistics
from collections import Counter, defaultdict
from pathlib import Path

log = logging.getLogger("rl_pipeline.report")


def load_episodes(rl_output: Path) -> list[dict]:
    """Carga todos los episode.json de rl_output (planos y en _episodes/)."""
    eps = []
    for p in rl_output.glob("*.episode.json"):
        try:
            eps.append(json.loads(p.read_text()))
        except Exception as e:
            log.warning("no pudo leer %s: %s", p, e)
    for p in (rl_output / "_episodes").glob("*/episode.json"):
        try:
            eps.append(json.loads(p.read_text()))
        except Exception:
            pass
    # dedup por id
    seen = set()
    uniq = []
    for e in eps:
        eid = e.get("id")
        if eid and eid not in seen:
            seen.add(eid)
            uniq.append(e)
    return uniq


def _summarize_param(value) -> str:
    """Compacta un valor de parámetro para mostrarlo (float→3 dec, listas cortas)."""
    if isinstance(value, float):
        return f"{value:.3f}"
    if isinstance(value, bool):
        return str(value)
    return str(value)


def build_report(rl_output: Path, top: int = 10) -> dict:
    eps = load_episodes(rl_output)
    if not eps:
        return {"error": f"no se encontraron episode.json en {rl_output}"}

    # Sólo episodios no fallidos
    ok = [e for e in eps if not e.get("failed")]
    failed = [e for e in eps if e.get("failed")]

    # ranking por reward
    ranked = sorted(ok, key=lambda e: float(e.get("reward", -2)), reverse=True)
    top_k = ranked[:top]

    # --- frecuencia global ---
    tool_counts = Counter()
    tool_rewards = defaultdict(list)  # reward del episodio donde se usó el tool
    for e in ok:
        seen_in_ep = set()
        for s in e.get("steps", []):
            t = s.get("tool")
            if t and t not in seen_in_ep:
                tool_counts[t] += 1
                seen_in_ep.add(t)
                tool_rewards[t].append(float(e.get("reward", 0)))

    # --- frecuencia en el top-K ---
    top_counts = Counter()
    for e in top_k:
        for s in e.get("steps", []):
            t = s.get("tool")
            if t:
                top_counts[t] += 1

    # --- parámetros más frecuentes por herramienta (top-K) ---
    # param_values[tool][param_name] = Counter(value_str)
    param_values: dict[str, dict[str, Counter]] = defaultdict(lambda: defaultdict(Counter))
    # param_rewards[tool][param_name][value_str] = [rewards...]
    param_rewards: dict[str, dict[str, dict[str, list[float]]]] = \
        defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    # nombres de parámetros wired a excluir (rutas/seed/etc.) — son ruido
    WIRED = {"from_narrator", "melody_midi", "input_midi", "output_midi",
             "out_dir", "out_json", "plan", "curves", "tension_curve",
             "export_combined", "fast", "seed", "candidates", "per_section"}

    for e in top_k:
        r = float(e.get("reward", 0))
        for s in e.get("steps", []):
            t = s.get("tool")
            params = s.get("params", {})
            if not t or not params:
                continue
            for pname, pval in params.items():
                if pname in WIRED:
                    continue
                vs = _summarize_param(pval)
                param_values[t][pname][vs] += 1
                param_rewards[t][pname][vs].append(r)

    # --- secuencias más exitosas ---
    seq_counter: Counter = Counter()
    seq_rewards: dict[tuple, list[float]] = defaultdict(list)
    for e in ok:
        seq = tuple(s.get("tool") for s in e.get("steps", []) if s.get("tool"))
        if not seq:
            continue
        seq_counter[seq] += 1
        seq_rewards[seq].append(float(e.get("reward", 0)))

    # --- montar reporte ---
    report = {
        "n_episodes": len(eps),
        "n_ok": len(ok),
        "n_failed": len(failed),
        "top_k": top,
        "reward_stats": {
            "all_ok": _stats([float(e.get("reward", 0)) for e in ok]),
            "top_k":  _stats([float(e.get("reward", 0)) for e in top_k]),
        },
        "ranking": [
            {"id": e.get("id"), "reward": float(e.get("reward", 0)),
             "failed": bool(e.get("failed")),
             "seq": [s.get("tool") for s in e.get("steps", [])],
             "midi": e.get("saved_midi") or e.get("final_midi")}
            for e in ranked[:max(top, 10)]
        ],
        "tool_frequency": {
            t: {
                "uses_global": tool_counts[t],
                "uses_top_k": top_counts.get(t, 0),
                "reward_mean_when_used": _stats(tool_rewards[t])["mean"],
                "n_episodes_when_used": len(tool_rewards[t]),
            }
            for t in sorted(tool_counts, key=lambda x: tool_counts[x], reverse=True)
        },
        "params_by_tool": {},
        "top_sequences": [],
    }

    for t, pnames in param_values.items():
        report["params_by_tool"][t] = {}
        for pname, ctr in pnames.items():
            rows = []
            for vs, cnt in ctr.most_common(5):
                rs = param_rewards[t][pname][vs]
                rows.append({
                    "value": vs,
                    "count": cnt,
                    "reward_mean": _stats(rs)["mean"],
                })
            report["params_by_tool"][t][pname] = rows

    for seq, cnt in seq_counter.most_common(8):
        rs = seq_rewards[seq]
        report["top_sequences"].append({
            "sequence": list(seq),
            "count": cnt,
            "reward_mean": _stats(rs)["mean"],
            "reward_max": max(rs) if rs else 0,
        })

    return report


def _stats(xs: list[float]) -> dict:
    if not xs:
        return {"mean": 0.0, "min": 0.0, "max": 0.0, "std": 0.0, "n": 0}
    return {
        "mean": float(statistics.mean(xs)),
        "min": float(min(xs)),
        "max": float(max(xs)),
        "std": float(statistics.pstdev(xs)) if len(xs) > 1 else 0.0,
        "n": len(xs),
    }


# ---------- render humano (texto) ----------
def render_text(report: dict) -> str:
    if "error" in report:
        return report["error"]
    L = []
    L.append("═" * 72)
    L.append("  REPORTE DE USO DE HERRAMIENTAS — rl_output/")
    L.append("═" * 72)
    L.append(f"Episodios: {report['n_episodes']} totales "
             f"({report['n_ok']} ok, {report['n_failed']} fallidos)")
    rs = report["reward_stats"]
    L.append(f"Reward medio: all_ok={rs['all_ok']['mean']:.3f}  "
             f"top_{report['top_k']}={rs['top_k']['mean']:.3f}")
    L.append("")

    L.append("─" * 72)
    L.append(f"  RANKING DE OBRAS (top {len(report['ranking'])})")
    L.append("─" * 72)
    for i, e in enumerate(report["ranking"], 1):
        seq = " → ".join(e["seq"]) if e["seq"] else "(vacío)"
        L.append(f"  {i:2d}. {e['id']:14s}  r={e['reward']:+.3f}  {seq}")
    L.append("")

    L.append("─" * 72)
    L.append("  FRECUENCIA DE HERRAMIENTAS")
    L.append("─" * 72)
    L.append(f"  {'tool':22s} {'global':>7s} {'topK':>5s} {'r_medio':>8s} {'n_eps':>6s}")
    for t, info in report["tool_frequency"].items():
        L.append(f"  {t:22s} {info['uses_global']:7d} {info['uses_top_k']:5d} "
                 f"{info['reward_mean_when_used']:8.3f} {info['n_episodes_when_used']:6d}")
    L.append("")

    L.append("─" * 72)
    L.append("  PARÁMETROS MÁS FRECUENTES POR HERRAMIENTA (entre top-K)")
    L.append("─" * 72)
    pbt = report["params_by_tool"]
    if not pbt:
        L.append("  (sin parámetros agent registrados)")
    for t in sorted(pbt):
        L.append(f"  ■ {t}")
        for pname, rows in pbt[t].items():
            L.append(f"     · {pname}:")
            for row in rows:
                L.append(f"         {row['value']:18s} ×{row['count']}  "
                         f"(r_medio={row['reward_mean']:.3f})")
    L.append("")

    L.append("─" * 72)
    L.append("  SECUENCIAS MÁS EXITOSAS")
    L.append("─" * 72)
    for s in report["top_sequences"]:
        L.append(f"  [{s['count']}×] r_medio={s['reward_mean']:.3f} r_max={s['reward_max']:.3f}")
        L.append(f"     {' → '.join(s['sequence'])}")
    L.append("")
    L.append("═" * 72)
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="Informe de uso de herramientas")
    ap.add_argument("--rl-output", default="rl_output")
    ap.add_argument("--top", type=int, default=10)
    ap.add_argument("--json", action="store_true", help="salida JSON en vez de texto")
    ap.add_argument("--out", default=None, help="escribir a fichero además de stdout")
    args = ap.parse_args()

    rl = Path(args.rl_output)
    report = build_report(rl, top=args.top)
    if args.json:
        text = json.dumps(report, ensure_ascii=False, indent=2, default=str)
    else:
        text = render_text(report)
    print(text)
    if args.out:
        Path(args.out).write_text(text)
        print(f"\n[reporte guardado en {args.out}]", file=__import__("sys").stderr)


if __name__ == "__main__":
    main()
