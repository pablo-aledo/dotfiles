#!/usr/bin/env python3
# ==============================================================================
#                          Y U E _ C O M P O S E R . P Y
# ------------------------------------------------------------------------------
#  Letra + estilo -> partitura ABC editable (melodia + acordes) -> cancion
#  completa (voz + acompanamiento, 48kHz estereo). YuE2 (M.A.P / HKUST):
#  backbone AR-NAR (Mixture-of-Transformers) que primero planifica una
#  partitura simbolica inspeccionable y luego la sintetiza con flow matching
#  y un decodificador VAE.
#
#  Fichero unico, autocontenido, adaptado del paquete oficial yue2-infer al
#  estilo mutopia (una herramienta = un fichero, subcomandos simples).
#
#  SUBCOMANDOS
#    doctor          Diagnostico de entorno: GPU, versiones, pesos locales
#    plan            Solo la etapa de planificacion (estilo+letra -> ABC)
#    generate        Pipeline completo (o solo "plan" con --stage plan)
#    all-modes       Genera los 3 modos (full/melody/off) de una peticion
#    decode          Re-decodifica latentes cacheados de una generacion previa
#    batch           Genera un lote de peticiones desde un JSONL
#
#  EJEMPLOS
#    yue_composer.py doctor
#    yue_composer.py generate --style "pop acustico, voz femenina" \
#        --lyrics-file letra.txt --output runs/mi_cancion
#    yue_composer.py plan --style "..." --lyrics "..." --output runs/plan
#    yue_composer.py all-modes --style "..." --lyrics "..." --output runs/comparar
#    yue_composer.py decode --source runs/mi_cancion/song --output runs/redecodificado
#    yue_composer.py batch --input peticiones.jsonl --output runs/lote
#
#  Requiere GPU NVIDIA con soporte BF16 y ~24GB VRAM (Python 3.10+).
#  Dependencias primarias: torch, transformers, huggingface_hub, safetensors,
#  tiktoken, numpy, soundfile. Opcionales (--backend vllm): vllm, triton.
#  Los pesos se descargan de Hugging Face (m-a-p/YuE2-3B) en el primer uso,
#  o se toman de ./models/YuE2-3B si existe (ver YUE2_KIT).
# ==============================================================================
from __future__ import annotations

import argparse
import base64
import contextlib
import dataclasses
import gc
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import operator
import os
import re
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import uuid
import weakref
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field, asdict
from numbers import Integral
from pathlib import Path
from typing import Callable, List, Literal, Optional, Sequence, Tuple, Union

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import weight_norm
from transformers import GenerationMixin, PretrainedConfig, PreTrainedModel
from transformers.cache_utils import DynamicCache
from transformers.modeling_outputs import CausalLMOutputWithPast

# Colores ANSI para salida de terminal (estilo mutopia)
_C = {"g": "\033[32m", "y": "\033[33m", "r": "\033[31m", "b": "\033[34m",
      "bold": "\033[1m", "reset": "\033[0m"}


def _c(text, color):
    if not sys.stderr.isatty():
        return text
    return f"{_C[color]}{text}{_C['reset']}"

# ----------------------------------------------------------------------------
# PROTOCOLO Y CONSTANTES DE TOKENS
# ----------------------------------------------------------------------------

EOD = 151643
ABC_START, ABC_END = 151847, 151848
MUSIC_START, MUSIC_END = 151851, 151852
CODEC_OFFSET, CODEC_SIZE = 151853, 32768
LATENT_START, LATENT_END, LATENT_PAD = 184621, 184622, 184623
VOCAB_SIZE, CONTEXT = 184704, 24576
PROTOCOL_VERSION = "yue2-native-v1"
INSTRUCTIONS = {
    "off": "Generate music with codec tokens from the given conditions.",
    "melody": "Generate a melody-only ABC transcription without chord symbols, then generate music with codec tokens from the given conditions.",
    "full": "Generate a chord-annotated ABC transcription, then generate music with codec tokens from the given conditions.",
}


@dataclass(frozen=True)
class Sampling:
    temperature: float = 1.0
    top_p: float = 0.95
    top_k: int = 100
    repetition_penalty: float = 1.2
    penalty_window: int = 50
    min_tokens: int = 200
    max_tokens: int = 9000

    def __post_init__(self):
        if any(type(x) is not int for x in (self.top_k, self.penalty_window, self.min_tokens, self.max_tokens)):
            raise ValueError("Sampling counts must be integers")
        if not all(math.isfinite(x) for x in (self.temperature, self.top_p, self.repetition_penalty)):
            raise ValueError("Sampling numbers must be finite")
        if not 0 <= self.temperature <= 5 or not 0 < self.top_p <= 1 or self.top_k < 1:
            raise ValueError("Invalid sampling temperature/top_p/top_k")
        if self.repetition_penalty <= 0 or not 1 <= self.penalty_window <= 100:
            raise ValueError("Invalid repetition penalty/window")
        if not 0 <= self.min_tokens <= self.max_tokens or self.max_tokens < 1:
            raise ValueError("Require 0 <= min_tokens <= max_tokens")


@dataclass(frozen=True)
class GenerationConfig:
    abc: Sampling = field(default_factory=lambda: Sampling(.7, .9, 30, 1.005, 100, 32, 4096))
    semantic: Sampling = field(default_factory=Sampling)
    ode_steps: int = 32
    ode_method: str = "midpoint"
    context: int = CONTEXT
    version: str = PROTOCOL_VERSION

    def __post_init__(self):
        if self.context != CONTEXT or self.ode_method != "midpoint" or type(self.ode_steps) is not int or self.ode_steps < 1:
            raise ValueError("Require context=24576 and midpoint with positive integer steps")

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        value = dict(data)
        defaults = cls()
        for key in ("abc", "semantic"):
            if key in value and isinstance(value[key], dict):
                value[key] = Sampling(**{**asdict(getattr(defaults, key)), **value[key]})
        return cls(**value)


def resolve_sampling(value, default):
    if value is None:
        return default
    if isinstance(value, Sampling):
        return value
    if isinstance(value, dict):
        return Sampling(**{**asdict(default), **value})
    raise TypeError("Sampling must be a Sampling object or a dictionary of overrides")


@dataclass(frozen=True)
class SongRequest:
    style: str
    lyrics: str
    cot: str = "full"
    seed: int = 831001
    abc: str | None = None
    cfg_scale: float | None = None
    id: str = "song"

    def __post_init__(self):
        if self.cot not in INSTRUCTIONS:
            raise ValueError("cot must be off, melody or full")
        if not isinstance(self.style, str) or not isinstance(self.lyrics, str):
            raise TypeError("style and lyrics must be strings")
        if type(self.seed) is not int or not 0 <= self.seed < 2**63:
            raise ValueError("seed must be an integer in [0, 2**63)")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,179}", self.id) or self.id in {".", ".."}:
            raise ValueError("id must be a filename-safe identifier")
        if self.abc is not None and (self.cot == "off" or not isinstance(self.abc, str) or not self.abc.strip()):
            raise ValueError("External ABC requires nonempty text and cot=melody/full")
        if self.cfg_scale is not None and (not math.isfinite(self.cfg_scale) or not 0 <= self.cfg_scale <= 20):
            raise ValueError("cfg_scale must be finite and in [0,20]")

    @property
    def guidance(self):
        return (1.01 if self.cot == "off" else 1.0) if self.cfg_scale is None else self.cfg_scale

    def text(self):
        return f"{INSTRUCTIONS[self.cot]}\n[Tags]\n{self.style}\n[Lyrics]\n{self.lyrics}\n"

    def to_dict(self):
        return asdict(self)


def token_prefixes(request, tokenizer, abc_ids=None):
    base = [EOD] + tokenizer.encode(request.text())
    if request.cot == "off":
        return base + [ABC_START, ABC_END, MUSIC_START]
    if abc_ids is None:
        if request.abc is None:
            return base + [ABC_START]
        abc_ids = tokenizer.encode(request.abc)
    abc_ids = list(abc_ids)
    if any(type(token) is not int or not 0 <= token < EOD for token in abc_ids):
        raise ValueError("ABC IDs must remain inside the ordinary text vocabulary")
    return base + [ABC_START] + abc_ids + [ABC_END, MUSIC_START]


def negative_prefix(request, tokenizer, abc_ids=None):
    base = [EOD] + tokenizer.encode(INSTRUCTIONS[request.cot])
    if request.cot == "off":
        return base + [MUSIC_START]
    if abc_ids is None:
        raise ValueError("Symbolic CFG must retain the exact positive-branch ABC IDs")
    abc_ids = list(abc_ids)
    if any(type(token) is not int or not 0 <= token < EOD for token in abc_ids):
        raise ValueError("ABC IDs must remain inside the ordinary text vocabulary")
    return base + [ABC_START] + abc_ids + [ABC_END, MUSIC_START]


def chunk_ranges(frames, prefix_tokens, context=CONTEXT):
    size = min((context - prefix_tokens - 3) // 2, CONTEXT)
    if frames < 1 or size < 1:
        raise ValueError("Empty codec or prefix leaves no acoustic context")
    return [(a, min(a + size, frames)) for a in range(0, frames, size)]


# ----------------------------------------------------------------------------
# RESOLUCION DE MODELOS Y ARTEFACTOS EN DISCO
# ----------------------------------------------------------------------------

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def identity(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    os.replace(temporary, path)


# Explicit public model files. Extra reports, caches and arbitrary code are not exported.
MODEL_FILES = frozenset({
    "config.json", "generation_config.json", "yue2_generation_config.json",
    "weights_manifest.json", "model.safetensors", "model.safetensors.index.json",
    "qwen.tiktoken", "modeling_yue2.py", "modeling_vae.py",
    "LICENSE", "THIRD_PARTY_NOTICES.md",
})
MODEL_LICENSES = frozenset({"stable-audio-tools-MIT.txt", "SnakeBeta-NVIDIA-MIT.txt"})
SHARD_NAME = re.compile(r"model-[0-9]{5}-of-[0-9]{5}\.safetensors")


def resolve_model(model, revision=None, local_files_only=False, token=None, cache_dir=None, **kwargs):
    path = Path(model).expanduser()
    if path.is_dir():
        return path.resolve()
    if path.is_absolute() or str(model).startswith("."):
        raise FileNotFoundError(path)
    from huggingface_hub import snapshot_download
    return Path(snapshot_download(str(model), revision=revision, local_files_only=local_files_only,
                                  token=token, cache_dir=cache_dir,
                                  allow_patterns=sorted(MODEL_FILES) +
                                      ["model-?????-of-?????.safetensors"] +
                                      ["licenses/" + name for name in sorted(MODEL_LICENSES)]))


def copy_model_files(source, destination):
    """Export a model to an empty directory with a documented file boundary."""
    source, destination = Path(source).resolve(), Path(destination)
    if destination.exists() and any(destination.iterdir()):
        raise FileExistsError("save_pretrained needs an empty model destination")
    config = json.loads((source / "config.json").read_text())
    kind = config.get("model_type")
    if kind == "yue2":
        clean_config = YuE2Config(**config).to_dict()
        code_name = "modeling_yue2.py"
    elif kind == "yue2_vae":
        clean_config = YuE2VAEConfig(**config).to_dict()
        code_name = "modeling_vae.py"
    else:
        raise ValueError("Unsupported model configuration")
    weights = model_identity(source)
    names = set(MODEL_FILES) - {"config.json", "modeling_yue2.py", "modeling_vae.py", "weights_manifest.json"}
    names.update(name for name in weights["files"] if SHARD_NAME.fullmatch(name))
    if set(weights["files"]) - names:
        raise ValueError("Unexpected model weight filename")
    destination.mkdir(parents=True, exist_ok=True)
    for name in sorted(names):
        file = source / name
        if file.is_file():
            if name == "yue2_generation_config.json":
                write_json(destination / name, GenerationConfig.from_dict(json.loads(file.read_text())).to_dict())
            elif name == "generation_config.json":
                from transformers import GenerationConfig as HFGenerationConfig
                known = HFGenerationConfig().to_dict()
                value = {key: value for key, value in json.loads(file.read_text()).items()
                         if key in known and not key.startswith("_")}
                write_json(destination / name, value)
            else:
                shutil.copyfile(file, destination / name)
    # Use the installed, reviewed implementation instead of arbitrary source-folder code.
    # (yue_composer.py es fichero unico: contiene modeling_yue2.py y modeling_vae.py fusionados,
    # asi que ambos nombres de referencia se satisfacen con una copia del propio fichero.)
    shutil.copyfile(Path(__file__).resolve(), destination / code_name)
    for name in sorted(MODEL_LICENSES):
        file = source / "licenses" / name
        if file.is_file():
            (destination / "licenses").mkdir(exist_ok=True)
            shutil.copyfile(file, destination / "licenses" / name)
    write_json(destination / "config.json", clean_config)
    write_json(destination / "weights_manifest.json", {"files": weights["files"]})


def model_identity(path, verify=True):
    path = Path(path)
    manifest = path / "weights_manifest.json"
    expected = json.loads(manifest.read_text()) if manifest.exists() else None
    files = sorted(path.glob("*.safetensors"))
    if not files:
        raise FileNotFoundError(f"No safetensors weights in {path}")
    entries = {}
    for file in files:
        digest = sha256_file(file)
        if verify and expected is not None:
            wanted = expected.get("files", {}).get(file.name, {}).get("sha256")
            if wanted != digest:
                raise ValueError(f"Weight integrity failed: {file.name}")
        entries[file.name] = {"sha256": digest, "bytes": file.stat().st_size}
    if expected is not None and set(entries) != set(expected.get("files", {})):
        raise ValueError("Weight manifest has missing or unexpected shards")
    return {"files": entries, "config_sha256": sha256_file(path / "config.json")}


def collect_hashes(directory, exclude=("result.json",)):
    directory = Path(directory)
    return {str(p.relative_to(directory)): {"sha256": sha256_file(p), "bytes": p.stat().st_size}
            for p in sorted(directory.rglob("*")) if p.is_file() and p.name not in exclude}


def verify_result(directory, expected_identity=None):
    directory = Path(directory)
    result = json.loads((directory / "result.json").read_text())
    if result.get("status") != "complete":
        raise ValueError("Saved request did not complete")
    if expected_identity is not None and result.get("identity") != expected_identity:
        raise ValueError("Request/config/weight identity changed; use a new output directory")
    required = {"audio.flac", "prefix.npy", "semantic.npy", "latent.npy", "request.json", "config.json"}
    artifacts = result.get("artifacts", {})
    if not required <= set(artifacts):
        raise ValueError("Incomplete result artifact manifest")
    for name, expected in artifacts.items():
        p = directory / name
        if Path(name).is_absolute() or not p.resolve().is_relative_to(directory.resolve()):
            raise ValueError("Invalid artifact path")
        if not p.is_file() or p.stat().st_size != expected["bytes"] or sha256_file(p) != expected["sha256"]:
            raise ValueError(f"Missing or corrupt result: {name}")
    return result


# ----------------------------------------------------------------------------
# BARRA DE PROGRESO
# ----------------------------------------------------------------------------

_clock = time.monotonic
_STATUSES = {
    "completed": "Completed",
    "failed": "Failed",
    "cancelled": "Cancelled",
    "truncated": "Finished (generation limit reached)",
}


def _count(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a nonnegative integer")
    try:
        value = operator.index(value)
    except TypeError as exc:
        raise ValueError(f"{name} must be a nonnegative integer") from exc
    if value < 0:
        raise ValueError(f"{name} must be a nonnegative integer")
    return value


def _ascii(text):
    return "".join(c if " " <= c <= "~" else " " for c in str(text)).strip()


def _terminal_columns(stream):
    # Unconfigured PTYs can report (0, 0), including those created by `script`.
    # Honor a positive COLUMNS override, then the device, then a usable fallback.
    try:
        columns = int(os.environ.get("COLUMNS", ""))
        if columns > 0:
            return columns
    except ValueError:
        pass
    try:
        columns = os.get_terminal_size(stream.fileno()).columns
        if columns > 0:
            return columns
    except (AttributeError, OSError, ValueError):
        pass
    return 80


def _exit_status(exc_type):
    if exc_type is None:
        return "completed"
    if issubclass(exc_type, (InterruptedError, KeyboardInterrupt)) or any(
        base.__name__ in {"CancelledError", "CanceledError"} for base in exc_type.__mro__
    ):
        return "cancelled"
    return "failed"


class Progress:
    """Write ASCII progress to stderr, with a heartbeat during blocking work.

    TTYs at least 60 columns wide refresh one line. Narrow terminals and other
    streams receive start/end lines and at most one intermediate line per five
    seconds, without clipping labels or counts. ``enabled=False`` starts no thread
    and performs no stream operations. A stage owns its heartbeat lifetime, so
    an outer ``with Progress()`` is optional. ``close()`` is also available.
    """

    def __init__(self, enabled=True, stream=None, refresh_interval=0.25):
        if not math.isfinite(refresh_interval) or refresh_interval <= 0:
            raise ValueError("refresh_interval must be positive and finite")
        self.enabled = bool(enabled)
        self.stream = sys.stderr if stream is None else stream
        self.refresh_interval = float(refresh_interval)
        self._lock = threading.RLock()
        self._active = []
        self._thread = None
        self._stop = None
        self._closed = False
        self._summary_written = False
        self._line_width = 0
        self._tty = False
        self._columns = 80
        if self.enabled:
            try:
                self._tty = bool(self.stream.isatty())
            except (AttributeError, OSError, ValueError):
                pass
            if self._tty:
                self._columns = _terminal_columns(self.stream)
                self._tty = self._columns >= 60
        self._interval = self.refresh_interval if self._tty else max(5.0, self.refresh_interval)

    def __enter__(self):
        with self._lock:
            if self._closed:
                raise RuntimeError("Progress is closed")
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close(status=_exit_status(exc_type))
        return False

    def stage(self, label, total=None, unit=None):
        """Return a context manager; entering it starts this stage at zero."""
        return _Stage(self, label, total=total, unit=unit)

    def _write(self, text, final=False):
        if not self.enabled:
            return
        try:
            if self._tty:
                text = text[:self._columns - 1]
                self.stream.write("\r" + text + " " * max(0, self._line_width - len(text)))
                self._line_width = len(text)
                if final:
                    self.stream.write("\n")
                    self._line_width = 0
            else:
                self.stream.write(text + "\n")
            self.stream.flush()
        except (OSError, ValueError):
            # A closed terminal must not turn successful inference into failure.
            self.enabled = False
            if self._stop is not None:
                self._stop.set()

    def _newline(self):
        if self.enabled and self._tty and self._line_width:
            self._write("", final=True)

    def _render(self, stage, now, status=None, force=False):
        if not self.enabled or (not force and now - stage._last_render < self._interval):
            return
        stage._last_render = now
        elapsed = max(0.0, now - stage._started)
        parts = []
        if stage.total is not None:
            # Keep an honest count even if a caller exceeds its advertised total.
            amount = f"{stage.completed}/{stage.total} {stage.unit or 'items'}"
            if stage.total > 0:
                amount += f" ({100 * stage.completed / stage.total:.0f}%)"
                if self._tty:
                    filled = min(8, int(8 * stage.completed / stage.total))
                    amount = "[" + "#" * filled + "-" * (8 - filled) + "] " + amount
            parts.append(amount)
        elif stage.unit is not None or stage.completed:
            parts.append(f"{stage.completed} {stage.unit or 'items'}")
        if stage.unit == "tokens":
            rate = stage.completed / elapsed if elapsed > 0 else 0.0
            parts.append(f"{rate:.1f} tokens/s")
        parts.append(f"{elapsed:.1f}s" if self._tty else f"elapsed {elapsed:.1f}s")
        suffix = " | ".join(parts)
        if status is not None:
            prefix = "Limit reached" if self._tty and status == "truncated" else _STATUSES[status]
        elif self._tty:
            prefix = "|/-\\"[int(elapsed / self.refresh_interval) % 4]
        else:
            prefix = "Starting" if force and stage.completed == 0 else "Running"
        label = stage.label
        if self._tty:
            available = self._columns - 1 - len(f"[YuE2] {prefix} : {suffix}")
            if len(label) > max(0, available):
                label = label[:max(0, available - 3)] + ("..." if available >= 3 else "")
        self._write(f"[YuE2] {prefix} {label}: {suffix}", final=status is not None)

    def _heartbeat(self, stop):
        while not stop.wait(self._interval):
            with self._lock:
                if stop.is_set() or not self.enabled:
                    return
                if self._active:
                    self._render(self._active[-1], _clock())

    def _start(self, stage):
        with self._lock:
            if self._closed:
                raise RuntimeError("Progress is closed")
            if stage._started is not None:
                raise RuntimeError("A progress stage can only be entered once")
            stage._started = _clock()
            self._newline()
            self._active.append(stage)
            self._render(stage, stage._started, force=True)
            if self.enabled and self._thread is None:
                self._stop = threading.Event()
                self._thread = threading.Thread(target=self._heartbeat, args=(self._stop,),
                                                name="yue2-progress", daemon=True)
                self._thread.start()

    def _finish(self, stage, status):
        if status not in _STATUSES:
            raise ValueError("Unknown progress status")
        thread = None
        with self._lock:
            if stage._finished:
                return
            if stage._started is None:
                raise RuntimeError("Enter a progress stage before finishing it")
            stage._finished = True
            stage.status = status
            if self._active[-1] is not stage:
                self._newline()
            self._active.remove(stage)
            self._render(stage, _clock(), status=status, force=True)
            if self._active:
                self._render(self._active[-1], _clock(), force=True)
            elif self._thread is not None:
                self._stop.set()
                thread, self._thread = self._thread, None
                self._stop = None
        if thread is not None and thread is not threading.current_thread():
            thread.join()

    def close(self, status="completed"):
        """Finish active stages and stop the heartbeat; safe to call repeatedly."""
        if status not in _STATUSES:
            raise ValueError("Unknown progress status")
        with self._lock:
            self._closed = True
            active = list(reversed(self._active))
        for stage in active:
            self._finish(stage, status)

    def complete(self, audio_seconds, elapsed, *, truncated=False):
        """Write one final summary without starting a heartbeat thread."""
        if not all(math.isfinite(x) and x >= 0 for x in (audio_seconds, elapsed)):
            raise ValueError("audio_seconds and elapsed must be nonnegative and finite")
        with self._lock:
            if self._active:
                raise RuntimeError("Finish active stages before the completion summary")
            if self._summary_written:
                return
            self._summary_written = True
            status = _STATUSES["truncated" if truncated else "completed"]
            self._write(f"[YuE2] {status}: {audio_seconds:.1f}s audio in {elapsed:.1f}s", final=True)


class _Stage:
    """Stage handle returned by :meth:`Progress.stage`; updates are thread-safe."""

    def __init__(self, owner, label, total=None, unit=None):
        self._owner = owner
        self.label = _ascii(label)
        self.unit = _ascii(unit) if unit is not None else None
        self.total = None if total is None else _count(total, "total")
        self.completed = 0
        self.status = None
        self._started = None
        self._last_render = -math.inf
        self._finished = False

    def __enter__(self):
        self._owner._start(self)
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.finish(status=_exit_status(exc_type))
        return False

    def _check_active(self):
        if self._started is None:
            raise RuntimeError("Enter a progress stage before updating it")

    def update(self, completed, total=None):
        """Set an absolute count and optionally the total discovered at runtime."""
        completed = _count(completed, "completed")
        total = None if total is None else _count(total, "total")
        with self._owner._lock:
            self._check_active()
            if self._finished:
                return
            if completed < self.completed:
                raise ValueError("completed must not decrease")
            self.completed = completed
            if total is not None:
                self.total = total
            if self._owner._active[-1] is self:
                self._owner._render(self, _clock())

    def set_total(self, total):
        """Set the real work total; ``None`` restores an unknown total."""
        total = None if total is None else _count(total, "total")
        with self._owner._lock:
            self._check_active()
            if self._finished:
                return
            self.total = total
            if self._owner._active[-1] is self:
                self._owner._render(self, _clock())

    def advance(self, count=1):
        """Add completed work without a read/update race between callbacks."""
        count = _count(count, "count")
        with self._owner._lock:
            self.update(self.completed + count)

    def token(self, phase, token):
        """Count one actual emitted token; phase/token contents are not inspected."""
        self.advance()

    def finish(self, status="completed"):
        """Stop this stage. Supports completed, failed, cancelled, or truncated."""
        self._owner._finish(self, status)


# ----------------------------------------------------------------------------
# CUANTIZACION FP8
# ----------------------------------------------------------------------------

AR_LINEAR = re.compile(r"model\.layers\.\d+\.(?:self_attn\.(?:q|k|v|o)_proj|mlp\.(?:gate|up|down)_proj)$")


def quantize_tensor(value):
    source = value.detach().float()
    limit = torch.finfo(torch.float8_e4m3fn).max
    scale = source.abs().amax().clamp_min(1e-12) / limit
    return (source / scale).clamp(-limit, limit).to(torch.float8_e4m3fn), scale.float().reshape(1)


class FP8Linear(nn.Module):
    """Per-tensor E4M3 weights and dynamic activations, BF16/FP16 output."""
    def __init__(self, linear, device):
        super().__init__()
        weight, scale = quantize_tensor(linear.weight)
        self.in_features, self.out_features = linear.in_features, linear.out_features
        self.register_buffer("weight", weight.to(device))
        self.register_buffer("weight_scale", scale.to(device))
        self.register_buffer("bias", linear.bias.detach().clone().to(device) if linear.bias is not None else None)

    def forward(self, value):
        if value.device.type != "cuda":
            raise RuntimeError("FP8 execution requires CUDA; restore_ar(model) before CPU/MPS use")
        if value.dtype not in (torch.bfloat16, torch.float16):
            raise ValueError("FP8 AR expects BF16/FP16 input")
        shape = value.shape
        rows = value.reshape(-1, self.in_features)
        # cuBLAS FP8 accepts aligned GEMM rows; one-token decode is padded here.
        count = rows.shape[0]
        padded = F.pad(rows, (0, 0, 0, (-count) % 16))
        activation, scale = quantize_tensor(padded)
        output = torch._scaled_mm(activation, self.weight.t(), scale_a=scale,
                                  scale_b=self.weight_scale, out_dtype=value.dtype,
                                  bias=self.bias, use_fast_accum=False)
        if isinstance(output, tuple):
            output = output[0]
        return output[:count].reshape(*shape[:-1], self.out_features)

    def dequantized_weight(self):
        """Diagnostic/reference helper; normal inference uses scaled_mm."""
        return self.weight.float() * self.weight_scale


def _replace(model, name, replacement):
    parent_name, child = name.rsplit(".", 1)
    setattr(model.get_submodule(parent_name), child, replacement)


def prepare_fp8_ar(model, device):
    """Quantize only AR projections/MLPs once, preserving CPU BF16 originals."""
    if model is None:
        raise ValueError("Load the MoT model before preparing FP8")
    device = torch.device(device)
    if getattr(model, "_yue2_fp8_originals", None):
        return quantization_status(model)
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("Experimental FP8 AR requires CUDA compute capability >=8.9; use quantization='none'")
    if torch.cuda.get_device_capability(device) < (8, 9):
        raise RuntimeError("Experimental FP8 AR requires CUDA compute capability >=8.9")
    selected = [(name, module) for name, module in model.named_modules() if AR_LINEAR.fullmatch(name)]
    if not selected or any(not isinstance(module, nn.Linear) for _, module in selected):
        raise ValueError("Expected unquantized YuE2 AR Linear layers")
    if any(module.weight.dtype != torch.bfloat16 for _, module in selected):
        raise ValueError("Experimental FP8 preparation requires the original BF16 AR weights")
    if any(module.in_features % 16 or module.out_features % 16 for _, module in selected):
        raise ValueError("FP8 matrix dimensions must be multiples of 16")
    originals = {}
    # A plain attribute dictionary is intentionally not an nn.ModuleDict:
    # model.to(cuda) must not move these reference weights back onto the GPU.
    object.__setattr__(model, "_yue2_fp8_originals", originals)
    try:
        for name, original in selected:
            replacement = FP8Linear(original, device)
            originals[name] = original.to("cpu")
            _replace(model, name, replacement)
    except BaseException:
        restore_ar(model)
        raise
    return quantization_status(model)


def restore_ar(model):
    """Restore exact original tensors before NAR prefill, save, or CPU use."""
    if model is None:
        return
    originals = getattr(model, "_yue2_fp8_originals", None)
    if not originals:
        return
    for name, original in originals.items():
        replacement = model.get_submodule(name)
        device = replacement.weight.device
        _replace(model, name, original.to(device))
    object.__setattr__(model, "_yue2_fp8_originals", {})


def quantization_status(model):
    originals = getattr(model, "_yue2_fp8_originals", {}) if model is not None else {}
    return {"mode": "fp8" if originals else "none", "active_ar_linears": len(originals),
            "weight_format": "float8_e4m3fn" if originals else None,
            "original_weights": "cpu_bfloat16" if originals else None,
            "quality_validation": "unvalidated", "performance_validation": "unvalidated"}


# ----------------------------------------------------------------------------
# TOKENIZADOR DE TEXTO (tiktoken, qwen.tiktoken)
# ----------------------------------------------------------------------------

class YuE2TextTokenizer:
    def __init__(self, merge_file):
        import tiktoken
        self.merge_file = Path(merge_file)
        ranks = {base64.b64decode(t): int(r) for t, r in
                 (line.split() for line in self.merge_file.read_bytes().splitlines() if line)}
        if len(ranks) != 151643:
            raise ValueError("Expected checkpoint-native qwen.tiktoken (151643 ordinary tokens)")
        specials = ["<|endoftext|>", "<|im_start|>", "<|im_end|>", "<R>", "<S>", "<X>", "<mask>", "<sep>"]
        specials += [f"<extra_{i}>" for i in range(200)]
        specials[204:206] = ["<abc>", "</abc>"]
        pattern = r"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}| ?[^\s\p{L}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+"
        self._enc = tiktoken.Encoding("YuE2", pat_str=pattern, mergeable_ranks=ranks,
                                     special_tokens={s: i + len(ranks) for i, s in enumerate(specials)})

    def encode(self, text):
        return self._enc.encode_ordinary(unicodedata.normalize("NFC", text))

    def decode(self, ids):
        return self._enc.decode([int(i) for i in ids if 0 <= i < self._enc.n_vocab], errors="replace")

    @classmethod
    def from_pretrained(cls, path, **kwargs):
        return cls(resolve_model(path, **kwargs) / "qwen.tiktoken")

    def save_pretrained(self, directory):
        import shutil
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / "qwen.tiktoken"
        if target.resolve() != self.merge_file.resolve():
            shutil.copyfile(self.merge_file, target)
        return (str(target),)


# ----------------------------------------------------------------------------
# MUESTREO AUTOREGRESIVO
# ----------------------------------------------------------------------------

def synchronize(device):
    device = torch.device(device)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elif device.type == "mps":
        torch.mps.synchronize()


def window_penalty(logits, recent_ids, penalty):
    if penalty == 1.0 or len(recent_ids) == 0:
        return logits
    recent = torch.as_tensor(recent_ids, dtype=torch.long, device=logits.device).reshape(1, -1)
    freq = torch.zeros_like(logits)
    freq.scatter_add_(-1, recent, torch.ones_like(recent, dtype=logits.dtype))
    alpha = penalty ** freq
    return torch.where(logits < 0, logits * alpha, logits / alpha)


def distribution(logits, sampling, history, step, phase, legacy_off=False):
    # vLLM's symbolic processor receives FP32 logits; historical off uses BF16.
    scores = logits.clone() if legacy_off else logits.float().clone()
    end = ABC_END if phase == "abc" else MUSIC_END
    allowed = torch.full_like(scores, float("-inf"))
    if phase == "abc":
        allowed[..., :EOD] = 0
    else:
        allowed[..., CODEC_OFFSET:CODEC_OFFSET + CODEC_SIZE] = 0
    allowed[..., end] = 0
    scores = scores + allowed
    if step < sampling.min_tokens:
        scores[..., end] = -torch.inf
    scores = window_penalty(scores, history[-sampling.penalty_window:], sampling.repetition_penalty)
    if sampling.temperature == 0:
        return scores
    if sampling.temperature != 1:
        scores = scores / sampling.temperature
    threshold = scores.topk(min(sampling.top_k, scores.shape[-1])).values[..., -1, None]
    scores = scores.masked_fill(scores < threshold, -torch.inf)
    if sampling.top_p < 1:
        values, indices = scores.sort(descending=True)
        probabilities = values.softmax(-1)
        removed = probabilities.cumsum(-1) - probabilities > sampling.top_p
        removed[..., :3 if legacy_off else 1] = False
        values = values.masked_fill(removed, -torch.inf)
        scores = values.scatter(-1, indices, values)
    return scores


@torch.inference_mode()
def generate_tokens(model, prefix, sampling, seed, phase, negative=None, cfg_scale=1.0,
                    legacy_off=False, cancelled=None, on_token=None, use_cuda_graph=True):
    device = next(model.parameters()).device
    dtype = next(model.parameters()).dtype
    if len(prefix) + sampling.max_tokens > CONTEXT:
        raise ValueError("Prefix + requested generation budget exceeds 24576; no implicit truncation")
    if cfg_scale != 1 and negative is None:
        raise ValueError("CFG requires a negative prefix")
    if negative is not None and len(negative) + sampling.max_tokens > CONTEXT:
        raise ValueError("Negative prefix + generation budget exceeds context")
    if cancelled is not None and cancelled():
        raise InterruptedError("Cancelled before prefill")
    # The two stages deliberately reset their request-local seed, matching the preset.
    rng_device = device if device.type in {"cpu", "cuda"} else torch.device("cpu")
    generator = torch.Generator(device=rng_device).manual_seed(seed)
    config = model.config

    def prefill(ids):
        cache = StaticKVCache(num_layers=config.num_hidden_layers, batch_size=1,
                              num_kv_heads=config.num_key_value_heads,
                              max_seq_len=len(ids) + sampling.max_tokens,
                              head_dim=config.head_dim, dtype=dtype, device=device)
        output = model(torch.tensor([ids], device=device), past_key_values=cache,
                       use_cache=True, logits_to_keep=1)
        return output.logits[:, -1, :], output.past_key_values

    graph = None
    positive_cache = negative_cache = None
    graph_enabled = use_cuda_graph and device.type == "cuda" and not getattr(model, "_yue2_fp8_originals", {})
    synchronize(device)
    start = time.perf_counter()
    try:
        if graph_enabled:
            graph = GraphAR(model, [prefix] if cfg_scale == 1 else [prefix, negative], sampling.max_tokens)
            logits = graph.prefill()
            conditional = logits[:1]
            unconditional = logits[1:] if cfg_scale != 1 else None
        else:
            conditional, positive_cache = prefill(prefix)
            unconditional = None
            if cfg_scale != 1.0:
                unconditional, negative_cache = prefill(negative)
        synchronize(device)
        prefill_seconds = time.perf_counter() - start
        history, first, eos = [], None, False
        end = ABC_END if phase == "abc" else MUSIC_END
        for step in range(sampling.max_tokens):
            if cancelled is not None and cancelled():
                raise InterruptedError(f"Cancelled during {phase}")
            # Preserve historical BF16 CFG subtraction/multiply/add before upcast.
            logits = conditional if cfg_scale == 1.0 else unconditional + cfg_scale * (conditional - unconditional)
            scores = distribution(logits, sampling, history, step, phase, legacy_off)
            if sampling.temperature == 0:
                next_id = scores.argmax(-1, keepdim=True)
            else:
                probabilities = scores.softmax(-1)
                if device.type == "mps":
                    next_id = torch.multinomial(probabilities.cpu(), 1, generator=generator).to(device)
                else:
                    next_id = torch.multinomial(probabilities, 1, generator=generator)
            token = int(next_id.item())
            if first is None:
                first = time.perf_counter() - start
            if on_token is not None:
                on_token(phase, token)
            if token == end:
                eos = True
                break
            history.append(token)
            if step + 1 < sampling.max_tokens:
                if graph is not None:
                    branch_logits = graph.step(next_id)
                    conditional = branch_logits[:1]
                    unconditional = branch_logits[1:] if cfg_scale != 1 else None
                else:
                    conditional = model(next_id, past_key_values=positive_cache, use_cache=True,
                                        logits_to_keep=1).logits[:, -1, :]
                    if negative_cache is not None:
                        unconditional = model(next_id, past_key_values=negative_cache, use_cache=True,
                                              logits_to_keep=1).logits[:, -1, :]
        synchronize(device)
        seconds = time.perf_counter() - start
        count = len(history) + int(eos)
        timing = {"seconds": seconds, "prefill_seconds": prefill_seconds,
                  "ttft_seconds": first, "output_tokens": count, "content_tokens": len(history),
                  "output_tps": count / seconds, "prefix_tokens": len(prefix),
                  "cfg_branches": 1 if cfg_scale == 1 else 2,
                  "execution": "cuda_graph" if graph is not None else "eager",
                  "attention": graph.attention_backend if graph is not None else "sdpa"}
        if use_cuda_graph and not graph_enabled:
            timing["graph_fallback_reason"] = "fp8_not_graph_validated" if getattr(model, "_yue2_fp8_originals", {}) else "non_cuda_device"
        return history, timing, not eos
    finally:
        if graph is not None:
            graph.close()
        positive_cache = negative_cache = None


# ----------------------------------------------------------------------------
# CAPTURA DE CUDA GRAPHS
# ----------------------------------------------------------------------------

class _PrefixCache:
    """A single branch view used only by the original eager HF prefill."""
    def __init__(self, keys, values, branch):
        self.key_cache = [value[branch:branch+1].transpose(1, 2) for value in keys]
        self.value_cache = [value[branch:branch+1].transpose(1, 2) for value in values]
        self.seen = 0

    def get_seq_length(self, layer_idx=0):
        return self.seen

    def update(self, key, value, layer_idx, cache_kwargs=None):
        end = self.seen + key.shape[2]
        if end > self.key_cache[layer_idx].shape[2]:
            raise ValueError("Prefix exceeds preallocated KV capacity")
        self.key_cache[layer_idx][:, :, self.seen:end].copy_(key)
        self.value_cache[layer_idx][:, :, self.seen:end].copy_(value)
        if layer_idx == len(self.key_cache) - 1:
            self.seen = end
        return self.key_cache[layer_idx][:, :, :end], self.value_cache[layer_idx][:, :, :end]


class GraphAR:
    """Fixed-capacity decode for batch one or a synchronized CFG branch pair.

    ``prefill()`` predicts the first token. At most ``max_tokens-1`` calls to
    ``step(token)`` predict the remaining tokens. Returned graph logits share
    output storage and remain valid until the next step. ``capture=False`` is
    an eager diagnostic path for CPU/tiny-model correctness checks.
    """
    def __init__(self, model, prefixes, max_tokens, *, capture=True, attention_backend="auto", fuse_projections=False):
        if model.training:
            raise ValueError("GraphAR requires model.eval()")
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, Integral) or max_tokens < 1:
            raise ValueError("max_tokens must be a positive integer")
        prefixes = [list(prefix) for prefix in prefixes]
        if len(prefixes) not in {1, 2}:
            raise ValueError("GraphAR supports one request or exactly two CFG branches")
        config = model.config
        for prefix in prefixes:
            if not prefix or any(isinstance(token, bool) or not isinstance(token, Integral) or
                                 not 0 <= token < config.vocab_size for token in prefix):
                raise ValueError("Prefixes require valid integer token IDs")
            if len(prefix) + max_tokens > config.max_position_embeddings:
                raise ValueError("Prefix plus generation budget exceeds model context; no length was shortened")
        weight = model.model.embed_tokens.weight
        self.model, self.device, self.dtype = model, weight.device, weight.dtype
        linears = [module for layer in model.model.layers for module in
                   (layer.self_attn.q_proj, layer.self_attn.k_proj, layer.self_attn.v_proj,
                    layer.self_attn.o_proj, layer.mlp.gate_proj, layer.mlp.up_proj, layer.mlp.down_proj)]
        if getattr(model, "_yue2_fp8_originals", None) or any(
                not isinstance(module, torch.nn.Linear) or module.weight.dtype != self.dtype for module in linears):
            raise ValueError("GraphAR only supports unquantized standard AR Linear layers; use eager for FP8")
        if capture and self.device.type != "cuda":
            raise ValueError("CUDA graphs require a CUDA model; capture=False is for diagnostics")
        self.prefixes = [[int(token) for token in prefix] for prefix in prefixes]
        self.max_tokens, self.branches = int(max_tokens), len(prefixes)
        self.capacity = max(map(len, prefixes)) + self.max_tokens
        self.capture, self.graph, self.output = capture, None, None
        if attention_backend not in {"auto", "flash", "cudnn", "sdpa"}:
            raise ValueError("attention_backend must be auto, flash, cudnn, or sdpa")
        fused = self.device.type == "cuda" and self.dtype in {torch.bfloat16, torch.float16} and config.head_dim % 8 == 0
        flash = fused and config.head_dim <= 256 and hasattr(torch.ops.aten, "_flash_attention_forward") and (
            "seqused_k" in str(torch.ops.aten._flash_attention_forward.default._schema))
        # Torch 2.10 is pinned by the package. Its native variable-length FA
        # accepts GPU effective lengths; the public masked SDPA can select a
        # much slower math kernel. Keep a cuDNN/public-SDPA fallback explicit.
        if attention_backend == "auto":
            attention_backend = "flash" if flash else "cudnn" if fused and torch.backends.cudnn.is_available() else "sdpa"
        if attention_backend == "flash" and not flash:
            raise ValueError("Pinned PyTorch variable-length CUDA FlashAttention is unavailable")
        if attention_backend == "cudnn" and not (fused and torch.backends.cudnn.is_available()):
            raise ValueError("cuDNN attention requires a supported CUDA dtype/head dimension")
        self.attention_backend = attention_backend
        self.ready, self.closed, self.steps = False, False, 0
        # Sequence-major layout makes the packed FA view contiguous without
        # copying all cached keys at each decode step.
        shape = (self.branches, self.capacity, config.num_key_value_heads, config.head_dim)
        self.keys = [torch.zeros(shape, device=self.device, dtype=self.dtype) for _ in model.model.layers]
        self.values = [torch.zeros(shape, device=self.device, dtype=self.dtype) for _ in model.model.layers]
        self.positions = torch.tensor([len(prefix) for prefix in prefixes], dtype=torch.long, device=self.device)
        self.initial_positions = self.positions.clone()
        self.key_positions = torch.arange(self.capacity, dtype=torch.long, device=self.device)
        self.cu_q = torch.arange(self.branches + 1, dtype=torch.int32, device=self.device)
        self.cu_k = self.cu_q * self.capacity
        self.tokens = torch.tensor([[prefix[-1]] for prefix in prefixes], dtype=torch.long, device=self.device)
        self.kv_bytes = 2 * len(self.keys) * self.keys[0].numel() * self.keys[0].element_size()
        self.fused_weights = []
        if fuse_projections:
            if any(module.bias is not None for module in linears):
                raise ValueError("Fused projections require the checkpoint's bias-free AR linears")
            with torch.no_grad():
                for layer in model.model.layers:
                    self.fused_weights.append((torch.cat([layer.self_attn.q_proj.weight, layer.self_attn.k_proj.weight,
                                                         layer.self_attn.v_proj.weight], dim=0),
                                               torch.cat([layer.mlp.gate_proj.weight, layer.mlp.up_proj.weight], dim=0)))
        self.fused_weight_bytes = sum(value.numel() * value.element_size() for pair in self.fused_weights for value in pair)

    @torch.inference_mode()
    def _decode(self):
        backbone = self.model.model
        cos, sin = backbone.rotary_emb(self.positions[:, None])
        x = backbone.embed_tokens(self.tokens)
        visible = None
        if self.attention_backend != "flash":
            visible = (self.key_positions[None, :] <= self.positions[:, None])[:, None, None, :]
        used_lengths = (self.positions + 1).to(torch.int32)
        config = self.model.config
        slots = self.positions[:, None, None, None].expand(
            self.branches, 1, config.num_key_value_heads, config.head_dim)
        for index, (layer, keys, values) in enumerate(zip(backbone.layers, self.keys, self.values)):
            normalized = layer.input_layernorm(x)
            if self.fused_weights:
                sizes = (config.num_attention_heads * config.head_dim,
                         config.num_key_value_heads * config.head_dim, config.num_key_value_heads * config.head_dim)
                q, k, v = F.linear(normalized, self.fused_weights[index][0]).split(sizes, dim=-1)
                q = layer.self_attn.q_norm(q.view(self.branches, 1, config.num_attention_heads, config.head_dim))
                k = layer.self_attn.k_norm(k.view(self.branches, 1, config.num_key_value_heads, config.head_dim))
                v = v.view(self.branches, 1, config.num_key_value_heads, config.head_dim)
                q = _apply_rotary(q, cos.unsqueeze(2), sin.unsqueeze(2))
                k = _apply_rotary(k, cos.unsqueeze(2), sin.unsqueeze(2))
            else:
                q, k, v = layer.self_attn.project_qkv(normalized, cos, sin)
            keys.scatter_(1, slots, k)
            values.scatter_(1, slots, v)
            # All allocated slots are present, but only each branch's completed
            # prefix and the current token are visible. Future slots never leak.
            if self.attention_backend == "flash":
                # seqused_k is respected by the 3D packed/varlen entrypoint.
                # The 4D fixed-batch entrypoint ignores it in torch 2.10, so do
                # not replace this call with an apparently equivalent 4D call.
                h = torch.ops.aten._flash_attention_forward(
                    q[:, 0], keys.view(-1, config.num_key_value_heads, config.head_dim),
                    values.view(-1, config.num_key_value_heads, config.head_dim),
                    self.cu_q, self.cu_k, 1, self.capacity, 0.0, False, False,
                    seqused_k=used_lengths)[0][:, None]
            elif self.attention_backend == "cudnn":
                from torch.nn.attention import SDPBackend, sdpa_kernel
                with sdpa_kernel(SDPBackend.CUDNN_ATTENTION):
                    h = F.scaled_dot_product_attention(q.transpose(1, 2), keys.transpose(1, 2), values.transpose(1, 2),
                            attn_mask=visible, is_causal=False,
                            enable_gqa=config.num_attention_heads != config.num_key_value_heads).transpose(1, 2)
            else:
                h = F.scaled_dot_product_attention(q.transpose(1, 2), keys.transpose(1, 2), values.transpose(1, 2),
                            attn_mask=visible, is_causal=False,
                            enable_gqa=config.num_attention_heads != config.num_key_value_heads).transpose(1, 2)
            x = x + layer.self_attn.o_proj(h.reshape(self.branches, 1, -1))
            normalized = layer.post_attention_layernorm(x)
            if self.fused_weights:
                gate, up = F.linear(normalized, self.fused_weights[index][1]).chunk(2, dim=-1)
                x = x + layer.mlp.down_proj(F.silu(gate) * up)
            else:
                x = x + layer.mlp(normalized)
        output = self.model.lm_head(backbone.norm(x))[:, 0]
        self.positions.add_(1)
        return output

    @torch.inference_mode()
    def _capture(self):
        with torch.cuda.device(self.device):
            current = torch.cuda.current_stream(self.device)
            warmup = torch.cuda.Stream(device=self.device)
            warmup.wait_stream(current)
            with torch.cuda.stream(warmup):
                for _ in range(3):
                    self.positions.copy_(self.initial_positions)
                    self._decode()
                self.positions.copy_(self.initial_positions)
            current.wait_stream(warmup)
            torch.cuda.synchronize(self.device)
            self.graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(self.graph):
                self.output = self._decode()
            # Warmup/capture wrote one future slot. The first real step
            # overwrites that slot in every layer before making it visible.
            self.positions.copy_(self.initial_positions)

    @torch.inference_mode()
    def prefill(self):
        if self.closed or self.ready:
            raise RuntimeError("prefill must be called exactly once on an open GraphAR")
        logits = []
        for branch, prefix in enumerate(self.prefixes):
            cache = _PrefixCache(self.keys, self.values, branch)
            result = self.model(torch.tensor([prefix], dtype=torch.long, device=self.device),
                                past_key_values=cache, use_cache=True, logits_to_keep=1)
            logits.append(result.logits[:, -1])
        result = torch.cat(logits, dim=0)
        if self.capture and self.max_tokens > 1:
            self._capture()
        self.ready = True
        return result

    @torch.inference_mode()
    def step(self, token):
        if self.closed or not self.ready:
            raise RuntimeError("Call prefill before step and do not use a closed GraphAR")
        if self.steps >= self.max_tokens - 1:
            raise ValueError("Requested generation budget is exhausted")
        if isinstance(token, Integral) and not isinstance(token, bool):
            if not 0 <= int(token) < self.model.config.vocab_size:
                raise ValueError("Token is outside the model vocabulary")
            self.tokens.fill_(int(token))
        elif isinstance(token, torch.Tensor) and token.numel() == 1 and token.dtype in {torch.int32, torch.int64}:
            # Sampling already produced/validated this scalar. Copying the
            # tensor avoids a second GPU-to-CPU synchronization in the caller.
            if token.device.type == "cpu" and not 0 <= token.item() < self.model.config.vocab_size:
                raise ValueError("Token is outside the model vocabulary")
            self.tokens.copy_(token.reshape(1, 1).expand(self.branches, 1))
        else:
            raise ValueError("step needs one shared integer token, including for CFG")
        if self.graph is not None:
            self.graph.replay()
            result = self.output
        else:
            result = self._decode()
        self.steps += 1
        return result

    def close(self):
        self.graph = self.output = None
        self.keys.clear()
        self.values.clear()
        self.fused_weights.clear()
        self.tokens = self.positions = self.initial_positions = self.key_positions = None
        self.cu_q = self.cu_k = None
        self.closed = True


# ----------------------------------------------------------------------------
# MODELO VAE (latentes -> audio)
# ----------------------------------------------------------------------------

def checkpoint(function, *args, **kwargs):
    from torch.utils.checkpoint import checkpoint as torch_checkpoint
    kwargs.setdefault("use_reentrant", False)
    return torch_checkpoint(function, *args, **kwargs)


def WNConv1d(*args, **kwargs):
    return weight_norm(nn.Conv1d(*args, **kwargs))


def WNConvTranspose1d(*args, **kwargs):
    return weight_norm(nn.ConvTranspose1d(*args, **kwargs))


def snake_beta(x, alpha, beta):
    return x + (1.0 / (beta + 0.000000001)) * torch.pow(
        torch.sin(x * alpha), 2
    )


class SnakeBeta(nn.Module):
    def __init__(
        self,
        in_features,
        alpha=1.0,
        alpha_trainable=True,
        alpha_logscale=True,
    ):
        super().__init__()
        self.in_features = in_features
        self.alpha_logscale = alpha_logscale
        if self.alpha_logscale:
            self.alpha = nn.Parameter(torch.zeros(in_features) * alpha)
            self.beta = nn.Parameter(torch.zeros(in_features) * alpha)
        else:
            self.alpha = nn.Parameter(torch.ones(in_features) * alpha)
            self.beta = nn.Parameter(torch.ones(in_features) * alpha)
        self.alpha.requires_grad = alpha_trainable
        self.beta.requires_grad = alpha_trainable
        self.no_div_by_zero = 0.000000001

    def forward(self, x):
        alpha = self.alpha.unsqueeze(0).unsqueeze(-1)
        beta = self.beta.unsqueeze(0).unsqueeze(-1)
        if self.alpha_logscale:
            alpha = torch.exp(alpha)
            beta = torch.exp(beta)
        return snake_beta(x, alpha, beta)


def get_activation(
    activation: Literal["elu", "snake", "none"], channels=None
) -> nn.Module:
    if activation == "elu":
        return nn.ELU()
    if activation == "snake":
        return SnakeBeta(channels)
    if activation == "none":
        return nn.Identity()
    raise ValueError(f"Unknown activation {activation}")


class ResidualUnit(nn.Module):
    def __init__(self, in_channels, out_channels, dilation, act_type):
        super().__init__()
        self.dilation = dilation
        padding = (dilation * (7 - 1)) // 2
        self.layers = nn.Sequential(
            get_activation(act_type, channels=out_channels),
            WNConv1d(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_size=7,
                dilation=dilation,
                padding=padding,
            ),
            get_activation(act_type, channels=out_channels),
            WNConv1d(
                in_channels=out_channels,
                out_channels=out_channels,
                kernel_size=1,
            ),
        )

    def forward(self, x):
        residual = x
        if self.training:
            x = checkpoint(self.layers, x)
        else:
            x = self.layers(x)
        return x + residual


class EncoderBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride, act_type):
        super().__init__()
        self.layers = nn.Sequential(
            ResidualUnit(in_channels, in_channels, 1, act_type),
            ResidualUnit(in_channels, in_channels, 3, act_type),
            ResidualUnit(in_channels, in_channels, 9, act_type),
            get_activation(act_type, channels=in_channels),
            WNConv1d(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_size=2 * stride,
                stride=stride,
                padding=math.ceil(stride / 2),
            ),
        )

    def forward(self, x):
        return self.layers(x)


class DecoderBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride, act_type):
        super().__init__()
        upsample_layer = WNConvTranspose1d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=2 * stride,
            stride=stride,
            padding=math.ceil(stride / 2),
        )
        self.layers = nn.Sequential(
            get_activation(act_type, channels=in_channels),
            upsample_layer,
            ResidualUnit(out_channels, out_channels, 1, act_type),
            ResidualUnit(out_channels, out_channels, 3, act_type),
            ResidualUnit(out_channels, out_channels, 9, act_type),
        )

    def forward(self, x):
        return self.layers(x)


class OobleckEncoder(nn.Module):
    def __init__(
        self,
        in_channels=2,
        channels=128,
        latent_dim=32,
        c_mults=(1, 2, 4, 8),
        strides=(2, 4, 8, 8),
        use_snake=False,
        antialias_activation=False,
    ):
        super().__init__()
        if antialias_activation:
            raise ValueError("The released encoder does not use antialias_activation")
        self.in_channels = in_channels
        c_mults = [1] + list(c_mults)
        self.depth = len(c_mults)
        layers = [
            WNConv1d(
                in_channels=in_channels,
                out_channels=c_mults[0] * channels,
                kernel_size=7,
                padding=3,
            )
        ]
        act_type = "snake" if use_snake else "elu"
        for i in range(self.depth - 1):
            layers.append(
                EncoderBlock(
                    in_channels=c_mults[i] * channels,
                    out_channels=c_mults[i + 1] * channels,
                    stride=strides[i],
                    act_type=act_type,
                )
            )
        layers.extend(
            [
                get_activation(act_type, channels=c_mults[-1] * channels),
                WNConv1d(
                    in_channels=c_mults[-1] * channels,
                    out_channels=latent_dim,
                    kernel_size=3,
                    padding=1,
                ),
            ]
        )
        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


class OobleckDecoder(nn.Module):
    def __init__(
        self,
        out_channels=2,
        channels=128,
        latent_dim=32,
        c_mults=(1, 2, 4, 8),
        strides=(2, 4, 8, 8),
        use_snake=False,
        snake_type="vanilla",
        antialias_activation=False,
        use_nearest_upsample=False,
        use_filter=False,
        final_tanh=True,
    ):
        super().__init__()
        if antialias_activation or use_nearest_upsample or use_filter:
            raise ValueError("Unsupported option for the released decoder")
        if use_snake and snake_type != "vanilla":
            raise ValueError("The released decoder uses vanilla SnakeBeta")
        self.out_channels = out_channels
        c_mults = [1] + list(c_mults)
        self.depth = len(c_mults)
        layers = [
            WNConv1d(
                in_channels=latent_dim,
                out_channels=c_mults[-1] * channels,
                kernel_size=7,
                padding=3,
            )
        ]
        act_type = "snake" if use_snake else "elu"
        for i in range(self.depth - 1, 0, -1):
            layers.append(
                DecoderBlock(
                    in_channels=c_mults[i] * channels,
                    out_channels=c_mults[i - 1] * channels,
                    stride=strides[i - 1],
                    act_type=act_type,
                )
            )
        layers.extend(
            [
                get_activation(act_type, channels=c_mults[0] * channels),
                WNConv1d(
                    in_channels=c_mults[0] * channels,
                    out_channels=out_channels,
                    kernel_size=7,
                    padding=3,
                    bias=False,
                ),
                nn.Tanh() if final_tanh else nn.Identity(),
            ]
        )
        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


class YuE2VAEConfig(PretrainedConfig):
    """Configuration shared by YuE2-Vae and YuE2-Vae-legacy.

    Use ``standard`` for listening and ``legacy`` for the paper metric baseline.
    """

    model_type = "yue2_vae"

    _hf_fields = frozenset({
        "model_type", "architectures", "auto_map", "transformers_version",
        "dtype", "torch_dtype", "return_dict", "output_hidden_states",
        "output_attentions", "use_cache", "tie_word_embeddings", "torchscript",
        "is_decoder", "is_encoder_decoder", "add_cross_attention",
        "bos_token_id", "eos_token_id", "pad_token_id", "decoder_start_token_id",
        "attn_implementation",
    })

    def to_dict(self):
        return {key: value for key, value in super().to_dict().items()
                if key in self._hf_fields or key in self._inference_fields}

    _inference_fields = frozenset(['encoder_config', 'decoder_config', 'sample_rate', 'latent_dim', 'downsampling_ratio', 'audio_channels', 'release_variant', 'decode_core_frames', 'decode_halo_frames'])

    def __init__(self, encoder_config=None, decoder_config=None,
                 sample_rate=48000, latent_dim=64, downsampling_ratio=1920,
                 audio_channels=2, release_variant="standard",
                 decode_core_frames=1024, decode_halo_frames=16,
                 **kwargs):
        kwargs = {key: value for key, value in kwargs.items() if key in self._hf_fields}
        kwargs.setdefault("architectures", ["YuE2VAE"])
        kwargs.setdefault("auto_map", {
            "AutoConfig": "modeling_vae.YuE2VAEConfig",
            "AutoModel": "modeling_vae.YuE2VAE",
        })
        super().__init__(**kwargs)
        self.encoder_config = encoder_config or dict(
            in_channels=2, channels=64, c_mults=[1, 2, 4, 8, 16, 32],
            strides=[2, 2, 4, 4, 5, 6], latent_dim=128, use_snake=True)
        self.decoder_config = decoder_config or dict(
            out_channels=2, channels=64, c_mults=[1, 2, 4, 8, 16, 32],
            strides=[2, 2, 4, 4, 5, 6], latent_dim=64, use_snake=True,
            snake_type="vanilla", use_filter=False, final_tanh=False)
        encoder_fields = {"in_channels", "channels", "latent_dim", "c_mults", "strides",
                          "use_snake", "antialias_activation"}
        decoder_fields = {"out_channels", "channels", "latent_dim", "c_mults", "strides",
                          "use_snake", "snake_type", "antialias_activation",
                          "use_nearest_upsample", "use_filter", "final_tanh"}
        self.encoder_config = {key: value for key, value in self.encoder_config.items() if key in encoder_fields}
        self.decoder_config = {key: value for key, value in self.decoder_config.items() if key in decoder_fields}
        self.sample_rate = int(sample_rate)
        self.latent_dim = int(latent_dim)
        self.downsampling_ratio = int(downsampling_ratio)
        self.audio_channels = int(audio_channels)
        self.release_variant = release_variant
        self.decode_core_frames = int(decode_core_frames)
        self.decode_halo_frames = int(decode_halo_frames)
        if self.decode_core_frames < 1 or self.decode_halo_frames < 0:
            raise ValueError("Invalid VAE core/halo configuration")
        if math.prod(self.decoder_config["strides"]) != self.downsampling_ratio:
            raise ValueError("Decoder strides do not match downsampling_ratio")
        if self.decoder_config["latent_dim"] != self.latent_dim:
            raise ValueError("Decoder input channels do not match latent_dim")


def _dependency_interval(module, low, high):
    """Inclusive input support of an output interval; no waveform blending."""
    if isinstance(module, (nn.Sequential, OobleckDecoder, DecoderBlock)):
        layers = module if isinstance(module, nn.Sequential) else module.layers
        for child in reversed(list(layers)):
            low, high = _dependency_interval(child, low, high)
        return low, high
    if isinstance(module, ResidualUnit):
        a, b = _dependency_interval(module.layers, low, high)
        return min(a, low), max(b, high)
    if isinstance(module, nn.ConvTranspose1d):
        s, p, d, k = (module.stride[0], module.padding[0],
                      module.dilation[0], module.kernel_size[0])
        return -(-(low + p - d * (k - 1)) // s), (high + p) // s
    if isinstance(module, nn.Conv1d):
        s, p, d, k = (module.stride[0], module.padding[0],
                      module.dilation[0], module.kernel_size[0])
        return low * s - p, high * s - p + d * (k - 1)
    if isinstance(module, (SnakeBeta, nn.ELU, nn.Identity, nn.Tanh)):
        return low, high
    raise TypeError(f"No audited support rule for {type(module).__name__}")


def _output_length(module, length):
    if isinstance(module, (nn.Sequential, OobleckDecoder, DecoderBlock)):
        layers = module if isinstance(module, nn.Sequential) else module.layers
        for child in layers:
            length = _output_length(child, length)
        return length
    if isinstance(module, nn.ConvTranspose1d):
        return ((length - 1) * module.stride[0] - 2 * module.padding[0]
                + module.dilation[0] * (module.kernel_size[0] - 1)
                + module.output_padding[0] + 1)
    if isinstance(module, nn.Conv1d):
        return ((length + 2 * module.padding[0]
                 - module.dilation[0] * (module.kernel_size[0] - 1) - 1)
                // module.stride[0] + 1)
    if isinstance(module, (ResidualUnit, SnakeBeta, nn.ELU, nn.Identity, nn.Tanh)):
        return length
    raise TypeError(f"No audited length rule for {type(module).__name__}")


class YuE2VAE(PreTrainedModel):
    """Strict EMA model; only the decoder needs to reside on an accelerator.

    ``decode_tiled`` preserves finite receptive-field context and writes cropped
    cores to CPU. The mathematical waveform is the full decoder's waveform;
    convolution kernel choices may cause small FP32 rounding differences.
    """

    config_class = YuE2VAEConfig
    base_model_prefix = ""
    main_input_name = "audio"

    def __init__(self, config, decoder_only=False):
        super().__init__(config)
        self.decoder_only = bool(decoder_only)
        if not self.decoder_only:
            self.encoder = OobleckEncoder(**config.encoder_config)
        self.decoder = OobleckDecoder(**config.decoder_config)
        self.eval().requires_grad_(False)

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *model_args,
                        config=None, decoder_only=False, device="cpu",
                        torch_dtype=None, dtype=None, revision=None, token=None,
                        cache_dir=None, local_files_only=False,
                        force_download=False, subfolder="", **kwargs):
        """Load a local export or Hub repository, selecting decoder tensors.

        Complete exports use unprefixed EMA keys. ``decoder_only=True`` avoids
        constructing the encoder or loading encoder tensors into RAM/GPU.
        """
        from safetensors import safe_open
        requested_dtype = dtype if dtype is not None else torch_dtype
        if requested_dtype not in (None, "auto", "float32", torch.float32):
            raise ValueError("The validated VAE requires FP32; quantize the LM separately")
        device_map = kwargs.pop("device_map", None)
        if device_map is not None:
            if device_map == "auto":
                device = "cuda" if torch.cuda.is_available() else "cpu"
            elif isinstance(device_map, str):
                device = device_map
            elif isinstance(device_map, dict) and set(device_map) == {""}:
                device = device_map[""]
            else:
                raise ValueError("Use decoder_only=True and a single device for the VAE")
        for name in ("trust_remote_code", "low_cpu_mem_usage", "_from_auto",
                     "_from_pipeline", "_commit_hash", "adapter_kwargs",
                     "_fast_init", "weights_only", "use_safetensors"):
            kwargs.pop(name, None)
        output_loading_info = kwargs.pop("output_loading_info", False)
        if kwargs or model_args:
            raise TypeError(f"Unsupported VAE loading options: {sorted(kwargs)}")
        path = Path(pretrained_model_name_or_path).expanduser()
        if not path.is_dir():
            from huggingface_hub import snapshot_download
            path = Path(snapshot_download(
                str(pretrained_model_name_or_path), revision=revision, token=token,
                cache_dir=cache_dir, local_files_only=local_files_only,
                force_download=force_download,
                allow_patterns=[f"{subfolder + '/' if subfolder else ''}{pattern}"
                                for pattern in ("config.json", "*.safetensors",
                                                "*.safetensors.index.json")]))
        path = path / subfolder
        if config is None:
            config = YuE2VAEConfig.from_pretrained(path, local_files_only=True)
        model = cls(config, decoder_only=decoder_only)
        index = path / "model.safetensors.index.json"
        if index.exists():
            mapping = json.loads(index.read_text())["weight_map"]
            files = sorted({name for key, name in mapping.items()
                            if not decoder_only or key.startswith("decoder.")})
        else:
            files = ["model.safetensors"]
        state = {}
        for name in files:
            with safe_open(path / name, framework="pt", device="cpu") as handle:
                for key in handle.keys():
                    if not decoder_only or key.startswith("decoder."):
                        if key in state:
                            raise ValueError(f"Duplicate VAE tensor: {key}")
                        state[key] = handle.get_tensor(key)
        expected = set(model.state_dict())
        if set(state) != expected:
            raise ValueError(f"VAE tensor mismatch: missing={sorted(expected-set(state))}, "
                             f"unexpected={sorted(set(state)-expected)}")
        if any(value.dtype != torch.float32 for value in state.values()):
            raise ValueError("VAE export contains tensors that are not FP32")
        model.load_state_dict(state, strict=True)
        model.to(device=device, dtype=torch.float32).eval().requires_grad_(False)
        if output_loading_info:
            return model, dict(missing_keys=[], unexpected_keys=[], mismatched_keys=[],
                               error_msgs=[])
        return model

    def save_pretrained(self, save_directory, *args, **kwargs):
        if self.decoder_only:
            raise ValueError("Reload decoder_only=False to save a complete VAE repository")
        if kwargs.get("safe_serialization", True) is False:
            raise ValueError("YuE2 VAE release exports require safetensors")
        return super().save_pretrained(save_directory, *args, **kwargs)

    @property
    def decoder_device(self):
        return next(self.decoder.parameters()).device

    def _latent(self, latent):
        latent = torch.as_tensor(latent)
        if (latent.ndim != 3 or latent.shape[1] != self.config.latent_dim
                or latent.shape[0] < 1 or latent.shape[-1] < 1):
            raise ValueError(f"Expected nonempty [B,{self.config.latent_dim},T] latents")
        if not torch.isfinite(latent).all():
            raise ValueError("VAE latents contain non-finite values")
        if next(self.decoder.parameters()).dtype != torch.float32:
            raise ValueError("VAE decoder weights must remain FP32")
        return latent

    @torch.inference_mode()
    def encode(self, audio, sample=False, generator=None, return_info=False):
        """Encode FP32 stereo audio; posterior mean by default.

        Set ``sample=True`` with a per-request ``torch.Generator`` to reproduce
        stochastic posterior sampling. This audio VAE is not the unreleased
        semantic audio tokenizer semantic tokenizer.
        """
        if self.decoder_only:
            raise RuntimeError("Encoder not loaded; reload with decoder_only=False")
        audio = torch.as_tensor(audio)
        if (audio.ndim != 3 or audio.shape[1] != self.config.audio_channels
                or audio.shape[-1] < self.config.downsampling_ratio):
            raise ValueError("Expected audio [B,2,S] with at least one latent frame")
        if not torch.isfinite(audio).all():
            raise ValueError("Audio contains non-finite values")
        device = next(self.encoder.parameters()).device
        pre = self.encoder(audio.to(device=device, dtype=torch.float32))
        mean, scale = pre.chunk(2, dim=1)
        stdev = torch.nn.functional.softplus(scale) + 1e-4
        if sample:
            noise = torch.randn(mean.shape, dtype=mean.dtype,
                                device=device, generator=generator)
            latent = noise * stdev + mean
        else:
            latent = mean
        if return_info:
            return latent, dict(mean=mean, scale=scale, stdev=stdev)
        return latent

    @torch.inference_mode()
    def decode(self, latent):
        """Full waveform, FP32 [B,2,1920*T-64], without clipping."""
        latent = self._latent(latent)
        with torch.autocast(device_type=self.decoder_device.type, enabled=False):
            return self.decoder(latent.to(device=self.decoder_device, dtype=torch.float32))

    def natural_output_length(self, frames):
        if int(frames) < 1:
            raise ValueError("frames must be positive")
        return _output_length(self.decoder, int(frames))

    def required_halo(self, core_frames=None):
        core_frames = self.config.decode_core_frames if core_frames is None else core_frames
        ratio = self.config.downsampling_ratio
        low, high = _dependency_interval(self.decoder, 0, core_frames * ratio - 1)
        return max(0, -low, high - core_frames + 1)

    @torch.inference_mode()
    def decode_tiled(self, latent, core_frames=None, halo_frames=None,
                     output_device="cpu",
                     on_progress: Callable[[int, int], None] | None = None):
        """Decode bounded tiles, retaining exact cores with natural end length.

        Each crop has enough left/right context for every dependency. There is
        no crossfade or boundary smoothing, and no zero padding of final audio.
        CPU output prevents an entire song from accumulating on the GPU.
        ``on_progress(completed, total)`` runs after each existing crop copy;
        no extra synchronization is added. With a CUDA output device, queued
        work may still be executing. Callback exceptions propagate.
        """
        latent = self._latent(latent)
        core_frames = self.config.decode_core_frames if core_frames is None else core_frames
        halo_frames = self.config.decode_halo_frames if halo_frames is None else halo_frames
        if not isinstance(core_frames, int) or core_frames < 1:
            raise ValueError("core_frames must be a positive integer")
        required = self.required_halo(core_frames)
        if not isinstance(halo_frames, int) or halo_frames < required:
            raise ValueError(f"halo_frames must be at least {required} for this decoder")
        frames = latent.shape[-1]
        ratio = self.config.downsampling_ratio
        total = self.natural_output_length(frames)
        audio = torch.empty((latent.shape[0], self.config.audio_channels, total),
                            dtype=torch.float32, device=output_device)
        tiles = (frames + core_frames - 1) // core_frames
        for tile_index, start in enumerate(range(0, frames, core_frames)):
            end = min(frames, start + core_frames)
            left = max(0, start - halo_frames)
            right = min(frames, end + halo_frames)
            tile = self.decode(latent[..., left:right])
            out_start, out_end = start * ratio, min(end * ratio, total)
            crop_start = (start - left) * ratio
            crop = tile[..., crop_start:crop_start + out_end - out_start]
            if crop.shape[-1] != out_end - out_start:
                raise RuntimeError("VAE tile did not cover its requested output core")
            audio[..., out_start:out_end].copy_(crop.to(output_device))
            del tile, crop
            if on_progress is not None:
                on_progress(tile_index + 1, tiles)
        return audio

    def decode_audio(self, latent, chunked=True, **kwargs):
        return self.decode_tiled(latent, **kwargs) if chunked else self.decode(latent)

    def forward(self, audio, sample=False, generator=None):
        return self.decode(self.encode(audio, sample=sample, generator=generator))


YuE2VAEConfig.register_for_auto_class("AutoConfig")
YuE2VAE.register_for_auto_class("AutoModel")


# ----------------------------------------------------------------------------
# BACKBONE AR-NAR (Mixture-of-Transformers)
# ----------------------------------------------------------------------------

def sdpa(query, key, value, *, attn_mask=None, is_causal=False):
    """Use native grouped-query attention, including a portable MPS fallback."""
    grouped = query.shape[1] != key.shape[1]
    if grouped and query.device.type == "mps":
        # PyTorch's MPS attention does not implement enable_gqa on every release.
        groups = query.shape[1] // key.shape[1]
        key = key.repeat_interleave(groups, dim=1)
        value = value.repeat_interleave(groups, dim=1)
        grouped = False
    return F.scaled_dot_product_attention(
        query, key, value, attn_mask=attn_mask, is_causal=is_causal,
        enable_gqa=grouped,
    )


def _causal_mask(attention_mask, cache_position, key_length, batch_size):
    """Physical cache slots are causal; RoPE positions may exclude padding."""
    device = cache_position.device
    visible = torch.arange(key_length, device=device)[None, :] <= cache_position[:, None]
    visible = visible[None, None].expand(batch_size, 1, -1, -1)
    if attention_mask is None:
        return visible
    mask = attention_mask.to(device=device)
    if mask.ndim == 2:
        if mask.shape[0] != batch_size or mask.shape[1] > key_length:
            raise ValueError("attention_mask must cover the batch and used cache slots")
        # Static cache has unused capacity after the supplied 2D padding mask.
        if mask.shape[1] < key_length:
            mask = F.pad(mask, (0, key_length - mask.shape[1]), value=0)
        return visible & mask[:, None, None, :].bool()
    if mask.ndim != 4 or mask.shape[-2:] != visible.shape[-2:]:
        raise ValueError("Expected a 2D padding mask or a matching 4D attention mask")
    if mask.dtype == torch.bool:
        return visible & mask
    return mask.masked_fill(~visible, float("-inf"))

# ══════════════════════════════════════════════════════════════════════════════
# Config
# ══════════════════════════════════════════════════════════════════════════════


class YuE2Config(PretrainedConfig):
    model_type = "yue2"

    _hf_fields = frozenset({
        "model_type", "architectures", "auto_map", "transformers_version",
        "dtype", "torch_dtype", "return_dict", "output_hidden_states",
        "output_attentions", "use_cache", "tie_word_embeddings", "torchscript",
        "is_decoder", "is_encoder_decoder", "add_cross_attention",
        "bos_token_id", "eos_token_id", "pad_token_id", "decoder_start_token_id",
        "attn_implementation",
    })

    def to_dict(self):
        return {key: value for key, value in super().to_dict().items()
                if key in self._hf_fields or key in self._inference_fields}

    _inference_fields = frozenset(['hidden_size', 'num_hidden_layers', 'num_attention_heads', 'num_key_value_heads', 'head_dim', 'intermediate_size', 'vocab_size', 'rms_norm_eps', 'rope_theta', 'max_position_embeddings', 'tie_word_embeddings', 'latent_type', 'latent_dim', 'max_latent_frames', 'timestep_shift'])

    def __init__(
        self,
        hidden_size: int = 2048,
        num_hidden_layers: int = 28,
        num_attention_heads: int = 16,
        num_key_value_heads: int = 8,
        head_dim: int = 128,
        intermediate_size: int = 6144,
        vocab_size: int = 184704,
        rms_norm_eps: float = 1e-6,
        rope_theta: float = 1000000.0,
        max_position_embeddings: int = 24576,
        tie_word_embeddings: bool = False,
        # Acoustic inference architecture
        latent_type: str = "vae",
        latent_dim: int = 64,
        max_latent_frames: int = 24576,
        timestep_shift: float = 1.0,
        **kwargs,
    ):
        if latent_type != "vae":
            raise ValueError("YuE2 inference supports only latent_type='vae'")
        # Serialize only the documented model and Transformers configuration.
        kwargs = {key: value for key, value in kwargs.items() if key in self._hf_fields}
        super().__init__(tie_word_embeddings=tie_word_embeddings, **kwargs)
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.num_key_value_heads = num_key_value_heads
        self.head_dim = head_dim
        self.intermediate_size = intermediate_size
        self.vocab_size = vocab_size
        self.rms_norm_eps = rms_norm_eps
        self.rope_theta = rope_theta
        self.max_position_embeddings = max_position_embeddings
        self.latent_type = latent_type
        self.latent_dim = latent_dim
        self.max_latent_frames = max_latent_frames
        self.timestep_shift = timestep_shift


# ══════════════════════════════════════════════════════════════════════════════
# Building blocks
# ══════════════════════════════════════════════════════════════════════════════


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * torch.rsqrt(x.float().pow(2).mean(-1, keepdim=True) + self.eps).to(x.dtype) * self.weight


class RotaryEmbedding(nn.Module):
    def __init__(self, head_dim: int, base: float = 1000000.0):
        super().__init__()
        self.head_dim = head_dim
        self.base = base
        self._inv_freq: Optional[torch.Tensor] = None

    def forward(self, position_ids: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        if self._inv_freq is None or self._inv_freq.device != position_ids.device:
            self._inv_freq = 1.0 / (self.base ** (
                torch.arange(0, self.head_dim, 2, dtype=torch.float32, device=position_ids.device) / self.head_dim
            ))
        pos = position_ids.float().unsqueeze(-1)
        angles = pos * self._inv_freq
        return angles.cos(), angles.sin()


def _apply_rotary(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    half = x.shape[-1] // 2
    x1, x2 = x[..., :half], x[..., half:]
    cos, sin = cos.to(x.dtype), sin.to(x.dtype)
    return torch.cat([x1 * cos - x2 * sin, x2 * cos + x1 * sin], dim=-1)


class Attention(nn.Module):
    def __init__(self, config: YuE2Config):
        super().__init__()
        self.num_heads = config.num_attention_heads
        self.num_kv_heads = config.num_key_value_heads
        self.head_dim = config.head_dim
        self.num_kv_groups = self.num_heads // self.num_kv_heads

        self.q_proj = nn.Linear(config.hidden_size, self.num_heads * self.head_dim, bias=False)
        self.k_proj = nn.Linear(config.hidden_size, self.num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(config.hidden_size, self.num_kv_heads * self.head_dim, bias=False)
        self.o_proj = nn.Linear(self.num_heads * self.head_dim, config.hidden_size, bias=False)
        self.q_norm = RMSNorm(self.head_dim, config.rms_norm_eps)
        self.k_norm = RMSNorm(self.head_dim, config.rms_norm_eps)

    def project_qkv(
        self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Project, normalize, and apply RoPE. No SDPA, no KV cache, no O proj.

        Returns Q [B,T,num_heads,hd], K [B,T,num_kv_heads,hd], V [B,T,num_kv_heads,hd].
        """
        B, T, _ = x.shape
        q = self.q_proj(x).view(B, T, self.num_heads, self.head_dim)
        k = self.k_proj(x).view(B, T, self.num_kv_heads, self.head_dim)
        v = self.v_proj(x).view(B, T, self.num_kv_heads, self.head_dim)
        q, k = self.q_norm(q), self.k_norm(k)
        rc, rs = cos.unsqueeze(2), sin.unsqueeze(2)
        q = _apply_rotary(q, rc, rs)
        k = _apply_rotary(k, rc, rs)
        return q, k, v

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        past_key_value: Optional[DynamicCache] = None,
        layer_idx: int = 0,
        attention_mask: Optional[torch.Tensor] = None,
        cache_position: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        B, T, _ = x.shape
        q, k, v = self.project_qkv(x, cos, sin)

        q, k, v = q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2)

        if past_key_value is not None:
            k, v = past_key_value.update(k, v, layer_idx, {"cache_position": cache_position})

        if attention_mask is not None:
            out = sdpa(q, k, v, attn_mask=attention_mask[..., :k.shape[2]])
        else:
            out = sdpa(q, k, v, is_causal=(T > 1 and k.shape[2] == T))
        return self.o_proj(out.transpose(1, 2).reshape(B, T, -1))


class MLP(nn.Module):
    def __init__(self, config: YuE2Config):
        super().__init__()
        self.gate_proj = nn.Linear(config.hidden_size, config.intermediate_size, bias=False)
        self.up_proj = nn.Linear(config.hidden_size, config.intermediate_size, bias=False)
        self.down_proj = nn.Linear(config.intermediate_size, config.hidden_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class DecoderLayer(nn.Module):
    """Transformer layer with full MoT: dual attention projections + dual MLP."""

    def __init__(self, config: YuE2Config):
        super().__init__()
        # AR attention path
        self.input_layernorm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.self_attn = Attention(config)
        # NAR attention path (separate Q/K/V/O + layernorms)
        self.nar_input_layernorm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.nar_self_attn = Attention(config)
        # AR MLP path
        self.post_attention_layernorm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.mlp = MLP(config)
        # NAR MLP path
        self.nar_pre_mlp_layernorm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.nar_mlp = MLP(config)

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        past_key_value: Optional[DynamicCache] = None,
        layer_idx: int = 0,
        attention_mask: Optional[torch.Tensor] = None,
        ar_mask: Optional[torch.Tensor] = None,
        cache_position: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if ar_mask is not None:
            mask_3d = ar_mask.unsqueeze(-1)  # [B, S, 1]
            mask_4d = ar_mask.unsqueeze(-1).unsqueeze(-1)  # [B, S, 1, 1]

            # Per-type input layernorm
            ln_ar = self.input_layernorm(x)
            ln_nar = self.nar_input_layernorm(x)

            # Per-type QKV projection (both process all tokens)
            q_ar, k_ar, v_ar = self.self_attn.project_qkv(ln_ar, cos, sin)
            q_nar, k_nar, v_nar = self.nar_self_attn.project_qkv(ln_nar, cos, sin)

            # Merge Q/K/V per-position: AR positions use AR projections, NAR use NAR
            query = torch.where(mask_4d, q_ar, q_nar)    # [B, S, num_heads, hd]
            # K/V have num_kv_heads (fewer), same mask broadcast works
            key = torch.where(mask_4d, k_ar, k_nar)      # [B, S, num_kv_heads, hd]
            value = torch.where(mask_4d, v_ar, v_nar)

            # Transpose to [B, H, S, D] for SDPA
            B, S = x.shape[:2]
            query = query.transpose(1, 2)
            key = key.transpose(1, 2)
            value = value.transpose(1, 2)

            # Shared attention with hybrid mask
            if attention_mask is not None and attention_mask.dtype != torch.bool:
                attention_mask = attention_mask.to(query.dtype)
            core_out = sdpa(query, key, value, attn_mask=attention_mask)
            core_out = core_out.transpose(1, 2).reshape(B, S, -1)

            # Per-type O projection, merge by mask
            o_ar = self.self_attn.o_proj(core_out)
            o_nar = self.nar_self_attn.o_proj(core_out)
            h = torch.where(mask_3d, o_ar, o_nar)
            x = x + h

            # Per-type MLP
            ar_out = self.mlp(self.post_attention_layernorm(x))
            nar_out = self.nar_mlp(self.nar_pre_mlp_layernorm(x))
            mlp_out = torch.where(mask_3d, ar_out, nar_out)
        else:
            # AR-only mode (generation): use AR path only
            h = self.self_attn(self.input_layernorm(x), cos, sin, past_key_value, layer_idx,
                               attention_mask, cache_position)
            x = x + h
            mlp_out = self.mlp(self.post_attention_layernorm(x))

        x = x + mlp_out
        return x


# ══════════════════════════════════════════════════════════════════════════════
# NAR auxiliary modules
# ══════════════════════════════════════════════════════════════════════════════


class TimestepEmbedder(nn.Module):
    """Sinusoidal timestep → MLP → hidden_size (same as modules.py)."""

    def __init__(self, hidden_size: int, frequency_embedding_size: int = 256):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(frequency_embedding_size, hidden_size),
            nn.SiLU(),
            nn.Linear(hidden_size, hidden_size),
        )
        self.frequency_embedding_size = frequency_embedding_size

    def forward(self, t):
        half = self.frequency_embedding_size // 2
        freqs = torch.exp(
            -math.log(10000) * torch.arange(half, device=t.device, dtype=torch.float32) / half
        )
        args = t.float().unsqueeze(-1) * freqs.unsqueeze(0)
        emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        return self.mlp(emb.to(next(self.parameters()).dtype))


class AudioPositionEmbedding(nn.Module):
    """Non-learnable 1D sinusoidal PE for audio latent frames."""

    def __init__(self, max_frames: int, hidden_size: int):
        super().__init__()
        pe = torch.zeros(max_frames, hidden_size)
        position = torch.arange(0, max_frames, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, hidden_size, 2, dtype=torch.float32) * (-math.log(10000.0) / hidden_size)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe)

    def forward(self, position_ids):
        return self.pe[position_ids]


# ══════════════════════════════════════════════════════════════════════════════
# Static KV Cache
# ══════════════════════════════════════════════════════════════════════════════


class StaticKVCache:
    """Bounded, append-only cache for the explicit single-request AR loop.

    Returns views of the used prefix and never reallocates/copies its history.
    Standard HF ``generate`` also supports Transformers' own StaticCache.
    """

    def __init__(
        self, num_layers: int, batch_size: int, num_kv_heads: int,
        max_seq_len: int, head_dim: int, dtype: torch.dtype, device: torch.device,
    ):
        self.num_layers = num_layers
        self.max_seq_len = max_seq_len
        self._seen_tokens = 0
        self.key_cache: List[torch.Tensor] = [
            torch.zeros(batch_size, num_kv_heads, max_seq_len, head_dim, dtype=dtype, device=device)
            for _ in range(num_layers)
        ]
        self.value_cache: List[torch.Tensor] = [
            torch.zeros(batch_size, num_kv_heads, max_seq_len, head_dim, dtype=dtype, device=device)
            for _ in range(num_layers)
        ]

    def get_seq_length(self, layer_idx=0) -> int:
        return self._seen_tokens

    def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
        T = key_states.shape[2]
        pos = self._seen_tokens
        end = pos + T
        if end > self.max_seq_len:
            raise ValueError(f"KV cache capacity {self.max_seq_len} exceeded by {end}; generation was not shortened")
        self.key_cache[layer_idx][:, :, pos:end] = key_states
        self.value_cache[layer_idx][:, :, pos:end] = value_states
        if layer_idx == self.num_layers - 1:
            self._seen_tokens = end
        return self.key_cache[layer_idx][:, :, :end], self.value_cache[layer_idx][:, :, :end]

    def reset(self):
        self._seen_tokens = 0

    def reorder_cache(self, beam_idx):
        self.key_cache = [v.index_select(0, beam_idx.to(v.device)) for v in self.key_cache]
        self.value_cache = [v.index_select(0, beam_idx.to(v.device)) for v in self.value_cache]


# ══════════════════════════════════════════════════════════════════════════════
# Model
# ══════════════════════════════════════════════════════════════════════════════


class Backbone(nn.Module):
    """Transformer backbone with MoT dual MLP."""

    def __init__(self, config: YuE2Config):
        super().__init__()
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)
        self.layers = nn.ModuleList([DecoderLayer(config) for _ in range(config.num_hidden_layers)])
        self.norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.rotary_emb = RotaryEmbedding(config.head_dim, config.rope_theta)

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values=None,
        use_cache: bool = True,
        attention_mask: Optional[torch.Tensor] = None,
        ar_mask: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
        cache_position: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, ...]:
        if inputs_embeds is not None:
            x = inputs_embeds
        else:
            x = self.embed_tokens(input_ids)
        cos, sin = self.rotary_emb(position_ids)

        if use_cache and past_key_values is None:
            past_key_values = DynamicCache()

        for i, layer in enumerate(self.layers):
            x = layer(x, cos, sin, past_key_values if use_cache else None,
                      layer_idx=i, attention_mask=attention_mask, ar_mask=ar_mask,
                      cache_position=cache_position)

        return self.norm(x), past_key_values


class YuE2PreTrainedModel(PreTrainedModel):
    config_class = YuE2Config
    base_model_prefix = "model"
    supports_gradient_checkpointing = True
    _no_split_modules = ["DecoderLayer"]
    _supports_sdpa = True

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, std=0.01)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, std=0.01)


class YuE2ForCausalLM(YuE2PreTrainedModel, GenerationMixin):
    """YuE2 model: AR causal LM (generate) + NAR flow matching (ODE)."""

    def __init__(self, config: YuE2Config):
        super().__init__(config)
        self.model = Backbone(config)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        # NAR auxiliary
        self.llm2vae = nn.Linear(config.hidden_size, config.latent_dim)
        self.vae2llm = nn.Linear(config.latent_dim, config.hidden_size)
        self.time_embedder = TimestepEmbedder(config.hidden_size)
        self.latent_pos_embed = AudioPositionEmbedding(config.max_latent_frames, config.hidden_size)

        self.post_init()

    def get_input_embeddings(self):
        return self.model.embed_tokens

    def set_input_embeddings(self, value):
        self.model.embed_tokens = value

    def get_output_embeddings(self):
        return self.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.lm_head = new_embeddings

    # ── AR forward (standard causal LM, KV cached) ───────────────────

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values=None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        return_dict: Optional[bool] = None,
        **kwargs,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        if (input_ids is None) == (inputs_embeds is None):
            raise ValueError("Supply exactly one of input_ids or inputs_embeds")
        use_cache = use_cache if use_cache is not None else getattr(self.config, "use_cache", True)
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        tensor = input_ids if input_ids is not None else inputs_embeds
        batch_size, seq_len = tensor.shape[:2]
        if not seq_len:
            raise ValueError("Input must contain at least one token")
        device = tensor.device
        past_len = past_key_values.get_seq_length() if past_key_values is not None and use_cache else 0
        if cache_position is None:
            cache_position = torch.arange(past_len, past_len + seq_len, device=device)
        else:
            cache_position = cache_position.to(device=device, dtype=torch.long)
        if cache_position.ndim != 1 or cache_position.numel() != seq_len:
            raise ValueError("cache_position must identify each current token's physical cache slot")
        if position_ids is None:
            if attention_mask is not None and attention_mask.ndim == 2:
                position_ids = attention_mask.long().cumsum(-1) - 1
                position_ids.masked_fill_(attention_mask == 0, 0)
                position_ids = position_ids[:, -seq_len:].to(device)
            else:
                position_ids = cache_position[None]
        else:
            position_ids = position_ids.to(device=device, dtype=torch.long)
        if position_ids.shape[-1] != seq_len:
            raise ValueError("position_ids must cover the current input tokens")

        key_length = past_len + seq_len
        if use_cache and past_key_values is not None and hasattr(past_key_values, "get_max_cache_shape"):
            capacity = past_key_values.get_max_cache_shape()
            if capacity is not None and capacity > 0:
                key_length = capacity
        # No explicit mask is needed for unpadded prefill or single-token dynamic
        # decode. Chunked prefill needs bottom-right causal alignment; a full
        # static cache additionally needs to hide all unfilled slots.
        needs_mask = attention_mask is not None or key_length != past_len + seq_len or (past_len > 0 and seq_len > 1)
        causal_mask = _causal_mask(attention_mask, cache_position, key_length, batch_size) if needs_mask else None
        hidden_states, past_key_values = self.model(
            input_ids=input_ids, position_ids=position_ids,
            past_key_values=past_key_values, use_cache=use_cache,
            attention_mask=causal_mask, inputs_embeds=inputs_embeds,
            cache_position=cache_position,
        )

        if isinstance(logits_to_keep, int):
            if logits_to_keep < 0:
                raise ValueError("logits_to_keep must be nonnegative")
            selected = hidden_states[:, -logits_to_keep:, :] if logits_to_keep else hidden_states
        else:
            selected = hidden_states[:, logits_to_keep.to(device), :]
        if labels is not None and selected.shape[1] != hidden_states.shape[1]:
            raise ValueError("Loss computation requires logits_to_keep=0")
        logits = self.lm_head(selected)

        loss = None
        if labels is not None:
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss = F.cross_entropy(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

        if not return_dict:
            output = (logits, past_key_values) if use_cache else (logits,)
            return ((loss,) + output) if loss is not None else output
        return CausalLMOutputWithPast(loss=loss, logits=logits, past_key_values=past_key_values if use_cache else None)

    def prepare_inputs_for_generation(
        self, input_ids, past_key_values=None, attention_mask=None,
        inputs_embeds=None, cache_position=None, position_ids=None, **kwargs,
    ):
        """Keep physical cache slots separate from padding-aware RoPE positions."""
        past_len = past_key_values.get_seq_length() if past_key_values is not None else 0
        if cache_position is None:
            total = inputs_embeds.shape[1] if inputs_embeds is not None and past_len == 0 else input_ids.shape[1]
            count = max(total - past_len, 1) if past_len else total
            cache_position = torch.arange(past_len, past_len + count, device=input_ids.device)
        count = cache_position.numel()
        use_embeds = inputs_embeds is not None and past_len == 0
        if use_embeds:
            current_ids, current_embeds = None, inputs_embeds[:, -count:]
        else:
            current_ids, current_embeds = input_ids[:, -count:].contiguous(), None
        if position_ids is None and attention_mask is not None and attention_mask.ndim == 2:
            position_ids = attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(attention_mask == 0, 0)
        if position_ids is not None:
            position_ids = position_ids[:, -count:].contiguous()
        return {
            "input_ids": current_ids, "inputs_embeds": current_embeds,
            "past_key_values": past_key_values, "attention_mask": attention_mask,
            "position_ids": position_ids, "cache_position": cache_position,
            "use_cache": kwargs.get("use_cache", True),
            "logits_to_keep": kwargs.get("logits_to_keep", 1),
        }

    # ── NAR velocity (flow matching, no KV cache) ────────────────────

    def _shift_t_value(self, t_value: float, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        t_sig = torch.sigmoid(torch.tensor(t_value, dtype=dtype, device=device))
        shift = self.config.timestep_shift
        return shift * t_sig / (1 + (shift - 1) * t_sig)

    @torch.no_grad()
    def nar_velocity(
        self,
        tokens: torch.LongTensor,
        ar_mask: torch.BoolTensor,
        nar_mask: torch.BoolTensor,
        nar_content_mask: torch.BoolTensor,
        x_t: torch.Tensor,
        t_value: float,
        nar_cond_end: int = 0,
    ) -> torch.Tensor:
        """Compute v_theta(x_t, t) — flow-matching velocity field.

        Args:
            tokens: [1, S] full sequence (AR + NAR tokens)
            ar_mask: [1, S] True for AR positions
            nar_mask: [1, S] True for NAR positions
            nar_content_mask: [1, S] True for actual latent positions (not LATENT_START/END)
            x_t: [T_lat, D] current ODE state
            t_value: raw timestep (will be sigmoid-shifted)
            nar_cond_end: if > 0, NAR only sees positions < nar_cond_end (text-only mode)
        Returns:
            v_pred: [T_lat, D] predicted velocity
        """
        device = tokens.device
        dtype = next(self.parameters()).dtype
        B, S = tokens.shape

        # 1. Token embeddings
        token_emb = self.model.embed_tokens(tokens)  # [B, S, H]

        # 2. Build latent hidden for ALL NAR positions (START + content + END)
        # Training injects vae2llm(x_t) + time_emb + pos_emb at ALL NAR positions,
        # including LATENT_START (clean=0) and LATENT_END (clean=0).
        # NAR position IDs via cumsum: START=0, content=[1..T_lat], END=T_lat+1.
        t_shifted = self._shift_t_value(t_value, device, dtype)
        T_lat = x_t.shape[0]

        nar_indices = nar_mask[0].nonzero(as_tuple=True)[0]  # all NAR positions
        content_indices = nar_content_mask[0].nonzero(as_tuple=True)[0]
        N_nar = nar_indices.shape[0]  # START + T_lat + END

        # Build x_t for all NAR positions: zeros for START/END, actual x_t for content
        x_nar = torch.zeros(N_nar, x_t.shape[1], device=device, dtype=dtype)
        x_nar[1:1 + T_lat] = x_t.to(dtype)  # content frames at positions [1, T_lat]

        latent_hidden_nar = self.vae2llm(x_nar.unsqueeze(0))  # [1, N_nar, H]

        # Timestep embedding (same t for all NAR positions)
        time_emb = self.time_embedder(t_shifted.expand(N_nar)).unsqueeze(0)
        latent_hidden_nar = latent_hidden_nar + time_emb

        # Position embedding: cumsum-style [0, 1, 2, ..., N_nar-1]
        pos_ids = torch.arange(N_nar, device=device).clamp(max=self.config.max_latent_frames - 1)
        pos_emb = self.latent_pos_embed(pos_ids).unsqueeze(0)
        latent_hidden_nar = latent_hidden_nar + pos_emb

        # Inject at ALL NAR positions (matching training's torch.where)
        token_emb[0, nar_indices] = latent_hidden_nar[0]

        # 3. Build hybrid attention mask [B, 1, S, S]
        # AR→AR: causal, NAR→AR: full, NAR→NAR: bidirectional, AR→NAR: blocked
        ar_q = ar_mask.unsqueeze(2).float()   # [B, S, 1]
        ar_k = ar_mask.unsqueeze(1).float()   # [B, 1, S]
        nar_q = nar_mask.unsqueeze(2).float()
        nar_k = nar_mask.unsqueeze(1).float()
        causal = torch.tril(torch.ones(S, S, device=device))

        if nar_cond_end > 0:
            # Codec dropout: NAR only sees positions < nar_cond_end (text) + NAR
            text_k = torch.zeros(1, 1, S, device=device)
            text_k[0, 0, :nar_cond_end] = 1.0
            mask = (ar_q * ar_k * causal) + (nar_q * text_k) + (nar_q * nar_k)
        else:
            mask = (ar_q * ar_k * causal) + (nar_q * ar_k) + (nar_q * nar_k)
        # Convert to additive: 0 → attend, -inf → block
        attn_mask = mask.unsqueeze(1)  # [B, 1, S, S]
        attn_mask = attn_mask.masked_fill(attn_mask == 0, float("-inf")).masked_fill(attn_mask > 0, 0.0)

        # 4. Position IDs + RoPE
        position_ids = torch.arange(S, device=device).unsqueeze(0)

        # 5. Forward through decoder (with MoT routing)
        ar_mask_bt = ar_mask  # [B, S] bool for MoT routing
        hidden_states, _ = self.model(
            inputs_embeds=token_emb, position_ids=position_ids,
            use_cache=False, attention_mask=attn_mask, ar_mask=ar_mask_bt,
        )

        # 6. NAR head at content positions
        nar_pred = self.llm2vae(hidden_states)  # [B, S, D]
        v_pred = nar_pred[0, content_indices]  # [T_lat, D]
        return v_pred

# Keep custom code + auto_map when a local user calls save_pretrained as well
# as when the release builder creates a Hub repository.
YuE2Config.register_for_auto_class()
YuE2ForCausalLM.register_for_auto_class("AutoModelForCausalLM")


# ----------------------------------------------------------------------------
# GENERACION NO AUTOREGRESIVA (flow matching)
# ----------------------------------------------------------------------------

@dataclass
class Chunk:
    ar_tokens: list[int]
    noise: torch.Tensor
    nar_cond_end: int = 0


def _integers(values, name):
    result = list(values)
    if not result or any(isinstance(v, bool) or not isinstance(v, Integral) for v in result):
        raise ValueError(f"{name} must be a nonempty sequence of integer token IDs")
    return [int(v) for v in result]


def song_chunks(prefix, codec, seed, context=CONTEXT):
    """Draw the complete noise tensor once, then take views at historical cuts."""
    prefix = _integers(prefix, "prefix")
    codec = _integers(codec, "codec")
    if min(prefix) < 0 or min(codec) < 0 or max(codec) >= CODEC_SIZE:
        raise ValueError("Token IDs are outside their allowed vocabulary")
    if isinstance(seed, bool) or not isinstance(seed, Integral):
        raise ValueError("seed must be an integer")
    if isinstance(context, bool) or not isinstance(context, Integral) or not 1 <= context <= CONTEXT:
        raise ValueError(f"context must be an integer in 1..{CONTEXT}")
    ranges = chunk_ranges(len(codec), len(prefix), int(context))
    generator = torch.Generator(device="cpu").manual_seed(int(seed))
    noise = torch.randn((len(codec), 64), dtype=torch.float32, device="cpu", generator=generator)
    return [Chunk(prefix + [value + CODEC_OFFSET for value in codec[a:b]] + [MUSIC_END], noise[a:b])
            for a, b in ranges]


def attention(q, k, v, *, causal=False, backend="sdpa", query_chunk_size=None):
    """Attend [tokens, heads, dim] tensors without materializing a song mask.

    CPU/MPS bound the number of query rows for a potential math SDPA fallback.
    CUDA normally uses PyTorch's fused SDPA without an external flash package.
    """
    if backend not in {"sdpa", "math", "flash"}:
        raise ValueError("attention must be sdpa, math, or flash")
    if q.ndim != 3 or k.ndim != 3 or v.shape != k.shape or q.shape[-1] != k.shape[-1]:
        raise ValueError("Expected Q/K/V [tokens, heads, dim] with matching K/V")
    if min(q.shape) < 1 or min(k.shape) < 1 or q.shape[1] % k.shape[1]:
        raise ValueError("Invalid attention lengths or grouped-query head count")
    if causal and len(q) != len(k):
        raise ValueError("Causal prefill requires matching Q/K sequence lengths")
    if backend == "flash" and q.device.type != "cuda":
        raise ValueError("Explicit flash SDPA requires a CUDA device")
    if query_chunk_size is not None and (isinstance(query_chunk_size, bool) or
                                        not isinstance(query_chunk_size, Integral) or query_chunk_size < 1):
        raise ValueError("query_chunk_size must be a positive integer")
    block = query_chunk_size or (len(q) if q.device.type == "cuda" and backend != "math" else 256)
    query = q.transpose(0, 1).unsqueeze(0)
    key = k.transpose(0, 1).unsqueeze(0)
    value = v.transpose(0, 1).unsqueeze(0)
    grouped = query.shape[1] != key.shape[1]
    if grouped and q.device.type == "mps":
        groups = query.shape[1] // key.shape[1]
        key, value = key.repeat_interleave(groups, 1), value.repeat_interleave(groups, 1)
        grouped = False
    context = nullcontext()
    if backend != "sdpa":
        from torch.nn.attention import SDPBackend, sdpa_kernel
        context = sdpa_kernel(SDPBackend.MATH if backend == "math" else SDPBackend.FLASH_ATTENTION)
    outputs = []
    with context:
        for start in range(0, len(q), block):
            end = min(start + block, len(q))
            used_key = key[..., :end, :] if causal else key
            used_value = value[..., :end, :] if causal else value
            # is_causal on a rectangular Q/K uses an upper-left triangle, so a
            # later query block needs its absolute query positions explicitly.
            mask = None
            if causal and start:
                mask = (torch.arange(end, device=q.device)[None, :] <=
                        torch.arange(start, end, device=q.device)[:, None])
            outputs.append(F.scaled_dot_product_attention(
                query[..., start:end, :], used_key, used_value,
                attn_mask=mask, is_causal=causal and start == 0, enable_gqa=grouped,
            ))
    return torch.cat(outputs, dim=-2)[0].transpose(0, 1)


class CachedNAR:
    """One original acoustic chunk; AR prefix KV is invariant during the ODE."""

    def __init__(self, model, chunk: Chunk, attention="sdpa", query_chunk_size=None):
        self.model, self.chunk = model, chunk
        self.backend, self.query_chunk_size = attention, query_chunk_size
        weight = next(model.vae2llm.parameters())
        self.device, self.dtype = weight.device, weight.dtype
        if chunk.noise.ndim != 2 or chunk.noise.shape[1] != 64 or len(chunk.noise) < 1:
            raise ValueError("Expected nonempty acoustic noise [frames,64]")
        if not torch.isfinite(chunk.noise).all():
            raise ValueError("Acoustic noise contains non-finite values")
        self.ar_length, self.nar_length = len(chunk.ar_tokens), len(chunk.noise) + 2
        if self.ar_length < 1 or min(chunk.ar_tokens) < 0 or max(chunk.ar_tokens) >= model.config.vocab_size:
            raise ValueError("AR prefix is empty or outside the model vocabulary")
        if self.ar_length + self.nar_length > model.config.max_position_embeddings:
            raise ValueError("Original acoustic chunk exceeds the model context")
        if chunk.nar_cond_end < 0:
            raise ValueError("nar_cond_end must be nonnegative")
        self.visible_length = min(chunk.nar_cond_end, self.ar_length) if chunk.nar_cond_end else self.ar_length
        positions = torch.arange(self.ar_length, self.ar_length + self.nar_length, device=self.device)[None]
        self.cos, self.sin = model.model.rotary_emb(positions)
        local = torch.arange(self.nar_length, device=self.device).clamp(max=model.config.max_latent_frames - 1)
        self.pos_emb = model.latent_pos_embed(local)[None]
        self.cache = []
        self._prefill()

    def _attention(self, q, k, v, causal=False):
        return attention(q, k, v, causal=causal, backend=self.backend, query_chunk_size=self.query_chunk_size)

    @torch.inference_mode()
    def _prefill(self):
        backbone = self.model.model
        ids = torch.tensor([self.chunk.ar_tokens], dtype=torch.long, device=self.device)
        positions = torch.arange(self.ar_length, device=self.device)[None]
        cos, sin = backbone.rotary_emb(positions)
        x = backbone.embed_tokens(ids)
        for layer in backbone.layers:
            q, k, v = layer.self_attn.project_qkv(layer.input_layernorm(x), cos, sin)
            # Clone only for restricted visibility; a slice would retain the
            # storage of invisible codec tokens for every layer.
            cached = (k[0, :self.visible_length], v[0, :self.visible_length])
            if self.visible_length != self.ar_length:
                cached = tuple(t.clone() for t in cached)
            self.cache.append(cached)
            h = self._attention(q[0], k[0], v[0], causal=True)
            x = x + layer.self_attn.o_proj(h.flatten(1)[None])
            x = x + layer.mlp(layer.post_attention_layernorm(x))

    @torch.inference_mode()
    def velocity(self, state, raw_t):
        model = self.model
        if tuple(state.shape) != tuple(self.chunk.noise.shape):
            raise ValueError("ODE state shape changed")
        x_nar = F.pad(state, (0, 0, 1, 1))
        shifted = model._shift_t_value(raw_t, self.device, self.dtype)
        x = model.vae2llm(x_nar[None])
        x = x + model.time_embedder(shifted.expand(self.nar_length))[None]
        x = x + self.pos_emb
        for layer, (ar_k, ar_v) in zip(model.model.layers, self.cache):
            q, k, v = layer.nar_self_attn.project_qkv(layer.nar_input_layernorm(x), self.cos, self.sin)
            k, v = torch.cat((ar_k, k[0])), torch.cat((ar_v, v[0]))
            h = self._attention(q[0], k, v)
            x = x + layer.nar_self_attn.o_proj(h.flatten(1)[None])
            x = x + layer.nar_mlp(layer.nar_pre_mlp_layernorm(x))
        return model.llm2vae(model.model.norm(x))[0, 1:-1]

    @torch.inference_mode()
    def solve(self, steps=32, cancelled: Callable[[], bool] | None = None,
              on_progress: Callable[[int, int], None] | None = None):
        """Solve a chunk, reporting each submitted midpoint step without syncing.

        CUDA work may still be executing when ``on_progress`` runs. The existing
        CPU result transfer completes that work before this method returns.
        Callback exceptions propagate to the caller.
        """
        if isinstance(steps, bool) or not isinstance(steps, Integral) or steps < 1:
            raise ValueError("steps must be a positive integer")
        state = self.chunk.noise.to(device=self.device, dtype=self.dtype)
        dt = 1.0 / steps
        for step in range(steps):
            if cancelled is not None and cancelled():
                raise InterruptedError("Cancelled during acoustic flow matching")
            t = 1.0 - step * dt
            raw = torch.logit(torch.tensor(t, dtype=torch.float64, device="cpu")).clamp(-20, 20).item()
            first = self.velocity(state, raw)
            mid = state - first * (dt / 2)
            if cancelled is not None and cancelled():
                raise InterruptedError("Cancelled during acoustic flow matching")
            raw_mid = torch.logit(torch.tensor(t - dt / 2, dtype=torch.float64, device="cpu")).clamp(-20, 20).item()
            state = state - self.velocity(mid, raw_mid) * dt
            if on_progress is not None:
                on_progress(step + 1, int(steps))
        result = state.float().cpu()
        if not torch.isfinite(result).all():
            raise FloatingPointError("Acoustic flow matching produced non-finite latents")
        return result

    def close(self):
        self.cache.clear()
        self.cos = self.sin = self.pos_emb = None


@contextmanager
def _offload_ar(model, enabled):
    """Temporarily move unused AR modules; this model cannot serve concurrently."""
    modules = [model.model.embed_tokens, model.lm_head]
    for layer in model.model.layers:
        modules.extend((layer.input_layernorm, layer.self_attn, layer.post_attention_layernorm, layer.mlp))
    moved = []
    try:
        if enabled:
            for module in modules:
                device = next(module.parameters()).device
                if device.type != "cpu":
                    module.to(device="cpu")
                    moved.append((module, device))
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        yield
    finally:
        for module, device in moved:
            module.to(device=device)


@torch.inference_mode()
def synthesize(model, prefix: Sequence[int], codec: Sequence[int], seed: int,
               steps=32, context=CONTEXT, attention="sdpa", offload_ar=False,
               cancelled=None, query_chunk_size=None,
               on_progress: Callable[[int, int], None] | None = None):
    """Return CPU FP32 [frames,64] latents, solving original chunks serially.

    Defaults preserve the release protocol. Explicit steps/context overrides
    belong in the caller's effective configuration record. ``offload_ar`` is
    an optional memory tradeoff and requires exclusive access to ``model``.
    Progress counts submitted midpoint steps across all original chunks; it
    introduces no device synchronization. Callback exceptions propagate after
    the current chunk's cache is released and any offloaded weights restored.
    """
    if model.training:
        raise ValueError("synthesize requires model.eval()")
    chunks = song_chunks(prefix, codec, seed, context)
    output = []
    for chunk_index, chunk in enumerate(chunks):
        if cancelled is not None and cancelled():
            raise InterruptedError("Cancelled before acoustic prefill")
        engine = CachedNAR(model, chunk, attention, query_chunk_size)
        # Drop the prefix cache before restoring AR weights, including on
        # cancellation/failure, to keep the restoration memory peak bounded.
        with _offload_ar(model, offload_ar):
            try:
                progress = None
                if on_progress is not None:
                    def progress(completed, total):
                        on_progress(chunk_index * total + completed, total * len(chunks))
                output.append(engine.solve(steps, cancelled, on_progress=progress))
            finally:
                engine.close()
        del engine
    return torch.cat(output, dim=0)


# ----------------------------------------------------------------------------
# BACKEND RAPIDO OPCIONAL (vLLM + Triton)
# ----------------------------------------------------------------------------

WIRE = "YUE2_FAST\t"
PENALTY, WINDOW = "yue2_window_penalty", "yue2_penalty_window"


def ar_keys(config):
    names = {"model.embed_tokens.weight", "model.norm.weight", "lm_head.weight"}
    for index in range(config["num_hidden_layers"]):
        prefix = f"model.layers.{index}."
        names.update(prefix + name + ".weight" for name in (
            "input_layernorm", "post_attention_layernorm", "self_attn.q_proj",
            "self_attn.k_proj", "self_attn.v_proj", "self_attn.o_proj",
            "self_attn.q_norm", "self_attn.k_norm", "mlp.gate_proj",
            "mlp.up_proj", "mlp.down_proj"))
    return names


def qwen_config(config):
    required = ("hidden_size", "intermediate_size", "num_hidden_layers", "num_attention_heads",
                "num_key_value_heads", "head_dim", "vocab_size", "rms_norm_eps", "rope_theta")
    output = {name: config[name] for name in required}
    output.update(architectures=["Qwen3ForCausalLM"], model_type="qwen3", hidden_act="silu",
                  max_position_embeddings=config.get("max_position_embeddings", CONTEXT),
                  tie_word_embeddings=False, attention_bias=False, attention_dropout=0.,
                  use_sliding_window=False, sliding_window=None, max_window_layers=0,
                  torch_dtype="bfloat16")
    return output


def derive_ar_checkpoint(model_dir, cache_dir=None):
    """Extract the exact AR tensors; checksum both source and cached derivative."""
    from safetensors import safe_open
    from safetensors.torch import save_file
    model_dir = Path(model_dir)
    source = model_identity(model_dir)
    config = json.loads((model_dir / "config.json").read_text())
    converted = qwen_config(config)
    stamp = {"schema": 1, "source": source, "config": converted}
    key = identity(stamp)
    if cache_dir is None:
        base = Path(os.environ.get("YUE2_CACHE", os.environ.get("HF_HOME", Path.home() / ".cache/huggingface")))
        cache_dir = base / "yue2-ar"
    parent = Path(cache_dir)
    parent.mkdir(parents=True, exist_ok=True)
    target = parent / key
    # Linux is the supported vLLM platform; lock prevents simultaneous writers.
    import fcntl
    with (parent / (key + ".lock")).open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if target.exists():
            manifest = json.loads((target / "derivation.json").read_text())
            if manifest.get("identity") != key or manifest.get("source") != source:
                raise ValueError("AR cache provenance mismatch; remove this derived cache explicitly")
            for name, digest in manifest["sha256"].items():
                if sha256_file(target / name) != digest:
                    raise ValueError(f"Corrupt derived AR cache: {name}")
            return target
        with tempfile.TemporaryDirectory(prefix=key + ".", dir=parent) as temporary:
            temp = Path(temporary)
            wanted, tensors = ar_keys(config), {}
            with contextlib.ExitStack() as stack:
                for filename in source["files"]:
                    reader = stack.enter_context(safe_open(model_dir / filename, framework="pt", device="cpu"))
                    for name in wanted.intersection(reader.keys()):
                        if name in tensors:
                            raise ValueError(f"Duplicate source tensor: {name}")
                        tensors[name] = reader.get_tensor(name)
                if set(tensors) != wanted:
                    raise ValueError(f"Missing AR tensors: {sorted(wanted - set(tensors))}")
                save_file(tensors, temp / "model.safetensors", metadata={"format": "pt"})
            write_json(temp / "config.json", converted)
            write_json(temp / "derivation.json", {**stamp, "identity": key,
                       "tensor_count": len(tensors), "sha256": {
                           name: sha256_file(temp / name) for name in ("model.safetensors", "config.json")}})
            # Rename only our finished directory; leave TemporaryDirectory an
            # empty replacement to clean up normally.
            os.replace(temp, target)
            temp.mkdir()
    return target


def kv_cache_bytes(config, max_sequences=1, context=CONTEXT, block_size=16):
    positions = math.ceil(context / block_size) * block_size
    return positions * max_sequences * config["num_hidden_layers"] * 2 * config["num_key_value_heads"] * config["head_dim"] * 2


def __getattr__(name):
    if name != "WindowedPenalty":
        raise AttributeError(name)
    # vLLM resolves this FQCN only inside its optional worker processes.
    from vllm.v1.sample.logits_processor import LogitsProcessor
    import torch
    import triton
    import triton.language as tl

    @triton.jit
    def penalty_kernel(logits, histories, alphas, stride: tl.constexpr, window: tl.constexpr,
                       vocab: tl.constexpr, width: tl.constexpr):
        row = tl.program_id(0)
        pos = tl.arange(0, width)
        ids = tl.load(histories + row * window + pos, pos < window, other=-1)
        equal = (ids[:, None] == ids[None, :]) & (ids[:, None] >= 0)
        count = tl.sum(equal.to(tl.int32), axis=1)
        earlier = tl.sum((equal & (pos[None, :] < pos[:, None])).to(tl.int32), axis=1)
        valid = (pos < window) & (ids >= 0) & (ids < vocab) & (earlier == 0)
        multiplier = tl.load(alphas + row * (window + 1) + count)
        value = tl.load(logits + row * stride + ids, valid, other=0).to(tl.float32)
        tl.store(logits + row * stride + ids,
                 tl.where(value < 0, value * multiplier, value / multiplier), valid)

    class WindowedPenalty(LogitsProcessor):
        @classmethod
        def validate_params(cls, params):
            extra = params.extra_args or {}
            if not 0 < float(extra.get(PENALTY, 1)) or not 1 <= int(extra.get(WINDOW, 50)) <= 100:
                raise ValueError("Invalid window penalty")

        def __init__(self, vllm_config, device, is_pin_memory):
            self.device, self.states = device, {}
            self.capacity = vllm_config.scheduler_config.max_num_seqs
            self.window = 100
            self.host = torch.full((self.capacity, self.window), -1, dtype=torch.long, pin_memory=is_pin_memory)
            self.histories = torch.empty_like(self.host, device=device)
            self.alphas = torch.ones((self.capacity, self.window + 1), dtype=torch.float32, device=device)
            self.lookup = {}

        def is_argmax_invariant(self):
            return False

        def update_state(self, update):
            if update is None:
                return
            for index in update.removed:
                self.states.pop(index, None)
            for index, params, prompt, output in update.added:
                extra = params.extra_args or {}
                self.states[index] = (output, float(extra.get(PENALTY, 1)), int(extra.get(WINDOW, 50)))
                penalty = self.states[index][1]
                if penalty not in self.lookup:
                    self.lookup[penalty] = torch.pow(torch.tensor(penalty, device=self.device, dtype=torch.float32),
                                                    torch.arange(self.window + 1, device=self.device, dtype=torch.float32))
            for a, b, direction in update.moved:
                if direction.name == "SWAP":
                    va, vb = self.states.pop(a, None), self.states.pop(b, None)
                    if va is not None:
                        self.states[b] = va
                    if vb is not None:
                        self.states[a] = vb
                else:
                    self.states.pop(b, None)
                    if a in self.states:
                        self.states[b] = self.states.pop(a)
            for index, (_, penalty, _) in self.states.items():
                self.alphas[index].copy_(self.lookup[penalty])

        def apply(self, logits):
            if logits.device.type == "cuda":
                n = len(logits)
                self.host[:n].fill_(-1)
                host = self.host.numpy()
                for row, (history, _, window) in self.states.items():
                    recent = history[-window:]
                    if recent and row < n:
                        host[row, :len(recent)] = recent
                self.histories[:n].copy_(self.host[:n], non_blocking=True)
                penalty_kernel[(n,)](logits, self.histories, self.alphas, logits.stride(0),
                                     self.window, logits.shape[-1], 128, num_warps=4)
                return logits
            # CPU oracle for focused state/penalty tests without a GPU.
            for row, (history, penalty, window) in self.states.items():
                if row >= len(logits) or not history or penalty == 1:
                    continue
                ids, counts = torch.tensor(history[-window:], device=logits.device).unique(return_counts=True)
                multiplier = torch.pow(torch.tensor(penalty, device=logits.device, dtype=torch.float32), counts.float())
                values = logits[row, ids].float()
                logits[row, ids] = torch.where(values < 0, values * multiplier, values / multiplier).to(logits.dtype)
            return logits

    WindowedPenalty.__module__ = __name__
    WindowedPenalty.__qualname__ = "WindowedPenalty"
    globals()[name] = WindowedPenalty
    return WindowedPenalty


def _stop_process(process):
    if process.poll() is None:
        with contextlib.suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)


class _Worker:
    def __init__(self, pipe):
        self.lock = threading.Lock()
        self.temp = tempfile.TemporaryDirectory(prefix="yue2-vllm-")
        self.log_path = Path(self.temp.name) / "worker.log"
        self.log = self.log_path.open("w+")
        env = os.environ.copy()
        env["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
        self.process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--worker"],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log,
                         bufsize=0, env=env, start_new_session=True)
        self.finalizer = weakref.finalize(self, _stop_process, self.process)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.process.stdout, selectors.EVENT_READ)
        self.buffer = b""
        self._send({"model_dir": str(pipe.model_dir), "device": str(pipe.device),
                    "memory_budget_gib": pipe.memory_budget_gib})

    def _send(self, value):
        self.process.stdin.write((json.dumps(value) + "\n").encode())
        self.process.stdin.flush()

    def request(self, payload, cancelled=None, on_token=None):
        with self.lock:
            self._send(payload)
            while True:
                if cancelled is not None and cancelled():
                    self.close()
                    raise InterruptedError("Cancelled during vLLM AR generation")
                if self.selector.select(timeout=.1):
                    block = os.read(self.process.stdout.fileno(), 65536)
                    if not block:
                        break
                    self.buffer += block
                    while b"\n" in self.buffer:
                        raw, self.buffer = self.buffer.split(b"\n", 1)
                        line = raw.decode(errors="replace")
                        if not line.startswith(WIRE):
                            self.log.write(line + "\n")
                            continue
                        event = json.loads(line[len(WIRE):])
                        if event.get("error"):
                            self.close()
                            raise RuntimeError(event["error"])
                        if event.get("event") == "token" and on_token is not None:
                            on_token(payload["phase"], event["token"])
                        if event.get("event") == "result":
                            return event["ids"], event["timing"], event["truncated"]
                if self.process.poll() is not None:
                    break
            self.log.flush()
            details = self.log_path.read_text(errors="replace")[-12000:]
            self.close()
            raise RuntimeError(f"vLLM worker exited without a result: {details}")

    def close(self):
        _stop_process(self.process)
        self.finalizer.detach()
        self.selector.close()
        for stream in (self.process.stdin, self.process.stdout, self.log):
            if stream is not None and not stream.closed:
                stream.close()
        self.temp.cleanup()


def close_vllm(pipe):
    worker = getattr(pipe, "_vllm_worker", None)
    if worker is not None:
        worker.close()
        pipe._vllm_worker = None


def generate_vllm(pipe, prefix, sampling, seed, phase, negative=None, cfg_scale=1.,
                  legacy_off=False, cancelled=None, on_token=None):
    if phase not in {"abc", "semantic"}:
        raise ValueError("phase must be abc or semantic")
    if len(prefix) + sampling.max_tokens > CONTEXT:
        raise ValueError("Prefix plus requested generation budget exceeds context")
    reason = None
    if cfg_scale != 1.:
        reason = "paired_cfg_uses_torch"
    elif legacy_off:
        reason = "historical_off_sampling_uses_torch"
    elif pipe.device.type != "cuda":
        reason = "vllm_requires_cuda"
    elif pipe.quantization != "none":
        reason = "experimental_fp8_uses_torch"
    if reason:
        close_vllm(pipe)
        ids, timing, truncated = generate_tokens(pipe._load_model(), prefix, sampling, seed, phase,
                    negative=negative, cfg_scale=cfg_scale, legacy_off=legacy_off,
                    cancelled=cancelled, on_token=on_token)
        timing.update(backend_actual="torch", backend_requested="vllm", fallback_reason=reason)
        return ids, timing, truncated
    if cancelled is not None and cancelled():
        raise InterruptedError("Cancelled before vLLM load")
    if importlib.util.find_spec("vllm") is None:
        raise ImportError("Backend rapido no disponible: instala 'pip install vllm triton' junto a yue_composer.py")
    if getattr(pipe, "_vllm_worker", None) is None:
        import torch
        if pipe._model is not None:
            pipe._model.to("cpu")
        if getattr(pipe, "_vae", None) is not None:
            pipe._vae.to("cpu")
        gc.collect()
        torch.cuda.empty_cache()
        pipe._vllm_worker = _Worker(pipe)
    payload = {"prefix": list(prefix), "sampling": dataclasses.asdict(sampling),
               "seed": seed, "phase": phase, "stream_tokens": on_token is not None}
    try:
        return pipe._vllm_worker.request(payload, cancelled, on_token)
    except BaseException:
        close_vllm(pipe)
        raise


def _emit(value):
    print(WIRE + json.dumps(value), flush=True)


async def _worker_main():
    import asyncio
    import torch
    setup = json.loads(sys.stdin.readline())
    device = torch.device(setup["device"])
    if device.index is not None:
        # vLLM sees one logical device; respect the parent scheduler's mapping.
        visible = os.environ.get("CUDA_VISIBLE_DEVICES")
        os.environ["CUDA_VISIBLE_DEVICES"] = visible.split(",")[device.index] if visible else str(device.index)
    import vllm
    if vllm.__version__ != "0.19.0":
        raise RuntimeError(f"This backend requires vllm==0.19.0, found {vllm.__version__}")
    from vllm import SamplingParams
    from vllm.engine.arg_utils import AsyncEngineArgs
    from vllm.v1.engine.async_llm import AsyncLLM
    derived = derive_ar_checkpoint(setup["model_dir"])
    config = json.loads((derived / "config.json").read_text())
    total = torch.cuda.get_device_properties(0).total_memory
    budget = min(setup["memory_budget_gib"] * 2**30, total)
    kv_bytes = kv_cache_bytes(config)
    weights_bytes = (derived / "model.safetensors").stat().st_size
    if kv_bytes + weights_bytes + 3 * 2**30 > budget:
        raise MemoryError("Requested vLLM memory budget cannot fit full-context BF16 AR+KV+3GiB reserve")
    load_start = time.perf_counter()
    args = AsyncEngineArgs(model=str(derived), skip_tokenizer_init=True, dtype="bfloat16",
                           max_model_len=CONTEXT, max_num_seqs=1, max_num_batched_tokens=2048,
                           enable_chunked_prefill=True, enable_prefix_caching=True,
                           kv_cache_memory_bytes=kv_bytes,
                           gpu_memory_utilization=min(.9, (budget - 2 * 2**30) / total),
                           logits_processors=["__main__:WindowedPenalty"], disable_log_stats=True)
    engine = AsyncLLM.from_engine_args(args)
    load_seconds = time.perf_counter() - load_start
    try:
        while line := await asyncio.to_thread(sys.stdin.readline):
            request = json.loads(line)
            sampling = Sampling(**request["sampling"])
            abc = request["phase"] == "abc"
            end = ABC_END if abc else MUSIC_END
            allowed = list(range(EOD)) + [end] if abc else list(range(CODEC_OFFSET, CODEC_OFFSET + CODEC_SIZE)) + [end]
            params = SamplingParams(temperature=sampling.temperature, top_p=sampling.top_p,
                       top_k=sampling.top_k, repetition_penalty=1., min_tokens=sampling.min_tokens,
                       max_tokens=sampling.max_tokens, seed=request["seed"], stop_token_ids=[end],
                       allowed_token_ids=allowed, detokenize=False,
                       extra_args={PENALTY: sampling.repetition_penalty, WINDOW: sampling.penalty_window})
            start, first, output, sent = time.perf_counter(), None, None, 0
            async for result in engine.generate({"prompt_token_ids": request["prefix"]}, params, str(uuid.uuid4())):
                output = result.outputs[0]
                if output.token_ids and first is None:
                    first = time.perf_counter() - start
                if request["stream_tokens"]:
                    for token in output.token_ids[sent:]:
                        _emit({"event": "token", "token": int(token)})
                    sent = len(output.token_ids)
            if output is None:
                raise RuntimeError("vLLM returned no output")
            ids = list(output.token_ids)
            ended = bool(ids and ids[-1] == end) or output.stop_reason == end
            if ids and ids[-1] == end:
                ids.pop()
            elapsed = time.perf_counter() - start
            count = len(ids) + int(ended)
            _emit({"event": "result", "ids": ids, "truncated": not ended,
                   "timing": {"seconds": elapsed, "ttft_seconds": first,
                       "output_tokens": count, "content_tokens": len(ids), "output_tps": count / elapsed,
                       "prefix_tokens": len(request["prefix"]), "cfg_branches": 1,
                       "backend_actual": "vllm", "backend_requested": "vllm",
                       "engine_load_seconds": load_seconds, "kv_cache_memory_bytes": kv_bytes,
                       "ar_derivation_identity": derived.name, "max_num_seqs": 1}})
            load_seconds = 0.
    finally:
        engine.shutdown()


def _run_fast_worker():
    """Bucle del proceso worker de vLLM, lanzado como `<este fichero> --worker`."""
    import asyncio
    try:
        asyncio.run(_worker_main())
    except BaseException as error:
        _emit({"error": f"{type(error).__name__}: {error}"})
        raise


# ----------------------------------------------------------------------------
# PIPELINE DE ALTO NIVEL (plan / generate_semantic / synthesize / decode)
# ----------------------------------------------------------------------------

@dataclass
class SymbolicPlan:
    request: SongRequest
    abc: str | None
    abc_ids: list[int]
    prefix: list[int]
    timing: dict = field(default_factory=dict)
    truncated: bool = False

    def save(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        if self.abc is not None:
            (directory / "score.abc").write_bytes(self.abc.encode("utf-8"))
        np.save(directory / "abc_tokens.npy", np.asarray(self.abc_ids, dtype=np.int32))
        np.save(directory / "prefix.npy", np.asarray(self.prefix, dtype=np.int32))
        write_json(directory / "plan.json", {"request": self.request.to_dict(), "timing": self.timing,
                                              "truncated": self.truncated, "prefix": self.prefix,
                                              "abc_ids": self.abc_ids, "abc": self.abc})


        names = ["plan.json", "abc_tokens.npy", "prefix.npy"] + (["score.abc"] if self.abc is not None else [])
        write_json(directory / "plan_manifest.json", {name: sha256_file(directory / name) for name in names})

    @classmethod
    def load(cls, directory):
        """Restore exact planner output without decoding and retokenizing its ABC."""
        directory = Path(directory)
        hashes = json.loads((directory / "plan_manifest.json").read_text())
        if not {"plan.json", "abc_tokens.npy", "prefix.npy"} <= hashes.keys():
            raise ValueError("Incomplete saved plan")
        for name, digest in hashes.items():
            if name not in {"plan.json", "abc_tokens.npy", "prefix.npy", "score.abc"} or (directory / name).is_symlink():
                raise ValueError("Invalid plan artifact")
            if sha256_file(directory / name) != digest:
                raise ValueError("Saved plan changed; supply modified ABC as an external planner input")
        data = json.loads((directory / "plan.json").read_text())
        for field, filename in (("abc_ids", "abc_tokens.npy"), ("prefix", "prefix.npy")):
            array = np.load(directory / filename, allow_pickle=False)
            if array.ndim != 1 or array.dtype.kind not in "iu" or array.tolist() != data[field]:
                raise ValueError("Saved plan token array mismatch")
        if data["abc"] is not None and ("score.abc" not in hashes or (directory / "score.abc").read_bytes() != data["abc"].encode("utf-8")):
            raise ValueError("Saved ABC text mismatch")
        return cls(SongRequest(**data["request"]), data["abc"], data["abc_ids"], data["prefix"],
                   data["timing"], data["truncated"])


@dataclass
class SemanticResult:
    plan: SymbolicPlan
    tokens: list[int]
    timing: dict
    truncated: bool


@dataclass
class SongResult:
    audio: np.ndarray
    sample_rate: int
    semantic: SemanticResult
    latents: np.ndarray
    config: dict
    weights: dict
    timing: dict
    request_identity: str

    @property
    def abc(self):
        return self.semantic.plan.abc

    @property
    def truncated(self):
        return {"abc": self.semantic.plan.truncated, "semantic": self.semantic.truncated}

    def save(self, path):
        """Write audio; use save_artifacts(directory) to retain a reproducible run."""
        import soundfile as sf
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix.lower() not in {".flac", ".wav"}:
            raise ValueError("Use .flac or .wav; MP3 is an optional delivery conversion")
        sf.write(path, self.audio, self.sample_rate, subtype="PCM_24" if path.suffix.lower() == ".flac" else "FLOAT")
        return str(path)

    def save_artifacts(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.semantic.plan.save(directory)
        self.save(directory / "audio.flac")
        np.save(directory / "semantic.npy", np.asarray(self.semantic.tokens, dtype=np.int32))
        np.save(directory / "latent.npy", self.latents.astype(np.float32))
        write_json(directory / "request.json", self.semantic.plan.request.to_dict())
        write_json(directory / "config.json", self.config)
        result = {"status": "complete", "identity": self.request_identity,
                  "truncated": self.truncated, "sample_rate": self.sample_rate,
                  "audio_seconds": len(self.audio) / self.sample_rate,
                  "weights": self.weights, "timing": self.timing,
                  "artifacts": collect_hashes(directory)}
        write_json(directory / "result.json", result)
        return result


class YuE2Pipeline:
    def __init__(self, model_dir, vae_dir, *, device="auto", memory_budget_gib=24,
                 backend="torch", generation_config=None, verify_hashes=True,
                 vae_core_frames=None, quantization="none", offload_ar=False, progress=True):
        if not isinstance(progress, bool):
            raise TypeError("progress must be True or False")
        self.progress = progress
        if backend not in {"torch", "torch-eager", "vllm"}:
            raise ValueError("backend must be torch, torch-eager, or vllm")
        if quantization not in {"none", "fp8"}:
            raise ValueError("quantization must be none or fp8")
        if not 0 < memory_budget_gib:
            raise ValueError("memory_budget_gib must be positive")
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
        self.device = torch.device(device)
        if self.device.type == "cuda" and self.device.index is None:
            self.device = torch.device("cuda", torch.cuda.current_device())
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
        torch.set_float32_matmul_precision("highest")
        self.model_dir, self.vae_dir = Path(model_dir), Path(vae_dir)
        self.backend, self.quantization = backend, quantization
        self.memory_budget_gib = float(memory_budget_gib)
        self.vae_core_frames = vae_core_frames if vae_core_frames is not None else (512 if memory_budget_gib <= 12 else 1024)
        self.offload_ar = offload_ar
        self.generation_config = generation_config or GenerationConfig()
        self.tokenizer = YuE2TextTokenizer(self.model_dir / "qwen.tiktoken")
        with self._status("Verifying model files"):
            self.weights = {"mot": model_identity(self.model_dir, verify_hashes),
                            "vae": model_identity(self.vae_dir, verify_hashes)}
        self.runtime_sha256 = identity({p.name: sha256_file(p) for p in sorted(Path(__file__).parent.glob("*.py"))})
        self._model, self._vae = None, None
        self.load_timing = {}
        if self.device.type == "cuda":
            if not torch.cuda.is_bf16_supported():
                raise RuntimeError("The unquantized preset requires CUDA BF16 support")
            total = torch.cuda.get_device_properties(self.device).total_memory
            budget = min((self.memory_budget_gib - 2) * 2**30, total - 2 * 2**30)
            if budget <= 0:
                raise ValueError("Memory budget must leave room for a 2GiB reserve")
            torch.cuda.set_per_process_memory_fraction(min(budget / total, 1), self.device)

    @classmethod
    def from_pretrained(cls, model="m-a-p/YuE2-3B", *, vae="m-a-p/YuE2-Vae",
                        revision=None, vae_revision=None, local_files_only=False,
                        token=None, cache_dir=None, progress=True, **kwargs):
        """Load a song pipeline with English progress on stderr; set progress=False to hide it."""
        if not isinstance(progress, bool):
            raise TypeError("progress must be True or False")
        start = time.perf_counter()
        saved = Path(model) / "pipeline.json"
        if saved.is_file():
            metadata = json.loads(saved.read_text())
            parent = Path(model)
            model = parent / metadata["model"]
            if vae == "m-a-p/YuE2-Vae":
                vae = parent / metadata["vae"]
            kwargs.setdefault("generation_config", GenerationConfig.from_dict(metadata["generation_config"]))
        hub = dict(local_files_only=local_files_only, token=token, cache_dir=cache_dir)
        with Progress(enabled=progress).stage("Resolving model files"):
            model_path = resolve_model(model, revision=revision, **hub)
            vae_path = resolve_model(vae, revision=vae_revision, **hub)
        result = cls(model_path, vae_path, progress=progress, **kwargs)
        result.load_timing["resolve_and_integrity_seconds"] = time.perf_counter() - start
        return result

    @contextmanager
    def _status(self, label, *, total=None, unit=None):
        # Display state never enters the request/config identity or model RNG.
        with Progress(enabled=self.progress) as reporter:
            with reporter.stage(label, total=total, unit=unit) as stage:
                yield stage

    def save_pretrained(self, directory):
        directory = Path(directory)
        if directory.exists() and any(directory.iterdir()):
            raise FileExistsError("save_pretrained needs an empty pipeline destination")
        for name, source in (("YuE2-3B", self.model_dir), ("YuE2-Vae", self.vae_dir)):
            destination = directory / name
            if destination.resolve() == source.resolve():
                continue
            copy_model_files(source, destination)
        write_json(directory / "pipeline.json", {"model": "YuE2-3B", "vae": "YuE2-Vae",
                   "generation_config": self.generation_config.to_dict(), "source_weights": self.weights})

    def _load_model(self, for_nar=False):
        loading = self._model is None or next(self._model.parameters()).device != self.device
        with self._status("Loading model") if loading else nullcontext():
            if self._model is None:
                start = time.perf_counter()
                self._model = YuE2ForCausalLM.from_pretrained(self.model_dir, local_files_only=True,
                              torch_dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
                self.load_timing["mot_load_seconds"] = time.perf_counter() - start
            if self.quantization == "fp8" and not for_nar:
                prepare_fp8_ar(self._model, self.device)
            self._model.to(self.device)
        return self._model

    def _request(self, style=None, lyrics=None, *, tags=None, **kwargs):
        if style is not None and tags is not None and style != tags:
            raise ValueError("style and tags are aliases and cannot disagree")
        style = tags if style is None else style
        if style is None or lyrics is None:
            raise ValueError("Provide style and lyrics")
        return SongRequest(style=style, lyrics=lyrics, **kwargs)

    def _generate(self, prefix, sampling, seed, phase, **kwargs):
        model = self._load_model() if self.backend != "vllm" else None
        callback = kwargs.pop("on_token", None)
        label = "Planning score" if phase == "abc" else "Generating song"
        with self._status(label, unit="tokens") as status:
            def on_output(token_phase, token):
                # The backend emits each real output once, including its end token.
                # Prefixes, provided scores and extra CFG branches are not output.
                status.advance()
                if callback is not None:
                    callback(token_phase, token)
            observed = on_output if self.progress else callback
            if self.backend == "vllm":
                result = generate_vllm(self, prefix, sampling, seed, phase, on_token=observed, **kwargs)
            else:
                result = generate_tokens(model, prefix, sampling, seed, phase,
                                         use_cuda_graph=self.backend != "torch-eager", on_token=observed, **kwargs)
            if result[2]:
                status.finish(status="truncated")
            return result

    def plan(self, style=None, lyrics=None, *, tags=None, request=None, abc_sampling=None,
             cancelled=None, on_token=None, **kwargs):
        request = request or self._request(style, lyrics, tags=tags, **kwargs)
        if request.cot == "off":
            return SymbolicPlan(request, None, [], token_prefixes(request, self.tokenizer))
        if request.abc is not None:
            with self._status("Using provided score"):
                ids = self.tokenizer.encode(request.abc)
                return SymbolicPlan(request, request.abc, ids, token_prefixes(request, self.tokenizer, ids),
                                    {"seconds": 0., "output_tokens": 0, "external_prefix_tokens": len(ids)})
        sampling = resolve_sampling(abc_sampling, self.generation_config.abc)
        ids, timing, truncated = self._generate(token_prefixes(request, self.tokenizer), sampling,
                            request.seed, "abc", cancelled=cancelled, on_token=on_token)
        return SymbolicPlan(request, self.tokenizer.decode(ids), ids,
                            token_prefixes(request, self.tokenizer, ids), timing, truncated)

    def generate_semantic(self, plan, *, sampling=None, cancelled=None, on_token=None):
        if not isinstance(plan, SymbolicPlan):
            raise TypeError("Pass the SymbolicPlan returned by pipe.plan()")
        request = plan.request
        expected = token_prefixes(request, self.tokenizer, plan.abc_ids)
        if expected != plan.prefix:
            raise ValueError("Plan prefix disagrees with request/exact ABC IDs")
        sampling = resolve_sampling(sampling, self.generation_config.semantic)
        negative = negative_prefix(request, self.tokenizer, plan.abc_ids) if request.guidance != 1 else None
        ids, timing, truncated = self._generate(plan.prefix, sampling, request.seed, "semantic",
                        negative=negative, cfg_scale=request.guidance, legacy_off=request.cot == "off",
                        cancelled=cancelled, on_token=on_token)
        return SemanticResult(plan, [int(t) - CODEC_OFFSET for t in ids], timing, truncated)

    def synthesize(self, semantic, *, cancelled=None):
        if self.backend == "vllm":
            close_vllm(self)
        if not isinstance(semantic, SemanticResult):
            raise TypeError("Pass the SemanticResult returned by generate_semantic()")
        if token_prefixes(semantic.plan.request, self.tokenizer, semantic.plan.abc_ids) != semantic.plan.prefix:
            raise ValueError("Semantic result does not retain the request's exact prefix")
        if self.quantization != "none":
            restore_ar(self._model)
        model = self._load_model(for_nar=True)
        with self._status("Synthesizing audio", unit="steps") as status:
            report = (lambda completed, total: status.update(completed, total=total)) if self.progress else None
            result = synthesize(model, semantic.plan.prefix, semantic.tokens,
                                semantic.plan.request.seed, steps=self.generation_config.ode_steps,
                                context=self.generation_config.context, offload_ar=self.offload_ar,
                                cancelled=cancelled, on_progress=report)
            return result.detach().float().cpu().numpy()

    def close(self):
        if self.backend == "vllm":
            close_vllm(self)
        self._model, self._vae = None, None
        if self.device.type == "cuda":
            torch.cuda.empty_cache()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def decode(self, latents, *, full=False, vae=None):
        with self._status("Loading audio decoder"):
            if self._model is not None:
                self._model.to("cpu")
            if self.device.type == "cuda":
                torch.cuda.empty_cache()
            if vae is not None:
                model = YuE2VAE.from_pretrained(vae, decoder_only=True, device=self.device)
            else:
                if self._vae is None:
                    self._vae = YuE2VAE.from_pretrained(self.vae_dir, decoder_only=True, device="cpu",
                                                        local_files_only=True)
                model = self._vae.to(self.device)
        z = torch.as_tensor(latents, dtype=torch.float32)
        if z.ndim == 2 and z.shape[1] == 64:
            z = z.T.unsqueeze(0)
        if z.ndim != 3 or z.shape[0] != 1 or z.shape[1] != 64:
            raise ValueError("Expected latents [T,64] or [1,64,T]")
        try:
            tiles = 1 if full else (z.shape[-1] + self.vae_core_frames - 1) // self.vae_core_frames
            with self._status("Decoding audio", total=tiles, unit="chunks") as status:
                report = (lambda completed, total: status.update(completed, total=total)) if self.progress else None
                with torch.inference_mode():
                    if full:
                        audio = model.decode(z.to(self.device)).cpu()
                        status.update(1)
                    else:
                        audio = model.decode_tiled(z, core_frames=self.vae_core_frames, halo_frames=16,
                                                   output_device="cpu", on_progress=report)
                if not torch.isfinite(audio).all():
                    raise ValueError("VAE produced non-finite audio")
                return audio[0].float().clamp(-1, 1).T.contiguous().numpy()
        finally:
            model.to("cpu")
            if self.device.type == "cuda":
                torch.cuda.empty_cache()

    def effective_config(self, request, abc_sampling=None, semantic_sampling=None):
        config = self.generation_config.to_dict()
        for key, sampling in (("abc", abc_sampling), ("semantic", semantic_sampling)):
            if sampling is not None:
                config[key] = dataclasses.asdict(resolve_sampling(sampling, getattr(self.generation_config, key)))
        defaults = GenerationConfig().to_dict()
        overrides = {k: v for k, v in config.items() if defaults.get(k) != v}
        if request.guidance != (1.01 if request.cot == "off" else 1.0):
            overrides["cfg_scale"] = request.guidance
        return {"generation": config, "overrides": overrides,
                "cot": request.cot, "cfg_scale": request.guidance,
                "cfg_negative": "instruction_only" if request.cot == "off" else "same_instruction_and_exact_abc",
                "backend": self.backend, "quantization": self.quantization,
                "model_dtype": "bfloat16", "vae_dtype": "float32", "vae_decode": "halo_crop",
                "vae_core_frames": self.vae_core_frames, "vae_halo_frames": 16,
                "device": str(self.device), "memory_budget_gib": self.memory_budget_gib,
                "offload_ar": self.offload_ar, "runtime_sha256": self.runtime_sha256,
                "decoder_release": json.loads((self.vae_dir / "config.json").read_text()).get("release_variant"),
                "validation_status": "unvalidated"}

    def __call__(self, style=None, lyrics=None, *, tags=None, abc_sampling=None,
                 semantic_sampling=None, cancelled=None, on_token=None, **kwargs):
        request = self._request(style, lyrics, tags=tags, **kwargs)
        config = self.effective_config(request, abc_sampling, semantic_sampling)
        request_id = identity({"request": request.to_dict(), "config": config, "weights": self.weights})
        start = time.perf_counter()
        plan = self.plan(request=request, abc_sampling=abc_sampling, cancelled=cancelled, on_token=on_token)
        semantic = self.generate_semantic(plan, sampling=semantic_sampling, cancelled=cancelled, on_token=on_token)
        nar_start = time.perf_counter()
        latents = self.synthesize(semantic, cancelled=cancelled)
        nar_seconds = time.perf_counter() - nar_start
        if cancelled is not None and cancelled():
            raise InterruptedError("Cancelled before VAE")
        vae_start = time.perf_counter()
        audio = self.decode(latents)
        timing = {"abc": plan.timing, "semantic": semantic.timing, "nar_seconds": nar_seconds,
                  "vae_seconds": time.perf_counter() - vae_start, "load": dict(self.load_timing),
                  "e2e_seconds": time.perf_counter() - start}
        Progress(enabled=self.progress).complete(len(audio) / 48000, timing["e2e_seconds"],
                                                truncated=plan.truncated or semantic.truncated)
        return SongResult(audio, 48000, semantic, latents, config, self.weights, timing, request_id)
# ------------------------------------------------------------------------------
# CLI (subcomandos: doctor, plan, generate, batch)
# ------------------------------------------------------------------------------

def kit_root():
    return Path(os.environ.get("YUE2_KIT", Path(__file__).resolve().parent))


def model_paths(args):
    root = kit_root()
    local_model = root / "models/YuE2-3B"
    local_vae = root / "models" / ("YuE2-Vae-legacy" if args.vae == "legacy" else "YuE2-Vae")
    model = args.model or (str(local_model) if local_model.exists() else "m-a-p/YuE2-3B")
    vae = args.vae if args.vae not in {"standard", "legacy"} else (
        str(local_vae) if local_vae.exists() else "m-a-p/" + local_vae.name)
    return model, vae


def get_pipe(args):
    model, vae = model_paths(args)
    config = GenerationConfig.from_dict(json.loads(Path(args.config).read_text())) if args.config else None
    return YuE2Pipeline.from_pretrained(model, vae=vae, revision=args.revision,
             vae_revision=args.vae_revision, device=args.device, memory_budget_gib=args.budget,
             backend=args.backend, quantization=args.quantization, offload_ar=args.offload_ar,
             local_files_only=args.offline, generation_config=config,
             vae_core_frames=512 if args.budget <= 12 else 1024,
             progress=not getattr(args, "quiet", False))


def request_kwargs(data, base=None):
    base = base or Path.cwd()
    allowed = {"style", "tags", "lyrics", "cot", "seed", "abc", "cfg_scale", "id", "abc_sampling", "semantic_sampling"}
    metadata = {"lang", "eval_index", "clip_id", "prompt"}
    unknown = set(data) - allowed - metadata - {"abc_path"}
    if unknown:
        raise ValueError(f"Campos de peticion desconocidos: {sorted(unknown)}")
    result = {k: v for k, v in data.items() if k in allowed}
    if "abc_path" in data:
        if data.get("abc") is not None:
            raise ValueError("Usa abc o abc_path, no ambos")
        result["abc"] = (base / data["abc_path"]).read_bytes().decode("utf-8")
    if data.get("prompt") is not None:
        request = SongRequest(style=result.get("style", result.get("tags")), lyrics=result["lyrics"],
                              cot=result.get("cot", "full"))
        if data["prompt"] != request.text():
            raise ValueError("El prompt literal historico no coincide con instruction/style/lyrics nativos")
    return result


def cmd_doctor(args):
    model, vae = model_paths(args)
    versions = {}
    for package in ("torch", "transformers", "huggingface-hub", "safetensors", "tiktoken", "soundfile"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    devices = []
    for i in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(i)
        devices.append({"id": i, "name": p.name, "memory_gib": p.total_memory / 2**30,
                        "compute_capability": [p.major, p.minor]})
    report = {"dependencies_ready": all(versions.values()), "versions": versions,
              "cuda": devices, "mps_available": torch.backends.mps.is_available(),
              "model": model, "vae": vae, "default_cot": "full",
              "default_cfg": {"full": 1., "melody": 1., "off": 1.01},
              "validated": False, "note": "El entorno estar listo no implica calidad ni 24GB reales."}
    if args.verify_hashes:
        report["weights"] = {"model": model_identity(resolve_model(model, local_files_only=args.offline)),
                             "vae": model_identity(resolve_model(vae, local_files_only=args.offline))}
    if args.output:
        write_json(args.output, report)
    ok = report["dependencies_ready"]
    print(_c("OK" if ok else "FALTAN DEPENDENCIAS", "g" if ok else "r"), file=sys.stderr)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if ok else 1


def _load_request_data(args):
    if args.request:
        path = Path(args.request)
        data = json.loads(path.read_text())
        base = path.parent
    else:
        data, base = {}, Path.cwd()
    for key in ("id", "style", "cot", "seed", "cfg_scale"):
        value = getattr(args, key, None)
        if value is not None:
            data[key] = value
    if args.lyrics_file:
        data["lyrics"] = Path(args.lyrics_file).read_bytes().decode("utf-8")
    elif args.lyrics is not None:
        data["lyrics"] = args.lyrics
    if args.abc_file:
        data["abc"] = Path(args.abc_file).read_bytes().decode("utf-8")
        data.pop("abc_path", None)
    if not data:
        data = {"id": "primera_cancion", "style": "pop acustico calido, piano, voz femenina",
                "lyrics": "[Verse]\nEl viento cruza la ventana\n"
                          "queda tu risa en el ayer\n[Chorus]\nque esta cancion te acompane lejos\n"
                          "y todo lo que extrano se vuelva manana"}
    return data, base


def cmd_generate(args):
    data, base = _load_request_data(args)
    kwargs = request_kwargs(data, base)
    pipe = get_pipe(args)
    directory = Path(args.output or "runs/default") / kwargs.get("id", "song")
    if args.resume and (directory / "result.json").exists():
        req_kwargs = {k: v for k, v in kwargs.items() if k not in {"abc_sampling", "semantic_sampling"}}
        request = pipe._request(**req_kwargs)
        config = pipe.effective_config(request, kwargs.get("abc_sampling"), kwargs.get("semantic_sampling"))
        expected = identity({"request": request.to_dict(), "config": config, "weights": pipe.weights})
        result = verify_result(directory, expected)
        print(json.dumps({"resumed": True, "result": str(directory / "result.json"),
                          "truncated": result["truncated"]}))
        return 0
    if directory.exists() and any(directory.iterdir()):
        raise FileExistsError(f"{directory} no esta vacio; usa --resume u otro --output")
    directory.mkdir(parents=True, exist_ok=True)
    try:
        if args.stage == "plan":
            kwargs.pop("semantic_sampling", None)
            plan = pipe.plan(**kwargs)
            plan.save(directory)
            print(_c(f"partitura guardada en {directory}", "g"), file=sys.stderr)
            print(json.dumps({"stage": "plan", "output": str(directory), "truncated": plan.truncated}))
        else:
            result = pipe(**kwargs)
            result.save_artifacts(directory)
            print(_c(f"cancion guardada en {directory}", "g"), file=sys.stderr)
            print(json.dumps({"status": "complete", "output": str(directory), "truncated": result.truncated,
                              "seconds": result.timing["e2e_seconds"]}))
        return 0
    except BaseException as exc:
        write_json(directory / "failure.json", {"status": "failed", "type": type(exc).__name__,
                                                "reason": str(exc), "request": data})
        print(_c(f"fallo: {exc}", "r"), file=sys.stderr)
        raise
    finally:
        pipe.close()


def cmd_batch(args):
    if args.concurrency != 1:
        raise ValueError("El pipeline torch minimo solo soporta concurrency=1; no compartas un pipeline en paralelo")
    path = Path(args.input)
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    ids = [r.get("id") for r in rows]
    if any(x is None for x in ids) or len(ids) != len(set(ids)):
        raise ValueError("Cada peticion del lote necesita un id unico")
    pipe = get_pipe(args)
    output = Path(args.output or "runs/batch")
    receipts, failures = [], 0
    try:
        for index, row in enumerate(rows, 1):
            if not args.quiet:
                print(_c(f"cancion {index}/{len(rows)}: {row['id']}", "b"), file=sys.stderr, flush=True)
            kwargs = request_kwargs(row, path.parent)
            if args.cot is not None:
                kwargs["cot"] = args.cot
            directory = output / row["id"]
            try:
                request = pipe._request(**{k: v for k, v in kwargs.items()
                                           if k not in {"abc_sampling", "semantic_sampling"}})
                cfg = pipe.effective_config(request, kwargs.get("abc_sampling"), kwargs.get("semantic_sampling"))
                expected = identity({"request": request.to_dict(), "config": cfg, "weights": pipe.weights})
                if args.resume and (directory / "result.json").exists():
                    receipt = verify_result(directory, expected)
                else:
                    if directory.exists() and any(directory.iterdir()):
                        raise FileExistsError("Salida no vacia para esta peticion; usa --resume u otra carpeta")
                    receipt = pipe(**kwargs).save_artifacts(directory)
                receipts.append({"id": row["id"], "status": "complete", "identity": receipt["identity"]})
            except Exception as exc:
                failures += 1
                failure = {"id": row["id"], "status": "failed", "reason": str(exc), "type": type(exc).__name__}
                write_json(directory / "failure.json", failure)
                receipts.append(failure)
            write_json(output / "batch.json", {"complete": len(receipts) == len(rows) and not failures,
                       "expected": len(rows), "failed": failures, "results": receipts})
    finally:
        pipe.close()
    print(_c(f"lote completo: {len(rows) - failures}/{len(rows)} ok", "g" if not failures else "y"),
          file=sys.stderr)
    return int(failures > 0)


def cmd_plan(args):
    args.stage = "plan"
    return cmd_generate(args)


def cmd_all_modes(args):
    data, base = _load_request_data(args)
    if data.get("abc") is not None or args.abc_file:
        raise ValueError("all-modes genera las 3 partituras el mismo; no aceptes una ABC externa")
    data.pop("cot", None)
    kwargs = request_kwargs(data, base)
    pipe = get_pipe(args)
    output = Path(args.output or "runs/all_modes") / kwargs.get("id", "song")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"{output} no esta vacio; usa otro --output")
    output.mkdir(parents=True, exist_ok=True)
    results, failures = [], 0
    try:
        for mode in ("full", "melody", "off"):
            directory = output / mode
            row_kwargs = dict(kwargs, cot=mode)
            print(_c(f"modo {mode}...", "b"), file=sys.stderr)
            try:
                result = pipe(**row_kwargs)
                result.save_artifacts(directory)
                results.append({"mode": mode, "status": "complete", "truncated": result.truncated})
            except Exception as exc:
                failures += 1
                failure = {"mode": mode, "status": "failed", "reason": str(exc), "type": type(exc).__name__}
                write_json(directory / "failure.json", failure)
                results.append(failure)
        write_json(output / "all_modes.json", {"output": str(output), "results": results, "failed": failures})
        print(json.dumps({"output": str(output), "results": results}, ensure_ascii=False))
        print(_c(f"{3 - failures}/3 modos completos", "g" if not failures else "y"), file=sys.stderr)
        return int(failures > 0)
    finally:
        pipe.close()


def cmd_decode(args):
    source = Path(args.source)
    verify_result(source)
    original = json.loads((source / "result.json").read_text())
    original_config = json.loads((source / "config.json").read_text())
    plan = SymbolicPlan.load(source)
    tokens = np.load(source / "semantic.npy", allow_pickle=False)
    if tokens.ndim != 1 or tokens.dtype.kind not in "iu":
        raise ValueError("Tokens semanticos en cache no validos")
    latents = np.load(source / "latent.npy", allow_pickle=False)
    semantic = SemanticResult(plan, tokens.tolist(), original["timing"].get("semantic", {}),
                              original["truncated"]["semantic"])
    output = Path(args.output or "runs/decode") / plan.request.id
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"{output} no esta vacio; usa otro --output")
    pipe = get_pipe(args)
    try:
        if pipe.weights["mot"] != original["weights"]["mot"]:
            raise ValueError("--model debe coincidir exactamente con el modelo de la generacion original")
        start = time.perf_counter()
        audio = pipe.decode(latents)
        elapsed = time.perf_counter() - start
        current = pipe.effective_config(plan.request)
        config = dict(original_config)
        for key in ("vae_dtype", "vae_decode", "vae_core_frames", "vae_halo_frames", "decoder_release"):
            config[key] = current[key]
        config["cached_decode"] = {
            "source_identity": original["identity"], "source_config_sha256": sha256_file(source / "config.json"),
            "runtime_sha256": pipe.runtime_sha256, "device": str(pipe.device),
            "memory_budget_gib": pipe.memory_budget_gib,
        }
        timing = {"operation": "decode_cached_latents", "vae_seconds": elapsed,
                  "semantic": semantic.timing, "source_generation": original["timing"]}
        digest = identity({"request": plan.request.to_dict(), "config": config, "weights": pipe.weights})
        song = SongResult(audio, 48000, semantic, latents, config, pipe.weights, timing, digest)
        receipt = song.save_artifacts(output)
        verify_result(output)
        if sha256_file(output / "latent.npy") != sha256_file(source / "latent.npy"):
            raise ValueError("Los latentes cambiaron al re-decodificar")
        print(_c(f"audio re-decodificado en {output}", "g"), file=sys.stderr)
        print(json.dumps({"status": "complete", "output": str(output), "identity": receipt["identity"],
                          "truncated": receipt["truncated"]}, ensure_ascii=False))
        return 0
    finally:
        pipe.close()


def build_parser():
    p = argparse.ArgumentParser(
        prog="yue_composer.py",
        description="YuE2: estilo + letra -> partitura ABC editable -> cancion")
    sub = p.add_subparsers(dest="command", required=True)
    for name in ("doctor", "generate", "plan", "batch", "all-modes", "decode"):
        q = sub.add_parser(name)
        q.add_argument("--model")
        q.add_argument("--vae", default="standard",
                       help="standard (escucha), legacy (evaluacion del paper), ruta local o repo HF")
        q.add_argument("--revision")
        q.add_argument("--vae-revision")
        q.add_argument("--device", default="auto")
        q.add_argument("--budget", type=float, default=24)
        q.add_argument("--backend", choices=("torch", "torch-eager", "vllm"), default="torch",
                       help="'vllm' usa el backend rapido opcional (requiere vllm+triton instalados)")
        q.add_argument("--quantization", choices=("none", "fp8"), default="none")
        q.add_argument("--offload-ar", action="store_true")
        q.add_argument("--offline", action="store_true")
        q.add_argument("--config")
        q.add_argument("--output")
        if name == "doctor":
            q.add_argument("--verify-hashes", action="store_true")
        elif name == "decode":
            q.add_argument("--source", required=True, help="Carpeta de una generacion previa verificada")
        else:
            q.add_argument("--cot", choices=("full", "melody", "off"))
            q.add_argument("--resume", action="store_true")
            q.add_argument("--quiet", "--no-progress", action="store_true",
                           help="Oculta el progreso de YuE2 en stderr; el resultado sigue en stdout")
            if name == "batch":
                q.add_argument("--input", required=True)
                q.add_argument("--concurrency", type=int, default=1)
            else:
                q.add_argument("--request")
                q.add_argument("--id")
                q.add_argument("--style")
                q.add_argument("--lyrics")
                q.add_argument("--lyrics-file")
                q.add_argument("--abc-file")
                q.add_argument("--seed", type=int)
                q.add_argument("--cfg-scale", type=float)
                if name == "generate":
                    q.add_argument("--stage", choices=("plan", "audio"), default="audio")
    return p


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    args = build_parser().parse_args(argv)
    handlers = {"doctor": cmd_doctor, "generate": cmd_generate, "plan": cmd_plan,
                "batch": cmd_batch, "all-modes": cmd_all_modes, "decode": cmd_decode}
    return handlers[args.command](args)


if __name__ == "__main__":
    if sys.argv[1:] == ["--worker"]:
        # Reinvocacion interna: YuE2Pipeline(backend="vllm") lanza este mismo
        # fichero como subproceso worker (ver _Worker.__init__ mas arriba).
        _run_fast_worker()
    else:
        raise SystemExit(main())
