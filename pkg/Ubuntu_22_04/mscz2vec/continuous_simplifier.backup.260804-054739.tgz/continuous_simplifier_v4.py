#!/usr/bin/env python3
"""
continuous_simplifier_v4.py
════════════════════════════════════════════════════════════════════════
LINAJE DE VERSIONES (ver v1/v2/v3 en este mismo directorio):

  v1 - target-grade continuo SIN calibrar
  v2 - calibra contra el percentil de dificultad de la propia pieza
  v3 - añade rejilla de respaldo de 6 peldaños fijos a v2
       LIMITACION: 6 peldaños son pocos. Cualquier target que caiga
       entre dos de ellos aterriza en el mismo resultado que el peldaño
       mas cercano -> saltos grandes en la zona media.

  v4 (este fichero) - EXPANDE los 6 peldaños de v3 a N_SUBSTEPS_PER_TRANSITION
      subpasos cada uno (30 por defecto). Entre cada par de peldaños
      base consecutivos, en vez de aplicar el salto a toda la pieza de
      golpe, lo aplica progresivamente compas a compas: los compases de
      MENOR peso estructural agregado (los mas prescindibles) dan el
      salto primero; el resto se queda en la version anterior hasta que
      les toca. Cada compas individual sigue usando siempre una tecnica
      de rejilla real y coherente (nunca mezcla dos rejillas dentro del
      mismo compas) -- lo que varia gradualmente es CUANTOS compases ya
      han dado el salto, no como suena cada uno por separado.

  Reutiliza reduce_graded_calibrated() de v2 sin modificarla (importada
  directamente); solo sustituye el paso de rejilla de v3.
════════════════════════════════════════════════════════════════════════
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import combined_simplifier as cs
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple

from continuous_simplifier_v2 import _raw_diff, _build_calibration, _calibrate, reduce_graded_calibrated


N_SUBSTEPS_PER_TRANSITION = 5   # 6 peldaños base -> hasta 30 finos


def _calibrated_whole_piece_grade(rh, lh, tc, xs, ys):
    if not (rh or lh):
        return 1.0
    _, raw_diff = cs.whole_piece_grade(rh, lh, tc)
    pct = _calibrate(raw_diff, xs, ys)
    return pct * 7.0 + 1.0


def _bar_importance(records: List["cs.NoteRec"]) -> Dict[int, float]:
    """Peso estructural agregado por compas (excluye notas ya protegidas
    por el suelo, que nunca entran en la rejilla de todos modos). Compases
    con menor peso total son los 'mas prescindibles' y escalan primero."""
    agg: Dict[int, float] = {}
    for r in records:
        if r.floor_protected:
            continue
        agg[r.bar] = agg.get(r.bar, 0.0) + r.weight
    return agg


def _build_fine_ladder(records0: List["cs.NoteRec"], tc, tpb: int,
                        n_substeps: int = N_SUBSTEPS_PER_TRANSITION):
    """Genera la lista fina de (records, etiqueta) recorriendo los 6
    peldaños base de cs._grid_ladder(), y entre cada par consecutivo
    insertando n_substeps rollouts progresivos por compas."""
    base_ladder = cs._grid_ladder(tpb)
    fine_stages: List[Tuple[str, List["cs.NoteRec"]]] = []

    stage_prev = records0  # version "sin rejilla" (solo suelo protegido)
    for i, (grid_ticks, max_voices) in enumerate(base_ladder):
        stage_full = cs.grid_fallback(stage_prev, tc, grid_ticks, max_voices)

        importance = _bar_importance(stage_prev)
        bars_sorted = sorted(importance, key=lambda b: importance[b])  # menos importantes primero
        n_bars_here = len(bars_sorted)

        for s in range(1, n_substeps + 1):
            frac = s / n_substeps
            k = round(frac * n_bars_here)
            escalate_bars = set(bars_sorted[:k])

            if frac >= 1.0:
                fine_stages.append((f"peldaño{i+1}.full", stage_full))
                continue

            recs_escalate = [r for r in stage_prev if r.bar in escalate_bars]
            recs_keep = [r for r in stage_prev if r.bar not in escalate_bars]
            out_escalate = cs.grid_fallback(recs_escalate, tc, grid_ticks, max_voices) if recs_escalate else []
            merged = sorted(out_escalate + recs_keep, key=lambda r: r.note.start)
            fine_stages.append((f"peldaño{i+1}.{s}/{n_substeps}", merged))

        stage_prev = stage_full  # el siguiente peldaño parte del anterior COMPLETO

    return fine_stages


def apply_fine_grid_fallback_until_target(records, tc, tpb, target_grade, xs, ys,
                                           n_substeps: int = N_SUBSTEPS_PER_TRANSITION):
    rh = [r.note for r in records if r.hand == "rh"]
    lh = [r.note for r in records if r.hand == "lh"]
    grade = _calibrated_whole_piece_grade(rh, lh, tc, xs, ys)
    if grade <= target_grade:
        return records, grade, True, "sin rejilla"

    fine_stages = _build_fine_ladder(records, tc, tpb, n_substeps)
    for label, recs in fine_stages:
        rh = [r.note for r in recs if r.hand == "rh"]
        lh = [r.note for r in recs if r.hand == "lh"]
        grade = _calibrated_whole_piece_grade(rh, lh, tc, xs, ys)
        if grade <= target_grade:
            return recs, grade, True, label
    return fine_stages[-1][1], grade, False, f"limite tras {len(fine_stages)} peldaños finos"


def combined_simplify_calibrated_fine(midi_path: str, target_grades: List[float],
                                       floor_level: str = "ursatz", split: int = 60,
                                       n_substeps: int = N_SUBSTEPS_PER_TRANSITION) -> Dict:
    result = reduce_graded_calibrated(midi_path, target_grades, floor_level=floor_level, split=split)
    tc, mid = result["tc"], result["mid"]
    xs, ys = result["calibration_xs"], result["calibration_ys"]

    levels = {}
    for t in sorted(set(target_grades), reverse=True):
        snap = result["level_snapshots"][t]
        rh = [r.note for r in snap if r.hand == "rh"]
        lh = [r.note for r in snap if r.hand == "lh"]
        achieved = _calibrated_whole_piece_grade(rh, lh, tc, xs, ys)

        if achieved <= t:
            levels[t] = dict(target=t, achieved=achieved, method="estructural",
                              n_notes=len(snap), records=snap)
        else:
            reduced, achieved2, ok, label = apply_fine_grid_fallback_until_target(
                snap, tc, mid.tpb, t, xs, ys, n_substeps)
            method = f"estructural+rejilla fina ({label})"
            levels[t] = dict(target=t, achieved=achieved2, method=method,
                              n_notes=len(reduced), records=reduced)

    return {"mid": mid, "tc": tc, "levels": levels}


def run_sweep(midi_path: str, targets: List[float], outdir: str, split: int = 60,
              n_substeps: int = N_SUBSTEPS_PER_TRANSITION):
    out = combined_simplify_calibrated_fine(midi_path, targets, split=split, n_substeps=n_substeps)
    mid, tc = out["mid"], out["tc"]
    stem = Path(midi_path).stem
    outdir_p = Path(outdir)
    outdir_p.mkdir(parents=True, exist_ok=True)
    rows = []
    csv_path = outdir_p / "sweep_results.csv"
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write("version,target,n_notes,achieved,method,path\n")
        for t in sorted(targets, reverse=True):
            lv = out["levels"][t]
            out_path = outdir_p / f"{stem}_v4fine{t:.2f}.mid"
            cs.export_grade_midi(lv["records"], mid.tpb, str(out_path), mid.tempo_map, mid.timesig_map)
            rows.append(dict(target=t, achieved=round(lv["achieved"], 3),
                              method=lv["method"], n_notes=lv["n_notes"], path=str(out_path)))
            f.write(f"v4,{t:.2f},{lv['n_notes']},{lv['achieved']:.4f},{lv['method']},{out_path}\n")
            print(f"  target-grade {t:.2f} (v4 calibrado+fino): alcanzado={lv['achieved']:.2f}  "
                  f"metodo={lv['method']}  notas={lv['n_notes']}")
    return rows


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("midi")
    ap.add_argument("--target-grade", type=float, nargs="+", required=True)
    ap.add_argument("--split", type=int, default=60)
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--substeps", type=int, default=N_SUBSTEPS_PER_TRANSITION)
    args = ap.parse_args()
    run_sweep(args.midi, args.target_grade, args.outdir, split=args.split, n_substeps=args.substeps)
