#!/usr/bin/env python3
"""
continuous_simplifier_v1.py
════════════════════════════════════════════════════════════════════════
LINAJE DE VERSIONES (ver v2/v3/v4 en este mismo directorio):

  v1 (este fichero) - target-grade CONTINUO, SIN calibrar
      Sustituye el grado entero 1-8 de combined_simplifier.py (que sale
      de round(diff*7)+1) por el valor 'diff' crudo (0..1) ya calculado
      en bar_factors() pero descartado por el round(). Permite pedir
      --target-grade 6.3, 6.75, etc.
      LIMITACION CONOCIDA: diff se compara contra constantes ABSOLUTAS
      (12 notas/seg, 14 semitonos de extension...) pensadas para
      repertorio pianistico general. Si el compas mas dificil de tu
      pieza no alcanza esos extremos absolutos, la zona alta de la
      escala (p.ej. 6.75-7.0) sale plana: nada que remover. -> resuelto
      en v2 con calibracion por percentil.
      TAMPOCO incluye rejilla de respaldo: por debajo del suelo
      estructural simplemente no baja mas. -> resuelto en v3.

  v2 - añade calibracion por percentil (ECDF) de la propia pieza
  v3 - añade rejilla de respaldo (6 peldaños) a v2
  v4 - expande la rejilla de v3 de 6 a ~30 peldaños (rollout progresivo
       por compas), evitando los saltos grandes de v3

Usa este (v1) solo si quieres ver el comportamiento SIN calibrar, p.ej.
para comparar cuanto cambia la curva al calibrar contra la pieza.
════════════════════════════════════════════════════════════════════════
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import combined_simplifier as cs
from pathlib import Path
from typing import List, Dict


def _grade_continuous(rh_bar, lh_bar, rh_ctx, lh_ctx, tc):
    """Igual que cs.bar_factors pero devuelve la escala 1..8 SIN redondear."""
    _, factors, diff = cs.bar_factors(rh_bar, lh_bar, rh_ctx, lh_ctx, tc)
    return diff * 7.0 + 1.0


def reduce_graded_continuous(midi_path: str, target_grades: List[float],
                              floor_level: str = "ursatz", split: int = 60,
                              threshold: float = 0.35) -> dict:
    mid, tc, all_notes = cs.load_notes(midi_path)
    tonic_pc, mode, spans = cs.analyze_harmony_local(all_notes, tc)
    rh_notes, lh_notes = cs.separate_hands(mid, split)

    weights_cfg = dict(cs.DEFAULT_WEIGHTS)
    num = mid.timesig_map[0][1]
    subdiv = 4
    W = cs.metric_weights(num, subdiv)

    floor, scored_mel0, scored_bass0 = cs.compute_structural_floor(
        all_notes, tc, spans, tonic_pc, mode, num, subdiv, W, weights_cfg,
        floor_level=floor_level, threshold=threshold)

    records = cs.build_note_records(all_notes, rh_notes, lh_notes, scored_mel0, scored_bass0,
                                     spans, tc, num, subdiv, W, weights_cfg, floor)

    last_tick = max(n.end for n in all_notes)
    n_bars = max(1, tc.bar(last_tick - 1))

    targets_sorted = sorted(set(target_grades), reverse=True)
    active: List[cs.NoteRec] = list(records)
    level_snapshots: Dict[float, List[cs.NoteRec]] = {}

    for bar in range(1, n_bars + 1):
        bar_t0, bar_t1 = tc.bar_range_ticks(bar)
        bar_active = [r for r in active if bar_t0 <= r.note.start < bar_t1]
        rh_bar = [r.note for r in bar_active if r.hand == "rh"]
        lh_bar = [r.note for r in bar_active if r.hand == "lh"]
        bsec0 = tc.sec(bar_t0) - 2.0
        bsec1 = tc.sec(bar_t1) + 2.0
        rh_ctx = [r.note for r in active if r.hand == "rh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
        lh_ctx = [r.note for r in active if r.hand == "lh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
        cur_grade = _grade_continuous(rh_bar, lh_bar, rh_ctx, lh_ctx, tc)

        grade_after: Dict[float, float] = {}
        candidates = [r for r in bar_active if r.candidate]
        next_target_idx = 0
        bar_snapshots: Dict[float, List[cs.NoteRec]] = {}

        while next_target_idx < len(targets_sorted) and cur_grade <= targets_sorted[next_target_idx]:
            t = targets_sorted[next_target_idx]
            grade_after[t] = cur_grade
            bar_snapshots[t] = cs._copy_bar_state(active, bar_t0, bar_t1)
            next_target_idx += 1

        def _recompute():
            bar_active_now = [r for r in active if bar_t0 <= r.note.start < bar_t1]
            rh_b = [r.note for r in bar_active_now if r.hand == "rh"]
            lh_b = [r.note for r in bar_active_now if r.hand == "lh"]
            rh_c = [r.note for r in active if r.hand == "rh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
            lh_c = [r.note for r in active if r.hand == "lh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
            return _grade_continuous(rh_b, lh_b, rh_c, lh_c, tc)

        remaining = list(candidates)
        while remaining and next_target_idx < len(targets_sorted):
            best = None
            best_ratio = -1e18
            best_delta = None
            for r in remaining:
                if r not in active:
                    continue
                active.remove(r)
                g_after = _recompute()
                active.append(r)
                delta = cur_grade - g_after
                ratio = delta / max(r.weight, 1e-6)
                if ratio > best_ratio:
                    best_ratio = ratio
                    best = r
                    best_delta = delta
            if best is None or best_delta is None or best_delta <= 0:
                break
            active.remove(best)
            cs._extend_neighbor_on_removal(active, best, bar_t0, bar_t1)
            remaining.remove(best)
            cur_grade = _recompute()
            while next_target_idx < len(targets_sorted) and cur_grade <= targets_sorted[next_target_idx]:
                t = targets_sorted[next_target_idx]
                grade_after[t] = cur_grade
                bar_snapshots[t] = cs._copy_bar_state(active, bar_t0, bar_t1)
                next_target_idx += 1

        for t in targets_sorted[next_target_idx:]:
            grade_after[t] = cur_grade
            bar_snapshots[t] = cs._copy_bar_state(active, bar_t0, bar_t1)

        for t in target_grades:
            level_snapshots.setdefault(t, [])
            level_snapshots[t].extend(bar_snapshots[t])

    grade_before_piece, _ = cs.whole_piece_grade(rh_notes, lh_notes, tc)

    return {"mid": mid, "tc": tc, "n_bars": n_bars,
            "level_snapshots": level_snapshots, "grade_before_piece": grade_before_piece}


def run_sweep(midi_path: str, targets: List[float], outdir: str, split: int = 60):
    out = reduce_graded_continuous(midi_path, targets, split=split)
    mid, tc = out["mid"], out["tc"]
    stem = Path(midi_path).stem
    outdir_p = Path(outdir)
    outdir_p.mkdir(parents=True, exist_ok=True)
    rows = []
    csv_path = outdir_p / "sweep_results.csv"
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write("version,target,n_notes,achieved,method,path\n")
        for t in sorted(targets, reverse=True):
            snap = out["level_snapshots"][t]
            rh = [r.note for r in snap if r.hand == "rh"]
            lh = [r.note for r in snap if r.hand == "lh"]
            achieved_int, achieved_diff = cs.whole_piece_grade(rh, lh, tc)
            n_notes = len(snap)
            out_path = outdir_p / f"{stem}_v1grade{t:.2f}.mid"
            cs.export_grade_midi(snap, mid.tpb, str(out_path), mid.tempo_map, mid.timesig_map)
            rows.append(dict(target=t, achieved_int=achieved_int, achieved_diff=round(achieved_diff, 4),
                              n_notes=n_notes, path=str(out_path)))
            f.write(f"v1,{t:.2f},{n_notes},{achieved_diff*7+1:.4f},sin_calibrar,{out_path}\n")
            print(f"  target-grade {t:.2f} (v1 sin calibrar): grado_entero={achieved_int}/8  "
                  f"diff={achieved_diff:.4f}  notas={n_notes}")
    return rows


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("midi")
    ap.add_argument("--target-grade", type=float, nargs="+", required=True)
    ap.add_argument("--split", type=int, default=60)
    ap.add_argument("--outdir", default=".")
    args = ap.parse_args()
    run_sweep(args.midi, args.target_grade, args.outdir, split=args.split)
