#!/usr/bin/env python3
"""
continuous_simplifier_v3.py
════════════════════════════════════════════════════════════════════════
LINAJE DE VERSIONES (ver v1/v2/v4 en este mismo directorio):

  v1 - target-grade continuo SIN calibrar
  v2 - calibra contra el percentil de dificultad de la propia pieza
       LIMITACION: sin rejilla de respaldo, se queda plano por debajo
       del suelo estructural puro.

  v3 (este fichero) - AÑADE la rejilla de respaldo de
      combined_simplifier.py (6 peldaños fijos: corchea/3voces ->
      corchea/2voces -> negra/2voces -> negra/1voz -> blanca/mono ->
      redonda/mono) a v2, para poder seguir bajando de notas por debajo
      del suelo estructural. El criterio de parada en cada peldaño usa
      el grado CALIBRADO (mismo ECDF que v2) en vez del grado absoluto
      entero de whole_piece_grade().
      LIMITACION CONOCIDA: la rejilla solo tiene 6 peldaños discretos.
      Cualquier target que caiga entre dos peldaños aterriza en el
      mismo resultado que el peldaño mas cercano -> saltos grandes en
      la zona media (p.ej. target 4.25 a 6.25 todos ~1075-1086 notas
      en las pruebas). -> resuelto en v4.

  v4 - expande la rejilla de v3 de 6 a ~30 peldaños (rollout progresivo
       por compas), evitando esos saltos grandes
════════════════════════════════════════════════════════════════════════
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import combined_simplifier as cs
import numpy as np
from pathlib import Path
from typing import List, Dict


def _raw_diff(rh_bar, lh_bar, rh_ctx, lh_ctx, tc):
    _, factors, diff = cs.bar_factors(rh_bar, lh_bar, rh_ctx, lh_ctx, tc)
    return diff


def _build_calibration(rh_notes, lh_notes, tc, n_bars):
    raws = []
    for bar in range(1, n_bars + 1):
        bar_t0, bar_t1 = tc.bar_range_ticks(bar)
        rh_bar = [n for n in rh_notes if bar_t0 <= n.start < bar_t1]
        lh_bar = [n for n in lh_notes if bar_t0 <= n.start < bar_t1]
        bsec0, bsec1 = tc.sec(bar_t0) - 2.0, tc.sec(bar_t1) + 2.0
        rh_ctx = [n for n in rh_notes if bsec0 <= tc.sec(n.start) <= bsec1]
        lh_ctx = [n for n in lh_notes if bsec0 <= tc.sec(n.start) <= bsec1]
        raws.append(_raw_diff(rh_bar, lh_bar, rh_ctx, lh_ctx, tc))
    xs = np.sort(np.array(raws))
    ys = np.linspace(0.0, 1.0, len(xs))
    return xs, ys


def _calibrate(raw_diff, xs, ys):
    return float(np.interp(raw_diff, xs, ys, left=0.0, right=1.0))


def _calibrated_whole_piece_grade(rh, lh, tc, xs, ys):
    if not (rh or lh):
        return 1.0
    _, raw_diff = cs.whole_piece_grade(rh, lh, tc)
    pct = _calibrate(raw_diff, xs, ys)
    return pct * 7.0 + 1.0


def _grid_fallback_until_target_calibrated(records, tc, tpb, target_grade, xs, ys):
    """Igual que cs.apply_grid_fallback_until_target pero comparando contra
    el grado CALIBRADO en cada peldaño en vez del entero absoluto."""
    cur = records
    rh = [r.note for r in cur if r.hand == "rh"]
    lh = [r.note for r in cur if r.hand == "lh"]
    grade = _calibrated_whole_piece_grade(rh, lh, tc, xs, ys)
    steps = 0
    for grid_ticks, max_voices in cs._grid_ladder(tpb):
        if grade <= target_grade:
            break
        cur = cs.grid_fallback(cur, tc, grid_ticks, max_voices)
        rh = [r.note for r in cur if r.hand == "rh"]
        lh = [r.note for r in cur if r.hand == "lh"]
        grade = _calibrated_whole_piece_grade(rh, lh, tc, xs, ys)
        steps += 1
    return cur, grade, grade <= target_grade, steps


def reduce_graded_calibrated(midi_path: str, target_grades: List[float],
                              floor_level: str = "ursatz", split: int = 60,
                              threshold: float = 0.35) -> dict:
    mid, tc, all_notes = cs.load_notes(midi_path)
    tonic_pc, mode, spans = cs.analyze_harmony_local(all_notes, tc)
    rh_notes, lh_notes = cs.separate_hands(mid, split)

    weights_cfg = dict(cs.DEFAULT_WEIGHTS)
    num = mid.timesig_map[0][1]
    subdiv = 4
    W = cs.metric_weights(num, subdiv)

    floor, scored_mel0, scored_bass0 = cs.compute_structural_floor(
        all_notes, tc, spans, tonic_pc, mode, num, subdiv, W, weights_cfg,
        floor_level=floor_level, threshold=threshold)

    records = cs.build_note_records(all_notes, rh_notes, lh_notes, scored_mel0, scored_bass0,
                                     spans, tc, num, subdiv, W, weights_cfg, floor)

    last_tick = max(n.end for n in all_notes)
    n_bars = max(1, tc.bar(last_tick - 1))

    xs, ys = _build_calibration(rh_notes, lh_notes, tc, n_bars)

    def _grade_calibrated(rh_bar, lh_bar, rh_ctx, lh_ctx, tc):
        raw = _raw_diff(rh_bar, lh_bar, rh_ctx, lh_ctx, tc)
        pct = _calibrate(raw, xs, ys)
        return pct * 7.0 + 1.0

    targets_sorted = sorted(set(target_grades), reverse=True)
    active: List[cs.NoteRec] = list(records)
    level_snapshots: Dict[float, List[cs.NoteRec]] = {}

    for bar in range(1, n_bars + 1):
        bar_t0, bar_t1 = tc.bar_range_ticks(bar)
        bar_active = [r for r in active if bar_t0 <= r.note.start < bar_t1]
        rh_bar = [r.note for r in bar_active if r.hand == "rh"]
        lh_bar = [r.note for r in bar_active if r.hand == "lh"]
        bsec0 = tc.sec(bar_t0) - 2.0
        bsec1 = tc.sec(bar_t1) + 2.0
        rh_ctx = [r.note for r in active if r.hand == "rh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
        lh_ctx = [r.note for r in active if r.hand == "lh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
        cur_grade = _grade_calibrated(rh_bar, lh_bar, rh_ctx, lh_ctx, tc)

        grade_after: Dict[float, float] = {}
        candidates = [r for r in bar_active if r.candidate]
        next_target_idx = 0
        bar_snapshots: Dict[float, List[cs.NoteRec]] = {}

        while next_target_idx < len(targets_sorted) and cur_grade <= targets_sorted[next_target_idx]:
            t = targets_sorted[next_target_idx]
            grade_after[t] = cur_grade
            bar_snapshots[t] = cs._copy_bar_state(active, bar_t0, bar_t1)
            next_target_idx += 1

        def _recompute():
            bar_active_now = [r for r in active if bar_t0 <= r.note.start < bar_t1]
            rh_b = [r.note for r in bar_active_now if r.hand == "rh"]
            lh_b = [r.note for r in bar_active_now if r.hand == "lh"]
            rh_c = [r.note for r in active if r.hand == "rh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
            lh_c = [r.note for r in active if r.hand == "lh" and bsec0 <= tc.sec(r.note.start) <= bsec1]
            return _grade_calibrated(rh_b, lh_b, rh_c, lh_c, tc)

        remaining = list(candidates)
        while remaining and next_target_idx < len(targets_sorted):
            best = None
            best_ratio = -1e18
            best_delta = None
            for r in remaining:
                if r not in active:
                    continue
                active.remove(r)
                g_after = _recompute()
                active.append(r)
                delta = cur_grade - g_after
                ratio = delta / max(r.weight, 1e-6)
                if ratio > best_ratio:
                    best_ratio = ratio
                    best = r
                    best_delta = delta
            if best is None or best_delta is None or best_delta <= 0:
                break
            active.remove(best)
            cs._extend_neighbor_on_removal(active, best, bar_t0, bar_t1)
            remaining.remove(best)
            cur_grade = _recompute()
            while next_target_idx < len(targets_sorted) and cur_grade <= targets_sorted[next_target_idx]:
                t = targets_sorted[next_target_idx]
                grade_after[t] = cur_grade
                bar_snapshots[t] = cs._copy_bar_state(active, bar_t0, bar_t1)
                next_target_idx += 1

        for t in targets_sorted[next_target_idx:]:
            grade_after[t] = cur_grade
            bar_snapshots[t] = cs._copy_bar_state(active, bar_t0, bar_t1)

        for t in target_grades:
            level_snapshots.setdefault(t, [])
            level_snapshots[t].extend(bar_snapshots[t])

    return {"mid": mid, "tc": tc, "n_bars": n_bars,
            "level_snapshots": level_snapshots, "xs": xs, "ys": ys}


def combined_simplify_calibrated(midi_path: str, target_grades: List[float],
                                  floor_level: str = "ursatz", split: int = 60) -> Dict:
    result = reduce_graded_calibrated(midi_path, target_grades, floor_level=floor_level, split=split)
    tc, mid, xs, ys = result["tc"], result["mid"], result["xs"], result["ys"]

    levels = {}
    for t in sorted(set(target_grades), reverse=True):
        snap = result["level_snapshots"][t]
        rh = [r.note for r in snap if r.hand == "rh"]
        lh = [r.note for r in snap if r.hand == "lh"]
        achieved = _calibrated_whole_piece_grade(rh, lh, tc, xs, ys)

        if achieved <= t:
            levels[t] = dict(target=t, achieved=achieved, method="estructural",
                              n_notes=len(snap), records=snap)
        else:
            reduced, achieved2, ok, steps = _grid_fallback_until_target_calibrated(
                snap, tc, mid.tpb, t, xs, ys)
            method = "estructural+rejilla" if ok else f"estructural+rejilla (limite tras {steps} peldaños)"
            levels[t] = dict(target=t, achieved=achieved2, method=method,
                              n_notes=len(reduced), records=reduced)

    return {"mid": mid, "tc": tc, "levels": levels}


def run_sweep(midi_path: str, targets: List[float], outdir: str, split: int = 60):
    out = combined_simplify_calibrated(midi_path, targets, split=split)
    mid, tc = out["mid"], out["tc"]
    stem = Path(midi_path).stem
    outdir_p = Path(outdir)
    outdir_p.mkdir(parents=True, exist_ok=True)
    rows = []
    csv_path = outdir_p / "sweep_results.csv"
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write("version,target,n_notes,achieved,method,path\n")
        for t in sorted(targets, reverse=True):
            lv = out["levels"][t]
            out_path = outdir_p / f"{stem}_v3grid{t:.2f}.mid"
            cs.export_grade_midi(lv["records"], mid.tpb, str(out_path), mid.tempo_map, mid.timesig_map)
            rows.append(dict(target=t, achieved=round(lv["achieved"], 3),
                              method=lv["method"], n_notes=lv["n_notes"], path=str(out_path)))
            f.write(f"v3,{t:.2f},{lv['n_notes']},{lv['achieved']:.4f},{lv['method']},{out_path}\n")
            print(f"  target-grade {t:.2f} (v3 calibrado+rejilla): alcanzado={lv['achieved']:.2f}  "
                  f"metodo={lv['method']}  notas={lv['n_notes']}")
    return rows


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("midi")
    ap.add_argument("--target-grade", type=float, nargs="+", required=True)
    ap.add_argument("--split", type=int, default=60)
    ap.add_argument("--outdir", default=".")
    args = ap.parse_args()
    run_sweep(args.midi, args.target_grade, args.outdir, split=args.split)
