#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────
# compare_versions.sh
#
# Ejecuta continuous_simplifier_v1.py, v2.py, v3.py y v4.py sobre el
# mismo MIDI con el mismo barrido de target-grade (1.0 a 8.0), cada una
# en su propia subcarpeta, y junta los resultados en un CSV comparativo
# para poder ver de un vistazo cuantas notas produce cada version en
# cada nivel.
#
# RUTAS RELATIVAS: este script espera encontrar los 4
# continuous_simplifier_v*.py Y combined_simplifier.py en el MISMO
# directorio donde vive este propio script (SCRIPT_DIR, calculado mas
# abajo) -- es decir, el directorio donde ya tienes el resto de tus
# herramientas no-continuas. No hace falta editar rutas si copias este
# script junto a ellas.
#
# USO:
#   ./compare_versions.sh <fichero.mid> [outdir] [step] [split] [substeps]
#
#   fichero.mid   ruta al MIDI de entrada (obligatorio, relativa o absoluta)
#   outdir        carpeta base de salida (por defecto: ./out_compare)
#   step          paso entre target-grades (por defecto: 0.25)
#   split         pitch MIDI que separa mano derecha/izquierda (por defecto: 60)
#   substeps      subpasos por transicion de rejilla, solo usado por v4
#                 (por defecto: 5 -> 30 peldaños finos)
#
# SALIDA:
#   outdir/v1/*.mid, outdir/v1/sweep_results.csv
#   outdir/v2/*.mid, outdir/v2/sweep_results.csv
#   outdir/v3/*.mid, outdir/v3/sweep_results.csv
#   outdir/v4/*.mid, outdir/v4/sweep_results.csv
#   outdir/comparison_all_versions.csv   <- las 4 CSV concatenadas
#
# EJEMPLOS:
#   ./compare_versions.sh what_could_have_been.mid
#   ./compare_versions.sh what_could_have_been.mid ./out 0.5      # mas rapido, paso mas ancho
#   ./compare_versions.sh what_could_have_been.mid ./out 0.25 60 8
# ─────────────────────────────────────────────────────────────────────────
set -euo pipefail

MIDI="${1:?Uso: $0 <fichero.mid> [outdir] [step] [split] [substeps]}"
OUTDIR="${2:-./out_compare}"
STEP="${3:-0.25}"
SPLIT="${4:-60}"
SUBSTEPS="${5:-5}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -f "$MIDI" ]]; then
    echo "[ERROR] No se encuentra el fichero MIDI: $MIDI" >&2
    exit 1
fi
for v in 1 2 3 4; do
    if [[ ! -f "$SCRIPT_DIR/continuous_simplifier_v${v}.py" ]]; then
        echo "[ERROR] No se encuentra continuous_simplifier_v${v}.py en $SCRIPT_DIR" >&2
        exit 1
    fi
done
if [[ ! -f "$SCRIPT_DIR/combined_simplifier.py" ]]; then
    echo "[ERROR] No se encuentra combined_simplifier.py en $SCRIPT_DIR" >&2
    echo "        Copia este script al mismo directorio que tus herramientas no-continuas." >&2
    exit 1
fi

mkdir -p "$OUTDIR"

# genera la lista de target-grades de 1.0 a 8.0 en pasos de $STEP con
# awk (evita problemas de coma flotante de bash/seq con locales distintos)
TARGETS=$(awk -v step="$STEP" 'BEGIN {
    for (t = 1.0; t <= 8.0 + 1e-9; t += step) printf "%.4f ", t
}')

echo "════════════════════════════════════════════════════════════════"
echo "  Comparativa continuous_simplifier v1 vs v2 vs v3 vs v4"
echo "  MIDI de entrada : $MIDI"
echo "  Carpeta salida  : $OUTDIR"
echo "  Paso            : $STEP"
echo "  Split MD/MI     : $SPLIT"
echo "  Subpasos (v4)   : $SUBSTEPS"
echo "  target-grades   : $TARGETS"
echo "════════════════════════════════════════════════════════════════"

echo "version,target,n_notes,achieved,method,path" > "$OUTDIR/comparison_all_versions.csv"

run_version () {
    local v="$1"
    shift
    local subdir="$OUTDIR/v${v}"
    mkdir -p "$subdir"
    echo
    echo "── v${v} ──────────────────────────────────────────────────────"
    python3 "$SCRIPT_DIR/continuous_simplifier_v${v}.py" "$MIDI" \
        --target-grade $TARGETS \
        --outdir "$subdir" \
        --split "$SPLIT" \
        "$@"
    tail -n +2 "$subdir/sweep_results.csv" >> "$OUTDIR/comparison_all_versions.csv"
}

run_version 1
run_version 2
run_version 3
run_version 4 --substeps "$SUBSTEPS"

echo
echo "════════════════════════════════════════════════════════════════"
echo "Listo. Por version en: $OUTDIR/v{1,2,3,4}/ (ficheros .mid + sweep_results.csv)"
echo "Comparativa conjunta  : $OUTDIR/comparison_all_versions.csv"
echo "════════════════════════════════════════════════════════════════"
