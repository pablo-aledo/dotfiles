"""
Suite de pruebas de adaptive_layer_composer_spec.md §5, contra las
implementaciones de fallback interno (sin depender del resto del
ecosistema, que no está presente en este entorno de pruebas). Cubre:

  §5.1 layer_graph_composer.py
    1. Sin colisión de registro
    2. Tensión dentro de tolerancia (varios tension_target)
    3. Sincronía compartida (esqueleto Y capas heredan el acorde de llegada)
    4. Reintento acotado -> error explícito, nunca bucle infinito

  §5.2 adaptive_playback_runtime.py
    1. Vertical layering ordenado
    2. Transición diferida a sync point
    3. Rechazo de transición no permitida
    4. Determinismo de --simulate-random
    5. Smoke test extremo a extremo
"""
import json
import random
from pathlib import Path

import pytest

import layer_graph_composer as lgc
import adaptive_playback_runtime as apr


# ─────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────

def make_graph(shared_chord="I"):
    return lgc.GraphSpec.from_dict({
        "shared_transition_chord": shared_chord,
        "states": [
            {
                "name": "calma",
                "tension_target": 0.2,
                "layers": [
                    {"name": "cuerdas", "register_band": [48, 63], "instrument": "cuerdas_calidas",
                     "activation_threshold": 0.0, "always_on": True},
                    {"name": "coro", "register_band": [65, 79], "instrument": "coro_sereno",
                     "activation_threshold": 0.4},
                ],
                "sync_points_beats": [16.0, 32.0],
                "transitions_to": ["combate"],
            },
            {
                "name": "combate",
                "tension_target": 0.6,
                "layers": [
                    {"name": "percusion", "register_band": [35, 50], "instrument": "percusion_tribal",
                     "activation_threshold": 0.0, "always_on": True},
                    {"name": "metales", "register_band": [52, 66], "instrument": "metales_triunfo",
                     "activation_threshold": 0.5},
                    {"name": "cuerdas_agitadas", "register_band": [68, 84], "instrument": "cuerdas_tension",
                     "activation_threshold": 0.3},
                ],
                "sync_points_beats": [16.0, 32.0],
                "transitions_to": ["calma"],
            },
        ],
    })


class Args:
    """Objeto simple con los mismos atributos que argparse.Namespace,
    para llamar a compose_layer_pack/compose_state directamente en tests."""
    def __init__(self, **kw):
        self.out_dir = kw.get("out_dir", "layer_pack")
        self.tension_tolerance = kw.get("tension_tolerance", 0.12)
        self.max_retries = kw.get("max_retries", 3)
        self.render_audio = kw.get("render_audio", False)
        self.bars_per_state = kw.get("bars_per_state", 8)
        self.tempo = kw.get("tempo", 120.0)
        self.register_overlap_tolerance = kw.get("register_overlap_tolerance", 2)
        self.collision_max_retries = kw.get("collision_max_retries", 3)
        self.seed = kw.get("seed", 42)
        self.sample_rate = kw.get("sample_rate", 22050)
        self.verbose = kw.get("verbose", False)


@pytest.fixture
def pack(tmp_path):
    graph = make_graph()
    args = Args(out_dir=str(tmp_path / "pack"))
    manifest = lgc.compose_layer_pack(graph, Path(args.out_dir), args)
    return manifest, Path(args.out_dir)


# ─────────────────────────────────────────────────────────────────────────
# §5.1.1 — Sin colisión de registro: contenido real dentro de register_band
# ─────────────────────────────────────────────────────────────────────────

def test_layers_stay_within_declared_register_band(pack):
    manifest, out_dir = pack
    for state in manifest.graph.states:
        for layer in state.layers:
            path = manifest.layer_files[(state.name, layer.name)]
            note_range = lgc.actual_note_range(Path(path))
            assert note_range is not None, f"{state.name}/{layer.name} sin notas"
            lo, hi = note_range
            band_lo, band_hi = layer.register_band
            assert band_lo <= lo and hi <= band_hi, (
                f"{state.name}/{layer.name}: rango real {note_range} fuera de "
                f"la banda declarada {layer.register_band}"
            )


def test_no_register_collision_between_layers_of_same_state(pack):
    manifest, out_dir = pack
    for state in manifest.graph.states:
        ranges = {}
        for layer in state.layers:
            path = manifest.layer_files[(state.name, layer.name)]
            r = lgc.actual_note_range(Path(path))
            if r:
                ranges[layer.name] = r
        collisions = lgc.check_register_collisions(ranges, tolerance_semitones=2)
        assert collisions == [], f"colisión de registro en estado {state.name!r}: {collisions}"


# ─────────────────────────────────────────────────────────────────────────
# §5.1.2 — Tensión dentro de tolerancia para varios tension_target
# ─────────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("target", [0.15, 0.3, 0.45, 0.6])
def test_skeleton_tension_within_tolerance(tmp_path, target):
    state = lgc.StateSpec.from_dict({
        "name": "s", "tension_target": target,
        "layers": [], "sync_points_beats": [], "transitions_to": [],
    })
    rng = random.Random(1)
    out_path = tmp_path / "s.skeleton.mid"
    score = lgc.generate_skeleton(
        state, out_path, bars=8, tempo=120.0,
        tolerance=0.15, max_retries=5, rng=rng, verbose=False,
    )
    assert abs(score - target) <= 0.15


# ─────────────────────────────────────────────────────────────────────────
# §5.1.3 — Sincronía compartida: esqueleto Y todas las capas cadencian sobre
#          shared_transition_chord justo antes de cada sync point
# ─────────────────────────────────────────────────────────────────────────

def test_all_layers_inherit_shared_transition_chord_at_syncpoints(pack):
    manifest, out_dir = pack
    target_pcs = set(lgc._chord_symbol_to_pitch_classes("I"))

    for state in manifest.graph.states:
        for sync_beat in state.sync_points_beats:
            bar_start = sync_beat - 4.0
            # esqueleto
            skeleton_path = Path(manifest.skeleton_files[state.name])
            pcs = _pitch_classes_in_window(skeleton_path, bar_start, sync_beat)
            assert pcs, f"esqueleto {state.name} sin notas en compás de cadencia"
            assert pcs <= target_pcs, (
                f"esqueleto {state.name}: pitch-classes {pcs} no están todas en "
                f"el acorde compartido {target_pcs} antes de beat={sync_beat}"
            )
            # cada capa
            for layer in state.layers:
                layer_path = Path(manifest.layer_files[(state.name, layer.name)])
                pcs_layer = _pitch_classes_in_window(layer_path, bar_start, sync_beat)
                assert pcs_layer, f"{state.name}/{layer.name} sin notas en compás de cadencia"
                assert pcs_layer <= target_pcs, (
                    f"{state.name}/{layer.name}: pitch-classes {pcs_layer} no heredan "
                    f"el punto de llegada del esqueleto ({target_pcs}) antes de beat={sync_beat}"
                )


def _pitch_classes_in_window(midi_path: Path, beat_start: float, beat_end: float) -> set:
    import mido

    mid = mido.MidiFile(str(midi_path))
    pcs = set()
    for track in mid.tracks:
        abs_tick = 0
        for msg in track:
            abs_tick += msg.time
            if msg.type == "note_on" and msg.velocity > 0:
                beat_pos = abs_tick / mid.ticks_per_beat
                if beat_start <= beat_pos < beat_end:
                    pcs.add(msg.note % 12)
    return pcs


# ─────────────────────────────────────────────────────────────────────────
# §5.1.4 — Reintento acotado: falla explícitamente, nunca en bucle infinito
# ─────────────────────────────────────────────────────────────────────────

def test_skeleton_generation_fails_explicitly_after_max_retries(tmp_path, monkeypatch):
    state = lgc.StateSpec.from_dict({
        "name": "imposible", "tension_target": 0.5,
        "layers": [], "sync_points_beats": [], "transitions_to": [],
    })

    # Forzar que la validación de tensión falle SIEMPRE, sin importar el candidato.
    monkeypatch.setattr(lgc, "score_tension", lambda *a, **kw: 0.0)

    rng = random.Random(1)
    out_path = tmp_path / "imposible.skeleton.mid"
    with pytest.raises(lgc.SkeletonToleranceExceeded):
        lgc.generate_skeleton(
            state, out_path, bars=8, tempo=120.0,
            tolerance=0.1, max_retries=3, rng=rng, verbose=False,
        )


def test_register_collision_fails_explicitly_when_bands_genuinely_overlap(tmp_path):
    # Dos capas cuyas bandas declaradas solapan mucho más que la tolerancia:
    # ninguna regeneración de "capa infractora" puede arreglarlo (la banda
    # es la misma en cada reintento) -> debe fallar explícitamente, nunca
    # aceptar en silencio ni bucle infinito.
    graph = lgc.GraphSpec.from_dict({
        "shared_transition_chord": None,
        "states": [{
            "name": "choque",
            "tension_target": 0.3,
            "layers": [
                {"name": "a", "register_band": [48, 67], "instrument": "cuerdas", "activation_threshold": 0.0, "always_on": True},
                {"name": "b", "register_band": [55, 74], "instrument": "coro", "activation_threshold": 0.0, "always_on": True},
            ],
            "sync_points_beats": [],
            "transitions_to": [],
        }],
    })
    args = Args(out_dir=str(tmp_path / "pack"), collision_max_retries=2)
    with pytest.raises(lgc.RegisterCollisionUnresolved):
        lgc.compose_state(graph, graph.states[0], Path(args.out_dir), args, random.Random(1))


# ─────────────────────────────────────────────────────────────────────────
# §5.2.1 — Vertical layering ordenado
# ─────────────────────────────────────────────────────────────────────────

def test_vertical_layering_activates_in_threshold_order(pack):
    manifest, out_dir = pack
    events = [
        apr.IntensityEvent(dt=1.0, intensity=0.0),
        apr.IntensityEvent(dt=1.0, intensity=0.1),
        apr.IntensityEvent(dt=1.0, intensity=0.5),
        apr.IntensityEvent(dt=1.0, intensity=0.9),
    ]
    log = apr.run(manifest, events, str(out_dir / "preview.wav"), start_state="calma")
    layer_events = [e for e in log.entries if e["type"] == "layers_changed"]

    # 'cuerdas' (always_on) activa desde el primer instante.
    assert "cuerdas" in layer_events[0]["active"]
    assert layer_events[0]["at_time_s"] == pytest.approx(0.0)

    # 'coro' (threshold 0.4) sólo debe activarse cuando la intensidad llega
    # a 0.5 (evento en t=2.0), nunca antes: ningún registro de capas
    # anterior a ese instante debe mostrarla activa.
    activations = [e for e in layer_events if "coro" in e["activated"]]
    assert len(activations) == 1
    assert activations[0]["at_time_s"] == pytest.approx(2.0)
    assert all("coro" not in e["active"] for e in layer_events if e["at_time_s"] < 2.0)


# ─────────────────────────────────────────────────────────────────────────
# §5.2.2 — Transición diferida a sync point
# ─────────────────────────────────────────────────────────────────────────

def test_transition_deferred_until_next_syncpoint(pack):
    manifest, out_dir = pack
    # tempo 120bpm -> 0.5s/beat; sync points en beat 16 y 32 -> a 8s y 16s.
    events = [
        apr.IntensityEvent(dt=2.0, intensity=0.1),
        apr.IntensityEvent(dt=2.0, intensity=0.1, requested_state="combate"),  # a mitad de loop
        apr.IntensityEvent(dt=2.0, intensity=0.1),
        apr.IntensityEvent(dt=2.0, intensity=0.1),
        apr.IntensityEvent(dt=2.0, intensity=0.1),  # cruza beat 16 (8s) aquí
    ]
    log = apr.run(manifest, events, str(out_dir / "preview.wav"), start_state="calma")
    transitions = log.transitions()
    assert len(transitions) == 1
    assert transitions[0]["at_beat"] == pytest.approx(16.0)
    # La transición no debe registrarse antes de que se solicitó (t=2.0),
    # y por construcción del grafo (sync points en beat 16/32, 120bpm) sólo
    # puede aplicarse al cruzar beat 16 (dentro del evento que lo cruza).
    requested_at = 2.0
    assert transitions[0]["at_time_s"] >= requested_at


# ─────────────────────────────────────────────────────────────────────────
# §5.2.3 — Rechazo de transición no permitida
# ─────────────────────────────────────────────────────────────────────────

def test_rejects_transition_not_in_transitions_to(pack):
    manifest, out_dir = pack
    events = [
        apr.IntensityEvent(dt=1.0, intensity=0.1, requested_state="estado_inexistente"),
        apr.IntensityEvent(dt=1.0, intensity=0.1),
    ]
    log = apr.run(manifest, events, str(out_dir / "preview.wav"), start_state="calma")
    assert len(log.transitions()) == 0
    rejections = log.rejections()
    assert len(rejections) == 1
    assert rejections[0]["requested_state"] == "estado_inexistente"
    assert rejections[0]["current_state"] == "calma"


# ─────────────────────────────────────────────────────────────────────────
# §5.2.4 — Determinismo de --simulate-random
# ─────────────────────────────────────────────────────────────────────────

def test_simulate_random_is_deterministic(pack):
    manifest, out_dir = pack
    events_a = apr.simulate_random_events(manifest.graph, duration=20, seed=99)
    events_b = apr.simulate_random_events(manifest.graph, duration=20, seed=99)
    assert [e.__dict__ for e in events_a] == [e.__dict__ for e in events_b]

    log_a = apr.run(manifest, events_a, str(out_dir / "a.wav"), start_state="calma")
    log_b = apr.run(manifest, events_b, str(out_dir / "b.wav"), start_state="calma")
    assert (out_dir / "a.wav").read_bytes() == (out_dir / "b.wav").read_bytes()
    assert log_a.to_dict() == log_b.to_dict()


# ─────────────────────────────────────────────────────────────────────────
# Modo interactivo (headless, sin dispositivo de audio real)
# ─────────────────────────────────────────────────────────────────────────

def test_playback_session_step_matches_batch_run(pack):
    """El refactor a PlaybackSession no debe cambiar el comportamiento de
    run(): procesar los eventos uno a uno con .step() debe dar exactamente
    el mismo log y el mismo audio que run()."""
    manifest, out_dir = pack
    events = apr.simulate_random_events(manifest.graph, duration=15, seed=3)

    log_a = apr.run(manifest, events, str(out_dir / "a.wav"), start_state="calma")

    session = apr.PlaybackSession(manifest, start_state="calma")
    chunks = [session.step(e) for e in events]
    import numpy as np
    apr._write_wav(str(out_dir / "b.wav"), np.concatenate(chunks), manifest.sample_rate)

    assert (out_dir / "a.wav").read_bytes() == (out_dir / "b.wav").read_bytes()
    assert log_a.to_dict() == session.log.to_dict()


def test_live_controller_intensity_clamped_and_nudge():
    controller = apr.LiveController(initial_intensity=0.5)
    controller.set_intensity(1.5)
    assert controller.intensity == 1.0
    controller.set_intensity(-0.5)
    assert controller.intensity == 0.0
    controller.set_intensity(0.5)
    controller.nudge(0.2)
    assert controller.intensity == pytest.approx(0.7)


def test_live_controller_requested_state_popped_once():
    controller = apr.LiveController()
    assert controller.pop_requested_state() is None
    controller.request_state("combate")
    assert controller.pop_requested_state() == "combate"
    assert controller.pop_requested_state() is None


def test_interactive_headless_applies_transition_and_records(pack, monkeypatch):
    """Simula una sesión --interactive --headless completa: parchea input()
    para reproducir un guion de comandos con pausas de tiempo real (via
    time.sleep real, breve) para que el temporizador headless tenga ocasión
    de cruzar el sync point y aplicar la transición solicitada."""
    manifest, out_dir = pack
    import time as _time

    # tempo 120bpm, sync points en beat 16/32 -> 8s/16s de wall-clock.
    # Usamos un blocksize grande y dt correspondiente para no necesitar
    # esperar 8s reales en el test: en su lugar, dirigimos la sesión
    # directamente sobre PlaybackSession con eventos sintéticos que imitan
    # lo que el ticker headless produciría, verificando el mismo camino de
    # código que _headless_ticker/produce_chunk usan internamente.
    session = apr.PlaybackSession(manifest, start_state="calma")
    controller = apr.LiveController(initial_intensity=0.5)

    def produce_chunk(n_frames):
        dt = n_frames / manifest.sample_rate
        intensity = controller.intensity
        requested = controller.pop_requested_state()
        event = apr.IntensityEvent(dt=dt, intensity=intensity, requested_state=requested)
        return session.step(event)

    controller.request_state("combate")
    # avanzar en pasos de 1s hasta sobrepasar el sync point en beat 16 (8s)
    for _ in range(10):
        produce_chunk(manifest.sample_rate)  # 1 segundo por paso

    assert session.current_state == "combate"
    assert len(session.log.transitions()) == 1
    assert session.log.transitions()[0]["at_beat"] == pytest.approx(16.0)


def test_interactive_rejects_unknown_state_without_crashing(pack):
    manifest, out_dir = pack
    session = apr.PlaybackSession(manifest, start_state="calma")
    # get_state debe lanzar KeyError para un nombre inexistente, tal y como
    # usa _command_loop para validar antes de aceptar el comando 'state'.
    with pytest.raises(KeyError):
        apr.get_state(manifest.graph, "no_existe")
    # y la sesión debe seguir funcionando con normalidad después:
    chunk = session.step(apr.IntensityEvent(dt=0.5, intensity=0.2))
    assert chunk is not None

def test_end_to_end_smoke(tmp_path):
    graph = make_graph()
    args = Args(out_dir=str(tmp_path / "pack"), render_audio=True, sample_rate=22050)
    manifest = lgc.compose_layer_pack(graph, Path(args.out_dir), args)

    events = apr.simulate_random_events(manifest.graph, duration=120, seed=7)
    out_wav = tmp_path / "preview.wav"
    log = apr.run(manifest, events, str(out_wav), start_state="calma")

    assert out_wav.exists()
    import wave
    with wave.open(str(out_wav), "rb") as wf:
        duration_s = wf.getnframes() / wf.getframerate()
    assert duration_s == pytest.approx(120.0, abs=0.5)
    assert len(log.transitions()) >= 1
