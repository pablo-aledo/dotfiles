#!/usr/bin/env python3
r"""
║                   ADAPTIVE PLAYBACK RUNTIME  v1.0                            ║
║       Reproducción/mezcla de referencia para música adaptativa por capas     ║
║                                                                              ║
║  Programa 2 de 2 (ver layer_graph_composer.py para el Programa 1). Consume  ║
║  un layer_pack/manifest.json (LayerPackManifest) y un flujo de eventos de   ║
║  intensidad, y decide qué capas están activas y cuándo se permite una       ║
║  transición de estado, produciendo una mezcla de previsualización en WAV.   ║
║  No compone nada — sólo reproduce/mezcla lo que el Programa 1 ya generó,    ║
║  según las reglas del grafo (vertical layering + horizontal re-sequencing). ║
║                                                                              ║
║  ALCANCE (documentar siempre, ver spec §6): esto es una implementación de   ║
║  referencia para validar el DISEÑO del grafo y generar previsualizaciones — ║
║  NO sustituye a middleware de audio de videojuego real (Wwise/FMOD) ni      ║
║  integra con ningún motor de juego. Llevarlo a producción real requeriría   ║
║  ese trabajo adicional, específico por motor, fuera de alcance aquí.        ║
║                                                                              ║
║  REGLAS:                                                                     ║
║    Vertical layering    — activación/desactivación continua de capas según  ║
║                            activation_threshold vs. intensidad actual, sin   ║
║                            esperar a ningún punto de sincronía. Rampa de     ║
║                            crossfade (default 150 ms) al cambiar de estado   ║
║                            activo por capa — nunca mute/unmute instantáneo.  ║
║    Horizontal re-sequencing — un cambio de estado solicitado NO se ejecuta   ║
║                            de inmediato: queda en cola y se aplica sólo al   ║
║                            llegar al siguiente sync_points_beats del estado  ║
║                            actual, y sólo si el destino está en              ║
║                            transitions_to. Una transición no permitida se    ║
║                            ignora explícitamente (con aviso en el log),      ║
║                            nunca se ejecuta igualmente ni se descarta en     ║
║                            silencio.                                         ║
║                                                                              ║
║  MODOS:                                                                      ║
║    Por lotes (por defecto) — procesa una lista de IntensityEvent (fichero   ║
║      --events o --simulate-random) y escribe un único WAV de una vez.       ║
║    --interactive             — abre un stream de audio en tiempo real       ║
║      (sounddevice/PortAudio) y expone una consola de comandos en la misma   ║
║      terminal para variar intensidad, pedir transiciones de estado, y       ║
║      ajustar el crossfade MIENTRAS suena. Si no hay dispositivo de audio    ║
║      disponible (o --headless), cae a un modo "headless": mismo bucle de    ║
║      control y de estado, ritmo de tiempo real simulado con temporizador,   ║
║      pero sin salida de sonido — útil para probar el diseño del grafo sin   ║
║      hardware de audio (p.ej. en un servidor/CI), y es como se validó este  ║
║      módulo en el entorno de desarrollo.                                    ║
║                                                                              ║
║  COMANDOS EN MODO --interactive (consola, mientras suena):                  ║
║    i 0.7 | intensity 0.7   Fija la intensidad a 0.7 (0-1)                  ║
║    +  / -                   Sube/baja la intensidad 0.05                    ║
║    state combate            Solicita transición a 'combate' (se aplica en   ║
║                              el próximo sync point si el grafo lo permite;  ║
║                              si no, se rechaza y queda en el log)           ║
║    crossfade 300            Cambia la rampa de crossfade a 300 ms al vuelo  ║
║    status                   Imprime estado/intensidad/beat/capas activas    ║
║    help                     Muestra estos comandos                          ║
║    q | quit | exit          Termina la sesión (guarda --log/--record)      ║
║                                                                              ║
║  USO:                                                                        ║
║    python adaptive_playback_runtime.py layer_pack/manifest.json \           ║
║        --events events.json --out preview.wav                               ║
║    python adaptive_playback_runtime.py layer_pack/manifest.json \           ║
║        --simulate-random --duration 120 --seed 7 --out preview.wav \        ║
║        --log transitions.json                                                ║
║    python adaptive_playback_runtime.py layer_pack/manifest.json \           ║
║        --interactive --initial-intensity 0.3 --log session.json \           ║
║        --record session.wav                                                  ║
║                                                                              ║
║  OPCIONES:                                                                   ║
║    manifest.json         Ruta al LayerPackManifest (salida del Programa 1)  ║
║    --events FILE         Lista de IntensityEvent en JSON (timestamp,        ║
║                          intensidad 0-1, estado solicitado opcional)        ║
║    --simulate-random     Genera un paseo aleatorio de intensidad en vez de  ║
║                          requerir --events                                   ║
║    --duration N          Duración en segundos de --simulate-random          ║
║    --seed S              Semilla determinista de --simulate-random          ║
║    --interactive         Modo en tiempo real con consola de comandos (ver   ║
║                          arriba); sustituye a --events/--simulate-random    ║
║    --initial-intensity F Intensidad inicial en --interactive (default: 0.3) ║
║    --blocksize N         Tamaño de buffer de audio en frames (def.: 1024)   ║
║    --device D            Dispositivo de salida (índice o nombre; sounddevice)║
║    --headless            Fuerza el modo sin dispositivo de audio real       ║
║    --record FILE         Graba toda la sesión --interactive a un WAV        ║
║    --out FILE            WAV de previsualización mezclado (modo por lotes;  ║
║                          obligatorio salvo en --interactive)                ║
║    --log FILE            RuntimeLog (transiciones, rechazos, cambios de     ║
║                          capas activas) en JSON                              ║
║    --crossfade-ms N      Duración de la rampa de activación/desactivación   ║
║                          de capa (default: 150)                              ║
║    --start-state NAME    Estado inicial (default: primer estado del grafo)  ║
║    --verbose              Informe detallado                                  ║
║                                                                              ║
║  COMO MÓDULO:                                                               ║
║    from adaptive_playback_runtime import run, run_interactive, \            ║
║        IntensityEvent, RuntimeLog, PlaybackSession, LiveController          ║
║                                                                              ║
║  LIMITACIONES A DOCUMENTAR (spec §6):                                       ║
║    - Implementación de referencia, no middleware de producción.             ║
║    - La restricción de banda de registro por capa (Programa 1) asume        ║
║      capas razonablemente estáticas en tesitura.                            ║
║    - El crossfade es una rampa LINEAL simple, no equal-power; suficiente    ║
║      para validar el diseño, no necesariamente la curva perceptualmente     ║
║      óptima.                                                                 ║
║                                                                              ║
║  DEPENDENCIAS: mido, numpy (mezcla de audio y fallback de síntesis).        ║
║  Opcional para --interactive con sonido real: sounddevice (PortAudio). Sin  ║
║  ella (o sin dispositivo de audio), --interactive cae automáticamente al    ║
║  modo headless descrito arriba — nunca falla por falta de tarjeta de audio. ║
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ══════════════════════════════════════════════════════════════════════════
# 1. Estructuras de datos — contrato compartido con layer_graph_composer.py
#    (spec §2). Se duplican aquí siguiendo la convención de ficheros
#    autocontenidos del ecosistema.
# ══════════════════════════════════════════════════════════════════════════

@dataclass
class LayerSpec:
    name: str
    register_band: tuple
    instrument: str
    activation_threshold: float
    always_on: bool = False
    leitmotif_treatment: Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "LayerSpec":
        return LayerSpec(
            name=d["name"],
            register_band=tuple(d["register_band"]),
            instrument=d["instrument"],
            activation_threshold=float(d["activation_threshold"]),
            always_on=bool(d.get("always_on", False)),
            leitmotif_treatment=d.get("leitmotif_treatment"),
        )


@dataclass
class StateSpec:
    name: str
    tension_target: float
    layers: list
    sync_points_beats: list
    transitions_to: list
    tempo_bpm: Optional[float] = None
    arrival_chord: Optional[str] = None
    key: str = "C"
    mode: str = "major"

    @staticmethod
    def from_dict(d: dict) -> "StateSpec":
        return StateSpec(
            name=d["name"],
            tension_target=float(d["tension_target"]),
            layers=[LayerSpec.from_dict(x) for x in d["layers"]],
            sync_points_beats=list(d["sync_points_beats"]),
            transitions_to=list(d["transitions_to"]),
            tempo_bpm=d.get("tempo_bpm"),
            arrival_chord=d.get("arrival_chord"),
            key=d.get("key", "C"),
            mode=d.get("mode", "major"),
        )


@dataclass
class GraphSpec:
    states: list
    shared_transition_chord: Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "GraphSpec":
        return GraphSpec(
            states=[StateSpec.from_dict(x) for x in d["states"]],
            shared_transition_chord=d.get("shared_transition_chord"),
        )

    def get_state(self, name: str) -> "StateSpec":
        for s in self.states:
            if s.name == name:
                return s
        raise KeyError(f"Estado desconocido en el grafo: {name!r}")


@dataclass
class LayerPackManifest:
    graph: GraphSpec
    layer_files: dict     # {(state_name, layer_name): path}
    skeleton_files: dict
    sample_rate: int
    tempo_bpm: dict         # {state_name: float}

    @staticmethod
    def from_dict(d: dict) -> "LayerPackManifest":
        layer_files = {}
        for k, v in d["layer_files"].items():
            state_name, layer_name = k.split("::", 1)
            layer_files[(state_name, layer_name)] = v
        return LayerPackManifest(
            graph=GraphSpec.from_dict(d["graph"]),
            layer_files=layer_files,
            skeleton_files=dict(d["skeleton_files"]),
            sample_rate=int(d["sample_rate"]),
            tempo_bpm=dict(d["tempo_bpm"]),
        )

    @staticmethod
    def load(path) -> "LayerPackManifest":
        with open(path, "r", encoding="utf-8") as f:
            return LayerPackManifest.from_dict(json.load(f))


@dataclass
class IntensityEvent:
    dt: float                              # segundos desde el evento anterior
    intensity: float                       # 0-1
    requested_state: Optional[str] = None  # cambio de estado solicitado (opcional)

    @staticmethod
    def from_dict(d: dict) -> "IntensityEvent":
        return IntensityEvent(
            dt=float(d["dt"]),
            intensity=float(d["intensity"]),
            requested_state=d.get("requested_state"),
        )


class RuntimeLog:
    """Registro de lo ocurrido durante la reproducción: transiciones
    aplicadas, transiciones rechazadas, y cambios de capas activas. Ver
    spec §4.1-4.2 — imprescindible para depurar por qué el grafo se
    comportó de una forma u otra."""

    def __init__(self):
        self.entries = []

    def transition(self, from_state: str, to_state: str, at_beat: float, at_time_s: float = None):
        self.entries.append({
            "type": "transition",
            "from_state": from_state,
            "to_state": to_state,
            "at_beat": at_beat,
            "at_time_s": at_time_s,
        })

    def reject(self, event: IntensityEvent, reason: str, current_state: str = None, at_time_s: float = None):
        self.entries.append({
            "type": "reject",
            "requested_state": event.requested_state,
            "current_state": current_state,
            "reason": reason,
            "at_time_s": at_time_s,
        })

    def layers_changed(self, state: str, at_time_s: float, active: set, activated: list, deactivated: list):
        if not activated and not deactivated:
            return
        self.entries.append({
            "type": "layers_changed",
            "state": state,
            "at_time_s": at_time_s,
            "active": sorted(active),
            "activated": sorted(activated),
            "deactivated": sorted(deactivated),
        })

    def transitions(self) -> list:
        return [e for e in self.entries if e["type"] == "transition"]

    def rejections(self) -> list:
        return [e for e in self.entries if e["type"] == "reject"]

    def to_dict(self) -> dict:
        return {"entries": self.entries}

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)


# ══════════════════════════════════════════════════════════════════════════
# 2. Utilidades de log de proceso (distinto de RuntimeLog, que es el
#    registro musical/de diseño que pide la spec)
# ══════════════════════════════════════════════════════════════════════════

def _log(verbose: bool, msg: str):
    if verbose:
        print(f"[adaptive_playback_runtime] {msg}", file=sys.stderr)


def _warn(msg: str):
    print(f"[adaptive_playback_runtime] AVISO: {msg}", file=sys.stderr)


# ══════════════════════════════════════════════════════════════════════════
# 3. Pseudocódigo del bucle de reproducción (spec §4.2), llevado a código
# ══════════════════════════════════════════════════════════════════════════

def advance_beats(beat_position: float, dt: float, tempo_bpm: float) -> float:
    return beat_position + dt * (tempo_bpm / 60.0)


def is_at_sync_point(prev_beat: float, beat_position: float, sync_points_beats: list, epsilon: float = 1e-6) -> bool:
    """Cruce de un sync point entre dos posiciones de beat consecutivas (no
    sólo igualdad exacta, que sería frágil frente a la granularidad de los
    eventos de entrada)."""
    for sp in sync_points_beats:
        if prev_beat - epsilon <= sp <= beat_position + epsilon:
            return True
    return False


def get_state(graph: GraphSpec, name: str) -> StateSpec:
    return graph.get_state(name)


# ══════════════════════════════════════════════════════════════════════════
# 4. Motor de mezcla de audio
# ══════════════════════════════════════════════════════════════════════════

class _LayerAudioSource:
    """Carga perezosa (y cachea) el audio de una capa como array float32
    mono normalizado en [-1, 1], a `sample_rate`. Acepta WAV directamente;
    si el manifest sólo contiene MIDI (--render-audio no se usó en el
    Programa 1), lo renderiza sobre la marcha con la misma estrategia que
    layer_graph_composer.py (timidity si está disponible, si no un
    sintetizador aditivo interno), cacheando el resultado en disco junto al
    MIDI de origen."""

    _cache = {}

    @classmethod
    def load(cls, path: str, sample_rate: int, verbose: bool):
        key = (path, sample_rate)
        if key in cls._cache:
            return cls._cache[key]

        p = Path(path)
        wav_path = p
        if p.suffix.lower() in (".mid", ".midi"):
            wav_path = p.with_suffix(".rendered_preview.wav")
            if not wav_path.exists():
                _log(verbose, f"capa {p.name} es MIDI; renderizando a WAV para mezcla ({wav_path.name})")
                _render_midi_to_wav_for_playback(p, wav_path, sample_rate, verbose)

        audio = _read_wav_mono_float(wav_path, sample_rate)
        cls._cache[key] = audio
        return audio


def _render_midi_to_wav_for_playback(midi_path: Path, out_path: Path, sample_rate: int, verbose: bool):
    import shutil
    import subprocess

    timidity = shutil.which("timidity")
    if timidity:
        cmd = [timidity, str(midi_path), "-Ow", "-o", str(out_path), "--sampling-freq", str(sample_rate)]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
            if result.returncode == 0 and out_path.exists():
                return
            _warn(f"timidity devolvió código {result.returncode}; usando sintetizador interno.")
        except (OSError, subprocess.SubprocessError) as exc:
            _warn(f"no se pudo invocar timidity ({exc}); usando sintetizador interno.")
    _fallback_synth_midi_to_wav(midi_path, out_path, sample_rate)


def _fallback_synth_midi_to_wav(midi_path: Path, out_path: Path, sample_rate: int):
    import wave
    import mido
    import numpy as np

    mid = mido.MidiFile(str(midi_path))
    events = []
    for track in mid.tracks:
        t = 0.0
        tempo = 500000
        for msg in track:
            t += mido.tick2second(msg.time, mid.ticks_per_beat, tempo)
            if msg.type == "set_tempo":
                tempo = msg.tempo
            if msg.type == "note_on" and msg.velocity > 0:
                events.append((t, "on", msg.note, msg.velocity))
            elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
                events.append((t, "off", msg.note, 0))

    duration = (max((t for t, *_ in events), default=0.0)) + 0.5
    n_samples = max(1, int(duration * sample_rate))
    buffer = np.zeros(n_samples, dtype=np.float64)
    open_notes = {}
    events.sort(key=lambda e: (e[0], 0 if e[1] == "off" else 1))
    for t, kind, note, vel in events:
        if kind == "on":
            open_notes[note] = t
        else:
            start = open_notes.pop(note, t)
            _add_note_tone(buffer, sample_rate, start, t, note, 90)
    for note, start in open_notes.items():
        _add_note_tone(buffer, sample_rate, start, duration, note, 90)

    peak = float(np.max(np.abs(buffer))) if buffer.size else 0.0
    if peak > 1e-9:
        buffer = buffer / peak * 0.85

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes((buffer * 32767).astype(np.int16).tobytes())


def _add_note_tone(buffer, sample_rate: int, start_s: float, end_s: float, note: int, velocity: int):
    import numpy as np

    start_i = int(start_s * sample_rate)
    end_i = int(end_s * sample_rate)
    n = max(1, end_i - start_i)
    if start_i >= buffer.shape[0]:
        return
    n = min(n, buffer.shape[0] - start_i)
    freq = 440.0 * (2.0 ** ((note - 69) / 12.0))
    t = np.arange(n) / sample_rate
    amp = (velocity / 127.0) * 0.2
    tone = amp * np.sin(2 * np.pi * freq * t)
    attack = min(n, int(0.01 * sample_rate))
    release = min(n, int(0.03 * sample_rate))
    if attack > 0:
        tone[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        tone[-release:] *= np.linspace(1, 0, release)
    buffer[start_i:start_i + n] += tone


def _read_wav_mono_float(path: Path, target_sample_rate: int):
    import wave
    import numpy as np

    with wave.open(str(path), "rb") as wf:
        n_channels = wf.getnchannels()
        sample_width = wf.getsampwidth()
        frame_rate = wf.getframerate()
        n_frames = wf.getnframes()
        raw = wf.readframes(n_frames)

    if sample_width == 2:
        data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    elif sample_width == 1:
        data = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    else:
        data = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0

    if n_channels > 1:
        data = data.reshape(-1, n_channels).mean(axis=1)

    if frame_rate != target_sample_rate and data.size:
        # remuestreo lineal simple: suficiente para una mezcla de previsualización
        import numpy as np
        duration = data.shape[0] / frame_rate
        n_target = max(1, int(duration * target_sample_rate))
        x_old = np.linspace(0.0, duration, num=data.shape[0], endpoint=False)
        x_new = np.linspace(0.0, duration, num=n_target, endpoint=False)
        data = np.interp(x_new, x_old, data).astype(np.float32)

    return data


class MixEngine:
    """Mantiene, por capa activa/inactiva, una ganancia actual que se
    interpola linealmente (crossfade) hacia la ganancia objetivo (1.0 si
    está activa, 0.0 si no) cada vez que se mezcla un fragmento de audio.
    El crossfade es una rampa lineal simple (spec §6: mejora futura
    razonable sería equal-power)."""

    def __init__(self, sample_rate: int, crossfade_ms: float, verbose: bool):
        self.sample_rate = sample_rate
        self.crossfade_samples = max(1, int(sample_rate * crossfade_ms / 1000.0))
        self.verbose = verbose
        self._gain = {}       # (state, layer) -> ganancia actual 0-1
        self._playhead = {}   # state -> posición de reproducción en muestras (loop)

    def reset_playhead(self, state: str):
        self._playhead[state] = 0

    def mix_chunk(self, manifest: LayerPackManifest, state_name: str, active_layers: set, dt: float):
        import numpy as np

        n_samples = max(1, int(round(dt * self.sample_rate)))
        chunk = np.zeros(n_samples, dtype=np.float64)
        state = manifest.graph.get_state(state_name)
        playhead = self._playhead.get(state_name, 0)

        for layer in state.layers:
            key = (state_name, layer.name)
            path = manifest.layer_files.get(key)
            if path is None:
                continue
            audio = _LayerAudioSource.load(path, self.sample_rate, self.verbose)
            target_gain = 1.0 if layer.name in active_layers else 0.0
            current_gain = self._gain.get(key, 0.0)

            gains = self._ramp(current_gain, target_gain, n_samples)
            self._gain[key] = float(gains[-1]) if n_samples else current_gain

            if audio.size == 0:
                continue
            looped = _read_loop(audio, playhead, n_samples)
            chunk += looped * gains

        self._playhead[state_name] = (playhead + n_samples) % max(1, self._max_layer_len(manifest, state_name))
        return chunk

    def _ramp(self, current_gain: float, target_gain: float, n_samples: int):
        import numpy as np

        if current_gain == target_gain:
            return np.full(n_samples, target_gain, dtype=np.float64)
        ramp_len = min(n_samples, self.crossfade_samples)
        ramp = np.linspace(current_gain, target_gain, ramp_len, dtype=np.float64)
        if ramp_len < n_samples:
            tail = np.full(n_samples - ramp_len, target_gain, dtype=np.float64)
            return np.concatenate([ramp, tail])
        return ramp

    def _max_layer_len(self, manifest: LayerPackManifest, state_name: str) -> int:
        state = manifest.graph.get_state(state_name)
        lengths = []
        for layer in state.layers:
            path = manifest.layer_files.get((state_name, layer.name))
            if path is None:
                continue
            audio = _LayerAudioSource.load(path, self.sample_rate, self.verbose)
            lengths.append(audio.shape[0])
        return max(lengths) if lengths else self.sample_rate


def _read_loop(audio, playhead: int, n_samples: int):
    import numpy as np

    length = audio.shape[0]
    if length == 0:
        return np.zeros(n_samples, dtype=np.float64)
    idx = (np.arange(n_samples) + playhead) % length
    return audio[idx].astype(np.float64)


# ══════════════════════════════════════════════════════════════════════════
# 5. Bucle principal de reproducción (spec §4.2)
# ══════════════════════════════════════════════════════════════════════════

class PlaybackSession:
    """Encapsula el estado del bucle de reproducción (spec §4.2) paso a
    paso: un `step(event)` procesa UN IntensityEvent (vertical layering +
    horizontal re-sequencing + mezcla) y devuelve el fragmento de audio
    mezclado correspondiente. `run()` (render por lotes) y el modo
    `--interactive` (streaming en vivo) son ambos clientes finos de esta
    misma clase, para que el comportamiento sea idéntico en los dos casos —
    ninguna lógica de estado se duplica entre "offline" y "tiempo real"."""

    def __init__(self, manifest: LayerPackManifest, crossfade_ms: float = 150.0,
                 start_state: Optional[str] = None, verbose: bool = False):
        self.manifest = manifest
        self.verbose = verbose
        self.current_state = start_state or manifest.graph.states[0].name
        self.pending_transition: Optional[str] = None
        self.beat_position = 0.0
        self.active_layers: set = set()
        self.log = RuntimeLog()
        self.engine = MixEngine(manifest.sample_rate, crossfade_ms, verbose)
        self.engine.reset_playhead(self.current_state)
        self.t_elapsed = 0.0

    def set_crossfade_ms(self, crossfade_ms: float):
        self.engine.crossfade_samples = max(1, int(self.manifest.sample_rate * crossfade_ms / 1000.0))

    def step(self, event: IntensityEvent):
        """Procesa un IntensityEvent y devuelve el chunk de audio mezclado
        (numpy float64, longitud = round(event.dt * sample_rate))."""
        state_spec = get_state(self.manifest.graph, self.current_state)
        tempo = self.manifest.tempo_bpm.get(self.current_state, 120.0)
        prev_beat = self.beat_position
        self.beat_position = advance_beats(self.beat_position, event.dt, tempo)

        # --- Vertical layering: continuo, sin esperar a nada ---
        new_active = {
            l.name for l in state_spec.layers
            if l.always_on or event.intensity >= l.activation_threshold
        }
        activated = sorted(new_active - self.active_layers)
        deactivated = sorted(self.active_layers - new_active)
        self.active_layers = new_active

        # --- Horizontal re-sequencing: sólo en puntos de sincronía declarados ---
        if event.requested_state and event.requested_state != self.current_state:
            if event.requested_state in state_spec.transitions_to:
                self.pending_transition = event.requested_state
                _log(self.verbose, f"transición a {event.requested_state!r} en cola (esperando sync point)")
            else:
                reason = "transicion no permitida por el grafo"
                self.log.reject(event, reason=reason, current_state=self.current_state, at_time_s=self.t_elapsed)
                _warn(
                    f"transición rechazada: {self.current_state!r} -> {event.requested_state!r} "
                    f"({reason}; transitions_to={state_spec.transitions_to})"
                )

        if self.pending_transition and is_at_sync_point(prev_beat, self.beat_position, state_spec.sync_points_beats):
            self.log.transition(self.current_state, self.pending_transition, at_beat=self.beat_position, at_time_s=self.t_elapsed)
            _log(self.verbose, f"transición aplicada: {self.current_state!r} -> {self.pending_transition!r} en beat={self.beat_position:.2f}")
            self.current_state, self.pending_transition, self.beat_position = self.pending_transition, None, 0.0
            self.engine.reset_playhead(self.current_state)
            state_spec = get_state(self.manifest.graph, self.current_state)
            new_active = {
                l.name for l in state_spec.layers
                if l.always_on or event.intensity >= l.activation_threshold
            }
            activated = sorted(new_active)
            deactivated = []
            self.active_layers = new_active
        elif state_spec.sync_points_beats:
            # El audio de la capa SÍ hace loop (playhead módulo en MixEngine);
            # el contador de beats debe hacerlo también, o los sync points
            # sólo se cruzan una vez en la vida del estado y nunca más se
            # ofrece otra oportunidad de transición (bug real: beat_position
            # subía sin límite — 69, 90... — sin volver a dar la vuelta).
            loop_length = max(state_spec.sync_points_beats)
            if loop_length > 0 and self.beat_position >= loop_length:
                self.beat_position %= loop_length

        self.log.layers_changed(self.current_state, self.t_elapsed, self.active_layers, activated, deactivated)

        chunk = self.engine.mix_chunk(self.manifest, self.current_state, self.active_layers, event.dt)
        self.t_elapsed += event.dt
        return chunk


def run(
    manifest: LayerPackManifest,
    events: list,
    out_wav: str,
    crossfade_ms: float = 150.0,
    start_state: Optional[str] = None,
    verbose: bool = False,
) -> RuntimeLog:
    import numpy as np
    import wave

    session = PlaybackSession(manifest, crossfade_ms, start_state, verbose)
    master_chunks = [session.step(event) for event in events]
    master = np.concatenate(master_chunks) if master_chunks else np.zeros(1, dtype=np.float64)
    _write_wav(out_wav, master, manifest.sample_rate)
    return session.log


def _write_wav(path: str, master, sample_rate: int):
    import numpy as np
    import wave

    peak = float(np.max(np.abs(master))) if master.size else 0.0
    if peak > 1.0:
        master = master / peak * 0.98

    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes((master * 32767).astype(np.int16).tobytes())


# ══════════════════════════════════════════════════════════════════════════
# 5.bis. Modo interactivo: streaming en tiempo real + consola de comandos
# ══════════════════════════════════════════════════════════════════════════

class LiveController:
    """Estado mutable compartido entre la consola de comandos (hilo
    principal) y el productor de audio (callback de sounddevice, o el
    temporizador headless): intensidad actual y una transición de estado
    solicitada pendiente de "recoger" en el próximo chunk. Todo acceso debe
    hacerse bajo el lock del llamador (esta clase no se bloquea a sí misma)."""

    def __init__(self, initial_intensity: float = 0.3):
        self.intensity = max(0.0, min(1.0, initial_intensity))
        self._requested_state: Optional[str] = None

    def set_intensity(self, value: float):
        self.intensity = max(0.0, min(1.0, value))

    def nudge(self, delta: float):
        self.set_intensity(self.intensity + delta)

    def request_state(self, name: str):
        self._requested_state = name

    def pop_requested_state(self) -> Optional[str]:
        s, self._requested_state = self._requested_state, None
        return s


_INTERACTIVE_HELP = """\
comandos disponibles (Enter para confirmar):
  i VALOR | intensity VALOR   fija la intensidad (0-1), ej: i 0.7
  +  / -                       sube/baja la intensidad 0.05
  state NOMBRE                 solicita transición a NOMBRE (se aplica en
                                el próximo sync point si el grafo lo permite)
  crossfade MS                 cambia la rampa de crossfade en caliente
  status                       imprime estado actual, capas activas,
                                transiciones permitidas desde aquí, y el
                                próximo sync point
  help                         muestra esta ayuda
  q | quit | exit              termina la sesión\
"""


def _print_status(session: "PlaybackSession", controller: LiveController):
    state_spec = get_state(session.manifest.graph, session.current_state)
    next_sync = next(
        (sp for sp in sorted(state_spec.sync_points_beats) if sp >= session.beat_position),
        None,
    )
    pending = f" (en cola: -> {session.pending_transition!r})" if session.pending_transition else ""
    print(
        f"[estado={session.current_state!r} intensidad={controller.intensity:.2f} "
        f"beat={session.beat_position:.1f} t={session.t_elapsed:.1f}s "
        f"capas_activas={sorted(session.active_layers)}]"
    )
    print(
        f"  transiciones permitidas desde aquí: {state_spec.transitions_to or '(ninguna)'}{pending}"
    )
    print(
        f"  próximo sync point: beat={next_sync:.1f}" if next_sync is not None
        else "  próximo sync point: ninguno más en este estado (sync_points_beats agotados)"
    )


def _command_loop(session: "PlaybackSession", controller: LiveController, lock):
    while True:
        try:
            line = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not line:
            continue
        parts = line.split()
        cmd = parts[0].lower()

        if cmd in ("q", "quit", "exit"):
            return
        elif cmd in ("i", "intensity") and len(parts) > 1:
            try:
                value = float(parts[1])
            except ValueError:
                print("valor de intensidad inválido (esperaba un número 0-1)")
                continue
            with lock:
                controller.set_intensity(value)
            print(f"intensidad -> {controller.intensity:.2f}")
        elif cmd == "+":
            with lock:
                controller.nudge(+0.05)
            print(f"intensidad -> {controller.intensity:.2f}")
        elif cmd == "-":
            with lock:
                controller.nudge(-0.05)
            print(f"intensidad -> {controller.intensity:.2f}")
        elif cmd == "state" and len(parts) > 1:
            target = parts[1]
            try:
                get_state(session.manifest.graph, target)
            except KeyError:
                print(f"estado desconocido en el grafo: {target!r}")
                continue
            current_spec = get_state(session.manifest.graph, session.current_state)
            if target not in current_spec.transitions_to:
                print(
                    f"AVISO: {target!r} no está en transitions_to de {session.current_state!r} "
                    f"({current_spec.transitions_to or '(ninguna)'}) — el grafo la rechazará igualmente, "
                    "pero se envía si insistes."
                )
            with lock:
                controller.request_state(target)
            print(f"transición solicitada -> {target!r} (en cola hasta el próximo sync point)")
        elif cmd == "crossfade" and len(parts) > 1:
            try:
                ms = float(parts[1])
            except ValueError:
                print("valor de crossfade inválido (esperaba milisegundos)")
                continue
            session.set_crossfade_ms(ms)
            print(f"crossfade -> {ms:.0f} ms")
        elif cmd == "status":
            _print_status(session, controller)
        elif cmd == "help":
            print(_INTERACTIVE_HELP)
        else:
            print("comando no reconocido; escribe 'help' para ver la lista")


def _headless_ticker(produce_chunk, blocksize: int, sample_rate: int, stop_event):
    import time

    period = blocksize / sample_rate
    next_tick = time.monotonic()
    while not stop_event.is_set():
        produce_chunk(blocksize)
        next_tick += period
        sleep_for = next_tick - time.monotonic()
        if sleep_for > 0:
            time.sleep(sleep_for)


def run_interactive(
    manifest: LayerPackManifest,
    crossfade_ms: float = 150.0,
    start_state: Optional[str] = None,
    initial_intensity: float = 0.3,
    blocksize: int = 1024,
    device=None,
    record_wav: Optional[str] = None,
    headless: bool = False,
    verbose: bool = False,
) -> RuntimeLog:
    """Sesión de reproducción en tiempo real con control interactivo por
    consola (ver comandos en _INTERACTIVE_HELP / docstring del módulo).

    Usa la MISMA PlaybackSession.step() que el render por lotes (`run()`),
    llamada repetidamente con eventos sintéticos de duración = un buffer de
    audio (`blocksize` frames) y la intensidad/transición vigentes en ese
    instante según LiveController — así vertical layering, horizontal
    re-sequencing y el RuntimeLog se comportan EXACTAMENTE igual que en modo
    por lotes, sólo que alimentados en vivo en vez de desde una lista
    pre-computada.

    Si sounddevice/PortAudio no está disponible o no hay dispositivo de
    salida (o se fuerza con `headless=True`), la sesión sigue funcionando:
    un temporizador interno avanza al ritmo real sin emitir sonido, así el
    diseño del grafo y los comandos se pueden probar sin hardware de audio.
    """
    import threading

    import numpy as np

    session = PlaybackSession(manifest, crossfade_ms, start_state, verbose)
    controller = LiveController(initial_intensity)
    lock = threading.Lock()
    recorded_chunks = [] if record_wav else None

    def produce_chunk(n_frames: int):
        dt = n_frames / manifest.sample_rate
        with lock:
            intensity = controller.intensity
            requested = controller.pop_requested_state()
        event = IntensityEvent(dt=dt, intensity=intensity, requested_state=requested)
        chunk = session.step(event)
        if recorded_chunks is not None:
            recorded_chunks.append(chunk)
        return chunk

    stream = None
    if not headless:
        try:
            import sounddevice as sd

            def _callback(outdata, frames, time_info, status):
                if status:
                    _warn(str(status))
                chunk = produce_chunk(frames)
                outdata[:, 0] = chunk.astype(np.float32)

            stream = sd.OutputStream(
                samplerate=manifest.sample_rate, channels=1, dtype="float32",
                blocksize=blocksize, device=device, callback=_callback,
            )
        except Exception as exc:  # noqa: BLE001 - cualquier fallo de audio cae a headless
            _warn(
                f"no se pudo abrir un dispositivo de audio real ({exc}); "
                "usando modo headless (sin sonido, sólo control/simulación)."
            )
            stream = None

    print(_INTERACTIVE_HELP)
    _print_status(session, controller)

    if stream is not None:
        with stream:
            _command_loop(session, controller, lock)
    else:
        stop_event = threading.Event()
        ticker = threading.Thread(
            target=_headless_ticker,
            args=(produce_chunk, blocksize, manifest.sample_rate, stop_event),
            daemon=True,
        )
        ticker.start()
        try:
            _command_loop(session, controller, lock)
        finally:
            stop_event.set()
            ticker.join(timeout=1.0)

    if record_wav and recorded_chunks:
        master = np.concatenate(recorded_chunks)
        _write_wav(record_wav, master, manifest.sample_rate)
        print(f"grabación de la sesión guardada en {record_wav}")

    return session.log


# ══════════════════════════════════════════════════════════════════════════
# 6. Generación de eventos
# ══════════════════════════════════════════════════════════════════════════

def load_events(path: str) -> list:
    """Lee IntensityEvent desde JSON. Acepta dos formatos de entrada, tal y
    como describe la spec ("timestamp, intensidad 0-1, estado solicitado
    opcional"): timestamps absolutos (se convierten a dt consecutivos) o
    dt ya explícito por entrada."""
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    events = []
    prev_t = 0.0
    for entry in raw:
        if "dt" in entry:
            events.append(IntensityEvent.from_dict(entry))
        else:
            t = float(entry["timestamp"])
            dt = max(0.0, t - prev_t)
            prev_t = t
            events.append(IntensityEvent(dt=dt, intensity=float(entry["intensity"]), requested_state=entry.get("requested_state")))
    return events


def simulate_random_events(graph: GraphSpec, duration: float, seed: int, step_s: float = 0.5) -> list:
    """Paseo aleatorio de intensidad determinista (misma semilla -> mismos
    eventos -> mismo WAV/log, spec test 5.2.4), con peticiones ocasionales
    de transición a estados vecinos del grafo."""
    rng = random.Random(seed)
    events = []
    intensity = 0.5
    n_steps = max(1, int(duration / step_s))
    current_state_guess = graph.states[0].name

    for _ in range(n_steps):
        intensity += rng.uniform(-0.15, 0.15)
        intensity = max(0.0, min(1.0, intensity))

        requested = None
        if rng.random() < 0.05:
            state_spec = graph.get_state(current_state_guess)
            if state_spec.transitions_to:
                requested = rng.choice(state_spec.transitions_to)
                current_state_guess = requested  # sólo para elegir la próxima petición con sentido; el runtime real decide si se aplica

        events.append(IntensityEvent(dt=step_s, intensity=intensity, requested_state=requested))

    return events


# ══════════════════════════════════════════════════════════════════════════
# 7. CLI
# ══════════════════════════════════════════════════════════════════════════

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Reproduce/mezcla de previsualización un paquete de capas según un flujo de eventos de intensidad.",
    )
    p.add_argument("manifest", help="Ruta a layer_pack/manifest.json (salida de layer_graph_composer.py)")
    p.add_argument("--events", help="Fichero JSON de IntensityEvent")
    p.add_argument("--simulate-random", action="store_true", help="Genera un paseo aleatorio de intensidad en vez de --events")
    p.add_argument("--duration", type=float, default=60.0, help="Duración en segundos de --simulate-random (default: 60)")
    p.add_argument("--seed", type=int, default=7, help="Semilla determinista de --simulate-random (default: 7)")
    p.add_argument("--interactive", action="store_true", help="Modo en tiempo real con consola de comandos (ver docstring)")
    p.add_argument("--initial-intensity", type=float, default=0.3, help="Intensidad inicial en --interactive (default: 0.3)")
    p.add_argument("--blocksize", type=int, default=1024, help="Tamaño de buffer de audio en frames (default: 1024)")
    p.add_argument("--device", default=None, help="Dispositivo de salida (índice o nombre; sounddevice)")
    p.add_argument("--headless", action="store_true", help="Fuerza el modo sin dispositivo de audio real en --interactive")
    p.add_argument("--record", help="Graba toda la sesión --interactive a este WAV")
    p.add_argument("--out", help="WAV de previsualización mezclado (modo por lotes; obligatorio salvo en --interactive)")
    p.add_argument("--log", help="RuntimeLog en JSON")
    p.add_argument("--crossfade-ms", type=float, default=150.0, help="Rampa de activación/desactivación de capa (default: 150)")
    p.add_argument("--start-state", help="Estado inicial (default: primer estado del grafo)")
    p.add_argument("--verbose", action="store_true", help="Informe detallado")
    return p


def main(argv=None):
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    manifest = LayerPackManifest.load(args.manifest)

    if args.interactive:
        device = args.device
        if device is not None:
            try:
                device = int(device)
            except ValueError:
                pass  # nombre de dispositivo, no índice
        log = run_interactive(
            manifest,
            crossfade_ms=args.crossfade_ms,
            start_state=args.start_state,
            initial_intensity=args.initial_intensity,
            blocksize=args.blocksize,
            device=device,
            record_wav=args.record,
            headless=args.headless,
            verbose=args.verbose,
        )
        if args.log:
            log.save(args.log)
        n_transitions = len(log.transitions())
        n_rejections = len(log.rejections())
        print(
            f"sesión interactiva finalizada — {n_transitions} transición(es) aplicada(s), "
            f"{n_rejections} rechazada(s)."
        )
        return 0

    if args.simulate_random:
        events = simulate_random_events(manifest.graph, args.duration, args.seed)
    elif args.events:
        events = load_events(args.events)
    else:
        parser.error("se requiere --events FILE, --simulate-random, o --interactive")
        return 2

    if not args.out:
        parser.error("--out es obligatorio en modo por lotes (o usa --interactive)")
        return 2

    log = run(
        manifest, events, args.out,
        crossfade_ms=args.crossfade_ms,
        start_state=args.start_state,
        verbose=args.verbose,
    )

    if args.log:
        log.save(args.log)

    n_transitions = len(log.transitions())
    n_rejections = len(log.rejections())
    print(
        f"previsualización escrita en {args.out} — {len(events)} eventos procesados, "
        f"{n_transitions} transición(es) aplicada(s), {n_rejections} rechazada(s)."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
