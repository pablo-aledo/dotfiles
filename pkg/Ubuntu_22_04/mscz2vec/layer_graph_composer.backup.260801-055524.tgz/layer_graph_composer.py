#!/usr/bin/env python3
r"""
║                      LAYER GRAPH COMPOSER  v1.0                              ║
║      Composición offline de "paquetes de capas" para música adaptativa       ║
║                                                                              ║
║  Programa 1 de 2 (ver adaptive_playback_runtime.py para el Programa 2).     ║
║  El pipeline habitual del ecosistema asume una forma fija de antemano        ║
║  (arco emocional sobre una línea de tiempo: narrator.py / arc_supervisor.py).║
║  Este módulo invierte esa premisa: dado un GRAFO de estados/capas, genera    ║
║  el contenido musical real de cada estado — un esqueleto armónico            ║
║  compartido, cada capa orquestada con su banda de registro reservada, y      ║
║  los puntos de sincronía preparados para transición — sin saber nada de      ║
║  reproducción en tiempo real. Eso es responsabilidad exclusiva de            ║
║  adaptive_playback_runtime.py (Programa 2), que consume el "paquete de       ║
║  capas" (manifest.json + ficheros MIDI/WAV) producido aquí.                  ║
║                                                                              ║
║  REUTILIZACIÓN DEL ECOSISTEMA (ver spec §1):                                ║
║    chord_progression_generator.py → esqueleto armónico compartido/estado    ║
║    arc_supervisor.py              → auditoría de arco completo, a posteriori║
║                                       (Modo A real: varias secciones + lista║
║                                       de tensiones separadas por comas; NO  ║
║                                       puntúa un candidato aislado — el      ║
║                                       bucle de reintentos usa un heurístico ║
║                                       interno rápido, ver score_tension())  ║
║    orchestral_colorist.py         → timbre por capa (etiqueta = emoción)    ║
║    leitmotif_tracker.py           → siembra de motivo por capa (inject)     ║
║    cadence_designer.py            → resolución de acordes (chord_name_to_   ║
║                                       midi) para los sync points, y pista   ║
║                                       "Cadences" de auditoría en el         ║
║                                       esqueleto (insert_cadences_into_midi) ║
║    tonicization_engine.py         → inyección de dominantes secundarios    ║
║                                       reales cuando --style/--complexity ya ║
║                                       no dan más margen (techo estructural  ║
║                                       de chord_progression_generator.py en  ║
║                                       bloques de acordes) — REQUIERE        ║
║                                       harmonic_analyzer.py junto a ella     ║
║  Cada adaptador intenta invocar la herramienta real (subproceso o import,   ║
║  mismo directorio que este script) y si no está disponible cae a una        ║
║  implementación interna equivalente, avisando por stderr — así el programa  ║
║  es ejecutable/testeable de forma autónoma incluso sin el ecosistema        ║
║  completo instalado.                                                        ║
║                                                                              ║
║  EXTENSIONES PRAGMÁTICAS AL CONTRATO DE DATOS (documentadas, opt-in,        ║
║  con default que preserva compatibilidad con GraphSpec ya escritos):        ║
║    StateSpec.tempo_bpm       — tempo propio del estado (si no se declara,   ║
║                                 se usa --tempo del CLI para todos)          ║
║    StateSpec.arrival_chord   — acorde de llegada específico de este estado, ║
║                                 usado en sync points cuando NO hay          ║
║                                 shared_transition_chord a nivel de grafo    ║
║                                 (spec §3.1.5, rama "si no...")              ║
║    StateSpec.key / .mode     — tonalidad del estado (default "C"/"major"),  ║
║                                 necesaria para chord_name_to_midi de        ║
║                                 cadence_designer.py y para el generador     ║
║                                 diatónico interno de fallback               ║
║                                                                              ║
║  USO:                                                                       ║
║    python layer_graph_composer.py graph_spec.json --out-dir layer_pack/    ║
║    python layer_graph_composer.py graph_spec.json --out-dir layer_pack/ \  ║
║        --tension-tolerance 0.05 --max-retries 5                             ║
║    python layer_graph_composer.py graph_spec.json --out-dir layer_pack/ \  ║
║        --render-audio                                                       ║
║                                                                              ║
║  OPCIONES:                                                                   ║
║    graph_spec.json          GraphSpec serializado (JSON, escrito a mano)    ║
║    --out-dir DIR            Carpeta de salida (default: layer_pack)         ║
║    --tension-tolerance F    Tolerancia de arc_supervisor (default: 0.1)     ║
║    --max-retries N          Reintentos de esqueleto antes de fallar (def:3) ║
║    --render-audio           Además de MIDI, renderiza cada capa a WAV       ║
║    --bars-per-state N       Compases del esqueleto de cada estado (def: 8)  ║
║    --tempo F                Tempo por defecto si el estado no declara uno   ║
║                              (default: 120)                                 ║
║    --register-overlap-tolerance N   Semitonos de solape permitido entre     ║
║                              bandas de registro vecinas (default: 2)        ║
║    --collision-max-retries N  Reintentos de regeneración de capa ante       ║
║                              colisión de registro (default: 3)              ║
║    --seed N                 Semilla determinista para los fallbacks         ║
║                              internos de generación (default: 42)           ║
║    --sample-rate N          Sample rate del audio renderizado (def: 44100)  ║
║    --leitmotif-bank FILE    Banco de leitmotifs (default: leitmotif_bank    ║
║                              .json junto al script, como leitmotif_tracker) ║
║    --verbose                Informe detallado del pipeline                  ║
║                                                                              ║
║  SALIDA:                                                                    ║
║    <out-dir>/manifest.json           — LayerPackManifest serializado        ║
║    <out-dir>/<estado>.skeleton.mid   — esqueleto compartido de cada estado  ║
║    <out-dir>/<estado>__<capa>.mid    — cada capa orquestada                 ║
║    <out-dir>/*.wav                   — si --render-audio                    ║
║                                                                              ║
║  COMO MÓDULO:                                                               ║
║    from layer_graph_composer import (GraphSpec, StateSpec, LayerSpec,       ║
║        LayerPackManifest, compose_layer_pack)                               ║
║                                                                              ║
║  DEPENDENCIAS: mido, numpy (numpy sólo si --render-audio sin timidity)      ║
"""

from __future__ import annotations

import argparse
import json
import random
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


# ══════════════════════════════════════════════════════════════════════════
# 1. Estructuras de datos — contrato compartido con adaptive_playback_runtime
#    (spec §2). Se duplican aquí en vez de importarse de un módulo común
#    porque este ecosistema sigue la convención de ficheros Python
#    autocontenidos (ver audio_effects.py / mix_evolver.py como precedente).
# ══════════════════════════════════════════════════════════════════════════

@dataclass
class LayerSpec:
    name: str
    register_band: tuple  # (pitch_min, pitch_max) MIDI
    instrument: str
    activation_threshold: float
    always_on: bool = False
    leitmotif_treatment: Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "LayerSpec":
        return LayerSpec(
            name=d["name"],
            register_band=tuple(d["register_band"]),
            instrument=d["instrument"],
            activation_threshold=float(d["activation_threshold"]),
            always_on=bool(d.get("always_on", False)),
            leitmotif_treatment=d.get("leitmotif_treatment"),
        )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "register_band": list(self.register_band),
            "instrument": self.instrument,
            "activation_threshold": self.activation_threshold,
            "always_on": self.always_on,
            "leitmotif_treatment": self.leitmotif_treatment,
        }


@dataclass
class StateSpec:
    name: str
    tension_target: float
    layers: list  # list[LayerSpec]
    sync_points_beats: list
    transitions_to: list
    # --- extensiones pragmáticas (ver docstring del módulo) ---
    tempo_bpm: Optional[float] = None
    arrival_chord: Optional[str] = None
    key: str = "C"
    mode: str = "major"

    @staticmethod
    def from_dict(d: dict) -> "StateSpec":
        return StateSpec(
            name=d["name"],
            tension_target=float(d["tension_target"]),
            layers=[LayerSpec.from_dict(x) for x in d["layers"]],
            sync_points_beats=list(d["sync_points_beats"]),
            transitions_to=list(d["transitions_to"]),
            tempo_bpm=d.get("tempo_bpm"),
            arrival_chord=d.get("arrival_chord"),
            key=d.get("key", "C"),
            mode=d.get("mode", "major"),
        )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "tension_target": self.tension_target,
            "layers": [l.to_dict() for l in self.layers],
            "sync_points_beats": list(self.sync_points_beats),
            "transitions_to": list(self.transitions_to),
            "tempo_bpm": self.tempo_bpm,
            "arrival_chord": self.arrival_chord,
            "key": self.key,
            "mode": self.mode,
        }


@dataclass
class GraphSpec:
    states: list  # list[StateSpec]
    shared_transition_chord: Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "GraphSpec":
        return GraphSpec(
            states=[StateSpec.from_dict(x) for x in d["states"]],
            shared_transition_chord=d.get("shared_transition_chord"),
        )

    def to_dict(self) -> dict:
        return {
            "states": [s.to_dict() for s in self.states],
            "shared_transition_chord": self.shared_transition_chord,
        }

    @staticmethod
    def load(path) -> "GraphSpec":
        with open(path, "r", encoding="utf-8") as f:
            return GraphSpec.from_dict(json.load(f))

    def get_state(self, name: str) -> "StateSpec":
        for s in self.states:
            if s.name == name:
                return s
        raise KeyError(f"Estado desconocido en el grafo: {name!r}")


@dataclass
class LayerPackManifest:
    graph: GraphSpec
    layer_files: dict     # {(state_name, layer_name): path}
    skeleton_files: dict   # {state_name: path}
    sample_rate: int
    tempo_bpm: dict         # {state_name: float}

    def to_dict(self) -> dict:
        return {
            "graph": self.graph.to_dict(),
            "layer_files": {f"{k[0]}::{k[1]}": v for k, v in self.layer_files.items()},
            "skeleton_files": dict(self.skeleton_files),
            "sample_rate": self.sample_rate,
            "tempo_bpm": dict(self.tempo_bpm),
        }

    @staticmethod
    def from_dict(d: dict) -> "LayerPackManifest":
        layer_files = {}
        for k, v in d["layer_files"].items():
            state_name, layer_name = k.split("::", 1)
            layer_files[(state_name, layer_name)] = v
        return LayerPackManifest(
            graph=GraphSpec.from_dict(d["graph"]),
            layer_files=layer_files,
            skeleton_files=dict(d["skeleton_files"]),
            sample_rate=int(d["sample_rate"]),
            tempo_bpm=dict(d["tempo_bpm"]),
        )

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)

    @staticmethod
    def load(path) -> "LayerPackManifest":
        with open(path, "r", encoding="utf-8") as f:
            return LayerPackManifest.from_dict(json.load(f))


class SkeletonToleranceExceeded(RuntimeError):
    """Se agotaron los reintentos sin alcanzar tension_target +/- tolerancia."""


class RegisterCollisionUnresolved(RuntimeError):
    """Colisión de banda de registro que no se resolvió tras los reintentos."""


# ══════════════════════════════════════════════════════════════════════════
# 2. Utilidades de log
# ══════════════════════════════════════════════════════════════════════════

def _log(verbose: bool, msg: str):
    if verbose:
        print(f"[layer_graph_composer] {msg}", file=sys.stderr)


def _warn(msg: str):
    print(f"[layer_graph_composer] AVISO: {msg}", file=sys.stderr)


# ══════════════════════════════════════════════════════════════════════════
# 3. Adaptadores al ecosistema (subprocess con fallback interno)
# ══════════════════════════════════════════════════════════════════════════

def _ecosystem_tool(name: str) -> Optional[Path]:
    """Busca <name> junto a este script (convención del ecosistema)."""
    here = Path(__file__).resolve().parent
    candidate = here / name
    return candidate if candidate.exists() else None


_STYLE_CANDIDATES = ["pop", "diatonic", "romantic", "jazz", "impressionist", "flamenco"]

# Peldaños de --complexity elegidos para cruzar los dos umbrales REALES y
# confirmados en resolve_numeral() de chord_progression_generator.py:
#   > 0.6  → tríadas simples ganan 7ª (mayor o menor)
#   > 0.75 → acordes que ya tenían 7ª (p.ej. la V7 de 'jazz') ganan 9ª
# 0.85 cruza los dos; 0.65 sólo el primero; 0.40 y 0.15 ninguno. Un control
# proporcional suave puede quedarse indefinidamente al mismo lado de un
# umbral sin que la tensión medida cambie nada — por eso se usan peldaños
# discretos en vez de una fórmula continua.
_COMPLEXITY_RUNGS = [0.85, 0.65, 0.40, 0.15]

_STYLE_BUCKETS = [
    (0.20, "pop"),
    (0.40, "diatonic"),
    (0.60, "romantic"),
    (0.80, "jazz"),
    (1.01, "impressionist"),
]


def _style_for_tension(tension_target: float) -> str:
    """Punto de partida razonable para el rastreo de estilo en
    generate_skeleton() — sólo el primer candidato a probar, NO un orden de
    tensión creciente fiable (datos reales mostraron que 'jazz' mide más
    tensión que 'impressionist' pese a "sonar" menos extremo sobre el
    papel; ver generate_skeleton())."""
    for ceiling, style in _STYLE_BUCKETS:
        if tension_target < ceiling:
            return style
    return _STYLE_BUCKETS[-1][1]


def generate_skeleton_candidate(
    state: StateSpec,
    out_path: Path,
    bars: int,
    tempo: float,
    rng: random.Random,
    verbose: bool,
    complexity: Optional[float] = None,
    style: Optional[str] = None,
    tension_profile: str = "arch",
):
    """Genera UN candidato de esqueleto armónico para `state` en `out_path`.

    Intenta chord_progression_generator.py; si no está disponible usa un
    generador diatónico interno de bloques de acordes (fallback determinista
    vía `rng`), suficiente para producir un MIDI válido y testeable.

    CORRECCIÓN IMPORTANTE #3 (con datos reales): las dos primeras rondas de
    corrección asumían `--tension-profile "neutral"` porque "queríamos un
    bloque parejo, no una forma" — pero los datos reales muestran que 5 de
    6 estilos daban tensión EXACTAMENTE 0.000 con ese perfil, siempre,
    fuera cual fuera el target. Eso no es "estos estilos son calmados": es
    que "neutral" (mi propia elección, NO el default real de la
    herramienta) probablemente suprime por diseño cualquier dispositivo
    generador de disonancia (suspensiones, dominantes secundarias, notas de
    paso). El default real y documentado de chord_progression_generator.py
    es "arch", no "neutral" — se prueba aquí en su lugar. `--complexity`
    (0=tríadas simples, 1=9as/13as) mueve sobre todo la dimensión "harmony"
    medida por arc_supervisor.py, casi nada "tension" en sí. `--style` sí
    parece mover tension — ver generate_skeleton(), que RASTREA varios
    estilos sin asumir un orden de tensión creciente entre ellos. La
    herramienta no tiene --seed: con los mismos argumentos da SIEMPRE la
    misma salida.
    """
    tool = _ecosystem_tool("chord_progression_generator.py")
    if tool is not None:
        if style is None:
            style = _style_for_tension(state.tension_target)
        if complexity is None:
            complexity = state.tension_target
        complexity = max(0.0, min(1.0, complexity))
        cmd = [
            sys.executable, str(tool),
            # CRÍTICO: NUNCA pasar una descripción en lenguaje natural aquí.
            # Leí el código real de chord_progression_generator.py:
            # parse_intent() aplica SEMANTIC_MAP por coincidencia de
            # SUBCADENA (no palabra completa) sobre cualquier texto de
            # descripción, y --complexity es el ÚNICO parámetro que NO se
            # re-aplica desde CLI después de la semántica (a diferencia de
            # --key/--mode/--style, que sí). Como generábamos la
            # descripción incluyendo el nombre del estado tal cual
            # ("tango_intimo", "climax_epico"), coincidía por subcadena con
            # entradas reales del catálogo ('intimo' → complexity -0.2,
            # 'epico' → complexity +0.15, con cambios de moda/estilo que la
            # reaplicación de CLI sí corregía pero la de complexity no) y
            # corrompía silenciosamente el --complexity que pasábamos cada
            # vez. Como aquí siempre se pasan --key/--mode/--style/
            # --complexity explícitos, usamos el modo "parámetros directos"
            # documentado por la propia herramienta (sin texto de
            # descripción) y evitamos SEMANTIC_MAP por completo.
            "--key", state.key,
            "--mode", state.mode,
            "--style", style,
            "--bars", str(bars),
            "--tempo", str(int(tempo)),
            "--complexity", f"{complexity:.2f}",
            "--tension-profile", tension_profile,
            "--export-midi", str(out_path),
        ]
        _log(
            verbose,
            f"invocando chord_progression_generator.py para {state.name!r} "
            f"(style={style!r}, complexity={complexity:.2f}, tension_profile={tension_profile!r})",
        )
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if result.returncode == 0 and out_path.exists():
                return
            _warn(
                f"chord_progression_generator.py devolvió código {result.returncode} "
                f"para {state.name!r}; usando fallback interno. "
                f"stdout: {result.stdout[-400:] if result.stdout else '(vacío)'} "
                f"stderr: {result.stderr[-400:] if result.stderr else '(vacío)'}"
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _warn(f"no se pudo invocar chord_progression_generator.py ({exc}); usando fallback interno.")
    else:
        _warn("chord_progression_generator.py no encontrado junto a este script; usando fallback interno.")

    _fallback_generate_skeleton(state, out_path, bars, tempo, rng)


# Progresiones diatónicas de referencia (grados en escala mayor natural,
# 0-indexados sobre C) usadas por el fallback interno, ordenadas de menor a
# mayor "tensión" percibida de forma muy aproximada (más disonancia/cromatismo
# hacia el final de la lista).
_FALLBACK_PROGRESSIONS = [
    ([0, 5, 3, 4], 0.15),        # I - vi - IV - V  (calmo, muy consonante)
    ([0, 3, 4, 0], 0.30),        # I - IV - V - I
    ([1, 4, 0, 4], 0.45),        # ii - V - I - V
    ([0, 2, 3, 4], 0.55),        # I - iii - IV - V
    ([5, 3, 4, 0], 0.65),        # vi - IV - V - I
    ([1, 4, 5, 3], 0.75),        # ii - V - vi - IV  (deceptivo, más tenso)
    ([4, 5, 1, 4], 0.85),        # V - vi - ii - V   (evita reposo)
    ([1, 4, 0, 4], 0.95),        # ii - V - I - V con densidad extra (ver abajo)
]

_MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]
_TRIAD_QUALITY = ["maj", "min", "min", "maj", "maj", "min", "dim"]


def _degree_to_triad(degree: int, key_root: int = 60) -> list:
    """Devuelve las notas MIDI (registro medio) de la tríada diatónica del
    grado `degree` (0-indexado) sobre una tonalidad mayor con tónica
    `key_root` (default C4=60)."""
    root = key_root + _MAJOR_SCALE[degree % 7]
    third_degree = (degree + 2) % 7
    fifth_degree = (degree + 4) % 7
    third = key_root + _MAJOR_SCALE[third_degree] + (12 if _MAJOR_SCALE[third_degree] < _MAJOR_SCALE[degree % 7] else 0)
    fifth = key_root + _MAJOR_SCALE[fifth_degree] + (12 if _MAJOR_SCALE[fifth_degree] < _MAJOR_SCALE[degree % 7] else 0)
    return sorted([root, third, fifth])


def _fallback_generate_skeleton(state: StateSpec, out_path: Path, bars: int, tempo: float, rng: random.Random):
    """Generador diatónico interno de bloques de acordes, usado sólo cuando
    chord_progression_generator.py no está disponible.

    Cada compás es o bien una tríada diatónica de _FALLBACK_PROGRESSIONS
    (consonante) o bien un clúster de 3 semitonos adyacentes (todos los
    pares a distancia de 2ª, intrínsecamente disonante bajo el heurístico
    interno de _fallback_tension_score). La FRACCIÓN de compases-clúster se
    deriva analíticamente de state.tension_target invirtiendo la fórmula de
    ese heurístico (dissonance_ratio ~= fracción de compases disonantes,
    density fija ~0.1125 con 3 notas/compás), de forma que el candidato
    generado caiga ya cerca del objetivo sin necesitar muchos reintentos.
    `rng` decide QUÉ compases son disonantes (varía entre reintentos)."""
    import mido

    best = min(_FALLBACK_PROGRESSIONS, key=lambda pt: abs(pt[1] - state.tension_target))
    degrees, _ = best

    ticks_per_beat = 480
    beats_per_bar = 4
    bar_ticks = ticks_per_beat * beats_per_bar

    mid = mido.MidiFile(ticks_per_beat=ticks_per_beat)
    track = mido.MidiTrack()
    mid.tracks.append(track)
    track.append(mido.MetaMessage("set_tempo", tempo=mido.bpm2tempo(tempo), time=0))
    track.append(mido.MetaMessage("track_name", name=f"skeleton_{state.name}", time=0))

    # inversión aproximada de score = 0.192 + 0.45*frac_disonante (recalibrado
    # empíricamente contra el heurístico interno con término de riqueza
    # armónica). Techo real observado ~0.64 — este generador interno es sólo
    # un candidato de reserva para cuando chord_progression_generator.py no
    # está disponible; con la herramienta real, generate_skeleton() ya no
    # depende de esto (usa --complexity + arc_supervisor.py/heurístico).
    frac_dissonant = max(0.0, min(1.0, (state.tension_target - 0.192) / 0.45))
    n_dissonant_bars = round(frac_dissonant * bars)
    dissonant_bar_idxs = set(rng.sample(range(bars), n_dissonant_bars)) if n_dissonant_bars else set()

    key_root = _key_root_pitch(state.key)

    events = []  # (tick, type, note)
    for bar_idx in range(bars):
        start = bar_idx * bar_ticks
        end = start + bar_ticks
        if bar_idx in dissonant_bar_idxs:
            root = key_root + rng.randint(-4, 4)
            chord = [root, root + 1, root + 2]  # clúster cromático: todos los pares son 2ª (disonante)
        else:
            degree = degrees[bar_idx % len(degrees)]
            chord = _degree_to_triad(degree, key_root=key_root)
        for note in chord:
            events.append((start, "on", note))
            events.append((end, "off", note))

    events.sort(key=lambda e: (e[0], 0 if e[1] == "off" else 1))
    prev_tick = 0
    for tick, kind, note in events:
        delta = tick - prev_tick
        prev_tick = tick
        if kind == "on":
            track.append(mido.Message("note_on", note=note, velocity=72, time=delta))
        else:
            track.append(mido.Message("note_off", note=note, velocity=0, time=delta))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    mid.save(str(out_path))


def score_tension(midi_path: Path, tension_target: float, bars: int, verbose: bool) -> float:
    """Devuelve la tensión medida (0-1) de `midi_path` para el bucle de
    reintentos de generate_skeleton().

    SEGUNDA VUELTA (tras revisar el primer intento fallido con más
    cuidado): mi primera llamada a arc_supervisor.py no pasaba `--sections`
    en absoluto — ni Modo A válido (que quiere ≥2 ficheros) ni Modo B
    válido (que exige `--sections`). Eso por sí solo explica el código de
    salida 1, no necesariamente que el paradigma fuera incompatible. Modo B
    con un único número en `--sections` (una sección = el candidato
    completo) SÍ debería poder puntuar un candidato aislado contra UN
    tension_target. Se prueba aquí; si falla (verás el stdout/stderr
    completos en el aviso) o si arc_supervisor.py no está disponible, cae
    al heurístico interno."""
    tool = _ecosystem_tool("arc_supervisor.py")
    if tool is not None:
        report_path = midi_path.with_suffix(".arc_report.json")
        cmd = [
            sys.executable, str(tool), str(midi_path),
            "--sections", str(bars),
            "--tension", f"{tension_target:.3f}",
            "--report", str(report_path),
        ]
        _log(verbose, f"invocando arc_supervisor.py (Modo B, 1 sección de {bars} compases) sobre {midi_path.name}")
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            # NOTA: el código de salida de arc_supervisor.py no es un indicador de
            # fallo de la invocación — devuelve 1 quand la sección se desvía del
            # plan emocional ("PROBLEMA"), que es un diagnóstico legítimo, no un
            # crash. El único indicador fiable de que la llamada funcionó es que
            # el informe se haya escrito de verdad.
            if report_path.exists():
                with open(report_path, "r", encoding="utf-8") as f:
                    report = json.load(f)
                score = _extract_tension_from_report(report)
                if score is not None:
                    return score
                _warn(
                    "no se pudo interpretar el JSON de arc_supervisor.py con las rutas de clave "
                    "conocidas; usando heurístico interno. Estructura real del informe (para "
                    f"corregir el parseo): {json.dumps(report, ensure_ascii=False)[:1500]}"
                )
            else:
                _warn(
                    f"arc_supervisor.py (Modo B) no escribió informe para {midi_path.name} "
                    f"(código {result.returncode}); usando heurístico interno. "
                    f"stdout: {result.stdout[-500:] if result.stdout else '(vacío)'} "
                    f"stderr: {result.stderr[-500:] if result.stderr else '(vacío)'}"
                )
        except (OSError, subprocess.SubprocessError) as exc:
            _warn(f"no se pudo invocar arc_supervisor.py ({exc}); usando heurístico interno.")
    else:
        _warn("arc_supervisor.py no encontrado junto a este script; usando heurístico interno de tensión.")

    return _fallback_tension_score(midi_path)


def _extract_tension_from_report(report: dict) -> Optional[float]:
    """Esquema real confirmado (Pablo pegó un arc_report.json real):
    report['sections'][0]['measured']['tension']. Se deja como primera
    ruta; el resto son conjeturas previas, mantenidas como red de
    seguridad por si una versión distinta de arc_supervisor.py cambia el
    esquema."""
    candidates = [
        lambda r: r["sections"][0]["measured"]["tension"],
        lambda r: r["sections"][0]["dimensions"]["tension"],
        lambda r: r["sections"][0]["tension"],
        lambda r: r["dimensions"]["tension"],
        lambda r: r["tension"],
        lambda r: r["global"]["tension"],
    ]
    for get in candidates:
        try:
            val = get(report)
            return float(val)
        except (KeyError, IndexError, TypeError, ValueError):
            continue
    return None


def audit_full_arc(state_names: list, skeleton_paths: list, tension_targets: list, out_dir: Path, verbose: bool):
    """Llama a arc_supervisor.py UNA VEZ MÁS, en su Modo A real (varias
    secciones MIDI ya generadas + --tension "t1,t2,...,tN" + --report),
    sobre el arco completo del grafo en el orden en que aparecen los
    estados. Esto es puramente informativo/de auditoría — no bloquea ni
    regenera nada, sólo deja un diagnóstico real en
    `<out_dir>/arc_report.json` para que lo revises (contraste entre
    estados, saltos abruptos, etc.), complementario al scoring por
    candidato de score_tension(). Si arc_supervisor.py no está disponible o
    falla, se omite con un aviso."""
    if len(skeleton_paths) < 2:
        return  # el arco (contraste entre secciones) no tiene sentido con un solo estado
    tool = _ecosystem_tool("arc_supervisor.py")
    if tool is None:
        _warn("arc_supervisor.py no encontrado junto a este script; no se audita el arco completo del grafo.")
        return

    report_path = out_dir / "arc_report.json"
    tension_arg = ",".join(f"{t:.3f}" for t in tension_targets)
    cmd = [sys.executable, str(tool), *[str(p) for p in skeleton_paths], "--tension", tension_arg, "--report", str(report_path)]
    _log(verbose, f"invocando arc_supervisor.py (Modo A) sobre el arco completo: {state_names}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        if report_path.exists():
            print(f"auditoría de arco completo (arc_supervisor.py) escrita en {report_path}")
        else:
            _warn(
                f"arc_supervisor.py (auditoría de arco completo) no escribió informe (código {result.returncode}). "
                f"stdout: {result.stdout[-600:] if result.stdout else '(vacío)'} "
                f"stderr: {result.stderr[-600:] if result.stderr else '(vacío)'}"
            )
    except (OSError, subprocess.SubprocessError) as exc:
        _warn(f"no se pudo invocar arc_supervisor.py para la auditoría de arco completo ({exc}).")


def _fallback_tension_score(midi_path: Path) -> float:
    """Heurístico interno (usado si arc_supervisor.py no está disponible o
    falla): combina disonancia de intervalos simultáneos, densidad de notas,
    y RIQUEZA ARMÓNICA (nº de pitch-classes distintas sonando a la vez,
    normalizado). El primer intento de este heurístico (sólo disonancia +
    densidad) tenía un techo real observado ~0.4-0.6 incluso con acordes muy
    extendidos, porque una tríada/7ª/9ª siempre conserva varios intervalos
    consonantes (5ª, 3ª) que diluyen la proporción — no dejaba hueco real
    para llegar a tension_target altos. La riqueza armónica (una 13ª tiene
    hasta 7 pitch-classes distintas sonando a la vez, una tríada sólo 3)
    responde mucho más directamente a --complexity de
    chord_progression_generator.py."""
    import mido

    mid = mido.MidiFile(str(midi_path))
    active = set()
    dissonant = 0
    total = 0
    note_count = 0
    richness_sum = 0.0
    richness_samples = 0
    for msg in mido.merge_tracks(mid.tracks):
        if msg.type == "note_on" and msg.velocity > 0:
            note_count += 1
            for other in active:
                interval = abs(msg.note - other) % 12
                total += 1
                if interval in (1, 2, 6, 10, 11):
                    dissonant += 1
            active.add(msg.note)
            distinct_pcs = len(set(n % 12 for n in active))
            richness_sum += min(1.0, distinct_pcs / 6.0)  # 6 pitch-classes distintas ~ acorde de 11a/13a
            richness_samples += 1
        elif msg.type in ("note_off",) or (msg.type == "note_on" and msg.velocity == 0):
            active.discard(msg.note)

    dissonance_ratio = (dissonant / total) if total else 0.0
    density = min(1.0, note_count / 64.0)
    richness = (richness_sum / richness_samples) if richness_samples else 0.0
    return max(0.0, min(1.0, 0.45 * dissonance_ratio + 0.2 * density + 0.35 * richness))


def _key_string_for_tonicization(state: StateSpec) -> str:
    """tonicization_engine.py espera la tonalidad en el formato que emite
    su propio harmonic_analyzer: 'Cmaj' (mayor) o 'Am' (menor) — letra +
    sostenido/bemol opcional, SIN separar modo aparte. state.key/state.mode
    son campos separados en nuestro contrato (p.ej. key='Am', mode='minor'
    o key='A', mode='major'), así que hay que recomponerlos."""
    tonic = state.key.rstrip("mM") or state.key[0]
    return f"{tonic}maj" if state.mode == "major" else f"{tonic}m"


def apply_tonicization(midi_path: Path, key_str: str, density: float, out_path: Path, verbose: bool) -> bool:
    """Invoca tonicization_engine.py (tu herramienta) para inyectar
    dominantes secundarios reales sobre `midi_path`. Devuelve True si
    escribió `out_path` con éxito. REQUIERE harmonic_analyzer.py junto a
    tonicization_engine.py (dependencia dura de la propia herramienta,
    sale con código 1 en el import si falta) — si no está, esto fallará de
    forma visible en el aviso (con stdout/stderr completos), no en
    silencio."""
    tool = _ecosystem_tool("tonicization_engine.py")
    if tool is None:
        _warn("tonicization_engine.py no encontrado junto a este script; no se pueden inyectar dominantes secundarios.")
        return False
    cmd = [
        sys.executable, str(tool), str(midi_path),
        "--key", key_str,
        "--density", f"{density:.2f}",
        "--seventh",
        "--output", str(out_path),
    ]
    _log(verbose, f"invocando tonicization_engine.py sobre {midi_path.name} (key={key_str!r}, density={density:.2f})")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0 and out_path.exists():
            return True
        _warn(
            f"tonicization_engine.py devolvió código {result.returncode} para {midi_path.name}; "
            "no se inyectaron dominantes secundarios en este intento. "
            f"stdout: {result.stdout[-500:] if result.stdout else '(vacío)'} "
            f"stderr: {result.stderr[-500:] if result.stderr else '(vacío)'}"
        )
        return False
    except (OSError, subprocess.SubprocessError) as exc:
        _warn(f"no se pudo invocar tonicization_engine.py ({exc}); no se inyectaron dominantes secundarios.")
        return False


def generate_skeleton(
    state: StateSpec,
    out_path: Path,
    bars: int,
    tempo: float,
    tolerance: float,
    max_retries: int,
    rng: random.Random,
    verbose: bool,
) -> float:
    """Implementa spec §3.1 puntos 1-2: genera candidato, valida tensión con
    arc_supervisor (o fallback), y si se desvía más allá de `tolerance`
    regenera, hasta `max_retries`. Nunca acepta en silencio un esqueleto que
    no cumple el objetivo: agotados los reintentos, lanza
    SkeletonToleranceExceeded — dejando en disco el MEJOR candidato
    encontrado (no necesariamente el último probado).

    TERCERA CORRECCIÓN (leyendo por fin el código fuente real de
    chord_progression_generator.py — resolve_numeral()): --complexity NO
    es un dial continuo. Sólo importa al cruzar dos umbrales exactos:
    >0.6 añade 7ª a tríadas simples, >0.75 añade 9ª a acordes ya con 7ª
    (p.ej. la V7 de 'jazz'). Ahora se usan peldaños discretos
    (_COMPLEXITY_RUNGS) que SÍ cruzan los umbrales reales.

    Fase 1 (rastreo): probar varios estilos con complexity=0.85 fija (cruza
      AMBOS umbrales), sin asumir un orden de tensión creciente entre ellos
      (datos reales: 'jazz' > 'impressionist', al revés de lo esperado).
    Fase 2 (afinado): si el mejor resultado SE PASA del objetivo, bajar
      peldaños de --complexity para desprender extensiones.
    Fase 3 (tonicización — CUARTA CORRECCIÓN): si el mejor resultado se
      queda CORTO incluso agotando estilo+complexity, es un techo
      ESTRUCTURAL real de chord_progression_generator.py en bloques de
      acordes (confirmado con datos reales: la propia selección de
      patrones de la herramienta prioriza coherencia funcional sobre
      densidad de disonancia, así que un bloque de 8 compases rara vez
      supera ~0.2-0.3 en la métrica de arc_supervisor). --style/
      --complexity ya no pueden ayudar más. Se usa entonces
      tonicization_engine.py para inyectar dominantes secundarios REALES
      sobre el mejor esqueleto encontrado, escalando --density.
    Early-exit en cuanto algún intento cae dentro de tolerancia."""
    best_score = None
    best_style = None
    best_complexity = None
    best_deviation = None
    best_is_on_disk = False  # ¿el mejor candidato encontrado es exactamente lo que hay ahora en out_path?
    attempt = 0

    start_style = _style_for_tension(state.tension_target)
    scan_order = [start_style] + [s for s in _STYLE_CANDIDATES if s != start_style]
    n_scan = min(max_retries, len(scan_order))
    scan_complexity = _COMPLEXITY_RUNGS[0]  # 0.85: cruza ambos umbrales reales

    for style in scan_order[:n_scan]:
        attempt += 1
        generate_skeleton_candidate(state, out_path, bars, tempo, rng, verbose, complexity=scan_complexity, style=style)
        score = score_tension(out_path, state.tension_target, bars, verbose)
        deviation = abs(score - state.tension_target)
        _log(
            verbose,
            f"estado={state.name!r} intento={attempt}/{max_retries} [rastreo de estilo] "
            f"objetivo={state.tension_target:.3f} medido={score:.3f} desviacion={deviation:.3f} "
            f"tolerancia={tolerance:.3f} complexity={scan_complexity:.2f} style={style!r}",
        )
        if best_deviation is None or deviation < best_deviation:
            best_score, best_style, best_complexity, best_deviation = score, style, scan_complexity, deviation
            best_is_on_disk = True
        else:
            best_is_on_disk = False
        if deviation <= tolerance:
            return score

    # Fase 2: afinar --complexity dentro del mejor estilo encontrado, sólo
    # tiene sentido si el problema es SOBRAR tensión (bajar peldaños). Si
    # falta tensión, 0.85 ya cruzó ambos umbrales reales: no hay más
    # margen vía complexity.
    if best_score > state.tension_target:
        for complexity in _COMPLEXITY_RUNGS[1:]:
            if attempt >= max_retries:
                break
            attempt += 1
            generate_skeleton_candidate(state, out_path, bars, tempo, rng, verbose, complexity=complexity, style=best_style)
            score = score_tension(out_path, state.tension_target, bars, verbose)
            deviation = abs(score - state.tension_target)
            _log(
                verbose,
                f"estado={state.name!r} intento={attempt}/{max_retries} [afinado] "
                f"objetivo={state.tension_target:.3f} medido={score:.3f} desviacion={deviation:.3f} "
                f"tolerancia={tolerance:.3f} complexity={complexity:.2f} style={best_style!r}",
            )
            if deviation <= tolerance:
                return score
            if deviation < best_deviation:
                best_score, best_complexity, best_deviation = score, complexity, deviation
                best_is_on_disk = True
            else:
                best_is_on_disk = False

    # Fase 3: si aún falta tensión, --style/--complexity ya no pueden
    # ayudar más (techo estructural del generador de bloques de acordes) —
    # inyectar dominantes secundarios reales con tonicization_engine.py.
    #
    # CUARTA CORRECCIÓN (con datos + matemática real): NO se toniciza el
    # mejor estilo encontrado (p.ej. 'jazz'), sino una base DIATÓNICA
    # limpia generada aparte (complexity=0.3, sin 7as/9as) — confirmado
    # con el MIDI real de Pablo: 'jazz' a complexity=0.85 ya parte de
    # disonancia 44/152=0.289 (usa 7as por todas partes), así que
    # sustituir un acorde YA disonante (m7, con su propia 7a) por otro
    # disonante (dominante) apenas mueve la proporción. Una base diatónica
    # parte de 0/48=0.000 — cada dominante secundario inyectado SÍ suma
    # disonancia nueva de verdad en vez de canjear una por otra.
    #
    # AUN ASÍ hay un techo matemático real, no sólo de esta herramienta:
    # compute_tension() de arc_supervisor.py es una PROPORCIÓN sobre TODOS
    # los pares de notas simultáneas de la sección entera. Una proyección
    # optimista (10 de 16 grupos de acorde tonicizados, partiendo de cero
    # disonancia) da un techo ≈0.28 — para llegar a 0.9 haría falta que la
    # inmensa mayoría de TODAS las notas simultáneas de los 8 compases
    # choquen entre sí, que ya no es una progresión funcional sino un
    # clúster — así que si tension_target es 0.7-0.9, ninguna combinación
    # de --style/--complexity/tonicización sobre una progresión musicalmente
    # coherente va a alcanzarlo. Se avisa explícitamente de esto.
    if best_score < state.tension_target and attempt < max_retries:
        key_str = _key_string_for_tonicization(state)
        tonic_base = out_path.with_name(out_path.stem + ".tonic_base.mid")
        tonic_tmp = out_path.with_name(out_path.stem + ".tonic_candidate.mid")
        attempt += 1
        generate_skeleton_candidate(
            state, tonic_base, bars, tempo, rng, verbose,
            complexity=0.30, style="diatonic", tension_profile="neutral",
        )
        base_score = score_tension(tonic_base, state.tension_target, bars, verbose)
        _log(
            verbose,
            f"estado={state.name!r} intento={attempt}/{max_retries} [base para tonicización] "
            f"base diatónica limpia generada, tensión de partida medida={base_score:.3f} "
            "(objetivo: máximo margen para que tonicization_engine.py sume disonancia nueva)",
        )
        _warn(
            f"estado={state.name!r}: con el mejor estilo encontrado ({best_style!r}) a "
            f"complexity=0.85 sólo se alcanzó tensión medida={best_score:.3f} — techo estructural de "
            "chord_progression_generator.py en bloques de acordes. Probando tonicization_engine.py "
            "sobre una base diatónica limpia (más margen que tonicizar un estilo ya alterado). "
            "AVISO: si tension_target es alto (>0.5), es matemáticamente improbable alcanzarlo por esta "
            "vía — compute_tension() es una proporción sobre TODOS los pares de notas simultáneas de la "
            "sección; para llegar ahí haría falta que la mayoría de la sección entera choque, que ya no "
            "sería una progresión funcional sino un clúster."
        )
        for density in (1.0, 0.6, 0.3):  # probar el techo primero: es lo más informativo
            if attempt >= max_retries:
                break
            attempt += 1
            ok = apply_tonicization(tonic_base, key_str, density, tonic_tmp, verbose)
            if not ok:
                break  # la herramienta falló (p.ej. falta playability_auditor.py): no insistir con más densidades
            score = score_tension(tonic_tmp, state.tension_target, bars, verbose)
            deviation = abs(score - state.tension_target)
            _log(
                verbose,
                f"estado={state.name!r} intento={attempt}/{max_retries} [tonicización sobre base diatónica] "
                f"objetivo={state.tension_target:.3f} medido={score:.3f} desviacion={deviation:.3f} "
                f"tolerancia={tolerance:.3f} density={density:.2f}",
            )
            if deviation <= tolerance:
                shutil.copy(tonic_tmp, out_path)
                tonic_base.unlink(missing_ok=True)
                tonic_tmp.unlink(missing_ok=True)
                return score
            if deviation < best_deviation:
                best_score, best_deviation = score, deviation
                shutil.copy(tonic_tmp, out_path)
                best_is_on_disk = True
        tonic_base.unlink(missing_ok=True)
        tonic_tmp.unlink(missing_ok=True)

    # Nunca se alcanzó la tolerancia: se deja en disco el MEJOR candidato
    # encontrado (no el último probado, que podría ser peor) antes de fallar.
    if not best_is_on_disk:
        generate_skeleton_candidate(state, out_path, bars, tempo, rng, verbose, complexity=best_complexity, style=best_style)

    raise SkeletonToleranceExceeded(
        f"Estado {state.name!r}: no se alcanzó tension_target={state.tension_target:.3f} "
        f"dentro de tolerancia={tolerance:.3f} tras {max_retries} reintentos "
        f"(mejor medición encontrada: {best_score:.3f}, style={best_style!r}, complexity={best_complexity:.2f})."
    )


_ORCHESTRAL_COLORIST_EMOTIONS = {
    "melancolia", "calidez", "fragilidad", "angustia",
    "esperanza", "serenidad", "tension", "triunfo",
}


def orchestrate_layer(skeleton_path: Path, layer: LayerSpec, out_path: Path, verbose: bool):
    """Copia el esqueleto y le aplica timbre vía orchestral_colorist.py.

    layer.instrument se interpreta como la etiqueta de EMOCIÓN que consume
    orchestral_colorist (spec §2) — debe ser una de las 8 del catálogo real:
    melancolia, calidez, fragilidad, angustia, esperanza, serenidad,
    tension, triunfo. Se invoca por CLI (subprocess) con sus flags
    documentadas (`--emotion`, `--output`), NO importando el módulo y
    adivinando nombres de parámetro de colorize_midi() — eso falló contra
    la herramienta real (colorize_midi() no acepta output= como keyword) y
    la CLI es la superficie estable y documentada. Si la etiqueta no está
    en el catálogo, o la herramienta no está disponible/falla, se usa la
    asignación GM interna por palabra clave."""
    if layer.instrument not in _ORCHESTRAL_COLORIST_EMOTIONS:
        _warn(
            f"instrument={layer.instrument!r} de la capa {layer.name!r} no es una emoción válida de "
            f"orchestral_colorist.py ({sorted(_ORCHESTRAL_COLORIST_EMOTIONS)}); usando asignación GM interna."
        )
        _fallback_orchestrate_layer(skeleton_path, layer, out_path)
        return

    tool = _ecosystem_tool("orchestral_colorist.py")
    if tool is not None:
        cmd = [sys.executable, str(tool), str(skeleton_path), "--emotion", layer.instrument, "--output", str(out_path)]
        _log(verbose, f"invocando orchestral_colorist.py --emotion {layer.instrument!r} para capa {layer.name!r}")
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if result.returncode == 0 and out_path.exists():
                return
            _warn(
                f"orchestral_colorist.py devolvió código {result.returncode} para {layer.instrument!r}; "
                f"usando fallback interno. stdout: {result.stdout[-400:] if result.stdout else '(vacío)'} "
                f"stderr: {result.stderr[-400:] if result.stderr else '(vacío)'}"
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _warn(f"no se pudo invocar orchestral_colorist.py ({exc}); usando fallback interno.")
    else:
        _warn("orchestral_colorist.py no encontrado junto a este script; usando asignación GM interna por etiqueta de instrumento.")

    _fallback_orchestrate_layer(skeleton_path, layer, out_path)


_GM_PROGRAM_BY_KEYWORD = [
    ("percus", 0),       # sin program change útil; se trata aparte (canal 10)
    ("cuerd", 48),        # string ensemble
    ("string", 48),
    ("violin", 40),
    ("viola", 41),
    ("cello", 42),
    ("contrabaj", 43),
    ("coro", 52),         # choir aahs
    ("choir", 52),
    ("voz", 53),
    ("metal", 61),        # brass section
    ("brass", 61),
    ("trompet", 56),
    ("trombon", 57),
    ("madera", 71),       # clarinet
    ("flaut", 73),
    ("oboe", 68),
    ("clarinet", 71),
    ("piano", 0),
    ("arpa", 46),
    ("harp", 46),
    ("sintetiz", 88),
    ("synth", 88),
]


def _gm_program_for_instrument(instrument_label: str) -> int:
    label = instrument_label.lower()
    for keyword, program in _GM_PROGRAM_BY_KEYWORD:
        if keyword in label:
            return program
    return 0  # acoustic grand piano por defecto


def _fallback_orchestrate_layer(skeleton_path: Path, layer: LayerSpec, out_path: Path):
    import mido

    mid = mido.MidiFile(str(skeleton_path))
    program = _gm_program_for_instrument(layer.instrument)
    is_percussion = "percus" in layer.instrument.lower()

    for track in mid.tracks:
        if is_percussion:
            for msg in track:
                if msg.type in ("note_on", "note_off"):
                    msg.channel = 9  # canal 10 (GM percusión), 0-indexado
        else:
            track.insert(0, mido.Message("program_change", program=program, time=0))
            for msg in track:
                if msg.type == "track_name":
                    msg.name = f"{layer.name}_{layer.instrument}"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    mid.save(str(out_path))


# --- restricción dura de banda de registro -----------------------------------

def enforce_register_band(midi_path: Path, band: tuple, out_path: Path):
    """Transpone por octavas cada nota fuera de `band` hasta caer dentro (o,
    si la banda es más estrecha que una octava y no hay solución exacta por
    octavas, la fija al límite más cercano). Se aplica como restricción
    DURA (spec §3.1.3), no como aviso: el fichero resultante SIEMPRE cumple
    la banda."""
    import mido

    lo, hi = band
    mid = mido.MidiFile(str(midi_path))
    for track in mid.tracks:
        for msg in track:
            if msg.type in ("note_on", "note_off") and hasattr(msg, "note"):
                note = msg.note
                if lo <= note <= hi:
                    continue
                # buscar el desplazamiento de octava que la acerque más a la banda
                best = note
                best_dist = min(abs(note - lo), abs(note - hi))
                for k in range(-10, 11):
                    candidate = note + 12 * k
                    if lo <= candidate <= hi:
                        best = candidate
                        best_dist = 0
                        break
                    dist = min(abs(candidate - lo), abs(candidate - hi))
                    if dist < best_dist:
                        best = candidate
                        best_dist = dist
                # clamp final por si la banda es más estrecha que 12 semitonos
                best = max(lo, min(hi, best))
                msg.note = best

    out_path.parent.mkdir(parents=True, exist_ok=True)
    mid.save(str(out_path))


def actual_note_range(midi_path: Path) -> Optional[tuple]:
    import mido

    mid = mido.MidiFile(str(midi_path))
    notes = [
        msg.note
        for track in mid.tracks
        for msg in track
        if msg.type == "note_on" and msg.velocity > 0
    ]
    if not notes:
        return None
    return (min(notes), max(notes))


def check_register_collisions(layer_ranges: dict, tolerance_semitones: int) -> list:
    """layer_ranges: {layer_name: (min,max) real, tras enforce_register_band}.
    Devuelve una lista de tuplas (layer_a, layer_b, overlap) para cada par
    cuyo solape excede `tolerance_semitones`. Con enforce_register_band ya
    aplicado como restricción dura, esto actúa como red de seguridad final
    (spec §3.1.4)."""
    collisions = []
    names = list(layer_ranges.keys())
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            lo_a, hi_a = layer_ranges[a]
            lo_b, hi_b = layer_ranges[b]
            overlap = min(hi_a, hi_b) - max(lo_a, lo_b)
            if overlap > tolerance_semitones:
                collisions.append((a, b, overlap))
    return collisions


# --- leitmotif -----------------------------------------------------------

def seed_leitmotif(layer_path: Path, treatment: str, band: tuple, tempo: float, out_path: Path, verbose: bool, bank_path: Optional[str] = None):
    """Intenta leitmotif_tracker.py `inject`; si no hay banco/tool disponible,
    o si la inyección real falla, usa un motivo interno de 4 notas
    transformado según el perfil de tratamiento, como placeholder
    estructural.

    AVISO DE HONESTIDAD: definitions.txt no documenta el esquema exacto de
    schedule.json que espera `inject` (sólo que "stitcher.py genera
    leitmotif_schedule.json compatible"). El schedule que se construye aquí
    abajo es una MEJOR SUPOSICIÓN razonable, no una integración verificada
    contra el esquema real — si tu leitmotif_tracker.py espera otra
    estructura, `inject` fallará (con --verbose verás el código de salida y
    stderr) y este layer caerá automáticamente al motivo placeholder sin
    interrumpir el resto del pipeline. Si me pasas un schedule.json de
    ejemplo generado por tu propio flujo (suggest/plan/stitcher), puedo
    corregir esto para que sea una integración real."""
    tool = _ecosystem_tool("leitmotif_tracker.py")
    bank = Path(bank_path) if bank_path else _ecosystem_tool("leitmotif_bank.json")
    if bank_path and not Path(bank_path).exists():
        _warn(f"--leitmotif-bank {bank_path!r} no existe; usando motivo placeholder interno.")
        bank = None
    if tool is not None and bank is not None:
        schedule = layer_path.with_suffix(".leitmotif_schedule.json")
        try:
            with open(schedule, "w", encoding="utf-8") as f:
                json.dump({"treatment": treatment, "target": str(layer_path)}, f)
            cmd = [sys.executable, str(tool), "inject", str(layer_path), str(schedule), "--bank", str(bank)]
            _log(verbose, f"invocando leitmotif_tracker.py inject sobre {layer_path.name}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if result.returncode == 0:
                shutil.copy(layer_path, out_path)
                return
            _warn(
                f"leitmotif_tracker.py inject devolvió código {result.returncode}; usando motivo placeholder interno. "
                f"stdout: {result.stdout[-400:] if result.stdout else '(vacío)'} "
                f"stderr: {result.stderr[-400:] if result.stderr else '(vacío)'}"
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _warn(f"no se pudo invocar leitmotif_tracker.py ({exc}); usando motivo placeholder interno.")
    else:
        _warn(
            "leitmotif_tracker.py y/o un banco de motivos no están disponibles "
            "(requiere un motivo pre-registrado, fuera del alcance de esta spec); "
            f"sembrando motivo placeholder interno con perfil {treatment!r}."
        )

    _fallback_seed_leitmotif(layer_path, treatment, band, tempo, out_path)


def _fallback_seed_leitmotif(layer_path: Path, treatment: str, band: tuple, tempo: float, out_path: Path):
    import mido

    mid = mido.MidiFile(str(layer_path))
    ticks_per_beat = mid.ticks_per_beat
    lo, hi = band
    center = (lo + hi) // 2
    # célula de 4 notas: 1-2-b3-5 relativos al centro de la banda (contorno reconocible)
    cell = [center, center + 2, center + 3, center + 7]
    cell = [max(lo, min(hi, n)) for n in cell]

    augmented = "tutti" in treatment or "augment" in treatment
    solo = "solo" in treatment or "legato" in treatment
    velocity = 100 if augmented else (58 if solo else 78)
    note_ticks = (ticks_per_beat * 2) if augmented else (ticks_per_beat // 2 if not solo else ticks_per_beat)
    doubled = augmented

    track = mido.MidiTrack()
    track.append(mido.MetaMessage("track_name", name=f"leitmotif_{treatment}", time=0))
    for pitch in cell:
        track.append(mido.Message("note_on", note=pitch, velocity=velocity, time=0))
        if doubled and pitch + 12 <= hi:
            track.append(mido.Message("note_on", note=pitch + 12, velocity=max(1, velocity - 10), time=0))
        track.append(mido.Message("note_off", note=pitch, velocity=0, time=note_ticks))
        if doubled and pitch + 12 <= hi:
            track.append(mido.Message("note_off", note=pitch + 12, velocity=0, time=0))
    mid.tracks.append(track)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    mid.save(str(out_path))


# --- puntos de sincronía / cadencia ---------------------------------------

def _import_cadence_designer():
    """Importa cadence_designer.py como módulo (mismo directorio que este
    script), reutilizando su chord_name_to_midi (vocabulario de numerales
    romanos con 7as/dim/aug/half-dim, mucho más rico que un parser propio)
    y su insert_cadences_into_midi (pista de auditoría "Cadences")."""
    here = str(Path(__file__).resolve().parent)
    if here not in sys.path:
        sys.path.insert(0, here)
    try:
        import cadence_designer  # type: ignore
        return cadence_designer
    except ImportError:
        return None


# Tabla mínima de acordes, usada SÓLO si cadence_designer.py no está
# disponible: numerales romanos (relativos a C mayor, se transporta por
# posición de grado) y símbolos de letra básicos.
_ROMAN_DEGREES = {"I": 0, "II": 1, "III": 2, "IV": 3, "V": 4, "VI": 5, "VII": 6}
_LETTER_PC = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def _key_root_pitch(key: str) -> int:
    """Convierte una tónica ("C", "F#", "Bb"...) a nota MIDI en octava 4."""
    letter = key[0].upper() if key else "C"
    root_pc = _LETTER_PC.get(letter, 0)
    idx = 1
    if idx < len(key) and key[idx] in "#b":
        root_pc += 1 if key[idx] == "#" else -1
        idx += 1
    return 60 + (root_pc % 12)


def _chord_symbol_to_pitch_classes(symbol: str) -> list:
    """Parser interno de último recurso (sin cadence_designer.py). Acepta
    numerales romanos ("I", "V", "vi"...) sobre C mayor, o símbolos de letra
    simples ("C", "G7", "Am")."""
    s = symbol.strip()
    upper = s.upper()
    if upper in _ROMAN_DEGREES:
        degree = _ROMAN_DEGREES[upper]
        triad = [_MAJOR_SCALE[degree % 7], _MAJOR_SCALE[(degree + 2) % 7], _MAJOR_SCALE[(degree + 4) % 7]]
        return sorted(set(pc % 12 for pc in triad))

    root_letter = s[0].upper()
    if root_letter not in _LETTER_PC:
        raise ValueError(f"Símbolo de acorde no reconocido: {symbol!r}")
    idx = 1
    root_pc = _LETTER_PC[root_letter]
    if idx < len(s) and s[idx] in "#b":
        root_pc += 1 if s[idx] == "#" else -1
        idx += 1
    rest = s[idx:].lower()
    minor = rest.startswith("m") and not rest.startswith("maj")
    seventh = "7" in rest
    third = root_pc + (3 if minor else 4)
    fifth = root_pc + 7
    pcs = [root_pc % 12, third % 12, fifth % 12]
    if seventh:
        pcs.append((root_pc + (10 if minor else 11)) % 12)
    return sorted(set(pcs))


def resolve_chord_pitch_classes(target_chord: str, key: str, mode: str, verbose: bool) -> list:
    """Resuelve `target_chord` (numeral romano, ej. "I", "V7", "vi") a
    pitch-classes (0-11) en la tonalidad `key`/`mode`. Usa
    cadence_designer.chord_name_to_midi si el módulo está disponible; si no,
    el parser interno (sólo triadas simples, siempre en modo mayor)."""
    cd = _import_cadence_designer()
    if cd is not None:
        try:
            notes = cd.chord_name_to_midi(target_chord, key, mode)
            _log(verbose, f"cadence_designer.chord_name_to_midi({target_chord!r}, {key!r}, {mode!r}) -> {notes}")
            return sorted(set(n % 12 for n in notes))
        except Exception as exc:  # noqa: BLE001
            _warn(f"cadence_designer.chord_name_to_midi falló para {target_chord!r} ({exc}); usando parser interno.")
    else:
        _warn("cadence_designer.py no encontrado junto a este script; usando parser de acordes interno (sólo triadas mayores).")

    return _chord_symbol_to_pitch_classes(target_chord)


def add_cadence_guide_track(
    skeleton_path: Path,
    sync_points_beats: list,
    target_chord: str,
    key: str,
    mode: str,
    beats_per_bar: int,
    out_path: Path,
    verbose: bool,
):
    """Añade al esqueleto una pista MIDI adicional "Cadences" (sólo
    documental/de auditoría — no se usa en tiempo de ejecución, ver spec
    §3.3) marcando visualmente en el DAW dónde se fuerza cada acorde de
    llegada, vía cadence_designer.insert_cadences_into_midi. Si
    cadence_designer.py no está disponible, se omite sin fallar (no es
    imprescindible para la corrección musical, sólo para inspección)."""
    if not sync_points_beats:
        return
    cd = _import_cadence_designer()
    if cd is None:
        _warn("cadence_designer.py no disponible; no se añade la pista de auditoría 'Cadences'.")
        return

    cadences = []
    for sp in sync_points_beats:
        position = max(1, int(round(sp / beats_per_bar)))  # compás 1-indexado que termina justo en el sync point
        cadences.append(cd.Cadence(
            position=position,
            cad_type="adaptive_graph_arrival",
            key=key,
            strength=1.0,
            tension_before=0.0,
            tension_after=0.0,
            description=f"Llegada forzada del grafo adaptativo en sync point (beat={sp})",
            progression=[target_chord],
            bass_degrees=[target_chord],
            is_final=False,
            section="sync_point",
        ))

    total_bars = max(cad.position for cad in cadences)
    plan = cd.CadencePlan(
        total_bars=total_bars, key=key, mode=mode, form="adaptive_graph",
        cadences=cadences, tension_curve=[0.0] * total_bars,
    )
    try:
        cd.insert_cadences_into_midi(str(skeleton_path), plan, str(out_path), velocity=45)
        _log(verbose, f"pista 'Cadences' de auditoría añadida a {out_path.name} ({len(cadences)} punto(s))")
    except Exception as exc:  # noqa: BLE001
        _warn(f"cadence_designer.insert_cadences_into_midi falló ({exc}); no se añadió la pista guía.")


def _resolve_target_chord(graph: GraphSpec, state: StateSpec) -> Optional[str]:
    if graph.shared_transition_chord:
        return graph.shared_transition_chord
    return state.arrival_chord  # puede ser None: entonces no se fuerza nada


def force_cadence_at_syncpoints(
    midi_path: Path,
    sync_points_beats: list,
    target_chord: str,
    key: str,
    mode: str,
    tempo: float,
    beats_per_bar: int,
    band: Optional[tuple],
    out_path: Path,
    verbose: bool = False,
):
    """Fuerza, en la ventana de `beats_per_bar` beats inmediatamente anterior
    a cada sync point, las pitch-classes de `target_chord` en `key`/`mode`
    (spec §3.1.5), resueltas vía cadence_designer.chord_name_to_midi. Si
    `band` se indica, las notas resultantes se transportan dentro de esa
    banda (para que las capas hereden el punto de llegada del esqueleto sin
    desviarse — spec §5.1.3)."""
    import mido

    pitch_classes = resolve_chord_pitch_classes(target_chord, key, mode, verbose)
    mid = mido.MidiFile(str(midi_path))
    ticks_per_beat = mid.ticks_per_beat
    bar_ticks = ticks_per_beat * beats_per_bar

    for track in mid.tracks:
        abs_tick = 0
        for msg in track:
            abs_tick += msg.time
            if msg.type in ("note_on", "note_off") and hasattr(msg, "note"):
                beat_pos = abs_tick / ticks_per_beat
                for sync_beat in sync_points_beats:
                    window_start = sync_beat - beats_per_bar
                    window_end = sync_beat
                    if window_start <= beat_pos < window_end:
                        target_pc = min(pitch_classes, key=lambda pc: abs((msg.note % 12) - pc))
                        new_note = (msg.note - (msg.note % 12)) + target_pc
                        if band is not None:
                            lo, hi = band
                            while new_note < lo:
                                new_note += 12
                            while new_note > hi:
                                new_note -= 12
                            new_note = max(lo, min(hi, new_note))
                        msg.note = new_note
                        break

    out_path.parent.mkdir(parents=True, exist_ok=True)
    mid.save(str(out_path))


# --- audio ------------------------------------------------------------------

def render_midi_to_wav(midi_path: Path, out_path: Path, sample_rate: int, verbose: bool):
    """Usa timidity si está en PATH; si no, un sintetizador aditivo interno
    (sumas de sinusoides con envolvente ADSR simple) para que --render-audio
    funcione de extremo a extremo sin dependencias externas pesadas."""
    timidity = shutil.which("timidity")
    if timidity:
        cmd = [timidity, str(midi_path), "-Ow", "-o", str(out_path), "--sampling-freq", str(sample_rate)]
        _log(verbose, f"renderizando {midi_path.name} con timidity")
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
            if result.returncode == 0 and out_path.exists():
                return
            _warn(f"timidity devolvió código {result.returncode}; usando sintetizador interno.")
        except (OSError, subprocess.SubprocessError) as exc:
            _warn(f"no se pudo invocar timidity ({exc}); usando sintetizador interno.")
    else:
        _log(verbose, f"timidity no encontrado en PATH; renderizando {midi_path.name} con sintetizador aditivo interno")
    _fallback_synth_midi_to_wav(midi_path, out_path, sample_rate)


def _fallback_synth_midi_to_wav(midi_path: Path, out_path: Path, sample_rate: int):
    import wave
    import mido
    import numpy as np

    mid = mido.MidiFile(str(midi_path))
    events = []  # (time_seconds, type, note, velocity)
    for track in mid.tracks:
        t = 0.0
        tempo = 500000  # microsegundos por beat, default 120bpm
        for msg in track:
            t += mido.tick2second(msg.time, mid.ticks_per_beat, tempo)
            if msg.type == "set_tempo":
                tempo = msg.tempo
            if msg.type == "note_on" and msg.velocity > 0:
                events.append((t, "on", msg.note, msg.velocity))
            elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
                events.append((t, "off", msg.note, 0))

    if not events:
        duration = 0.5
    else:
        duration = max(t for t, *_ in events) + 0.5

    n_samples = max(1, int(duration * sample_rate))
    buffer = np.zeros(n_samples, dtype=np.float64)
    open_notes = {}
    events.sort(key=lambda e: (e[0], 0 if e[1] == "off" else 1))
    for t, kind, note, vel in events:
        if kind == "on":
            open_notes[note] = t
        else:
            start = open_notes.pop(note, t)
            _add_note_tone(buffer, sample_rate, start, t, note, 90)
    for note, start in open_notes.items():
        _add_note_tone(buffer, sample_rate, start, duration, note, 90)

    peak = np.max(np.abs(buffer)) if buffer.size else 0.0
    if peak > 1e-9:
        buffer = buffer / peak * 0.85
    pcm = (buffer * 32767).astype(np.int16)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm.tobytes())


def _add_note_tone(buffer, sample_rate: int, start_s: float, end_s: float, note: int, velocity: int):
    import numpy as np

    start_i = int(start_s * sample_rate)
    end_i = int(end_s * sample_rate)
    n = max(1, end_i - start_i)
    if start_i >= buffer.shape[0]:
        return
    n = min(n, buffer.shape[0] - start_i)
    freq = 440.0 * (2.0 ** ((note - 69) / 12.0))
    t = np.arange(n) / sample_rate
    amp = (velocity / 127.0) * 0.2
    tone = amp * np.sin(2 * np.pi * freq * t)
    # envolvente simple: ataque/decay cortos para evitar clicks
    attack = min(n, int(0.01 * sample_rate))
    release = min(n, int(0.03 * sample_rate))
    if attack > 0:
        tone[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        tone[-release:] *= np.linspace(1, 0, release)
    buffer[start_i:start_i + n] += tone


# ══════════════════════════════════════════════════════════════════════════
# 4. Pipeline principal (spec §3.1, por cada StateSpec)
# ══════════════════════════════════════════════════════════════════════════

def compose_state(
    graph: GraphSpec,
    state: StateSpec,
    out_dir: Path,
    args,
    rng: random.Random,
) -> tuple:
    """Devuelve (skeleton_path, {layer_name: layer_path})."""
    tempo = state.tempo_bpm or args.tempo
    beats_per_bar = 4

    skeleton_path = out_dir / f"{state.name}.skeleton.mid"
    generate_skeleton(
        state, skeleton_path, args.bars_per_state, tempo,
        args.tension_tolerance, args.max_retries, rng, args.verbose,
    )

    target_chord = _resolve_target_chord(graph, state)
    if target_chord and state.sync_points_beats:
        force_cadence_at_syncpoints(
            skeleton_path, state.sync_points_beats, target_chord, state.key, state.mode,
            tempo, beats_per_bar, band=None, out_path=skeleton_path, verbose=args.verbose,
        )
    elif state.sync_points_beats:
        _warn(
            f"estado {state.name!r} tiene sync_points_beats pero no hay "
            "shared_transition_chord de grafo ni arrival_chord propio: "
            "no se fuerza cadencia de llegada."
        )

    layer_paths = {}
    for layer in state.layers:
        raw_path = out_dir / f"{state.name}__{layer.name}.raw.mid"
        orchestrate_layer(skeleton_path, layer, raw_path, args.verbose)

        banded_path = out_dir / f"{state.name}__{layer.name}.mid"
        enforce_register_band(raw_path, layer.register_band, banded_path)
        raw_path.unlink(missing_ok=True)

        if target_chord and state.sync_points_beats:
            force_cadence_at_syncpoints(
                banded_path, state.sync_points_beats, target_chord, state.key, state.mode,
                tempo, beats_per_bar, band=layer.register_band, out_path=banded_path, verbose=args.verbose,
            )

        if layer.leitmotif_treatment:
            seeded_path = out_dir / f"{state.name}__{layer.name}.mid"
            seed_leitmotif(
                banded_path, layer.leitmotif_treatment, layer.register_band, tempo,
                seeded_path, args.verbose, bank_path=getattr(args, "leitmotif_bank", None),
            )

        layer_paths[layer.name] = banded_path

    # spec §3.1.4 — colisión de registro, con reintento acotado
    for collision_attempt in range(1, args.collision_max_retries + 1):
        ranges = {}
        for name, path in layer_paths.items():
            rng_actual = actual_note_range(path)
            if rng_actual is not None:
                ranges[name] = rng_actual
        collisions = check_register_collisions(ranges, args.register_overlap_tolerance)
        if not collisions:
            break
        _log(
            args.verbose,
            f"estado={state.name!r} colisiones de registro (intento {collision_attempt}): {collisions}",
        )
        for a, b, _overlap in collisions:
            # regenerar la capa infractora (la de mayor solape declarado con
            # su vecina) re-aplicando la restricción dura de banda
            offending = a
            layer_spec = next(l for l in state.layers if l.name == offending)
            enforce_register_band(layer_paths[offending], layer_spec.register_band, layer_paths[offending])
    else:
        if collisions:
            raise RegisterCollisionUnresolved(
                f"Estado {state.name!r}: colisión de registro sin resolver tras "
                f"{args.collision_max_retries} reintentos: {collisions}"
            )

    # pista de auditoría "Cadences" (sólo documental — se añade DESPUÉS de
    # que las capas ya se hayan orquestado a partir del esqueleto limpio,
    # para que nunca se filtre en los ficheros de capa reales)
    if target_chord and state.sync_points_beats:
        add_cadence_guide_track(
            skeleton_path, state.sync_points_beats, target_chord, state.key, state.mode,
            beats_per_bar, out_path=skeleton_path, verbose=args.verbose,
        )

    return skeleton_path, layer_paths


def compose_layer_pack(graph: GraphSpec, out_dir: Path, args) -> LayerPackManifest:
    out_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)

    layer_files = {}
    skeleton_files = {}
    tempo_bpm = {}

    for state in graph.states:
        _log(args.verbose, f"generando estado {state.name!r}...")
        skeleton_path, layers = compose_state(graph, state, out_dir, args, rng)
        skeleton_files[state.name] = str(skeleton_path)
        tempo_bpm[state.name] = state.tempo_bpm or args.tempo

        for layer_name, layer_path in layers.items():
            final_path = layer_path
            if args.render_audio:
                wav_path = layer_path.with_suffix(".wav")
                render_midi_to_wav(layer_path, wav_path, args.sample_rate, args.verbose)
                final_path = wav_path
            layer_files[(state.name, layer_name)] = str(final_path)

    audit_full_arc(
        [s.name for s in graph.states],
        [Path(skeleton_files[s.name]) for s in graph.states],
        [s.tension_target for s in graph.states],
        out_dir, args.verbose,
    )

    manifest = LayerPackManifest(
        graph=graph,
        layer_files=layer_files,
        skeleton_files=skeleton_files,
        sample_rate=args.sample_rate,
        tempo_bpm=tempo_bpm,
    )
    manifest.save(out_dir / "manifest.json")
    return manifest


# ══════════════════════════════════════════════════════════════════════════
# 5. CLI
# ══════════════════════════════════════════════════════════════════════════

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Genera un paquete de capas (layer pack) a partir de un GraphSpec para música adaptativa.",
    )
    p.add_argument("graph_spec", help="Ruta al GraphSpec serializado (JSON)")
    p.add_argument("--out-dir", default="layer_pack", help="Carpeta de salida (default: layer_pack)")
    p.add_argument("--tension-tolerance", type=float, default=0.1, help="Tolerancia de arc_supervisor (default: 0.1)")
    p.add_argument("--max-retries", type=int, default=3, help="Reintentos de esqueleto antes de fallar (default: 3)")
    p.add_argument("--render-audio", action="store_true", help="Renderiza además cada capa a WAV")
    p.add_argument("--bars-per-state", type=int, default=8, help="Compases del esqueleto de cada estado (default: 8)")
    p.add_argument("--tempo", type=float, default=120.0, help="Tempo por defecto si el estado no declara uno (default: 120)")
    p.add_argument("--register-overlap-tolerance", type=int, default=2, help="Semitonos de solape permitido (default: 2)")
    p.add_argument("--collision-max-retries", type=int, default=3, help="Reintentos ante colisión de registro (default: 3)")
    p.add_argument("--seed", type=int, default=42, help="Semilla determinista para fallbacks internos (default: 42)")
    p.add_argument("--sample-rate", type=int, default=44100, help="Sample rate del audio renderizado (default: 44100)")
    p.add_argument("--leitmotif-bank", default=None, help="Ruta al banco de leitmotifs (default: leitmotif_bank.json junto al script)")
    p.add_argument("--verbose", action="store_true", help="Informe detallado del pipeline")
    return p


def main(argv=None):
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    graph = GraphSpec.load(args.graph_spec)
    out_dir = Path(args.out_dir)

    try:
        manifest = compose_layer_pack(graph, out_dir, args)
    except (SkeletonToleranceExceeded, RegisterCollisionUnresolved) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    n_layers = sum(len(s.layers) for s in graph.states)
    print(
        f"layer pack generado en {out_dir}/ — {len(graph.states)} estado(s), "
        f"{n_layers} capa(s), manifest.json escrito."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
