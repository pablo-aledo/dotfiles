"""Reward terminal (§5.4).

reward = w_arc * arc_supervisor_score(final_midi, plan)
       + w_eval * eval_provider.score(final_midi, ctx)

Penalización dura (-1.0) si algún step falló de forma no recuperable.
"""
from __future__ import annotations
import json
import logging
import subprocess
import tempfile
from pathlib import Path

log = logging.getLogger("rl_pipeline.reward")


def arc_supervisor_score(midi_path: str, ctx: dict, root: str = ".") -> float:
    """Ejecuta arc_supervisor.py sobre el MIDI final + plan, normaliza a [0,1]."""
    script = Path(root) / "arc_supervisor.py"
    if not script.exists() or not midi_path or not Path(midi_path).exists():
        return 0.5
    sections = ctx.get("sections_bars")  # lista de compases por sección
    curves = ctx.get("curves_path")
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            report = f.name
        cmd = ["python", str(script), midi_path, "--report", report]
        if sections and len(sections) > 1:
            cmd += ["--sections"] + [str(s) for s in sections]
        if curves:
            cmd += ["--curves", str(curves)]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120,
                           cwd=str(root))
        # arc_supervisor exita !=0 cuando detecta problemas (no es error real):
        # el reporte se escribe igualmente. Sólo fallamos si no hay reporte.
        if not Path(report).exists():
            log.warning("arc_supervisor sin reporte: rc=%s stderr=%s",
                        r.returncode, r.stderr[-300:])
            return 0.5
        data = json.loads(Path(report).read_text())
        summary = data.get("summary", {})
        if summary.get("ok", False):
            return 1.0
        n_problems = summary.get("n_problems", 0)
        secs = data.get("sections", [])
        if secs:
            ok_frac = sum(1 for s in secs if s.get("ok")) / len(secs)
            return max(0.0, min(1.0, ok_frac * (1.0 - 0.1 * n_problems)))
        return max(0.0, 1.0 - 0.2 * n_problems)
    except Exception as e:
        log.warning("arc_supervisor exception: %s", e)
        return 0.5
    finally:
        try:
            import os as _os; _os.unlink(report)
        except Exception:
            pass


def compute_terminal_reward(
    final_midi: str | None,
    ctx: dict,
    eval_provider,
    w_arc: float,
    w_eval: float,
    root: str = ".",
) -> float:
    """reward = w_arc*arc + w_eval*eval. Si no hay midi final, 0.0."""
    if not final_midi or not Path(final_midi).exists():
        return 0.0
    arc = arc_supervisor_score(final_midi, ctx, root=root)
    try:
        ev = eval_provider.score(final_midi, ctx)
    except Exception as e:
        log.warning("eval_provider falló: %s — usando 0.0", e)
        ev = 0.0
    return float(w_arc) * arc + float(w_eval) * ev
