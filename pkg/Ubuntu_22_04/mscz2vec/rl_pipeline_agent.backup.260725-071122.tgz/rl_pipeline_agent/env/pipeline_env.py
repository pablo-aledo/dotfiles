"""PipelineEnv — entorno Gymnasium del pipeline de composición (§5).

Acción: Tuple(Discrete(N_TOOL_SLOTS), Box(0,1,MAX_PARAMS)).
El discrete se enmascara vía action_masks() (§5.2).
"""
from __future__ import annotations
import json
import logging
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

import gymnasium as gym
import numpy as np

from ..engine.effects import EFFECTS
from ..engine.manifest_loader import Manifest
from ..engine.params import build_command, resolve_agent_param
from ..engine.predicates import eval_predicate
from ..engine.renderers import RENDERERS
from .action_mask import compute_mask, any_valid
from .reward import compute_terminal_reward

log = logging.getLogger("rl_pipeline.env")

TOOL_TIMEOUT_S = 180


class PipelineEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(
        self,
        manifest: Manifest,
        cfg: dict,
        eval_provider,
        plan_path: str,
        curves_path: str | None,
        sections_bars: list[int],
        work_root: str,
        output_root: str | None = None,
        episode_id_prefix: str = "ep",
        save_outputs: bool = True,
    ):
        super().__init__()
        self.manifest = manifest
        self.schema = manifest.schema
        self.cfg = cfg
        self.eval_provider = eval_provider
        self.plan_path = plan_path
        self.curves_path = curves_path
        self.sections_bars = sections_bars
        self.work_root = Path(work_root)
        self.output_root = Path(output_root) if output_root else None
        self.episode_id_prefix = episode_id_prefix
        self.save_outputs = save_outputs

        self.horizon = int(cfg.get("horizon", 6))
        self.n_tool_slots = int(cfg.get("n_tool_slots", max(16, len(manifest.tools) + 4)))
        self.max_params = int(cfg.get("max_params_per_tool", 6))
        self.w_arc = float(cfg.get("reward", {}).get("w_arc", 0.4))
        self.w_eval = float(cfg.get("reward", {}).get("w_eval", 0.6))
        self.root_dir = cfg.get("root_dir", ".")

        # espacios
        self.action_space = gym.spaces.Tuple((
            gym.spaces.Discrete(self.n_tool_slots),
            gym.spaces.Box(low=0.0, high=1.0, shape=(self.max_params,), dtype=np.float32),
        ))
        self.obs_dim = self._compute_obs_dim()
        self.observation_space = gym.spaces.Box(
            low=-np.inf, high=np.inf, shape=(self.obs_dim,), dtype=np.float32)

        self.tools_by_id = manifest.tools  # indexado por tool_id
        self._episode_counter = 0

    # ------------------ observation ------------------
    def _compute_obs_dim(self) -> int:
        n_flags = len(self.schema.flags)
        n_scalars = len(self.schema.scalars)
        n_cat = sum(len(v["vocab"]) for v in self.schema.categoricals.values())
        return n_flags + n_scalars + n_cat + 5 + 2  # +5 qs_dims +2 step

    def _build_obs(self) -> np.ndarray:
        s = self.state
        parts: list[float] = []
        # flags
        for f in self.schema.flags:
            parts.append(1.0 if s["flags"].get(f) else 0.0)
        # scalars normalizadas
        for k, v in self.schema.scalars.items():
            lo, hi = float(v["min"]), float(v["max"])
            val = float(s["scalars"].get(k, 0.0))
            if hi > lo:
                parts.append((val - lo) / (hi - lo))
            else:
                parts.append(0.0)
        # categoricals one-hot
        for k, v in self.schema.categoricals.items():
            vocab = v["vocab"]
            cur = s["categoricals"].get(k, v.get("default"))
            one = [0.0] * len(vocab)
            try:
                one[vocab.index(cur)] = 1.0
            except ValueError:
                pass
            parts.extend(one)
        # qs_dims (5)
        qs = self.ctx.get("qs_dims", {"formal": 0, "coherence": 0, "arc": 0, "melodic": 0, "corpus": 0})
        for d in ("formal", "coherence", "arc", "melodic", "corpus"):
            parts.append(float(qs.get(d, 0.0)))
        # step info
        parts.append(self.steps_taken / max(1, self.horizon))
        parts.append(max(0.0, (self.horizon - self.steps_taken)) / max(1, self.horizon))
        return np.asarray(parts, dtype=np.float32)

    # ------------------ wiring ------------------
    def _wire(self, pspec, tool, step) -> Any:
        name = pspec.name
        if name == "from_narrator":
            return self.plan_path
        if name in ("melody_midi", "input_midi"):
            return self.current_midi
        if name == "output_midi":
            return str(self.work_dir / f"{tool.name}_step{step}.mid")
        if name == "out_dir":
            return str(self.work_dir)
        if name == "out_json":
            return str(self.work_dir / f"{tool.name}_step{step}.json")
        if name == "plan":
            return self.plan_path
        if name == "fast":
            return True
        if name == "export_combined":
            return True
        if name == "seed":
            return int(1 + (self._episode_counter * 31 + step) % 99991)
        return pspec.default

    def _produced_expected_output(self, tool, resolved) -> bool:
        spec = tool.output_resolve or {}
        mode = spec.get("mode", "wired_output")
        if mode == "keep_current":
            # eval tool: éxito si escribió su out_json
            return bool(resolved.get("out_json") and Path(resolved["out_json"]).exists())
        if mode == "wired_output":
            p = resolved.get("output_midi")
            return bool(p and Path(p).exists())
        if mode == "glob":
            return self._resolve_output(tool, resolved) not in (None, self.current_midi)
        return False

    # ------------------ output resolution ------------------
    def _resolve_output(self, tool, resolved) -> str | None:
        spec = tool.output_resolve or {}
        mode = spec.get("mode", "wired_output")
        if mode == "keep_current":
            return self.current_midi
        if mode == "wired_output":
            p = resolved.get("output_midi")
            return p if p and Path(p).exists() else self.current_midi
        if mode == "glob":
            template = spec["template"]
            output_midi = resolved.get("output_midi")
            input_midi = resolved.get("input_midi") or self.current_midi
            output_base = Path(output_midi).with_suffix("").as_posix() if output_midi else None
            input_base = (Path(input_midi).with_suffix("").name) if input_midi else None
            pat = template.format(output_base=output_base or "*", input_base=input_base or "*",
                                  work_dir=str(self.work_dir))
            # patron de basename
            import glob as _g
            base_pat = Path(pat).name
            matches = sorted(self.work_dir.glob(base_pat), key=lambda p: p.stat().st_mtime, reverse=True)
            if matches:
                return str(matches[0])
            return self.current_midi
        return self.current_midi

    # ------------------ gym API ------------------
    def _compute_mask_padded(self) -> list[bool]:
        raw = compute_mask(self.manifest, self.state, self.schema)
        pad = [False] * (self.n_tool_slots - len(raw))
        return list(raw) + pad

    def action_masks(self) -> np.ndarray:
        return np.asarray(self.action_mask, dtype=bool)

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)
        self._episode_counter += 1
        self.episode_id = f"{self.episode_id_prefix}{self._episode_counter:04d}"
        self.work_dir = self.work_root / self.episode_id
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.steps_taken = 0
        self.current_midi = None
        self.ctx = {
            "plan_path": self.plan_path,
            "curves_path": self.curves_path,
            "sections_bars": self.sections_bars,
            "tonalidad": "C",
            "qs_dims": {"formal": 0, "coherence": 0, "arc": 0, "melodic": 0, "corpus": 0},
            "last_qs_score": 0.0,
            "root": self.root_dir,
        }
        self.state = self.schema.default_state()
        self._seed_state_from_plan()
        self.action_mask = self._compute_mask_padded()
        self.episode_log = {"id": self.episode_id, "steps": [], "failed": False, "reason": None}
        return self._build_obs(), {"episode_id": self.episode_id}

    def _seed_state_from_plan(self):
        try:
            plan = json.loads(Path(self.plan_path).read_text())
            self.state["flags"]["tiene_plan"] = True
            self.state["flags"]["tiene_forma"] = True
            self.state["flags"]["tiene_curva_tension"] = self.curves_path is not None
            self.state["scalars"]["num_compases"] = float(plan.get("n_bars", 16))
            self.state["scalars"]["num_secciones"] = float(len(plan.get("sections", [])))
            key = plan.get("base_key", "C")
            self.state["categoricals"]["tonalidad_actual"] = key
            self.ctx["tonalidad"] = key
            self.state["scalars"]["tension_actual"] = 0.3
        except Exception as e:
            log.warning("no pudo leer plan para seed de estado: %s", e)

    def step(self, action):
        tool_id = int(action[0])
        param_vec = np.asarray(action[1], dtype=np.float32).flatten()

        if tool_id >= len(self.tools_by_id) or not self.action_mask[tool_id]:
            # acción fuera de máscara: rechazo explícito (§Fase 3 test)
            raise AssertionError(
                f"acción inválida pese a máscara — bug. tool_id={tool_id} "
                f"mask={self.action_mask}")

        tool = self.tools_by_id[tool_id]
        step_idx = self.steps_taken
        resolved: dict[str, Any] = {}
        agent_idx = 0
        for pspec in tool.params:
            if pspec.source == "wired":
                resolved[pspec.name] = self._wire(pspec, tool, step_idx)
                continue
            if pspec.requires_local and not eval_predicate(
                    pspec.requires_local, self.state, resolved, self.schema):
                continue  # parámetro omitido
            if pspec.source == "derived":
                resolved[pspec.name] = pspec.default
                continue
            # source == agent
            raw = float(param_vec[agent_idx]) if agent_idx < len(param_vec) else 0.5
            agent_idx += 1
            resolved[pspec.name] = resolve_agent_param(pspec, raw, self.state)

        cmd = build_command(tool, resolved, {**self.ctx, "tonalidad": self.state["categoricals"].get("tonalidad_actual", "C")})
        t0 = time.time()
        self.episode_log["steps"].append({
            "tool": tool.name, "cmd": cmd, "params": {k: v for k, v in resolved.items()},
        })
        try:
            result = subprocess.run(cmd, capture_output=True, text=True,
                                    timeout=TOOL_TIMEOUT_S, cwd=str(self.root_dir))
            failed = result.returncode != 0
        except subprocess.TimeoutExpired:
            failed = True
            result = None
        except FileNotFoundError:
            failed = True
            result = None

        if failed:
            # tolerancia: si el output esperado se produjo igualmente, tratar
            # como éxito (algunas tools exitan !=0 con warnings pero output válido)
            if self._produced_expected_output(tool, resolved):
                log.info("[%s] exit !=0 pero output presente — tolerado", tool.name)
                failed = False
        if failed:
            return self._terminal_failure(tool, cmd, result)

        # aplicar efectos (con shaping leve de progresión: §1 lo permite como opcional)
        flags_before = dict(self.state["flags"])
        effects = EFFECTS[tool.produces](resolved, self.ctx)
        self._apply_effects(effects)
        new_flags = sum(1 for f, v in self.state["flags"].items()
                        if v and not flags_before.get(f, False))
        shaping = float(self.cfg.get("reward", {}).get("shaping_progress", 0.0))
        step_reward = shaping * new_flags
        # resolver output
        new_midi = self._resolve_output(tool, resolved)
        if new_midi and Path(new_midi).exists():
            self.current_midi = new_midi

        self.steps_taken += 1
        self.state["scalars"]["paso_actual"] = float(self.steps_taken)
        self.state["scalars"]["pasos_restantes"] = float(max(0, self.horizon - self.steps_taken))

        terminal_tool = tool.terminal
        horizon_reached = self.steps_taken >= self.horizon
        self.action_mask = self._compute_mask_padded()
        mask_empty = not any_valid(self.action_mask)

        done = terminal_tool or horizon_reached or mask_empty
        reward = step_reward
        if done:
            reward += self._compute_terminal_reward()
            self._finalize_episode(reward)

        info = {"tool_called": tool.name, "params": resolved,
                "duration_s": time.time() - t0, "episode_id": self.episode_id}
        return self._build_obs(), reward, done, False, info

    def _apply_effects(self, effects: dict):
        for f, v in effects.get("flags", {}).items():
            self.state["flags"][f] = v
        for k, v in effects.get("scalars", {}).items():
            self.state["scalars"][k] = v
        for k, v in effects.get("categoricals", {}).items():
            self.state["categoricals"][k] = v
        for k, v in effects.get("ctx", {}).items():
            self.ctx[k] = v

    def _terminal_failure(self, tool, cmd, result):
        stderr = result.stderr[-800:] if result is not None else "(no result)"
        log.warning("TOOL FAIL [%s]: %s\nstderr: %s", tool.name, " ".join(cmd), stderr)
        self.episode_log["failed"] = True
        self.episode_log["reason"] = f"tool_fail:{tool.name}"
        self.episode_log["stderr"] = stderr
        self._finalize_episode(-1.0)
        return self._build_obs(), -1.0, True, False, {"tool_called": tool.name, "failed": True}

    def _compute_terminal_reward(self) -> float:
        if not self.current_midi or not Path(self.current_midi).exists():
            return 0.0
        ctx = dict(self.ctx)
        # si el agente ya corrió quality_scorer, reutilizamos su score
        if self.state["flags"].get("fue_evaluado") and "last_qs_score" in self.ctx:
            from .reward import arc_supervisor_score
            arc = arc_supervisor_score(self.current_midi, ctx, root=self.root_dir)
            ev = float(self.ctx.get("last_qs_score", 0.0))
            return self.w_arc * arc + self.w_eval * ev
        return compute_terminal_reward(
            self.current_midi, ctx, self.eval_provider,
            self.w_arc, self.w_eval, root=self.root_dir)

    def _finalize_episode(self, reward: float):
        self.episode_log["reward"] = float(reward)
        self.episode_log["final_midi"] = self.current_midi
        # guardar log
        try:
            (self.work_dir / "episode.json").write_text(
                json.dumps(self.episode_log, ensure_ascii=False, indent=2, default=str))
        except Exception:
            pass
        # copiar salida musical a output_root para evaluación humana
        if self.save_outputs and self.output_root and self.current_midi \
                and Path(self.current_midi).exists():
            try:
                self.output_root.mkdir(parents=True, exist_ok=True)
                dst = self.output_root / f"{self.episode_id}_r{reward:+.3f}.mid"
                shutil.copy2(self.current_midi, dst)
                self.episode_log["saved_midi"] = str(dst)
            except Exception as e:
                log.warning("no se pudo copiar salida: %s", e)

    # util para políticas externas: samplear acción dentro de la máscara
    def sample_masked_action(self, rng: np.random.Generator):
        mask = self.action_mask
        valid = [i for i, ok in enumerate(mask) if ok]
        if not valid:
            valid = [0]
        tool_id = int(rng.choice(valid))
        params = rng.random(self.max_params).astype(np.float32)
        return (tool_id, params)
