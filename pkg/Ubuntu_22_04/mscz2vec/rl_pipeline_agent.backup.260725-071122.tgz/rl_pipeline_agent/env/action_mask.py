"""Cómputo de la máscara de acciones (§5.2, §5.6)."""
from __future__ import annotations
from typing import TYPE_CHECKING

from ..engine.predicates import eval_predicate

if TYPE_CHECKING:
    from ..engine.manifest_loader import Manifest


def compute_mask(manifest: "Manifest", state: dict, schema) -> list[bool]:
    """Devuelve una lista de bools, uno por tool_id, indicando validez."""
    mask = []
    for tool in manifest.tools:
        try:
            ok = eval_predicate(tool.requires, state, None, schema)
        except Exception:
            ok = False
        mask.append(bool(ok))
    return mask


def any_valid(mask: list[bool]) -> bool:
    return any(mask)
