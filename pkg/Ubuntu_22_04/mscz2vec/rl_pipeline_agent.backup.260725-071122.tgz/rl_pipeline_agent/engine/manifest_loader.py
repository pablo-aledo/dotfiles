"""Carga + valida el manifest (tools.json + state_schema.json).

Valida que toda clave referenciada en `requires` / `requires_local` exista en
state_schema, y que cada `produces`/`render`/`range state_fn` apunte a algo
registrado en effects/renderers/param state-fns.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .predicates import eval_predicate  # noqa: F401  (re-exported)


class ManifestError(Exception):
    pass


@dataclass
class StateSchema:
    flags: list[str]
    scalars: dict
    categoricals: dict

    @classmethod
    def load(cls, path: str | Path) -> "StateSchema":
        d = json.loads(Path(path).read_text())
        return cls(flags=list(d["flags"]), scalars=dict(d["scalars"]),
                   categoricals=dict(d["categoricals"]))

    def default_state(self) -> dict:
        return {
            "flags": {f: False for f in self.flags},
            "scalars": {k: v.get("default", 0.0) for k, v in self.scalars.items()},
            "categoricals": {k: v.get("default") for k, v in self.categoricals.items()},
        }


@dataclass
class ParamSpec:
    name: str
    source: str
    type: str
    range: Any = None
    requires_local: dict | None = None
    render: str | None = None
    default: Any = None
    flag: str | None = None
    positional: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "ParamSpec":
        return cls(
            name=d["name"], source=d["source"], type=d.get("type", "str"),
            range=d.get("range"), requires_local=d.get("requires_local"),
            render=d.get("render"), default=d.get("default"),
            flag=d.get("flag"), positional=d.get("positional", False),
        )

    @property
    def is_agent(self) -> bool:
        return self.source == "agent"


@dataclass
class ToolSpec:
    name: str
    cli: str
    terminal: bool
    requires: dict
    params: list[ParamSpec]
    produces: str
    stage_hint: str | None = None
    output_resolve: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "ToolSpec":
        return cls(
            name=d["name"], cli=d["cli"], terminal=d.get("terminal", False),
            requires=d["requires"], params=[ParamSpec.from_dict(p) for p in d["params"]],
            produces=d["produces"], stage_hint=d.get("stage_hint"),
            output_resolve=d.get("output_resolve", {}),
        )

    @property
    def n_agent_params(self) -> int:
        return sum(1 for p in self.params if p.is_agent)


@dataclass
class Manifest:
    schema: StateSchema
    tools: list[ToolSpec]

    @classmethod
    def load(cls, schema_path: str | Path, tools_path: str | Path,
             effects_registry: dict | None = None,
             renderers_registry: dict | None = None) -> "Manifest":
        schema = StateSchema.load(schema_path)
        td = json.loads(Path(tools_path).read_text())
        tools = [ToolSpec.from_dict(t) for t in td["tools"]]
        m = cls(schema=schema, tools=tools)
        m.validate(effects_registry or {}, renderers_registry or {})
        return m

    def validate(self, effects_registry: dict, renderers_registry: dict) -> None:
        for t in self.tools:
            # requires contra schema
            _walk_predicate_keys(t.requires, self.schema)
            for p in t.params:
                if p.requires_local:
                    _walk_predicate_keys(p.requires_local, self.schema)
                if p.source == "agent":
                    if p.type == "categorical":
                        if not isinstance(p.range, list) or not p.range:
                            raise ManifestError(f"{t.name}.{p.name}: categorical necesita range lista")
                    elif p.type in ("int", "float"):
                        if not (isinstance(p.range, list) and len(p.range) == 2):
                            raise ManifestError(f"{t.name}.{p.name}: {p.type} necesita range [min,max]")
                    elif p.type == "curve":
                        if p.render and p.render not in renderers_registry:
                            raise ManifestError(f"{t.name}.{p.name}: renderer '{p.render}' no registrado")
            if t.produces not in effects_registry:
                raise ManifestError(f"{t.name}: produces '{t.produces}' no registrado en effects")
        # sin nombres duplicados
        names = [t.name for t in self.tools]
        if len(set(names)) != len(names):
            raise ManifestError(f"tools duplicados: {names}")


def _walk_predicate_keys(pred: dict, schema: StateSchema, in_param: bool = False) -> None:
    """Recorre un predicate validando estructura. Dentro de un contexto
    `param`, las referencias pueden ser nombres de parámetros locales (no
    declarados en schema), así que no se valida pertenencia."""
    if not isinstance(pred, dict) or len(pred) != 1:
        raise ManifestError(f"predicate malformado: {pred!r}")
    (op, operand), = pred.items()
    if op == "flag":
        if not in_param and operand not in schema.flags:
            raise ManifestError(f"flag '{operand}' no en schema")
    elif op == "not":
        _walk_predicate_keys(operand, schema, in_param)
    elif op in ("and", "or"):
        for p in operand:
            _walk_predicate_keys(p, schema, in_param)
    elif op in ("gte", "lte", "between", "eq", "in"):
        name = operand[0]
        if not in_param:
            if op in ("gte", "lte", "between"):
                if name not in schema.scalars:
                    raise ManifestError(f"scalar '{name}' no en schema")
            else:
                if name not in schema.categoricals:
                    raise ManifestError(f"categorical '{name}' no en schema")
    elif op == "param":
        pname, inner = operand
        _walk_predicate_keys(inner, schema, in_param=True)
    else:
        raise ManifestError(f"operador desconocido en manifest: {op}")
