"""Intérprete del lenguaje de predicados (§3 de la especificación).

Pure, determinista, sin eval(). Valida contra state_schema.json: cualquier
clave no declarada lanza PredicateSchemaError (no KeyError silencioso).
"""
from __future__ import annotations
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .manifest_loader import StateSchema

class PredicateSchemaError(Exception):
    """Referencia a una clave no declarada en state_schema.json."""


_VALID_OPS = {"flag", "not", "and", "or", "gte", "lte", "between", "eq", "in", "param"}


def _check_flag(name: str, schema: "StateSchema") -> None:
    if name not in schema.flags:
        raise PredicateSchemaError(f"flag '{name}' no declarado en state_schema.json")


def _check_scalar(name: str, schema: "StateSchema") -> None:
    if name not in schema.scalars:
        raise PredicateSchemaError(f"scalar '{name}' no declarado en state_schema.json")


def _check_categorical(name: str, schema: "StateSchema") -> None:
    if name not in schema.categoricals:
        raise PredicateSchemaError(f"categorical '{name}' no declarado en state_schema.json")


def eval_predicate(
    predicate: dict,
    global_state: dict,
    local_params: dict[str, Any] | None = None,
    schema: "StateSchema | None" = None,
) -> bool:
    """Evalúa recursivamente un predicate JSON.

    `global_state` es el PipelineState actual (con claves flags/scalars/categoricals).
    `local_params` son los parámetros ya resueltos del step actual (para `{"param":...}`).
    """
    if not isinstance(predicate, dict) or len(predicate) != 1:
        raise PredicateSchemaError(f"predicate debe ser dict de 1 clave, got: {predicate!r}")
    (op, operand), = predicate.items()
    if op not in _VALID_OPS:
        raise PredicateSchemaError(f"operador desconocido: {op!r}")

    if op == "flag":
        _check_flag(operand, schema)
        return bool(global_state["flags"].get(operand, False))

    if op == "not":
        return not eval_predicate(operand, global_state, local_params, schema)

    if op == "and":
        return all(eval_predicate(p, global_state, local_params, schema) for p in operand)

    if op == "or":
        return any(eval_predicate(p, global_state, local_params, schema) for p in operand)

    # operadores binarios: [name, ...]
    if not isinstance(operand, list) or len(operand) < 2:
        raise PredicateSchemaError(f"operando de {op} debe ser lista [name, ...]: {operand!r}")
    name = operand[0]

    if op == "gte":
        _check_scalar(name, schema)
        val = _lookup_value(name, global_state, local_params, schema, expect="scalar")
        return float(val) >= float(operand[1])

    if op == "lte":
        _check_scalar(name, schema)
        val = _lookup_value(name, global_state, local_params, schema, expect="scalar")
        return float(val) <= float(operand[1])

    if op == "between":
        _check_scalar(name, schema)
        val = _lookup_value(name, global_state, local_params, schema, expect="scalar")
        return float(operand[1]) <= float(val) <= float(operand[2])

    if op == "eq":
        _check_categorical(name, schema)
        val = _lookup_value(name, global_state, local_params, schema, expect="categorical")
        return str(val) == str(operand[1])

    if op == "in":
        _check_categorical(name, schema)
        val = _lookup_value(name, global_state, local_params, schema, expect="categorical")
        return str(val) in [str(v) for v in operand[1]]

    if op == "param":
        # {"param": [name, predicate]} — reevalúa predicate con local_params[name]
        # sustituyendo la referencia. Implementación: evalúa el predicado interno
        # contra un "estado" sintético donde la clave referenciada toma el valor
        # del parámetro local `name`.
        pname, inner = operand
        if local_params is None or pname not in local_params:
            return False
        return eval_predicate_paramed(inner, pname, local_params[pname], global_state, local_params, schema)

    raise PredicateSchemaError(f"operador no implementado: {op}")


def _lookup_value(name, global_state, local_params, schema, expect):
    """Lookups: dentro de un predicado plano (no param), las referencias a
    escalares/categóricas se resuelven contra global_state."""
    key = {"scalar": "scalars", "categorical": "categoricals"}[expect]
    return global_state[key].get(name, 0 if expect == "scalar" else None)


def eval_predicate_paramed(predicate, param_name, param_value, global_state, local_params, schema):
    """Evalúa `predicate` sustituyendo cualquier referencia a la clave
    `param_name` por `param_value`. Soporta anidación (varios niveles de param).
    """
    if not isinstance(predicate, dict) or len(predicate) != 1:
        raise PredicateSchemaError(f"predicate debe ser dict de 1 clave, got: {predicate!r}")
    (op, operand), = predicate.items()

    if op == "flag":
        if operand == param_name:
            return bool(param_value)
        _check_flag(operand, schema)
        return bool(global_state["flags"].get(operand, False))

    if op == "not":
        return not eval_predicate_paramed(operand, param_name, param_value, global_state, local_params, schema)

    if op == "and":
        return all(eval_predicate_paramed(p, param_name, param_value, global_state, local_params, schema) for p in operand)
    if op == "or":
        return any(eval_predicate_paramed(p, param_name, param_value, global_state, local_params, schema) for p in operand)

    if op in ("gte", "lte", "between", "eq", "in"):
        name = operand[0]
        if name == param_name:
            val = param_value
        else:
            if op in ("gte", "lte", "between"):
                _check_scalar(name, schema)
                val = global_state["scalars"].get(name, 0)
            else:
                _check_categorical(name, schema)
                val = global_state["categoricals"].get(name)
        if op == "gte":
            return float(val) >= float(operand[1])
        if op == "lte":
            return float(val) <= float(operand[1])
        if op == "between":
            return float(operand[1]) <= float(val) <= float(operand[2])
        if op == "eq":
            return str(val) == str(operand[1])
        if op == "in":
            return str(val) in [str(v) for v in operand[1]]

    if op == "param":
        # anidación: {"param: [name2, pred]} — name2 debe estar en local_params
        pname2, inner = operand
        if local_params is None or pname2 not in local_params:
            return False
        return eval_predicate_paramed(inner, pname2, local_params[pname2], global_state, local_params, schema)

    raise PredicateSchemaError(f"operador no implementado en contexto param: {op}")
