"""Efectos de cada herramienta sobre el estado (§5.1 `produces`).

Cada effects_X(resolved, ctx) -> dict devuelve las actualizaciones a aplicar
sobre flags/scalars/categoricals (y opcionalmente sobre ctx, p.ej. para
guardar el resultado de quality_scorer y alimentar la observación).
"""
from __future__ import annotations
import json
from pathlib import Path

EFFECTS: dict = {}


def register(name: str):
    def deco(fn):
        EFFECTS[name] = fn
        return fn
    return deco


@register("effects_melody_generator")
def effects_melody_generator(resolved: dict, ctx: dict) -> dict:
    return {"flags": {"tiene_melodia": True}}


@register("effects_bass_line_composer")
def effects_bass_line_composer(resolved: dict, ctx: dict) -> dict:
    return {
        "flags": {"tiene_bajo": True},
        "categoricals": {"estilo_activo": resolved.get("style", "walking")},
    }


@register("effects_reharmonizer")
def effects_reharmonizer(resolved: dict, ctx: dict) -> dict:
    return {
        "flags": {"tiene_armonia": True},
        "categoricals": {"estilo_activo": resolved.get("strategy", "diatonic")},
    }


@register("effects_drummer")
def effects_drummer(resolved: dict, ctx: dict) -> dict:
    return {"flags": {"tiene_ritmo": True}}


@register("effects_orchestrator")
def effects_orchestrator(resolved: dict, ctx: dict) -> dict:
    return {
        "flags": {"esta_orquestado": True, "tiene_ritmo": True},
        "categoricals": {"instrumentacion_actual": resolved.get("template", "chamber")},
    }


@register("effects_performer")
def effects_performer(resolved: dict, ctx: dict) -> dict:
    return {"flags": {"esta_renderizado": True, "esta_interpretado": True}}


@register("effects_quality_scorer")
def effects_quality_scorer(resolved: dict, ctx: dict) -> dict:
    out_json = resolved.get("out_json")
    score = 0.0
    dims = {"formal": 0.0, "coherence": 0.0, "arc": 0.0, "melodic": 0.0, "corpus": 0.0}
    try:
        data = json.loads(Path(out_json).read_text())
        s = data.get("score", {})
        score = float(s.get("absolute", 0.0))
        d = data.get("dimensions", {})
        for k in dims:
            if k in d and isinstance(d[k], dict):
                dims[k] = float(d[k].get("score", 0.0))
    except Exception:
        pass
    return {
        "flags": {"fue_evaluado": True},
        "scalars": {"quality_score_actual": score},
        "ctx": {"last_qs_score": score, "qs_dims": dims},
    }
