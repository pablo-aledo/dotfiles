"""Renderers de parámetros complejos (§4).

Una función por parámetro `type=curve` con `render="render_X"`. Recibe el
valor normalizado 0..1 emitido por el agente y un ctx, devuelve el string
que se pasará como valor del flag CLI (un único argv token).
"""
from __future__ import annotations
from typing import Callable

RENDERERS: dict[str, Callable[[float, dict], str]] = {}


def register(name: str):
    def deco(fn):
        RENDERERS[name] = fn
        return fn
    return deco


@register("render_ostinato_pattern")
def render_ostinato_pattern(value: float, ctx: dict) -> str:
    """Traduce un valor 0..1 a un patrón de ostinato válido para
    `bass_line_composer.py --ostinato-pattern 'D3:2 C3:1 Bb2:1'`.

    Determinista: el patrón depende solo de `value` y de la tonalidad (ctx).
    """
    key = ctx.get("tonalidad", "C")
    # tónica en registro grave, mapeo simple a MIDI note names
    note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    # interpretar key como "C", "Am", "F#", etc. → tónica = primer char-name
    root = key.rstrip("m")
    try:
        root_idx = note_names.index(root)
    except ValueError:
        root_idx = 0
    fifth_idx = (root_idx + 7) % 12
    octave_idx = (root_idx + 12) % 12
    root_name = note_names[root_idx]
    fifth_name = note_names[fifth_idx]
    oct_name = note_names[octave_idx]

    # 4 patrones deterministas según cuartil de value
    if value < 0.25:
        pat = f"{root_name}2:4"
    elif value < 0.5:
        pat = f"{root_name}2:2 {fifth_name}2:2"
    elif value < 0.75:
        pat = f"{root_name}2:2 {fifth_name}2:1 {oct_name}3:1"
    else:
        pat = f"{root_name}2:1 {fifth_name}2:1 {oct_name}3:1 {root_name}3:1"
    return pat
