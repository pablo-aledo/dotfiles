"""Resolución de parámetros y construcción de comando CLI (§4, §5.5).

- resolve_range: rango estático [min,max] o "state_fn:<name>".
- derive: parámetros source=derived.
- wire: parámetros source=wired (rutas determinadas por el step anterior).
- build_command: ensambla el argv real.
"""
from __future__ import annotations
import shlex
from typing import Any, Callable

from .manifest_loader import ParamSpec, ToolSpec
from .predicates import eval_predicate
from .renderers import RENDERERS


# ---- state functions para rangos dinámicos ----
STATE_FNS: dict[str, Callable[[dict], tuple[float, float]]] = {}


def register_state_fn(name: str):
    def deco(fn):
        STATE_FNS[name] = fn
        return fn
    return deco


@register_state_fn("tesitura_idiomatica_bajo")
def _tesitura_bajo(state: dict) -> tuple[float, float]:
    """Rango MIDI idiomático para bajo según instrumentación actual."""
    instr = state["categoricals"].get("instrumentacion_actual", "solo")
    if instr == "strings_only":
        return (28.0, 55.0)   # contrabajo/cello grave
    if instr == "full":
        return (24.0, 60.0)
    return (36.0, 60.0)       # chamber/solo: C2-C3


def resolve_range(pspec: ParamSpec, state: dict) -> tuple[float, float]:
    if isinstance(pspec.range, list) and len(pspec.range) == 2:
        return float(pspec.range[0]), float(pspec.range[1])
    if isinstance(pspec.range, str) and pspec.range.startswith("state_fn:"):
        fn_name = pspec.range.split(":", 1)[1]
        if fn_name not in STATE_FNS:
            raise KeyError(f"state_fn no registrada: {fn_name}")
        return STATE_FNS[fn_name](state)
    # categorical / curve sin rango continuo: devolvemos 0..1 (el agente emite
    # un índice sobre la lista; el resolvedor de categóricos lo gestiona)
    return 0.0, 1.0


def resolve_agent_param(pspec: ParamSpec, raw: float, state: dict) -> Any:
    """Convierte el valor normalizado 0..1 del agente al valor semántico."""
    if pspec.type == "categorical":
        opts = pspec.range
        idx = int(round(raw * (len(opts) - 1)))
        idx = max(0, min(len(opts) - 1, idx))
        return opts[idx]
    if pspec.type == "int":
        low, high = resolve_range(pspec, state)
        return int(round(low + raw * (high - low)))
    if pspec.type in ("float", "curve"):
        low, high = resolve_range(pspec, state)
        return low + raw * (high - low)
    return raw


def derive(pspec: ParamSpec, resolved: dict) -> Any:
    """source=derived: por ahora solo normalización de pesos (no usada en v1)."""
    return pspec.default


def build_command(
    tool: ToolSpec,
    resolved: dict[str, Any],
    ctx: dict,
) -> list[str]:
    """Construye el argv real a partir de los parámetros resueltos."""
    cmd = shlex.split(tool.cli)
    # primero posicionales (en orden de declaración), luego flags
    for pspec in tool.params:
        if pspec.name not in resolved:
            continue
        if pspec.positional:
            cmd.append(str(resolved[pspec.name]))
    for pspec in tool.params:
        if pspec.name not in resolved:
            continue
        if pspec.positional:
            continue
        val = resolved[pspec.name]
        if pspec.render:
            rendered = RENDERERS[pspec.render](float(val), ctx)
            cmd.append(pspec.flag)
            cmd.append(rendered)
            continue
        if pspec.type == "bool":
            if val:
                cmd.append(pspec.flag)
            continue
        if pspec.flag:
            cmd.append(pspec.flag)
            cmd.append(str(val))
    return cmd
