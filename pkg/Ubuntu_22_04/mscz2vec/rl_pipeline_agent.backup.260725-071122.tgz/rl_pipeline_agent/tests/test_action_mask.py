from pathlib import Path

import pytest

from rl_pipeline_agent.engine import effects as _effects
from rl_pipeline_agent.engine import renderers as _renderers
from rl_pipeline_agent.engine.manifest_loader import Manifest
from rl_pipeline_agent.env.action_mask import compute_mask, any_valid

PKG = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def manifest():
    return Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "manifest" / "tools.json",
        effects_registry=_effects.EFFECTS,
        renderers_registry=_renderers.RENDERERS,
    )


def state(manifest, **kw):
    s = manifest.schema.default_state()
    s["flags"].update(kw)
    return s


def test_initial_mask_only_plan_dependent(manifest):
    # al inicio (tiene_plan=True) solo melody_generator es válido
    s = state(manifest, tiene_plan=True, tiene_forma=True)
    mask = compute_mask(manifest, s, manifest.schema)
    valid = [t.name for t, ok in zip(manifest.tools, mask) if ok]
    assert "melody_generator" in valid
    assert "bass_line_composer" not in valid   # requiere tiene_melodia
    assert "quality_scorer" not in valid       # requiere esta_renderizado


def test_mask_progresses_after_melody(manifest):
    s = state(manifest, tiene_plan=True, tiene_melodia=True)
    mask = compute_mask(manifest, s, manifest.schema)
    valid = [t.name for t, ok in zip(manifest.tools, mask) if ok]
    assert "bass_line_composer" in valid
    assert "reharmonizer" in valid
    assert "drummer" in valid
    assert "orchestrator" in valid
    assert "melody_generator" not in valid  # ya tiene_melodia


def test_terminal_only_when_rendered(manifest):
    s = state(manifest, esta_renderizado=True)
    mask = compute_mask(manifest, s, manifest.schema)
    valid = [t.name for t, ok in zip(manifest.tools, mask) if ok]
    assert valid == ["quality_scorer"]


def test_any_valid(manifest):
    s = state(manifest)
    assert any_valid(compute_mask(manifest, s, manifest.schema)) is False
    s = state(manifest, tiene_plan=True)
    assert any_valid(compute_mask(manifest, s, manifest.schema)) is True
