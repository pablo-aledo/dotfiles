import json
from pathlib import Path
from unittest import mock

import pytest

from rl_pipeline_agent.engine.eval_providers import (
    QualityScorerProvider, PreferenceTrainerProvider, HumanProvider,
    WeightedProvider, resolve_eval_provider, EvalProviderUnavailableError,
)


def test_quality_scorer_available_when_script_exists(tmp_path):
    (tmp_path / "quality_scorer.py").write_text("# stub")
    p = QualityScorerProvider({}, root=str(tmp_path))
    assert p.is_available({})


def test_quality_scorer_unavailable_when_missing(tmp_path):
    p = QualityScorerProvider({}, root=str(tmp_path))
    assert not p.is_available({})


def test_preference_trainer_unavailable_without_model(tmp_path):
    (tmp_path / "preference_trainer.py").write_text("# stub")
    p = PreferenceTrainerProvider({"preference_trainer_model": "prefs",
                                   "preference_trainer_model_type": "linear"},
                                  root=str(tmp_path))
    assert not p.is_available({})
    # si creamos el fichero de modelo, queda disponible
    (tmp_path / "prefs.linear.json").write_text("{}")
    assert p.is_available({})


def test_resolve_falls_back_to_quality_scorer(tmp_path, caplog):
    (tmp_path / "quality_scorer.py").write_text("# stub")
    cfg = {"eval_mode": "preference_trainer",
           "preference_trainer_model": "prefs",
           "preference_trainer_model_type": "linear",
           "weighted": {"quality_scorer": 0.6, "preference_trainer": 0.4},
           "fallback_order": ["preference_trainer", "quality_scorer"]}
    prov = resolve_eval_provider(cfg, root=str(tmp_path), allow_blocking=False)
    assert isinstance(prov, QualityScorerProvider)


def test_weighted_falls_back_to_only_quality_scorer(tmp_path):
    (tmp_path / "quality_scorer.py").write_text("# stub")
    qs = QualityScorerProvider({}, root=str(tmp_path))
    pt = PreferenceTrainerProvider({"preference_trainer_model": "prefs"},
                                   root=str(tmp_path))
    w = WeightedProvider([(qs, 0.6), (pt, 0.4)])
    assert w.is_available({})
    # pt no disponible → renormaliza a qs con peso 1.0
    with mock.patch.object(qs, "score", return_value=0.7) as mqs:
        s = w.score("x.mid", {})
        assert abs(s - 0.7) < 1e-6
        mqs.assert_called_once()


def test_none_available_raises(tmp_path):
    cfg = {"eval_mode": "preference_trainer",
           "preference_trainer_model": "prefs",
           "preference_trainer_model_type": "linear",
           "weighted": {},
           "fallback_order": ["preference_trainer"]}
    with pytest.raises(EvalProviderUnavailableError):
        resolve_eval_provider(cfg, root=str(tmp_path), allow_blocking=False)


def test_human_blocking_requires_flag(tmp_path):
    (tmp_path / "quality_scorer.py").write_text("# stub")
    cfg = {"eval_mode": "human",
           "weighted": {},
           "fallback_order": ["quality_scorer"]}
    # sin --allow-blocking-eval → falla rápido (no se cuelga esperando input)
    with pytest.raises(EvalProviderUnavailableError):
        resolve_eval_provider(cfg, root=str(tmp_path), allow_blocking=False)
    # con allow_blocking y human disponible → devuelve HumanProvider
    prov2 = resolve_eval_provider(cfg, root=str(tmp_path), allow_blocking=True)
    assert isinstance(prov2, HumanProvider)
