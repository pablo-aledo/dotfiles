"""Smoke test del entorno con subprocess fake (no tools reales).

Valida §Fase 3: reset + N steps con acciones dentro de la máscara no crashea,
done=True en horizonte, reward float finito; acción fuera de máscara lanza
AssertionError explícito.
"""
import json
import subprocess
from pathlib import Path
from unittest import mock

import numpy as np
import pytest

from rl_pipeline_agent.engine import effects as _effects
from rl_pipeline_agent.engine import renderers as _renderers
from rl_pipeline_agent.engine.manifest_loader import Manifest
from rl_pipeline_agent.env.pipeline_env import PipelineEnv

PKG = Path(__file__).resolve().parent.parent


class FakeResult:
    def __init__(self, rc=0, out="", err=""):
        self.returncode = rc
        self.stdout = out
        self.stderr = err


def fake_run(cmd, capture_output=True, text=True, timeout=None, cwd=None):
    """Crea los ficheros de salida esperados según los flags del cmd."""
    args = list(cmd)
    out_midi = None
    out_json = None
    out_dir = None
    input_midi = None
    export_combined = False
    tool_name = None
    for i, a in enumerate(args):
        if a == "--output" and i + 1 < len(args):
            out_midi = args[i + 1]
        elif a == "--out-json" and i + 1 < len(args):
            out_json = args[i + 1]
        elif a == "--out-dir" and i + 1 < len(args):
            out_dir = args[i + 1]
        elif a == "--export-combined":
            export_combined = True
        elif a.endswith(".py"):
            tool_name = Path(a).stem
    # input midi posicional: último arg .mid sin flag previo
    for a in reversed(args):
        if isinstance(a, str) and a.endswith(".mid") and a != out_midi:
            input_midi = a
            break
    # crear outputs
    if out_midi:
        Path(out_midi).write_bytes(b"MThd")
    if export_combined and out_midi:
        base = Path(out_midi).with_suffix("")
        Path(str(base) + ".combined.mid").write_bytes(b"MThd")
    if out_dir and input_midi:
        base = Path(input_midi).with_suffix("").name
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        (Path(out_dir) / f"{base}.rehar_diatonic_01.mid").write_bytes(b"MThd")
    if out_json:
        data = {"score": {"absolute": 0.55},
                "dimensions": {"formal": {"score": 0.5}, "coherence": {"score": 0.6},
                               "arc": {"score": 0.4}, "melodic": {"score": 0.7},
                               "corpus": {"score": 0.5}}}
        Path(out_json).write_text(json.dumps(data))
    return FakeResult(0, "ok", "")


@pytest.fixture
def env(tmp_path):
    manifest = Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "manifest" / "tools.json",
        effects_registry=_effects.EFFECTS,
        renderers_registry=_renderers.RENDERERS,
    )
    plan = tmp_path / "plan.json"
    plan.write_text(json.dumps({"n_bars": 16, "base_key": "C", "sections": [
        {"bars": 8}, {"bars": 8}]}))
    curves = tmp_path / "plan.curves.json"
    curves.write_text("{}")
    cfg = {"horizon": 6, "n_tool_slots": 16, "max_params_per_tool": 6,
           "reward": {"w_arc": 0.4, "w_eval": 0.6}, "root_dir": str(tmp_path)}
    ep = mock.Mock()
    ep.score = lambda midi, ctx: 0.5
    ep.is_available = lambda ctx: True
    env = PipelineEnv(manifest=manifest, cfg=cfg, eval_provider=ep,
                      plan_path=str(plan), curves_path=str(curves),
                      sections_bars=[8, 8], work_root=str(tmp_path / "work"),
                      output_root=str(tmp_path / "out"), save_outputs=False)
    return env


def test_reset_returns_obs_and_mask(env):
    with mock.patch("rl_pipeline_agent.env.pipeline_env.subprocess.run", fake_run):
        obs, info = env.reset()
        assert obs.shape == (env.observation_space.shape[0],)
        mask = env.action_masks()
        assert mask.dtype == bool
        assert mask.sum() >= 1
        assert "melody_generator" in [t.name for t, m in zip(env.tools_by_id, mask) if m]


def test_full_episode_masked_random(env):
    with mock.patch("rl_pipeline_agent.env.pipeline_env.subprocess.run", fake_run):
        rng = np.random.default_rng(0)
        env.reset()
        done = False
        rewards = []
        steps = 0
        while not done:
            action = env.sample_masked_action(rng)
            obs, r, done, _, info = env.step(action)
            rewards.append(r)
            steps += 1
            assert np.isfinite(r)
            if steps > 20:
                break
        assert done
        assert np.isfinite(rewards[-1])


def test_invalid_action_raises_assertion(env):
    with mock.patch("rl_pipeline_agent.env.pipeline_env.subprocess.run", fake_run):
        env.reset()
        # forzar tool_id inválido (más allá del manifest) → fuera de máscara
        with pytest.raises(AssertionError):
            env.step((len(env.tools_by_id) + 5, np.zeros(env.max_params, dtype=np.float32)))


def test_terminal_tool_ends_episode(env):
    with mock.patch("rl_pipeline_agent.env.pipeline_env.subprocess.run", fake_run):
        rng = np.random.default_rng(1)
        env.reset()
        # correr hasta que esta_renderizado forzando la cadena
        done = False
        for _ in range(env.horizon):
            action = env.sample_masked_action(rng)
            _, r, done, _, _ = env.step(action)
            if done:
                break
        assert done
