from pathlib import Path

import pytest

from rl_pipeline_agent.engine import effects as _effects
from rl_pipeline_agent.engine import renderers as _renderers
from rl_pipeline_agent.engine.manifest_loader import Manifest
from rl_pipeline_agent.engine.params import (
    build_command, resolve_agent_param, resolve_range, STATE_FNS)
from rl_pipeline_agent.engine.renderers import RENDERERS

PKG = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def manifest():
    return Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "manifest" / "tools.json",
        effects_registry=_effects.EFFECTS,
        renderers_registry=_renderers.RENDERERS,
    )


def find_tool(manifest, name):
    return next(t for t in manifest.tools if t.name == name)


def test_categorical_resolution(manifest):
    ps = next(p for p in find_tool(manifest, "bass_line_composer").params if p.name == "style")
    val = resolve_agent_param(ps, 0.0, manifest.schema.default_state())
    assert val == "walking"
    val = resolve_agent_param(ps, 1.0, manifest.schema.default_state())
    assert val == "ostinato"


def test_float_resolution(manifest):
    ps = next(p for p in find_tool(manifest, "reharmonizer").params if p.name == "complexity")
    assert resolve_agent_param(ps, 0.0, manifest.schema.default_state()) == 0.0
    assert resolve_agent_param(ps, 1.0, manifest.schema.default_state()) == 1.0


def test_state_fn_range_dynamic(manifest):
    ps = next(p for p in find_tool(manifest, "bass_line_composer").params if p.name == "approach_prob")
    # approach_prob es rango fijo [0,1]
    lo, hi = resolve_range(ps, manifest.schema.default_state())
    assert (lo, hi) == (0.0, 1.0)
    # state_fn registrado
    assert "tesitura_idiomatica_bajo" in STATE_FNS
    lo, hi = STATE_FNS["tesitura_idiomatica_bajo"](manifest.schema.default_state())
    assert lo < hi and 24 <= lo <= 60


def test_bass_command_ostinato_includes_pattern(manifest):
    tool = find_tool(manifest, "bass_line_composer")
    resolved = {
        "from_narrator": "/tmp/plan.json", "melody_midi": "/tmp/m.mid",
        "output_midi": "/tmp/bass.mid", "export_combined": True, "seed": 1,
        "style": "ostinato", "ostinato_pattern": 0.8,
        "approach_prob": 0.5, "swing": 0.0,
    }
    cmd = build_command(tool, resolved, {"tonalidad": "C"})
    assert "--ostinato-pattern" in cmd
    idx = cmd.index("--ostinato-pattern")
    # el valor renderizado debe ser un patrón con notas
    pat = cmd[idx + 1]
    assert ":" in pat and " " in pat
    assert "--style" in cmd and cmd[cmd.index("--style") + 1] == "ostinato"
    assert "--export-combined" in cmd


def test_bass_command_walking_omits_pattern(manifest):
    tool = find_tool(manifest, "bass_line_composer")
    resolved = {
        "from_narrator": "/tmp/plan.json", "melody_midi": "/tmp/m.mid",
        "output_midi": "/tmp/bass.mid", "export_combined": True, "seed": 1,
        "style": "walking", "approach_prob": 0.5, "swing": 0.0,
    }
    cmd = build_command(tool, resolved, {"tonalidad": "C"})
    assert "--ostinato-pattern" not in cmd
    assert "--style" in cmd and cmd[cmd.index("--style") + 1] == "walking"


def test_reharmonizer_positional_input(manifest):
    tool = find_tool(manifest, "reharmonizer")
    resolved = {
        "input_midi": "/tmp/m.mid", "out_dir": "/tmp/work",
        "complexity": 0.7, "strategy": "diatonic", "acc_style": "arpeggio",
    }
    cmd = build_command(tool, resolved, {})
    # input_midi es positional → debe aparecer como arg suelto (no tras flag)
    assert "/tmp/m.mid" in cmd
    assert "--out-dir" in cmd and "/tmp/work" in cmd
    # el input va en la posición del primer arg tras 'reharmonizer.py'
    base_end = cmd.index("reharmonizer.py") + 1
    assert cmd[base_end] == "/tmp/m.mid"
