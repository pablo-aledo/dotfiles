import json
from pathlib import Path

import pytest

from rl_pipeline_agent.engine import effects as _effects
from rl_pipeline_agent.engine import renderers as _renderers
from rl_pipeline_agent.engine.manifest_loader import Manifest, ManifestError


PKG = Path(__file__).resolve().parent.parent


def test_load_full_manifest():
    m = Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "manifest" / "tools.json",
        effects_registry=_effects.EFFECTS,
        renderers_registry=_renderers.RENDERERS,
    )
    assert len(m.tools) >= 7
    names = [t.name for t in m.tools]
    assert "melody_generator" in names and "quality_scorer" in names
    # cada tool tiene produces registrado
    for t in m.tools:
        assert t.produces in _effects.EFFECTS


def test_load_tiny_manifest():
    m = Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "tests" / "fixtures" / "tiny_manifest.json",
        effects_registry={
            "effects_a": lambda r, c: {"flags": {}},
            "effects_b": lambda r, c: {"flags": {}},
        },
        renderers_registry={},
    )
    assert len(m.tools) == 2


def test_invalid_manifest_unknown_produces():
    bad = {"tools": [{
        "name": "x", "cli": "python x.py", "terminal": False,
        "requires": {"flag": "tiene_plan"},
        "params": [{"name": "p", "source": "agent", "type": "float", "range": [0, 1]}],
        "produces": "no_registrado",
    }]}
    import tempfile
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        f.write(json.dumps(bad)); p = f.name
    with pytest.raises(ManifestError):
        Manifest.load(PKG / "manifest" / "state_schema.json", p,
                      effects_registry={}, renderers_registry={})


def test_invalid_manifest_unknown_flag_in_requires():
    bad = {"tools": [{
        "name": "x", "cli": "python x.py", "terminal": False,
        "requires": {"flag": "flag_inexistente"},
        "params": [], "produces": "effects_a",
    }]}
    import tempfile
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        f.write(json.dumps(bad)); p = f.name
    with pytest.raises(ManifestError):
        Manifest.load(PKG / "manifest" / "state_schema.json", p,
                      effects_registry={"effects_a": lambda r, c: {}}, renderers_registry={})
