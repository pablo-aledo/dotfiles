import json
from pathlib import Path

import pytest

from rl_pipeline_agent.engine.manifest_loader import StateSchema
from rl_pipeline_agent.engine.predicates import eval_predicate, PredicateSchemaError

SCHEMA = StateSchema(
    flags=["tiene_plan", "tiene_melodia", "tiene_armonia", "tiene_bajo",
           "tiene_ritmo", "esta_orquestado", "esta_renderizado", "fue_evaluado"],
    scalars={"num_compases": {"min": 0, "max": 128, "default": 0},
             "tension_actual": {"min": 0, "max": 1, "default": 0},
             "pasos_restantes": {"min": 0, "max": 16, "default": 0}},
    categoricals={"tonalidad_actual": {"default": "C", "vocab": ["C", "Dm"]},
                  "estilo_activo": {"default": "auto", "vocab": ["auto", "walking", "ostinato"]}},
)


def st(flags=None, scalars=None, cats=None):
    s = SCHEMA.default_state()
    if flags:
        s["flags"].update(flags)
    if scalars:
        s["scalars"].update(scalars)
    if cats:
        s["categoricals"].update(cats)
    return s


def test_flag():
    assert eval_predicate({"flag": "tiene_melodia"}, st(), None, SCHEMA) is False
    assert eval_predicate({"flag": "tiene_melodia"}, st(flags={"tiene_melodia": True}), None, SCHEMA) is True


def test_not():
    assert eval_predicate({"not": {"flag": "tiene_melodia"}}, st(), None, SCHEMA) is True


def test_and_or():
    p = {"and": [{"flag": "tiene_melodia"}, {"not": {"flag": "tiene_bajo"}}]}
    assert eval_predicate(p, st(flags={"tiene_melodia": True}), None, SCHEMA) is True
    assert eval_predicate(p, st(flags={"tiene_melodia": True, "tiene_bajo": True}), None, SCHEMA) is False
    p2 = {"or": [{"flag": "tiene_bajo"}, {"flag": "tiene_melodia"}]}
    assert eval_predicate(p2, st(), None, SCHEMA) is False
    assert eval_predicate(p2, st(flags={"tiene_melodia": True}), None, SCHEMA) is True


def test_gte_lte_between():
    assert eval_predicate({"gte": ["tension_actual", 0.5]}, st(scalars={"tension_actual": 0.7}), None, SCHEMA) is True
    assert eval_predicate({"gte": ["tension_actual", 0.5]}, st(scalars={"tension_actual": 0.3}), None, SCHEMA) is False
    assert eval_predicate({"lte": ["tension_actual", 0.5]}, st(scalars={"tension_actual": 0.3}), None, SCHEMA) is True
    assert eval_predicate({"between": ["tension_actual", 0.2, 0.8]}, st(scalars={"tension_actual": 0.5}), None, SCHEMA) is True
    assert eval_predicate({"between": ["tension_actual", 0.2, 0.8]}, st(scalars={"tension_actual": 0.9}), None, SCHEMA) is False


def test_eq_in():
    assert eval_predicate({"eq": ["estilo_activo", "ostinato"]}, st(cats={"estilo_activo": "ostinato"}), None, SCHEMA) is True
    assert eval_predicate({"eq": ["estilo_activo", "ostinato"]}, st(cats={"estilo_activo": "walking"}), None, SCHEMA) is False
    assert eval_predicate({"in": ["estilo_activo", ["walking", "ostinato"]]}, st(cats={"estilo_activo": "walking"}), None, SCHEMA) is True
    assert eval_predicate({"in": ["estilo_activo", ["walking", "ostinato"]]}, st(cats={"estilo_activo": "auto"}), None, SCHEMA) is False


def test_param_local():
    # requires_local: ostinato_pattern solo si style==ostinato
    p = {"param": ["style", {"eq": ["style", "ostinato"]}]}
    assert eval_predicate(p, st(), {"style": "ostinato"}, SCHEMA) is True
    assert eval_predicate(p, st(), {"style": "walking"}, SCHEMA) is False
    assert eval_predicate(p, st(), None, SCHEMA) is False  # sin local_params


def test_param_nested_two_levels():
    # {"param: [a, {"param: [b, {"eq": [b, "x"]}]}]}
    p = {"param": ["a", {"param": ["b", {"eq": ["b", "x"]}]}]}
    assert eval_predicate(p, st(), {"a": "irrelevant", "b": "x"}, SCHEMA) is True
    assert eval_predicate(p, st(), {"a": "irrelevant", "b": "y"}, SCHEMA) is False


def test_schema_error_on_unknown_flag():
    with pytest.raises(PredicateSchemaError):
        eval_predicate({"flag": "no_existe"}, st(), None, SCHEMA)


def test_schema_error_on_unknown_scalar():
    with pytest.raises(PredicateSchemaError):
        eval_predicate({"gte": ["inventado", 0.5]}, st(), None, SCHEMA)


def test_schema_error_on_unknown_categorical():
    with pytest.raises(PredicateSchemaError):
        eval_predicate({"eq": ["inventado", "x"]}, st(), None, SCHEMA)
