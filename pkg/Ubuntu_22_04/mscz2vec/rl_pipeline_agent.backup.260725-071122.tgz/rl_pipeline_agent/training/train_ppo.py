"""train_ppo.py — entrenamiento PPO con action masking sobre PipelineEnv.

Implementación propia (no sb3-contrib) porque el espacio de acción es
Tuple(Discrete, Box) y MaskablePPO no soporta Tuple. La máscara se aplica
sobre los logits del head discreto (§1: "MaskablePPO o implementación
equivalente de action masking").

Uso:
    python -m rl_pipeline_agent.training.train_ppo [--config CONFIG]
            [--allow-blocking-eval] [--episodes N] [--baseline-only]
"""
from __future__ import annotations
import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml

# --- registrar effects/renderers/state_fns por importación ---
from ..engine import effects as _effects        # noqa: F401
from ..engine import renderers as _renderers    # noqa: F401
from ..engine import params as _params          # noqa: F401
from ..engine.manifest_loader import Manifest
from ..engine.eval_providers import (
    resolve_eval_provider, EvalProviderUnavailableError)
from ..env.pipeline_env import PipelineEnv

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s %(message)s")
log = logging.getLogger("rl_pipeline.train")

HERE = Path(__file__).resolve().parent
PKG = HERE.parent


# ------------------ red de política ------------------
class PolicyNet(nn.Module):
    def __init__(self, obs_dim, n_tools, max_params, hidden=128):
        super().__init__()
        self.n_tools = n_tools
        self.max_params = max_params
        self.trunk = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
        )
        self.tool_head = nn.Linear(hidden, n_tools)
        self.param_mean = nn.Linear(hidden, max_params)
        self.value_head = nn.Linear(hidden, 1)
        self.log_std = nn.Parameter(torch.zeros(max_params))

    def tool_logits(self, obs, mask):
        h = self.trunk(obs)
        logits = self.tool_head(h)
        neg = torch.finfo(logits.dtype).min
        logits = logits.masked_fill(~mask, neg)
        return logits, h


# ------------------ plan seed ------------------
def build_plan_if_needed(cfg, root):
    import subprocess
    plan_cfg = cfg.get("plan", {})
    work = Path(cfg["training"]["work_root"])
    if not work.is_absolute():
        work = root / work
    work.mkdir(parents=True, exist_ok=True)
    plan_path = work / "plan.json"
    curves_path = work / "plan.curves.json"
    if plan_path.exists() and curves_path.exists():
        log.info("plan reusado: %s", plan_path)
    else:
        out_base = work / "plan"
        cmd = ["python", str(root / "narrator.py"),
               "--arc", plan_cfg.get("arc", "hero"),
               "--bars", str(plan_cfg.get("bars", 16)),
               "--key", plan_cfg.get("key", "C"),
               "--tempo", str(plan_cfg.get("tempo", 120)),
               "--sections", plan_cfg.get("sections", "A:8,B:8"),
               "--output", str(out_base), "--export-curves", "--export-yaml", "--no-gui"]
        log.info("generando plan: %s", " ".join(cmd))
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120, cwd=str(root))
        if r.returncode != 0:
            log.error("narrator falló:\n%s", r.stderr[-800:])
            raise RuntimeError("narrator falló")
        if not plan_path.exists():
            cands = list(work.glob("plan*.json"))
            if cands:
                plan_path = cands[0]
        if not curves_path.exists():
            cs = list(work.glob("plan*.curves.json")) or list(work.glob("*.curves.json"))
            if cs:
                curves_path = cs[0]
    try:
        pd = json.loads(Path(plan_path).read_text())
        secs = [int(s["bars"]) for s in pd.get("sections", [])]
        if not secs:
            secs = [int(pd.get("n_bars", 16)) // 2] * 2
    except Exception:
        secs = [8, 8]
    return str(plan_path), str(curves_path), secs


def make_env(cfg, root, eval_provider, plan_path, curves_path, sections, output_root, prefix):
    manifest = Manifest.load(
        PKG / "manifest" / "state_schema.json",
        PKG / "manifest" / "tools.json",
        effects_registry=_effects.EFFECTS,
        renderers_registry=_renderers.RENDERERS,
    )
    work_root = Path(cfg["training"]["work_root"])
    if not work_root.is_absolute():
        work_root = root / work_root
    return PipelineEnv(
        manifest=manifest, cfg=cfg, eval_provider=eval_provider,
        plan_path=plan_path, curves_path=curves_path, sections_bars=sections,
        work_root=str(work_root), output_root=output_root,
        episode_id_prefix=prefix, save_outputs=True,
    )


# ------------------ rollout ------------------
def run_episode(env, policy=None, device="cpu", greedy=False, rng=None):
    """Captura por step: obs, máscara válida para esa acción, n_agent, logp, value."""
    obs, _ = env.reset()
    traj = []
    done = False
    while not done:
        mask_now = np.asarray(env.action_masks(), dtype=bool)
        obs_t = torch.as_tensor(obs, dtype=torch.float32, device=device)[None, :]
        mask_t = torch.as_tensor(mask_now, dtype=torch.bool, device=device)[None, :]
        if policy is not None:
            with torch.no_grad():
                logits, h = policy.tool_logits(obs_t, mask_t)
                dist = torch.distributions.Categorical(logits=logits)
                tool_id = int(dist.probs.argmax(-1)) if greedy else int(dist.sample())
                logp_tool = float(dist.log_prob(torch.tensor(tool_id, device=device)))
                mean = policy.param_mean(h).squeeze(0)
                std = policy.log_std.exp()
                z = mean + std * torch.randn_like(mean)
                x = torch.sigmoid(z).clamp(1e-5, 1 - 1e-5)
                value = float(policy.value_head(h).squeeze().item())
                action_params = x.detach().cpu().numpy().astype(np.float32)
        else:
            if rng is None:
                rng = np.random.default_rng()
            tool_id, action_params = env.sample_masked_action(rng)
            logp_tool = 0.0
            value = 0.0
        n_agent = env.tools_by_id[tool_id].n_agent_params
        action = (tool_id, action_params)
        obs, reward, done, _, info = env.step(action)
        traj.append({
            "obs": obs, "mask": mask_now, "tool_id": tool_id,
            "params": action_params, "logp": logp_tool, "value": value,
            "reward": float(reward), "done": done, "n_agent": n_agent,
        })
    final_reward = traj[-1]["reward"] if traj else 0.0
    return traj, final_reward, env.episode_log


def compute_returns(traj, gamma):
    T = len(traj)
    returns = np.zeros(T, dtype=np.float32)
    g = 0.0
    for t in reversed(range(T)):
        r = traj[t]["reward"]
        not_done = 0.0 if traj[t]["done"] else 1.0
        g = r + gamma * g * not_done
        returns[t] = g
    advs = returns - np.asarray([tr["value"] for tr in traj], dtype=np.float32)
    return returns, advs


def ppo_update(policy, opt, batch, device, clip, epochs, ent_coef, vf_coef):
    obs = torch.as_tensor(np.stack([b["obs"] for b in batch]), dtype=torch.float32, device=device)
    masks = torch.as_tensor(np.stack([b["mask"] for b in batch]), dtype=torch.bool, device=device)
    tool_ids = torch.as_tensor([b["tool_id"] for b in batch], dtype=torch.long, device=device)
    params = torch.as_tensor(np.stack([b["params"] for b in batch]), dtype=torch.float32, device=device)
    n_agents = torch.as_tensor([b["n_agent"] for b in batch], dtype=torch.long, device=device)
    old_logp = torch.as_tensor([b["logp"] for b in batch], dtype=torch.float32, device=device)
    returns = torch.as_tensor([b["return"] for b in batch], dtype=torch.float32, device=device)
    advs = torch.as_tensor([b["adv"] for b in batch], dtype=torch.float32, device=device)
    if advs.numel() > 1:
        advs = (advs - advs.mean()) / (advs.std() + 1e-8)

    logits, h = policy.tool_logits(obs, masks)
    dist = torch.distributions.Categorical(logits=logits)
    logp_tool = dist.log_prob(tool_ids)
    mean = policy.param_mean(h)
    std = policy.log_std.exp()
    z = torch.logit(params.clamp(1e-5, 1 - 1e-5))
    nmax = int(n_agents.max().item())
    if nmax > 0:
        m_sel = mean[:, :nmax]
        s_sel = std[:nmax]
        z_sel = z[:, :nmax]
        lp = torch.distributions.Normal(m_sel, s_sel).log_prob(z_sel)
        col_mask = (torch.arange(nmax, device=device)[None, :] < n_agents[:, None]).float()
        logp_param = (lp * col_mask).sum(-1)
    else:
        logp_param = torch.zeros(obs.shape[0], device=device)
    logp = logp_tool + logp_param
    values = policy.value_head(h).squeeze(-1)

    ratio = torch.exp(logp - old_logp)
    surr1 = ratio * advs
    surr2 = torch.clamp(ratio, 1 - clip, 1 + clip) * advs
    pg_loss = -torch.min(surr1, surr2).mean()
    v_loss = F.mse_loss(values, returns)
    ent = dist.entropy().mean()
    loss = pg_loss + vf_coef * v_loss - ent_coef * ent
    opt.zero_grad()
    loss.backward()
    nn.utils.clip_grad_norm_(policy.parameters(), 0.5)
    opt.step()
    return {"pg": pg_loss.item(), "v": v_loss.item(), "ent": ent.item(),
            "loss": loss.item()}


def _write_summary(out_root, cfg, base_rewards, ppo_rewards, plan_path,
                   train_rewards=None, delta=None):
    summ = {
        "baseline_mean": float(np.mean(base_rewards)) if base_rewards else None,
        "baseline_rewards": [float(r) for r in base_rewards],
        "ppo_mean": float(np.mean(ppo_rewards)) if ppo_rewards is not None else None,
        "ppo_rewards": [float(r) for r in ppo_rewards] if ppo_rewards is not None else None,
        "train_rewards": [float(r) for r in train_rewards] if train_rewards else None,
        "delta": delta,
        "plan_path": plan_path,
    }
    (out_root / "summary.json").write_text(json.dumps(summ, indent=2))
    log.info("summary escrito en %s/summary.json", out_root)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(HERE / "config.yaml"))
    ap.add_argument("--allow-blocking-eval", action="store_true")
    ap.add_argument("--episodes", type=int, default=None)
    ap.add_argument("--baseline-only", action="store_true")
    ap.add_argument("--no-train", action="store_true")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config))
    root = Path(cfg.get("root_dir", ".."))
    if not root.is_absolute():
        root = (HERE / root).resolve()
    cfg["root_dir"] = str(root)
    out_root = root / cfg["training"]["output_root"]
    out_root.mkdir(parents=True, exist_ok=True)

    plan_path, curves_path, sections = build_plan_if_needed(cfg, root)
    log.info("plan: %s | curves: %s | sections: %s", plan_path, curves_path, sections)

    # resolver eval provider (mergeando cfg de reward + cfg raíz)
    reward_cfg = dict(cfg.get("reward", {}))
    for k in ("preference_trainer_model", "preference_trainer_model_type",
              "quality_scorer_corpus", "quality_scorer_cache"):
        if k in cfg:
            reward_cfg[k] = cfg[k]
    try:
        eval_provider = resolve_eval_provider(reward_cfg, root=str(root),
                                              allow_blocking=args.allow_blocking_eval)
    except EvalProviderUnavailableError as e:
        log.error("eval provider: %s", e)
        sys.exit(2)
    log.info("eval provider: %s", type(eval_provider).__name__)

    env = make_env(cfg, root, eval_provider, plan_path, curves_path, sections,
                   out_root, prefix="rand_")
    seed = int(cfg["training"].get("seed", 42))
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    device = "cpu"

    # ------------------ baseline aleatorio ------------------
    n_base = int(cfg["training"].get("eval_episodes", 6))
    log.info("=== Baseline aleatorio-dentro-de-máscara (%d episodios) ===", n_base)
    base_rewards = []
    for i in range(n_base):
        _, R, elog = run_episode(env, policy=None, device=device, rng=rng)
        base_rewards.append(R)
        log.info("  [%d] reward=%.3f failed=%s midi=%s", i, R, elog.get("failed"),
                 elog.get("saved_midi", elog.get("final_midi")))
    log.info("baseline mean reward: %.4f (std %.4f)",
             float(np.mean(base_rewards)), float(np.std(base_rewards)))

    if args.baseline_only or args.no_train:
        _write_summary(out_root, cfg, base_rewards, None, plan_path)
        return 0

    # ------------------ entrenamiento PPO ------------------
    obs_dim = env.observation_space.shape[0]
    policy = PolicyNet(obs_dim, env.n_tool_slots, env.max_params)
    opt = torch.optim.Adam(policy.parameters(), lr=float(cfg["training"].get("lr", 8e-4)))
    total_eps = args.episodes or int(cfg["training"].get("total_episodes", 32))
    rollout_eps = int(cfg["training"].get("rollout_episodes", 8))
    clip = float(cfg["training"].get("clip", 0.2))
    epochs = int(cfg["training"].get("epochs", 6))
    ent_coef = float(cfg["training"].get("ent_coef", 0.01))
    vf_coef = float(cfg["training"].get("vf_coef", 0.5))

    env.episode_id_prefix = "tr_"
    update = 0
    done_eps = 0
    train_rewards_all = []
    while done_eps < total_eps:
        batch_eps = min(rollout_eps, total_eps - done_eps)
        batch = []
        ep_rewards = []
        for _ in range(batch_eps):
            traj, R, _ = run_episode(env, policy, device=device, rng=rng)
            returns, advs = compute_returns(traj, 0.99)
            for t, tr in enumerate(traj):
                batch.append({
                    "obs": tr["obs"], "mask": tr["mask"], "tool_id": tr["tool_id"],
                    "params": tr["params"], "logp": tr["logp"], "value": tr["value"],
                    "return": returns[t], "adv": advs[t], "n_agent": tr["n_agent"],
                })
            ep_rewards.append(R)
            train_rewards_all.append(R)
        for _ in range(epochs):
            stats = ppo_update(policy, opt, batch, device, clip, 1, ent_coef, vf_coef)
        update += 1
        done_eps += batch_eps
        log.info("update %d | eps=%d | meanR=%.4f | pg=%.4f v=%.4f ent=%.4f",
                 update, done_eps, float(np.mean(ep_rewards)),
                 stats["pg"], stats["v"], stats["ent"])

    torch.save(policy.state_dict(), out_root / "ppo_policy.pt")

    # ------------------ eval policy entrenada ------------------
    env.episode_id_prefix = "ppo_"
    n_eval = int(cfg["training"].get("eval_episodes", 6))
    log.info("=== Eval política entrenada (%d episodios, greedy=False) ===", n_eval)
    ppo_rewards = []
    for i in range(n_eval):
        _, R, elog = run_episode(env, policy=policy, device=device, greedy=False, rng=rng)
        ppo_rewards.append(R)
        log.info("  [%d] reward=%.3f midi=%s", i, R,
                 elog.get("saved_midi", elog.get("final_midi")))
    log.info("ppo mean reward:      %.4f (std %.4f)",
             float(np.mean(ppo_rewards)), float(np.std(ppo_rewards)))
    log.info("baseline mean reward: %.4f", float(np.mean(base_rewards)))
    delta = float(np.mean(ppo_rewards) - np.mean(base_rewards))
    log.info("delta (ppo - baseline): %+.4f  →  %s", delta,
             "MEJORA" if delta > 0 else "sin mejora")

    _write_summary(out_root, cfg, base_rewards, ppo_rewards, plan_path,
                   train_rewards=train_rewards_all, delta=delta)
    return 0


if __name__ == "__main__":
    sys.exit(main())
