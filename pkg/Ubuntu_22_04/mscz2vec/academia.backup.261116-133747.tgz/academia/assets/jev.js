/* ═══════════════════════════════════════════════════════════════════
   Academia Mutopia — Jev en el navegador
   Port de la lógica de jev_composer.py (v4.0) y jev_realtime.py (v0.1):
     · candidatos (acordes diatónicos + V7, notas legales) y sus descripciones
     · documento de estado y preguntas que se envían a Jev (jev_composer)
     · formato de la cache JSONL y su clave sha256
     · rasgos hasheados (crc32) y modelo de dos torres con Adagrad (jev_realtime)
     · estimador de reglas, muestreo con temperatura, capa rítmica
     · motor por compases con sliders cuantizados
   Lo que NO está aquí: la llamada a la API de Jev (jev_composer) ni el modelo
   entrenado con MIDIs (jev_realtime). Donde hace falta una distribución se
   usa el «estimador de reglas» de jev_realtime, que el propio script ofrece
   para probar el motor sin modelo.
   Se comprueba contra el Python real con build/check_jev.py.
   ═══════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
const J = {};
const EPS = 1e-6;
const mod = (a, n) => ((a % n) + n) % n;
const clamp = (x, lo = 0, hi = 1) => x < lo ? lo : x > hi ? hi : x;

/* ─────────────────────────── TEORÍA ─────────────────────────── */
const PN = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const MODE_IV = {
  major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], dorian: [0, 2, 3, 5, 7, 9, 10],
  phrygian: [0, 1, 3, 5, 7, 8, 10], lydian: [0, 2, 4, 6, 7, 9, 11], mixolydian: [0, 2, 4, 5, 7, 9, 10],
  harmonic_minor: [0, 2, 3, 5, 7, 8, 11], phrygian_dominant: [0, 1, 4, 5, 7, 8, 10]};
const MODES = Object.keys(MODE_IV);
const MODE_INFO = {
  major: 'Major (Ionian): bright, stable, optimistic, resolved',
  minor: 'Natural minor (Aeolian): sad, serious, introspective',
  dorian: 'Dorian: minor with a raised 6th; melancholic yet hopeful, groovy, folk and jazz flavour',
  phrygian: 'Phrygian: minor with a flat 2nd; dark, tense, Spanish or exotic',
  lydian: 'Lydian: major with a raised 4th; dreamy, floating, wonder',
  mixolydian: 'Mixolydian: major with a flat 7th; relaxed, bluesy, rock and folk flavour',
  harmonic_minor: 'Harmonic minor: minor with a raised 7th; dramatic, classical, Eastern-flavoured',
  phrygian_dominant: 'Phrygian dominant: major third over a flat 2nd; flamenco, Middle-Eastern, intense'};
const BRIGHT = {phrygian: 0, phrygian_dominant: .1, harmonic_minor: .15, minor: .25, dorian: .45, mixolydian: .65, major: .85, lydian: 1};
const LADDER = ['phrygian', 'minor', 'dorian', 'mixolydian', 'major', 'lydian'];
const TRIAD_Q = {'0,4,7': '', '0,3,7': 'm', '0,3,6': 'dim', '0,4,8': 'aug'};
const SEVENTH_Q = {'0,4,7,11': 'M7', '0,4,7,10': '7', '0,3,7,10': 'm7', '0,3,6,10': 'hdim7', '0,3,6,9': 'dim7'};
const SEVENTH_SUFFIX = {M7: 'M7', '7': '7', m7: '7', hdim7: 'ø7', dim7: '°7'};
const TPL = {'': [0, 4, 7], m: [0, 3, 7], dim: [0, 3, 6], aug: [0, 4, 8], '7': [0, 4, 7, 10], M7: [0, 4, 7, 11], m7: [0, 3, 7, 10],
  hdim7: [0, 3, 6, 10], dim7: [0, 3, 6, 9], sus4: [0, 5, 7], sus2: [0, 2, 7], '5': [0, 7]};
const SEVENTH_QS = new Set(['7', 'M7', 'm7', 'hdim7', 'dim7']);
const ODD_Q = new Set(['dim', 'aug', 'hdim7', 'dim7', 'sus2', 'sus4']);
const MINOR_Q = new Set(['m', 'dim', 'm7', 'hdim7', 'dim7']);
const ROMAN_CHROM = ['I', 'bII', 'II', 'bIII', 'III', 'IV', '#IV', 'V', 'bVI', 'VI', 'bVII', 'VII'];
const FN_OF_REL = {0: 'tonic', 1: 'other', 2: 'supertonic', 3: 'mediant', 4: 'mediant', 5: 'subdominant', 6: 'other', 7: 'dominant', 8: 'submediant', 9: 'submediant', 10: 'subtonic', 11: 'leading'};
const FN_TENSION = {tonic: 0, mediant: .2, submediant: .2, subdominant: .4, supertonic: .55, other: .7, subtonic: .8, dominant: 1, leading: 1};
const FN_CLASS = {tonic: 'T', mediant: 'T', submediant: 'T', subdominant: 'S', supertonic: 'P', dominant: 'D', leading: 'D', subtonic: 'D', other: 'P'};
const CHORD_ROLE_RT = {0: 'root', 2: '9th', 3: 'minor 3rd', 4: 'major 3rd', 5: '4th', 6: 'diminished 5th', 7: '5th', 8: 'augmented 5th', 9: '6th', 10: 'minor 7th', 11: 'major 7th'};
const CHORD_ROLE_CMP = {0: 'root', 2: '9th', 3: 'minor 3rd', 4: 'major 3rd', 6: 'diminished 5th', 7: '5th', 8: 'augmented 5th', 9: '6th', 10: 'minor 7th', 11: 'major 7th'};
const QUAL_VALENCE = {'': 1, M7: .9, '7': .6, sus4: .5, sus2: .5, '5': .5, aug: .4, m: .1, m7: .2, hdim7: .05, dim: 0, dim7: 0};
const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
const DEGREE_FUNCTION = ['tonic', 'supertonic (pre-dominant)', 'mediant (tonic substitute)', 'subdominant', 'dominant', 'submediant (tonic substitute)', 'leading/subtonic (dominant substitute)'];
const SLIDERS = ['valencia', 'energia', 'densidad', 'tension', 'registro', 'complejidad', 'sorpresa', 'groove'];
const SLIDER_DEFAULTS = {valencia: .6, energia: .5, densidad: .5, tension: .25, registro: .5, complejidad: .3, sorpresa: .35, groove: .2};
const DEFAULT_PARAMS = {levels: 5, depth: 4, leap: 9, half_width: 14, reg_lo: 48, reg_hi: 84};
const TRANS = {T: {T: .3, S: 1, P: .7, D: .6}, S: {T: .8, S: .2, P: .4, D: 1.1}, P: {T: .3, S: .1, P: .1, D: 1.5}, D: {T: 1.8, S: .2, P: .1, D: .2}};
Object.assign(J, {PN, MODE_IV, MODES, MODE_INFO, BRIGHT, LADDER, SLIDERS, SLIDER_DEFAULTS, DEFAULT_PARAMS, FN_CLASS, FN_TENSION, QUAL_VALENCE, SEVENTH_QS, TRANS, ROMAN_CHROM});

/* %g de Python: 6 cifras significativas, sin ceros sobrantes */
const fmt = x => String(parseFloat(Number(x).toPrecision(6)));
const midiName = m => PN[mod(m, 12)] + (Math.floor(m / 12) - 1);
const pyRound = x => { const r = Math.round(x); return (Math.abs(x % 1) === 0.5 && r % 2 !== 0) ? r - 1 : r; };
J.fmt = fmt; J.midiName = midiName;

/* ─────────────────────────── ACORDES ─────────────────────────── */
function makeChord(rootPc, q, tonic, ivs) {
  ivs = ivs || TPL[q] || [0, 4, 7];
  const rel = mod(rootPc - tonic, 12);
  let num = ROMAN_CHROM[rel];
  if (MINOR_Q.has(q)) num = num.toLowerCase();
  num += ({dim: '°', aug: '+', hdim7: 'ø7', dim7: '°7', '7': '7', M7: 'M7', m7: '7'})[q] || '';
  return {name: PN[rootPc] + q, root: rootPc, q, pitches: ivs.map(i => (rootPc + i) % 12), fn: FN_OF_REL[rel], numeral: num};
}
const chordDesc = c => `${c.fn}${SEVENTH_QS.has(c.q) ? ', with 7th' : ''}; notes ${c.pitches.map(p => PN[p]).join(' ')}`;

/* jev_realtime.diatonic_chords / chord_options: [{label, desc, chord}] */
J.rtChordOptions = function (tonic, mode) {
  const sc = MODE_IV[mode], out = new Map();
  const add = c => { c.label = `${c.numeral} (${c.name})`; c.desc = chordDesc(c); if (!out.has(c.label)) out.set(c.label, c); };
  for (let i = 0; i < 7; i++) {
    const root = (tonic + sc[i]) % 12;
    const tones = [0, 2, 4, 6].map(k => sc[(i + k) % 7] + 12 * Math.floor((i + k) / 7) - sc[i]);
    const tq = TRIAD_Q[tones.slice(0, 3).map(t => t % 12).join(',')];
    if (tq !== undefined) add(makeChord(root, tq, tonic, tones.slice(0, 3).map(t => t % 12)));
    const sq = SEVENTH_Q[tones.slice(0, 4).map(t => t % 12).join(',')];
    if (sq !== undefined) add(makeChord(root, sq, tonic, tones.slice(0, 4).map(t => t % 12)));
  }
  const v = (tonic + 7) % 12;
  if (![...out.values()].some(c => c.name === PN[v] + '7')) add(makeChord(v, '7', tonic));
  return [...out.values()].map(c => ({label: c.label, desc: c.desc, chord: c}));
};

/* jev_composer.diatonic_chords: {etiqueta: {label, numeral, chord, pitches, desc}} (en orden) */
J.composerChordOptions = function (tonic, mode) {
  const sc = MODE_IV[mode], major = MODE_IV.major, out = new Map();
  const add = (numeral, rootIv, quality, tones, fn) => {
    const rootPc = (tonic + rootIv) % 12, name = PN[rootPc] + quality, label = `${numeral} (${name})`;
    if (out.has(label)) return;
    const pcs = tones.map(iv => (rootPc + iv) % 12);
    out.set(label, {label, numeral, chord: name, pitches: pcs, desc: `${fn}; notes ${pcs.map(p => PN[p]).join(' ')}`});
  };
  for (let i = 0; i < 7; i++) {
    const root = sc[i];
    const tones = [0, 2, 4, 6].map(k => sc[(i + k) % 7] + 12 * Math.floor((i + k) / 7) - root);
    const acc = root < major[i] ? 'b' : root > major[i] ? '#' : '';
    const tq = TRIAD_Q[tones.slice(0, 3).map(t => t % 12).join(',')];
    if (tq !== undefined) {
      let numeral = acc + ((tq === 'm' || tq === 'dim') ? ROMAN[i].toLowerCase() : ROMAN[i]);
      numeral += ({dim: '°', aug: '+'})[tq] || '';
      add(numeral, root, tq, tones.slice(0, 3).map(t => t % 12), DEGREE_FUNCTION[i]);
    }
    const sq = SEVENTH_Q[tones.slice(0, 4).map(t => t % 12).join(',')];
    if (sq !== undefined) {
      let numeral = acc + (['m7', 'hdim7', 'dim7'].includes(sq) ? ROMAN[i].toLowerCase() : ROMAN[i]);
      numeral += SEVENTH_SUFFIX[sq];
      add(numeral, root, sq, tones.slice(0, 4).map(t => t % 12), DEGREE_FUNCTION[i] + ', with 7th');
    }
  }
  if (![...out.values()].some(c => c.chord === PN[(tonic + 7) % 12] + '7'))
    add('V7', 7, '7', [0, 4, 7, 10], 'dominant (borrowed), strong pull towards the tonic');
  return out;
};

/* ─────────────────────────── NOTAS ─────────────────────────── */
/* jev_realtime.note_option */
function noteOption(tonic, mode, chord, prev, m) {
  const scale = MODE_IV[mode], rootPc = chord.pitches[0], pc = mod(m, 12), pv = prev == null ? m : prev;
  let role, rk;
  if (chord.pitches.includes(pc)) { role = `chord tone (${CHORD_ROLE_RT[mod(pc - rootPc, 12)] || 'tone'} of ${chord.name})`; rk = 'ct'; }
  else { const rel = mod(pc - tonic, 12); if (scale.includes(rel)) { role = `passing scale tone (degree ${scale.indexOf(rel) + 1})`; rk = 'pass'; } else { role = 'chromatic tone'; rk = 'chrom'; } }
  if (pc === tonic) role += ', the tonic';
  const d = m - pv, motion = d === 0 ? 'repeats the previous note' : `${d > 0 ? 'up' : 'down'} ${Math.abs(d)} semitone(s)`;
  return {label: midiName(m), desc: `${role}; ${motion}`, midi: m, role: rk, istonic: pc === tonic, tone: mod(pc - rootPc, 12), delta: d};
}
J.noteOption = noteOption;
J.noteOptions = function (P, tonic, mode, chord, prev, center) {
  const hw = Math.trunc(P.half_width), leap = Math.trunc(P.leap), lo = center - hw, hi = center + hw, pv = prev == null ? center : prev;
  const scalePcs = new Set(MODE_IV[mode].map(iv => (tonic + iv) % 12)), allowed = new Set([...scalePcs, ...chord.pitches]);
  let pool = [];
  for (let m = Math.max(lo, pv - leap); m <= Math.min(hi, pv + leap); m++) if (allowed.has(mod(m, 12))) pool.push(m);
  if (!pool.length) { for (let m = lo; m <= hi; m++) if (allowed.has(mod(m, 12))) pool.push(m); if (!pool.length) pool = [pv]; }
  return pool.map(m => noteOption(tonic, mode, chord, pv, m));
};
/* jev_composer.pitch_candidates: notas de escala/acorde entre base-5 y base+19, a ≤ leap de la anterior */
J.composerPitchCandidates = function (chord, tonic, mode, prev, octave, leap) {
  const base = octave * 12 + tonic, lo = base - 5, hi = base + 19, pv = prev == null ? base : prev;
  const scalePcs = new Set(MODE_IV[mode].map(iv => (tonic + iv) % 12)), allowed = new Set([...scalePcs, ...chord.pitches]);
  let pool = [];
  for (let m = Math.max(lo, pv - leap); m <= Math.min(hi, pv + leap); m++) if (allowed.has(mod(m, 12))) pool.push(m);
  if (!pool.length) for (let m = lo; m <= hi; m++) if (allowed.has(mod(m, 12))) pool.push(m);
  const rootPc = chord.pitches[0], scale = MODE_IV[mode], out = [];
  for (const m of pool) {
    const pc = mod(m, 12); let role;
    if (chord.pitches.includes(pc)) role = `chord tone (${CHORD_ROLE_CMP[mod(pc - rootPc, 12)] || 'tone'} of ${chord.chord})`;
    else { const rel = mod(pc - tonic, 12); role = scale.includes(rel) ? `passing scale tone (degree ${scale.indexOf(rel) + 1})` : 'chromatic tone'; }
    if (pc === tonic) role += ', the tonic';
    const d = m - pv, motion = d === 0 ? 'repeats the previous note' : `${d > 0 ? 'up' : 'down'} ${Math.abs(d)} semitone(s)`;
    out.push({name: midiName(m), midi: m, desc: `${role}; ${motion}`});
  }
  return out;
};

/* ─────────────────────────── ESTIMADOR DE REGLAS ─────────────────────────── */
/* PriorEstimator de jev_realtime (NO es el modelo: sirve para probar el motor) */
const softmax = s => { const m = Math.max(...s), e = s.map(x => Math.exp(x - m)), t = e.reduce((a, b) => a + b, 0); return e.map(x => x / t); };
J.softmax = softmax;
J.ruleProbs = function (q) {
  const L = Math.max(1, q.L - 1), v = {}; SLIDERS.forEach(k => v[k] = q.levels[k] / L);
  const t = v.tension - .5, c = v.complejidad - .5, sc = [];
  if (q.kind === 'acorde') {
    const prev = q.window.length ? FN_CLASS[q.window[q.window.length - 1].chord.fn] : 'T';
    for (const o of q.options) {
      const ch = o.chord, cl = FN_CLASS[ch.fn];
      let w = Math.log(TRANS[prev][cl] + .05);
      if (q.window.length && q.window[q.window.length - 1].chord.name === ch.name) w -= 1.5;
      w += 2 * t * (cl === 'D' ? 1 : cl === 'T' ? -.8 : 0);
      w += SEVENTH_QS.has(ch.q) ? 1.5 * c : -.8 * c;
      if (['dim', 'hdim7', 'dim7'].includes(ch.q)) w += 1 * t - .3;
      sc.push(w);
    }
  } else {
    const hw = 14;
    for (const o of q.options) {
      let w = ({ct: 1.1, pass: .2, chrom: -1.5})[o.role] - 1 * t * (o.role === 'ct') + 1 * t * (o.role !== 'ct');
      const d = Math.abs(o.delta);
      w -= d === 0 ? .5 : .28 * Math.max(0, d - 2) + (d <= 2 ? 0 : .2);
      w += .3 * o.istonic - .5 * ((o.midi - q.center) / (.75 * hw)) ** 2;
      sc.push(w);
    }
  }
  return softmax(sc);
};

/* ─────────────────────────── MUESTREO ─────────────────────────── */
J.mulberry = seed => { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };
/* jev_realtime.sample: p^(1/T) con T ≥ 0.05; devuelve el índice */
J.sample = function (probs, T, rng) {
  T = Math.max(T, .05);
  const lg = probs.map(p => Math.log(Math.max(p, 1e-9)) / T), m = Math.max(...lg), w = lg.map(x => Math.exp(x - m));
  let r = rng() * w.reduce((a, b) => a + b, 0), acc = 0;
  for (let i = 0; i < w.length; i++) { acc += w[i]; if (r <= acc) return i; }
  return w.length - 1;
};
/* jev_composer.pick: T ≤ 0 → la más probable. Trabaja sobre {opción: p}; devuelve la opción */
J.pick = function (probs, T, rng) {
  const items = Object.entries(probs).sort((a, b) => b[1] - a[1]);
  if (T <= 0 || items.length === 1) return items[0][0];
  const w = items.map(([, p]) => Math.exp(Math.log(p) / T));
  let r = rng() * w.reduce((a, b) => a + b, 0), acc = 0;
  for (let i = 0; i < items.length; i++) { acc += w[i]; if (r <= acc) return items[i][0]; }
  return items[items.length - 1][0];
};
/* mezcla geométrica probs^(1-s) · prior^s */
J.combine = function (probs, prior, s) {
  const p = probs.map((a, i) => Math.max(a, 1e-12) ** (1 - s) * Math.max(prior[i], 1e-12) ** s), t = p.reduce((a, b) => a + b, 0);
  return t > 1e-30 ? p.map(x => x / t) : p.map(() => 1 / p.length);
};

/* ─────────────────────────── RITMO ─────────────────────────── */
const GRID = [.25, .5, .75, 1, 1.5, 2, 3, 4];
J.GRID = GRID;
J.rhythmWeights = function (t, maxDur, density, groove, prior) {
  const opb = .25 * 16 ** density, target = Math.log2(1 / opb), ws = [];
  GRID.forEach((d, i) => {
    if (d > maxDur + EPS) { ws.push(0); return; }
    let w = Math.exp(-((Math.log2(d) - target) ** 2) / (2 * .55 ** 2));
    const end = (t + d) % 1;
    if (Math.min(end, 1 - end) > .01 && Math.abs(end - .5) > .01) w *= .35;
    if (Math.abs((t + d) % .5) > .01) w *= .3;
    if (d === .75 || d === 1.5 || d === 3) w *= .5 + 1.2 * groove;
    if (prior) w *= Math.max(prior[i], 1e-6);
    ws.push(w);
  });
  return ws;
};
J.restProb = (density, barIdx, t, beats) => .28 * (1 - density) ** 2 + ((barIdx % 4 === 3 && (t % beats) >= beats - 1 - EPS) ? .35 : 0);
J.rhythmSample = function (rng, t, maxDur, density, groove, beats, barIdx, lastRest, prior) {
  const ws = J.rhythmWeights(t, maxDur, density, groove, prior), tot = ws.reduce((a, b) => a + b, 0);
  let d;
  if (tot <= 0) d = Math.min(maxDur, .25);
  else { let r = rng() * tot, acc = 0; d = GRID[0]; for (let i = 0; i < GRID.length; i++) { acc += ws[i]; d = GRID[i]; if (r <= acc) break; } }
  d = Math.min(d, maxDur);
  return [d, !lastRest && rng() < J.restProb(density, barIdx, t, beats)];
};

/* ─────────────────────────── SLIDERS → NIVELES ─────────────────────────── */
/* levels_now: cuantización estocástica a L niveles (redondeo con probabilidad = parte fraccionaria) */
J.levelsNow = function (values, L, rng) {
  const out = {};
  for (const v of SLIDERS) {
    const f = values[v] * L - .5;
    let lv;
    if (f <= 0) lv = 0; else if (f >= L - 1) lv = L - 1; else { const lo = Math.floor(f); lv = rng() < f - lo ? lo + 1 : lo; }
    out[v] = lv;
  }
  return out;
};

/* ─────────────────────────── CONSULTA (jev_realtime.Query) ─────────────────────────── */
J.Query = function (kind, o) { Object.assign(this, {kind, beat: 0, dur: 0, cur: null, center: 60}, o); };
const pitched = win => win.flatMap(e => e.notes.filter(n => n[0] != null));
J.queryCriteria = q => { const o = {}; q.options.forEach(x => o[x.label] = x.desc); return o; };
J.queryInstructions = q => q.kind === 'acorde'
  ? `Which chord should come next? It starts at bar ${q.bar + 1} beat 1 and lasts ${fmt(q.beats)} beats. Choose the single best fit for the description, the slider values and the chord history.`
  : `Which note should the melody play next? It starts at bar ${q.bar + 1} beat ${fmt(Math.round((q.beat + 1) * 1e4) / 1e4)}, lasts ${fmt(q.dur)} beat(s) and sounds over the chord ${q.cur.name}. Choose the single best fit for the description, the slider values and the harmony.`;
J.queryState = function (q) {
  const sc = MODE_IV[q.mode].map(iv => PN[(q.tonic + iv) % 12]).join(' ');
  const lines = q.window.map(e => {
    const ns = e.notes.filter(n => n[0] != null).map(([m, d]) => `${midiName(m)}(${fmt(d)})`).join(' ');
    return `bar ${e.bar + 1} | ${e.chord.name} (${fmt(q.beats)} beats): ${ns || '(no melody yet)'}`;
  });
  const sl = SLIDERS.map(v => `${v} ${q.levels[v]}/${q.L - 1}`).join(', ');
  return `PIECE DESCRIPTION:\n${q.desc.trim()}\n\nKEY: ${PN[q.tonic]} ${q.mode} (scale: ${sc})\nMETER: ${fmt(q.beats)} beats per bar\nSLIDERS FOR THIS BAR: ${sl}\n\nCHORD HISTORY (last ${q.window.length} bar(s), melody as note(beats)):\n${lines.join('\n')}\n`;
};

/* ─────────────────────────── RASGOS HASHEADOS ─────────────────────────── */
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
J.crc32 = s => { const b = new TextEncoder().encode(s); let c = 0xFFFFFFFF; for (const x of b) c = CRC[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
J.hash = (tok, bits = 16) => J.crc32(tok) & ((1 << bits) - 1);
J.words = text => (String(text).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').match(/[a-z0-9]{2,}/g)) || [];
const dedupe = a => [...new Set(a)];
const relChord = (c, tonic) => `${mod(c.root - tonic, 12)}_${c.q}`;

J.queryTokens = function (q) {
  const kind = q.kind, tonic = q.tonic, T = ['k=' + kind];
  const add = (tok, kp = true) => { T.push(tok); if (kp) T.push(kind + '/' + tok); };
  const dw = J.words(q.desc).slice(0, 120);
  dw.forEach(w => add('w:' + w));
  for (let i = 0; i + 1 < dw.length; i++) T.push(`b:${dw[i]}_${dw[i + 1]}`);
  add('mode=' + q.mode); add('tonic=' + PN[tonic]); add('meter=' + fmt(q.beats));
  for (const v of SLIDERS) { const lv = q.levels[v]; add(`${v}=${lv}`); for (let k = 1; k <= lv; k++) add(`${v}>=${k}`); }
  const lv = q.levels;
  add(`valmode=${lv.valencia}|${q.mode}`); add(`tenen=${lv.tension}|${lv.energia}`);
  add('ph4=' + (q.bar % 4)); add('ph8=' + (q.bar % 8));
  const win = q.window;
  win.slice(-4).reverse().forEach((e, i) => add(`c-${i + 1}:${relChord(e.chord, tonic)}`));
  if (win.length >= 2) add(`c-12:${relChord(win[win.length - 2].chord, tonic)}>${relChord(win[win.length - 1].chord, tonic)}`);
  const pn = pitched(win);
  pn.slice(-4).reverse().forEach(([m, d], i) => { add(`n-${i + 1}:${mod(m - tonic, 12)}`); add(`d-${i + 1}:${fmt(d)}`); });
  if (pn.length >= 2) add('i-1:' + Math.max(-12, Math.min(12, pn[pn.length - 1][0] - pn[pn.length - 2][0])));
  if (pn.length) add('reg:' + Math.floor(pn[pn.length - 1][0] / 6));
  if (kind === 'nota') {
    add('beat=' + fmt(q.beat)); add('dur=' + fmt(q.dur)); add('cur:' + relChord(q.cur, tonic)); add('curfn:' + q.cur.fn);
    add('cen:' + Math.floor(Math.trunc(q.center) / 6));
  }
  return dedupe(T);
};
J.optionTokens = function (q, o, prevChord) {
  const kind = q.kind, tonic = q.tonic, O = [`o:${kind}|${o.label}`];
  const add = (tok, kp = true) => { O.push(tok); if (kp) O.push(kind + '/' + tok); };
  J.words(o.desc.split('; notes ')[0]).slice(0, 60).forEach(w => add('ow:' + w));
  if (kind === 'acorde') {
    const c = o.chord, rel = mod(c.root - tonic, 12);
    add('num:' + c.numeral); add('q:' + c.q); add('fn:' + c.fn); add('rel:' + rel); add(`rq:${rel}_${c.q}`);
    if (SEVENTH_QS.has(c.q)) add('seventh');
    if (prevChord) {
      if (prevChord.name === c.name) add('repeat');
      const d = mod(c.root - prevChord.root, 12);
      add('rm:' + d); add(`rmq:${d}_${prevChord.q}>${c.q}`);
    }
  } else {
    const m = o.midi, ch = q.cur;
    add('pitch:' + m); add('reg:' + Math.floor(m / 6)); add('rp:' + mod(m - tonic, 12));
    const d = o.delta;
    add('mv:' + Math.max(-12, Math.min(12, d))); add('mva:' + Math.min(Math.abs(d), 12));
    add('dir:' + (d > 0 ? 'up' : d < 0 ? 'down' : 'same'));
    add('cr:' + mod(m - ch.root, 12)); add(`crq:${mod(m - ch.root, 12)}_${ch.q}`); add('role:' + o.role);
    if (o.istonic) add('istonic');
    add('cen:' + Math.max(-4, Math.min(4, pyRound((m - q.center) / 3))));
  }
  return dedupe(O);
};
J.featurize = function (q, bits = 16) {
  const qt = J.queryTokens(q), prev = (q.kind === 'acorde' && q.window.length) ? q.window[q.window.length - 1].chord : null;
  const ot = q.options.map(o => J.optionTokens(q, o, prev));
  return {qt, ot, qi: qt.map(t => J.hash(t, bits)), oi: ot.map(a => a.map(t => J.hash(t, bits)))};
};

/* ─────────────────────────── MODELO DE DOS TORRES (juguete) ─────────────────────────── */
/* s_i = a_i + <e_Q, e_Oi>; embeddings hasheados con filas creadas al vuelo; Adagrad sobre filas dispersas.
   Misma estructura que jev_realtime.TwoTower (dim 16 en vez de 32 para que quepa en una gráfica). */
J.TwoTower = class {
  constructor(bits = 16, dim = 16, seed = 1) { this.bits = bits; this.dim = dim; this.seed = seed; this.reset(); }
  reset() { this.EQ = new Map(); this.EO = new Map(); this.w = new Map(); this.GQ = new Map(); this.GO = new Map(); this.Gw = new Map(); this.steps = 0; }
  _row(M, tag, i) {
    let r = M.get(i);
    if (!r) {
      const rng = J.mulberry((this.seed * 2654435761 + i * 97 + tag) >>> 0); r = new Float64Array(this.dim);
      for (let j = 0; j < this.dim; j++) { const u = Math.max(rng(), 1e-12), v = rng(); r[j] = .1 * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
      M.set(i, r);
    }
    return r;
  }
  eq(i) { return this._row(this.EQ, 1, i); }
  eo(i) { return this._row(this.EO, 2, i); }
  forward(f) {
    const D = this.dim, cq = 1 / Math.sqrt(f.qi.length), eQ = new Float64Array(D);
    for (const i of f.qi) { const r = this.eq(i); for (let j = 0; j < D; j++) eQ[j] += r[j] * cq; }
    const eO = [], sq = [], s = [];
    for (const oi of f.oi) {
      const sv = Math.sqrt(oi.length), e = new Float64Array(D); let a = 0;
      for (const i of oi) { const r = this.eo(i); for (let j = 0; j < D; j++) e[j] += r[j] / sv; a += (this.w.get(i) || 0) / sv; }
      let dot = 0; for (let j = 0; j < D; j++) dot += e[j] * eQ[j];
      eO.push(e); sq.push(sv); s.push(a + dot);
    }
    return {s, ctx: {eQ, eO, cq, sq}};
  }
  probs(f, tau = 1) { return softmax(this.forward(f).s.map(x => x / tau)); }
  _acc(M, i, vec) { const a = M.get(i); if (a) { for (let j = 0; j < vec.length; j++) a[j] += vec[j]; } else M.set(i, Float64Array.from(vec)); }
  backward(g, f, ctx, acc) {
    const D = this.dim, {eQ, eO, cq, sq} = ctx;
    f.oi.forEach((oi, k) => {
      const gA = g[k] / sq[k], ve = Float64Array.from(eQ, v => gA * v);
      for (const i of oi) { this._acc(acc.EO, i, ve); acc.w.set(i, (acc.w.get(i) || 0) + gA); }
    });
    const gq = new Float64Array(D);
    g.forEach((gk, k) => { for (let j = 0; j < D; j++) gq[j] += gk * eO[k][j]; });
    for (let j = 0; j < D; j++) gq[j] *= cq;
    for (const i of f.qi) this._acc(acc.EQ, i, gq);
  }
  apply(acc, lr, l2) {
    const upd = (M, G, tab, scalar) => {
      for (const [i, tot] of tab) {
        const par = scalar ? (M.get(i) || 0) : this._row(M, M === this.EQ ? 1 : 2, i);
        if (scalar) {
          let t = tot; if (l2) t += l2 * par;
          const gg = (G.get(i) ?? .1) + t * t; G.set(i, gg); M.set(i, par - lr * t / Math.sqrt(gg));
        } else {
          let gr = G.get(i); if (!gr) { gr = new Float64Array(this.dim).fill(.1); G.set(i, gr); }
          for (let j = 0; j < this.dim; j++) { let t = tot[j]; if (l2) t += l2 * par[j]; gr[j] += t * t; par[j] -= lr * t / Math.sqrt(gr[j]); }
        }
      }
    };
    upd(this.EQ, this.GQ, acc.EQ, false); upd(this.EO, this.GO, acc.EO, false); upd(this.w, this.Gw, acc.w, true);
  }
  /* una pasada por el conjunto en lotes (cmd_train): objetivo con label smoothing, g = (p − t)/B */
  epoch(samples, {lr = .3, l2 = 1e-6, batch = 32, ls = .02, rng = Math.random} = {}) {
    const order = samples.map((_, i) => i); for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    let tot = 0;
    for (let b = 0; b < order.length; b += batch) {
      const idx = order.slice(b, b + batch), acc = {EQ: new Map(), EO: new Map(), w: new Map()};
      for (const k of idx) {
        const s = samples[k], {s: sc, ctx} = this.forward(s.f), p = softmax(sc), n = p.length;
        const t = new Array(n).fill(ls / n); t[s.truth] += 1 - ls;
        tot += -t.reduce((a, tv, i) => a + tv * Math.log(Math.max(p[i], 1e-12)), 0);
        this.backward(p.map((x, i) => (x - t[i]) / idx.length), s.f, ctx, acc);
      }
      this.apply(acc, lr, l2);
    }
    this.steps++;
    return tot / samples.length;
  }
  evaluate(samples) {
    let ce = 0, top = 0, uni = 0;
    for (const s of samples) { const p = this.probs(s.f); ce += -Math.log(Math.max(p[s.truth], 1e-12)); top += p.indexOf(Math.max(...p)) === s.truth ? 1 : 0; uni += Math.log(p.length); }
    return {ce: ce / samples.length, top1: top / samples.length, uniform: uni / samples.length};
  }
};
/* estimador que usa el modelo de juguete para acordes y las reglas para notas */
J.toyEstimator = model => ({probs: q => q.kind === 'acorde' ? model.probs(J.featurize(q)) : J.ruleProbs(q), name: 'modelo de juguete (acordes) + reglas (notas)'});
J.ruleEstimator = {probs: J.ruleProbs, name: 'estimador de reglas'};

/* ─────────────────────────── PATRONES DE ACOMPAÑAMIENTO (chord_pattern_voicer) ─────────────────────────── */
const PATTERN_STEPS = {block: ['todas'], 'bombo-caja': ['bajo', 'resto'], alberti: ['bajo', 'agudo', 'medio', 'agudo']};
const ROLE_ALIASES = {bajo: 'bass', root: 'bass', raiz: 'bass', bass: 'bass', agudo: 'top', alto: 'top', top: 'top', medio: 'mid', mid: 'mid', middle: 'mid', resto: 'rest', caja: 'rest', rest: 'rest', todas: 'all', all: 'all', block: 'all'};
J.PATTERNS = ['plantilla', 'block', 'bombo-caja', 'alberti', 'arpeggio-up', 'arpeggio-down', 'arpeggio-updown'];
J.splitCustom = text => { const toks = []; let cur = '', depth = 0; for (const ch of text) { if (ch === '[') depth++; else if (ch === ']') depth = Math.max(0, depth - 1); if (ch === ',' && depth === 0) { toks.push(cur); cur = ''; } else cur += ch; } toks.push(cur); return toks.map(t => t.trim()).filter(Boolean); };
J.resolveRole = function rr(token, notes) {
  token = token.trim();
  if (token.startsWith('[') && token.endsWith(']')) {
    const out = [];
    for (const sub of token.slice(1, -1).split(',')) if (sub.trim()) for (const n of rr(sub, notes)) if (!out.includes(n)) out.push(n);
    return out.length ? out : [notes[0]];
  }
  const n = notes.length, t = ROLE_ALIASES[token.toLowerCase()] || token.toLowerCase();
  if (t === 'bass') return [notes[0]]; if (t === 'top') return [notes[n - 1]];
  if (t === 'mid') return n >= 3 ? [notes[Math.floor(n / 2)]] : [notes[n - 1]];
  if (t === 'rest') return n > 1 ? notes.slice(1) : [notes[0]]; if (t === 'all') return notes.slice();
  if (/^[+-]?\d+$/.test(t)) return [notes[mod(parseInt(t, 10), n)]];
  return [notes[0]];
};
J.patternTokens = function (name, custom, n) {
  const r = (a, b) => Array.from({length: Math.max(0, b - a)}, (_, i) => String(a + i));
  if (name === 'custom') return J.splitCustom(custom || '');
  if (name === 'arpeggio-up') return r(0, n);
  if (name === 'arpeggio-down') return r(0, n).reverse();
  if (name === 'arpeggio-updown') return r(0, n).concat(n > 2 ? r(1, n - 1).reverse() : []);
  return PATTERN_STEPS[name].slice();
};
/* [(inicio, duración, nota, factor de velocity)] para un acorde que dura d desde t */
J.patternEvents = function (notes, name, custom, t, d, reps, gate, accent) {
  const toks = J.patternTokens(name, custom, notes.length);
  if (!toks.length || !notes.length) return [];
  const cyc = d / reps, step = cyc / toks.length, ev = [];
  for (let r = 0; r < reps; r++) toks.forEach((tok, k) => { for (const m of J.resolveRole(tok, notes)) ev.push([t + r * cyc + k * step, Math.max(.05, step * gate), m, k === 0 ? accent : 1]); });
  return ev;
};

/* ─────────────────────────── MINI-CORPUS PARA EL MODELO DE JUGUETE ─────────────────────────── */
/* Cuatro piezas de 16 compases (tres para entrenar, una de validación). Cada compás es una consulta de acorde
   cuya respuesta correcta es el acorde que suena; en jev_realtime esto lo hace cmd_train con MIDIs reales. */
const LV = (v, e, d, t, r, c, so, g) => ({valencia: v, energia: e, densidad: d, tension: t, registro: r, complejidad: c, sorpresa: so, groove: g});
J.TOY_PIECES = [
  {id: 'nana', desc: 'nana melancólica para una noche de lluvia', mode: 'minor', tonic: 9, lv: LV(1, 1, 1, 1, 2, 1, 1, 0), prog: ['i', 'bVI', 'bIII', 'bVII', 'i', 'bVI', 'iv', 'V7'], train: true},
  {id: 'marcha', desc: 'marcha épica de fantasía con metales', mode: 'major', tonic: 2, lv: LV(4, 4, 3, 2, 2, 1, 2, 1), prog: ['I', 'V', 'vi', 'IV', 'I', 'IV', 'V7', 'I'], train: true},
  {id: 'danza', desc: 'danza oscura y tensa de tango', mode: 'harmonic_minor', tonic: 2, lv: LV(0, 3, 3, 3, 1, 3, 2, 2), prog: ['i', 'iv', 'V7', 'i', 'i', 'bVI', 'V7', 'i'], train: true},
  {id: 'cuna', desc: 'nana tranquila de cuna', mode: 'minor', tonic: 4, lv: LV(1, 1, 1, 1, 2, 1, 1, 0), prog: ['i', 'bVI', 'bIII', 'bVII', 'i', 'iv', 'V7', 'i'], train: false}];
J.toySamples = function (pieces, bars = 16) {
  const out = [];
  for (const p of pieces) {
    const opts = J.rtChordOptions(p.tonic, p.mode), win = [];
    for (let b = 0; b < bars; b++) {
      const num = p.prog[b % p.prog.length], truth = opts.findIndex(o => o.chord.numeral === num);
      if (truth < 0) throw new Error('numeral no encontrado: ' + num);
      const lv = Object.assign({}, p.lv); if (num === 'V7') lv.tension = Math.min(4, lv.tension + 1);
      const q = new J.Query('acorde', {desc: p.desc, tonic: p.tonic, mode: p.mode, beats: 4, bar: b, levels: lv, L: 5, window: win.slice(-4).map(e => ({chord: e.chord, bar: e.bar, notes: []})), options: opts});
      out.push({f: J.featurize(q), truth, q, piece: p.id});
      win.push({chord: opts[truth].chord, bar: b});
    }
  }
  return out;
};

/* ─────────────────────────── ANÁLISIS DE UN COMPÁS (bar_raws) ─────────────────────────── */
/* Valores «crudos» de los sliders para un compás; en train se pasan a rango percentil sobre el corpus. */
J.barRaws = function (chord, mode, mel, harm, beats, cov = 1) {
  const ons = harm.map(n => [n.start, n.start + n.dur, n.vel]).concat(mel.map(n => [n.start, n.start + n.dur, n.vel]));
  const nons = ons.length, vel = nons ? ons.reduce((a, o) => a + o[2], 0) / nons : 64, q = chord.q;
  const melTot = mel.reduce((a, n) => a + n.dur, 0);
  const nonch = melTot ? mel.filter(n => !chord.pitches.includes(mod(n.midi, 12))).reduce((a, n) => a + n.dur, 0) / melTot : 0;
  const sev = ODD_Q.has(q) ? 1 : SEVENTH_QS.has(q) ? .5 : 0;
  const allpcs = new Set([...harm.map(n => mod(n.midi, 12)), ...mel.map(n => mod(n.midi, 12))]);
  const mp = mel.map(n => n.midi), steps = mp.slice(1).map((m, i) => Math.abs(mp[i] - m));
  const sixt = ons.filter(o => Math.abs(((o[0] * 2) % 1)) > 1e-3 && Math.abs(o[0] % .5) > 1e-3).length;
  const cross = ons.filter(o => Math.abs(o[0] % 1) > 1e-3 && o[1] > Math.floor(o[0] + EPS) + 1 + EPS).length;
  return {
    valencia: .5 * BRIGHT[mode] + .5 * (QUAL_VALENCE[q] ?? .5),
    energia: .6 * vel / 127 + .4 * Math.min(1, Math.log2(1 + nons / beats) / 3),
    densidad: mel.length / beats,
    tension: .45 * FN_TENSION[chord.fn] + .25 * sev + .30 * nonch,
    complejidad: .35 * SEVENTH_QS.has(q) + .15 * ODD_Q.has(q) + .35 * Math.min(1, allpcs.size / 10) + .15 * (1 - cov),
    groove: .5 * sixt / Math.max(1, nons) + .5 * cross / Math.max(1, nons),
    regmean: mp.length ? mp.reduce((a, b) => a + b, 0) / mp.length : null,
    melstep: steps.length ? steps.reduce((a, b) => a + b, 0) / steps.length : 0,
  };
};

/* ─────────────────────────── MOTOR POR COMPASES (jev_realtime.Engine, sin referencias ni hardware) ─────────────────────────── */
J.Engine = class {
  constructor(o = {}) {
    this.rng = o.rng || Math.random; this.estimator = o.estimator || J.ruleEstimator;
    this.desc = o.desc || 'obra instrumental'; this.tonic = o.tonic ?? 0; this.mode = o.mode || 'major'; this.beats = o.beats || 4;
    this.P = Object.assign({}, DEFAULT_PARAMS, o.params || {});
    this.V = Object.assign({}, SLIDER_DEFAULTS, o.sliders || {});
    this.K = Object.assign({temperatura: .5, amplitud: .5, vol_melodia: .5, vol_acordes: .5, vol_bajo: .5}, o.knobs || {});
    this.temperature = o.temperature ?? 1; this.valenceMode = !!o.valenceMode; this.octave = 0;
    this.onNote = o.onNote || (() => {}); this.onSay = o.onSay || (() => {}); this.onQuery = o.onQuery || (() => {});
    this.layers = {melodia: true, acordes: true, bajo: true}; this.pattern = 'plantilla'; this.gate = .85; this.accent = 1;
    this.mem = {entries: [], lastMidi: null}; this.curBar = -1; this.melT = 0; this.lastRest = false; this.force = []; this.pendingKey = null;
    this.ladderI = Math.round(this.V.valencia * (LADDER.length - 1)); this.vcCenter = 62; this.rec = null; this.recs = [];
    this.chord = null; this.levels = null; this.curCenter = 60;
  }
  sv(n) { return this.V[n]; }
  gain(n) { return Math.min((2 * this.K[n]) ** 1.3, 1.8); }
  temp() { return this.temperature * (.5 + this.K.temperatura); }
  center() { return Math.trunc(clamp(this.P.reg_lo + this.sv('registro') * (this.P.reg_hi - this.P.reg_lo) + 12 * this.octave, 30, 100)); }
  notePars() { return Object.assign({}, this.P, {half_width: Math.max(4, Math.trunc(this.P.half_width * (.5 + this.K.amplitud)))}); }
  window() { return this.mem.entries.slice(-this.P.depth); }
  query(kind, bar, opts, chord, beat, dur) {
    return new J.Query(kind, {desc: this.desc, tonic: this.tonic, mode: this.mode, beats: this.beats, bar, levels: this.levels, L: this.P.levels,
      window: this.window(), options: opts, beat: beat || 0, dur: dur || 0, cur: chord || null, center: this.curCenter});
  }
  ask(q) { return q.options.length === 1 ? [1] : this.estimator.probs(q); }
  emit(start, dur, ch, note, vel, role) {
    if (!this.layers[['melodia', 'acordes', 'bajo'][ch]]) return;
    const g = this.sv('groove'), sw = g * .8 / 6, swung = b => b + (Math.abs(b - Math.floor(b) - .5) < 1e-3 ? sw : 0);
    const s = Math.max(0, swung(start)), e = Math.max(swung(start + dur * (ch === 0 ? 1 - .45 * g : .98)), s + .08);
    const v = clamp(vel, 1, 127);
    if (this.rec) { const r = {start: start - this.barStart, dur, midi: note, vel: v}; (ch === 0 ? this.rec.mel : this.rec.harm).push(r); }
    this.onNote({t: s, d: e - s, ch, m: note, v, role});
  }
  velMel(t) { const e = this.sv('energia'); let v = 42 + 62 * e; const fr = t % this.beats; v += fr < EPS ? 10 : Math.abs(fr - Math.round(fr)) < EPS ? 5 : 0; return clamp(v * this.gain('vol_melodia'), 1, 127); }
  voice(pcs) {
    const out = [...new Set(pcs.map(pc => { let best = null; for (let m = 50; m < 74; m++) if (m % 12 === pc && (best === null || Math.abs(m - this.vcCenter) < Math.abs(best - this.vcCenter))) best = m; return best; }))].sort((a, b) => a - b);
    this.vcCenter = .5 * this.vcCenter + .5 * (out.reduce((a, b) => a + b, 0) / out.length); return out;
  }
  playBass(chord, t, d) {
    const e = this.sv('energia'), vb = clamp((55 + 45 * e) * this.gain('vol_bajo'), 1, 127), root = 36 + mod(chord.root - 36, 12);
    if (e < .35 || d < 2) this.emit(t, d, 2, root, vb);
    else if (e < .7) { this.emit(t, d / 2, 2, root, vb); this.emit(t + d / 2, d / 2, 2, root + 7, vb * .85); }
    else { let x = 0, i = 0; while (x < d - EPS) { this.emit(t + x, Math.min(1, d - x), 2, i % 2 === 0 ? root : root + 12, vb); x += 1; i++; } }
  }
  playChord(chord, t, d) {
    const e = this.sv('energia'), c = this.sv('complejidad'), pcs = chord.pitches.slice();
    if (c > .7 && pcs.length < 5) pcs.push((pcs[0] + 2) % 12);
    const notes = this.voice(pcs), vc = clamp((30 + 50 * e) * this.gain('vol_acordes'), 1, 127);
    if (this.pattern !== 'plantilla') {
      const reps = e < .35 ? 1 : e < .7 ? 2 : 4;
      for (const [st, du, m, f] of J.patternEvents(notes.slice().sort((a, b) => a - b), this.pattern, null, t, d, reps, this.gate, this.accent)) this.emit(st, du, 1, m, vc * f);
      this.playBass(chord, t, d); return;
    }
    if (e < .35) notes.forEach(n => this.emit(t, d, 1, n, vc));
    else {
      const step = e < .6 ? 1 : .5, seq = e < .8 ? notes : notes.concat(notes.slice(1, -1).reverse());
      let x = 0, i = 0; while (x < d - EPS) { this.emit(t + x, Math.min(step, d - x), 1, seq[i % seq.length], x ? vc * .8 : vc); x += step; i++; }
    }
    this.playBass(chord, t, d);
  }
  decideChord(bar) {
    const opts = J.rtChordOptions(this.tonic, this.mode);
    while (this.force.length) {
      const want = this.force.shift();
      for (const o of opts) { const c = o.chord; if ((want === 'V7' && c.numeral === 'V7') || (want === 'tonic' && (c.numeral === 'I' || c.numeral === 'i') && c.pitches.length === 3)) { this.lastChordQuery = null; return c; } }
    }
    const q = this.query('acorde', bar, opts, null, 0, this.beats), p = this.ask(q), i = J.sample(p, this.temp(), this.rng);
    this.lastChordQuery = {q, p, i}; this.onQuery('acorde', q, p, i);
    return opts[i].chord;
  }
  beginBar(bar) {
    if (this.recs.length && this.rec) this.recs[this.recs.length - 1] = this.rec;
    if (this.pendingKey != null) { this.tonic = this.pendingKey; this.pendingKey = null; }
    if (this.valenceMode) { const f = this.sv('valencia') * (LADDER.length - 1); if (Math.abs(f - this.ladderI) > .65) this.ladderI = Math.round(f); this.mode = LADDER[this.ladderI]; }
    const t0 = bar * this.beats; this.curBar = bar; this.barStart = t0;
    this.levels = J.levelsNow(this.V, this.P.levels, this.rng); this.curCenter = this.center();
    const prev = this.chord, chord = this.decideChord(bar);
    this.prevChord = prev; this.chord = chord;
    this.entry = {chord, bar, notes: []}; this.mem.entries.push(this.entry); if (this.mem.entries.length > 64) this.mem.entries.splice(0, this.mem.entries.length - 32);
    this.rec = {bar, chord, mel: [], harm: []}; this.recs.push(this.rec); if (this.recs.length > 8) this.recs.shift();
    this.playChord(chord, t0, this.beats);
    const lq = this.lastChordQuery;
    this.onSay(`<b>Compás ${bar + 1}</b> · venía de «${prev ? prev.name + ' (' + FN_CLASS[prev.fn] + ')' : '—'}» → ` +
      (lq ? `la consulta da ${(lq.p[lq.i] * 100).toFixed(0)} % a <b>${chord.name}</b> (${chord.fn}); tensión nivel ${this.levels.tension}/${this.P.levels - 1}. Sorteado.` : `acorde forzado: <b>${chord.name}</b>.`));
  }
  genNote(t) {
    const chord = this.chord, barEnd = this.barStart + this.beats;
    const [d0, rest] = J.rhythmSample(this.rng, t - this.barStart, barEnd - t, this.sv('densidad'), this.sv('groove'), this.beats, this.curBar, this.lastRest);
    const d = d0 <= 1e-6 ? barEnd - t : d0; this.lastRest = rest;
    if (!rest) {
      this.curCenter = this.center();
      const opts = J.noteOptions(this.notePars(), this.tonic, this.mode, chord, this.mem.lastMidi, this.curCenter);
      const q = this.query('nota', this.curBar, opts, chord, t - this.barStart, d), p = this.ask(q), j = J.sample(p, this.temp(), this.rng), x = opts[j];
      this.lastNoteQuery = {q, p, i: j}; this.onQuery('nota', q, p, j);
      this.entry.notes.push([x.midi, d]); this.mem.lastMidi = x.midi;
      this.emit(t, d, 0, x.midi, this.velMel(t), x.role);
      this.onSay(`nota <b>${midiName(x.midi)}</b> (${({ct: 'del acorde', pass: 'de paso', chrom: 'cromática'})[x.role]}, ${x.delta > 0 ? '+' : ''}${x.delta} st) · P=${(p[j] * 100).toFixed(0)} % entre ${opts.length} candidatas · dura ${fmt(d)} pulsos`);
    } else this.onSay(`silencio de ${fmt(d)} pulsos (prob. de respiro ${(J.restProb(this.sv('densidad'), this.curBar, t - this.barStart, this.beats) * 100).toFixed(0)} %)`);
    this.melT = Math.round((t + d) * 1e6) / 1e6;
  }
  advance(upto) {
    while (this.melT < upto - EPS) {
      const bar = Math.floor(this.melT / this.beats + EPS);
      if (bar !== this.curBar) this.beginBar(bar);
      this.genNote(this.melT);
    }
  }
  cadence() { this.force = ['V7', 'tonic']; }
  transpose(n) { this.pendingKey = mod((this.pendingKey ?? this.tonic) + n, 12); }
};

/* ─────────────────────────── jev_composer: simulador de la ventana deslizante ─────────────────────────── */
const progText = prog => prog.map(c => `${c.chord}:${fmt(c.duration_beats)}`).join(' ');
const melText = notes => notes.map(n => `${n.note}:${fmt(n.duration_beats)}`).join(' ');
J.progressionText = progText; J.melodyText = melText;
J.descriptionState = function (desc, tonic, mode, chordSeed, chordLabel = 'CHORD SEED', tonicHint = null) {
  let s = `PIECE DESCRIPTION:\n${desc.trim()}\n`;
  if (mode != null) s += `\nMODE: ${mode}\n`;
  if (tonic != null) s += `KEY: ${PN[tonic]} ${mode}\n`;
  else if (tonicHint != null) s += `\nTONIC: ${PN[tonicHint]}\n`;
  if (chordSeed && chordSeed.length) { let t = progText(chordSeed.slice(0, 16)); if (chordSeed.length > 16) t += ` ... (${chordSeed.length} chords in total)`; s += `${chordLabel}: ${t}\n`; }
  return s;
};
J.MODE_QUESTION = 'Which musical mode best suits the piece described in this document? Choose the single best fit.';
J.tonicQuestion = mode => `The piece will be in ${mode} mode. Which tonic note (key centre) best suits the piece described in this document? Choose the single best fit.`;
J.tonicCriteria = () => { const o = {}; for (let i = 0; i < 12; i++) o[`${PN[i]}`] = `Tonic note ${PN[i]}`; return o; };

J.ComposerSim = class {
  /* o: {desc, tonic, mode, seeds:{progression:[{chord,numeral,pitches,duration_beats}], notes:[{note,midi,duration_beats}]},
          bars, beats, depth, temperature, leap, octave, rng, barNotes:{bar:[text]}} */
  constructor(o) {
    Object.assign(this, {bars: 8, beats: 4, depth: 4, temperature: 1, leap: 9, octave: 5, rng: Math.random, barNotes: {}}, o);
    this.total = this.bars * this.beats; this.base = this.octave * 12 + this.tonic;
    this.candidates = J.composerChordOptions(this.tonic, this.mode);
    this.chordDurs = this.seeds.progression.map(c => c.duration_beats); if (!this.chordDurs.length) this.chordDurs = [this.beats / 2];
    this.rhythm = this.seeds.notes.map(n => [n.duration_beats, n.midi == null]); if (!this.rhythm.length) this.rhythm = [[1, false]];
    this.rhythmI = this.seeds.notes.length; this.chords = []; this.melody = []; this.melT = 0; this.lastMidi = null; this.queries = [];
  }
  pos(t) { return `bar ${Math.floor(t / this.beats) + 1} beat ${fmt(Math.round((t % this.beats + 1) * 1e4) / 1e4)}`; }
  notesOf(c) { const end = c.start + c.dur; return this.melody.filter(m => c.start - EPS <= m.start && m.start < end - EPS); }
  extra(t0, t1) {
    const b0 = Math.floor(t0 / this.beats) + 1, b1 = Math.floor((Math.max(t1, t0 + EPS) - EPS) / this.beats) + 1, out = [];
    for (let b = b0; b <= b1; b++) if (this.barNotes[b]) out.push(`bar ${b}: ${this.barNotes[b].join('; ')}`);
    return out.join('\n');
  }
  state(extra = '') {
    const scale = MODE_IV[this.mode].map(iv => PN[(this.tonic + iv) % 12]).join(' '), visible = this.chords;
    const lines = visible.slice(-this.depth).map(c => {
      const ns = this.notesOf(c).map(m => `${m.note}(${fmt(m.dur)})`).join(' ');
      return `${this.pos(c.start)} | ${c.chord} (${fmt(c.dur)} beats): ${ns || '(no melody yet)'}`;
    });
    return `PIECE DESCRIPTION:\n${this.desc.trim()}\n\nKEY: ${PN[this.tonic]} ${this.mode} (scale: ${scale})\nMETER: ${this.beats} beats per bar, ${this.bars} bars in total\n` +
      `CHORD SEED: ${progText(this.seeds.progression)}\nMOTIF SEED: ${melText(this.seeds.notes)}\n\n` +
      `MUSIC SO FAR (last ${Math.min(this.depth, visible.length)} chord(s), melody as note(beats)):\n` + lines.join('\n') + '\n' +
      (extra ? `\nEXTRA INFORMATION FOR THIS POSITION:\n${extra}\n` : '');
  }
  placeSeed() {
    let t = 0;
    for (const c of this.seeds.progression) { const d = Math.min(c.duration_beats, this.total - t); if (d <= EPS) break; this.chords.push({chord: c.chord, numeral: c.numeral || '', pitches: c.pitches, start: t, dur: d, source: 'seed'}); t = Math.round((t + d) * 1e6) / 1e6; }
    const seedEnd = t; t = 0;
    for (const n of this.seeds.notes) { const d = Math.min(n.duration_beats, this.total - t); if (d <= EPS) break; this.melody.push({note: n.note, midi: n.midi, start: t, dur: d, source: 'seed'}); if (n.midi != null) this.lastMidi = n.midi; t = Math.round((t + d) * 1e6) / 1e6; }
    this.melT = t; return seedEnd;
  }
  chordAt(t) { for (let i = this.chords.length - 1; i >= 0; i--) if (this.chords[i].start <= t + EPS) return this.chords[i]; return this.chords[0]; }
  /* estimador de reglas como sustituto de Jev: se construye una Query de jev_realtime con sliders en el nivel medio */
  _stand(kind, opts, chordRT, t) {
    const lv = {}; SLIDERS.forEach(s => lv[s] = 2);
    const win = this.chords.slice(-this.depth).map(c => ({chord: this._rt(c), bar: Math.floor(c.start / this.beats), notes: this.notesOf(c).filter(m => m.midi != null).map(m => [m.midi, m.dur])}));
    return new J.Query(kind, {desc: this.desc, tonic: this.tonic, mode: this.mode, beats: this.beats, bar: Math.floor(t / this.beats), levels: lv, L: 5, window: win, options: opts, beat: t % this.beats, dur: 1, cur: chordRT, center: this.base + 7});
  }
  _rt(c) { // acorde de jev_composer (nombre + pitches) → estructura de jev_realtime (root, q, fn…) para el estimador
    const root = c.pitches[0], rel = mod(root - this.tonic, 12), pcs = c.pitches.map(p => mod(p - root, 12)).join(',');
    const q = ({'0,4,7': '', '0,3,7': 'm', '0,3,6': 'dim', '0,4,8': 'aug', '0,4,7,11': 'M7', '0,4,7,10': '7', '0,3,7,10': 'm7', '0,3,6,10': 'hdim7', '0,3,6,9': 'dim7'})[pcs] ?? '';
    return {name: c.chord, root, q, pitches: c.pitches, fn: FN_OF_REL[rel], numeral: c.numeral || ''};
  }
  record(kind, state, instr, criteria, probs, label, t) {
    this.queries.push({kind, state, instructions: instr, criteria, probs, choice: label, t, pos: this.pos(t)});
  }
  nextChord(t) {
    const dur = Math.min(this.chordDurs[this.chords.length % this.chordDurs.length], this.total - t);
    const extra = this.extra(t, t + dur);
    const instr = `Which chord should come next? It starts at ${this.pos(t)} and lasts ${fmt(dur)} beat(s). Choose the single best fit for the description, the seeds and the harmonic flow.` + (extra ? ' Take into account the extra information given for this position.' : '');
    const criteria = {}; this.candidates.forEach((c, k) => criteria[k] = c.desc);
    const labels = [...this.candidates.keys()];
    const opts = labels.map(k => { const c = this.candidates.get(k); return {label: k, desc: c.desc, chord: this._rt({chord: c.chord, pitches: c.pitches, numeral: c.numeral})}; });
    const p = this.standIn ? this.standIn('acorde', labels) : J.ruleProbs(this._stand('acorde', opts, null, t)), probs = {}; labels.forEach((k, i) => probs[k] = p[i]);
    const label = J.pick(probs, this.temperature, this.rng), c = this.candidates.get(label);
    this.record('acorde', this.state(extra), instr, criteria, probs, label, t);
    const chord = {chord: c.chord, numeral: c.numeral, pitches: c.pitches, start: t, dur, source: 'jev'}; this.chords.push(chord); return chord;
  }
  fillMelody(until) {
    until = Math.min(until, this.total);
    while (this.melT < until - EPS) {
      const c = this.chordAt(this.melT), cEnd = c.start + c.dur, [slot, isRest] = this.rhythm[this.rhythmI % this.rhythm.length];
      this.rhythmI++;
      const dur = Math.min(slot, until - this.melT, cEnd - this.melT);
      if (dur <= EPS) break;
      if (isRest) this.melody.push({note: 'R', midi: null, start: this.melT, dur, source: 'jev'});
      else {
        const cands = J.composerPitchCandidates(c, this.tonic, this.mode, this.lastMidi, this.octave, this.leap);
        const extra = this.extra(this.melT, this.melT + dur);
        const instr = `Which note should the melody play next? It starts at ${this.pos(this.melT)}, lasts ${fmt(dur)} beat(s) and sounds over the chord ${c.chord}. Choose the single best fit for the description, the motif seed and the harmony.` + (extra ? ' Take into account the extra information given for this position.' : '');
        const crt = this._rt(c), pv = this.lastMidi == null ? this.base : this.lastMidi;
        const opts = cands.map(x => noteOption(this.tonic, this.mode, crt, pv, x.midi));
        const criteria = {}; cands.forEach(x => criteria[x.name] = x.desc);
        const p = this.standIn ? this.standIn('nota', cands.map(x => x.name)) : J.ruleProbs(this._stand('nota', opts, crt, this.melT)), probs = {}; cands.forEach((x, i) => probs[x.name] = p[i]);
        const name = J.pick(probs, this.temperature, this.rng), midi = cands.find(x => x.name === name).midi;
        this.record('nota', this.state(extra), instr, criteria, probs, name, this.melT);
        this.melody.push({note: name, midi, start: this.melT, dur, source: 'jev'}); this.lastMidi = midi;
      }
      this.melT = Math.round((this.melT + dur) * 1e6) / 1e6;
    }
  }
  compose() {
    const seedEnd = this.placeSeed(); this.fillMelody(seedEnd);
    let t = seedEnd;
    while (t < this.total - EPS) { const c = this.nextChord(t); t = Math.round((c.start + c.dur) * 1e6) / 1e6; this.fillMelody(t); }
    return this;
  }
};

/* ─────────────────────────── cache JSONL de jev_composer ─────────────────────────── */
/* json.dumps(…, sort_keys=True, ensure_ascii=False) de Python (separadores «, » y «: ») */
J.pyJson = function pj(v) {
  if (v === null) return 'null';
  if (Array.isArray(v)) return '[' + v.map(pj).join(', ') + ']';
  if (typeof v === 'object') return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ': ' + pj(v[k])).join(', ') + '}';
  return JSON.stringify(v);
};
J.sha256 = function (str) {
  const msg = new TextEncoder().encode(str), K = new Uint32Array(64), H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  let n = 2, c = 0; const isP = v => { for (let i = 2; i * i <= v; i++) if (v % i === 0) return false; return true; };
  for (let i = 0; c < 64; i++) { const v = n++; if (isP(v)) K[c++] = Math.floor((Math.cbrt(v) % 1) * 4294967296); }
  const l = msg.length, nb = (((l + 9 + 63) >> 6) << 6), b = new Uint8Array(nb); b.set(msg); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(nb - 8, Math.floor(l * 8 / 4294967296)); dv.setUint32(nb - 4, (l * 8) >>> 0);
  const w = new Uint32Array(64), rr = (x, k) => (x >>> k) | (x << (32 - k));
  for (let o = 0; o < nb; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) { const s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0; }
    let [a, bb, cc, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K[i] + w[i]) >>> 0, S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & bb) ^ (a & cc) ^ (bb & cc), t2 = (S0 + mj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = cc; cc = bb; bb = a; a = (t1 + t2) >>> 0;
    }
    H[0] += a; H[1] += bb; H[2] += cc; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
  }
  return [...H].map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
};
J.cacheKey = (model, state, instructions, criteria) => J.sha256(J.pyJson({model, state, instructions, criteria}));
/* Registro de la cache: source 'api' (probabilidades de Jev) o 'train' (1.0 en el valor real del MIDI) */
J.cacheRecord = function (model, kind, state, instructions, criteria, probs, choice, source) {
  const ans = source === 'train' ? {choice, probabilities: {[choice]: 1}} : {choice, probabilities: Object.fromEntries(Object.entries(probs).map(([k, v]) => [k, Math.round(v * 1e4) / 1e4]))};
  return {key: J.cacheKey(model, state, instructions, criteria), kind, model, source, instructions, state, criteria, answer: ans};
};

root.JEV = J;
if (typeof module !== 'undefined' && module.exports) module.exports = J;
})(typeof window !== 'undefined' ? window : globalThis);
