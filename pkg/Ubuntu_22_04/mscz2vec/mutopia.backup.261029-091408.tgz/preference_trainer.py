#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║                   PREFERENCE TRAINER  v1.2                          ║
║         Aprende tus preferencias musicales. Evalúa MIDIs.          ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                      ║
║  7 comandos — pipeline completo autónomo:                           ║
║  index · train · eval · rank · set · validate · info               ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  INDEX — vectoriza un corpus de MIDIs y genera el índice .npz      ║
║                                                                      ║
║    python preference_trainer.py index ./midis/                      ║
║    python preference_trainer.py index ./midis/ --output corpus.npz ║
║    python preference_trainer.py index ./midis/ --extended-features  ║
║    python preference_trainer.py index ./melodias/ --melodic-features║
║                                                                      ║
║  Procesa todos los .mid/.midi del directorio (recursivo). Solo      ║
║  hay que ejecutarlo una vez (100 000 MIDIs ≈ 1-3 h).               ║
║                                                                      ║
║  Modos de features (elige uno; incompatibles entre sí):            ║
║                                                                      ║
║  · Base (10 dims, defecto)                                          ║
║      pitch_center · pitch_range · interval_mean · contour          ║
║      density · rhythm_variance · polyphony                         ║
║      velocity_mean · velocity_variance · silence_ratio             ║
║                                                                      ║
║  · --extended-features (20 dims)                                    ║
║      Las 10 base + tension_arc · density_arc · pitch_entropy       ║
║      interval_entropy · repetition · harmonic_tension              ║
║      rhythmic_complexity · note_duration_mean                      ║
║      climax_position · dynamic_arc                                  ║
║      Captura estructura temporal y armonía; mejor discriminación.  ║
║                                                                      ║
║  · --melodic-features (16 dims, solo melodía monofónica)           ║
║      pitch_center · pitch_range · interval_mean · contour          ║
║      density · rhythm_variance · velocity_mean · silence_ratio     ║
║      melodic_peak_ratio · step_ratio · leap_ratio · phrase_arch    ║
║      climax_position · note_duration_mean · pitch_entropy          ║
║      interval_entropy                                               ║
║                                                                      ║
║  El modelo detecta el modo automáticamente por el nº de pesos      ║
║  (10=base · 16=melódico · 20=extendido). Modelos de distintos      ║
║  modos son incompatibles — usa archivos .prefs.json separados.     ║
║                                                                      ║
║  Opciones:                                                           ║
║    --output FILE           Archivo .npz de salida (def: corpus.npz) ║
║    --extended-features     Vectores de 20 dimensiones               ║
║    --melodic-features      Vectores de 16 dims para melodía mono    ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  TRAIN — sesión interactiva de anotación                            ║
║                                                                      ║
║    # Modo rating: puntúa MIDIs de 1 a 5 (defecto)                  ║
║    python preference_trainer.py train corpus.npz                    ║
║    python preference_trainer.py train corpus.npz --rounds 30       ║
║                                                                      ║
║    # Modo contraste: elige entre dos MIDIs                          ║
║    python preference_trainer.py train corpus.npz --mode contrast   ║
║                                                                      ║
║    # Con soundfont y modelo específico                              ║
║    python preference_trainer.py train corpus.npz                   ║
║        --model mis_prefs --soundfont ./gm.sf2 --rounds 20          ║
║                                                                      ║
║  Controles durante la sesión:                                        ║
║    Rating:    1-5=puntuar · p=reproducir · x=parar · q=guardar     ║
║    Contraste: A/B=elegir · pa/pb=reproducir A o B · x=parar        ║
║                                                                      ║
║  Selección activa de muestras (no aleatoria):                       ║
║    Rating:    muestra la pieza con mayor incertidumbre del modelo   ║
║    Contraste: muestra el par con mayor desacuerdo esperado          ║
║                                                                      ║
║  Opciones:                                                           ║
║    --mode rating|contrast  Modalidad de anotación (def: rating)     ║
║    --model FILE            Nombre base del modelo (def: prefs)      ║
║    --model-type TYPE       Tipo de modelo (def: linear):            ║
║                            linear  regresión logística SGD          ║
║                            neural  red neuronal 2 capas ocultas     ║
║                            kernel  regresión kernelizada RBF        ║
║                            gp      Gaussian Process sparse          ║
║                            svm     Ranking SVM pairwise             ║
║                            Cada tipo guarda archivo separado:       ║
║                            prefs.linear.json / prefs.neural.json…  ║
║    --rounds N              Número de rondas (def: 20)               ║
║    --soundfont FILE        Soundfont .sf2 para timidity o pygame    ║
║    --no-autoplay           No reproducir automáticamente            ║
║    --candidate-pool N      Pool para selección activa (def: 50)     ║
║                            Mayor valor = mejor selección, más lento ║
║    --strategy NOMBRE       Estrategia de selección activa:          ║
║                            uncertainty  incertidumbre × novedad     ║
║                                         (defecto, rápida)           ║
║                            density      × densidad en corpus        ║
║                                         (prefiere zonas densas)     ║
║                            emc          expected model change        ║
║                                         (señal alta, coste bajo)    ║
║                            eer          expected error reduction     ║
║                                         (óptima formal, lenta)      ║
║                            qbc          query by committee K=5      ║
║                                         (robusta al sobreajuste)    ║
║                            hybrid       combina las tres anteriores  ║
║                                         (recomendada en general)    ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  EVAL — evalúa uno o varios MIDIs con el modelo entrenado           ║
║                                                                      ║
║    # Evaluación básica                                               ║
║    python preference_trainer.py eval pieza.mid --model mis_prefs   ║
║                                                                      ║
║    # Con percentil, histograma y vecinos del corpus                 ║
║    python preference_trainer.py eval pieza.mid                      ║
║        --model mis_prefs --corpus corpus.npz                        ║
║                                                                      ║
║    # Preferencia + afinidad a obras de referencia                   ║
║    python preference_trainer.py eval pieza.mid                      ║
║        --model mis_prefs --affinity ./obras_afines/ --weight 0.4   ║
║                                                                      ║
║    # Múltiples MIDIs + desglose de dimensiones + salida JSON        ║
║    python preference_trainer.py eval *.mid                          ║
║        --model mis_prefs --corpus corpus.npz --verbose --json       ║
║                                                                      ║
║  Salida con --corpus (opcional pero recomendado):                   ║
║    · Score final y score de preferencia/afinidad por separado       ║
║    · Percentil sobre el corpus completo                             ║
║    · Histograma ASCII con posición marcada                          ║
║    · Dimensiones que favorecen / perjudican el score (--verbose)    ║
║    · Vecinos más cercanos con rating conocido                       ║
║                                                                      ║
║  Opciones:                                                           ║
║    --model FILE    Nombre base del modelo (def: prefs)              ║
║    --corpus FILE   .npz para percentil, histograma y vecinos        ║
║    --affinity DIR  Carpeta de obras afines                          ║
║    --weight W      Peso afinidad 0-1 (def: 0.5)                     ║
║                    0 = solo preferencia · 1 = solo afinidad         ║
║    --verbose       Desglose completo por dimensión                  ║
║    --json          Salida JSON machine-readable al final            ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  RANK — escanear y clasificar el corpus completo                    ║
║                                                                      ║
║    python preference_trainer.py rank corpus.npz --model prefs      ║
║                                                                      ║
║    # Con afinidad y exportación CSV                                 ║
║    python preference_trainer.py rank corpus.npz                     ║
║        --model prefs --affinity ./referencias/ --weight 0.4        ║
║        --top 30 --csv ranking.csv                                   ║
║                                                                      ║
║    # Solo MIDIs no anotados, con anotación interactiva              ║
║    python preference_trainer.py rank corpus.npz --model prefs      ║
║        --exclude-annotated --interactive --soundfont ./gm.sf2      ║
║                                                                      ║
║  Muestra:                                                            ║
║    · Histograma global de preferencia sobre el corpus               ║
║    · TOP N — las más preferidas según el modelo                     ║
║    · BOTTOM N — las menos preferidas                                ║
║    · INCIERTAS N — donde el modelo duda más (candidatas a train)    ║
║    · Exportación opcional a CSV con ranking completo                ║
║                                                                      ║
║  Opciones:                                                           ║
║    --model FILE          Nombre base del modelo (def: prefs)        ║
║    --top N               Entradas por lista (def: 20)               ║
║    --affinity DIR        Carpeta de obras afines                    ║
║    --weight W            Peso afinidad 0-1 (def: 0.5)               ║
║    --exclude-annotated   Excluir MIDIs ya anotados en train         ║
║    --interactive         Anotar MIDIs directamente desde el ranking ║
║    --soundfont FILE      Soundfont .sf2 para modo interactivo       ║
║    --csv FILE            Exportar ranking completo a CSV            ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  SET — anotar preferencia directamente sin sesión interactiva       ║
║                                                                      ║
║    python preference_trainer.py set cancion.mid --score 5           ║
║    python preference_trainer.py set *.mid --score 3 --model prefs  ║
║    python preference_trainer.py set ./carpeta/ --score 4            ║
║                                                                      ║
║    # Con fuerza de ajuste personalizada                             ║
║    python preference_trainer.py set pieza.mid --score 5            ║
║        --model mis_prefs --repetitions 20                           ║
║                                                                      ║
║  Asigna un rating directamente y actualiza el modelo               ║
║  inmediatamente. Muestra el cambio de score antes/después.          ║
║  --repetitions controla la fuerza del ajuste (se aplica N veces).  ║
║                                                                      ║
║  Opciones:                                                           ║
║    --score N         Preferencia a asignar, obligatorio (1-5)       ║
║    --model FILE      Nombre base del modelo (def: prefs)            ║
║    --repetitions N   Fuerza del ajuste, nº de aplicaciones (def:10) ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  VALIDATE — validación cruzada del modelo                           ║
║                                                                      ║
║    python preference_trainer.py validate --model prefs              ║
║    python preference_trainer.py validate --model prefs              ║
║        --corpus corpus.npz --folds 10                               ║
║                                                                      ║
║  Mide con k-fold cross-validation:                                  ║
║    · MAE — error absoluto medio en predicción de rating             ║
║    · Pair accuracy — % de pares ordenados correctamente             ║
║    · Correlación de Spearman entre predicciones y ratings reales    ║
║  Incluye interpretación automática y recomendaciones de mejora.     ║
║  Requiere al menos 10 ejemplos anotados para resultados fiables.    ║
║                                                                      ║
║  Opciones:                                                           ║
║    --model FILE    Nombre base del modelo (def: prefs)              ║
║    --corpus FILE   .npz para recuperar vectores del historial       ║
║    --folds N       Número de folds (def: 5)                         ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  INFO — inspeccionar el modelo guardado                             ║
║                                                                      ║
║    python preference_trainer.py info                                ║
║    python preference_trainer.py info --model mis_prefs             ║
║                                                                      ║
║  Muestra los pesos aprendidos por dimensión, número de ejemplos    ║
║  anotados, historial de sesiones y estadísticas del modelo.         ║
║                                                                      ║
║  Opciones:                                                           ║
║    --model FILE    Nombre base del modelo (def: prefs)              ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  REPRODUCCIÓN INTEGRADA                                              ║
║                                                                      ║
║  Cada MIDI se reproduce automáticamente al presentarse.             ║
║  La música continúa mientras el usuario decide; se para al votar.  ║
║                                                                      ║
║  Backends de audio (se detectan automáticamente):                   ║
║    pygame    pip install pygame          (recomendado, sin externo) ║
║    timidity  sudo apt install timidity   (mejor calidad con sf2)    ║
║                                                                      ║
║  Para usar soundfont con timidity:                                  ║
║    python preference_trainer.py train corpus.npz                   ║
║        --soundfont /usr/share/sounds/sf2/FluidR3_GM.sf2            ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  FLUJO TÍPICO                                                        ║
║                                                                      ║
║    # 1. Indexar el corpus (una sola vez)                            ║
║    python preference_trainer.py index ./midis/                      ║
║    python preference_trainer.py index ./midis/ --extended-features  ║
║                                                                      ║
║    # 2. Entrenar el modelo (repetir hasta tener ≥30 ejemplos)       ║
║    python preference_trainer.py train corpus.npz --rounds 20       ║
║    python preference_trainer.py train corpus.npz --mode contrast   ║
║                                                                      ║
║    # 3. Validar la calidad del modelo                               ║
║    python preference_trainer.py validate --model prefs             ║
║                                                                      ║
║    # 4. Evaluar una pieza propia                                    ║
║    python preference_trainer.py eval mi_pieza.mid                  ║
║        --model prefs --corpus corpus.npz --verbose                 ║
║                                                                      ║
║    # 5. Clasificar el corpus entero y exportar                      ║
║    python preference_trainer.py rank corpus.npz                    ║
║        --model prefs --top 50 --csv ranking.csv                    ║
║                                                                      ║
║    # 6. Anotar manualmente sin sesión interactiva                   ║
║    python preference_trainer.py set favorita.mid --score 5         ║
║                                                                      ║
║    # 7. Inspeccionar el modelo                                      ║
║    python preference_trainer.py info --model prefs                 ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  MODELO DE PREFERENCIAS                                              ║
║                                                                      ║
║  Regresión lineal sobre los vectores musicales del corpus.          ║
║  Entrenamiento incremental con SGD. Se guarda como JSON             ║
║  entre sesiones y acumula ejemplos de forma indefinida.             ║
║  Nombre del archivo: <model>.prefs.json  (def: prefs.prefs.json)   ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║  DEPENDENCIAS                                                        ║
║    pip install mido numpy          # obligatorio                    ║
║    pip install pygame              # opcional: audio (recomendado)  ║
║    sudo apt install timidity       # opcional: audio alternativo    ║
╚══════════════════════════════════════════════════════════════════════╝
"""


import sys
import os
import json
import math
import time
import random
import argparse
import subprocess
import threading
from pathlib import Path
from collections import defaultdict

# UTF-8 en stdin/stdout
if hasattr(sys.stdin, "reconfigure"):
    try:
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# ─── Dependencias opcionales ─────────────────────────────────────────

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

try:
    import mido
    HAS_MIDO = True
except ImportError:
    HAS_MIDO = False

import os as _os
_os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')  # sin banner de pygame en stdout
try:
    import pygame
    HAS_PYGAME = True
except ImportError:
    HAS_PYGAME = False


# ════════════════════════════════════════════════════════════════════
#  COLORES
# ════════════════════════════════════════════════════════════════════

USE_COLOR = sys.stdout.isatty()


def _ensure_parent(path):
    """Contrato de la suite: toda salida crea su directorio padre.
    Devuelve `path` sin modificar (solo actúa sobre rutas, no sobre ficheros)."""
    import os as _os
    if isinstance(path, (str, bytes, _os.PathLike)):
        d = _os.path.dirname(_os.path.abspath(_os.fsdecode(path)))
        if d:
            _os.makedirs(d, exist_ok=True)
    return path

def _c(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text

def bold(t):    return _c(t, "1")
def dim(t):     return _c(t, "2")
def green(t):   return _c(t, "32")
def yellow(t):  return _c(t, "33")
def cyan(t):    return _c(t, "36")
def red(t):     return _c(t, "31")
def magenta(t): return _c(t, "35")
def blue(t):    return _c(t, "34")


# ════════════════════════════════════════════════════════════════════
#  VECTORIZADOR — 10 dimensiones (mido + math, sin numpy)
# ════════════════════════════════════════════════════════════════════

# Features base (siempre calculadas)
DIM_NAMES_BASE = [
    "pitch_center",       # 0  altura media normalizada (0-1)
    "pitch_range",        # 1  rango de alturas normalizado (0-1)
    "interval_mean",      # 2  intervalo medio entre notas (0-1)
    "contour",            # 3  dirección global: 0 baja, 0.5 plana, 1 sube
    "density",            # 4  notas por segundo (0-1, saturado a 10 nps)
    "rhythm_variance",    # 5  irregularidad rítmica (0-1)
    "polyphony",          # 6  media de voces simultáneas (0-1, sat. a 8)
    "velocity_mean",      # 7  dinámica media (0-1)
    "velocity_variance",  # 8  variación dinámica (0-1)
    "silence_ratio",      # 9  proporción de silencio (0-1)
]

# Features extendidas (--extended-features, más costosas)
DIM_NAMES_EXTENDED = [
    "tension_arc",        # 10 arco de tensión: sube(1) / plana(0.5) / baja(0)
    "density_arc",        # 11 arco de densidad: cómo cambia la densidad a lo largo
    "pitch_entropy",      # 12 entropía de la distribución de alturas (diversidad tonal)
    "interval_entropy",   # 13 entropía de intervalos (diversidad melódica)
    "repetition",         # 14 índice de repetición motívica (0=ninguna, 1=muy repetitivo)
    "harmonic_tension",   # 15 tensión armónica media (disonancias vs consonancias)
    "rhythmic_complexity",# 16 complejidad rítmica por densidad de cambios de IOI
    "note_duration_mean", # 17 duración media de notas normalizada
    "climax_position",    # 18 posición temporal del clímax (0=inicio, 1=final)
    "dynamic_arc",        # 19 arco dinámico: crescendo(1) / decrescendo(0) / plano(0.5)
]

DIM_NAMES = DIM_NAMES_BASE  # se amplía a DIM_NAMES_BASE + DIM_NAMES_EXTENDED con --extended-features

N_DIMS = len(DIM_NAMES)

DIM_LABELS_BASE = {
    "pitch_center":     ("grave", "agudo"),
    "pitch_range":      ("estrecho", "amplio"),
    "interval_mean":    ("stepwise", "saltos grandes"),
    "contour":          ("descendente", "ascendente"),
    "density":          ("sparse", "denso"),
    "rhythm_variance":  ("regular", "irregular"),
    "polyphony":        ("monofónico", "polifónico"),
    "velocity_mean":    ("piano", "forte"),
    "velocity_variance":("dinámica estable", "dinámica variable"),
    "silence_ratio":    ("continuo", "silencioso"),
}

DIM_LABELS_EXTENDED = {
    "tension_arc":         ("tensión decae", "tensión crece"),
    "density_arc":         ("rarefacción", "densificación"),
    "pitch_entropy":       ("tonal fijo", "tonal diverso"),
    "interval_entropy":    ("melódica repetitiva", "melódica variada"),
    "repetition":          ("sin repetición", "muy repetitivo"),
    "harmonic_tension":    ("consonante", "disonante"),
    "rhythmic_complexity": ("ritmo simple", "ritmo complejo"),
    "note_duration_mean":  ("notas cortas", "notas largas"),
    "climax_position":     ("clímax al inicio", "clímax al final"),
    "dynamic_arc":         ("decrescendo", "crescendo"),
}

DIM_LABELS = {**DIM_LABELS_BASE, **DIM_LABELS_EXTENDED}

# Features melódicas — para MIDIs de una sola voz (--melodic-features)
# Reemplaza el set base: elimina polyphony/velocity_variance (irrelevantes
# en melodía monofónica) y añade análisis melódico fino.
DIM_NAMES_MELODIC = [
    "pitch_center",        # 0  altura media normalizada (0-1)
    "pitch_range",         # 1  rango de alturas normalizado (0-1)
    "interval_mean",       # 2  intervalo medio (0-1)
    "contour",             # 3  dirección global (0 baja, 0.5 plana, 1 sube)
    "density",             # 4  notas por segundo (0-1)
    "rhythm_variance",     # 5  irregularidad rítmica (0-1)
    "velocity_mean",       # 6  dinámica media (0-1)
    "silence_ratio",       # 7  proporción de silencio (0-1)
    "melodic_peak_ratio",  # 8  posición de la nota más alta dentro del rango (0-1)
    "step_ratio",          # 9  proporción de movimientos por grado (<=2 semitonos)
    "leap_ratio",          # 10 proporción de saltos grandes (>=7 semitonos)
    "phrase_arch",         # 11 curvatura de frase: sube-y-baja(1) vs monótona(0)
    "climax_position",     # 12 posición temporal del clímax (0=inicio, 1=final)
    "note_duration_mean",  # 13 duración media de notas normalizada
    "pitch_entropy",       # 14 entropía de distribución de alturas (diversidad)
    "interval_entropy",    # 15 entropía de intervalos (variedad melódica)
]

DIM_LABELS_MELODIC = {
    "pitch_center":       ("grave", "agudo"),
    "pitch_range":        ("estrecho", "amplio"),
    "interval_mean":      ("stepwise", "saltos grandes"),
    "contour":            ("descendente", "ascendente"),
    "density":            ("sparse", "denso"),
    "rhythm_variance":    ("regular", "irregular"),
    "velocity_mean":      ("piano", "forte"),
    "silence_ratio":      ("continuo", "silencioso"),
    "melodic_peak_ratio": ("cima baja", "cima alta"),
    "step_ratio":         ("pocas notas conjuntas", "movimiento conjunto"),
    "leap_ratio":         ("sin saltos", "muchos saltos"),
    "phrase_arch":        ("línea recta", "arco de frase"),
    "climax_position":    ("clímax al inicio", "clímax al final"),
    "note_duration_mean": ("notas cortas", "notas largas"),
    "pitch_entropy":      ("tonal fijo", "tonal diverso"),
    "interval_entropy":   ("melódica repetitiva", "melódica variada"),
}

DIM_LABELS = {**DIM_LABELS_BASE, **DIM_LABELS_EXTENDED, **DIM_LABELS_MELODIC}


def vectorize_midi(path: str, extended: bool = False,
                   melodic: bool = False) -> dict:
    """
    Extrae vector de características de un MIDI. Solo mido + math, sin numpy.

    Modos:
      base     (default) — 10 features generales
      extended            — 20 features (base + temporales/armónicas)
      melodic             — 16 features optimizadas para melodía monofónica
    """
    result = {
        "path": str(path),
        "vector": None,
        "duration_s": 0.0,
        "n_tracks": 0,
        "n_notes": 0,
        "tempo_bpm": 120,
        "error": None,
    }

    if not HAS_MIDO:
        result["error"] = "mido_not_installed"
        return result

    try:
        mid = mido.MidiFile(str(path), clip=True)
    except Exception as e:
        result["error"] = str(e)
        return result

    tempo = 500000
    ticks_per_beat = mid.ticks_per_beat or 480
    notes = []
    active = {}
    current_time_s = 0.0

    for track in mid.tracks:
        current_time_s = 0.0
        active = {}
        for msg in track:
            delta_s = mido.tick2second(msg.time, ticks_per_beat, tempo)
            current_time_s += delta_s

            if msg.type == "set_tempo":
                tempo = msg.tempo
            elif msg.type == "note_on" and msg.velocity > 0:
                active[msg.note] = (current_time_s, msg.velocity)
            elif msg.type in ("note_off",) or (
                msg.type == "note_on" and msg.velocity == 0
            ):
                if msg.note in active:
                    on_time, vel = active.pop(msg.note)
                    dur = current_time_s - on_time
                    notes.append((on_time, msg.note, vel, max(dur, 0.05)))

    result["n_tracks"] = len(mid.tracks)
    result["n_notes"] = len(notes)
    result["tempo_bpm"] = round(60_000_000 / tempo)

    if len(notes) < 4:
        result["error"] = "too_few_notes"
        return result

    end_times = [n[0] + n[3] for n in notes]
    total_dur = max(end_times) if end_times else 0.0
    result["duration_s"] = total_dur

    if total_dur < 2.0:
        result["error"] = "too_short"
        return result

    pitches     = [n[1] for n in notes]
    velocities  = [n[2] for n in notes]
    onset_times = sorted([n[0] for n in notes])

    pitch_mean   = sum(pitches) / len(pitches)
    pitch_center = (pitch_mean - 21) / (108 - 21)

    pitch_range = (max(pitches) - min(pitches)) / 87.0

    intervals    = [abs(pitches[i+1] - pitches[i]) for i in range(len(pitches)-1)]
    interval_mean = min((sum(intervals) / len(intervals)) / 12.0, 1.0)

    half = len(pitches) // 2
    first_half  = pitches[:half]
    second_half = pitches[half:]
    mean_first  = sum(first_half) / len(first_half)
    mean_second = sum(second_half) / len(second_half)
    contour_raw = mean_second - mean_first
    contour = (max(-1.0, min(1.0, contour_raw / 12.0)) + 1) / 2

    density = min(len(notes) / max(total_dur, 1.0) / 10.0, 1.0)

    iois = [onset_times[i+1] - onset_times[i] for i in range(len(onset_times)-1)]
    if iois:
        mean_ioi = sum(iois) / len(iois)
        var_ioi  = sum((x - mean_ioi)**2 for x in iois) / len(iois)
        rhythm_variance = min(math.sqrt(var_ioi) / 2.0, 1.0)
    else:
        rhythm_variance = 0.0

    sample_times = [total_dur * i / 100 for i in range(100)]
    poly_counts = [
        sum(1 for (on, p, v, dur) in notes if on <= t <= on + dur)
        for t in sample_times
    ]
    polyphony = min(sum(poly_counts) / len(poly_counts) / 8.0, 1.0)

    velocity_mean = sum(velocities) / len(velocities) / 127.0

    vel_mean = sum(velocities) / len(velocities)
    vel_var  = sum((v - vel_mean)**2 for v in velocities) / len(velocities)
    velocity_variance = min(math.sqrt(vel_var) / 64.0, 1.0)

    total_note_time = sum(n[3] for n in notes)
    silence_ratio   = max(0.0, 1.0 - (total_note_time / max(total_dur, 1.0)))

    base_vector = [
        pitch_center, pitch_range, interval_mean, contour,
        density, rhythm_variance, polyphony,
        velocity_mean, velocity_variance, silence_ratio,
    ]

    if not extended and not melodic:
        result["vector"] = base_vector
        return result

    # ── Features melódicas (melodic=True) ────────────────────────────
    if melodic:
        # 8. melodic_peak_ratio — altura de la nota más alta dentro del rango
        p_min, p_max = min(pitches), max(pitches)
        melodic_peak_ratio = (p_max - p_min) / 87.0 if p_max > p_min else 0.5

        # 9. step_ratio — proporción de movimientos por grado (≤2 semit.)
        if intervals:
            step_ratio = sum(1 for iv in intervals if iv <= 2) / len(intervals)
        else:
            step_ratio = 0.5

        # 10. leap_ratio — proporción de saltos grandes (≥7 semit.)
        if intervals:
            leap_ratio = sum(1 for iv in intervals if iv >= 7) / len(intervals)
        else:
            leap_ratio = 0.0

        # 11. phrase_arch — curvatura de frase media
        # Divide la melodía en frases de ~8 notas y mide si cada una
        # tiene forma de arco (sube luego baja o viceversa)
        phrase_size = 8
        arches = []
        for start in range(0, len(pitches) - phrase_size, phrase_size // 2):
            phrase = pitches[start:start + phrase_size]
            if len(phrase) < 4:
                continue
            mid = len(phrase) // 2
            first_half  = phrase[:mid]
            second_half = phrase[mid:]
            m1 = sum(first_half)  / len(first_half)
            m2 = sum(second_half) / len(second_half)
            center = sum(phrase) / len(phrase)
            # Arco: si el centro de la frase está por encima/debajo de ambos extremos
            extremes_mean = (phrase[0] + phrase[-1]) / 2
            arch = abs(center - extremes_mean) / max(p_max - p_min, 1)
            arches.append(min(arch, 1.0))
        phrase_arch = sum(arches) / len(arches) if arches else 0.0

        # 12. climax_position — posición temporal de la nota más alta
        max_pitch_val = max(pitches)
        max_indices   = [i for i, p in enumerate(pitches) if p == max_pitch_val]
        climax_idx    = max_indices[len(max_indices) // 2]
        climax_onset  = (sorted(onset_times)[climax_idx]
                         if climax_idx < len(onset_times) else total_dur / 2)
        climax_position = min(climax_onset / max(total_dur, 1.0), 1.0)

        # 13. note_duration_mean — duración media normalizada (sat. a 4s)
        durations = [n[3] for n in notes]
        note_duration_mean = min(sum(durations) / len(durations) / 4.0, 1.0)

        # 14. pitch_entropy — entropía de clases de altura (12 clases)
        pitch_classes = [0] * 12
        for p in pitches:
            pitch_classes[p % 12] += 1
        n_p = sum(pitch_classes) or 1
        pitch_entropy = 0.0
        for c in pitch_classes:
            if c > 0:
                p_i = c / n_p
                pitch_entropy -= p_i * math.log2(p_i)
        pitch_entropy = min(pitch_entropy / math.log2(12), 1.0)

        # 15. interval_entropy — entropía de intervalos (13 clases)
        interval_classes = [0] * 13
        for iv in intervals:
            interval_classes[min(iv, 12)] += 1
        n_iv = sum(interval_classes) or 1
        interval_entropy = 0.0
        for c in interval_classes:
            if c > 0:
                p_i = c / n_iv
                interval_entropy -= p_i * math.log2(p_i)
        interval_entropy = min(interval_entropy / math.log2(13), 1.0)

        result["vector"] = [
            pitch_center, pitch_range, interval_mean, contour,
            density, rhythm_variance, velocity_mean, silence_ratio,
            melodic_peak_ratio, step_ratio, leap_ratio, phrase_arch,
            climax_position, note_duration_mean, pitch_entropy, interval_entropy,
        ]
        return result

    # ── Features extendidas ──────────────────────────────────────────

    # 10. tension_arc — diferencia de "tensión" entre segunda y primera mitad
    # Proxy: densidad × rango de pitch en cada mitad
    half_t  = total_dur / 2
    first_n = [n for n in notes if n[0] < half_t]
    second_n= [n for n in notes if n[0] >= half_t]

    def _section_tension(ns):
        if not ns:
            return 0.0
        ps = [n[1] for n in ns]
        rng = (max(ps) - min(ps)) / 87.0
        den = min(len(ns) / max(half_t, 0.1) / 10.0, 1.0)
        return rng * den

    t1 = _section_tension(first_n)
    t2 = _section_tension(second_n)
    tension_arc = (math.tanh(t2 - t1) + 1) / 2  # 0=baja, 0.5=plana, 1=sube

    # 11. density_arc — cambio de densidad entre tercios
    third = total_dur / 3
    def _third_density(start, end):
        ns = [n for n in notes if start <= n[0] < end]
        return min(len(ns) / max(end - start, 0.1) / 10.0, 1.0)
    d1 = _third_density(0, third)
    d3 = _third_density(2*third, total_dur)
    density_arc = (math.tanh((d3 - d1) * 3) + 1) / 2

    # 12. pitch_entropy — entropía de distribución de clases de altura (12 clases)
    pitch_classes = [0] * 12
    for p in pitches:
        pitch_classes[p % 12] += 1
    n_p = sum(pitch_classes) or 1
    pitch_entropy = 0.0
    for c in pitch_classes:
        if c > 0:
            p_i = c / n_p
            pitch_entropy -= p_i * math.log2(p_i)
    pitch_entropy = min(pitch_entropy / math.log2(12), 1.0)  # normalizar a [0,1]

    # 13. interval_entropy — entropía de intervalos (clases 0-11 semítonos)
    interval_classes = [0] * 13
    for iv in intervals:
        interval_classes[min(iv, 12)] += 1
    n_iv = sum(interval_classes) or 1
    interval_entropy = 0.0
    for c in interval_classes:
        if c > 0:
            p_i = c / n_iv
            interval_entropy -= p_i * math.log2(p_i)
    interval_entropy = min(interval_entropy / math.log2(13), 1.0)

    # 14. repetition — similitud entre ventanas de 4 notas consecutivas
    # Cuenta cuántos n-gramas de 4 notas se repiten
    n_gram_size = 4
    if len(pitches) >= n_gram_size * 2:
        ngrams = []
        for i in range(len(pitches) - n_gram_size + 1):
            ngrams.append(tuple(pitches[i:i+n_gram_size]))
        unique = len(set(ngrams))
        total_ng = len(ngrams)
        repetition = 1.0 - (unique / total_ng)
    else:
        repetition = 0.0

    # 15. harmonic_tension — proporción de intervalos disonantes
    # Consonancias perfectas: 0, 5, 7, 12 semítonos
    consonant = {0, 5, 7, 12, 4, 3}
    if intervals:
        dissonant_count = sum(1 for iv in intervals if (iv % 12) not in consonant)
        harmonic_tension = dissonant_count / len(intervals)
    else:
        harmonic_tension = 0.0

    # 16. rhythmic_complexity — proporción de cambios de IOI >50%
    if len(iois) > 1:
        changes = sum(
            1 for i in range(len(iois)-1)
            if iois[i] > 0 and abs(iois[i+1] - iois[i]) / iois[i] > 0.5
        )
        rhythmic_complexity = changes / (len(iois) - 1)
    else:
        rhythmic_complexity = 0.0

    # 17. note_duration_mean — duración media normalizada (saturado a 4 segundos)
    durations = [n[3] for n in notes]
    note_duration_mean = min(sum(durations) / len(durations) / 4.0, 1.0)

    # 18. climax_position — posición temporal (0-1) de la nota más alta
    max_pitch   = max(pitches)
    max_indices = [i for i, p in enumerate(pitches) if p == max_pitch]
    climax_note_idx = max_indices[len(max_indices)//2]
    climax_onset    = sorted(onset_times)[climax_note_idx] if climax_note_idx < len(onset_times) else total_dur / 2
    climax_position = min(climax_onset / max(total_dur, 1.0), 1.0)

    # 19. dynamic_arc — diferencia de velocidad media entre mitades
    vel_first  = [n[2] for n in notes if n[0] < half_t]
    vel_second = [n[2] for n in notes if n[0] >= half_t]
    vm1 = sum(vel_first)  / len(vel_first)  if vel_first  else 64.0
    vm2 = sum(vel_second) / len(vel_second) if vel_second else 64.0
    dynamic_arc = (math.tanh((vm2 - vm1) / 32.0) + 1) / 2

    result["vector"] = base_vector + [
        tension_arc, density_arc, pitch_entropy, interval_entropy,
        repetition, harmonic_tension, rhythmic_complexity,
        note_duration_mean, climax_position, dynamic_arc,
    ]
    return result


def describe_vector(v: list) -> str:
    """Descripción textual breve de un vector de 10 dims."""
    parts = []
    labels = [
        ("pitch_center", 0), ("density", 4), ("polyphony", 6),
        ("contour", 3), ("silence_ratio", 9)
    ]
    for name, idx in labels:
        lo, hi = DIM_LABELS[name]
        val = v[idx]
        if val < 0.35:
            parts.append(lo)
        elif val > 0.65:
            parts.append(hi)
    return ", ".join(parts) if parts else "neutro"


def format_duration(s: float) -> str:
    m = int(s // 60)
    sec = int(s % 60)
    return f"{m}:{sec:02d}"


# ════════════════════════════════════════════════════════════════════
#  MODELOS DE PREFERENCIAS
#
#  Cinco implementaciones seleccionables con --model-type:
#
#  linear   Regresión logística con SGD incremental. Defecto.
#           Archivo: <name>.linear.json
#
#  neural   Red neuronal pequeña (2 capas ocultas). Aprende no-
#           linealidades. Backprop con mini-batch SGD.
#           Archivo: <name>.neural.json
#
#  kernel   Regresión kernelizada con RBF. Aproximación Nyström
#           para escalabilidad con >500 ejemplos.
#           Archivo: <name>.kernel.json
#
#  gp       Gaussian Process con kernel RBF + ruido. Incertidumbre
#           calibrada de forma exacta. Aproximación sparse (inducing
#           points) para O(m²n) con m<<n.
#           Archivo: <name>.gp.json
#           Tiene memoria incorporada — no usa score_with_memory.
#
#  svm      Ranking SVM (pairwise). Aprende orden relativo, no
#           scores absolutos. Optimización con SGD sobre pares.
#           Archivo: <name>.svm.json
#           Escala de salida incompatible — no usa score_with_memory.
#
#  Todos comparten la interfaz:
#    model.score(vector) → float [0,1]
#    model.uncertainty(vector) → float [0,1]
#    model.update_rating(vector, rating, path)
#    model.update_contrast(winner_vec, loser_vec, ...)
#    model.score_with_memory(vector, path) → float [0,1]
#    model.save(path) / cls.load(path)
#    model.has_builtin_memory → bool
# ════════════════════════════════════════════════════════════════════


# ── Base compartida ──────────────────────────────────────────────────

class _BaseModel:
    """
    Clase base que provee score_with_memory, annotation_count,
    novelty_score y el historial compartido a todos los modelos.
    Subclases deben implementar: score(), uncertainty(),
    update_rating(), update_contrast(), save(), load().
    """

    has_builtin_memory = False   # GP y SVM lo sobreescriben a True
    MODEL_TYPE         = "base"
    VERSION            = "1.0"

    def __init__(self):
        self.n_train         = 0
        self.history         = []
        self.annotated_paths = {}   # path → [ratings]

    # ── Memoria por pieza ────────────────────────────────────────────

    def score_with_memory(self, vector: list, path: str = "") -> float:
        if self.has_builtin_memory or not path:
            return self.score(vector)
        ratings = [r for r in self.annotated_paths.get(path, [])
                   if isinstance(r, (int, float))]
        if not ratings:
            return self.score(vector)
        k       = 5.0
        n       = len(ratings)
        w_mem   = n / (n + k)
        mem     = (sum(ratings) / n - 1) / 4.0
        return (1.0 - w_mem) * self.score(vector) + w_mem * mem

    def annotation_count(self, path: str) -> int:
        return len(self.annotated_paths.get(path, []))

    def novelty_score(self, path: str) -> float:
        n = self.annotation_count(path)
        return 1.0 / (1.0 + n)

    def calibrate(self, vectors: list):
        """Recalibra el sesgo para que los scores cubran [0.1, 0.9]."""
        if not vectors:
            return
        scores = [self.score(v) for v in random.sample(vectors, min(200, len(vectors)))]
        lo, hi = min(scores), max(scores)
        if hi - lo < 0.05:
            return
        # Escalar logits para que lo→0.1, hi→0.9
        import math as _m
        lo_l = _m.log(lo/(1-lo)) if 0 < lo < 1 else -4.0
        hi_l = _m.log(hi/(1-hi)) if 0 < hi < 1 else  4.0
        tl   = _m.log(0.1/0.9)
        th   = _m.log(0.9/0.1)
        if abs(hi_l - lo_l) < 1e-6:
            return
        self._rescale_logits((th - tl)/(hi_l - lo_l),
                              tl - (th - tl)/(hi_l - lo_l) * lo_l)

    def _rescale_logits(self, scale: float, offset: float):
        pass   # cada subclase implementa si corresponde

    # ── Selección activa (delegada a las funciones de estrategia) ────

    def select_rating_candidate(self, vectors, indices, paths=None,
                                corpus_vectors=None, strategy="uncertainty"):
        if self.n_train < 3:
            if paths:
                unseen = [i for i in indices
                          if self.annotation_count(str(paths[i])) == 0]
                return random.choice(unseen) if unseen else random.choice(indices)
            return random.choice(indices)
        fn = _RATING_STRATEGIES.get(strategy, _rating_uncertainty)
        return fn(self, vectors, indices, paths, corpus_vectors)

    def select_contrast_pair(self, vectors, indices, n_candidates=50,
                             paths=None, corpus_vectors=None,
                             strategy="uncertainty"):
        if len(indices) < 2:
            raise ValueError("Se necesitan al menos 2 candidatos.")
        pool = random.sample(indices, min(n_candidates, len(indices)))
        if self.n_train < 3:
            best_pair, best_sim = None, -1.0
            for ii in range(len(pool)):
                for jj in range(ii+1, len(pool)):
                    a, b = pool[ii], pool[jj]
                    sim = _cosine_similarity(vectors[a], vectors[b])
                    if sim > best_sim:
                        best_sim, best_pair = sim, (a, b)
            return best_pair
        fn = _CONTRAST_STRATEGIES.get(strategy, _contrast_uncertainty)
        return fn(self, vectors, pool, paths, corpus_vectors)

    # ── Diagnóstico ──────────────────────────────────────────────────

    def annotated_distribution(self):
        dist = []
        for entry in self.history:
            if entry.get("type") == "rating" and "rating" in entry:
                dist.append((entry["path"], (entry["rating"]-1)/4.0))
        return dist

    def top_dimensions(self, n=5):
        """Devuelve las n dims más influyentes. Subclases pueden sobreescribir."""
        return []

    def summary(self):
        return f"  Tipo: {self.MODEL_TYPE}  |  ejemplos: {self.n_train}"


# ════════════════════════════════════════════════════════════════════
#  1. LINEAR — regresión logística SGD  (defecto)
# ════════════════════════════════════════════════════════════════════

class PreferenceModel(_BaseModel):
    """
    Regresión logística con SGD incremental.
    score = sigmoid(w·x + b)
    Compatible hacia atrás con todos los archivos .prefs.json existentes.
    """

    VERSION = "1.0"

    MODEL_TYPE         = "linear"
    has_builtin_memory = False

    def __init__(self):
        super().__init__()
        self.weights          = [0.0] * N_DIMS
        self.bias             = 0.0
        self.lr               = 0.05
        self.feature_stats    = {
            "mean": [0.5] * N_DIMS,
            "std":  [0.3] * N_DIMS,
        }

    # ── Predicción ──────────────────────────────────────────────────

    def _sigmoid(self, x: float) -> float:
        try:
            return 1.0 / (1.0 + math.exp(-x))
        except OverflowError:
            return 0.0 if x < 0 else 1.0

    def score(self, vector: list) -> float:
        """Devuelve score de preferencia en [0, 1]."""
        n = min(len(self.weights), len(vector))
        logit = sum(self.weights[i] * vector[i] for i in range(n)) + self.bias
        return self._sigmoid(logit)

    def _rescale_logits(self, scale: float, offset: float):
        self.weights = [w * scale for w in self.weights]
        self.bias    = self.bias * scale + offset

    def uncertainty(self, vector: list) -> float:
        """Incertidumbre: 1 - 2*|score - 0.5|. Máxima en 0.5."""
        s = self.score(vector)
        return 1.0 - 2.0 * abs(s - 0.5)

    # ── Actualización con rating (1-5) ───────────────────────────────

    def update_rating(self, vector: list, rating: int, path: str = ""):
        """SGD paso con un ejemplo de rating."""
        target = (rating - 1) / 4.0  # [0, 1]
        pred   = self.score(vector)
        error  = target - pred
        # gradiente de MSE con sigmoid
        grad_logit = error * pred * (1 - pred)
        if len(self.weights) != len(vector):
            self.weights = self.weights[:len(vector)] + [0.0] * max(0, len(vector) - len(self.weights))
        for i in range(len(vector)):
            self.weights[i] += self.lr * grad_logit * vector[i]
        self.bias    += self.lr * grad_logit
        self.n_train += 1
        self._decay_lr()
        if path:
            self.annotated_paths.setdefault(path, []).append(rating)

    # ── Actualización con par (winner/loser) ────────────────────────

    def update_contrast(self, winner_vec: list, loser_vec: list,
                        winner_path: str = "", loser_path: str = ""):
        """Bradley-Terry: winner > loser."""
        s_w = self.score(winner_vec)
        s_l = self.score(loser_vec)
        # P(w > l) = sigmoid(logit_w - logit_l)
        # Gradient de log-loss
        prob_correct = self._sigmoid(
            sum((self.weights[i]) * (winner_vec[i] - loser_vec[i])
                for i in range(N_DIMS))
            # bias cancela al restar
        )
        # grad respecto a w_i: (1 - prob_correct) * (w_i - l_i)
        if len(self.weights) != len(winner_vec):
            self.weights = self.weights[:len(winner_vec)] + [0.0] * max(0, len(winner_vec) - len(self.weights))
        grad = 1.0 - prob_correct
        for i in range(len(winner_vec)):
            diff = winner_vec[i] - loser_vec[i]
            self.weights[i] += self.lr * grad * diff
        self.n_train += 1
        self._decay_lr()
        if winner_path:
            self.annotated_paths.setdefault(winner_path, []).append("win")
        if loser_path:
            self.annotated_paths.setdefault(loser_path, []).append("lose")

    def _decay_lr(self):
        """Learning rate decay suave."""
        self.lr = max(0.005, 0.05 / (1 + self.n_train * 0.02))

    # ── Selección activa ─────────────────────────────────────────────
    # (heredado de _BaseModel)

    # ── Diagnóstico ─────────────────────────────────────────────────

    def top_dimensions(self, n: int = 5) -> list:
        """Devuelve las n dimensiones con mayor peso absoluto."""
        n_w = len(self.weights)
        if n_w == 16:
            all_names = DIM_NAMES_MELODIC
        elif n_w == 20:
            all_names = DIM_NAMES_BASE + DIM_NAMES_EXTENDED
        else:
            all_names = DIM_NAMES_BASE
        indexed = sorted(
            enumerate(self.weights),
            key=lambda x: abs(x[1]), reverse=True
        )
        return [(all_names[i] if i < len(all_names) else f"dim_{i}", w)
                for i, w in indexed[:n]]

    def summary(self) -> str:
        n_features = len(self.weights)
        if n_features == 16:
            feat_label = f"melódico ({n_features} dims)"
        elif n_features == 20:
            feat_label = f"extendido ({n_features} dims)"
        else:
            feat_label = f"base ({n_features} dims)"
        lines = []
        lines.append(f"  Ejemplos de entrenamiento: {bold(str(self.n_train))}")
        lines.append(f"  Modo de features:          {feat_label}")
        lines.append(f"  Learning rate actual:       {self.lr:.4f}")
        lines.append(f"  Bias:                       {self.bias:+.3f}")
        lines.append("")
        lines.append(f"  {bold('Dimensiones más influyentes:')}")
        for name, w in self.top_dimensions(5):
            bar_len = int(abs(w) * 15)
            bar = ("+" if w >= 0 else "-") * bar_len
            lo, hi = DIM_LABELS[name]
            direction = hi if w > 0 else lo
            lines.append(
                f"    {name:<20} {bar:<16} {w:+.3f}  → {dim(direction)}"
            )
        return "\n".join(lines)

    # ── Serialización ───────────────────────────────────────────────

    def save(self, path: str):
        data = {
            "model_type":       self.MODEL_TYPE,
            "version":          self.VERSION,
            "weights":          self.weights,
            "bias":             self.bias,
            "lr":               self.lr,
            "n_train":          self.n_train,
            "history":          self.history[-200:],
            "annotated_paths":  self.annotated_paths,
            "feature_stats":    self.feature_stats,
        }
        with open(_ensure_parent(path), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, path: str) -> "PreferenceModel":
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        m = cls()
        m.weights          = data.get("weights", [0.0] * N_DIMS)
        m.bias             = data.get("bias", 0.0)
        m.lr               = data.get("lr", 0.05)
        m.n_train          = data.get("n_train", 0)
        m.history          = data.get("history", [])
        m.annotated_paths  = data.get("annotated_paths", {})
        m.feature_stats    = data.get("feature_stats", m.feature_stats)
        return m


# ════════════════════════════════════════════════════════════════════
#  ESTRATEGIAS DE SELECCIÓN ACTIVA
#  Todas comparten la misma firma para rating:
#    fn(model, vectors, indices, paths, corpus_vectors) -> int
#  Y para contraste:
#    fn(model, vectors, pool, paths, corpus_vectors) -> (int, int)
# ════════════════════════════════════════════════════════════════════

# ── Helpers compartidos ──────────────────────────────────────────────

def _mean_cosine(v: list, sample: list, top_k: int = 100) -> float:
    """Similitud coseno media de v con los top_k vectores más cercanos."""
    if not sample:
        return 0.5
    sims = sorted(
        (_cosine_similarity(v, u) for u in sample),
        reverse=True
    )
    k = min(top_k, len(sims))
    return sum(sims[:k]) / k


def _prob_rating(pred: float, rating: int) -> float:
    """
    Probabilidad aproximada de que el usuario asigne `rating` a una pieza
    cuya predicción del modelo es `pred`. Distribución triangular centrada
    en el rating que corresponde a pred, truncada en [1,5].
    """
    expected = pred * 4.0 + 1.0   # desnormalizar a [1,5]
    dist = [max(0.0, 1.0 - abs(r - expected)) for r in range(1, 6)]
    total = sum(dist)
    if total < 1e-9:
        return 0.2
    return dist[rating - 1] / total


def _clone_model(model) -> "_BaseModel":
    """Clona los pesos del modelo sin copiar el historial completo.
    Soporta todos los model types."""
    import json as _json, io as _io
    buf = _io.StringIO()
    model.save.__func__(model, buf) if False else None
    # Usar serialización JSON temporal en memoria
    try:
        tmp = {}
        model.save(_ensure_parent("/tmp/_clone_tmp.json"))
        m = model.__class__.load("/tmp/_clone_tmp.json")
        m.history = []
        m.n_train = model.n_train
        return m
    except Exception:
        # Fallback para linear
        m = PreferenceModel()
        if hasattr(model, 'weights'):
            m.weights = model.weights[:]
            m.bias    = model.bias
        m.lr      = model.lr
        m.n_train = model.n_train
        return m


# ── 1. UNCERTAINTY × NOVEDAD (defecto) ──────────────────────────────

def _rating_uncertainty(model, vectors, indices, paths, corpus_vectors):
    """Máxima incertidumbre del modelo × novedad. O(pool)."""
    def _score(i):
        unc = model.uncertainty(vectors[i])
        nov = model.novelty_score(str(paths[i])) if paths else 1.0
        return unc * nov
    return max(indices, key=_score)


def _contrast_uncertainty(model, vectors, pool, paths, corpus_vectors):
    best_pair, best_val = None, -1.0
    for ii in range(len(pool)):
        for jj in range(ii + 1, len(pool)):
            a, b = pool[ii], pool[jj]
            sa, sb = model.score(vectors[a]), model.score(vectors[b])
            sim  = _cosine_similarity(vectors[a], vectors[b])
            nov_a = model.novelty_score(str(paths[a])) if paths else 1.0
            nov_b = model.novelty_score(str(paths[b])) if paths else 1.0
            val  = sim * (1.0 - abs(sa - sb)) * math.sqrt(nov_a * nov_b)
            if val > best_val:
                best_val, best_pair = val, (a, b)
    return best_pair


# ── 2. DENSITY — incertidumbre × densidad en el corpus ───────────────

def _rating_density(model, vectors, indices, paths, corpus_vectors):
    """
    Incertidumbre × densidad × novedad. O(pool × corpus_sample).
    Prefiere piezas inciertas Y representativas de zonas densas del corpus.
    Anotar una pieza en una región densa beneficia a más vecinas.
    """
    sample = (random.sample(corpus_vectors, min(500, len(corpus_vectors)))
              if corpus_vectors else [])

    def _score(i):
        unc = model.uncertainty(vectors[i])
        den = _mean_cosine(vectors[i], sample) if sample else 0.5
        nov = model.novelty_score(str(paths[i])) if paths else 1.0
        return unc * den * nov

    return max(indices, key=_score)


def _contrast_density(model, vectors, pool, paths, corpus_vectors):
    sample = (random.sample(corpus_vectors, min(500, len(corpus_vectors)))
              if corpus_vectors else [])
    best_pair, best_val = None, -1.0
    for ii in range(len(pool)):
        for jj in range(ii + 1, len(pool)):
            a, b = pool[ii], pool[jj]
            sa, sb = model.score(vectors[a]), model.score(vectors[b])
            sim   = _cosine_similarity(vectors[a], vectors[b])
            den_a = _mean_cosine(vectors[a], sample) if sample else 0.5
            den_b = _mean_cosine(vectors[b], sample) if sample else 0.5
            nov_a = model.novelty_score(str(paths[a])) if paths else 1.0
            nov_b = model.novelty_score(str(paths[b])) if paths else 1.0
            val   = (sim * (1.0 - abs(sa - sb))
                     * math.sqrt(den_a * den_b)
                     * math.sqrt(nov_a * nov_b))
            if val > best_val:
                best_val, best_pair = val, (a, b)
    return best_pair


# ── 3. EMC — Expected Model Change ──────────────────────────────────

def _emc(model, v) -> float:
    """
    Cambio esperado en los pesos si se anotara el vector v.
    E[||Δw||] = Σ_rating P(rating|pred) × |error × pred × (1-pred)|
    O(5) por candidato — muy rápido.
    """
    pred = model.score(v)
    total = 0.0
    for rating in range(1, 6):
        p      = _prob_rating(pred, rating)
        target = (rating - 1) / 4.0
        error  = target - pred
        grad   = abs(error * pred * (1.0 - pred))
        total += p * grad
    return total


def _rating_emc(model, vectors, indices, paths, corpus_vectors):
    """Expected Model Change × novedad. O(pool)."""
    def _score(i):
        emc = _emc(model, vectors[i])
        nov = model.novelty_score(str(paths[i])) if paths else 1.0
        return emc * nov
    return max(indices, key=_score)


def _contrast_emc(model, vectors, pool, paths, corpus_vectors):
    best_pair, best_val = None, -1.0
    for ii in range(len(pool)):
        for jj in range(ii + 1, len(pool)):
            a, b   = pool[ii], pool[jj]
            sim    = _cosine_similarity(vectors[a], vectors[b])
            emc_ab = (_emc(model, vectors[a]) + _emc(model, vectors[b])) / 2
            nov_a  = model.novelty_score(str(paths[a])) if paths else 1.0
            nov_b  = model.novelty_score(str(paths[b])) if paths else 1.0
            val    = sim * emc_ab * math.sqrt(nov_a * nov_b)
            if val > best_val:
                best_val, best_pair = val, (a, b)
    return best_pair


# ── 4. EER — Expected Error Reduction ───────────────────────────────

def _current_error(model, annotated: list) -> float:
    """MSE del modelo sobre el historial anotado."""
    if not annotated:
        return 0.0
    total = 0.0
    for v, target in annotated:
        pred  = model.score(v)
        total += (pred - target) ** 2
    return total / len(annotated)


def _rating_eer(model, vectors, indices, paths, corpus_vectors):
    """
    Expected Error Reduction.
    Para cada candidato x y cada rating posible y:
      1. Clona el modelo y aplica update_rating(x, y)
      2. Mide el error sobre el historial anotado
      3. Pondera por P(Y=y | pred(x))
    Elige el candidato que más reduce el error esperado.
    O(pool × 5 × historial) — más lento, máxima calidad formal.
    """
    # Construir conjunto de evaluación desde el historial
    annotated = []
    for entry in model.history:
        if entry.get("type") == "rating" and "rating" in entry and "path" in entry:
            target = (entry["rating"] - 1) / 4.0
            # Buscar el vector del historial si está disponible
            for iv, ip in zip(vectors, paths if paths else []):
                if str(ip) == entry["path"]:
                    annotated.append((vectors[iv] if isinstance(iv, int) else iv, target))
                    break
    # Fallback: usar todos los vectores del pool con su pred actual como proxy
    if not annotated:
        return _rating_uncertainty(model, vectors, indices, paths, corpus_vectors)

    err_before = _current_error(model, annotated)
    best_idx, best_reduction = indices[0], -1.0

    for i in indices:
        v    = vectors[i]
        pred = model.score(v)
        expected_err = 0.0
        for rating in range(1, 6):
            p = _prob_rating(pred, rating)
            m_clone = _clone_model(model)
            m_clone.update_rating(v, rating)
            expected_err += p * _current_error(m_clone, annotated)
        reduction = err_before - expected_err
        nov = model.novelty_score(str(paths[i])) if paths else 1.0
        if reduction * nov > best_reduction:
            best_reduction = reduction * nov
            best_idx = i

    return best_idx


def _contrast_eer(model, vectors, pool, paths, corpus_vectors):
    """EER adaptado a contraste: elige el par cuya anotación esperada
    reduce más el error. Evalúa ganancias de ambas piezas y las combina."""
    annotated = []
    for entry in model.history:
        if entry.get("type") == "rating" and "rating" in entry and "path" in entry:
            target = (entry["rating"] - 1) / 4.0
            for iv, ip in zip(range(len(vectors)), paths if paths else []):
                if str(ip) == entry["path"]:
                    annotated.append((vectors[iv], target))
                    break
    if not annotated:
        return _contrast_uncertainty(model, vectors, pool, paths, corpus_vectors)

    err_before  = _current_error(model, annotated)
    best_pair, best_val = None, -1.0

    for ii in range(len(pool)):
        for jj in range(ii + 1, len(pool)):
            a, b = pool[ii], pool[jj]
            sim  = _cosine_similarity(vectors[a], vectors[b])
            # Reducción esperada conjunta del par
            total_reduction = 0.0
            for rating in range(1, 6):
                p = _prob_rating(model.score(vectors[a]), rating)
                m_clone = _clone_model(model)
                m_clone.update_rating(vectors[a], rating)
                m_clone.update_rating(vectors[b], rating)
                total_reduction += p * (err_before - _current_error(m_clone, annotated))
            nov_a = model.novelty_score(str(paths[a])) if paths else 1.0
            nov_b = model.novelty_score(str(paths[b])) if paths else 1.0
            val   = sim * total_reduction * math.sqrt(nov_a * nov_b)
            if val > best_val:
                best_val, best_pair = val, (a, b)
    return best_pair


# ── 5. QBC — Query by Committee ─────────────────────────────────────

def _build_committee(model, K: int = 5) -> list:
    """
    Construye K modelos entrenados con subsets aleatorios del historial.
    Cada modelo hereda los pesos actuales y se reajusta con un 70%
    aleatorio del historial de ratings.
    """
    rating_history = [e for e in model.history
                      if e.get("type") == "rating" and "rating" in e]
    committee = []
    for _ in range(K):
        m = _clone_model(model)
        subset = random.sample(rating_history,
                               max(1, int(len(rating_history) * 0.7)))
        for entry in subset:
            # Necesitamos el vector; si no está, skip
            if "__vector" in entry:
                m.update_rating(entry["__vector"], entry["rating"])
        committee.append(m)
    return committee


def _qbc_disagreement(committee: list, v: list) -> float:
    """Varianza de las predicciones del comité sobre v."""
    preds = [m.score(v) for m in committee]
    mean  = sum(preds) / len(preds)
    return sum((p - mean) ** 2 for p in preds) / len(preds)


def _rating_qbc(model, vectors, indices, paths, corpus_vectors):
    """
    Query by Committee con K=5 modelos.
    Elige la pieza con mayor desacuerdo entre modelos × novedad.
    O(K × pool). Robusto al sobreajuste local.

    Nota: requiere que el historial incluya el campo __vector en
    cada entrada de rating (se añade automáticamente al anotar).
    Si el historial no tiene vectores, degrada a uncertainty.
    """
    committee = _build_committee(model, K=5)
    if not any(m.n_train > 0 for m in committee):
        return _rating_uncertainty(model, vectors, indices, paths, corpus_vectors)

    def _score(i):
        dis = _qbc_disagreement(committee, vectors[i])
        nov = model.novelty_score(str(paths[i])) if paths else 1.0
        return dis * nov

    return max(indices, key=_score)


def _contrast_qbc(model, vectors, pool, paths, corpus_vectors):
    committee = _build_committee(model, K=5)
    if not any(m.n_train > 0 for m in committee):
        return _contrast_uncertainty(model, vectors, pool, paths, corpus_vectors)

    best_pair, best_val = None, -1.0
    for ii in range(len(pool)):
        for jj in range(ii + 1, len(pool)):
            a, b  = pool[ii], pool[jj]
            sim   = _cosine_similarity(vectors[a], vectors[b])
            dis   = (_qbc_disagreement(committee, vectors[a]) +
                     _qbc_disagreement(committee, vectors[b])) / 2
            nov_a = model.novelty_score(str(paths[a])) if paths else 1.0
            nov_b = model.novelty_score(str(paths[b])) if paths else 1.0
            val   = sim * dis * math.sqrt(nov_a * nov_b)
            if val > best_val:
                best_val, best_pair = val, (a, b)
    return best_pair


# ── 6. HYBRID — combinación ponderada ───────────────────────────────

def _rating_hybrid(model, vectors, indices, paths, corpus_vectors):
    """
    Combina uncertainty + density + EMC + novedad con pesos iguales.
    Equilibrio entre exploración (density) y explotación (emc/uncertainty).
    Recomendada para uso general.  O(pool × corpus_sample).
    """
    sample = (random.sample(corpus_vectors, min(500, len(corpus_vectors)))
              if corpus_vectors else [])

    def _score(i):
        v   = vectors[i]
        unc = model.uncertainty(v)
        den = _mean_cosine(v, sample) if sample else 0.5
        emc = _emc(model, v)
        nov = model.novelty_score(str(paths[i])) if paths else 1.0
        # Normalizar emc al rango aproximado de uncertainty (ambos en [0,0.25])
        return (unc + den + emc * 4.0) / 3.0 * nov

    return max(indices, key=_score)


def _contrast_hybrid(model, vectors, pool, paths, corpus_vectors):
    sample = (random.sample(corpus_vectors, min(500, len(corpus_vectors)))
              if corpus_vectors else [])
    best_pair, best_val = None, -1.0
    for ii in range(len(pool)):
        for jj in range(ii + 1, len(pool)):
            a, b  = pool[ii], pool[jj]
            sim   = _cosine_similarity(vectors[a], vectors[b])
            diff  = abs(model.score(vectors[a]) - model.score(vectors[b]))
            den   = (_mean_cosine(vectors[a], sample) +
                     _mean_cosine(vectors[b], sample)) / 2 if sample else 0.5
            emc   = (_emc(model, vectors[a]) + _emc(model, vectors[b])) / 2
            nov_a = model.novelty_score(str(paths[a])) if paths else 1.0
            nov_b = model.novelty_score(str(paths[b])) if paths else 1.0
            val   = (sim * (1.0 - diff) + den + emc * 4.0) / 3.0 * math.sqrt(nov_a * nov_b)
            if val > best_val:
                best_val, best_pair = val, (a, b)
    return best_pair


# ── Tablas de despacho ───────────────────────────────────────────────

SELECTION_STRATEGIES = ["uncertainty", "density", "emc", "eer", "qbc", "hybrid"]

_RATING_STRATEGIES = {
    "uncertainty": _rating_uncertainty,
    "density":     _rating_density,
    "emc":         _rating_emc,
    "eer":         _rating_eer,
    "qbc":         _rating_qbc,
    "hybrid":      _rating_hybrid,
}

_CONTRAST_STRATEGIES = {
    "uncertainty": _contrast_uncertainty,
    "density":     _contrast_density,
    "emc":         _contrast_emc,
    "eer":         _contrast_eer,
    "qbc":         _contrast_qbc,
    "hybrid":      _contrast_hybrid,
}


# ════════════════════════════════════════════════════════════════════
#  2. NEURAL — red neuronal pequeña con backprop
# ════════════════════════════════════════════════════════════════════

class NeuralModel(_BaseModel):
    MODEL_TYPE = "neural"; has_builtin_memory = False
    def __init__(self, n_dims=N_DIMS, hidden1=16, hidden2=8):
        super().__init__(); self.n_dims=n_dims; self.h1=hidden1; self.h2=hidden2
        self.lr=0.01; self.l2=0.001
        import math as _m
        def _xav(fi,fo): s=_m.sqrt(2.0/(fi+fo)); return [[random.gauss(0,s) for _ in range(fo)] for _ in range(fi)]
        self.W1=_xav(n_dims,hidden1); self.b1=[0.0]*hidden1
        self.W2=_xav(hidden1,hidden2); self.b2=[0.0]*hidden2
        self.W3=_xav(hidden2,1); self.b3=[0.0]
    @staticmethod
    def _relu(x): return [max(0.0,v) for v in x]
    @staticmethod
    def _sig(x):
        try: return 1.0/(1.0+math.exp(-x))
        except: return 0.0 if x<0 else 1.0
    @staticmethod
    def _mm(x,W): return [sum(x[i]*W[i][j] for i in range(len(x))) for j in range(len(W[0]))]
    @staticmethod
    def _add(a,b): return [x+y for x,y in zip(a,b)]
    def _fwd(self,x):
        z1=self._add(self._mm(x,self.W1),self.b1); a1=self._relu(z1)
        z2=self._add(self._mm(a1,self.W2),self.b2); a2=self._relu(z2)
        z3=self._add(self._mm(a2,self.W3),self.b3); out=self._sig(z3[0])
        return out,(x,z1,a1,z2,a2,z3)
    def score(self,vector):
        v=vector[:self.n_dims]+[0.0]*max(0,self.n_dims-len(vector))
        out,_=self._fwd(v); return out
    def uncertainty(self,vector): s=self.score(vector); return 1.0-2.0*abs(s-0.5)
    def _bp(self,cache,target):
        x,z1,a1,z2,a2,z3=cache; out=self._sig(z3[0]); lr=self.lr; l2=self.l2
        d3=[out-target]
        dz2=[sum(d3[k]*self.W3[j][k] for k in range(1))*(1.0 if z2[j]>0 else 0.0) for j in range(self.h2)]
        dz1=[sum(dz2[k]*self.W2[j][k] for k in range(self.h2))*(1.0 if z1[j]>0 else 0.0) for j in range(self.h1)]
        for j in range(self.h2):
            self.W3[j][0]-=lr*(d3[0]*a2[j]+l2*self.W3[j][0])
        self.b3[0]-=lr*d3[0]
        for j in range(self.h1):
            for k in range(self.h2): self.W2[j][k]-=lr*(dz2[k]*a1[j]+l2*self.W2[j][k])
        for k in range(self.h2): self.b2[k]-=lr*dz2[k]
        for j in range(self.n_dims):
            for k in range(self.h1): self.W1[j][k]-=lr*(dz1[k]*x[j]+l2*self.W1[j][k])
        for k in range(self.h1): self.b1[k]-=lr*dz1[k]
    def update_rating(self,vector,rating,path=""):
        v=vector[:self.n_dims]+[0.0]*max(0,self.n_dims-len(vector))
        target=(rating-1)/4.0; _,cache=self._fwd(v); self._bp(cache,target)
        self.n_train+=1; self.lr=max(0.001,0.01/(1+self.n_train*0.005))
        if path: self.annotated_paths.setdefault(path,[]).append(rating); self.history.append({"type":"rating","path":path,"rating":rating})
    def update_contrast(self,wv,lv,wp="",lp=""):
        """Bradley-Terry: P(w>l) = sigmoid(score_w - score_l).
        Gradient: push winner toward clamp(sw + (1-p_bt), 1),
                        loser toward clamp(sl - (1-p_bt), 0).
        p_bt = sigmoid(sw - sl); grad = 1 - p_bt (error signal)."""
        vw=wv[:self.n_dims]+[0.0]*max(0,self.n_dims-len(wv))
        vl=lv[:self.n_dims]+[0.0]*max(0,self.n_dims-len(lv))
        sw,_=self._fwd(vw); sl,_=self._fwd(vl)
        try: p_bt=1.0/(1.0+math.exp(-(sw-sl)))
        except: p_bt=1.0 if sw>sl else 0.0
        grad=1.0-p_bt   # 0 if already correct, 1 if totally wrong
        _,cw=self._fwd(vw); self._bp(cw,min(1.0,sw+grad))
        _,cl=self._fwd(vl); self._bp(cl,max(0.0,sl-grad))
        self.n_train+=1
        if wp: self.history.append({"type":"contrast","winner":wp,"loser":lp})
    def save(self,path):
        json.dump({"model_type":self.MODEL_TYPE,"version":self.VERSION,"n_dims":self.n_dims,"h1":self.h1,"h2":self.h2,"W1":self.W1,"b1":self.b1,"W2":self.W2,"b2":self.b2,"W3":self.W3,"b3":self.b3,"lr":self.lr,"n_train":self.n_train,"history":self.history[-200:],"annotated_paths":self.annotated_paths},open(_ensure_parent(path),"w",encoding="utf-8"),indent=2,ensure_ascii=False)
    @classmethod
    def load(cls,path):
        d=json.load(open(path,encoding="utf-8")); m=cls(d.get("n_dims",N_DIMS),d.get("h1",16),d.get("h2",8))
        m.W1=d["W1"]; m.b1=d["b1"]; m.W2=d["W2"]; m.b2=d["b2"]; m.W3=d["W3"]; m.b3=d["b3"]
        m.lr=d.get("lr",0.01); m.n_train=d.get("n_train",0); m.history=d.get("history",[]); m.annotated_paths=d.get("annotated_paths",{}); return m
    def summary(self): return f"  Tipo: neural  |  arquitectura: {self.n_dims}→{self.h1}→{self.h2}→1  |  ejemplos: {self.n_train}  |  lr={self.lr:.4f}"


# ════════════════════════════════════════════════════════════════════
#  3. KERNEL — regresión kernelizada RBF (soporte acotado)
# ════════════════════════════════════════════════════════════════════

class KernelModel(_BaseModel):
    """Regresión kernelizada RBF con conjunto de soporte acotado (max_support puntos).
    Puede aprender fronteras no lineales. Usa score_with_memory."""
    MODEL_TYPE="kernel"; has_builtin_memory=False
    def __init__(self,gamma=1.0,max_support=200):
        super().__init__(); self.gamma=gamma; self.max_support=max_support
        self.lr=0.05; self.support_X=[]; self.alpha=[]; self.bias=0.0
    def _rbf(self,x,y): return math.exp(-self.gamma*sum((a-b)**2 for a,b in zip(x,y)))
    def score(self,vector):
        if not self.support_X: return 0.5
        logit=self.bias+sum(a*self._rbf(vector,sv) for a,sv in zip(self.alpha,self.support_X))
        try: return 1.0/(1.0+math.exp(-logit))
        except: return 0.0 if logit<0 else 1.0
    def uncertainty(self,vector): s=self.score(vector); return 1.0-2.0*abs(s-0.5)
    def _add_sv(self,v,a):
        self.support_X.append(v[:]); self.alpha.append(a)
        if len(self.support_X)>self.max_support:
            idx=min(range(len(self.alpha)),key=lambda i:abs(self.alpha[i]))
            self.support_X.pop(idx); self.alpha.pop(idx)
    def update_rating(self,vector,rating,path=""):
        target=(rating-1)/4.0; pred=self.score(vector); error=target-pred; grad=error*pred*(1.0-pred)
        if self.support_X:
            dists=[sum((a-b)**2 for a,b in zip(vector,sv)) for sv in self.support_X]
            near=min(range(len(dists)),key=lambda i:dists[i])
            if dists[near]<0.01: self.alpha[near]+=self.lr*grad
            else: self._add_sv(vector,self.lr*grad)
        else: self._add_sv(vector,self.lr*grad)
        self.bias+=self.lr*grad*0.1; self.n_train+=1
        self.lr=max(0.005,0.05/(1+self.n_train*0.02))
        if path: self.annotated_paths.setdefault(path,[]).append(rating); self.history.append({"type":"rating","path":path,"rating":rating})
    def update_contrast(self,wv,lv,wp="",lp=""):
        """Bradley-Terry: always update proportional to prediction error.
        grad = 1 - P(w>l) = 1 - sigmoid(logit_w - logit_l).
        Winner alpha += lr*grad, loser alpha -= lr*grad."""
        sw=self.score(wv); sl=self.score(lv)
        try: p_bt=1.0/(1.0+math.exp(-(sw-sl)))
        except: p_bt=1.0 if sw>sl else 0.0
        grad=self.lr*(1.0-p_bt)
        self._add_sv(wv[:], grad)
        self._add_sv(lv[:], -grad)
        self.bias+=grad*0.05
        self.n_train+=1
        if wp: self.history.append({"type":"contrast","winner":wp,"loser":lp})
    def save(self,path):
        json.dump({"model_type":self.MODEL_TYPE,"version":self.VERSION,"gamma":self.gamma,"max_support":self.max_support,"support_X":self.support_X,"alpha":self.alpha,"bias":self.bias,"lr":self.lr,"n_train":self.n_train,"history":self.history[-200:],"annotated_paths":self.annotated_paths},open(_ensure_parent(path),"w",encoding="utf-8"),indent=2,ensure_ascii=False)
    @classmethod
    def load(cls,path):
        d=json.load(open(path,encoding="utf-8")); m=cls(d.get("gamma",1.0),d.get("max_support",200))
        m.support_X=d.get("support_X",[]); m.alpha=d.get("alpha",[]); m.bias=d.get("bias",0.0)
        m.lr=d.get("lr",0.05); m.n_train=d.get("n_train",0); m.history=d.get("history",[]); m.annotated_paths=d.get("annotated_paths",{}); return m
    def summary(self): return f"  Tipo: kernel (RBF)  |  γ={self.gamma}  |  soporte: {len(self.support_X)}/{self.max_support}  |  ejemplos: {self.n_train}"


# ════════════════════════════════════════════════════════════════════
#  HELPER: inversión de matriz densa (para GP)
# ════════════════════════════════════════════════════════════════════

def _mat_inv(A):
    n=len(A); M=[A[i][:]+[1.0 if i==j else 0.0 for j in range(n)] for i in range(n)]
    for col in range(n):
        piv=max(range(col,n),key=lambda r:abs(M[r][col])); M[col],M[piv]=M[piv],M[col]
        if abs(M[col][col])<1e-12: return [[1.0 if i==j else 0.0 for j in range(n)] for i in range(n)]
        inv=1.0/M[col][col]; M[col]=[v*inv for v in M[col]]
        for row in range(n):
            if row!=col: f=M[row][col]; M[row]=[M[row][k]-f*M[col][k] for k in range(2*n)]
    return [row[n:] for row in M]


# ════════════════════════════════════════════════════════════════════
#  4. GP — Gaussian Process con kernel RBF sparse
# ════════════════════════════════════════════════════════════════════

class GPModel(_BaseModel):
    """Gaussian Process con kernel RBF y sparse inducing points (max_inducing≤150).
    Incertidumbre calibrada como varianza posterior. has_builtin_memory=True."""
    MODEL_TYPE="gp"; has_builtin_memory=True
    def __init__(self,gamma=1.0,noise=0.1,max_inducing=150):
        super().__init__(); self.gamma=gamma; self.noise=noise; self.max_inducing=max_inducing
        self.X_ind=[]; self.y_ind=[]; self._K_inv=None; self._dirty=True
    def _rbf(self,x,y): return math.exp(-self.gamma*sum((a-b)**2 for a,b in zip(x,y)))
    def _build(self):
        n=len(self.X_ind)
        if n==0: self._K_inv=[]; self._dirty=False; return
        K=[[self._rbf(self.X_ind[i],self.X_ind[j])+(self.noise if i==j else 0.0) for j in range(n)] for i in range(n)]
        self._K_inv=_mat_inv(K); self._dirty=False
    def score(self,vector):
        if not self.X_ind: return 0.5
        if self._dirty: self._build()
        k=[self._rbf(vector,xi) for xi in self.X_ind]
        mu=sum(k[i]*sum(self._K_inv[i][j]*self.y_ind[j] for j in range(len(self.y_ind))) for i in range(len(k)))
        try: return 1.0/(1.0+math.exp(-mu*4.0))
        except: return 0.0 if mu<0 else 1.0
    def uncertainty(self,vector):
        if not self.X_ind or not self._K_inv: return 1.0
        if self._dirty: self._build()
        k=[self._rbf(vector,xi) for xi in self.X_ind]; kss=self._rbf(vector,vector)
        Kk=[sum(self._K_inv[i][j]*k[j] for j in range(len(k))) for i in range(len(k))]
        var=kss-sum(k[i]*Kk[i] for i in range(len(k)))
        return min(1.0,max(0.0,var/(kss+1e-9)))
    def _add_ind(self,vector,target):
        if len(self.X_ind)<self.max_inducing: self.X_ind.append(vector[:]); self.y_ind.append(target)
        else:
            dists=[sum((a-b)**2 for a,b in zip(vector,xi)) for xi in self.X_ind]
            near=min(range(len(dists)),key=lambda i:dists[i])
            if dists[near]<0.05: self.y_ind[near]=(self.y_ind[near]+target)/2
            else:
                flat=min(range(len(self.y_ind)),key=lambda i:abs(self.y_ind[i]-0.5))
                self.X_ind[flat]=vector[:]; self.y_ind[flat]=target
    def update_rating(self,vector,rating,path=""):
        self._add_ind(vector,(rating-1)/4.0); self.n_train+=1; self._dirty=True
        if path: self.annotated_paths.setdefault(path,[]).append(rating); self.history.append({"type":"rating","path":path,"rating":rating})
    def update_contrast(self,wv,lv,wp="",lp=""):
        """Bradley-Terry para GP: los targets se escalan con el error actual.
        p_bt = sigmoid(score_w - score_l); grad = 1 - p_bt.
        Target ganador = min(1, score_w + grad*0.5)  (se aleja de 0.5 hacia 1).
        Target perdedor = max(0, score_l - grad*0.5)  (se aleja de 0.5 hacia 0)."""
        sw=self.score(wv); sl=self.score(lv)
        try: p_bt=1.0/(1.0+math.exp(-(sw-sl)))
        except: p_bt=1.0 if sw>sl else 0.0
        grad=1.0-p_bt
        t_win=min(1.0, sw+grad*0.5)
        t_los=max(0.0, sl-grad*0.5)
        self._add_ind(wv,t_win); self._add_ind(lv,t_los)
        self.n_train+=1; self._dirty=True
        if wp: self.history.append({"type":"contrast","winner":wp,"loser":lp})
    def save(self,path):
        json.dump({"model_type":self.MODEL_TYPE,"version":self.VERSION,"gamma":self.gamma,"noise":self.noise,"max_inducing":self.max_inducing,"X_ind":self.X_ind,"y_ind":self.y_ind,"n_train":self.n_train,"history":self.history[-200:],"annotated_paths":self.annotated_paths},open(_ensure_parent(path),"w",encoding="utf-8"),indent=2,ensure_ascii=False)
    @classmethod
    def load(cls,path):
        d=json.load(open(path,encoding="utf-8")); m=cls(d.get("gamma",1.0),d.get("noise",0.1),d.get("max_inducing",150))
        m.X_ind=d.get("X_ind",[]); m.y_ind=d.get("y_ind",[]); m.n_train=d.get("n_train",0)
        m.history=d.get("history",[]); m.annotated_paths=d.get("annotated_paths",{}); m._dirty=True; return m
    def summary(self): return f"  Tipo: gp  |  γ={self.gamma}  noise={self.noise}  |  inducing: {len(self.X_ind)}/{self.max_inducing}  |  ejemplos: {self.n_train}"


# ════════════════════════════════════════════════════════════════════
#  5. SVM — Ranking SVM pairwise SGD
# ════════════════════════════════════════════════════════════════════

class SVMModel(_BaseModel):
    """Ranking SVM pairwise. Aprende orden relativo, no scores absolutos.
    has_builtin_memory=True (escala de salida incompatible con score_with_memory)."""
    MODEL_TYPE="svm"; has_builtin_memory=True
    def __init__(self,n_dims=N_DIMS,C=1.0):
        super().__init__(); self.n_dims=n_dims; self.C=C; self.lr=0.01
        self.weights=[0.0]*n_dims; self.bias=0.0; self._examples=[]
    def _dec(self,v): return sum(self.weights[i]*v[i] for i in range(min(len(self.weights),len(v))))+self.bias
    def score(self,vector):
        d=self._dec(vector)
        try: return 1.0/(1.0+math.exp(-d))
        except: return 0.0 if d<0 else 1.0
    def uncertainty(self,vector): s=self.score(vector); return 1.0-2.0*abs(s-0.5)
    def _sgd_pair(self,xp,xn):
        margin=self._dec(xp)-self._dec(xn)
        if margin>=1.0:
            for i in range(len(self.weights)): self.weights[i]*=(1.0-self.lr*0.001)
            return
        n=min(len(self.weights),len(xp),len(xn))
        for i in range(n): self.weights[i]+=self.lr*self.C*(xp[i]-xn[i]); self.weights[i]*=(1.0-self.lr*0.001)
        self.bias+=self.lr*self.C*0.1
    def update_rating(self,vector,rating,path=""):
        target=(rating-1)/4.0; self._examples.append((vector[:],target))
        for xj,tj in random.sample(self._examples,min(5,len(self._examples))):
            if target>tj+0.1: self._sgd_pair(vector,xj)
            elif tj>target+0.1: self._sgd_pair(xj,vector)
        if len(self._examples)>500: self._examples=random.sample(self._examples,400)
        self.n_train+=1; self.lr=max(0.001,0.01/(1+self.n_train*0.01))
        if path: self.annotated_paths.setdefault(path,[]).append(rating); self.history.append({"type":"rating","path":path,"rating":rating})
    def update_contrast(self,wv,lv,wp="",lp=""):
        self._sgd_pair(wv,lv); self.n_train+=1
        if wp: self.history.append({"type":"contrast","winner":wp,"loser":lp})
    def save(self,path):
        json.dump({"model_type":self.MODEL_TYPE,"version":self.VERSION,"n_dims":self.n_dims,"C":self.C,"weights":self.weights,"bias":self.bias,"lr":self.lr,"n_train":self.n_train,"history":self.history[-200:],"annotated_paths":self.annotated_paths},open(_ensure_parent(path),"w",encoding="utf-8"),indent=2,ensure_ascii=False)
    @classmethod
    def load(cls,path):
        d=json.load(open(path,encoding="utf-8")); m=cls(d.get("n_dims",N_DIMS),d.get("C",1.0))
        m.weights=d.get("weights",[0.0]*m.n_dims); m.bias=d.get("bias",0.0); m.lr=d.get("lr",0.01)
        m.n_train=d.get("n_train",0); m.history=d.get("history",[]); m.annotated_paths=d.get("annotated_paths",{}); return m
    def summary(self): return f"  Tipo: svm (ranking pairwise)  |  C={self.C}  |  ejemplos: {self.n_train}  |  lr={self.lr:.4f}"


# ════════════════════════════════════════════════════════════════════
#  FÁBRICA DE MODELOS
# ════════════════════════════════════════════════════════════════════

_MODEL_CLASSES = {
    "linear": PreferenceModel,
    "neural": NeuralModel,
    "kernel": KernelModel,
    "gp":     GPModel,
    "svm":    SVMModel,
}

_MODEL_EXTENSIONS = {
    "linear": ".linear.json",
    "neural": ".neural.json",
    "kernel": ".kernel.json",
    "gp":     ".gp.json",
    "svm":    ".svm.json",
}

_MODEL_LEGACY_EXT = ".prefs.json"


def _model_path_typed(base: str, model_type: str) -> str:
    ext = _MODEL_EXTENSIONS.get(model_type, ".linear.json")
    for e in list(_MODEL_EXTENSIONS.values()) + [_MODEL_LEGACY_EXT]:
        if base.endswith(e):
            base = base[:-len(e)]
            break
    return base + ext


def load_model(base: str, model_type: str) -> "_BaseModel":
    """Carga el modelo del tipo y base indicados. Soporta legado .prefs.json."""
    path = _model_path_typed(base, model_type)
    cls  = _MODEL_CLASSES.get(model_type, PreferenceModel)
    if not Path(path).exists():
        if model_type == "linear":
            legacy = base + _MODEL_LEGACY_EXT
            if Path(legacy).exists():
                return PreferenceModel.load(legacy)
            # También intentar sin extensión si el usuario pasó la ruta completa
            if Path(base).exists():
                return PreferenceModel.load(base)
        raise FileNotFoundError(f"No se encontró modelo en {path}")
    return cls.load(path)


def save_model(model: "_BaseModel", base: str) -> str:
    """Guarda el modelo en el archivo tipado. Devuelve la ruta."""
    path = _model_path_typed(base, model.MODEL_TYPE)
    model.save(_ensure_parent(path))
    return path



# ════════════════════════════════════════════════════════════════════
#  UTILIDADES
# ════════════════════════════════════════════════════════════════════

def _cosine_similarity(a: list, b: list) -> float:
    dot  = sum(x * y for x, y in zip(a, b))
    na   = math.sqrt(sum(x*x for x in a))
    nb   = math.sqrt(sum(x*x for x in b))
    if na < 1e-9 or nb < 1e-9:
        return 0.0
    return dot / (na * nb)


def _euclidean_distance(a: list, b: list) -> float:
    return math.sqrt(sum((x - y)**2 for x, y in zip(a, b)))


def _load_corpus_npz(path: str) -> tuple:
    """
    Carga un corpus.npz generado por corpus_explorer.
    Devuelve (vectors, paths, meta) como listas Python puras.
    """
    if not HAS_NUMPY:
        raise RuntimeError("numpy no instalado. pip install numpy")

    data    = np.load(path, allow_pickle=True)
    vectors = data["vectors"].tolist()
    paths   = data["paths"].tolist()
    _meta_key = "meta" if "meta" in data else ("metadata" if "metadata" in data else None)
    meta    = data[_meta_key].tolist() if _meta_key else ["{}"] * len(paths)
    return vectors, paths, meta


def _model_path(name: str) -> str:
    """Legado: ruta del archivo .prefs.json. Solo para display y compatibilidad."""
    return f"{name}.prefs.json"


def _model_type_from_args(args) -> str:
    """Extrae el model_type de args, con default 'linear'."""
    return getattr(args, "model_type", None) or "linear"


# Estado global del reproductor (una sola instancia activa a la vez)
_player_proc  = None   # subprocess de timidity, si está activo
_player_stop  = None   # threading.Event para el hilo pygame


def _print_continuation_banner(model, vectors: list, paths: list):
    """
    Muestra el estado del modelo previo y el progreso de cobertura del corpus
    al continuar una sesión de entrenamiento ya iniciada.
    """
    n_corpus    = len(vectors)
    n_annotated = len(model.annotated_paths)
    n_seen      = sum(1 for p in paths if str(p) in model.annotated_paths)
    coverage    = n_seen / n_corpus if n_corpus > 0 else 0.0

    # Distribucion de incertidumbre actual sobre el corpus
    uncertainties = [model.uncertainty(v) for v in vectors]
    high_unc  = sum(1 for u in uncertainties if u > 0.7)   # muy incierto
    med_unc   = sum(1 for u in uncertainties if 0.3 < u <= 0.7)
    low_unc   = sum(1 for u in uncertainties if u <= 0.3)  # bien calibrado

    # Barra de cobertura
    bar_w   = 30
    filled  = int(coverage * bar_w)
    cov_bar = green("█" * filled) + dim("░" * (bar_w - filled))

    print(f"\n  {bold('─ Modelo existente cargado ─')}")
    print(f"  Ejemplos acumulados:   {bold(str(model.n_train))}")
    print(f"  MIDIs distintos vistos:{bold(str(n_seen))} / {n_corpus}")
    print(f"  Cobertura del corpus:  {cov_bar}  {coverage*100:.1f}%")
    print()
    print(f"  {bold('Distribución de incertidumbre sobre el corpus:')}")
    # Mini histograma inline
    unc_total = n_corpus or 1
    hi_bar  = green("▓" * int(high_unc / unc_total * 25))
    med_bar = yellow("▓" * int(med_unc  / unc_total * 25))
    lo_bar  = dim("▓"   * int(low_unc  / unc_total * 25))
    print(f"  Alta  (>0.7)  {hi_bar:<26} {high_unc:>5}  ← prioritarios")
    print(f"  Media (0.3-0.7) {med_bar:<24} {med_unc:>5}")
    print(f"  Baja  (<0.3)  {lo_bar:<26} {low_unc:>5}  ← bien calibrados")
    print()

    if model.n_train > 0:
        print(f"  {bold('Lo que el modelo ha aprendido:')}")
        for name, w in model.top_dimensions(5):
            bar_len = int(abs(w) * 15)
            bar     = ("+" if w >= 0 else "-") * bar_len
            lo, hi  = DIM_LABELS[name]
            direction = hi if w > 0 else lo
            print(f"    {name:<20} {bar:<16} {w:+.3f}  → {dim(direction)}")
        print()

    if high_unc > 0:
        print(f"  {green(str(high_unc))} MIDIs con alta incertidumbre se presentarán primero.")
    else:
        print(f"  {yellow('El modelo cubre bien el corpus.')} "
              f"Las nuevas rondas refinarán casos límite.")
    print()


def _stop_playback():
    """Para cualquier reproducción activa (timidity o pygame)."""
    global _player_proc, _player_stop
    if _player_proc is not None:
        try:
            _player_proc.terminate()
            _player_proc.wait(timeout=2)
        except Exception:
            try:
                _player_proc.kill()
            except Exception:
                pass
        _player_proc = None
    if _player_stop is not None:
        _player_stop.set()
        _player_stop = None
    if HAS_PYGAME:
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass


def _play_midi(midi_path: str, soundfont: str = None, blocking: bool = False):
    """
    Reproduce un MIDI en background.

    Backends (en orden de preferencia):
      1. pygame  — sin proceso externo, control preciso, sin soundfont propio
      2. timidity — mejor calidad con soundfont, proceso externo

    Si blocking=True espera a que termine o a que el usuario pulse Enter.
    Si blocking=False lanza la reproducción y retorna inmediatamente;
    llamar a _stop_playback() para parar.
    """
    global _player_proc, _player_stop

    _stop_playback()   # parar cualquier reproducción anterior

    name = Path(midi_path).name

    # ── Backend 1: pygame ────────────────────────────────────────────
    if HAS_PYGAME and not soundfont:
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            pygame.mixer.music.load(midi_path)
            pygame.mixer.music.play()
            print(f"  {green(chr(9654))} {bold(name)}  "
                  f"{dim('(pygame — Enter para parar)')}", flush=True)

            if blocking:
                _pygame_wait_for_enter()
            else:
                stop_ev = threading.Event()
                _player_stop = stop_ev
                def _pygame_auto_stop():
                    while pygame.mixer.music.get_busy() and not stop_ev.is_set():
                        time.sleep(0.1)
                    if not stop_ev.is_set():
                        stop_ev.set()
                threading.Thread(target=_pygame_auto_stop, daemon=True).start()
            return
        except Exception as e:
            print(yellow(f"  (pygame error: {e} — intentando timidity)"))

    # ── Backend 2: timidity ──────────────────────────────────────────
    cmd = ["timidity"]
    if soundfont:
        cmd += ["-x", f"soundfont {soundfont}"]
    cmd.append(midi_path)

    try:
        proc = subprocess.Popen(cmd,
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
        _player_proc = proc
        print(f"  {green(chr(9654))} {bold(name)}  "
              f"{dim('(timidity — Enter para parar)')}", flush=True)

        if blocking:
            _timidity_wait_for_enter(proc)
            _player_proc = None
        else:
            # Hilo que limpia _player_proc cuando el proceso termina solo
            def _watch():
                global _player_proc
                proc.wait()
                if _player_proc is proc:
                    _player_proc = None
            threading.Thread(target=_watch, daemon=True).start()

    except FileNotFoundError:
        _player_proc = None
        print(yellow("  (timidity no instalado — sin audio)"))
        print(yellow("    sudo apt install timidity   # Ubuntu/Debian"))
        print(yellow("    brew install timidity       # macOS"))
    except Exception as e:
        _player_proc = None
        print(yellow(f"  (error de reproducción: {e})"))


def _pygame_wait_for_enter():
    """Espera Enter o fin de canción con pygame (usa select en Unix)."""
    try:
        import select as _select
        while pygame.mixer.music.get_busy():
            ready, _, _ = _select.select([sys.stdin], [], [], 0.2)
            if ready:
                sys.stdin.readline()
                pygame.mixer.music.stop()
                print(f"  {yellow(chr(9646))} {dim('Parado.')}")
                return
        print(f"  {green(chr(9646))} {dim('Fin.')}")
    except (AttributeError, OSError):
        # Windows fallback
        try:
            import msvcrt
            while pygame.mixer.music.get_busy():
                if msvcrt.kbhit():
                    msvcrt.getwch()
                    pygame.mixer.music.stop()
                    print(f"  {yellow(chr(9646))} {dim('Parado.')}")
                    return
                time.sleep(0.1)
        except ImportError:
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
        print(f"  {green(chr(9646))} {dim('Fin.')}")


def _timidity_wait_for_enter(proc):
    """Espera Enter o fin de proceso timidity con un hilo listener."""
    stop_ev = threading.Event()

    def _listener():
        try:
            input()
        except Exception:
            pass
        stop_ev.set()

    t = threading.Thread(target=_listener, daemon=True)
    t.start()

    while proc.poll() is None and not stop_ev.is_set():
        time.sleep(0.1)

    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()

    if stop_ev.is_set():
        print(f"  {yellow(chr(9646))} {dim('Parado.')}")
    else:
        print(f"  {green(chr(9646))} {dim('Fin.')}")


def _midi_header(info: dict, idx: int = None, label: str = None) -> str:
    name   = Path(str(info.get("path", "?"))).name
    dur    = format_duration(info.get("duration_s", 0))
    bpm    = info.get("tempo_bpm", "?")
    notes  = info.get("n_notes", "?")
    prefix = f"[{label}] " if label else (f"#{idx+1}  " if idx is not None else "")
    _label_1321 = f"{dur} · {bpm}bpm · {notes} notas"
    return f"{prefix}{cyan(name)}  {dim(_label_1321)}"


# ════════════════════════════════════════════════════════════════════
#  MODO TRAIN — rating
# ════════════════════════════════════════════════════════════════════

def cmd_train_rating(args, model: PreferenceModel, vectors, paths, meta):
    """Sesión de entrenamiento por rating (1-5)."""

    indices  = list(range(len(vectors)))
    rounds   = args.rounds
    played   = set()
    soundfont = getattr(args, "soundfont", None)

    print(f"\n{bold('MODO RATING')}  — puntúa cada MIDI de 1 a 5")
    print(dim("  1=no me gusta nada · 3=indiferente · 5=me encanta"))
    print(dim("  p=reproducir · x=parar · s=saltar · q=guardar y salir"))
    print()

    done = 0
    while done < rounds:
        available = [i for i in indices if i not in played]
        if not available:
            print(yellow("  Has puntuado todos los MIDIs disponibles."))
            break

        idx  = model.select_rating_candidate(
            vectors, available, paths=paths,
            corpus_vectors=vectors,
            strategy=getattr(args, "strategy", "uncertainty"))
        played.add(idx)

        v    = vectors[idx]
        path = str(paths[idx])
        try:
            m = json.loads(str(meta[idx]))
        except Exception:
            m = {}
        m["path"]       = path
        m["duration_s"] = m.get("duration_s", 0)
        m["tempo_bpm"]  = m.get("tempo_bpm", "?")
        m["n_notes"]    = m.get("n_notes", "?")

        n_seen_this = model.annotation_count(path)
        seen_tag    = dim(f"  [visto {n_seen_this}x]") if n_seen_this > 0 else ""
        print(f"  {'─'*52}")
        print(f"  {_midi_header(m, done)}{seen_tag}")
        print(f"  {dim(describe_vector(v))}")
        if model.n_train > 0:
            pred = model.score(v)
            unc  = model.uncertainty(v)
            unc_label = green("alta") if unc > 0.7 else (yellow("media") if unc > 0.3 else dim("baja"))
            _label_1371 = f"Predicción: {pred:.2f}  ·  incertidumbre: {unc:.2f} ("
            print(f"  {dim(_label_1371)}{unc_label}{dim(')')}")
        print()

        # Reproducción automática en background (salvo --no-autoplay)
        if not getattr(args, 'no_autoplay', False):
            _play_midi(path, soundfont=soundfont, blocking=False)

        # Bucle de input — la música sigue sonando mientras el usuario decide
        rating = None
        while rating is None:
            raw = input("  Puntuación [1-5 / p=repetir / x=parar / s=saltar / q=salir]: ").strip().lower()
            if raw in ("q", "quit", "exit"):
                _stop_playback()
                return "quit"
            elif raw in ("p", "play", "r"):
                _play_midi(path, soundfont=soundfont, blocking=False)
            elif raw in ("x", "stop", "0"):
                _stop_playback()
            elif raw in ("s", "skip"):
                rating = "skip"
            elif raw.isdigit() and 1 <= int(raw) <= 5:
                rating = int(raw)
                _stop_playback()
            else:
                print(red("  Introduce un número del 1 al 5."))

        if rating == "skip":
            print(dim("  Saltado.\n"))
            continue

        model.update_rating(v, rating, path=path)
        model.history.append({"type": "rating", "path": path, "rating": rating})

        stars = "★" * rating + "☆" * (5 - rating)
        print(green(f"  {stars}  Anotado.\n"))
        done += 1

        if done % 5 == 0 and done > 0:
            print(f"  {bold('─ Estado del modelo ─')}")
            print(model.summary())
            print()

    _stop_playback()
    return "done"


# ════════════════════════════════════════════════════════════════════
#  MODO TRAIN — contraste
# ════════════════════════════════════════════════════════════════════

def cmd_train_contrast(args, model: PreferenceModel, vectors, paths, meta):
    """Sesión de entrenamiento por contraste (A vs B)."""

    indices = list(range(len(vectors)))
    rounds  = args.rounds
    seen_pairs: set = set()

    print(f"\n{bold('MODO CONTRASTE')}  — elige el MIDI que prefieres")
    print(dim("  a=elige A · b=elige B · e=empate · s=saltar · q=guardar y salir"))
    print(dim("  pa=reproducir A · pb=reproducir B · x=parar"))
    print()

    done = 0
    while done < rounds:
        # Selección activa del par
        try:
            pair = model.select_contrast_pair(
                vectors, indices,
                n_candidates=getattr(args, "candidate_pool", 50),
                paths=paths,
                corpus_vectors=vectors,
                strategy=getattr(args, "strategy", "uncertainty")
            )
        except ValueError:
            print(yellow("  Corpus demasiado pequeño."))
            break

        if pair is None:
            break

        a_idx, b_idx = pair
        pair_key = (min(a_idx, b_idx), max(a_idx, b_idx))
        if pair_key in seen_pairs:
            # Intentar un par aleatorio
            alt = random.sample(indices, min(50, len(indices)))
            try:
                pair = model.select_contrast_pair(vectors, alt,
                    n_candidates=getattr(args, "candidate_pool", 50),
                    paths=paths,
                    corpus_vectors=vectors,
                    strategy=getattr(args, "strategy", "uncertainty"))
                a_idx, b_idx = pair
                pair_key = (min(a_idx, b_idx), max(a_idx, b_idx))
            except Exception:
                pass

        seen_pairs.add(pair_key)

        va   = vectors[a_idx]
        vb   = vectors[b_idx]
        path_a = str(paths[a_idx])
        path_b = str(paths[b_idx])

        def get_meta(idx, path):
            try:
                m = json.loads(str(meta[idx]))
            except Exception:
                m = {}
            m.setdefault("path", path)
            m.setdefault("duration_s", 0)
            m.setdefault("tempo_bpm", "?")
            m.setdefault("n_notes", "?")
            return m

        ma = get_meta(a_idx, path_a)
        mb = get_meta(b_idx, path_b)

        seen_a = model.annotation_count(path_a)
        seen_b = model.annotation_count(path_b)
        tag_a  = dim(f"  [{seen_a}x]") if seen_a > 0 else ""
        tag_b  = dim(f"  [{seen_b}x]") if seen_b > 0 else ""
        print(f"  {'─'*52}  Ronda {done+1}/{rounds}")
        print(f"  {bold('A')}  {_midi_header(ma)}{tag_a}")
        print(f"     {dim(describe_vector(va))}")
        print(f"  {bold('B')}  {_midi_header(mb)}{tag_b}")
        print(f"     {dim(describe_vector(vb))}")

        soundfont = getattr(args, "soundfont", None)

        if model.n_train > 0:
            sa  = model.score(va)
            sb  = model.score(vb)
            ua  = model.uncertainty(va)
            ub  = model.uncertainty(vb)
            _label_1501 = f"Predicción: A={sa:.2f} (unc={ua:.2f})  B={sb:.2f} (unc={ub:.2f})"
            print(f"  {dim(_label_1501)}")
        print()

        # Reproducción automática de A en background (salvo --no-autoplay)
        if not getattr(args, 'no_autoplay', False):
            _play_midi(path_a, soundfont=soundfont, blocking=False)

        choice = None
        while choice is None:
            raw = input("  ¿Qué prefieres? [a/b / pa/pb=reproducir / x=parar / e=empate / s=saltar / q=salir]: ").strip().lower()
            if raw in ("q", "quit"):
                _stop_playback()
                return "quit"
            elif raw in ("pa", "ra"):
                _play_midi(path_a, soundfont=soundfont, blocking=False)
            elif raw in ("pb", "rb"):
                _play_midi(path_b, soundfont=soundfont, blocking=False)
            elif raw in ("x", "stop"):
                _stop_playback()
            elif raw in ("s", "skip"):
                choice = "skip"
            elif raw in ("a",):
                choice = "a"
                _stop_playback()
            elif raw in ("b",):
                choice = "b"
                _stop_playback()
            elif raw in ("e", "empate", "="):
                choice = "tie"
                _stop_playback()
            else:
                print(red("  Introduce a, b, e, pa, pb o s."))

        if choice == "skip":
            print(dim("  Saltado.\n"))
            continue

        if choice == "a":
            model.update_contrast(va, vb, winner_path=path_a, loser_path=path_b)
            model.history.append({"type": "contrast", "winner": path_a, "loser": path_b})
            print(green(f"  ✓ A elegida.\n"))
        elif choice == "b":
            model.update_contrast(vb, va, winner_path=path_b, loser_path=path_a)
            model.history.append({"type": "contrast", "winner": path_b, "loser": path_a})
            print(green(f"  ✓ B elegida.\n"))
        elif choice == "tie":
            # Empate: ambas actualizaciones con gradient pequeño
            model.lr *= 0.3
            model.update_contrast(va, vb)
            model.update_contrast(vb, va)
            model.lr /= 0.3
            model.history.append({"type": "contrast", "winner": None,
                                   "paths": [path_a, path_b]})
            print(dim(f"  Empate anotado.\n"))

        done += 1

        if done % 5 == 0 and done > 0:
            print(f"  {bold('─ Estado del modelo ─')}")
            print(model.summary())
            print()

    _stop_playback()
    return "done"


# ════════════════════════════════════════════════════════════════════
#  CONTEXTO DE EVALUACIÓN
# ════════════════════════════════════════════════════════════════════

def _percentile(score: float, reference_scores: list) -> float:
    """Percentil de score dentro de reference_scores (0-100)."""
    if not reference_scores:
        return 50.0
    below = sum(1 for s in reference_scores if s < score)
    return below / len(reference_scores) * 100.0


def _dimension_narrative(vector: list, weights: list) -> tuple:
    """
    Devuelve (favor, contra) como strings con las dimensiones que más
    empujan el score hacia arriba y hacia abajo, en lenguaje natural.
    """
    contribs = [(DIM_NAMES[i], weights[i] * vector[i], weights[i], vector[i])
                for i in range(N_DIMS)]
    contribs.sort(key=lambda x: x[1], reverse=True)

    favor  = []
    contra = []
    for name, contrib, w, val in contribs:
        lo, hi = DIM_LABELS[name]
        label  = hi if val > 0.5 else lo
        if contrib > 0.005:
            favor.append(label)
        elif contrib < -0.005:
            contra.append(label)

    favor_str  = ", ".join(favor[:3])  if favor  else "—"
    contra_str = ", ".join(contra[:3]) if contra else "—"
    return favor_str, contra_str


def _nearest_annotated(vector: list, model, n: int = 3) -> list:
    """
    Devuelve los n MIDIs más cercanos en el historial con rating conocido,
    como lista de (nombre, rating, distancia).
    """
    candidates = []
    seen_paths = set()
    for entry in reversed(model.history):
        if entry.get("type") != "rating" or "rating" not in entry:
            continue
        path = entry["path"]
        if path in seen_paths:
            continue
        seen_paths.add(path)
        ann = model.annotated_paths.get(path, [])
        # media de ratings anotados (pueden ser múltiples)
        ratings = [x for x in ann if isinstance(x, int)]
        if not ratings:
            ratings = [entry["rating"]]
        avg_rating = sum(ratings) / len(ratings)
        # No tenemos el vector guardado, usamos el score del modelo como proxy
        # de similitud si no podemos calcular distancia real
        candidates.append((path, avg_rating))

    # Sin vectores de referencia almacenados, devolvemos los más recientes
    # con rating extremo primero (más informativos)
    candidates.sort(key=lambda x: abs(x[1] - 2.5), reverse=True)
    result = []
    for path, avg_rating in candidates[:n]:
        result.append((Path(path).name, avg_rating))
    return result


def _nearest_annotated_with_vectors(vector: list, model,
                                     corpus_vectors: list,
                                     corpus_paths: list,
                                     n: int = 3) -> list:
    """
    Versión que usa vectores reales del corpus para calcular distancia.
    Devuelve (nombre, rating_medio, distancia) de los n más cercanos anotados.
    """
    annotated_indices = []
    for i, path in enumerate(corpus_paths):
        p = str(path)
        if p in model.annotated_paths:
            ann = model.annotated_paths[p]
            ratings = [x for x in ann if isinstance(x, int)]
            if ratings:
                avg_rating_raw = sum(ratings) / len(ratings)  # escala 1-5
                avg_rating_norm = (avg_rating_raw - 1) / 4.0  # normalizar a 0-1
                annotated_indices.append((i, avg_rating_norm))

    if not annotated_indices:
        return []

    scored = []
    for i, avg_r in annotated_indices:
        if avg_r is None:
            continue
        dist = _euclidean_distance(vector, corpus_vectors[i])
        # Convertir rating normalizado (0-1) a escala 1-5 para las estrellas
        # avg_r ya está en escala 1-5 (se guarda el rating original)
        scored.append((Path(str(corpus_paths[i])).name, avg_r, dist))

    scored.sort(key=lambda x: x[2])
    return scored[:n]


def _corpus_histogram(score: float, all_scores: list, width: int = 40) -> str:
    """
    Histograma ASCII de la distribución de scores del corpus con la
    posición del MIDI evaluado marcada con ▲.
    """
    if not all_scores:
        return ""

    n_bins  = 10
    bin_w   = 1.0 / n_bins
    counts  = [0] * n_bins
    for s in all_scores:
        b = min(int(s / bin_w), n_bins - 1)
        counts[b] += 1

    max_count = max(counts) or 1
    bar_h     = 6   # altura en líneas

    # Construir columnas verticales
    cols = []
    for c in counts:
        filled = round(c / max_count * bar_h)
        col = ["█"] * filled + [" "] * (bar_h - filled)
        col.reverse()   # índice 0 = arriba
        cols.append(col)

    # Marcador de posición
    marker_bin = min(int(score / bin_w), n_bins - 1)

    lines = []
    for row in range(bar_h):
        line = "  "
        for b, col in enumerate(cols):
            ch = col[row]
            if b == marker_bin and row == bar_h - 1:
                line += cyan("▓▓▓▓")
            else:
                line += (dim("░░░░") if ch == " " else "████")
        lines.append(line)

    # Eje X con labels cada 2 bins (4 chars por bin)
    axis = "  "
    for b in range(n_bins):
        if b % 2 == 0:
            label = f"{b/n_bins:.1f}"
            axis += label + " " * (4 - len(label))
        else:
            axis += "    "

    # Marcador ▲ centrado en el bin
    marker_pos = 2 + marker_bin * 4 + 1
    marker_row = " " * marker_pos + cyan("▲")

    lines.append(axis)
    lines.append(marker_row)
    return "\n".join(lines)


# ════════════════════════════════════════════════════════════════════
#  MODO EVAL
# ════════════════════════════════════════════════════════════════════

def cmd_eval(args):
    """Evalúa uno o varios MIDIs con el modelo entrenado."""

    model_file = _model_path(args.model)


    model_type = _model_type_from_args(args)
    if not Path(model_file).exists():
        print(red(f"Modelo no encontrado: {model_file}"))
        print(yellow("  Entrena primero con:  python preference_trainer.py train <corpus.npz>"))
        sys.exit(1)

    model = load_model(args.model, model_type)
    print(f"\n{bold('PREFERENCE TRAINER — EVAL')}")
    print(f"  Modelo: {cyan(model_file)}  [{dim(model.MODEL_TYPE)}]  ({model.n_train} ejemplos de entrenamiento)")

    # ── Cargar corpus de referencia (para percentil, vecinos, histograma) ──
    corpus_vectors = []
    corpus_paths   = []
    if getattr(args, "corpus", None):
        corpus_path = args.corpus
        if Path(corpus_path).exists():
            try:
                corpus_vectors, corpus_paths, _ = _load_corpus_npz(corpus_path)
                print(f"  Corpus: {cyan(corpus_path)}  ({len(corpus_vectors):,} MIDIs)")
            except Exception as e:
                print(yellow(f"  No se pudo cargar corpus: {e}"))
        else:
            print(yellow(f"  Corpus no encontrado: {corpus_path}"))

    # Calibrar el modelo sobre los vectores disponibles para expandir el rango
    if corpus_vectors:
        model.calibrate(corpus_vectors)
    elif model.n_train >= 5:
        # Sin corpus, calibrar sobre los vectores del historial si hay suficientes
        hist_vecs = []
        seen = set()
        for entry in model.history:
            p = entry.get("path","")
            if p and p not in seen:
                seen.add(p)
                r = vectorize_midi(p)
                if r["vector"]:
                    hist_vecs.append(r["vector"])
        if hist_vecs:
            model.calibrate(hist_vecs)

    # Scores del corpus completo para histograma y percentil
    corpus_scores = [model.score(v) for v in corpus_vectors] if corpus_vectors else []

    # Scores del historial anotado para percentil alternativo
    annotated_dist = model.annotated_distribution()   # [(path, rating_norm)]
    annotated_scores_norm = [r for _, r in annotated_dist]

    # Detect if model was trained with extended features
    _n_weights = len(model.weights) if model.weights else 10
    _use_extended_eval = _n_weights == 20
    _use_melodic_eval  = _n_weights == 16

    # ── Cargar vectores de afinidad ──────────────────────────────────
    affinity_vectors = []
    if args.affinity:
        affinity_dir = Path(args.affinity)
        if not affinity_dir.exists():
            print(red(f"  Carpeta de afinidad no encontrada: {affinity_dir}"))
        else:
            aff_files = (list(affinity_dir.rglob("*.mid")) +
                         list(affinity_dir.rglob("*.midi")))
            print(f"  Cargando {len(aff_files)} obras afines de {cyan(str(affinity_dir))}...")
            for mf in aff_files:
                res = vectorize_midi(str(mf),
                                     extended=_use_extended_eval,
                                     melodic=_use_melodic_eval)
                if res["vector"]:
                    affinity_vectors.append(res["vector"])
            print(f"  {green(str(len(affinity_vectors)))} vectorizadas correctamente.")

    weight_pref = 1.0 - args.weight if affinity_vectors else 1.0
    weight_aff  = args.weight        if affinity_vectors else 0.0

    # ── Recoger archivos a evaluar ───────────────────────────────────
    midi_files = []
    for pattern in args.midi:
        p = Path(pattern)
        if p.is_dir():
            midi_files += list(p.rglob("*.mid")) + list(p.rglob("*.midi"))
        elif p.exists():
            midi_files.append(p)
        else:
            import glob
            midi_files += [Path(f) for f in glob.glob(pattern)]

    if not midi_files:
        print(red("  No se encontraron archivos MIDI."))
        sys.exit(1)

    results = []
    print(f"\n{'─'*60}")

    for mf in midi_files:
        res = vectorize_midi(str(mf),
                             extended=_use_extended_eval,
                             melodic=_use_melodic_eval)
        if res["error"]:
            err_msg = res["error"]
            print("  " + yellow("!") + f"  {mf.name}  " + dim("error: " + err_msg))
            continue

        v          = res["vector"]
        path_str   = str(mf)
        pref_score = model.score_with_memory(v, path_str)

        aff_score = 0.0
        if affinity_vectors:
            sims      = [_cosine_similarity(v, av) for av in affinity_vectors]
            aff_score = (sum(sims) / len(sims) + 1) / 2

        final_score = (weight_pref * pref_score + weight_aff * aff_score
                       if affinity_vectors else pref_score)

        # ── Contexto ────────────────────────────────────────────────
        # Percentil: sobre corpus si disponible, si no sobre anotaciones
        if corpus_scores:
            pct = _percentile(final_score, corpus_scores)
            pct_label = f"percentil {pct:.0f}% del corpus ({len(corpus_scores):,} MIDIs)"
        elif annotated_scores_norm:
            # Convertir ratings normalizados a scores del modelo aproximados
            pct = _percentile(final_score, annotated_scores_norm)
            pct_label = f"percentil {pct:.0f}% de lo anotado ({len(annotated_scores_norm)} ejemplos)"
        else:
            pct        = None
            pct_label  = "sin referencia (entrena más rondas)"

        # Vecinos anotados
        if corpus_vectors:
            neighbors = _nearest_annotated_with_vectors(
                v, model, corpus_vectors, corpus_paths, n=3)
        else:
            neighbors = _nearest_annotated(v, model, n=3)

        # Desglose dimensional narrativo
        favor_str, contra_str = _dimension_narrative(v, model.weights)

        results.append({
            "path":        str(mf),
            "name":        mf.name,
            "pref_score":  pref_score,
            "aff_score":   aff_score,
            "final_score": final_score,
            "vector":      v,
            "meta":        res,
            "pct":         pct,
            "pct_label":   pct_label,
            "neighbors":   neighbors,
            "favor":       favor_str,
            "contra":      contra_str,
        })

    if not results:
        print(red("  Ningún MIDI pudo ser procesado."))
        sys.exit(1)

    results.sort(key=lambda r: r["final_score"], reverse=True)

    # ── Salida ───────────────────────────────────────────────────────

    print(f"\n{'═'*60}")
    if affinity_vectors:
        print(f"  {bold('RESULTADOS')}  "
              f"[pref×{weight_pref:.2f} + afinidad×{weight_aff:.2f}]")
    else:
        print(f"  {bold('RESULTADOS')}  [solo preferencia]")
    print(f"{'═'*60}\n")

    for rank, r in enumerate(results, 1):
        score_color = green if r["final_score"] >= 0.65 else (
            yellow if r["final_score"] >= 0.40 else red)
        dur  = format_duration(r["meta"]["duration_s"])
        bpm  = r["meta"]["tempo_bpm"]

        # ── Historial de anotaciones para esta pieza ─────────────────
        prior_ratings = model.annotated_paths.get(r["path"], [])
        prior_numeric = [x for x in prior_ratings if isinstance(x, (int, float))]

        print(f"  {rank:>2}. {bold(cyan(r['name']))}")
        _label_1909 = f"{dur} · {bpm} bpm"
        print(f"      {dim(_label_1909)}")
        if prior_numeric:
            avg_prior = sum(prior_numeric) / len(prior_numeric)
            stars_str = "★" * round(avg_prior) + "☆" * (5 - round(avg_prior))
            n_mem = len(prior_numeric)
            w_mem = n_mem / (n_mem + 5.0)
            prior_tag = (yellow(f"  ★ anotada {n_mem}x  "
                                f"(media {avg_prior:.1f}/5  {stars_str})  "
                                f"memoria={w_mem*100:.0f}%"))
            print(f"      {prior_tag}")
        print()

        # ── Score principal ──────────────────────────────────────────
        bar_len = int(r["final_score"] * 30)
        bar     = "█" * bar_len + "░" * (30 - bar_len)
        fs      = f"{r['final_score']:.4f}"
        print(f"      {score_color(bar)}  {bold(fs)}")

        if affinity_vectors:
            _aff_label = f"preferencia={r['pref_score']:.4f}  ·  afinidad={r['aff_score']:.4f}"
            print(f"      {dim(_aff_label)}")
        print()

        # ── Percentil ────────────────────────────────────────────────
        if r["pct"] is not None:
            pct_bar_w = 30
            pct_filled = int(r["pct"] / 100 * pct_bar_w)
            pct_bar    = dim("─" * pct_filled) + cyan("┼") + dim("─" * (pct_bar_w - pct_filled))
            pct_color  = green if r["pct"] >= 70 else (yellow if r["pct"] >= 40 else red)
            _label_1929 = f'{r["pct"]:.0f}%'
            print(f"      {dim('Posición:')}  {pct_bar}  {pct_color(_label_1929)}")
            print(f"      {dim(r['pct_label'])}")
            print()

        # ── Histograma del corpus ─────────────────────────────────────
        if corpus_scores:
            print(f"      {dim('Distribución del corpus (▲ = esta pieza):')}")
            hist = _corpus_histogram(r["final_score"], corpus_scores)
            for line in hist.split("\n"):
                print(f"    {line}")
            print()

        # ── Dimensiones que favorecen / perjudican ────────────────────
        print(f"      {green('+ favorece:')}  {r['favor']}")
        print(f"      {red('- perjudica:')} {r['contra']}")
        print()

        # ── Vecinos anotados ─────────────────────────────────────────
        if r["neighbors"]:
            print(f"      {dim('Más parecido a lo que ya anotaste:')}")
            for nb in r["neighbors"]:
                if len(nb) == 3:
                    nb_name, nb_rating, nb_dist = nb
                    stars = "★" * round(nb_rating * 4 + 1) + "☆" * (5 - round(nb_rating * 4 + 1))
                    _label_1953 = f"(dist={nb_dist:.3f})"
                    print(f"        {stars}  {dim(nb_name)}  {dim(_label_1953)}")
                else:
                    nb_name, nb_rating = nb
                    n_stars = max(1, min(5, round(nb_rating * 4 + 1)))
                    stars = "★" * n_stars + "☆" * (5 - n_stars)
                    print(f"        {stars}  {dim(nb_name)}")
            print()

        # ── Desglose dimensional completo (--verbose) ─────────────────
        if args.verbose:
            print(f"      {dim('─ Detalle de dimensiones:')}")
            dims_sorted = sorted(range(N_DIMS),
                                 key=lambda i: abs(model.weights[i] * r["vector"][i]),
                                 reverse=True)
            for i in dims_sorted:
                val     = r["vector"][i]
                w       = model.weights[i]
                lo, hi  = DIM_LABELS[i] if isinstance(DIM_LABELS, list) else DIM_LABELS[DIM_NAMES[i]]
                bar2    = "▮" * int(val * 10) + "▯" * (10 - int(val * 10))
                contrib = w * val
                sign    = "+" if contrib >= 0 else ""
                c_color = green if contrib > 0.01 else (red if contrib < -0.01 else dim)
                _label_1976 = f"{sign}{contrib:.4f}"
                print(f"        {DIM_NAMES[i]:<20} {bar2}  {val:.2f}  "
                      f"{c_color(_label_1976)}")
            print()

        print(f"  {dim('─'*56)}")
        print()

    # ── Resumen numérico (formato mínimo garantizado) ─────────────────
    print(f"  {bold('RESUMEN NUMÉRICO')}")
    print()
    for r in results:
        pct_str = f"  pct={r['pct']:.0f}%" if r["pct"] is not None else ""
        if affinity_vectors:
            print(f"  {r['name']:<40}  score={r['final_score']:.4f}  "
                  f"pref={r['pref_score']:.4f}  aff={r['aff_score']:.4f}{pct_str}")
        else:
            print(f"  {r['name']:<40}  score={r['final_score']:.4f}{pct_str}")
    print()

    # JSON machine-readable
    if getattr(args, "json_out", False):
        output = []
        for r in results:
            entry = {
                "path":        r["path"],
                "score":       round(r["final_score"], 4),
                "pref_score":  round(r["pref_score"], 4),
                "percentile":  round(r["pct"], 1) if r["pct"] is not None else None,
                "favor":       r["favor"],
                "contra":      r["contra"],
                "vector":      [round(x, 4) for x in r["vector"]],
            }
            if affinity_vectors:
                entry["aff_score"] = round(r["aff_score"], 4)
            output.append(entry)
        print(json.dumps(output, indent=2, ensure_ascii=False))


# ════════════════════════════════════════════════════════════════════
#  COMANDO TRAIN (orquestador)
# ════════════════════════════════════════════════════════════════════

def cmd_train(args):
    """Orquesta la sesión de entrenamiento."""

    if not HAS_MIDO:
        print(red("Error: mido no instalado.  pip install mido"))
        sys.exit(1)
    if not HAS_NUMPY:
        print(red("Error: numpy no instalado.  pip install numpy"))
        sys.exit(1)

    corpus_path = args.corpus
    if not Path(corpus_path).exists():
        print(red(f"Corpus no encontrado: {corpus_path}"))
        sys.exit(1)

    print(f"\n{bold('PREFERENCE TRAINER — TRAIN')}")
    print(f"  Corpus: {cyan(corpus_path)}")

    # Cargar corpus
    print(f"  Cargando índice...", end=" ", flush=True)
    try:
        vectors, paths, meta = _load_corpus_npz(corpus_path)
    except Exception as e:
        print(red(f"\n  Error cargando corpus: {e}"))
        sys.exit(1)

    valid = [(v, p, m) for v, p, m in zip(vectors, paths, meta) if v is not None]
    if not valid:
        print(red("  El corpus no contiene vectores válidos."))
        sys.exit(1)

    vectors, paths, meta = zip(*valid)
    vectors = list(vectors)
    paths   = list(paths)
    meta    = list(meta)
    print(green(f"{len(vectors)} MIDIs"))

    # Cargar o crear modelo
    model_file = _model_path(args.model)

    model_type = _model_type_from_args(args)
    typed_path = _model_path_typed(args.model, model_type)
    if Path(typed_path).exists() or (model_type == "linear" and Path(model_file).exists()):
        model = load_model(args.model, model_type)
        _print_continuation_banner(model, vectors, paths)
    else:
        model = _MODEL_CLASSES.get(model_type, PreferenceModel)()
        print(f"  {yellow('Modelo nuevo')} ({cyan(model_type)}) — se guardará en {cyan(typed_path)}")
        print()

    # Sesión de entrenamiento
    strategy = getattr(args, "strategy", "uncertainty")
    strategy_descriptions = {
        "uncertainty": "incertidumbre × novedad",
        "density":     "incertidumbre × densidad × novedad",
        "emc":         "expected model change × novedad",
        "eer":         "expected error reduction (lenta)",
        "qbc":         "query by committee (K=5)",
        "hybrid":      "hybrid: uncertainty + density + emc",
    }
    print(f"  Estrategia: {cyan(strategy)}  {dim('— ' + strategy_descriptions.get(strategy, ''))}")
    print()
    try:
        if args.mode == "contrast":
            result = cmd_train_contrast(args, model, vectors, paths, meta)
        else:
            result = cmd_train_rating(args, model, vectors, paths, meta)
    except KeyboardInterrupt:
        result = "quit"

    # Calibrar y guardar modelo
    model.calibrate(vectors)
    save_model(model, args.model)
    print(f"\n{green('✓')} Modelo guardado: {cyan(model_file)}")
    print(f"  Total de ejemplos de entrenamiento: {bold(str(model.n_train))}")
    print()
    print(f"  {bold('─ Estado final del modelo ─')}")
    print(model.summary())
    print()
    print(f"  Para evaluar un MIDI:")
    _label_2083 = f"python preference_trainer.py eval tu_pieza.mid --model {args.model}"
    print(f"    {dim(_label_2083)}")


# ════════════════════════════════════════════════════════════════════
#  COMANDO INFO — inspeccionar el modelo
# ════════════════════════════════════════════════════════════════════



# ════════════════════════════════════════════════════════════════════
#  COMANDO SET — anotar preferencia directamente
# ════════════════════════════════════════════════════════════════════

def cmd_set(args):
    """Asigna un score de preferencia directamente a uno o varios MIDIs."""

    model_file = _model_path(args.model)


    model_type = _model_type_from_args(args)
    if not Path(model_file).exists():
        print(red(f"Modelo no encontrado: {model_file}"))
        print(yellow(f"  Crea uno primero con: python preference_trainer.py train <corpus.npz>"))
        sys.exit(1)

    model = load_model(args.model, model_type)

    # Recoger archivos
    midi_files = []
    for pattern in args.midi:
        p = Path(pattern)
        if p.is_dir():
            midi_files += sorted(p.rglob("*.mid")) + sorted(p.rglob("*.midi"))
        elif p.exists():
            midi_files.append(p)
        else:
            import glob as _glob
            midi_files += [Path(f) for f in sorted(_glob.glob(pattern))]

    if not midi_files:
        print(red("  No se encontraron archivos MIDI."))
        sys.exit(1)

    rating  = args.score
    reps    = getattr(args, 'repetitions', 10)
    _n_w_set = len(model.weights) if model.weights else 10
    use_ext  = _n_w_set == 20
    use_mel  = _n_w_set == 16

    print(f"\n{bold('PREFERENCE TRAINER — SET')}")
    print(f"  Modelo: {cyan(model_file)}  [{dim(model.MODEL_TYPE)}]  ({model.n_train} ejemplos previos)")
    print(f"  Score:  {'★' * rating + '☆' * (5 - rating)}  ({rating}/5)")
    print()

    updated = 0
    for mf in midi_files:
        res = vectorize_midi(str(mf), extended=use_ext, melodic=use_mel)
        if res["error"]:
            print(f"  {yellow('!')} {mf.name}  {dim('error: ' + res['error'])}")
            continue

        v    = res["vector"]
        path = str(mf)

        pred_before = model.score(v)
        n_prev      = model.annotation_count(path)

        # Si la pieza tiene anotaciones previas, escalar las repeticiones
        # para que la corrección tenga suficiente peso frente al historial.
        # Fórmula: reps_efectivas = max(reps, n_prev + 1)
        # Además elevar lr temporalmente para que la corrección del usuario
        # no quede diluida por el lr decaído tras muchos ejemplos.
        effective_reps = max(reps, n_prev + 1) if n_prev > 0 else reps
        saved_lr = model.lr
        if n_prev > 0:
            model.lr = min(0.15, saved_lr * (1 + n_prev * 0.1))
            override_tag = dim(f"  (lr={model.lr:.3f}, reps={effective_reps} por {n_prev} previas)")
        else:
            override_tag = ""

        for _ in range(effective_reps):
            model.update_rating(v, rating, path=path)
        model.lr = saved_lr  # restaurar lr original
        model.history.append({"type": "rating", "path": path, "rating": rating})

        pred_after = model.score(v)
        delta      = pred_after - pred_before
        delta_str  = (green(f"+{delta:.3f}") if delta > 0.001
                      else red(f"{delta:.3f}") if delta < -0.001
                      else dim(f"{delta:+.3f}"))

        seen_tag = dim(f"  (era {n_prev}x anotado)") if n_prev > 0 else ""
        print(f"  {green('✓')} {cyan(mf.name)}{seen_tag}")
        print(f"     score: {pred_before:.3f} → {pred_after:.3f}  Δ{delta_str}{override_tag}")
        updated += 1

    if not updated:
        print(red("  Ningún MIDI pudo ser procesado."))
        sys.exit(1)

    save_model(model, args.model)
    print(f"\n  {green('✓')} {updated} anotación(es) guardada(s) en {cyan(model_file)}")
    print(f"  Total ejemplos: {bold(str(model.n_train))}")

# ════════════════════════════════════════════════════════════════════
#  COMANDO VALIDATE — validación cruzada
# ════════════════════════════════════════════════════════════════════

def cmd_validate(args):
    """
    Validación cruzada k-fold sobre el historial de anotaciones.

    Mide qué tan bien generaliza el modelo aprendido:
    - MAE (error absoluto medio en predicción de rating)
    - Accuracy de ranking (pares ordenados correctamente)
    - Correlación de Spearman entre predicciones y ratings reales
    """
    model_file = _model_path(args.model)

    model_type = _model_type_from_args(args)
    if not Path(model_file).exists():
        print(red(f"Modelo no encontrado: {model_file}"))
        sys.exit(1)

    model_ref = load_model(args.model, model_type)

    # Recoger ejemplos de rating con vectores disponibles
    corpus_vectors = {}
    if getattr(args, "corpus", None) and Path(args.corpus).exists():
        vecs, paths, _ = _load_corpus_npz(args.corpus)
        for v, p in zip(vecs, paths):
            corpus_vectors[str(p)] = v

    # Construir dataset desde historial
    dataset = []
    seen = set()
    for entry in model_ref.history:
        if entry.get("type") != "rating" or "rating" not in entry:
            continue
        path = entry["path"]
        if path in seen:
            continue
        seen.add(path)
        ratings = [x for x in model_ref.annotated_paths.get(path, [])
                   if isinstance(x, int)]
        if not ratings:
            ratings = [entry["rating"]]
        avg_r = sum(ratings) / len(ratings)

        # Obtener vector
        if path in corpus_vectors:
            v = corpus_vectors[path]
        else:
            res = vectorize_midi(path,
                extended=len(model_ref.weights) > 10)
            if res["error"] or not res["vector"]:
                continue
            v = res["vector"]

        dataset.append({"path": path, "vector": v, "rating": avg_r})

    n = len(dataset)
    if n < 4:
        print(red(f"  Historial insuficiente: {n} ejemplos con vector disponible."))
        print(yellow("  Se necesitan al menos 4. Entrena más rondas."))
        sys.exit(1)

    print(f"\n{bold('PREFERENCE TRAINER — VALIDATE')}")
    print(f"  Modelo:   {cyan(model_file)}  [{dim(model.MODEL_TYPE)}]")
    print(f"  Ejemplos: {n}  (con vector recuperable)")

    k = min(args.folds, n)
    print(f"  Folds:    {k}-fold\n")

    # K-fold estratificado (ordenar por rating y distribuir)
    dataset_sorted = sorted(dataset, key=lambda x: x["rating"])
    folds = [[] for _ in range(k)]
    for i, item in enumerate(dataset_sorted):
        folds[i % k].append(item)

    fold_results = []
    all_pred, all_true = [], []

    for fold_i in range(k):
        test  = folds[fold_i]
        train = [item for j, fold in enumerate(folds) if j != fold_i for item in fold]

        if not train:
            continue

        # Entrenar modelo limpio en este fold
        m = _MODEL_CLASSES.get(model_type, PreferenceModel)()
        if hasattr(m, 'lr'):
            m.lr = 0.3
        for _ in range(30):
            random.shuffle(train)
            for item in train:
                m.update_rating(item["vector"], round(item["rating"]))
        m.calibrate([item["vector"] for item in train])

        # Evaluar en test
        maes, corrects, total_pairs = [], [], 0
        preds_fold, trues_fold = [], []

        for item in test:
            pred = m.score(item["vector"])
            true_norm = (item["rating"] - 1) / 4.0
            maes.append(abs(pred - true_norm))
            preds_fold.append(pred)
            trues_fold.append(true_norm)
            all_pred.append(pred)
            all_true.append(true_norm)

        # Pair accuracy en test
        correct_pairs = 0
        pair_total    = 0
        for ii in range(len(test)):
            for jj in range(ii+1, len(test)):
                ra = (test[ii]["rating"] - 1) / 4.0
                rb = (test[jj]["rating"] - 1) / 4.0
                if abs(ra - rb) < 0.01:
                    continue  # empate, no cuenta
                pa = m.score(test[ii]["vector"])
                pb = m.score(test[jj]["vector"])
                if (ra > rb and pa > pb) or (ra < rb and pa < pb):
                    correct_pairs += 1
                pair_total += 1

        mae   = sum(maes) / len(maes) if maes else 1.0
        p_acc = correct_pairs / pair_total if pair_total > 0 else 0.0
        fold_results.append({"fold": fold_i+1, "mae": mae, "pair_acc": p_acc,
                              "n_test": len(test)})

    # ── Métricas globales ────────────────────────────────────────────
    mean_mae  = sum(r["mae"]      for r in fold_results) / len(fold_results)
    mean_pacc = sum(r["pair_acc"] for r in fold_results) / len(fold_results)

    # Spearman global
    n_all  = len(all_pred)
    def _rank_list(lst):
        s = sorted(range(len(lst)), key=lambda i: lst[i])
        r = [0] * len(lst)
        for rank, idx in enumerate(s):
            r[idx] = rank + 1
        return r
    pred_ranks = _rank_list(all_pred)
    true_ranks = _rank_list(all_true)
    ds = [pred_ranks[i] - true_ranks[i] for i in range(n_all)]
    spearman = 1 - 6*sum(d**2 for d in ds) / (n_all*(n_all**2-1)) if n_all > 2 else 0.0

    # ── Salida ───────────────────────────────────────────────────────
    print(f"  {'Fold':<6} {'MAE':>6}  {'Pair Acc':>9}  {'n_test':>6}")
    print(f"  {'─'*36}")
    for r in fold_results:
        mae_color   = green if r["mae"]      < 0.15 else (yellow if r["mae"]      < 0.25 else red)
        pacc_color  = green if r["pair_acc"] > 0.75 else (yellow if r["pair_acc"] > 0.60 else red)
        _mae_2319 = f'{r["mae"]:.3f}'
        _pacc_2319 = f'{r["pair_acc"]*100:.1f}%'
        print(f"  {r['fold']:<6} {mae_color(_mae_2319):>6}  "
              f"{pacc_color(_pacc_2319):>9}  {r['n_test']:>6}")

    print(f"  {'─'*36}")
    mae_c  = green if mean_mae  < 0.15 else (yellow if mean_mae  < 0.25 else red)
    pacc_c = green if mean_pacc > 0.75 else (yellow if mean_pacc > 0.60 else red)
    sp_c   = green if spearman  > 0.70 else (yellow if spearman  > 0.50 else red)
    _mae_2326 = f"{mean_mae:.3f}"
    _pacc_2326 = f"{mean_pacc*100:.1f}%"
    print(f"  {'Media':<6} {mae_c(_mae_2326):>6}  {pacc_c(_pacc_2326):>9}")
    print()
    _sp_2328 = f"{spearman:.3f}"
    print(f"  Correlación de Spearman (global): {sp_c(_sp_2328)}")
    print()

    # ── Interpretación ───────────────────────────────────────────────
    print(f"  {bold('Interpretación:')}")

    if mean_mae < 0.10:
        print(f"  {green('●')} MAE excelente — el modelo predice el rating con alta precisión.")
    elif mean_mae < 0.20:
        print(f"  {yellow('●')} MAE aceptable — margen de ~1 estrella en promedio.")
    else:
        print(f"  {red('●')} MAE alto — el modelo generaliza mal. Entrena más rondas o")
        print(f"              revisa si los ratings son consistentes.")

    if mean_pacc > 0.75:
        print(f"  {green('●')} Pair accuracy alta — el modelo ordena bien tus preferencias.")
    elif mean_pacc > 0.60:
        print(f"  {yellow('●')} Pair accuracy moderada — el orden es mayormente correcto.")
    else:
        print(f"  {red('●')} Pair accuracy baja — el modelo no discrimina bien.")
        print(f"              Considera más rondas de contraste (--mode contrast).")

    if spearman > 0.70:
        print(f"  {green('●')} Ranking sólido — las predicciones reflejan fielmente tu gusto.")
    elif spearman > 0.45:
        print(f"  {yellow('●')} Ranking parcial — captura tendencias pero no casos límite.")
    else:
        print(f"  {red('●')} Ranking débil — necesitas más datos o más variedad en el corpus.")

    print()
    if n < 20:
        _label_2359 = f"Nota: {n} ejemplos es poco para validación fiable."
        print(f"  {dim(_label_2359)}")
        print(f"  {dim('Los resultados mejorarán con más sesiones de entrenamiento.')}")

# ════════════════════════════════════════════════════════════════════
#  COMANDO INDEX — vectorizar corpus
# ════════════════════════════════════════════════════════════════════

def cmd_index(args):
    """Vectoriza un directorio de MIDIs y guarda el índice .npz."""

    if not HAS_MIDO:
        print(red("Error: mido no instalado.  pip install mido"))
        sys.exit(1)
    if not HAS_NUMPY:
        print(red("Error: numpy no instalado.  pip install numpy"))
        sys.exit(1)

    midi_dir = Path(args.path)
    if not midi_dir.exists():
        print(red(f"Error: no existe '{midi_dir}'"))
        sys.exit(1)

    output = Path(args.output)

    midi_files = list(midi_dir.rglob("*.mid")) + list(midi_dir.rglob("*.midi"))
    total = len(midi_files)

    if total == 0:
        print(yellow("No se encontraron archivos MIDI en el directorio."))
        sys.exit(0)

    print(f"\n{bold('PREFERENCE TRAINER — INDEX')}")
    print(f"  Directorio:  {cyan(str(midi_dir))}")
    print(f"  Archivos:    {total:,}")
    print(f"  Salida:      {cyan(str(output))}\n")

    vectors  = []
    paths    = []
    metadata = []
    errors   = 0

    bar_width = 40
    t_start   = time.time()

    for i, path in enumerate(midi_files):
        pct     = (i + 1) / total
        filled  = int(bar_width * pct)
        bar     = "█" * filled + "░" * (bar_width - filled)
        elapsed = time.time() - t_start
        eta     = (elapsed / (i + 1)) * (total - i - 1) if i > 0 else 0
        print(f"\r  [{bar}] {i+1}/{total}  ETA:{eta:.0f}s  "
              f"OK:{len(vectors)}  Err:{errors}",
              end="", flush=True)

        r = vectorize_midi(str(path),
                           extended=getattr(args, 'extended_features', False),
                           melodic=getattr(args, 'melodic_features', False))

        if r["error"]:
            errors += 1
            continue

        vectors.append(r["vector"])
        paths.append(str(path))
        metadata.append({
            "duration_s": r["duration_s"],
            "n_notes":    r["n_notes"],
            "n_tracks":   r["n_tracks"],
            "tempo_bpm":  r["tempo_bpm"],
        })

    print()

    if not vectors:
        print(red("\nNo se pudo vectorizar ningún archivo."))
        sys.exit(1)

    # Filtrar vectores con NaN o dimensión incorrecta
    clean_v, clean_p, clean_m = [], [], []
    bad = 0
    for v, p, m in zip(vectors, paths, metadata):
        if getattr(args, 'melodic_features', False):
            expected_dims = 16
        elif getattr(args, 'extended_features', False):
            expected_dims = 20
        else:
            expected_dims = 10
        if v is not None and len(v) == expected_dims and all(x == x for x in v):
            clean_v.append(v)
            clean_p.append(p)
            clean_m.append(m)
        else:
            bad += 1

    if bad:
        print(yellow(f"  {bad} vectores descartados (NaN o dimensión incorrecta)"))

    arr_vectors = np.array(clean_v, dtype=np.float32)
    arr_paths   = np.array(clean_p)
    arr_meta    = np.array([json.dumps(m) for m in clean_m])

    if getattr(args, 'melodic_features', False):
        actual_dim_names = DIM_NAMES_MELODIC
    elif getattr(args, 'extended_features', False):
        actual_dim_names = DIM_NAMES_BASE + DIM_NAMES_EXTENDED
    else:
        actual_dim_names = DIM_NAMES_BASE
    np.savez_compressed(
        _ensure_parent(str(output)),
        vectors   = arr_vectors,
        paths     = arr_paths,
        meta      = arr_meta,
        dim_names = np.array(actual_dim_names),
    )

    elapsed = time.time() - t_start
    print(f"\n{bold('ÍNDICE GENERADO')}")
    print(f"  Vectorizados: {green(str(len(clean_v)))}")
    print(f"  Errores:      {red(str(errors + bad))}")
    print(f"  Tiempo:       {elapsed:.1f}s")
    print(f"  Archivo:      {cyan(str(output))}")
    out_str = str(output)
    print(f"\n  Siguiente paso:")
    print(f"    {dim('python preference_trainer.py train ' + out_str)}\n")




def _rank_interactive(args, model, entries, model_file):
    """
    Sesión interactiva post-rank: navegar el ranking, escuchar y anotar
    MIDIs sin salir del comando rank.
    """
    soundfont = getattr(args, "soundfont", None)

    # Construir lista navegable: top + inciertas (sin duplicados)
    top_n    = sorted(entries, key=lambda e: e["score"],  reverse=True)
    unc_n    = sorted(entries, key=lambda e: e["unc"],    reverse=True)
    # Intercalar: primero los más inciertos no anotados, luego el top
    queue = []
    seen_paths = set()
    for e in unc_n:
        if e["n_seen"] == 0 and e["path"] not in seen_paths:
            queue.append(e)
            seen_paths.add(e["path"])
    for e in top_n:
        if e["path"] not in seen_paths:
            queue.append(e)
            seen_paths.add(e["path"])

    _label_2510 = f"{len(queue)} MIDIs en cola"
    print(f"\n{bold('─ MODO INTERACTIVO ─')}  "
          f"{dim(_label_2510)}")
    print(dim("  Puntúa [1-5] · p=reproducir · x=parar · s=saltar · q=guardar y salir"))
    print()

    mode_str = getattr(args, 'mode', 'rating')
    done = 0

    for e in queue:
        v    = e["vector"]
        path = e["path"]
        name = e["name"]

        seen_tag = dim(f"  [{e['n_seen']}x anotado]") if e["n_seen"] > 0 else ""
        unc_col  = green if e["unc"] > 0.7 else (yellow if e["unc"] > 0.3 else dim)

        print(f"  {'─'*52}")
        print(f"  {cyan(name)}{seen_tag}")
        _sc_2528 = f'{e["score"]:.3f}'
        _uc_2528 = f'{e["unc"]:.2f}'
        print(f"  {dim(format_duration(e['dur']))} · {dim(str(e['bpm']))} bpm  "
              f"score={bold(_sc_2528)}  "
              f"unc={unc_col(_uc_2528)}")
        print()

        # Reproducción automática
        _play_midi(path, soundfont=soundfont, blocking=False)

        rating = None
        while rating is None:
            raw = input("  [1-5 / p=reproducir / x=parar / s=saltar / q=salir]: ").strip().lower()
            if raw in ("q", "quit"):
                _stop_playback()
                break
            elif raw in ("p", "play"):
                _play_midi(path, soundfont=soundfont, blocking=False)
            elif raw in ("x", "stop"):
                _stop_playback()
            elif raw in ("s", "skip", ""):
                rating = "skip"
            elif raw.isdigit() and 1 <= int(raw) <= 5:
                rating = int(raw)
                _stop_playback()
            else:
                print(red("  Introduce 1-5, p, x, s o q."))

        if raw in ("q", "quit"):
            break

        if rating == "skip":
            print(dim("  Saltado.\n"))
            continue

        model.update_rating(v, rating, path=path)
        model.history.append({"type": "rating", "path": path, "rating": rating})
        e["n_seen"] += 1

        stars = "★" * rating + "☆" * (5 - rating)
        print(green(f"  {stars}  Anotado.\n"))
        done += 1

        if done % 5 == 0:
            print(f"  {bold('─ Estado del modelo ─')}")
            print(model.summary())
            print()

    _stop_playback()

    if done > 0:
        model.calibrate([e["vector"] for e in entries])
        save_model(model, args.model)
        print(f"\n{green('✓')} {done} anotaciones guardadas en {cyan(model_file)}")
    else:
        print(dim("  Sin cambios."))

# ════════════════════════════════════════════════════════════════════
#  COMANDO RANK — escanear corpus completo
# ════════════════════════════════════════════════════════════════════

def cmd_rank(args):
    """Escanea el corpus completo y devuelve top/bottom/inciertas."""

    model_file = _model_path(args.model)


    model_type = _model_type_from_args(args)
    if not Path(model_file).exists():
        print(red(f"Modelo no encontrado: {model_file}"))
        sys.exit(1)
    if not Path(args.corpus).exists():
        print(red(f"Corpus no encontrado: {args.corpus}"))
        sys.exit(1)

    model = load_model(args.model, model_type)

    print(f"\n{bold('PREFERENCE TRAINER — RANK')}")
    print(f"  Modelo: {cyan(model_file)}  [{dim(model.MODEL_TYPE)}]  ({model.n_train} ejemplos de entrenamiento)")
    print(f"  Corpus: {cyan(args.corpus)}")

    vectors, paths, meta = _load_corpus_npz(args.corpus)
    n_total = len(vectors)
    print(f"  Total:  {n_total:,} MIDIs")

    if n_total == 0:
        print(red("  Corpus vacío."))
        sys.exit(1)

    # ── Cargar vectores de afinidad ──────────────────────────────────
    affinity_vectors = []
    weight_pref = 1.0
    weight_aff  = 0.0
    if getattr(args, "affinity", None):
        affinity_dir = Path(args.affinity)
        if not affinity_dir.exists():
            print(red(f"  Carpeta de afinidad no encontrada: {affinity_dir}"))
        else:
            aff_files = (list(affinity_dir.rglob("*.mid")) +
                         list(affinity_dir.rglob("*.midi")))
            print(f"  Cargando {len(aff_files)} obras afines de {cyan(str(affinity_dir))}...",
                  end=" ", flush=True)
            _n_w_rank = len(model.weights) if model.weights else 10
            _use_ext_rank = _n_w_rank == 20
            _use_mel_rank = _n_w_rank == 16
            for mf in aff_files:
                res = vectorize_midi(str(mf),
                                     extended=_use_ext_rank,
                                     melodic=_use_mel_rank)
                if res["vector"]:
                    affinity_vectors.append(res["vector"])
            print(green(f"{len(affinity_vectors)} OK"))
            weight_pref = 1.0 - args.weight
            weight_aff  = args.weight
            print(f"  Ponderación: preferencia×{weight_pref:.2f} + afinidad×{weight_aff:.2f}")

    # Calibrar el modelo sobre el corpus completo
    model.calibrate(vectors)

    # Calcular score e incertidumbre para cada MIDI
    print(f"  Calculando scores...", end=" ", flush=True)
    t0 = time.time()
    entries = []
    for i, (v, p, m) in enumerate(zip(vectors, paths, meta)):
        pref_score = model.score_with_memory(v, str(p))
        unc        = model.uncertainty(v)

        aff_score = 0.0
        if affinity_vectors:
            sims      = [_cosine_similarity(v, av) for av in affinity_vectors]
            aff_score = (sum(sims) / len(sims) + 1) / 2

        score = (weight_pref * pref_score + weight_aff * aff_score
                 if affinity_vectors else pref_score)

        try:
            md = json.loads(str(m))
        except Exception:
            md = {}
        n_seen = model.annotation_count(str(p))
        entries.append({
            "idx":        i,
            "path":       str(p),
            "name":       Path(str(p)).name,
            "score":      score,
            "pref_score": pref_score,
            "aff_score":  aff_score,
            "unc":        unc,
            "dur":        md.get("duration_s", 0),
            "bpm":        md.get("tempo_bpm", "?"),
            "n_seen":     n_seen,
            "vector":     v,
        })
    print(green(f"{time.time()-t0:.1f}s"))

    # ── Filtrar anotados si se pide ──────────────────────────────────
    if getattr(args, 'exclude_annotated', False):
        n_before = len(entries)
        entries  = [e for e in entries if e["n_seen"] == 0]
        n_after  = len(entries)
        excluded = n_before - n_after
        if excluded:
            _label_2684 = f"Excluidos {excluded} MIDIs ya anotados → quedan {n_after:,}"
            print(f"  {dim(_label_2684)}")
        if not entries:
            print(yellow("  Todos los MIDIs del corpus ya han sido anotados."))
            return

    n     = min(args.top, len(entries))
    top   = sorted(entries, key=lambda e: e["score"],  reverse=True)[:n]
    bot   = sorted(entries, key=lambda e: e["score"])[:n]
    unc_l = sorted(entries, key=lambda e: e["unc"],    reverse=True)[:n]

    # ── helpers de display ────────────────────────────────────────────
    def _score_bar(score, width=25):
        filled = int(score * width)
        bar    = "█" * filled + "░" * (width - filled)
        color  = green if score >= 0.65 else (yellow if score >= 0.40 else red)
        return color(bar)

    def _entry_line(rank, e, show_unc=False):
        seen_tag = dim(f" [{e['n_seen']}x]") if e["n_seen"] > 0 else ""
        dur      = format_duration(e["dur"])
        _unc_2704 = f'{e["unc"]:.2f}'
        extra    = (f"  {dim(f'unc={_unc_2704}')}" if show_unc else "")
        aff_tag  = (dim(f"  pref={e['pref_score']:.3f} aff={e['aff_score']:.3f}")
                    if affinity_vectors else "")
        _sc_2727 = f'{e["score"]:.3f}'
        print(f"  {rank:>4}.  {_score_bar(e['score'])}  "
              f"{bold(_sc_2727)}  "
              f"{cyan(e['name'])}{seen_tag}")
        _label_2710 = f'{dur} · {e["bpm"]} bpm'
        print(f"         {dim(_label_2710)}{extra}{aff_tag}")

    # ── Estadísticas globales ─────────────────────────────────────────
    all_scores = [e["score"] for e in entries]
    mean_score = sum(all_scores) / len(all_scores)
    sorted_s   = sorted(all_scores)
    median_s   = sorted_s[len(sorted_s)//2]
    p25        = sorted_s[int(len(sorted_s)*0.25)]
    p75        = sorted_s[int(len(sorted_s)*0.75)]
    n_high     = sum(1 for s in all_scores if s >= 0.65)
    n_low      = sum(1 for s in all_scores if s <= 0.35)
    n_mid      = n_total - n_high - n_low

    print(f"\n{bold('─ Distribución global ─')}")
    hist_full = _corpus_histogram(mean_score, all_scores)
    for line in hist_full.split("\n"):
        print(f"  {line}")
    print()
    print(f"  Media:   {mean_score:.3f}   Mediana: {median_s:.3f}")
    print(f"  P25:     {p25:.3f}          P75:     {p75:.3f}")
    print(f"  Alta preferencia (≥0.65): {green(str(n_high)):>6}  ({n_high/n_total*100:.1f}%)")
    print(f"  Indiferente    (0.35-0.65):{yellow(str(n_mid)):>6}  ({n_mid/n_total*100:.1f}%)")
    print(f"  Baja preferencia (≤0.35): {red(str(n_low)):>6}  ({n_low/n_total*100:.1f}%)")

    # ── TOP ───────────────────────────────────────────────────────────
    print(f"\n{'═'*60}")
    _label_2736 = f"TOP {n} — más preferidas"
    print(f"  {bold(green(_label_2736))}")
    print(f"{'═'*60}")
    for rank, e in enumerate(top, 1):
        _entry_line(rank, e)
    print()

    # ── BOTTOM ────────────────────────────────────────────────────────
    print(f"{'═'*60}")
    _label_2744 = f"BOTTOM {n} — menos preferidas"
    print(f"  {bold(red(_label_2744))}")
    print(f"{'═'*60}")
    for rank, e in enumerate(bot, 1):
        _entry_line(rank, e)
    print()

    # ── INCIERTAS ─────────────────────────────────────────────────────
    print(f"{'═'*60}")
    _label_2752 = f"INCIERTAS {n} — mayor incertidumbre"
    print(f"  {bold(yellow(_label_2752))}")
    print(f"  {dim('(donde más ganarías entrenando)')}")
    print(f"{'═'*60}")
    for rank, e in enumerate(unc_l, 1):
        _entry_line(rank, e, show_unc=True)
    print()

    # ── Modo interactivo ─────────────────────────────────────────────
    if getattr(args, 'interactive', False):
        _rank_interactive(args, model, entries, model_file)

    # ── Exportar CSV si se pide ───────────────────────────────────────
    if args.csv:
        import csv
        out_path = args.csv
        with open(_ensure_parent(out_path), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            header = ["rank_pref", "score", "uncertainty", "n_seen",
                      "duration_s", "bpm", "name", "path"]
            if affinity_vectors:
                header += ["pref_score", "aff_score"]
            w.writerow(header)
            for rank, e in enumerate(
                sorted(entries, key=lambda x: x["score"], reverse=True), 1
            ):
                row = [rank, f"{e['score']:.4f}", f"{e['unc']:.4f}",
                       e["n_seen"], f"{e['dur']:.1f}", e["bpm"],
                       e["name"], e["path"]]
                if affinity_vectors:
                    row += [f"{e['pref_score']:.4f}", f"{e['aff_score']:.4f}"]
                w.writerow(row)
        print(f"  {green('✓')} CSV exportado: {cyan(out_path)}")
        print(f"  {n_total:,} filas, ordenadas por preferencia descendente.")

def cmd_info(args):
    """Muestra información del modelo guardado."""
    model_file = _model_path(args.model)

    model_type = _model_type_from_args(args)
    if not Path(model_file).exists():
        print(red(f"Modelo no encontrado: {model_file}"))
        sys.exit(1)

    model = load_model(args.model, model_type)
    print(f"\n{bold('PREFERENCE TRAINER — INFO')}")
    print(f"  Archivo: {cyan(model_file)}")
    print()
    print(model.summary())
    print()

    if model.history:
        print(f"  {bold('Últimas anotaciones:')}")
        for entry in model.history[-10:]:
            if entry["type"] == "rating":
                stars = "★" * entry["rating"] + "☆" * (5 - entry["rating"])
                name  = Path(entry["path"]).name
                print(f"    {stars}  {dim(name)}")
            elif entry["type"] == "contrast" and entry.get("winner"):
                winner = Path(entry["winner"]).name
                loser  = Path(entry["loser"]).name
                print(f"    {green('▶')} {winner}  {dim('sobre')}  {loser}")
        print()


# ════════════════════════════════════════════════════════════════════
#  ENTRADA PRINCIPAL
# ════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Preference Trainer — aprende y evalúa preferencias musicales MIDI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # ── index ─────────────────────────────────────────────────────
    p_index = sub.add_parser("index", help="Vectorizar corpus de MIDIs → .npz")
    p_index.add_argument("path",
                         help="Directorio raíz que contiene los MIDIs (recursivo)")
    p_index.add_argument("--output", default="corpus.npz",
                         help="Archivo .npz de salida (default: corpus.npz)")
    p_index.add_argument("--extended-features", dest="extended_features",
                         action="store_true",
                         help="Calcular 20 features en lugar de 10 (más lento, mejor discriminación)")
    p_index.add_argument("--melodic-features", dest="melodic_features",
                         action="store_true",
                         help="Calcular 16 features melódicas (para MIDIs de una sola voz)")

    # ── train ──────────────────────────────────────────────────────
    p_train = sub.add_parser("train", help="Sesión de entrenamiento interactiva")
    p_train.add_argument("corpus",
                         help="Archivo .npz generado con: python preference_trainer.py index <dir/>")
    p_train.add_argument("--mode", default="rating", choices=["rating", "contrast"],
                         help="Modalidad de anotación (default: rating)")
    p_train.add_argument("--model", default="prefs",
                         help="Nombre base del modelo (default: prefs → prefs.prefs.json)")
    p_train.add_argument("--rounds", type=int, default=20,
                         help="Número de rondas de anotación (default: 20)")
    p_train.add_argument("--soundfont", default=None,
                         help="Soundfont .sf2 para timidity o pygame")
    p_train.add_argument("--no-autoplay", action="store_true",
                         help="No reproducir automáticamente al presentar cada MIDI")
    p_train.add_argument("--candidate-pool", type=int, default=50,
                         help="Pool de candidatos para selección activa (default: 50)")
    p_train.add_argument("--strategy", default="uncertainty",
                         choices=["uncertainty", "density", "emc", "eer", "qbc", "hybrid"],
                         help=(
                             "Estrategia de selección activa (default: uncertainty).\n"
                             "  uncertainty  Máxima incertidumbre × novedad. Rápida.\n"
                             "  density      Incertidumbre × densidad en corpus × novedad.\n"
                             "  emc          Expected Model Change. Alta señal, bajo coste.\n"
                             "  eer          Expected Error Reduction. Óptima formal, más lenta.\n"
                             "  qbc          Query by Committee (K=5 modelos). Robusta.\n"
                             "  hybrid       Combina uncertainty + density + emc. Recomendada."
                         ))
    p_train.add_argument("--model-type", default="linear",
                         choices=["linear","neural","kernel","gp","svm"],
                         help="Tipo de modelo (default: linear). Cada tipo usa archivo separado.")

    # ── eval ───────────────────────────────────────────────────────
    p_eval = sub.add_parser("eval", help="Evaluar uno o varios MIDIs")
    p_eval.add_argument("midi", nargs="+",
                        help="Archivo(s) MIDI a evaluar")
    p_eval.add_argument("--model", default="prefs",
                        help="Nombre base del modelo (default: prefs)")
    p_eval.add_argument("--affinity", default=None,
                        help="Carpeta con obras afines para ponderar afinidad")
    p_eval.add_argument("--weight", type=float, default=0.5,
                        help="Peso de la afinidad [0-1] (default: 0.5). "
                             "0=solo preferencia, 1=solo afinidad")
    p_eval.add_argument("--corpus", default=None,
                        help="Corpus .npz para percentil y vecinos (opcional pero recomendado)")
    p_eval.add_argument("--verbose", action="store_true",
                        help="Desglose completo de dimensiones")
    p_eval.add_argument("--json", dest="json_out", action="store_true",
                        help="Salida JSON machine-readable al final")
    p_eval.add_argument("--model-type", default="linear",
                         choices=["linear","neural","kernel","gp","svm"],
                         help="Tipo de modelo (default: linear). Cada tipo usa archivo separado.")

    # ── rank ───────────────────────────────────────────────────────
    p_rank = sub.add_parser("rank", help="Escanear corpus → top/bottom/inciertas")
    p_rank.add_argument("corpus",
                        help="Archivo .npz del corpus a escanear")
    p_rank.add_argument("--model", default="prefs",
                        help="Nombre base del modelo (default: prefs)")
    p_rank.add_argument("--top", type=int, default=20,
                        help="Número de entradas por lista (default: 20)")
    p_rank.add_argument("--affinity", default=None,
                        help="Carpeta con obras afines para ponderar afinidad")
    p_rank.add_argument("--weight", type=float, default=0.5,
                        help="Peso de la afinidad [0-1] (default: 0.5). "
                             "0=solo preferencia, 1=solo afinidad")
    p_rank.add_argument("--exclude-annotated", dest="exclude_annotated",
                        action="store_true",
                        help="Excluir MIDIs ya anotados en sesiones previas")
    p_rank.add_argument("--interactive", action="store_true",
                        help="Anotar MIDIs directamente desde el ranking")
    p_rank.add_argument("--soundfont", default=None,
                        help="Soundfont .sf2 para reproducción en modo interactivo")
    p_rank.add_argument("--csv", default=None,
                        help="Exportar ranking completo a CSV")
    p_rank.add_argument("--model-type", default="linear",
                         choices=["linear","neural","kernel","gp","svm"],
                         help="Tipo de modelo (default: linear). Cada tipo usa archivo separado.")

    # ── set ────────────────────────────────────────────────────────
    p_set = sub.add_parser("set", help="Asignar preferencia directamente a un MIDI")
    p_set.add_argument("midi", nargs="+",
                       help="Archivo(s) MIDI o directorio")
    p_set.add_argument("--score", type=int, required=True, choices=[1,2,3,4,5],
                       help="Preferencia a asignar (1-5)")
    p_set.add_argument("--model", default="prefs",
                       help="Nombre base del modelo (default: prefs)")
    p_set.add_argument("--repetitions", type=int, default=10,
                       help="Fuerza del ajuste: nº de veces que se aplica (default: 10)")
    p_set.add_argument("--model-type", default="linear",
                         choices=["linear","neural","kernel","gp","svm"],
                         help="Tipo de modelo (default: linear). Cada tipo usa archivo separado.")

    # ── validate ───────────────────────────────────────────────────
    p_val = sub.add_parser("validate", help="Validación cruzada del modelo")
    p_val.add_argument("--model", default="prefs",
                       help="Nombre base del modelo (default: prefs)")
    p_val.add_argument("--corpus", default=None,
                       help="Corpus .npz para recuperar vectores del historial")
    p_val.add_argument("--folds", type=int, default=5,
                       help="Número de folds (default: 5)")
    p_val.add_argument("--model-type", default="linear",
                         choices=["linear","neural","kernel","gp","svm"],
                         help="Tipo de modelo (default: linear). Cada tipo usa archivo separado.")

    # ── info ───────────────────────────────────────────────────────
    p_info = sub.add_parser("info", help="Inspeccionar modelo guardado")
    p_info.add_argument("--model", default="prefs",
                        help="Nombre base del modelo (default: prefs)")
    p_info.add_argument("--model-type", default="linear",
                         choices=["linear","neural","kernel","gp","svm"],
                         help="Tipo de modelo (default: linear). Cada tipo usa archivo separado.")

    args = parser.parse_args()

    if args.cmd == "set":
        cmd_set(args)
    elif args.cmd == "index":
        cmd_index(args)
    elif args.cmd == "train":
        cmd_train(args)
    elif args.cmd == "eval":
        cmd_eval(args)
    elif args.cmd == "rank":
        cmd_rank(args)
    elif args.cmd == "validate":
        cmd_validate(args)
    elif args.cmd == "info":
        cmd_info(args)


if __name__ == "__main__":
    main()

