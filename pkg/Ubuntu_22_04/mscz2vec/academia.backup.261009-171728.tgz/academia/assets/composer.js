/* ═══════════════════════════════════════════════════════════════════
   Academia Mutopia — mini-pipeline compositivo en el navegador.
   Cada función imita (de forma muy simplificada y explicable) una etapa
   del ecosistema, para que las lecciones y el taller puedan encadenarlas:

     planFromArc   ≈ narrator.py        (forma, mapa tonal, 5 curvas)
     harmonize     ≈ chord_progression_generator.py (+ tonicization_engine, cadence_designer)
     melodize      ≈ melody_conditioned / melody_generator (motivo por sección, notas fuertes en el acorde)
     bassLine      ≈ bass_line_composer.py
     accompany     ≈ leadsheet_realizer.py / chord_pattern_voicer.py
     drumsFor      ≈ drummer.py add (arquetipo + tensión por compás)
     perform       ≈ performer.py (rubato, agógica, dinámica, lead, humanize, pedal)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const M = window.M;

/* mapa tonal: rol de sección → tonalidad (ARC_TONAL_MAPS de narrator.py) */
M.tonalRole = (tonic, mode, role) => {
  const maj = mode === 'major';
  switch (role) {
    case 'relative': return maj ? {tonic: (tonic + 9) % 12, mode: 'minor'} : {tonic: (tonic + 3) % 12, mode: 'major'};
    case 'dominant': return {tonic: (tonic + 7) % 12, mode: maj ? 'major' : 'minor'};
    case 'subdominant': return {tonic: (tonic + 5) % 12, mode};
    case 'parallel': return {tonic, mode: maj ? 'minor' : 'major'};
    default: return {tonic, mode};
  }
};
M.keyStr = (k, flats) => M.pcName(k.tonic, flats ?? [5, 10, 3, 8, 1].includes(k.tonic)) + (k.mode === 'major' ? '' : 'm');

/* plan (narrator.py --arc X --bars N --key K) */
M.planFromArc = (arc, bars, tonic, mode, o = {}) => {
  const curves = M.arcCurves(arc, bars), secs = M.arcSections(arc, bars), roles = M.ARC_TONAL[arc] || ['base'];
  const sections = secs.map((s, i) => ({...s, role: roles[i] || 'base', ...(o.modulate === false ? {tonic, mode} : M.tonalRole(tonic, mode, roles[i] || 'base'))}));
  const t = curves.tension; let climax = t.indexOf(Math.max(...t));
  return {arc, bars, tonic, mode, tempo: o.tempo || 96, curves, sections, climax};
};
M.sectionOf = (plan, bar) => plan.sections.find(s => bar >= s.start && bar < s.start + s.bars) || plan.sections[plan.sections.length - 1];

/* armonía por función según la tensión (paso [1] de chord_progression_generator.py) */
const OPTS = {
  major: {T: ['I', 'vi', 'I', 'iii'], S: ['IV', 'ii', 'IV'], D: ['V', 'V7', 'vii°']},
  minor: {T: ['i', 'VI', 'i', 'III'], S: ['iv', 'ii°', 'iv', 'VI'], D: ['V', 'V7', 'VII']},
};
M.harmonize = (plan, o = {}) => {
  const out = [], r = M.rng(o.seed || 11);
  for (let b = 0; b < plan.bars; b++) {
    const sec = M.sectionOf(plan, b), k = b - sec.start, last = k === sec.bars - 1, pen = k === sec.bars - 2, final = sec === plan.sections[plan.sections.length - 1];
    const t = plan.curves.tension[b], h = plan.curves.harmony[b], mo = sec.mode === 'major' ? 'major' : 'minor', O = OPTS[mo];
    let fn = t < 0.38 ? 'T' : t < 0.62 ? 'S' : 'D', num, cad = null;
    if (k === 0) { fn = 'T'; num = O.T[0]; }
    else if (last) { if (final || t < 0.5) { num = O.T[0]; cad = final ? 'auténtica perfecta' : 'auténtica imperfecta'; } else { num = 'V'; cad = 'semicadencia'; } fn = num === 'V' ? 'D' : 'T'; }
    else if (pen) { num = h > 0.5 ? 'V7' : 'V'; fn = 'D'; }
    else { if (out.length >= 2 && out[out.length - 1].fn === fn && out[out.length - 2].fn === fn) fn = fn === 'D' ? 'S' : fn === 'T' ? 'S' : 'T'; num = M.choice(O[fn], r); if (out.length && out[out.length - 1].num === num) num = M.choice(O[fn].filter(x => x !== num), r); }
    if (h > 0.6 && !last && num.length <= 3 && !num.includes('7') && !num.includes('°')) num = num === 'I' ? 'IM7' : num === 'i' ? 'im7' : num + '7';
    out.push({bar: b, num, fn, cad, tonic: sec.tonic, mode: mo, sec: sec.id});
  }
  // tonicización: dominante secundaria antes de ii, IV, vi cuando la complejidad armónica es alta (tonicization_engine.py)
  if (o.tonicize !== false) for (let i = 1; i < out.length; i++) {
    const c = out[i], p = out[i - 1], base = c.num.replace(/7|M7/g, '');
    if (plan.curves.harmony[i - 1] > 0.55 && ['ii', 'IV', 'vi', 'iv', 'VI'].includes(base) && p.fn === 'T' && !p.cad && p.bar - M.sectionOf(plan, p.bar).start > 0) { p.num = 'V/' + base; p.fn = 'AD'; p.toniciza = base; }
  }
  out.forEach(c => { c.r = M.parseNumeral(c.num, c.mode, c.tonic); if (!c.r) c.r = M.parseNumeral(c.mode === 'major' ? 'I' : 'i', c.mode, c.tonic); });
  return out;
};

/* melodía: motivo rítmico/contorno sembrado por letra de sección (las secciones A comparten material) */
const RHY = [[[4], [2, 2], [3, 1]], [[2, 1, 1], [1, 1, 2], [1.5, .5, 2]], [[1, 1, 1, 1], [1.5, .5, 1, 1], [1, .5, .5, 2]], [[.5, .5, 1, .5, .5, 1], [1, .5, .5, .5, .5, 1], [.5, .5, .5, .5, 1, 1]], [[.5, .5, .5, .5, .5, .5, .5, .5], [.25, .25, .5, .5, .5, 1, .5, .5, .5], [.5, .25, .25, .5, .5, .5, .5, 1]]];
const hash = s => [...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
M.melodize = (plan, chords, o = {}) => {
  const notes = [], climaxBar = o.climaxBar ?? plan.climax, regMax = Math.max(...plan.curves.register);
  const ceiling = Math.round(64 + regMax * 10);                       // la nota más aguda se reserva para el clímax
  let p = Math.round(60 + plan.curves.register[0] * 8), lastIv = 0;
  for (let b = 0; b < plan.bars; b++) {
    const sec = M.sectionOf(plan, b), k = b - sec.start, r = M.rng(hash(sec.id) * 131 + k * 17 + (o.seed || 0)), ch = chords[b];
    const sc = M.SCALES[ch.mode].iv.map(x => (x + ch.tonic) % 12), cpcs = ch.r.pcs;
    const act = plan.curves.activity[b], reg = plan.curves.register[b], ten = plan.curves.tension[b];
    const lvl = M.clamp(Math.round(act * 4.4 - 0.4), 0, 4);
    const lastOfSec = k === sec.bars - 1, breath = lastOfSec || k % 4 === 3;     // fin de frase: respiración
    let rhythm = M.choice(RHY[lvl], r).slice();
    if (breath) rhythm = lvl >= 2 ? [1, .5, .5, 1] : [2, 1];                      // deja 1 tiempo de silencio
    const center = 59 + reg * 10, top = b === climaxBar ? ceiling : ceiling - 2;
    const inScale = m => sc.includes(((m % 12) + 12) % 12);
    let t = 0;
    rhythm.forEach((d, j) => {
      const strong = t % 2 === 0, endNote = breath && j === rhythm.length - 1;
      let dir = Math.abs(center - p) < 2 ? (r() < 0.5 ? 1 : -1) : Math.sign(center - p); if (r() < 0.3) dir = -dir;
      let cand;
      if (Math.abs(lastIv) >= 5) { dir = -Math.sign(lastIv); cand = p + dir; let g = 0; while (!inScale(cand) && g++ < 3) cand += dir; }   // compensar el salto
      else if (endNote) { const goal = lastOfSec ? (ch.cad === 'semicadencia' ? [(ch.tonic + 2) % 12, (ch.tonic + 7) % 12] : [ch.tonic, (ch.tonic + (ch.mode === 'major' ? 4 : 3)) % 12]) : cpcs; cand = nearestPc(p, goal, center); }
      else if (strong) { cand = nearestPc(p + dir * (r() < 0.2 ? 5 : 2), cpcs, center); }
      else { cand = p + dir; let g = 0; while (!inScale(cand) && g++ < 3) cand += dir; }
      if (b === climaxBar && j === Math.min(rhythm.length - 1, 1)) cand = nearestPc(ceiling, cpcs, ceiling);
      else cand = Math.min(cand, top);
      cand = M.clamp(cand, 57, 86);
      notes.push({t: b * 4 + t, d: d * (endNote ? 0.98 : 0.92), m: cand, v: M.clamp(0.42 + 0.48 * ten + (strong ? 0.05 : 0), 0.2, 1), bar: b, sec: sec.id});
      lastIv = cand - p; p = cand; t += d;
    });
  }
  return notes;
};
function nearestPc(target, pcs, center) { let best = target, bd = 1e9; for (let m = target - 8; m <= target + 8; m++) if (pcs.includes(((m % 12) + 12) % 12)) { const d = Math.abs(m - target) + 0.15 * Math.abs(m - center); if (d < bd) { bd = d; best = m; } } return best; }

/* bajo (bass_line_composer.py, estilos reducidos) */
M.bassLine = (chords, style = 'root', plan) => {
  const out = []; let last = 40;
  const near = (pc, ref) => { let best = 40, d = 99; for (let m = 28; m <= 52; m++) if (m % 12 === pc && Math.abs(m - ref) < d) { d = Math.abs(m - ref); best = m; } return best; };
  chords.forEach((c, i) => {
    const t0 = i * 4, r = near(c.r.root, last), nx = chords[i + 1], v = plan ? 0.55 + 0.35 * plan.curves.activity[i] : 0.75, iv = M.QUAL[c.r.q].iv;
    const add = (t, d, m, lab) => out.push({t: t0 + t, d: d * 0.92, m, v, label: lab});
    if (style === 'root') { add(0, 2, r, 'R'); add(2, 2, r + (iv[2] ?? 7) - 12 * (r + 7 > 52), '5'); }
    else if (style === 'pop') { for (let k = 0; k < 8; k++) add(k * .5, .5, k === 5 ? r + 12 : r, 'R'); }
    else if (style === 'walking') { add(0, 1, r, 'R'); add(1, 1, r + iv[1], '3'); add(2, 1, r + iv[2], '5'); const nr = nx ? near(nx.r.root, r) : r; add(3, 1, nr + (nr > r + iv[2] ? -1 : 1), 'aprox'); }
    else if (style === 'arpeggio') { [0, iv[2], 12, iv[2]].forEach((x, k) => add(k, 1, r + x, ['R', '5', '8', '5'][k])); }
    else if (style === 'latin') { const nr = nx ? near(nx.r.root, r) : r; add(1.5, 1.5, r + iv[2] - 12 * (r + iv[2] > 52), '5'); add(3, 1, nr, 'anticipa'); }
    last = r;
  });
  return out;
};
/* acompañamiento (patrones de leadsheet_realizer.py elegidos por la actividad) */
M.accompany = (chords, plan, o = {}) => {
  const out = []; let prev = null;
  chords.forEach((c, i) => {
    const v = M.voiceChord(c.r.pcs, prev, {lo: 53, hi: 72}); prev = v; const up = v.slice(1), act = plan.curves.activity[i], t0 = i * 4, vel = 0.32 + 0.25 * plan.curves.tension[i];
    const pat = o.pattern || (act < 0.35 ? 'block' : act < 0.6 ? 'ballad' : act < 0.8 ? 'arpeggio' : 'pop');
    const add = (t, d, m, vv = vel) => out.push({t: t0 + t, d, m, v: vv, bar: i});
    if (pat === 'block') up.forEach(m => add(0, 3.9, m));
    if (pat === 'ballad') up.forEach(m => { add(0, 1.9, m); add(2, 1.9, m, vel * .85); });
    if (pat === 'arpeggio') [0, 1, 2, 1, 0, 1, 2, 1].forEach((k, j) => add(j * .5, .5, up[k], vel * (j % 4 ? .85 : 1)));
    if (pat === 'pop') [.5, 1.5, 2.5, 3.5].forEach(t => up.forEach(m => add(t, .4, m, vel * .9)));
    out.forEach(n => n.pat = n.pat || pat);
  });
  return out;
};
/* batería (drummer.py add --style S): arquetipo regenerado con la tensión de cada compás */
M.drumsFor = (plan, style = 'rock_straight') => {
  const A = M.DRUM_ARCHETYPES[style] || M.DRUM_ARCHETYPES.rock_straight, out = [];
  for (let b = 0; b < plan.bars; b++) {
    const sec = M.sectionOf(plan, b), t = plan.curves.tension[b], a = plan.curves.activity[b];
    if (a < 0.22) continue;                                   // las secciones muy tranquilas van sin batería
    const pat = A.fn(t), last = b === sec.start + sec.bars - 1;
    M.drumEvents(pat, 1, b * 4).forEach(e => { if (last && e.t - b * 4 >= 3 && e.inst !== 'drum:kick') return; out.push({...e, v: e.v * (0.55 + 0.45 * a)}); });
    if (last && b < plan.bars - 1) [3, 3.25, 3.5, 3.75].forEach((x, k) => out.push({t: b * 4 + x, d: .25, m: 38, v: .45 + k * .12, inst: 'drum:snare'}));   // fill
    if (b === sec.start && b > 0) out.push({t: b * 4, d: .5, m: 49, v: .7, inst: 'drum:crash'});
  }
  return out;
};

/* ─── performer.py: reglas de interpretación (KTH / Director Musices) ─── */
M.detectPhrases = (mel) => {
  const ns = mel.slice().sort((a, b) => a.t - b.t); if (!ns.length) return [];
  const groups = [[ns[0]]];
  for (let i = 1; i < ns.length; i++) { const cur = groups[groups.length - 1], end = Math.max(...cur.map(n => n.t + n.d)); if (ns[i].t - end >= 0.45) groups.push([ns[i]]); else cur.push(ns[i]); }
  const merged = []; groups.forEach(g => { if (merged.length && g.length < 3) merged[merged.length - 1].push(...g); else merged.push(g); });
  // frases muy largas: cortar en notas largas (como hace performer.py "por silencios y notas largas")
  const out = []; merged.forEach(g => { let cur = []; g.forEach((n, i) => { cur.push(n); if (n.d >= 1.8 && cur.length >= 4 && i < g.length - 2) { out.push(cur); cur = []; } }); if (cur.length) out.push(cur); });
  return out.map(g => { let pk = 0; g.forEach((n, i) => { if (n.m > g[pk].m || (n.m === g[pk].m && n.d > g[pk].d)) pk = i; }); return {notes: g, start: g[0].t, end: Math.max(...g.map(n => n.t + n.d)), peak: pk}; });
};
M.perform = (mel, acc, o = {}) => {
  const I = o.intensity ?? 0.7, bpm = o.bpm || 96, spb = 60 / bpm, rules = Object.assign({rubato: true, agogica: true, dinamica: true, lead: true, humanize: true, pedal: true}, o.rules || {});
  const r = M.rng(o.seed || 42), phrases = M.detectPhrases(mel), total = Math.max(...mel.concat(acc).map(n => n.t + n.d), 1);
  // 1) mapa de tempo local por pulso (rubato por frase + ritardando final)
  const STEP = 0.25, nSteps = Math.ceil(total / STEP) + 8, fac = new Array(nSteps).fill(1);
  if (rules.rubato) {
    phrases.forEach(ph => { const L = Math.max(0.5, ph.end - ph.start), px = M.clamp((ph.notes[ph.peak].t - ph.start) / L, 0.2, 0.85);
      for (let s = Math.floor(ph.start / STEP); s < Math.ceil(ph.end / STEP); s++) { const x = (s * STEP - ph.start) / L; const f = x < px ? M.lerp(0.95, 1.06, x / px) : M.lerp(1.06, 0.86, (x - px) / (1 - px)); fac[s] = 1 + (f - 1) * I; } });
    const fr = Math.floor((total - 4) / STEP); for (let s = Math.max(0, fr); s < nSteps; s++) fac[s] *= 1 - 0.35 * I * M.clamp((s - fr) / (16), 0, 1);
  }
  const tsec = new Array(nSteps + 1).fill(0); for (let s = 0; s < nSteps; s++) tsec[s + 1] = tsec[s] + STEP * spb / fac[s];
  const toSec = beat => { const s = Math.min(nSteps - 1, Math.floor(beat / STEP)), fr = beat / STEP - s; return tsec[s] + fr * STEP * spb / fac[s]; };
  const peaks = new Set(phrases.map(ph => ph.notes[ph.peak])), dev = {rubato: 0, lead: 0, agogica: 0, dyn: 0};
  const perfMel = mel.map(n => {
    const ph = phrases.find(p => p.notes.includes(n)); let ts = toSec(n.t), te = toSec(n.t + n.d), v = vel01(n.v);
    if (rules.agogica && peaks.has(n)) { te += (te - ts) * 0.18 * I; dev.agogica++; }
    if (rules.dinamica && ph) { const pk = ph.notes[ph.peak].t, span = Math.max(1, pk - ph.start); const cres = n.t <= pk ? (n.t - ph.start) / span : 1 - (n.t - pk) / Math.max(1, ph.end - pk); v *= 1 + I * (0.22 * cres - 0.08); const beatPos = n.t % 4; v *= beatPos === 0 ? 1 + 0.08 * I : beatPos % 1 ? 1 - 0.06 * I : 1; v += (r() - 0.5) * 0.06 * I; dev.dyn++; }
    if (rules.lead) ts -= 0.015 * I / 0.7;
    if (rules.humanize) ts += (r() - 0.5) * 0.016 * I;
    return {...n, ts: Math.max(0, ts), ds: Math.max(0.05, te - ts), v: M.clamp(v, 0.08, 1)};
  });
  const perfAcc = acc.map(n => { let ts = toSec(n.t), te = toSec(n.t + n.d), v = vel01(n.v); if (rules.humanize) ts += (r() - 0.5) * 0.022 * I; if (rules.dinamica) { const beatPos = n.t % 4; v *= beatPos === 0 ? 1 + 0.06 * I : 1 - 0.03 * I; } if (rules.pedal && !String(n.inst || '').startsWith('drum') && n.inst !== 'bass') te = Math.max(te, toSec(Math.ceil((n.t + 0.01) / 4) * 4) - 0.02); return {...n, ts: Math.max(0, ts), ds: Math.max(0.04, te - ts), v: M.clamp(v, 0.05, 1)}; });
  const pedal = rules.pedal ? Array.from({length: Math.ceil(total / 4)}, (_, b) => [{t: b * 4 + 0.05, c: 64, v: 0}, {t: b * 4 + 0.12, c: 64, v: 127}]).flat() : [];
  return {mel: perfMel, acc: perfAcc, phrases, fac, toSec, pedal, dev, seconds: toSec(total)};
};
function vel01(v) { return v == null ? 0.7 : v > 1 ? v / 127 : v; }
/* pasa un resultado de perform() a "beats" a tempo fijo, para exportar el rubato horneado en un MIDI */
M.secondsToBeats = (evs, bpm) => evs.map(e => ({...e, t: e.ts * bpm / 60, d: e.ds * bpm / 60}));
})();
