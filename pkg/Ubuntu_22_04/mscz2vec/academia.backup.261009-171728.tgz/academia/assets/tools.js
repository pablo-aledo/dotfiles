// Generado automáticamente a partir de mutopia_compendio.pdf y de los docstrings del código.
window.MUTOPIA_TOOLS = [
{
"n": "analyzer",
"st": "analisis",
"pa": "estadistica",
"i": "MIDIs",
"o": "compare · nearest · diff · trajectory · path",
"les": [
"representacion",
"maquinas"
],
"rel": [
"mscz2vec",
"select"
],
"lines": 2138,
"t": "Análisis comparativo y de trayectoria entre MIDIs",
"p": "analyzer.py responde preguntas de similitud y evolución sobre obras MIDI: comparación dimensión a dimensión entre dos piezas, búsqueda de los N vecinos más cercanos en una colección, “diff” semántico (qué tiene A que no tenga B), matriz de similitud N×N, perfil vectorial de una obra y, en su versión más reciente, la trayectoria interna de una pieza a lo largo de ventanas temporales y el camino vectorial que conecta dos obras (o una secuencia de ellas).",
"a": "Las métricas de distancia implementadas son las tres clásicas del análisis de vecinos: euclídea, coseno y Manhattan, con conversión a una similitud acotada en [0,1]. El modo nearest es esencialmente un k-NN sobre el espacio vectorial de la colección. El modo diff no se limita a restar vectores: calcula la diferencia por dimensión y la filtra por un umbral (--threshold) para reportar solo los cambios “significativos”, añadiendo una descripción semántica de la dirección del cambio (p. ej. “más denso”, “más agudo”).",
"c": "Las dimensiones vectorizadas por mscz2vec.py (invocado como backend “full”) codifican propiedades como densidad melódica, complejidad armónica, rango de alturas, variedad rítmica y perfil de velocidades — es decir, una traducción de intuiciones de análisis musical (¿es denso?, ¿es tonalmente estable?, ¿cambia mucho de registro?) a un vector numérico comparable algebraicamente.",
"ex": [
"python analyzer.py compare A.mid B.mid",
"python analyzer.py compare A.mid B.mid --dimensions melodic harmonic",
"python analyzer.py nearest query.mid coleccion/*.mid",
"python analyzer.py nearest query.mid coleccion/*.mid --top 5"
],
"fam": false
},
{
"n": "anticipation_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "MIDI (melodía)",
"o": "acompañamiento anticipado",
"les": [
"maquinas"
],
"rel": [
"music_transformer"
],
"lines": 1092,
"t": "Anticipatory Music Transformer (adaptación de Stanford CRFM)",
"p": "Es una adaptación al estilo “fichero único” del Anticipatory Music Transformer de Stanford CRFM: una herramienta para tokenizar MIDI, manipular esas secuencias de tokens y generar música (desde cero, como continuación, o como acompañamiento condicionado a una melodía) usando modelos pre-entrenados descargados de HuggingFace Hub.",
"a": "El algoritmo distintivo es la anticipación: en vez de condicionar un modelo autorregresivo solo en el pasado (como un LLM de texto estándar), el Anticipatory Transformer intercala en la secuencia de entrada tokens de control que representan eventos futuros conocidos, desplazados una cantidad delta hacia el pasado en la secuencia — de ahí “anticipados”. Esto permite que un único modelo autorregresivo funcione tanto en modo puramente generativo (autorregresivo puro, sample_generate_ar) como en modo condicionado-al-futuro (modo AAR: autorregresivo + anticipación, sample_generate), por ejemplo generando un acompañamiento que “sabe” de antemano dónde caerán las notas de la melodía.",
"c": "El formato arrival-time separa explícitamente el “cuándo ocurre” de un evento de su contenido tonal, lo cual es natural para pensar en términos de textura polifónica: varias voces (partes instrumentales, identificadas por su programa MIDI) pueden entrelazarse temporalmente. La función extract_melody separa instrumentos concretos (p. ej.",
"ex": [],
"fam": false
},
{
"n": "arc_supervisor",
"st": "analisis",
"pa": "reglas",
"i": "secciones MIDI + plan",
"o": "diagnóstico por sección",
"les": [
"forma"
],
"rel": [
"tension_designer",
"climax_engineer"
],
"lines": 1261,
"t": "Supervisor de arco emocional para obras multi-sección",
"p": "Dada una obra dividida en secciones (ya sea como ficheros MIDI separados o como un único MIDI con puntos de corte en compases), mide si la evolución emocional real de la pieza coincide con un arco planificado de antemano, diagnostica discrepancias y sugiere valores concretos para corregirlas.",
"a": "Cada dimensión emocional se deriva con una heurística explícita sobre las notas extraídas del MIDI (extract_notes): la tensión armónica se calcula como la proporción de pares de notas simultáneas (que se solapan temporalmente) cuyo intervalo es disonante; la actividad es densidad de notas por beat ponderada por velocidad media, normalizada respecto a una referencia empírica (2 notas/beat a velocidad 90 ≈ 1.0); el registro es el pitch medio ponderado por duración, normalizado al rango de un piano (A0–C8); la armonía combina la proporción de ventanas temporales con 4 o más clases de altura simultáneas con el grado de cromatismo (fracción de las 12 clases de altura usadas).",
"c": "El sistema formaliza una intuición de forma musical y retórica: toda obra de cierta duración se sostiene mediante una progresión perceptible de tensión, densidad, registro y complejidad armónica —el “arco dramático”— y los errores de composición asistida por IA con frecuencia se manifiestan como una falta de contraste entre secciones o saltos abruptos no intencionados; arc_supervisor.py cuantifica ambos síntomas.",
"ex": [
"python arc_supervisor.py sec_A.mid sec_B.mid sec_C.mid",
"python arc_supervisor.py obra.mid --sections 8 8 8 8"
],
"fam": false
},
{
"n": "audio_diffusion_cli",
"st": "neuronal",
"pa": "neuronal",
"i": "— / WAV",
"o": "WAV generado/variado/interpolado",
"les": [
"maquinas"
],
"rel": [
"openmusic"
],
"lines": 808,
"t": "Generación de audio mediante difusión sobre espectrogramas Mel",
"p": "Interfaz de línea de comandos sobre la librería audio-diffusion (Robert Dargavel Smith / teticio) que genera, varía, interpola y extiende (outpainting) clips de audio usando modelos de difusión pre-entrenados en HuggingFace Hub, con variante “latente” (VAE + DDIM) más rápida.",
"a": "El generador base es un modelo de difusión probabilístico (DDPM), opcionalmente muestreado con el esquema determinista DDIM (Denoising Diffusion Implicit Models), que permite invertir el proceso: dado un espectrograma-imagen ya existente, _image_to_noise recupera (solo si el scheduler es DDIM, precisamente porque DDIM es determinista y por tanto invertible) el tensor de ruido latente que lo generaría, habilitando ediciones tipo “variación” (variate, con un parámetro strength que controla cuánto ruido se reintroduce antes de volver a des-ruidar: 0 = copia exacta, 1 = generación libre).",
"c": "Aunque el modelo opera directamente sobre representaciones tiempo-frecuencia sin ninguna noción explícita de nota, acorde o compás, la interpolación esférica entre “personalidades tímbricas” (los distintos checkpoints, entrenados sobre corpus como breaks de batería) permite explorar morphing tímbrico continuo entre dos texturas sonoras — un tipo de exploración que no tiene equivalente directo en la representación simbólica (MIDI) que domina el resto del ecosistema mutopia.",
"ex": [
"python audio_diffusion_cli.py generate --output salida.wav",
"python audio_diffusion_cli.py info --model teticio/audio-diffusion-256",
"python audio_diffusion_cli.py info --model teticio/latent-audio-diffusion-ddim-256"
],
"fam": false
},
{
"n": "audio_effects",
"st": "sonido",
"pa": "dsp",
"i": "WAV + cadena de efectos",
"o": "WAV procesado",
"les": [
"sonido"
],
"rel": [
"mix_evolver"
],
"lines": 690,
"t": "Librería DSP de efectos de audio (motor determinista para mix_evolver.py)",
"p": "Aplica, a un WAV ya renderizado, una cadena de efectos de procesamiento de señal conocida de antemano: ecualizador paramétrico, compresor, reverb, limitador, delay, saturación, entre otros. No genera ni busca combinaciones — es el “motor de ejecución” determinista que utiliza mix_evolver.py para evaluar el fitness de cada cadena candidata durante su búsqueda evolutiva.",
"a": "Cada efecto es una implementación DSP explícita y auditable: el EQ paramétrico usa un filtro biquad peaking con los coeficientes estándar del RBJ Audio EQ Cookbook; el compresor de rango dinámico usa un envelope follower secuencial (deliberadamente no vectorizado, pues cada muestra depende del estado del filtro en la muestra anterior) seguido de reducción de ganancia con attack/release configurables; el reverb sintetiza una respuesta al impulso (IR) artificial —ruido con envolvente exponencial decreciente, con semilla determinista fija por defecto para que la evaluación de fitness sea reproducible— y la convoluciona con la señal; el limitador es de tipo brick-wall con lookahead;",
"c": "La librería formaliza, con fórmulas DSP estándar de la industria del audio, las herramientas básicas de un ingeniero de mezcla: dar forma al espectro (EQ), controlar el rango dinámico (compresor/limitador), añadir espacio (reverb) y textura armónica (saturación, que añade armónicos no presentes en la señal original).",
"ex": [],
"fam": false
},
{
"n": "audio_lab",
"st": "sonido",
"pa": "dsp",
"i": "WAV / MIDI / timbre JSON",
"o": "espectrogramas NPZ↔PNG, WAV",
"les": [
"sonido"
],
"rel": [
"synth_forge",
"latent_lab"
],
"lines": 1785,
"t": "Síntesis aditiva, análisis espectral y edición de espectrogramas como imagen",
"p": "Conjunto de utilidades DSP de fichero único que cubre análisis espectral (FFT/STFT), síntesis aditiva de notas a partir de definiciones de timbre y envolvente, renderizado de MIDI a audio sin depender de un soundfont externo, y un flujo de edición creativa que convierte espectrogramas en imágenes PNG editables con herramientas gráficas convencionales.",
"a": "Incluye tanto una DFT ingenua (dft_analyse, con complejidad O(n²), incluida explícitamente con fines didácticos) como la FFT de NumPy (O(n log n)) para el caso de uso real. El análisis por ventanas deslizantes usa STFT con ventana de Hann para minimizar el spectral leakage (fuga espectral) que produciría una ventana rectangular. Como el pipeline PNG descarta la fase (solo conserva magnitud), la reconstrucción de audio a partir de una imagen editada requiere estimar una fase coherente: para ello se implementa el algoritmo de Griffin-Lim, un método iterativo que alterna entre el dominio tiempo y frecuencia, proyectando en cada iteración sobre la restricción de magnitud conocida y sobre la…",
"c": "El timbre se modela explícitamente como el perfil de amplitudes relativas de la serie de armónicos —la definición acústica estándar de timbre—, y la envolvente ADR captura la evolución temporal de la intensidad de una nota, dos de los parámetros perceptuales más básicos en síntesis de sonido.",
"ex": [
"python audio_lab.py analyse piano.wav --method fft --output spec.json",
"python audio_lab.py spectrogram piano.wav --window 4096 --log",
"python audio_lab.py npz-to-png piano.npz --log -o piano.png",
"python audio_lab.py png-to-npz piano_edited.png -o piano_edited.npz"
],
"fam": false
},
{
"n": "audio_reference_scorer",
"st": "analisis",
"pa": "estadistica",
"i": "WAV + corpus de referencia",
"o": "afinidad 0-1 (Mahalanobis, FAD)",
"les": [
"sonido"
],
"rel": [
"mix_evolver"
],
"lines": 1037,
"t": "Puntuación de afinidad de un WAV frente a un corpus de referencia",
"p": "Calcula una puntuación 0-1 de cuán “cercano” es un audio candidato a un corpus de referencia (grabaciones que le gustan al usuario), pensado como señal de recompensa para bucles de aprendizaje por refuerzo (es el cuarto EvalProvider del ecosistema, junto a quality_scorer, preference_trainer y evaluación humana).",
"a": "La métrica central es la distancia de Mahalanobis: a diferencia de la distancia euclídea, pondera cada dimensión por la inversa de la matriz de covarianza del corpus, de modo que la distancia tiene en cuenta tanto la escala como la correlación entre features — dos candidatos igual de “lejos” en euclídea pueden tener Mahalanobis muy distinta si una de las direcciones de desviación coincide con la varianza natural del corpus.",
"c": "La herramienta es explícita sobre una trampa metodológica común en evaluación de audio generado: si el corpus de referencia son grabaciones reales y los candidatos son renders sintéticos, la métrica termina midiendo sobre todo “¿es un soundfont o una grabación real?” en vez de “¿es buena música?” — un caso concreto de confounding entre la variable de interés (calidad musical) y una variable espuria correlacionada (fuente de renderizado), que el --floor-corpus mitiga parcialmente.",
"ex": [
"python audio_reference_scorer.py mi_obra.wav --cache ref.npz"
],
"fam": false
},
{
"n": "audiolm",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus de audio",
"o": "audio generado/continuado",
"les": [
"maquinas",
"sonido"
],
"rel": [
"musiclm"
],
"lines": 1049,
"t": "AudioLM: modelado de lenguaje sobre audio en tres etapas",
"p": "Wrapper CLI sobre audiolm-pytorch que replica la arquitectura de AudioLM (Google Research, 2022): tratar la generación de audio como un problema de predicción de tokens discretos, igual que un modelo de lenguaje de texto, mediante tres transformers encadenados que operan a distintos niveles de granularidad acústica.",
"a": "La pieza tecnológica subyacente es la cuantización vectorial residual (RVQ) del códec de audio neuronal (SoundStream/EnCodec): en vez de un único libro de códigos, se aplican sucesivos cuantizadores, cada uno codificando el residuo (error) que dejó el anterior, lo que permite representar audio continuo como una secuencia corta de índices discretos con fidelidad ajustable según cuántos niveles residuales se usen.",
"c": "La jerarquía semántico/grueso/fino es una forma de separar contenido y estilo/textura en audio de manera análoga a cómo un pentagrama separa altura y duración de una nota del timbre del instrumento que la toca: los tokens semánticos codifican “qué se está diciendo/tocando” con independencia casi total del timbre, mientras que los niveles acústicos progresivamente más finos añaden la textura sonora concreta — permitiendo, en teoría, generar la misma estructura semántica con distintos timbres, o viceversa.",
"ex": [
"python audiolm.py train-codec",
"python audiolm.py train-semantic",
"python audiolm.py train-coarse",
"python audiolm.py train-fine"
],
"fam": false
},
{
"n": "bass_line_composer",
"st": "ritmo",
"pa": "reglas",
"i": "acordes / texto",
"o": "línea de bajo MIDI",
"les": [
"ritmo",
"taller"
],
"rel": [
"drummer",
"counterpoint"
],
"lines": 2236,
"t": "Línea de bajo como voz compositiva autónoma",
"p": "A diferencia de las líneas de bajo generadas como subproducto de otras herramientas del ecosistema, este módulo trata el bajo como una voz independiente con su propio contrapunto contra la melodía, arco expresivo y lógica estilística, ofreciendo nueve estilos (walking jazz, clásico, barroco, tumbao latino, blues shuffle, pop, pedal, ostinato, y una detección “auto” del estilo más apropiado).",
"a": "El diseño cataloga explícitamente diez “técnicas compositivas” reutilizables entre estilos: notas de aproximación cromáticas y diatónicas (semitono o grado de escala hacia la raíz del siguiente acorde), enclosure (aproximación simultánea desde arriba y abajo), arpegio descendente raíz→7ª→5ª→3ª, notas de paso escalares, anticipación rítmica (atacar la siguiente raíz en el último octavo del compás), repetición rítmica, salto de octava con resolución, pedal armónico y contrapunto melódico por movimiento contrario contra la voz superior.",
"c": "El fichero es, en esencia, una codificación explícita de convenciones estilísticas de acompañamiento: el walking bass de jazz (negra por tiempo, aproximaciones cromáticas), el bajo Alberti clásico, la realización de bajo continuo barroco (movimiento conjunto, preparación-resolución de disonancias), el tumbao cubano (anticipación sincopada característica del son/salsa) y el patrón shuffle de blues (root-5th-6th-b7th con swing).",
"ex": [
"python bass_line_composer.py \"bajo de jazz oscuro en Re menor\"",
"python bass_line_composer.py --key Dm --style walking --bars 16",
"python bass_line_composer.py --key Am --chords \"Am F C G\" --bars 8",
"python bass_line_composer.py --key C --chords \"C Am F G\""
],
"fam": false
},
{
"n": "cadence_designer",
"st": "plan",
"pa": "reglas",
"i": "compases + forma / MIDI",
"o": "plan de cadencias JSON",
"les": [
"armonia",
"forma"
],
"rel": [
"expectation_engine",
"narrator"
],
"lines": 1297,
"t": "Diseñador de arquitectura de cadencias",
"p": "Diseña, desde cero o sobre un esqueleto de obra, la ubicación, tipo y fuerza de cada cadencia (punto de cierre armónico) a lo largo de una pieza, garantizando coherencia narrativa mediante una jerarquía de cierres donde el último es el más fuerte.",
"a": "plan_cadences combina una curva de tensión por compás (generada mediante perfiles predefinidos —arco, crescendo, decrescendo, onda, clímax tardío— o proporcionada explícitamente) con la forma de la obra (ABA, sonata, verso-estribillo, etc.) para determinar cuántas cadencias colocar y en qué posiciones (get_cadence_positions), asignando a cada posición el tipo de cadencia más adecuado según su tensión local, si es la cadencia final, y el modo tonal (select_cadence_for_position).",
"c": "El documento formaliza la jerarquía retórica de las cadencias tonales: la auténtica perfecta (V→I con ambos acordes en estado fundamental) como el cierre más definitivo; la plagal (IV→I, el “Amén” eclesiástico) como cierre suave; la semicadencia (que termina en V) como final “en suspenso”; la engañosa (V→vi) como sorpresa retórica que pospone el cierre;",
"ex": [
"python cadence_designer.py plan --bars 64 --key Am --form sonata",
"python cadence_designer.py strengthen plan.json --intensity 0.6",
"python cadence_designer.py realize plan_ref.json -o bajo_cifrado.json",
"python cadence_designer.py insert esqueleto.mid --plan plan_ref.json"
],
"fam": false
},
{
"n": "chord_copilot",
"st": "armonia",
"pa": "estadistica",
"i": "contexto de acordes + corpus",
"o": "siguiente acorde probable",
"les": [
"armonia",
"maquinas"
],
"rel": [
"chord_progression_generator"
],
"lines": 1597,
"t": "Autocompletado de progresiones por ngramas de corpus",
"p": "Copiloto de progresiones al estilo Hookpad Aria/ChordChord: dado un contexto reciente de acordes, sugiere el acorde más probable a continuación, entrenado estadísticamente sobre un corpus MIDI real mediante modelos de n-gramas, en contraste con chord_progression_generator.py, que genera progresiones completas desde reglas teóricas hardcodeadas.",
"a": "La detección de tonalidad usa el algoritmo de Krumhansl-Schmuckler, implementado de forma autocontenida (correlación entre un histograma de clases de altura ponderado por duración y perfiles tonales empíricos de mayor/menor obtenidos de estudios de percepción tonal), con una vía alternativa opcional a través de music21. La estimación de probabilidades usa suavizado add-k (Laplace generalizado, parámetro --k, por defecto 0.5): sin suavizado, cualquier transición no vista en el corpus de entrenamiento tendría probabilidad cero, lo cual es indeseable en un modelo generativo con datos escasos; add-k redistribuye una pequeña masa de probabilidad hacia todas las transiciones posibles.",
"c": "El sistema formaliza la intuición de que la “gramática” de las progresiones de acordes de un estilo musical concreto (pop, jazz, etc.) es aprendible empíricamente a partir de ejemplos reales, sin necesidad de codificar reglas de teoría armónica explícitas — un enfoque de modelado del lenguaje musical (n-gramas sobre “palabras” armónicas) directamente análogo a los primeros modelos de lenguaje natural basados en n-gramas de palabras.",
"ex": [],
"fam": false
},
{
"n": "chord_pattern_voicer",
"st": "ritmo",
"pa": "reglas",
"i": "MIDI multipista",
"o": "pista de armonía refigurada",
"les": [
"ritmo"
],
"rel": [
"leadsheet_realizer"
],
"lines": 918,
"t": "Reescritura del patrón rítmico de la pista de armonía",
"p": "Detecta automáticamente cuál de las pistas de un MIDI multi-pista es la “pista de armonía” (la más polifónica) y reescribe únicamente esa pista, redistribuyendo temporalmente las notas de cada acorde según un patrón configurable — de bloques simultáneos a arpegios, patrones tipo “bombo-caja”, bajo Alberti, o patrones a medida — dejando intactas el resto de pistas (melodía, bajo, batería).",
"a": "La detección de la pista de armonía usa una métrica de polifonía: se agrupan las notas de cada pista por proximidad de onset y se calcula el tamaño medio de esos grupos (polyphony_score) — una pista de acordes tendrá sistemáticamente varias notas por onset, mientras que una melodía tendrá mayoritariamente grupos de tamaño 1; la pista con mayor polifonía media (excluyendo el canal de batería) se elige como pista de armonía.",
"c": "El módulo formaliza la noción de figuración de acompañamiento: el mismo contenido armónico (el mismo conjunto de notas de un acorde) puede “tocarse” de maneras rítmicamente muy distintas — en bloque (himno), en arpegio (textura pianística romántica), en patrón Alberti (clasicismo vienés) o en “bombo-caja” (imitación de batería popular) — sin alterar en absoluto la armonía subyacente, ilustrando la independencia entre contenido armónico y figuración rítmica.",
"ex": [
"python chord_pattern_voicer.py cancion.mid",
"python chord_pattern_voicer.py cancion.mid --pattern bombo-caja",
"python chord_pattern_voicer.py cancion.mid --pattern alberti --reps 2",
"python chord_pattern_voicer.py cancion.mid --pattern arpeggio-up --reps 2 --gate 0.6"
],
"fam": false
},
{
"n": "chord_progression_generator",
"st": "armonia",
"pa": "reglas",
"i": "texto / curvas / plan",
"o": "progresión (txt · JSON · MIDI)",
"les": [
"armonia",
"taller"
],
"rel": [
"chord_table",
"chord_copilot",
"theorist"
],
"lines": 1256,
"t": "Intención musical → progresión de acordes fundamentada",
"p": "Genera progresiones de acordes desde cero, a partir de una descripción en lenguaje natural (“melancólico y tenso”), de parámetros explícitos (tonalidad, modo, estilo, complejidad), o de planes producidos por otras herramientas del ecosistema (theorist.py, tension_designer.py) — construyendo la progresión desde reglas teóricas puras, sin requerir ningún MIDI de referencia previo.",
"a": "El flujo interno es un pequeño pipeline de cinco etapas: (1) asignación de función armónica (Tónica/Subdominante/Dominante/predominante-Alterado, T/S/D/AD) a cada compás según la curva de tensión objetivo; (2) selección de un pool de patrones candidatos del catálogo, filtrado por estilo y modo; (3) resolución de numerales a acordes concretos; (4) scoring: cada patrón candidato se puntúa por su adecuación a la curva de tensión deseada y por variedad (score_pattern), seleccionándose los N mejores (select_best_patterns); (5) exportación a texto, JSON o MIDI de acordes en bloque.",
"c": "El sistema codifica ocho idiomas armónicos distintos (diatónico, barroco, jazz, modal, romántico, impresionista, pop, flamenco) cada uno como un catálogo de patrones característicos de esa práctica compositiva: la funcionalidad barroca I-V-vi-iii-IV-I-V, el ii-V-I de jazz con tensiones extendidas y sustitución tritonal, el movimiento modal que evita deliberadamente cadencias V-I, las mediantes cromáticas y préstamos modales del romanticismo, el paralelismo de acordes en tonos enteros del impresionismo, los “loops”…",
"ex": [
"python chord_progression_generator.py \"melancolía urbana bajo la lluvia\"",
"python chord_progression_generator.py --key Am --mode minor --style jazz",
"python chord_progression_generator.py --from-theorist obra.theorist.json",
"python chord_progression_generator.py --key Dm --curves curvas.json"
],
"fam": false
},
{
"n": "chord_table",
"st": "armonia",
"pa": "reglas",
"i": "búsqueda por emoción/tensión",
"o": "progresión (txt · JSON · MIDI)",
"les": [
"armonia"
],
"rel": [
"rhythm_table",
"motif_table"
],
"lines": 2541,
"t": "Catálogo curado de 70 progresiones con tensión y emoción",
"p": "Complementa a chord_progression_generator.py: en lugar de construir progresiones algorítmicamente, ofrece un catálogo curado y estático de 70 progresiones etiquetadas con nivel de tensión (escala 1-10) y descriptor emocional explícito, buscable por estilo, modo, emoción, rango de tensión o texto libre, y exportable a texto/JSON/MIDI.",
"a": "resolve_entry expande un patrón catalogado a acordes concretos en una tónica dada, con dos modos de repetición: ajuste al número de compases solicitado (pudiendo truncar el último ciclo) o repetición exacta de la progresión completa un número de veces dado (--reps, sin truncar). midi_to_chord_sequence invierte el proceso: lee un MIDI real y reconstruye una secuencia de acordes limpia a partir de los eventos de nota, permitiendo comparar progresiones reales contra el catálogo.",
"c": "El valor distintivo de esta herramienta frente al generador algorítmico es la etiqueta emocional explícita: cada progresión del catálogo asocia una estructura armónica concreta (p. ej. i-VI-III-VII en modo eolio) con un descriptor perceptual (melancolía, angustia, euforia, exotismo…), codificando de forma curada —no derivada automáticamente— la asociación empírica entre ciertas configuraciones armónicas y su efecto emocional convencional en la práctica compositiva occidental y de otras tradiciones (modo frigio…",
"ex": [
"python chord_table.py --list",
"python chord_table.py --emocion angustia",
"python chord_table.py --style jazz --mode minor",
"python chord_table.py --tension-min 7 --tension-max 10"
],
"fam": false
},
{
"n": "chordgan",
"st": "ensamblaje",
"pa": "estadistica",
"i": "corpus + MIDI",
"o": "MIDI con figuración del corpus",
"les": [
"maquinas",
"representacion"
],
"rel": [
"cycle_gan_style_transfer_v3"
],
"lines": 839,
"t": "Transferencia de estilo condicionada por chroma (ChordGAN sin TensorFlow)",
"p": "Reimplementación, sin TensorFlow y sin arquitectura GAN real, del paper ChordGAN (Lu & Dubnov, UCSD 2021): transfiere el “estilo” pianístico de un corpus MIDI de referencia a un MIDI nuevo, condicionando la generación en el contenido armónico (chroma) del MIDI de entrada, de modo que la armonía original se preserva pero la textura/figuración se sustituye por la aprendida del corpus.",
"a": "El generador original basado en GAN se sustituye por un regresor condicional (Ridge o k-NN, seleccionable) que aprende directamente el mapeo chroma→piano-roll sobre pares extraídos del corpus de entrenamiento (_build_mapper, fit). Se añade una pérdida de ciclo (cycle consistency loss, F(G(x)) ≈ x) mediante un segundo mapeador inverso roll→chroma, siguiendo la misma idea de CycleGAN que en cycle_gan_style_transfer.py: el objetivo es que, tras generar un roll a partir de un chroma y volver a extraer su chroma, se recupere aproximadamente el chroma original, lo cual penaliza transformaciones que destruyan la armonía original en vez de limitarse a reestilizar la figuración.",
"c": "La idea central es la separación entre contenido armónico (qué acordes/notas están sonando, capturado por el chroma, invariante a la octava) y estilo de ejecución/figuración (cómo se distribuyen esas notas en el registro y el tiempo, capturado por el piano roll completo): transferir estilo equivale a mantener fijo el primero y sustituir el segundo por el patrón aprendido de un corpus distinto, un principio de separación de “qué” y “cómo” análogo al usado en chordgan.py para audio y en otras herramientas de…",
"ex": [
"python chordgan.py train --corpus midis_pop/ --model pop.cgan.pkl",
"python chordgan.py train",
"python chordgan.py transfer entrada.mid",
"python chordgan.py analyze --input midis_pop/"
],
"fam": false
},
{
"n": "clara",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI (texto)",
"o": "piezas generadas",
"les": [
"representacion",
"maquinas"
],
"rel": [
"music_transformer"
],
"lines": 1372,
"t": "Generación de música con AWD-LSTM (adaptación del proyecto CLARA)",
"p": "Adaptación del proyecto CLARA (Christine McLeavey et al.) a fichero único: entrena una red recurrente AWD-LSTM (PyTorch + FastAI) sobre un corpus MIDI codificado como texto, y genera piezas nuevas; incluye además un clasificador “crítico” (real vs. generado) y un clasificador de compositores, junto con un servidor HTTP para reproducir y explorar los resultados.",
"a": "El modelo generador es un AWD-LSTM (ASGD Weight-Dropped LSTM, Merity et al. 2017): una LSTM con varias formas de regularización específicas para modelado de lenguaje — DropConnect sobre los pesos recurrentes en vez de sobre las activaciones, embedding dropout, weight tying entre la capa de entrada y salida, y optimización con promedio de pesos vía NT-ASGD — que en su momento fue estado del arte en modelado de lenguaje de texto antes de la era Transformer, aquí reutilizado para modelar secuencias de “palabras musicales”.",
"c": "La codificación chordwise vs. notewise refleja dos formas distintas de “leer” tiempo musical como texto: la primera es fiel a una rejilla temporal fija (como una partitura cuantizada en corcheas), la segunda es fiel a la secuencia real de eventos (más cercana a un MIDI sin cuantizar), con distintas ventajas para el aprendizaje del modelo de lenguaje según la regularidad rítmica del corpus.",
"ex": [
"python clara.py split --example",
"python clara.py train --prefix mi_modelo",
"python clara.py generate --model mi_modelo --output mis_piezas",
"python clara.py encode"
],
"fam": false
},
{
"n": "claude_analyzer",
"st": "analisis",
"pa": "reglas",
"i": "MIDI",
"o": "informe analítico completo",
"les": [
"armonia",
"forma"
],
"rel": [
"harmonic_analyzer"
],
"lines": 11142,
"t": "Analizador musical y emocional de MIDI (11.000 líneas)",
"p": "El fichero más extenso del ecosistema: un analizador exhaustivo de un único MIDI que combina detección de tonalidad, de acordes, de cadencias, de tensión, de expectativa melódica, de conducción de voces y de estructura formal en un único informe textual (con representación ASCII de curvas), producido sección a sección de la obra.",
"a": "La detección de tonalidad usa Krumhansl-Schmuckler, extendida más allá de mayor/menor a los siete modos griegos (dórico, frigio, lidio, mixolidio, locrio), correlacionando el histograma de clases de altura de la obra con perfiles empíricos de cada modo. La curva de tensión nota a nota combina siete factores ponderados: disonancia armónica entre notas simultáneas, tensión del acorde activo (según su función tonal), presencia de sensible, distancia de registro, densidad local, dinámica (velocidad) y distancia armónica a la tónica (centricidad tonal) — una síntesis multi-factorial de indicadores de tensión perceptual bien establecidos en la literatura de cognición musical.",
"c": "El fichero es, en efecto, una codificación computacional muy completa de un curso de análisis auditivo tradicional: tonalidad y modo, funciones armónicas (tónica/subdominante/dominante), cadencias, tensión-distensión, conducción de voces según reglas de contrapunto, y expectativa melódica según teorías cognitivas de la música — todo ello derivado automáticamente de los datos crudos de un MIDI, sin anotación manual previa.",
"ex": [],
"fam": false
},
{
"n": "climax_engineer",
"st": "expresion",
"pa": "reglas",
"i": "obra MIDI",
"o": "obra con clímax en φ",
"les": [
"forma"
],
"rel": [
"silence_designer",
"arc_supervisor"
],
"lines": 312,
"t": "Ingeniería deliberada del punto culminante",
"p": "Mientras arc_supervisor.py detecta si el arco emocional de una obra se cumple, climax_engineer.py lo construye activamente: localiza (por defecto según la proporción áurea, posición 0.618) dónde debe estar el clímax de la pieza, remodela todas las dimensiones de energía hacia ese punto, vacía dramáticamente los compases previos, refuerza el pico con duplicaciones a la octava, y atenúa clímax secundarios que puedan robarle protagonismo al principal.",
"a": "El pipeline tiene seis etapas explícitas: (1) cálculo de la curva de energía real por compás; (2) construcción de la curva objetivo (pico único, asimétrico, con anchura configurable); (3) reescalado de las velocidades de nota por compás para acercar la curva real a la objetivo, con un límite máximo de cambio por paso; (4) “vaciado” — reducción deliberada de dinámica y adelgazamiento de textura en los compases inmediatamente anteriores al pico, técnica retórica de crear expectación por contraste; (5) refuerzo del pico mediante duplicación a la octava de la línea melódica en la ventana alrededor del clímax;",
"c": "Formaliza la técnica retórica del “vacío antes del clímax” (reducir dinámica y densidad justo antes del punto culminante para que el contraste posterior se perciba con más fuerza) y la del refuerzo octava-doblada de la melodía en el clímax, dos recursos orquestales y pianísticos estándar para maximizar el impacto perceptual de un punto culminante.",
"ex": [
"python climax_engineer.py obra.mid",
"python climax_engineer.py obra.mid --position 0.618 --width 4",
"python climax_engineer.py obra.mid --hollow-bars 2 --intensity 0.8",
"python climax_engineer.py obra.mid --no-double --no-hollow"
],
"fam": false
},
{
"n": "cmt_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "acordes",
"o": "melodía (ritmo→altura)",
"les": [
"maquinas"
],
"rel": [
"melody_conditioned_v5"
],
"lines": 1679,
"t": "Generación de melodía condicionada por acordes (Chord-Melody Transformer)",
"p": "Adaptación de una arquitectura de generación de melodía condicionada armónicamente: dado una progresión de acordes, genera una línea melódica coherente mediante un pipeline de tres modelos encadenados — codificador de acordes, decodificador rítmico y decodificador de altura — entrenado en dos fases sobre un corpus de MIDIs orquestales convertidos a formato de dos pistas (melodía + acordes).",
"a": "La arquitectura es un encoder-decoder de tres etapas: un Chord Encoder basado en BiLSTM procesa la secuencia de acordes bidireccionalmente (capturando contexto armónico pasado y futuro para cada punto), cuya salida condiciona dos decodificadores Transformer causales (autorregresivos, con máscara que impide atender al futuro) en cascada: primero el Rhythm Decoder genera la secuencia de duraciones/onsets, y después el Pitch Decoder, condicionado tanto en los acordes como en el ritmo ya generado, decide las alturas concretas.",
"c": "La separación ritmo/altura como dos “capas” independientes del proceso compositivo (decidir primero cuándo suenan las notas, después qué notas son) refleja una intuición pedagógica común en composición: la escritura rítmica y la melódica pueden trabajarse como dimensiones semi-independientes de la línea musical.",
"ex": [
"python cmt_composer.py inspect --input cancion.mid",
"python cmt_composer.py convert     --input-dir midis_orquestales/ --output-dir midis_2pistas/",
"python cmt_composer.py convert     --input-dir midis_orquestales/ --output-dir midis_2pistas/     --melody-track 0",
"python cmt_composer.py convert     --input-dir midis_orquestales/ --output-dir midis_2pistas/     --exclude-drums --exclude-bass --chord-voices 3"
],
"fam": false
},
{
"n": "combined_simplifier",
"st": "practica",
"pa": "busqueda",
"i": "obra de piano",
"o": "versiones grado 1-8",
"les": [
"practica"
],
"rel": [
"combined_simplifier_hybrid_v2"
],
"lines": 2098,
"t": "Reducción pedagógica de dificultad pianística",
"p": "Cinco variantes del ecosistema abordan el mismo problema —convertir una partitura de piano en versiones progresivamente más fáciles de tocar (grados pedagógicos 1 a 8), preservando su identidad armónica y melódica— con distintos grados de sofisticación.",
"a": "Separa la textura pianística en voces de melodía y bajo mediante un algoritmo de tipo skyline (en cada instante, la nota más aguda define la melodía y la más grave el bajo), detecta la armonía por compás, y clasifica cada nota individual según su función tonal no-armónica: tono del acorde, nota de paso, nota de bordado (neighbor tone), apoyatura, suspensión, anticipación, nota escapada — la taxonomía estándar del contrapunto tonal para clasificar disonancias en relación a su preparación y resolución. Cada nota recibe un peso estructural derivado de esta clasificación.",
"c": "El problema pedagógico de “arreglos fáciles” (easy arrangements) de piano se formaliza como optimización con restricciones: minimizar una métrica objetiva de dificultad motriz (velocidad de ejecución, extensión de mano, polifonía, saltos, independencia entre manos) sujeta a la restricción implícita de preservar el “esqueleto” schenkeriano de la obra — es decir, tratando la reducción schenkeriana no como una herramienta puramente analítica sino como una restricción generativa que garantiza identidad musical mínima…",
"ex": [
"python combined_simplifier.py obra.mid --target-grade 1 3 5 7",
"python combined_simplifier.py obra.mid --target-grade 2 --outdir out/",
"python combined_simplifier.py obra.mid --target-grade 4 --split 60",
"python combined_simplifier.py obra.mid --schenker-sequence"
],
"fam": true
},
{
"n": "combined_simplifier_hybrid",
"st": "practica",
"pa": "busqueda",
"i": "obra de piano",
"o": "versiones grado 1-8",
"les": [
"practica"
],
"rel": [
"combined_simplifier_hybrid_v2"
],
"lines": 2577,
"t": "Reducción pedagógica de dificultad pianística",
"p": "Cinco variantes del ecosistema abordan el mismo problema —convertir una partitura de piano en versiones progresivamente más fáciles de tocar (grados pedagógicos 1 a 8), preservando su identidad armónica y melódica— con distintos grados de sofisticación.",
"a": "Separa la textura pianística en voces de melodía y bajo mediante un algoritmo de tipo skyline (en cada instante, la nota más aguda define la melodía y la más grave el bajo), detecta la armonía por compás, y clasifica cada nota individual según su función tonal no-armónica: tono del acorde, nota de paso, nota de bordado (neighbor tone), apoyatura, suspensión, anticipación, nota escapada — la taxonomía estándar del contrapunto tonal para clasificar disonancias en relación a su preparación y resolución. Cada nota recibe un peso estructural derivado de esta clasificación.",
"c": "El problema pedagógico de “arreglos fáciles” (easy arrangements) de piano se formaliza como optimización con restricciones: minimizar una métrica objetiva de dificultad motriz (velocidad de ejecución, extensión de mano, polifonía, saltos, independencia entre manos) sujeta a la restricción implícita de preservar el “esqueleto” schenkeriano de la obra — es decir, tratando la reducción schenkeriana no como una herramienta puramente analítica sino como una restricción generativa que garantiza identidad musical mínima…",
"ex": [
"python combined_simplifier_hybrid.py obra.mid --target-grade 1 3 5 7"
],
"fam": true
},
{
"n": "combined_simplifier_hybrid_v2",
"st": "practica",
"pa": "busqueda",
"i": "obra de piano",
"o": "versiones grado 1-8",
"les": [
"practica"
],
"rel": [
"graded_variations",
"practice_tutor"
],
"lines": 3080,
"t": "Reducción pedagógica de dificultad pianística",
"p": "Cinco variantes del ecosistema abordan el mismo problema —convertir una partitura de piano en versiones progresivamente más fáciles de tocar (grados pedagógicos 1 a 8), preservando su identidad armónica y melódica— con distintos grados de sofisticación.",
"a": "Separa la textura pianística en voces de melodía y bajo mediante un algoritmo de tipo skyline (en cada instante, la nota más aguda define la melodía y la más grave el bajo), detecta la armonía por compás, y clasifica cada nota individual según su función tonal no-armónica: tono del acorde, nota de paso, nota de bordado (neighbor tone), apoyatura, suspensión, anticipación, nota escapada — la taxonomía estándar del contrapunto tonal para clasificar disonancias en relación a su preparación y resolución. Cada nota recibe un peso estructural derivado de esta clasificación.",
"c": "El problema pedagógico de “arreglos fáciles” (easy arrangements) de piano se formaliza como optimización con restricciones: minimizar una métrica objetiva de dificultad motriz (velocidad de ejecución, extensión de mano, polifonía, saltos, independencia entre manos) sujeta a la restricción implícita de preservar el “esqueleto” schenkeriano de la obra — es decir, tratando la reducción schenkeriana no como una herramienta puramente analítica sino como una restricción generativa que garantiza identidad musical mínima…",
"ex": [],
"fam": true
},
{
"n": "combined_simplifier_transformed",
"st": "practica",
"pa": "busqueda",
"i": "obra de piano",
"o": "versiones grado 1-8",
"les": [
"practica"
],
"rel": [
"combined_simplifier_hybrid_v2"
],
"lines": 746,
"t": "Reducción pedagógica de dificultad pianística",
"p": "Cinco variantes del ecosistema abordan el mismo problema —convertir una partitura de piano en versiones progresivamente más fáciles de tocar (grados pedagógicos 1 a 8), preservando su identidad armónica y melódica— con distintos grados de sofisticación.",
"a": "Separa la textura pianística en voces de melodía y bajo mediante un algoritmo de tipo skyline (en cada instante, la nota más aguda define la melodía y la más grave el bajo), detecta la armonía por compás, y clasifica cada nota individual según su función tonal no-armónica: tono del acorde, nota de paso, nota de bordado (neighbor tone), apoyatura, suspensión, anticipación, nota escapada — la taxonomía estándar del contrapunto tonal para clasificar disonancias en relación a su preparación y resolución. Cada nota recibe un peso estructural derivado de esta clasificación.",
"c": "El problema pedagógico de “arreglos fáciles” (easy arrangements) de piano se formaliza como optimización con restricciones: minimizar una métrica objetiva de dificultad motriz (velocidad de ejecución, extensión de mano, polifonía, saltos, independencia entre manos) sujeta a la restricción implícita de preservar el “esqueleto” schenkeriano de la obra — es decir, tratando la reducción schenkeriana no como una herramienta puramente analítica sino como una restricción generativa que garantiza identidad musical mínima…",
"ex": [
"python combined_simplifier_transformed.py obra.mid --target-grade 1 3 5",
"python combined_simplifier_transformed.py obra.mid --target-grade 2"
],
"fam": true
},
{
"n": "combined_simplifier_transformed_2",
"st": "practica",
"pa": "busqueda",
"i": "obra de piano",
"o": "versiones grado 1-8",
"les": [
"practica"
],
"rel": [
"combined_simplifier_hybrid_v2"
],
"lines": 2270,
"t": "Reducción pedagógica de dificultad pianística",
"p": "Cinco variantes del ecosistema abordan el mismo problema —convertir una partitura de piano en versiones progresivamente más fáciles de tocar (grados pedagógicos 1 a 8), preservando su identidad armónica y melódica— con distintos grados de sofisticación.",
"a": "Separa la textura pianística en voces de melodía y bajo mediante un algoritmo de tipo skyline (en cada instante, la nota más aguda define la melodía y la más grave el bajo), detecta la armonía por compás, y clasifica cada nota individual según su función tonal no-armónica: tono del acorde, nota de paso, nota de bordado (neighbor tone), apoyatura, suspensión, anticipación, nota escapada — la taxonomía estándar del contrapunto tonal para clasificar disonancias en relación a su preparación y resolución. Cada nota recibe un peso estructural derivado de esta clasificación.",
"c": "El problema pedagógico de “arreglos fáciles” (easy arrangements) de piano se formaliza como optimización con restricciones: minimizar una métrica objetiva de dificultad motriz (velocidad de ejecución, extensión de mano, polifonía, saltos, independencia entre manos) sujeta a la restricción implícita de preservar el “esqueleto” schenkeriano de la obra — es decir, tratando la reducción schenkeriana no como una herramienta puramente analítica sino como una restricción generativa que garantiza identidad musical mínima…",
"ex": [],
"fam": true
},
{
"n": "completer",
"st": "ensamblaje",
"pa": "busqueda",
"i": "fragmento MIDI",
"o": "continuación (8 estrategias)",
"les": [
"maquinas"
],
"rel": [
"phrase_builder",
"evolver"
],
"lines": 2338,
"t": "Continuación inteligente de obras musicales incompletas",
"p": "Dado un fragmento MIDI (boceto, intro, frase suelta), genera una continuación coherente que respeta el “ADN musical” del original — tonalidad, ritmo, contorno melódico, curvas emocionales, densidad, registro y posición narrativa dentro de una forma mayor. Actúa como orquestador de alto nivel que delega en otras herramientas del ecosistema según la estrategia elegida.",
"a": "Ofrece ocho estrategias intercambiables: cadena de Markov entrenada sobre el propio fragmento (fidelidad estilística orgánica, sin generalizar más allá de las transiciones observadas), extrapolación de contorno melódico (sigue la “inercia” direccional de la melodía), síntesis de la sintaxis antecedente/consecuente (delegando en phrase_builder, aplica la gramática clásica de frase pregunta-respuesta), generación y encadenamiento de variaciones del material existente (variation_engine), búsqueda de fragmentos compatibles en una colección externa y su ensamblaje coherente (harvester + stitcher), inferencia de la posición narrativa dentro de un arco dramático mayor (narrator), evolución…",
"c": "El fichero formaliza la idea de que “continuar” una obra musical no es una única operación bien definida sino una familia de operaciones retóricamente distintas (extender linealmente, rellenar un hueco, desarrollar temáticamente, recapitular con variación, o cerrar con una coda) que corresponden a secciones formales distintas de la forma sonata y de otras formas clásicas.",
"ex": [
"python completer.py fragmento.mid",
"python completer.py fragmento.mid --bars 16",
"python completer.py fragmento.mid --strategy markov --bars 8",
"python completer.py fragmento.mid --strategy phrase --mode develop"
],
"fam": false
},
{
"n": "corpus_explorer",
"st": "analisis",
"pa": "estadistica",
"i": "corpus MIDI",
"o": "salud, índice vectorial, búsqueda",
"les": [
"maquinas"
],
"rel": [
"analyzer"
],
"lines": 3090,
"t": "De la intención musical a la música, sin fricción",
"p": "Flujo de trabajo en cinco pasos, cada uno independiente, que parte de un corpus MIDI sin etiquetar y termina en audio reproducible: diagnóstico de salud del corpus, indexado vectorial, y pasos posteriores de búsqueda semántica y generación (usando la API de Anthropic para interpretar intenciones en lenguaje natural, a juzgar por la dependencia anthropic).",
"a": "El paso health realiza un diagnóstico estadístico sobre una muestra del corpus (por defecto 500 ficheros): porcentaje de archivos utilizables (parseables sin error), histograma de distribución de duraciones, distribución de número de pistas/tempo/densidad, y una estimación del tiempo total de indexado extrapolada de la muestra — un patrón estándar de ingeniería de datos (muestreo para estimar costes de un pipeline sobre el conjunto completo antes de ejecutarlo).",
"c": "Las 10 dimensiones elegidas (más ligeras que las 17 de mscz2vec) representan un compromiso deliberado entre expresividad musical y coste computacional, pensado para operar a la escala de corpus muy grandes donde extraer features con music21 completo sería prohibitivamente lento.",
"ex": [
"python corpus_explorer.py health ./midis/",
"python corpus_explorer.py health ./midis/ --sample 1000",
"python corpus_explorer.py index ./midis/",
"python corpus_explorer.py index ./midis/ --output mi_corpus.npz"
],
"fam": false
},
{
"n": "counterexample",
"st": "ensamblaje",
"pa": "evolutivo",
"i": "deseado + rechazado + referencia",
"o": "candidatos dirigidos por Δ",
"les": [
"maquinas"
],
"rel": [
"evolver",
"preference_trainer"
],
"lines": 1077,
"t": "Composición paramétrica por contraejemplo",
"p": "Dado un MIDI “deseado” (lo que le gusta al usuario), un MIDI “rechazado” (lo que no le gusta) y un MIDI de referencia (material genético de base), calcula el vector diferencial musical entre deseo y rechazo y lo usa como función de fitness dirigida en un algoritmo genético, seleccionando candidatos que se acercan al deseado y se alejan del rechazado.",
"a": "El núcleo matemático es sencillo pero efectivo: se calcula el vector diferencial Δ = vector(deseado) − vector(rechazado), que apunta en la dirección del espacio de características que separa lo que gusta de lo que no gusta; este vector se proyecta sobre el MIDI de referencia (usando la referencia como punto de partida del espacio de búsqueda) y define una función de fitness dirigida: fitness = similitud(candidato, deseado) − λ·similitud(candidato, rechazado) + α·score_musical_intrínseco(candidato).",
"c": "Este es un ejemplo directo de aprendizaje por preferencias con dos ejemplos aplicado a música simbólica: en vez de que el usuario describa explícitamente qué características musicales quiere (densidad, tensión, etc.), basta con mostrar un ejemplo positivo y uno negativo, y el sistema infiere la dirección relevante del espacio de características automáticamente — una alternativa ligera a los modelos de preference learning basados en aprendizaje profundo usados en otras partes del ecosistema (preference_trainer.py).",
"ex": [
"python counterexample.py deseado.mid rechazado.mid referencia.mid",
"python counterexample.py good.mid bad.mid ref.mid --generations 8",
"python counterexample.py good.mid bad.mid ref.mid --repulsion 1.5",
"python counterexample.py good.mid bad.mid ref.mid --top 5 --listen"
],
"fam": false
},
{
"n": "counterpoint",
"st": "melodia",
"pa": "busqueda",
"i": "cantus firmus MIDI",
"o": "voz de contrapunto (especies 1-5)",
"les": [
"voces"
],
"rel": [
"voice_leader",
"harmony_checker"
],
"lines": 2029,
"t": "Motor de contrapunto por especies (Fux / Gradus ad Parnassum)",
"p": "Dado un MIDI de melodía (cantus firmus), genera una segunda voz de contrapunto aplicando las reglas clásicas de contrapunto por especies del tratado Gradus ad Parnassum de Johann Joseph Fux (1725), el texto pedagógico canónico de la disciplina desde hace tres siglos. Funciona tanto en modo standalone como módulo importado por variation_engine, orchestrator y otros.",
"a": "La primera especie (nota contra nota, 1:1) se resuelve mediante backtracking tipo CSP (Constraint Satisfaction Problem): en el modo --strict, las seis reglas clásicas de Fux (H1: solo consonancias verticales; H2: prohibición de quintas justas u octavas paralelas consecutivas; H3: prohibición de movimiento directo hacia una consonancia perfecta; H4: prohibición de cruce de voces; H5: no repetir el mismo intervalo armónico tres veces seguidas;",
"c": "El fichero es una implementación algorítmica directa y bastante fiel del sistema pedagógico de Fux: consonancia/disonancia como restricción vertical, movimiento paralelo/directo/oblicuo/contrario como restricción horizontal entre voces, y la jerarquía de las cinco especies como niveles progresivos de complejidad rítmica sobre el mismo cantus firmus — el punto de partida histórico de toda la teoría de la conducción de voces occidental.",
"ex": [
"python counterpoint.py melodia.mid --species 1 --strict",
"python counterpoint.py melodia.mid --species 1 --strict --voice viola",
"python counterpoint.py melodia.mid --species 2 --strict",
"python counterpoint.py melodia.mid --all-species --strict --key C"
],
"fam": false
},
{
"n": "csl_l2m",
"st": "neuronal",
"pa": "neuronal",
"i": "letra + 14 controles",
"o": "melodía",
"les": [
"maquinas"
],
"rel": [
"lyrics_melody"
],
"lines": 2740,
"t": "Generación controlable de melodía a partir de letra (CSL-L2M, AAAI-2025)",
"p": "Adaptación al estilo de fichero único del sistema CSL-L2M (Controllable SongLevel Lyric-to-Melody, AAAI-2025): genera melodía condicionada tanto en la letra de una canción como en catorce controles musicales explícitos por frase (altura, duración, ritmo, tonalidad, emoción, estructura), usando una arquitectura encoder-decoder Transformer sobre una representación tipo REMI-Aligned.",
"a": "El encoder Transformer procesa la secuencia de letra; el decoder Transformer, autorregresivo, genera la secuencia de eventos melódicos condicionado tanto en la codificación de la letra (vía atención cruzada) como en los 14 controles explícitos por frase. Un módulo VQ-VAE independiente (con TransformerEncoder propio) se entrena para extraer features melódicas latentes discretas — una representación comprimida y aprendida del “estilo” melódico de cada frase, útil tanto como control adicional en la generación como para análisis.",
"c": "El condicionamiento explícito en 14 controles musicales por frase (en vez de dejar que el modelo infiera implícitamente la relación letra-melodía) formaliza intuiciones de composición de canciones: la prosodia del texto (acentuación silábica) debe alinearse con el ritmo melódico, y ciertas emociones textuales correlacionan con ciertos perfiles melódicos y armónicos — controles que un compositor de canciones humano aplicaría de forma más o menos consciente.",
"ex": [
"python csl_l2m.py prepare --input-dir canciones/",
"python csl_l2m.py vocab --events-dir data/events/",
"python csl_l2m.py splits --events-dir data/events/",
"python csl_l2m.py attributes --events-dir data/events/"
],
"fam": false
},
{
"n": "cycle_gan_style_transfer",
"st": "ensamblaje",
"pa": "estadistica",
"i": "dos dominios MIDI",
"o": "MIDI transferido A↔B",
"les": [
"maquinas"
],
"rel": [
"cyclegan_composer"
],
"lines": 1526,
"t": "Transferencia de estilo bidireccional sin redes neuronales",
"p": "Dos versiones (cycle_gan_style_transfer.py v2.0 y cycle_gan_style_transfer_v3.py v3.1) implementan el marco conceptual de CycleGAN (Zhu et al.",
"a": "",
"c": "La segmentación del piano roll en roles (melodía, contrapunto, acompañamiento, bajo, percusión) antes de aplanarlo a vector formaliza la idea de que el “estilo” de un género musical no es un patrón único sino una combinación de patrones específicos por función textural — el bajo de un tango y el bajo de un jazz difieren de forma distinta a como difieren sus respectivas melodías, y tratarlos como subespacios separados permite una transferencia de estilo más fiel a cada rol.",
"ex": [
"python cycle_gan_style_transfer.py train",
"python cycle_gan_style_transfer.py transform entrada.mid"
],
"fam": true
},
{
"n": "cycle_gan_style_transfer_v3",
"st": "ensamblaje",
"pa": "estadistica",
"i": "dos dominios MIDI",
"o": "MIDI transferido A↔B",
"les": [
"maquinas"
],
"rel": [
"cyclegan_composer"
],
"lines": 2744,
"t": "Transferencia de estilo bidireccional sin redes neuronales",
"p": "Dos versiones (cycle_gan_style_transfer.py v2.0 y cycle_gan_style_transfer_v3.py v3.1) implementan el marco conceptual de CycleGAN (Zhu et al.",
"a": "",
"c": "La segmentación del piano roll en roles (melodía, contrapunto, acompañamiento, bajo, percusión) antes de aplanarlo a vector formaliza la idea de que el “estilo” de un género musical no es un patrón único sino una combinación de patrones específicos por función textural — el bajo de un tango y el bajo de un jazz difieren de forma distinta a como difieren sus respectivas melodías, y tratarlos como subespacios separados permite una transferencia de estilo más fiel a cada rol.",
"ex": [
"python cycle_gan_style_transfer_v3.py train",
"python cycle_gan_style_transfer_v3.py transform entrada.mid",
"python cycle_gan_style_transfer_v3.py cycle entrada.mid",
"python cycle_gan_style_transfer_v3.py analyze entrada.mid"
],
"fam": true
},
{
"n": "cyclegan_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "dos dominios",
"o": "transferencia A↔B",
"les": [
"maquinas"
],
"rel": [
"cycle_gan_style_transfer_v3"
],
"lines": 1948,
"t": "CycleGAN neuronal completo sobre piano rolls",
"p": "A diferencia de la familia anterior, esta es una implementación neuronal completa de CycleGAN aplicada a transferencia de estilo entre dos dominios musicales (p. ej. tango ↔ jazz): dos generadores ResNet, dos discriminadores PatchGAN, y las tres pérdidas estándar del marco (adversarial, ciclo, identidad).",
"a": "Los generadores son redes ResNet (bloques residuales, que facilitan el entrenamiento de redes más profundas al permitir que el gradiente fluya directamente a través de las conexiones de salto) con Dropout2d(0.05) en cada bloque residual como regularización adicional, explícitamente calibrada para corpus de entrenamiento pequeños (el caso típico en generación musical, donde los datos etiquetados por estilo son escasos comparado con visión por computador).",
"c": "El condicionamiento por tensión armónica vía AdaIN añade un grado de control ausente en el CycleGAN original de visión: permite pedir explícitamente “transfiere el estilo B pero mantén (o exagera) este nivel de tensión armónica”, separando la dimensión de “género/estilo” de la dimensión de “intensidad dramática”, que en principio son ejes ortogonales de la experiencia musical.",
"ex": [],
"fam": false
},
{
"n": "ddsp_synth",
"st": "sonido",
"pa": "neuronal",
"i": "audio de instrumento",
"o": "resíntesis DDSP",
"les": [
"sonido",
"maquinas"
],
"rel": [
"instrument_cloner"
],
"lines": 1089,
"t": "Síntesis diferenciable de audio (DDSP: Differentiable Digital Signal Processing)",
"p": "Implementación de un autoencoder DDSP (Engel et al., Google Magenta, 2020): aprende a resintetizar un instrumento real a partir de sus features de control (altura fundamental f0 y sonoridad), usando módulos de síntesis clásicos (aditivo armónico + ruido filtrado) que son diferenciables, permitiendo entrenar la red completa de extremo a extremo con descenso de gradiente.",
"a": "El corazón conceptual de DDSP es sustituir una red neuronal generativa “de caja negra” (que tendría que aprender desde cero las leyes de la síntesis de sonido) por módulos de síntesis DSP explícitos y diferenciables, dejando que la red solo aprenda los parámetros de control de esos módulos: (1) síntesis armónica aditiva (harmonic_synth_torch), que genera audio como suma ponderada de sinusoides armónicas de la f0 estimada, con las amplitudes de cada armónico controladas por la red (mediante una exp_sigmoid que garantiza positividad y un rango dinámico amplio, la parametrización estándar del paper original);",
"c": "El principio DDSP formaliza directamente el modelo físico-acústico fuente-filtro: separar la altura fundamental (control de “qué nota”) de la envolvente tímbrica (control de “qué instrumento/color”) y de la componente de ruido (aliento, ataque), permitiendo edición independiente de cada una tras el entrenamiento — algo que un modelo neuronal de caja negra no ofrece de forma nativa.",
"ex": [],
"fam": false
},
{
"n": "diffflow_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "obra (difusión + flujo)",
"les": [
"maquinas"
],
"rel": [
"flow_composer"
],
"lines": 2039,
"t": "Composición end-to-end mediante Diffusion Normalizing Flow (SDE dual)",
"p": "ARQUITECTURA: Dos SDEs neuronales entrenadas conjuntamente sobre el piano roll: forward : dx = f_θ(x,t,cond) dt + g dw   (drift APRENDIDO, no fijo) backward: dx = [f_θ(x,t,cond) - g²·s_θ(x,t,cond)] dt + g dw Se entrena minimizando KL(p_forward‖p_backward) sobre la trayectoria completa (Zhang & Chen, \"Diffusion Normalizing Flow\", NeurIPS 2021).",
"a": "",
"c": "",
"ex": [
"python diffflow_composer.py prepare --input-dir midis/ --output-dir data/ --report",
"python diffflow_composer.py prepare     --input-dir midis/ --output-dir data_small/     --disable-roles percussion counterpoint     --pitch-range 48",
"python diffflow_composer.py train     --data-dir data/ --model-dir model_diffflow/     --epochs 300 --batch-size 8 --lr 1e-4     --style-dim 16 --hidden-channels 64     --sde-steps 24 --g-coef 1.0 --patience 50",
"python diffflow_composer.py train     --data-dir data/ --model-dir model_diffflow/ --epochs 300 --resume"
],
"fam": false
},
{
"n": "diffusion_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "obra por difusión",
"les": [
"maquinas"
],
"rel": [
"diffusion_composer_v4"
],
"lines": 2741,
"t": "Composición end-to-end mediante difusión",
"p": "Tres versiones progresivas (diffusion_composer.py v0.1, diffusion_composer_v3.py y diffusion_composer_v4.py, ambas v3 con correcciones incrementales entre sí) abordan la composición completa de una obra multi-rol mediante modelos de difusión probabilística (DDPM), con una diferencia arquitectónica central entre la v0.1 y las v3/v4.",
"a": "Ambas familias exponen los mismos cuatro modos de composición: sample (generación pura desde ruido), denoise (parte de un MIDI de referencia con ruido parcial añadido —controlado por --strength— y lo “limpia” parcialmente, produciendo una variación cercana al original), blend (interpola entre dos estilos latentes) y sweep (recorre un parámetro continuamente para explorar el espacio). El muestreo usa el esquema DDIM acelerado (--ddim-steps, con --eta controlando la estocasticidad: 0 = determinista) en vez de los mil pasos completos del DDPM original, y un parámetro de --temperature para controlar la aleatoriedad del muestreo final.",
"c": "El condicionamiento explícito en un vector de tensión armónica (calculado con la misma heurística multi-factor que otras herramientas del ecosistema) permite guiar el proceso generativo con una noción musical de alto nivel además del propio “estilo” latente, combinando control estructural (dónde quiero tensión) con control estilístico (qué género/corpus).",
"ex": [
"python diffusion_composer.py prepare --input-dir midis/ --output-dir data/",
"python diffusion_composer.py train   --data-dir data/  --model-dir model/",
"python diffusion_composer.py encode  --input ref.mid   --model-dir model/",
"python diffusion_composer.py compose --mode sample --model-dir model/"
],
"fam": true
},
{
"n": "diffusion_composer_v3",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "obra por difusión",
"les": [
"maquinas"
],
"rel": [
"diffusion_composer_v4"
],
"lines": 3212,
"t": "Composición end-to-end mediante difusión",
"p": "Tres versiones progresivas (diffusion_composer.py v0.1, diffusion_composer_v3.py y diffusion_composer_v4.py, ambas v3 con correcciones incrementales entre sí) abordan la composición completa de una obra multi-rol mediante modelos de difusión probabilística (DDPM), con una diferencia arquitectónica central entre la v0.1 y las v3/v4.",
"a": "Ambas familias exponen los mismos cuatro modos de composición: sample (generación pura desde ruido), denoise (parte de un MIDI de referencia con ruido parcial añadido —controlado por --strength— y lo “limpia” parcialmente, produciendo una variación cercana al original), blend (interpola entre dos estilos latentes) y sweep (recorre un parámetro continuamente para explorar el espacio). El muestreo usa el esquema DDIM acelerado (--ddim-steps, con --eta controlando la estocasticidad: 0 = determinista) en vez de los mil pasos completos del DDPM original, y un parámetro de --temperature para controlar la aleatoriedad del muestreo final.",
"c": "El condicionamiento explícito en un vector de tensión armónica (calculado con la misma heurística multi-factor que otras herramientas del ecosistema) permite guiar el proceso generativo con una noción musical de alto nivel además del propio “estilo” latente, combinando control estructural (dónde quiero tensión) con control estilístico (qué género/corpus).",
"ex": [
"python diffusion_composer_v3.py train     --data-dir data/     --model-dir model_diff_v3/     --epochs 300     --batch-size 8     --lr 1e-4     --style-dim 16     --diffusion-steps 1000     --patience 50",
"python diffusion_composer_v3.py compose     --model-dir model_diff_v3/ --palette palette.json     --mode denoise --input midis/005505b_.mid     --strength 0.3 --ddim-steps 50 --eta 0.0     --temperature 1.0 --bars 16     --threshold-pct 99.0",
"python diffusion_composer_v3.py compose     --model-dir model_diff_v3/ --palette palette.json     --mode sweep     --inputs midis/005505b_.mid midis/008906b_.mid     --bars 32     --ddim-steps 50 --eta 0.0     --temperature 1.0     --threshold-pct 99.0",
"python diffusion_composer_v3.py compose     --model-dir model_diff_v3/ --palette palette.json     --mode blend     --inputs midis/005505b_.mid midis/008906b_.mid     --weights 0.5 0.5     --bars 16     --ddim-steps 50 --eta 0.0     --threshold-pct 99.0"
],
"fam": true
},
{
"n": "diffusion_composer_v4",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "obra por difusión",
"les": [
"maquinas"
],
"rel": [
"latent_composer",
"flow_composer"
],
"lines": 3402,
"t": "Composición end-to-end mediante difusión",
"p": "Tres versiones progresivas (diffusion_composer.py v0.1, diffusion_composer_v3.py y diffusion_composer_v4.py, ambas v3 con correcciones incrementales entre sí) abordan la composición completa de una obra multi-rol mediante modelos de difusión probabilística (DDPM), con una diferencia arquitectónica central entre la v0.1 y las v3/v4.",
"a": "Ambas familias exponen los mismos cuatro modos de composición: sample (generación pura desde ruido), denoise (parte de un MIDI de referencia con ruido parcial añadido —controlado por --strength— y lo “limpia” parcialmente, produciendo una variación cercana al original), blend (interpola entre dos estilos latentes) y sweep (recorre un parámetro continuamente para explorar el espacio). El muestreo usa el esquema DDIM acelerado (--ddim-steps, con --eta controlando la estocasticidad: 0 = determinista) en vez de los mil pasos completos del DDPM original, y un parámetro de --temperature para controlar la aleatoriedad del muestreo final.",
"c": "El condicionamiento explícito en un vector de tensión armónica (calculado con la misma heurística multi-factor que otras herramientas del ecosistema) permite guiar el proceso generativo con una noción musical de alto nivel además del propio “estilo” latente, combinando control estructural (dónde quiero tensión) con control estilístico (qué género/corpus).",
"ex": [],
"fam": true
},
{
"n": "drummer",
"st": "ritmo",
"pa": "reglas",
"i": "MIDI (+biblioteca de grooves)",
"o": "MIDI con batería",
"les": [
"ritmo",
"taller"
],
"rel": [
"rhythm_table",
"bass_line_composer"
],
"lines": 3560,
"t": "Motor de percusión rítmica con catálogo de arquetipos estilísticos",
"p": "Añade una pista de batería estilísticamente coherente a una obra MIDI existente, con un flujo de trabajo que va desde aprender grooves de una colección personal (learn), extraer y nombrar patrones favoritos (extract), añadir percusión a una obra nueva (add), y transformarla o evolucionarla (transform/morph).",
"a": "El comando learn extrae estadísticamente patrones rítmicos de una colección de MIDIs de referencia, construyendo una biblioteca de grooves reutilizables — un enfoque de generación por corpus en vez de reglas puramente hardcodeadas, aunque el catálogo de arquetipos por defecto sí codifica reglas específicas por estilo (p. ej. bossa nova: clave 3-2, maracas en negras, bombo suave; reggae one-drop: bombo desplazado al tercer tiempo en vez del primero, la característica distintiva del estilo).",
"c": "El catálogo de arquetipos codifica rasgos rítmicos distintivos de tradiciones de percusión muy dispares — la clave (patrón asimétrico de referencia rítmica de la música afrocubana, en sus variantes 2-3 y 3-2), el backbeat seco del rock (acento en los tiempos 2 y 4), el patrón one-drop del reggae, y el triplillo swing del ride de jazz —, formalizando en cada caso la relación característica entre el bombo, la caja y el elemento de color (hihat/ride/maracas) que define auditivamente el género.",
"ex": [
"python drummer.py add melodia.mid --style jazz_ride",
"python drummer.py add melodia.mid --style flamenco",
"python drummer.py add melodia.mid --style funk_16th --library lib.json",
"python drummer.py add --list-styles"
],
"fam": false
},
{
"n": "ear_trainer",
"st": "practica",
"pa": "reglas",
"i": "tipo + nivel",
"o": "dictados MIDI + solucionario",
"les": [
"practica",
"armonia"
],
"rel": [
"etude_generator"
],
"lines": 303,
"t": "Generador de dictados de entrenamiento auditivo",
"p": "El oído es, según el propio docstring, “la mitad de aprender a componer y a tocar”, y el ecosistema carecía de una herramienta dedicada a entrenarlo: genera ejercicios de dictado musical reproducibles como MIDI (intervalos, calidades de acorde, progresiones armónicas cortas) junto con un solucionario separado, siguiendo el modelo pedagógico clásico del entrenamiento auditivo (ear training).",
"a": "Para intervals, se muestrean dos notas (melódicas —secuenciales— o armónicas —simultáneas, según --harmonic) separadas por un intervalo elegido de un repertorio que se amplía según el nivel de dificultad (--level easy|medium|hard); el “solucionario” es simplemente el nombre teórico del intervalo generado. Para chords, se genera un acorde con una calidad concreta (mayor, menor, disminuido, aumentado, con séptima…) elegida del repertorio de nivel correspondiente. Para progressions, se genera una secuencia de 2 a 4 acordes en una tonalidad dada, con el solucionario en numerales romanos.",
"c": "El diseño refleja directamente la progresión pedagógica estándar del solfeo auditivo: primero intervalos aislados (la unidad perceptual más básica), después acordes completos (percepción vertical simultánea), y finalmente progresiones armónicas cortas (percepción de la función tonal en contexto) — los tres niveles clásicos de un curso de entrenamiento auditivo de conservatorio.",
"ex": [
"python ear_trainer.py --type intervals --count 12",
"python ear_trainer.py --type intervals --harmonic --seed 7",
"python ear_trainer.py --type chords --count 10",
"python ear_trainer.py --type progressions --key G --count 8"
],
"fam": false
},
{
"n": "etude_generator",
"st": "practica",
"pa": "reglas",
"i": "tonalidad + tipo",
"o": "escalas, arpegios, Hanon, cadencias",
"les": [
"practica"
],
"rel": [
"practice_tutor"
],
"lines": 402,
"t": "Generador de ejercicios técnicos de piano",
"p": "Complementa a fingering.py (que calcula digitación para una pieza ya dada): genera desde cero material técnico diario de estudio pianístico —escalas, arpegios, acordes quebrados tipo Alberti, patrones de cinco dedos al estilo Hanon, y cadencias armónicas con enlace de voces— en cualquier tonalidad y modo, con digitación estándar ya anotada.",
"a": "El generador de cadencias implementa la fórmula armónica de enlace de voces clásica I–IV–I⁶⁄₄–V–I (tónica, subdominante, tónica en segunda inversión como preparación ornamental de la dominante, dominante, tónica), con las reglas estándar de conducción de voces (movimiento por el intervalo más pequeño posible, resolución de la sensible) entre cada acorde consecutivo. El patrón Hanon (hanon) reproduce la figura característica del primer ejercicio de The Virtuoso Pianist de Charles-Louis Hanon: un patrón de cinco notas ascendentedescendente que se transpone grado a grado a lo largo de la escala completa.",
"c": "El fichero formaliza el currículo técnico estándar de la pedagogía pianística clásica (escalas y arpegios en todas las tonalidades, ejercicios mecánicos de independencia digital, cadencias armónicas básicas), con la digitación convencional ya resuelta algorítmicamente en vez de dejada a interpretación del estudiante.",
"ex": [
"python etude_generator.py --type scale --key C --octaves 2",
"python etude_generator.py --type scale --key A --mode harmonic_minor",
"python etude_generator.py --type arpeggio --key G --hands right",
"python etude_generator.py --type hanon --key C --tempo 100"
],
"fam": false
},
{
"n": "evolver",
"st": "ensamblaje",
"pa": "evolutivo",
"i": "N fragmentos MIDI",
"o": "variantes evolucionadas",
"les": [
"maquinas"
],
"rel": [
"counterexample",
"midi_dna_unified"
],
"lines": 842,
"t": "Motor de evolución genética de secciones MIDI",
"p": "Toma N fragmentos MIDI como “genes” de una población inicial, genera variantes por cruce y mutación, las puntúa automáticamente usando el sistema de scoring de midi_dna_unified (consonancia, variedad, arco expresivo) y selecciona las mejores durante varias generaciones — un algoritmo genético clásico aplicado a composición musical, que sirve de motor reutilizable para otras herramientas del ecosistema (counterexample.py, completer.py).",
"a": "Los operadores de cruce (crossover) combinan material de dos padres a lo largo de tres dimensiones independientes: contorno melódico, progresión armónica y patrón rítmico — permitiendo, por ejemplo, heredar el contorno melódico de un padre pero la armonía del otro. Los operadores de mutación cubren cinco tipos: desplazamiento de intervalo (±1-3 semitonos en notas aleatorias), escalado de duraciones rítmicas, variación de tempo (±5-15 BPM), transposición modal (al relativo o a la dominante) y sesgo en las curvas emocionales de tensión/arousal.",
"c": "Separar los operadores de cruce por dimensión musical independiente (contorno, armonía, ritmo) en vez de operar sobre la representación MIDI cruda refleja la intuición de que estas tres dimensiones son parcialmente independientes en la percepción musical y pueden recombinarse de forma más significativa por separado que a nivel de bytes o eventos MIDI.",
"ex": [
"python evolver.py fuente1.mid fuente2.mid [más MIDIs]",
"python evolver.py *.mid --generations 10 --population 20",
"python evolver.py a.mid b.mid --generations 5 --elite 3",
"python evolver.py a.mid b.mid --mode full_blend --bars 32"
],
"fam": false
},
{
"n": "expectation_engine",
"st": "armonia",
"pa": "reglas",
"i": "obra MIDI",
"o": "obra con expectativas manipuladas",
"les": [
"armonia",
"forma"
],
"rel": [
"cadence_designer",
"climax_engineer"
],
"lines": 355,
"t": "Manipulación de expectativas armónicas (Meyer/Huron)",
"p": "Fundamentado explícitamente en la teoría de la emoción musical de Leonard Meyer y David Huron (Sweet Anticipation): la emoción musical surge de generar expectativas y luego retrasarlas, negarlas o cumplirlas en el momento adecuado. Localiza los puntos de resolución previstos (cadencias V→I) e inyecta “dispositivos” retóricos que manipulan esa expectativa, reservando la resolución plena para el clímax final.",
"a": "Cuatro dispositivos retóricos formalizados algorítmicamente: cadencia rota (la dominante que “debería” resolver en tónica se redirige a la submediante, V→vi — la resolución esperada se niega); suspensión (la nota melódica previa se prolonga por encima del cambio de acorde, retrasando su resolución — el clásico retardo 4-3 del contrapunto); apoyatura (nota extraña acentuada sobre el objetivo melódico esperado, que resuelve descendiendo, generando una sensación de anhelo momentáneo); evasión (el bajo de la resolución se desplaza a la tercera del acorde —primera inversión— en vez de a la fundamental, debilitando la llegada).",
"c": "El fichero es una implementación computacional directa de la teoría “expectativa-tensión-resolución” (ETR) de la cognición musical: cada dispositivo corresponde a una técnica retórica documentada en la literatura de análisis musical (retardo, apoyatura, cadencia rota/evadida) reinterpretada explícitamente como una manipulación deliberada de la predicción implícita que un oyente hace sobre “qué viene después” en una progresión tonal familiar.",
"ex": [
"python expectation_engine.py obra.mid",
"python expectation_engine.py obra.mid --devices cadencia_rota suspension",
"python expectation_engine.py obra.mid --density 0.5 --seed 7",
"python expectation_engine.py obra.mid --climax-resolve"
],
"fam": false
},
{
"n": "expressive_injector",
"st": "expresion",
"pa": "reglas",
"i": "MIDI",
"o": "MIDI con recursos expresivos",
"les": [
"interpretacion"
],
"rel": [
"performer",
"expressive_resources"
],
"lines": 1733,
"t": "Inyección de un recurso expresivo en un compás concreto (piano RH/LH)",
"p": "Complementario a expressive_resources.py: introduce un recurso expresivo (rítmico, melódico, armónico o dinámico) en un compás concreto de un MIDI de piano con manos separadas (RH/LH), modificando las notas (o el tempo) existentes para materializarlo, y escribe un nuevo fichero .mid con el resultado.",
"a": "",
"c": "",
"ex": [],
"fam": false
},
{
"n": "expressive_resources",
"st": "expresion",
"pa": "reglas",
"i": "—",
"o": "catálogo de recursos expresivos (módulo)",
"les": [
"interpretacion"
],
"rel": [
"expressive_injector"
],
"lines": 1445,
"t": "Detección y explicación de recursos expresivos en piano a dos manos",
"p": "Detecta recursos expresivos (rítmicos, melódicos, armónicos y dinámicos) en un MIDI de piano con separación estándar de mano derecha (RH) / mano izquierda (LH), e indica por cada hallazgo: recurso, compás, intención expresiva y explicación en lenguaje natural. Recursos soportados (usa 'list-resources' para el detalle): Rítmicos:   sincopa, contratiempo, hemiola, rubato*, agogica*, polirritmia Melódicos:  apoyatura, floreo, anticipacion, escapada, nota_de_paso_cromatica Armónicos:  acorde_disminuido,…",
"a": "",
"c": "",
"ex": [],
"fam": false
},
{
"n": "fingering",
"st": "practica",
"pa": "busqueda",
"i": "MIDI de piano",
"o": "digitación",
"les": [
"practica"
],
"rel": [
"fingering_v6"
],
"lines": 605,
"t": "Digitación pianística automática (v1 → v3) y su puente a Synthesia",
"p": "Tres versiones sucesivas implementan y refinan un optimizador de digitación pianística automática a partir de MIDI, basado conceptualmente en el proyecto pianoplayer de Marco Musy, más una herramienta de exportación al formato de la aplicación Synthesia.",
"a": "Búsqueda por ventana deslizante de 9 notas: en vez de optimizar la digitación de toda la pieza de una vez (intratable combinatoriamente) ni nota a nota de forma puramente voraz (miope, ignora contexto), se optimiza una ventana local de 9 notas consecutivas a la vez, deslizándola progresivamente — un compromiso entre calidad de la solución y tractabilidad computacional.",
"c": "",
"ex": [
"python fingering.py archivo.mid",
"python fingering.py archivo.mid --hand-size L",
"python fingering.py archivo.mid --measures 8",
"python fingering.py archivo.mid --right-only"
],
"fam": true
},
{
"n": "fingering_to_synthesia",
"st": "practica",
"pa": "infra",
"i": "digitación JSON",
"o": ".synthesia",
"les": [
"practica"
],
"rel": [
"fingering_v6"
],
"lines": 746,
"t": "Puente de la digitación al formato de Synthesia",
"p": "te la digitación JSON producida por fingering_v3.py al formato propietario .synthesia (gramática LocalFingerInfoList/FingerInfo): dígitos 1-5 codifican mano izquierda (pulgar a meñique), 6-9 y 0 codifican mano derecha, con marcadores especiales para cambio de pista (tN:) y salto de compás (mN:).",
"a": "",
"c": "El problema de digitación pianística es, formalmente, un problema de optimización de camino de coste mínimo sobre un grafo cuyos nodos son asignaciones dedo-nota y cuyas aristas están ponderadas por el coste ergonómico de la transición entre dos posiciones consecutivas de la mano — la misma estructura matemática que la alineación de secuencias, aplicada aquí al espacio físico del teclado.",
"ex": [
"python fingering_to_synthesia.py digitacion.json -o salida.synthesia",
"python fingering_to_synthesia.py digitacion.json -o salida.synthesia --hash a48d1b2c62fc908118333dee270986a3",
"python fingering_to_synthesia.py digitacion.json -o merged.synthesia         --existing LocalFingerInfo.xml --hash a48d1b2c62fc908118333dee270986a3",
"python fingering_to_synthesia.py digitacion.json -o salida.synthesia --track-right 0 --track-left 1"
],
"fam": false
},
{
"n": "fingering_v2",
"st": "practica",
"pa": "busqueda",
"i": "MIDI de piano",
"o": "digitación",
"les": [
"practica"
],
"rel": [
"fingering_v6"
],
"lines": 1039,
"t": "Digitación v2: memoria de postura, tempo variable, confianza",
"p": "postura (relocation_alpha=0.3): el coste de una nueva posición de mano no depende solo de la comodidad absoluta sino que se pondera hacia la posición de mano anterior, penalizando reposicionamientos innecesarios (un pianista real prefiere mantener la mano donde está si es razonablemente cómodo, en vez de re-optimizar continuamente desde cero).",
"a": "",
"c": "",
"ex": [
"python fingering_v2.py archivo.mid",
"python fingering_v2.py archivo.mid --hand-size L",
"python fingering_v2.py archivo.mid --measures 8",
"python fingering_v2.py archivo.mid --right-only"
],
"fam": false
},
{
"n": "fingering_v3",
"st": "practica",
"pa": "busqueda",
"i": "MIDI de piano",
"o": "digitación JSON",
"les": [
"practica"
],
"rel": [
"fingering_v6"
],
"lines": 1231,
"t": "Digitación v3: separación de voces internas",
"p": "de una misma pista: distingue notas de melodía (cortas) de notas de una voz sostenida simultánea (tenor/bajo, de mayor duración relativa al pulso), clasificando cada nota por su duración relativa al beat y comprobando si coincide temporalmente con una nota de melodía — permitiendo digitar de forma independiente una voz sostenida (p.",
"a": "",
"c": "",
"ex": [
"python fingering_v3.py archivo.mid",
"python fingering_v3.py archivo.mid --confidence"
],
"fam": false
},
{
"n": "fingering_v4",
"st": "practica",
"pa": "busqueda",
"i": "MIDI de piano",
"o": "digitación (+acordes)",
"les": [
"practica"
],
"rel": [
"fingering_v6"
],
"lines": 1689,
"t": "Digitación pianística automática (v1 → v3) y su puente a Synthesia",
"p": "Tres versiones sucesivas implementan y refinan un optimizador de digitación pianística automática a partir de MIDI, basado conceptualmente en el proyecto pianoplayer de Marco Musy, más una herramienta de exportación al formato de la aplicación Synthesia.",
"a": "Búsqueda por ventana deslizante de 9 notas: en vez de optimizar la digitación de toda la pieza de una vez (intratable combinatoriamente) ni nota a nota de forma puramente voraz (miope, ignora contexto), se optimiza una ventana local de 9 notas consecutivas a la vez, deslizándola progresivamente — un compromiso entre calidad de la solución y tractabilidad computacional.",
"c": "",
"ex": [
"python fingering_v4.py archivo.mid --chords --chord-weight 1.0 --chord-report",
"python fingering_v4.py archivo.mid"
],
"fam": true
},
{
"n": "fingering_v5",
"st": "practica",
"pa": "busqueda",
"i": "MIDI de piano",
"o": "digitación",
"les": [
"practica"
],
"rel": [
"fingering_v6"
],
"lines": 2373,
"t": "Digitación pianística automática (v1 → v3) y su puente a Synthesia",
"p": "Tres versiones sucesivas implementan y refinan un optimizador de digitación pianística automática a partir de MIDI, basado conceptualmente en el proyecto pianoplayer de Marco Musy, más una herramienta de exportación al formato de la aplicación Synthesia.",
"a": "Búsqueda por ventana deslizante de 9 notas: en vez de optimizar la digitación de toda la pieza de una vez (intratable combinatoriamente) ni nota a nota de forma puramente voraz (miope, ignora contexto), se optimiza una ventana local de 9 notas consecutivas a la vez, deslizándola progresivamente — un compromiso entre calidad de la solución y tractabilidad computacional.",
"c": "",
"ex": [],
"fam": true
},
{
"n": "fingering_v6",
"st": "practica",
"pa": "busqueda",
"i": "MIDI de piano",
"o": "digitación JSON",
"les": [
"practica"
],
"rel": [
"fingering_to_synthesia"
],
"lines": 2466,
"t": "Digitación pianística automática (v1 → v3) y su puente a Synthesia",
"p": "Tres versiones sucesivas implementan y refinan un optimizador de digitación pianística automática a partir de MIDI, basado conceptualmente en el proyecto pianoplayer de Marco Musy, más una herramienta de exportación al formato de la aplicación Synthesia.",
"a": "Búsqueda por ventana deslizante de 9 notas: en vez de optimizar la digitación de toda la pieza de una vez (intratable combinatoriamente) ni nota a nota de forma puramente voraz (miope, ignora contexto), se optimiza una ventana local de 9 notas consecutivas a la vez, deslizándola progresivamente — un compromiso entre calidad de la solución y tractabilidad computacional.",
"c": "",
"ex": [],
"fam": true
},
{
"n": "flow_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "obra por flujos normalizadores",
"les": [
"maquinas"
],
"rel": [
"diffusion_composer_v4"
],
"lines": 1998,
"t": "Composición mediante Normalizing Flows condicionales",
"p": "Genera obras multi-rol completas usando flujos normalizadores (normalizing flows, familia RealNVP/Glow) condicionales sobre el piano roll, en contraste explícito con los enfoques VAE (pérdida por reconstrucción aproximada) y difusión (proceso iterativo estocástico) usados en otras herramientas del ecosistema: un flujo normalizador es una biyección exacta entre el espacio de datos y un espacio latente gaussiano, por lo que la reconstrucción x→z→x es perfecta salvo el ruido de dequantización — propiedad que se…",
"a": "La arquitectura apila K “pasos de flujo”, cada uno compuesto de tres transformaciones invertibles encadenadas: ActNorm (normalización por activación, análoga a batch norm pero con parámetros por canal inicializados a partir del primer batch, e invertible exactamente), una convolución 1×1 invertible (generaliza la permutación fija de canales de RealNVP a una mezcla lineal aprendida, invertible por construcción al parametrizarse como matriz con descomposición LU o similar), y un acoplamiento afín (affine coupling layer) con máscara tipo tablero de ajedrez (checkerboard): se particiona el tensor en dos mitades según un patrón fijo, una mitad se deja sin cambios y la otra se transforma…",
"c": "La ventaja distintiva de los flujos frente a VAE/difusión para composición es la invertibilidad exacta: permite operaciones deterministas y perfectamente reversibles entre MIDI real y espacio latente, útil para tareas de edición precisa (mover un punto en el espacio latente y volver a decodificar sabiendo exactamente qué combinación de “estilo” se está variando) sin la pérdida de fidelidad inherente a la reconstrucción aproximada de un autoencoder variacional.",
"ex": [
"python flow_composer.py prepare --input-dir midis/ --output-dir data/ --report",
"python flow_composer.py prepare     --input-dir midis/ --output-dir data_small/     --disable-roles percussion counterpoint     --pitch-range 48",
"python flow_composer.py train     --data-dir data/ --model-dir model_flow/     --epochs 300 --batch-size 8 --lr 1e-4     --style-dim 16 --flow-steps 8 --hidden-channels 64 --patience 50",
"python flow_composer.py encode --input midis/005505b_.mid     --model-dir model_flow/ --output z_estilo_A.json"
],
"fam": false
},
{
"n": "generar_midi",
"st": "ensamblaje",
"pa": "reglas",
"i": "partitura.yaml",
"o": "MIDIs por sección/frase/stem",
"les": [
"representacion",
"taller"
],
"rel": [
"midi2yaml"
],
"lines": 3822,
"t": "Sistema de composición YAML + Python para una obra concreta",
"p": "A diferencia de la mayoría de herramientas del ecosistema (genéricas, aplicables a cualquier MIDI de entrada), este es un sistema de producción a medida para una obra orquestal concreta de Pablo (“Entre el Tango y el Abismo”, según el contexto del ecosistema): lee una partitura completa especificada en YAML declarativo (partitura.yaml) y genera los ficheros MIDI correspondientes, sección por sección, frase por frase, con soporte de stems por instrumento, exportación por leitmotiv, comparación de versiones…",
"a": "build_chord_from_degree construye acordes por grado modal (I-VII, en notación romana o numérica) resolviendo la calidad del acorde según el modo activo en ese momento — es decir, un sistema de armonía modal explícito donde el mismo grado numérico produce un acorde de calidad distinta según si la obra está en modo jónico, dórico, frigio, etc., en vez de asumir siempre la convención mayor/menor implícita. _build_modal_voicing resuelve la disposición concreta de las voces (raíz en el bajo más tres voces superiores) para cada acorde.",
"c": "El sistema de modos declarado (14 escalas, incluyendo escalas no diatónicas como la octatónica —alternancia tono-semitono, de uso característico en Stravinsky y el jazz modal— y la doble armónica —con dos segundas aumentadas, de sonoridad “oriental” característica) permite que una misma estructura formal de frases y leitmotivs se reinterprete armónicamente de formas radicalmente distintas simplemente cambiando el parámetro de modo declarado en el YAML.",
"ex": [
"python generar_midi.py",
"python generar_midi.py --seccion I",
"python generar_midi.py --frase I.2",
"python generar_midi.py --preview"
],
"fam": false
},
{
"n": "genetic_style_transfer_v3",
"st": "ensamblaje",
"pa": "evolutivo",
"i": "colecciones origen/destino",
"o": "MIDI reestilizado",
"les": [
"maquinas"
],
"rel": [
"style_transfer"
],
"lines": 2871,
"t": "Transferencia de estilo por algoritmo genético + modelo aprendido",
"p": "Aprende transformaciones estilísticas entre una colección de MIDIs “origen” y una colección “destino” (p. ej. arreglos simples → arreglos jazzísticos) y las aplica a un MIDI nuevo, combinando un modelo de transformación aprendido (entrenado y reutilizable, serializado a .pkl) con mecanismos de aplicación granular, verbosa e incluso manual sin modelo entrenado.",
"a": "El modo apply permite aplicar parámetros de transformación concretos sin necesidad de modelo entrenado, útil para exploración manual del espacio de transformaciones; block ejecuta la transformación normal pero neutraliza selectivamente ciertos operadores indicados en --block, mostrando explícitamente el impacto marginal de cada operador individual sobre el resultado — una forma de análisis de sensibilidad ablation-style aplicado a un sistema de transformación musical, permitiendo entender qué parte de la “reestilización” aporta cada componente del modelo.",
"c": "La capacidad de bloquear operadores individuales y observar el resultado formaliza una forma de interpretabilidad por ablación aplicada a transformación de estilo musical: en vez de tratar la reestilización como una caja negra, el sistema permite atribuir el cambio percibido a componentes concretos (p. ej. “el 40% del cambio de carácter proviene solo de la reescritura rítmica, el resto de la reescritura armónica”).",
"ex": [],
"fam": false
},
{
"n": "genopatch",
"st": "sonido",
"pa": "evolutivo",
"i": "WAV objetivo",
"o": "parámetros de síntesis",
"les": [
"sonido",
"maquinas"
],
"rel": [
"genopatch_v2"
],
"lines": 1031,
"t": "Matching de patches de síntesis por búsqueda evolutiva e inferencia amortizada",
"p": "Tres ficheros abordan el mismo problema —el “problema inverso” del sonido: dado un WAV objetivo, encontrar los parámetros de un motor de síntesis paramétrico que mejor lo reproduzcan— con dos paradigmas algorítmicos distintos, inspirados en el “Genopatch” de Synplant 2 (Sonic Charge) pero sin red neuronal como motor principal de búsqueda.",
"a": "Un algoritmo genético clásico —selección por torneo, cruce aritmético (interpolación lineal entre los vectores de parámetros de dos padres), mutación gaussiana y elitismo— busca directamente en el espacio de parámetros del motor de síntesis elegido, sin ningún modelo aprendido de por medio: la propia búsqueda evolutiva es el modelo, determinista dado un --seed, ejecutable enteramente en CPU.",
"c": "Ambos enfoques abordan el “problema inverso” central de la síntesis sonora — dado un timbre deseado, encontrar los parámetros que lo producen — que es notoriamente difícil de resolver analíticamente para motores de síntesis no lineales (FM, sustractiva con filtros resonantes), y que un sound designer humano resuelve tradicionalmente por prueba y error manual; ambas herramientas automatizan ese proceso con paradigmas algorítmicos complementarios: búsqueda vs. inferencia amortizada.",
"ex": [],
"fam": true
},
{
"n": "genopatch_flow",
"st": "sonido",
"pa": "neuronal",
"i": "WAV objetivo",
"o": "posterior p(θ|x) de parámetros",
"les": [
"sonido",
"maquinas"
],
"rel": [
"genopatch_v2"
],
"lines": 637,
"t": "Matching de patches de síntesis por búsqueda evolutiva e inferencia amortizada",
"p": "Tres ficheros abordan el mismo problema —el “problema inverso” del sonido: dado un WAV objetivo, encontrar los parámetros de un motor de síntesis paramétrico que mejor lo reproduzcan— con dos paradigmas algorítmicos distintos, inspirados en el “Genopatch” de Synplant 2 (Sonic Charge) pero sin red neuronal como motor principal de búsqueda.",
"a": "Un algoritmo genético clásico —selección por torneo, cruce aritmético (interpolación lineal entre los vectores de parámetros de dos padres), mutación gaussiana y elitismo— busca directamente en el espacio de parámetros del motor de síntesis elegido, sin ningún modelo aprendido de por medio: la propia búsqueda evolutiva es el modelo, determinista dado un --seed, ejecutable enteramente en CPU.",
"c": "Ambos enfoques abordan el “problema inverso” central de la síntesis sonora — dado un timbre deseado, encontrar los parámetros que lo producen — que es notoriamente difícil de resolver analíticamente para motores de síntesis no lineales (FM, sustractiva con filtros resonantes), y que un sound designer humano resuelve tradicionalmente por prueba y error manual; ambas herramientas automatizan ese proceso con paradigmas algorítmicos complementarios: búsqueda vs. inferencia amortizada.",
"ex": [],
"fam": true
},
{
"n": "genopatch_v2",
"st": "sonido",
"pa": "evolutivo",
"i": "WAV objetivo",
"o": "parámetros de síntesis (6 motores)",
"les": [
"sonido",
"maquinas"
],
"rel": [
"genopatch_flow",
"synth_forge"
],
"lines": 1584,
"t": "Matching de patches de síntesis por búsqueda evolutiva e inferencia amortizada",
"p": "Tres ficheros abordan el mismo problema —el “problema inverso” del sonido: dado un WAV objetivo, encontrar los parámetros de un motor de síntesis paramétrico que mejor lo reproduzcan— con dos paradigmas algorítmicos distintos, inspirados en el “Genopatch” de Synplant 2 (Sonic Charge) pero sin red neuronal como motor principal de búsqueda.",
"a": "Un algoritmo genético clásico —selección por torneo, cruce aritmético (interpolación lineal entre los vectores de parámetros de dos padres), mutación gaussiana y elitismo— busca directamente en el espacio de parámetros del motor de síntesis elegido, sin ningún modelo aprendido de por medio: la propia búsqueda evolutiva es el modelo, determinista dado un --seed, ejecutable enteramente en CPU.",
"c": "Ambos enfoques abordan el “problema inverso” central de la síntesis sonora — dado un timbre deseado, encontrar los parámetros que lo producen — que es notoriamente difícil de resolver analíticamente para motores de síntesis no lineales (FM, sustractiva con filtros resonantes), y que un sound designer humano resuelve tradicionalmente por prueba y error manual; ambas herramientas automatizan ese proceso con paradigmas algorítmicos complementarios: búsqueda vs. inferencia amortizada.",
"ex": [],
"fam": true
},
{
"n": "graded_variations",
"st": "practica",
"pa": "reglas",
"i": "obra simplificada",
"o": "variaciones por dimensión",
"les": [
"practica",
"melodia"
],
"rel": [
"combined_simplifier_hybrid_v2"
],
"lines": 924,
"t": "Variaciones musicales por dimensión, a un grado pedagógico fijo",
"p": "Genera variaciones de una pieza de piano ya simplificada a un grado pedagógico concreto, donde cada variación aísla deliberadamente una única dimensión musical — ornamentación, ritmo, textura, registro, armonía, modo o articulación — permitiendo al estudiante practicar variaciones de un mismo material sin alterar significativamente su dificultad técnica global.",
"a": "Cada tipo de variación es una transformación paramétrica dirigida a una única dimensión perceptual, manteniendo las demás fijas — un diseño experimental de “un factor a la vez” (one-factor-at-a-time) aplicado a composición: la variación ornamental añade figuración (notas de adorno) sin tocar el ritmo base; la variación rítmica reescribe patrones de duración sin cambiar las alturas; la de registro transpone octavas selectivamente; la armónica sustituye acordes por otros de función equivalente; la de modo reinterpreta la pieza en un modo paralelo (p. ej. mayor→menor) preservando el contorno melódico.",
"c": "El diseño refleja una técnica pedagógica consolidada en la enseñanza de composición: aislar variables de variación (¿qué pasa si cambio solo el ritmo? ¿solo la armonía?) para que el estudiante perciba con claridad el efecto de cada parámetro musical por separado, en vez de presentar variaciones que cambian varias dimensiones simultáneamente y confunden la atribución causal del cambio perceptual.",
"ex": [
"python graded_variations.py obra.mid --grade 3 --variations 2",
"python graded_variations.py obra.mid --grade 5 --types ornamental ritmica",
"python graded_variations.py obra.mid --grade 2 --seed 42 --outdir out/"
],
"fam": false
},
{
"n": "grammar_composer",
"st": "ensamblaje",
"pa": "estadistica",
"i": "MIDI + gramática",
"o": "MIDI compuesto / gramática aprendida",
"les": [
"maquinas"
],
"rel": [
"grammar_transformer",
"harvester"
],
"lines": 1738,
"t": "Composición dirigida por gramáticas formales (modo compose + modo learn)",
"p": "Motor de composición basado en gramáticas formales: en modo compose, combina un MIDI de entrada con una gramática textual que define una estructura jerárquica (referenciando compases concretos del MIDI original o notas ABC directas) para generar un nuevo MIDI; en modo learn, invierte el proceso — analiza un MIDI y extrae automáticamente su gramática subyacente mediante el algoritmo Re-Pair.",
"a": "El algoritmo Re-Pair (Larsson & Moffat, 1999; aquí descrito como una simplificación de Sequitur) es un algoritmo de compresión gramatical: reemplaza repetidamente el par de símbolos adyacentes más frecuente en la secuencia por un nuevo símbolo no terminal, produciendo una gramática libre de contexto que genera exactamente la secuencia original con un número mínimo de reglas — cuando se aplica a una secuencia de eventos musicales (notas con su duración), las reglas resultantes capturan automáticamente los motivos repetidos de la pieza (frases, células temáticas, patrones de acompañamiento) sin necesidad de anotación manual, de forma análoga a como se usa en compresión de texto o de…",
"c": "La idea de tratar una pieza musical como una jerarquía de motivos anidados reutilizados —una gramática— formaliza computacionalmente la práctica compositiva tradicional de construir formas musicales por repetición y variación de células temáticas (el “desarrollo motívico” del análisis formal clásico), y el hecho de que Re-Pair la descubra automáticamente por compresión estadística sugiere que la estructura motívica de una pieza bien construida es, en cierto sentido, información redundante comprimible.",
"ex": [
"python grammar_composer.py entrada.mid gramatica.txt",
"python grammar_composer.py entrada.mid gramatica.txt -o salida.mid",
"python grammar_composer.py entrada.mid gramatica.txt --tempo 120",
"python grammar_composer.py entrada.mid gramatica.txt --channel 0"
],
"fam": false
},
{
"n": "grammar_transformer",
"st": "ensamblaje",
"pa": "estadistica",
"i": "MIDI",
"o": "variación estructural (Re-Pair)",
"les": [
"maquinas"
],
"rel": [
"grammar_composer"
],
"lines": 3181,
"t": "Transformación estructural de MIDI mediante gramática Re-Pair (3.181 líneas)",
"p": "Extiende la idea de grammar_composer.py (extracción de gramática Re-Pair) hacia la transformación del MIDI original: en vez de solo aprender la gramática, sustituye elementos de una longitud dada por otros elementos “compatibles” de la misma gramática, muestreados con una temperatura configurable — produciendo variaciones estructuralmente coherentes de la pieza que preservan su jerarquía motívica pero alteran su contenido concreto.",
"a": "El pipeline completo: (1) extracción de notas a secuencia de tokens; (2) aprendizaje de reglas jerárquicas Re-Pair (idéntico a grammar_composer.py en modo learn); (3) vectorización de cada regla a 47 dimensiones; (4) construcción de una matriz de compatibilidad por coseno, agrupada por longitud de elemento (solo se comparan elementos de la misma duración, para que la sustitución preserve el “hueco” rítmico exacto); (5) sustitución de los elementos de la longitud objetivo por otros elementos compatibles, muestreados con temperatura T (T=0: siempre el más compatible por similitud coseno, sustitución “greedy” de mínima variación; T más alto: más exploración/sorpresa);",
"c": "Sustituir un motivo por otro “compatible” en similitud vectorial —en vez de aleatoriamente— formaliza la práctica compositiva de la variación motívica controlada: cambiar el contenido concreto de una célula temática manteniendo su función estructural y su encaje rítmico dentro de la jerarquía formal de la pieza, similar en espíritu al principio de “desarrollo temático” beethoveniano pero automatizado mediante compresión gramatical y similitud vectorial.",
"ex": [
"python grammar_transformer.py obra.mid --report",
"python grammar_transformer.py obra.mid --report --report-format html",
"python grammar_transformer.py obra.mid --report --report-format both",
"python grammar_transformer.py obra.mid --report --length 1.0"
],
"fam": false
},
{
"n": "harmonic_analyzer",
"st": "analisis",
"pa": "reglas",
"i": "MIDI",
"o": "numerales romanos + funciones + cadencias",
"les": [
"armonia"
],
"rel": [
"harmonic_gnn_analyzer",
"metric_analyzer"
],
"lines": 445,
"t": "Análisis armónico funcional didáctico (numerales romanos con explicación)",
"p": "El “compañero armónico” de metric_analyzer.py (que cubre el eje rítmico): toma un MIDI y devuelve, compás a compás, el acorde detectado, su cifrado, su numeral romano, su función armónica (Tónica/Subdominante/Dominante) y las cadencias presentes, con una explicación en lenguaje llano del por qué de cada análisis — a diferencia de reharmonizer.py o voice_leader.py, que transforman la armonía, esta herramienta solo analiza y explica lo que ya está escrito, con fines didácticos explícitos.",
"a": "La estimación de tonalidad global usa Krumhansl-Schmuckler. La novedad de la v1.1 es la detección de dominantes secundarios: cuando aparece una tríada mayor o séptima de dominante “sorprendente” —que no encajaría diatónicamente en el grado donde aparece— el sistema comprueba si el acorde siguiente resuelve exactamente una quinta justa por debajo; si resuelve, se etiqueta como V/x o V7/x (dominante secundario de x, función D con tonicización temporal) en vez de forzar una etiqueta diatónica engañosa; si no resuelve de esa manera específica, se mantiene el etiquetado cromático genérico anterior (acorde de mediante, préstamo modal).",
"c": "El fichero implementa, paso a paso y con explicación textual, el flujo estándar de un curso universitario de armonía funcional: identificación de acordes por análisis vertical, determinación de tonalidad, cifrado en numerales romanos relativos a esa tonalidad, clasificación funcional (T/S/D) de cada acorde, y reconocimiento de cadencias — con el añadido de tonicización temporal vía dominantes secundarios, el primer paso hacia el análisis de música cromática más allá de la práctica común estrictamente diatónica.",
"ex": [
"python harmonic_analyzer.py obra.mid",
"python harmonic_analyzer.py obra.mid --key Cmaj",
"python harmonic_analyzer.py obra.mid --window 2",
"python harmonic_analyzer.py obra.mid --explain --json obra.harm.json"
],
"fam": false
},
{
"n": "harmonic_gnn_analyzer",
"st": "analisis",
"pa": "neuronal",
"i": "MIDI",
"o": "grafo de notas + nota estructural/ornamental",
"les": [
"armonia",
"maquinas"
],
"rel": [
"harmonic_analyzer",
"schenkerian_reducer"
],
"lines": 727,
"t": "Análisis armónico mediante grafo de notas (redes neuronales de grafos)",
"p": "Complementa a harmonic_analyzer.py, que analiza compás a compás sobre un histograma de alturas “plano” (una secuencia lineal de ventanas temporales independientes). Este fichero modela en cambio la pieza completa como un grafo de notas con dos tipos de arista —simultaneidad (verticalidad: “esto es un acorde”) y sucesión (horizontalidad: “esto es una línea melódica” dentro de la misma voz)— y propaga información entre notas vecinas mediante varias rondas de message passing, la operación fundamental de las redes…",
"a": "El argumento central, explícito en el propio código, es que un histograma “plano” por compás no distingue “cuatro notas simultáneas = un acorde en bloque” de “cuatro notas en sucesión rápida = un arpegio o una floritura melódica que pasa por esas alturas sin que ellas constituyan el acorde real” — ambos casos producen el mismo histograma de clases de altura si se analizan sin estructura temporal fina.",
"c": "El fichero formaliza, mediante una estructura de grafo y propagación de mensajes en vez de reglas explícitas de contrapunto, la distinción perceptual entre “nota estructural del acorde” y “nota de adorno melódico” — la misma distinción que un analista humano hace intuitivamente al distinguir un arpegio de un acorde en bloque, aquí resuelta mediante una arquitectura de aprendizaje relacional sobre el grafo temporal de la pieza.",
"ex": [
"python harmonic_gnn_analyzer.py analyze obra.mid",
"python harmonic_gnn_analyzer.py analyze obra.mid --key Cmaj",
"python harmonic_gnn_analyzer.py analyze obra.mid --layers 3 --explain",
"python harmonic_gnn_analyzer.py analyze obra.mid --json obra.gnn.json"
],
"fam": false
},
{
"n": "harmony_checker",
"st": "practica",
"pa": "reglas",
"i": "coral SATB MIDI",
"o": "errores explicados",
"les": [
"voces"
],
"rel": [
"voice_leader"
],
"lines": 348,
"t": "Corrector pedagógico de conducción de voces SATB",
"p": "Complementario inverso de voice_leader.py (que genera un voicing SATB correcto): toma un intento de armonización a cuatro voces (Soprano/Alto/Tenor/Bajo) ya escrito y señala sus errores con explicación pedagógica, “como un profesor corrigiendo deberes de armonía” — no reescribe nada, solo marca y explica.",
"a": "Detecta siete categorías de error mediante comparación directa entre pares de voces en instantes consecutivos: quintas y octavas paralelas (dos voces se mueven en el mismo intervalo perfecto de un acorde al siguiente — la infracción más fundamental del contrapunto de Fux/Rameau, porque diluye la independencia perceptual de las voces), quintas directas (llegada a una quinta/octava por movimiento directo —ambas voces en la misma dirección— entre las voces extremas), cruce de voces (una voz teóricamente inferior sube por encima de su vecina superior), solapamiento (una voz invade el registro que acaba de dejar su vecina, aun sin cruzarse estrictamente), espaciado excesivo (hueco mayor de una…",
"c": "El catálogo de errores es exactamente el temario estándar de un curso universitario de armonía a cuatro voces al estilo coral, formalizado como comprobaciones deterministas sobre pares de acordes MIDI consecutivos — convirtiendo una tarea tradicionalmente corregida a mano por un profesor de conservatorio en un proceso automatizado con feedback inmediato.",
"ex": [
"python harmony_checker.py coral.mid",
"python harmony_checker.py coral.mid --key Cmaj",
"python harmony_checker.py coral.mid --grid 1 --json errores.json"
],
"fam": false
},
{
"n": "harvester",
"st": "analisis",
"pa": "estadistica",
"i": "MIDI(s)",
"o": "fragmentos .frag/.motif/.phrase",
"les": [
"forma",
"maquinas"
],
"rel": [
"mosaic_composer",
"phrase_builder"
],
"lines": 1020,
"t": "Extracción de fragmentos musicales reutilizables desde MIDIs",
"p": "Segmenta MIDIs en fragmentos reutilizables (secciones formales, motivos, frases entre cadencias, segmentos de textura homogénea) usando criterios exclusivamente musicales, no arbitrariamente temporales, sirviendo de proveedor de material a otras herramientas del ecosistema (completer.py, leitmotif_tracker.py).",
"a": "Combina cinco criterios de detección de fronteras, ponderados conjuntamente: (1) curva de novedad derivada de una matriz de auto-similitud (SSM) con patrón de “tablero de ajedrez” (checkerboard kernel) — la técnica estándar de segmentación estructural en recuperación de información musical (MIR), donde se detecta un cambio de sección buscando, a lo largo de la diagonal de la SSM, los puntos donde un kernel en forma de tablero de ajedrez (positivo en dos cuadrantes diagonales, negativo en los otros dos) tiene máxima correlación — matemáticamente, detecta transiciones de “un bloque homogéneo de similitud a otro”;",
"c": "El uso combinado de la SSM tipo checkerboard (una técnica tomada directamente de la literatura de MIR para segmentación estructural de audio, aquí aplicada a datos simbólicos) junto con criterios explícitamente musicales (cadencias, motivos, silencio) refleja que la segmentación formal “correcta” de una pieza rara vez coincide con un único criterio: combina evidencia estadística (auto-similitud, repetición) con evidencia teórica (cadencias tonales) para una segmentación más robusta que cualquiera de los dos…",
"ex": [
"python harvester.py archivo.mid",
"python harvester.py *.mid --out-dir fragmentos/",
"python harvester.py archivo.mid --mode all",
"python harvester.py archivo.mid --mode form cadence motif"
],
"fam": false
},
{
"n": "instrument_cloner",
"st": "sonido",
"pa": "neuronal",
"i": "~16 s de audio",
"o": "timbre clonado",
"les": [
"sonido",
"maquinas"
],
"rel": [
"ddsp_synth"
],
"lines": 1271,
"t": "Clonación neuronal de timbres a partir de ~16 s de audio (DDSP)",
"p": "Puerto a PyTorch puro (sin TensorFlow ni la librería ddsp de Google) de Neural Instrument Cloning (Jonason & Ericsson, DAFx 2022): clona el timbre de un instrumento real a partir de apenas ~16 segundos de audio de referencia, sin reentrenar la red completa para cada instrumento nuevo.",
"a": "El pipeline replica el modelo fuente-filtro DDSP: (f0, loudness, z[instrumento]) se procesan con una GRU más MLPs para producir una distribución armónica, una amplitud global y magnitudes de ruido, que alimentan la misma síntesis armónica + ruido filtrado al estilo DDSP descrita en ddsp_synth.py, seguida de un reverb con respuesta al impulso (IR) aprendida por instrumento y una mezcla húmedo/seco también aprendida.",
"c": "El hecho de que solo ~16 segundos de audio basten para “clonar” un timbre nuevo depende críticamente de que el decoder compartido ya haya aprendido, durante el entrenamiento multi-instrumento, la estructura general de “cómo suena un instrumento acústico” (mapeo de f0/sonoridad a espectro armónico plausible);",
"ex": [],
"fam": false
},
{
"n": "latent_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "obra desde z (VAE)",
"les": [
"maquinas"
],
"rel": [
"diffusion_composer_v4",
"flow_composer"
],
"lines": 3489,
"t": "Composición end-to-end mediante VAE multi-rol",
"p": "El más temprano (v0.1) de los cuatro enfoques generativos de “composición endto-end” del ecosistema (junto a latentscore/diffusion/flow_composer), basado en un autoencoder variacional (VAE) sobre piano rolls multi-rol.",
"a": "Un VAE estándar: encoder que produce los parámetros (media, logvarianza) de una distribución gaussiana aproximada al posterior, muestreo por el truco de reparametrización (necesario para que el muestreo sea diferenciable y el gradiente pueda propagarse a través de él durante el entrenamiento) y decoder que reconstruye el piano roll. El entrenamiento maximiza el ELBO (Evidence Lower Bound: reconstrucción menos divergencia KL respecto al prior gaussiano), con --beta y --beta-warmup controlando el peso de la divergencia KL a lo largo del entrenamiento — la técnica estándar de “betaannealing” de β-VAE, que evita el colapso posterior (el fenómeno donde el decoder ignora completamente el código…",
"c": "Comparado con la difusión (que requiere un proceso iterativo de muestreo) y los flujos (biyección exacta pero arquitectónicamente más restringida), el VAE ofrece el espacio latente más simple y de menor dimensión de los cuatro enfoques, a costa de una calidad de reconstrucción típicamente más “promediada”/borrosa — el compromiso clásico de los VAE frente a modelos generativos más recientes.",
"ex": [
"python latent_composer.py prepare --input-dir midis/ --output-dir data/",
"python latent_composer.py train   --data-dir data/  --model-dir model/",
"python latent_composer.py encode  --input ref.mid   --model-dir model/",
"python latent_composer.py compose --mode z-noise --input ref.mid"
],
"fam": false
},
{
"n": "latent_lab",
"st": "sonido",
"pa": "neuronal",
"i": "WAV / PNG",
"o": "latentes editables, WAV",
"les": [
"sonido",
"maquinas"
],
"rel": [
"audio_lab"
],
"lines": 3876,
"t": "Codec neuronal de audio y puentes espectrograma↔latente (3.876 líneas)",
"p": "Laboratorio extenso de experimentación con codecs de audio neuronales propios (entrenados desde cero, no reutilizando EnCodec/SoundStream) y con puentes bidireccionales entre representaciones espectrales (STFT, compartidas con audio_lab.py) y espacios latentes aprendidos, incluyendo un flujo completo de edición mediante imágenes PNG.",
"a": "Los métodos de traducción espectrograma↔latente cubren un espectro de complejidad: greedy (decisión local óptima paso a paso, sin considerar el futuro), viterbi (programación dinámica que encuentra la secuencia globalmente óptima de estados latentes discretos dado un modelo de transición y emisión — el algoritmo clásico usado en HMMs para decodificación de secuencias), pix2pix (traducción de imagen a imagen mediante GAN condicional, tratando el espectrograma y el latente como dos “imágenes” a traducir entre sí, en la línea del paper original de Isola et al.), causal y causal-adv (variantes que respetan una restricción de causalidad temporal — el latente en el instante t solo depende del…",
"c": "El puente PNG editable extiende a espacios latentes aprendidos la misma filosofía de edición visual creativa que audio_lab.py aplica a espectrogramas STFT crudos, permitiendo manipular directamente representaciones internas de un modelo neuronal con herramientas gráficas convencionales, sin necesidad de escribir código.",
"ex": [
"python latent_lab.py train-coder corpus/*.wav --steps 4000 -o coder.pt",
"python latent_lab.py wav-to-latent voz.wav --coder coder.pt --png",
"python latent_lab.py latent-to-wav voz.png --coder coder.pt -o out.wav"
],
"fam": false
},
{
"n": "latentscore_composer",
"st": "sonido",
"pa": "dsp",
"i": "texto (\"lluvia en ciudad\")",
"o": "WAV ambiente",
"les": [
"sonido"
],
"rel": [
"openmusic"
],
"lines": 3929,
"t": "Síntesis procedimental de audio ambiente desde texto",
"p": "Integración directa del proyecto latentscore (github.com/beatsbyprabal/latentscore): un motor de síntesis 100% NumPy/SciPy (sin modelos neuronales de por medio) que genera texturas de audio ambiente a partir de descripciones textuales libres (“lluvia en ciudad”, “jazz cafe”) o de configuraciones JSON explícitas, con soporte de morphing entre dos ambientes y encadenamiento de varias “vibes” en una secuencia con transiciones.",
"a": "El comando morph realiza una transición paramétrica suave entre los parámetros de dos configuraciones (dos “vibes”), interpolando el vector de parámetros de síntesis a lo largo de varios pasos discretos en vez de mezclar directamente las señales de audio resultantes — una interpolación en el espacio de parámetros generativos, más coherente perceptualmente que un simple crossfade de las señales. El comando chain encadena varias vibes en una secuencia con fundidos (--fade) entre transiciones consecutivas, generando una pista ambiente continua de larga duración a partir de una lista de descripciones o de un fichero de playlist.",
"c": "El enfoque de “síntesis procedimental” (parámetros generativos determinados por reglas explícitas, sin aprendizaje estadístico) para música ambiental/generativa sigue la tradición de la “música generativa” popularizada por Brian Eno: sistemas basados en reglas que producen texturas sonoras continuas y variables sin una partitura fija, aquí con el añadido de control por lenguaje natural sobre los parámetros del sistema.",
"ex": [
"python latentscore_composer.py render \"lluvia en ciudad\"",
"python latentscore_composer.py render \"jazz cafe\" --dur 30",
"python latentscore_composer.py render --config cfg.json",
"python latentscore_composer.py render \"calma\""
],
"fam": false
},
{
"n": "leadsheet_realizer",
"st": "armonia",
"pa": "reglas",
"i": "cifrado \"C Am F G\"",
"o": "acompañamiento de piano MIDI",
"les": [
"armonia",
"ritmo"
],
"rel": [
"chord_pattern_voicer",
"voice_leader"
],
"lines": 318,
"t": "De cifrado de acordes a acompañamiento pianístico tocable",
"p": "El puente práctico que falta entre la armonía abstracta (chord_progression_generator.py, reharmonizer.py, que trabajan la armonía en abstracto) y el coral SATB de voice_leader.py: convierte un cifrado de acordes de jazz/pop estándar (C Am7 F G) en un acompañamiento de piano legible y tocable por una persona, con patrones de comping idiomáticos y voicings ergonómicos.",
"a": "Seis patrones de “comping” (acompañamiento pianístico idiomático) están codificados explícitamente: block (acorde sostenido más bajo, el patrón más simple), ballad (acorde en tiempos 1 y 3, bajo en raíz-quinta), arpeggio (arpegio ascendente de las notas del acorde), alberti (bajo Alberti clásico: grave-agudo-medio-agudo), waltz (patrón de vals 3/4: bajo en el primer tiempo, acorde en los tiempos 2 y 3) y pop (bajo en la mano izquierda con acordes a contratiempo en la derecha — el patrón sincopado característico del acompañamiento pop).",
"c": "Los seis patrones catalogados son, cada uno, el idioma de acompañamiento estándar de un género o contexto distinto —balada, jazz, vals, pop—, formalizando la práctica de “realizar” un cifrado (una habilidad central del pianista de acompañamiento, tradicionalmente aprendida por imitación e improvisación) como una función determinista del cifrado y el patrón elegido.",
"ex": [
"python leadsheet_realizer.py --chords \"C Am F G\"",
"python leadsheet_realizer.py --chords \"Cmaj7 A7 Dm7 G7\" --pattern arpeggio",
"python leadsheet_realizer.py --chords \"C G/B Am F\" --pattern ballad",
"python leadsheet_realizer.py --file cancion.txt --pattern pop --tempo 100"
],
"fam": false
},
{
"n": "leitmotif_analyst",
"st": "analisis",
"pa": "estadistica",
"i": "obra MIDI",
"o": "leitmotifs + transformaciones + mapa",
"les": [
"melodia"
],
"rel": [
"leitmotif_tracker",
"variation_engine"
],
"lines": 1509,
"t": "Identificación de leitmotifs y sus transformaciones",
"p": "Dado un MIDI, identifica automáticamente sus leitmotifs (células musicales breves y recurrentes asociadas a una idea, en el sentido wagneriano del término) y rastrea cada aparición a lo largo de la obra, detectando qué transformación compositiva se le aplicó en cada reaparición respecto a su forma original.",
"a": "Para cada reaparición del motivo, el sistema comprueba, contra el catálogo de transformaciones de variation_engine.py, cuál (si alguna) explica la diferencia entre la ocurrencia original y la nueva: inversión del contorno melódico (cada intervalo asciende donde antes descendía y viceversa — una de las transformaciones seriales clásicas, popularizada por la técnica dodecafónica pero presente ya en la fuga barroca), retrógrado (la secuencia temporal se invierte — se toca “hacia atrás”), inversión retrógrada (ambas transformaciones combinadas), aumentación y diminución rítmicas (todas las duraciones se multiplican o dividen por un factor, típicamente 2), transposición (mismo contorno exacto,…",
"c": "El catálogo de transformaciones (inversión, retrógrado, inversión retrógrada, aumentación, diminución, transposición) es precisamente el conjunto canónico de operaciones sobre un motivo temático en la tradición contrapuntística occidental desde la fuga barroca hasta la técnica dodecafónica de la Segunda Escuela de Viena, aquí usado no para generar variaciones (como en variation_engine.py) sino para reconocer cuál de ellas explica una reaparición observada en una obra ya compuesta — un problema de clasificación…",
"ex": [
"python leitmotif_analyst.py obra.mid",
"python leitmotif_analyst.py obra.mid --min-bars 2 --max-bars 8",
"python leitmotif_analyst.py obra.mid --threshold 0.60",
"python leitmotif_analyst.py obra.mid --top 5"
],
"fam": false
},
{
"n": "leitmotif_tracker",
"st": "melodia",
"pa": "reglas",
"i": "banco de motivos + plan",
"o": "motivos sembrados en la obra",
"les": [
"melodia",
"forma"
],
"rel": [
"narrator",
"leitmotif_analyst"
],
"lines": 1893,
"t": "Gestión, siembra y rastreo de leitmotifs en composición dirigida",
"p": "Complementa a leitmotif_analyst.py (que detecta leitmotifs en una obra ya existente): este gestiona un banco de leitmotifs definidos explícitamente por el usuario o importados de otras herramientas, y los siembra estratégicamente a lo largo de una obra en construcción, transformándolos según el contexto emocional de cada sección.",
"a": "El flujo cubre todo el ciclo de vida de un leitmotif en una composición dirigida: registro manual o importado (from-theorist, que importa sugerencias de theorist.json; from-harvest, que importa motivos ya extraídos por harvester.py), planificación de dónde sembrar cada motivo según el plan narrativo de la obra, un modo suggest exploratorio que propone activamente ubicaciones de inyección, inject para materializar la siembra según un schedule JSON explícito, trace para detectar apariciones en una obra ya compuesta (reutilizando la lógica de leitmotif_analyst.py), un informe combinado (mapa ASCII/JSON) y propagate, que aplica una mutación semántica a todos los motivos del banco…",
"c": "El sistema formaliza el uso wagneriano/straussiano del leitmotif como técnica narrativa: un motivo no es una entidad fija sino que se transforma sistemáticamente según su contexto dramático (una idea musical puede “oscurecerse” armónicamente al asociarse a un giro trágico de la trama), y este fichero automatiza tanto la asignación estratégica de motivos a secciones como su transformación contextual coherente.",
"ex": [
"python leitmotif_tracker.py register motivo.mid --name \"destino\"",
"python leitmotif_tracker.py list",
"python leitmotif_tracker.py show destino",
"python leitmotif_tracker.py plan obra_plan.json"
],
"fam": false
},
{
"n": "lyrics_melody",
"st": "neuronal",
"pa": "neuronal",
"i": "letra + perfil emocional",
"o": "melodía ABC/MIDI",
"les": [
"melodia",
"maquinas"
],
"rel": [
"lyrics_writer",
"csl_l2m"
],
"lines": 1744,
"t": "Melodía condicionada por el contenido emocional del texto (v3.1)",
"p": "Aprende la relación entre el contenido semántico/emocional de cada verso de una canción y la melodía completa que lo acompaña, a partir de un corpus de ficheros ABC con letra alineada (campo w:), generando después melodías nuevas condicionadas en un texto dado, con fluidez explícita entre frases consecutivas.",
"a": "Tres mejoras de consistencia melódica añadidas en la v3.1, aplicables sin reentrenar el modelo (post-procesado sobre la salida del muestreo): (A) suavizado de octava, que tras decodificar cada token corrige la octava elegida a la más próxima a la nota anterior (minimizando el salto en semitonos), eliminando saltos de registro abruptos que el modelo entrenado podía producir entre notas o versos consecutivos;",
"c": "La combinación de máscara de escala (restricción dura, garantiza corrección tonal) con sesgo de intervalo por perfil (preferencia blanda, orienta el carácter expresivo) ilustra un patrón de diseño recurrente en generación musical controlable: separar las restricciones que deben cumplirse siempre (corrección teórica) de las preferencias que deben orientar sin forzar (expresividad), aplicadas en momentos distintos del proceso de muestreo (antes vs. durante el cálculo de probabilidades).",
"ex": [
"python3 lyrics_melody.py train --corpus ./canciones_abc/       --epochs 60 --model-out lyrics_melody.pt",
"python3 lyrics_melody.py train --corpus ./canciones_abc/       --model-out lyrics_melody.pt --resume --epochs 30",
"python3 lyrics_melody.py generate --model lyrics_melody.pt       --lyrics letra.txt --key C --mode major --profile melancholic       --tempo 96 --out melodia.mid --abc-out melodia.abc",
"python3 lyrics_melody.py generate --model lyrics_melody.pt       --lyrics letra.txt --key Am --mode minor --profile melancholic       --interval-bias-strength 0.4 --out melodia.mid --abc-out melodia.abc"
],
"fam": false
},
{
"n": "lyrics_writer",
"st": "melodia",
"pa": "llm",
"i": "melodía ABC + tema",
"o": "ABC con letra (w:)",
"les": [
"melodia"
],
"rel": [
"lyrics_melody"
],
"lines": 866,
"t": "Generación automática de letras para melodías ABC (LLM)",
"p": "Dado un fichero de notación ABC sin letra y una temática general, genera automáticamente las líneas de letra (w:) correspondientes usando un LLM (API de Anthropic u OpenAI), de modo que el número de sílabas de cada línea coincida exactamente con el número de notas del compás correspondiente — el requisito estructural que espera lyrics_melody.py para su corpus de entrenamiento (una sílaba por nota).",
"a": "El flujo procesa compás a compás, en orden: para cada compás, calcula el número de notas (= número de sílabas objetivo), y llama al LLM pidiendo un fragmento de letra en español con exactamente ese número de sílabas, coherente temáticamente y narrativamente con los versos ya generados (se pasa el historial completo de versos previos en cada llamada, para mantener coherencia narrativa a lo largo de toda la canción — un uso directo del contexto de ventana larga de un LLM para generación secuencial con memoria completa). El conteo de sílabas se verifica con una heurística silábica para español tras cada respuesta del modelo;",
"c": "La restricción de “una sílaba por nota” formaliza la práctica clásica de escritura de canciones silábica (frente a la escritura melismática, donde una sílaba se extiende sobre varias notas), y el hecho de que se verifique mecánicamente compás a compás en vez de dejarlo a la intuición del LLM refleja que el conteo silábico es una restricción dura y verificable objetivamente, no una cuestión de estilo negociable.",
"ex": [
"python3 lyrics_writer.py write --abc-in melodia.abc --tema \"amor de verano\"       --abc-out melodia_con_letra.abc",
"python3 lyrics_writer.py write --abc-in melodia.abc --tema \"amor de verano\"       --abc-out melodia_con_letra.abc --provider openai",
"python3 lyrics_writer.py write --abc-in melodia.abc       --tema \"soledad en la ciudad\" --abc-out salida.abc       --provider anthropic --model claude-sonnet-4-6 --max-retries 4",
"python3 lyrics_writer.py write --abc-in melodia.abc --tema \"tango triste\"       --abc-out salida.abc --verbose"
],
"fam": false
},
{
"n": "melody_adapter",
"st": "melodia",
"pa": "reglas",
"i": "melodía + nuevos acordes",
"o": "melodía adaptada MIDI",
"les": [
"melodia",
"armonia"
],
"rel": [
"melody_harmonizer",
"reharmonizer"
],
"lines": 1213,
"t": "Adaptación de melodías a progresiones de acordes externas",
"p": "Dado un MIDI de melodía y una progresión de acordes distinta (en texto o en MIDI), ajusta las notas de la melodía para que sean compatibles con la nueva armonía, respetando el contorno melódico original y distinguiendo entre notas estructurales (del acorde) y notas de paso/ornamentales, que se tratan con criterios distintos.",
"a": "Cuatro modos de adaptación con niveles crecientes de intervención: strict (solo desplaza las llamadas avoid notes —notas que forman una disonancia especialmente chocante contra el nuevo acorde, típicamente una segunda menor sobre la fundamental o la tercera— y solo en tiempos métricamente fuertes, para mínima intervención); smooth (además de strict, añade notas de paso para suavizar los saltos melódicos que la propia adaptación introduce, dando un resultado más cantábile/fluido);",
"c": "La jerarquía de intervención (strict → smooth → jazz → rewrite) formaliza una escala continua entre dos objetivos en tensión — fidelidad a la melodía original vs. corrección armónica frente a la nueva progresión —, con el criterio jazzístico de qué constituye una “avoid note” (dependiente del idioma armónico, no absoluto: una 11ª natural es tensión válida en un acorde menor pero disonancia a evitar en uno mayor) codificado explícitamente como parte central del modo jazz.",
"ex": [
"python melody_adapter.py melodia.mid --chords \"C Am F G\"",
"python melody_adapter.py melodia.mid --chords \"C:2 F:2 G:4\" --mode smooth",
"python melody_adapter.py melodia.mid --chords-midi acomp.mid",
"python melody_adapter.py melodia.mid --chords \"Dm7 G7 Cmaj7\" --mode jazz"
],
"fam": false
},
{
"n": "melody_conditioned",
"st": "melodia",
"pa": "estadistica",
"i": "acordes",
"o": "melodía MIDI",
"les": [
"melodia",
"maquinas"
],
"rel": [
"melody_conditioned_v5"
],
"lines": 2177,
"t": "Generación de melodía condicionada a acordes (v1.1 → v5.0)",
"p": "Cinco versiones sucesivas del mismo problema —generar una línea melódica cuya cada nota “sabe” en todo momento qué acorde suena y decide en consecuencia— documentan una evolución algorítmica particularmente clara del ecosistema, añadiendo motores de generación en cada iteración sin eliminar los anteriores.",
"a": "",
"c": "El motivo estructural detrás de toda la familia es el espectro completo de paradigmas de generación de secuencias musicales condicionadas — reglas deterministas, cadenas de Markov, búsqueda heurística, algoritmos evolutivos, aprendizaje profundo (LSTM) y modelos estadísticos con suavizado — todos resolviendo el mismo problema (melodía condicionada armónicamente), permitiendo comparar directamente sus resultados sobre exactamente el mismo espacio de entrada/salida.",
"ex": [
"python melody_conditioned.py --engine chord_guided",
"python melody_conditioned.py --engine llm"
],
"fam": true
},
{
"n": "melody_conditioned_v2",
"st": "melodia",
"pa": "busqueda",
"i": "acordes",
"o": "melodía MIDI",
"les": [
"melodia",
"maquinas"
],
"rel": [
"melody_conditioned_v5"
],
"lines": 2482,
"t": "Generación de melodía condicionada a acordes (v1.1 → v5.0)",
"p": "Cinco versiones sucesivas del mismo problema —generar una línea melódica cuya cada nota “sabe” en todo momento qué acorde suena y decide en consecuencia— documentan una evolución algorítmica particularmente clara del ecosistema, añadiendo motores de generación en cada iteración sin eliminar los anteriores.",
"a": "",
"c": "El motivo estructural detrás de toda la familia es el espectro completo de paradigmas de generación de secuencias musicales condicionadas — reglas deterministas, cadenas de Markov, búsqueda heurística, algoritmos evolutivos, aprendizaje profundo (LSTM) y modelos estadísticos con suavizado — todos resolviendo el mismo problema (melodía condicionada armónicamente), permitiendo comparar directamente sus resultados sobre exactamente el mismo espacio de entrada/salida.",
"ex": [
"python melody_conditioned_v2.py --engine grammar",
"python melody_conditioned_v2.py --engine chord_guided",
"python melody_conditioned_v2.py --engine search",
"python melody_conditioned_v2.py --engine genetic"
],
"fam": true
},
{
"n": "melody_conditioned_v3",
"st": "melodia",
"pa": "neuronal",
"i": "acordes",
"o": "melodía MIDI",
"les": [
"melodia",
"maquinas"
],
"rel": [
"melody_conditioned_v5"
],
"lines": 3596,
"t": "Generación de melodía condicionada a acordes (v1.1 → v5.0)",
"p": "Cinco versiones sucesivas del mismo problema —generar una línea melódica cuya cada nota “sabe” en todo momento qué acorde suena y decide en consecuencia— documentan una evolución algorítmica particularmente clara del ecosistema, añadiendo motores de generación en cada iteración sin eliminar los anteriores.",
"a": "",
"c": "El motivo estructural detrás de toda la familia es el espectro completo de paradigmas de generación de secuencias musicales condicionadas — reglas deterministas, cadenas de Markov, búsqueda heurística, algoritmos evolutivos, aprendizaje profundo (LSTM) y modelos estadísticos con suavizado — todos resolviendo el mismo problema (melodía condicionada armónicamente), permitiendo comparar directamente sus resultados sobre exactamente el mismo espacio de entrada/salida.",
"ex": [
"python melody_conditioned_v3.py",
"python melody_conditioned_v3.py --engine grammar",
"python melody_conditioned_v3.py --engine search",
"python melody_conditioned_v3.py --engine genetic"
],
"fam": true
},
{
"n": "melody_conditioned_v4",
"st": "melodia",
"pa": "estadistica",
"i": "acordes + motivo semilla",
"o": "melodía MIDI",
"les": [
"melodia",
"maquinas"
],
"rel": [
"melody_conditioned_v5"
],
"lines": 4795,
"t": "Generación de melodía condicionada a acordes (v1.1 → v5.0)",
"p": "Cinco versiones sucesivas del mismo problema —generar una línea melódica cuya cada nota “sabe” en todo momento qué acorde suena y decide en consecuencia— documentan una evolución algorítmica particularmente clara del ecosistema, añadiendo motores de generación en cada iteración sin eliminar los anteriores.",
"a": "",
"c": "El motivo estructural detrás de toda la familia es el espectro completo de paradigmas de generación de secuencias musicales condicionadas — reglas deterministas, cadenas de Markov, búsqueda heurística, algoritmos evolutivos, aprendizaje profundo (LSTM) y modelos estadísticos con suavizado — todos resolviendo el mismo problema (melodía condicionada armónicamente), permitiendo comparar directamente sus resultados sobre exactamente el mismo espacio de entrada/salida.",
"ex": [],
"fam": true
},
{
"n": "melody_conditioned_v5",
"st": "melodia",
"pa": "busqueda",
"i": "acordes (+corpus)",
"o": "melodía / sección MIDI",
"les": [
"melodia",
"maquinas",
"taller"
],
"rel": [
"melody_generator",
"cmt_composer"
],
"lines": 5579,
"t": "Generación de melodía condicionada a acordes (v1.1 → v5.0)",
"p": "Cinco versiones sucesivas del mismo problema —generar una línea melódica cuya cada nota “sabe” en todo momento qué acorde suena y decide en consecuencia— documentan una evolución algorítmica particularmente clara del ecosistema, añadiendo motores de generación en cada iteración sin eliminar los anteriores.",
"a": "",
"c": "El motivo estructural detrás de toda la familia es el espectro completo de paradigmas de generación de secuencias musicales condicionadas — reglas deterministas, cadenas de Markov, búsqueda heurística, algoritmos evolutivos, aprendizaje profundo (LSTM) y modelos estadísticos con suavizado — todos resolviendo el mismo problema (melodía condicionada armónicamente), permitiendo comparar directamente sus resultados sobre exactamente el mismo espacio de entrada/salida.",
"ex": [
"python melody_conditioned_v5.py",
"python melody_conditioned_v5.py --corpus ./midis/",
"python melody_conditioned_v5.py --engine grammar",
"python melody_conditioned_v5.py --engine search"
],
"fam": true
},
{
"n": "melody_critic",
"st": "analisis",
"pa": "reglas",
"i": "melodía MIDI",
"o": "crítica pedagógica",
"les": [
"melodia"
],
"rel": [
"quality_scorer"
],
"lines": 289,
"t": "Crítica constructiva pedagógica de una melodía",
"p": "A diferencia de quality_scorer.py (que puntúa una obra pero no enseña), analiza una melodía y devuelve comentario pedagógico explicando qué está bien y qué mejorar, pensado explícitamente para quien está aprendiendo a componer, no para clasificar/rankear obras.",
"a": "Siete métricas de análisis melódico clásico, cada una con su propio criterio de “buena práctica” pedagógica: ámbito (distancia entre la nota más grave y más aguda; un ámbito moderado es considerado ideal para líneas cantábiles); proporción grados/saltos (movimiento conjunto —por segundas— frente a saltos mayores de una tercera, un indicador clásico de “cantabilidad” melódica); saltos sueltos (saltos grandes que no están compensados por un movimiento posterior en dirección contraria — la regla de compensación de saltos del contrapunto tradicional: un salto grande debería seguirse, idealmente, de movimiento por grado en sentido opuesto);",
"c": "El fichero codifica, con umbrales explícitos, un conjunto de heurísticas de “buena escritura melódica” que forman parte del canon pedagógico de composición desde el contrapunto especies hasta los manuales modernos de melodía: cantabilidad (grados vs. saltos), dirección del clímax, variedad de contorno y equilibrio formal — la misma información que un profesor de composición señalaría al revisar el ejercicio de un estudiante.",
"ex": [
"python melody_critic.py melodia.mid",
"python melody_critic.py obra.mid --track 0",
"python melody_critic.py melodia.mid --json critica.json"
],
"fam": false
},
{
"n": "melody_generator",
"st": "melodia",
"pa": "busqueda",
"i": "texto / parámetros / plan",
"o": "melodía MIDI",
"les": [
"melodia",
"taller",
"maquinas"
],
"rel": [
"melody_conditioned_v5",
"phrase_builder"
],
"lines": 2244,
"t": "Generación de melodías originales desde cero (“Bloque 0” melódico)",
"p": "Construye una melodía completa ex nihilo a partir de parámetros musicales o de lenguaje natural, sin ningún MIDI de entrada — el equivalente melódico exacto de chord_progression_generator.py para la voz principal, el “bloque 0” del pipeline compositivo del ecosistema.",
"a": "Cinco motores intercambiables: markov (cadena de Markov de segundo orden sobre pares intervalo-duración, con estadísticas aprendidas del corpus si se proporciona o tablas estilísticas internas por defecto); grammar (gramática generativa basada en reglas schenkerianas: elabora progresivamente desde una estructura de capa profunda —típicamente un arpegio de tónica— añadiendo notas de paso y ornamentos en capas sucesivas, el mismo principio estructural usado en combined_simplifier.py pero en dirección generativa en vez de reductiva);",
"c": "El motor hybrid formaliza una intuición compositiva real: la estructura profunda de una buena melodía suele seguir principios composicionales relativamente universales (arpegios de acorde, movimiento hacia un clímax), mientras que su superficie concreta (qué notas de paso exactas, qué ornamentos) se beneficia de la variedad estadística observada en ejemplos reales — combinar ambos aporta tanto coherencia estructural como naturalidad de superficie.",
"ex": [
"python melody_generator.py \"una melodía melancólica en La menor\"",
"python melody_generator.py --key Am --mode minor --bars 16",
"python melody_generator.py --from-theorist obra.theorist.json",
"python melody_generator.py --from-narrator obra_plan.json --per-section"
],
"fam": false
},
{
"n": "melody_harmonizer",
"st": "melodia",
"pa": "busqueda",
"i": "armonía.mid + melodía.mid",
"o": "melodía reescrita + ornamentos",
"les": [
"melodia"
],
"rel": [
"melody_adapter"
],
"lines": 2325,
"t": "Adaptación de melodía a una armonía dada, con ornamentación (v2.0)",
"p": "Toma un MIDI de armonía (acordes) y otro de melodía, y reescribe la melodía para que sea musicalmente correcta sobre la armonía dada — el problema complementario e inverso de chord_progression_generator.py/reharmonizer.py (que arman una progresión para una melodía existente): aquí la armonía es el dato fijo y la melodía la que se adapta.",
"a": "Se mencionan explícitamente modos como dp_global, sugiriendo que al menos una de las estrategias resuelve la adaptación mediante programación dinámica global sobre toda la melodía (en vez de decisiones locales nota a nota), buscando la secuencia de ajustes de altura globalmente óptima según una función de coste que penaliza tanto la disonancia armónica como el alejamiento del contorno original — análogo en estructura al algoritmo de alineación de secuencias (Needleman-Wunsch) pero aplicado a compatibilidad armónica en vez de similitud de secuencias biológicas.",
"c": "Comparte con melody_adapter.py el problema general de compatibilizar melodía y armonía, pero con la dirección de la restricción invertida (armonía fija, melodía flexible) y con énfasis explícito en la ornamentación post-adaptación como recurso expresivo adicional, no solo en la corrección de colisiones.",
"ex": [
"python melody_harmonizer.py --list-strategies",
"python melody_harmonizer.py harmony.mid melody.mid",
"python melody_harmonizer.py harmony.mid melody.mid --adapt-mode dp_global",
"python melody_harmonizer.py harmony.mid melody.mid --adapt-mode limited_leap --strategy-param leap_max=3"
],
"fam": false
},
{
"n": "meter_adapter",
"st": "ritmo",
"pa": "reglas",
"i": "MIDI + compás destino",
"o": "MIDI en nuevo compás",
"les": [
"ritmo"
],
"rel": [
"metric_analyzer"
],
"lines": 774,
"t": "Adaptación métrica: reescritura rítmica entre compases distintos",
"p": "Implementa directamente las guías del método “Adapting Music from one Meter to Another” (Active Analysis): reescribe una pieza en un compás distinto del original (p. ej. de 4/4 a 3/4), añadiendo o quitando pulsos, mientras preserva en la medida de lo posible el material asociado a los tiempos fuertes (incluyendo anacrusas), la textura rítmica (sin exceder la subdivisión más rápida del original) y el contorno melódico.",
"a": "Dos estrategias simétricas según la dirección del cambio: al añadir pulsos (compás destino más largo), si ya existe silencio de cola disponible en la unidad rítmica se usa ese margen sin tocar ninguna nota (equivalente a “separar más los motivos”); si la unidad está saturada (sin holgura), se alarga la nota del tiempo más débil, o —si el hueco es grande— se le añade una repetición melismática (--melisma) en vez de un único valor de duración desproporcionadamente largo, preservando la sensación de pulso interno. Al quitar pulsos (compás destino más corto), si ya hay silencio de cola suficiente simplemente se acorta el contenedor sin tocar notas;",
"c": "El orden de prioridad de eliminación de notas (repetidas > de paso > tiempo débil, nunca las notas de los extremos) codifica una jerarquía de importancia estructural muy similar en espíritu a la reducción schenkeriana usada en combined_simplifier.py: las notas menos estructurales (repetición literal, ornamentación de paso) se sacrifican primero, preservando el “esqueleto” armónico-melódico de la frase incluso bajo una restricción métrica muy distinta a la original.",
"ex": [
"python meter_adapter.py tema.mid --to 5/4",
"python meter_adapter.py tema.mid --to 5/8 --from 6/8",
"python meter_adapter.py rondo.mid --to 3/4 --accompaniment-style waltz",
"python meter_adapter.py montuno.mid --to 7/4 --group 2"
],
"fam": false
},
{
"n": "metric_analyzer",
"st": "analisis",
"pa": "reglas",
"i": "MIDI",
"o": "síncopa LHL · nPVI · hipermetro",
"les": [
"ritmo"
],
"rel": [
"harmonic_analyzer",
"drummer"
],
"lines": 366,
"t": "Análisis de estructura métrica y síncopa",
"p": "Cubre explícitamente un hueco identificado en la suite de análisis del ecosistema: mientras otras herramientas (analyzer, quality_scorer, section_score, arc_supervisor, playability_auditor) miden altura, armonía, emoción, forma y tocabilidad, ninguna diagnosticaba específicamente el eje rítmico-métrico — cuánto sincopa la obra, dónde “pelea” contra el pulso, cómo se agrupa en hipercompases, y si el ritmo es plano o variado.",
"a": "La métrica de síncopa implementa directamente el modelo de Longuet-Higgins & Lee (LHL, 1984): una nota se considera sincopada cuando cae en una posición métricamente débil pero se sostiene sobre una posición métricamente fuerte inmediatamente posterior (la nota “ocupa” tiempo fuerte sin haber empezado en él), ponderada por el peso métrico relativo de la posición implicada — el modelo canónico de la literatura de cognición musical para cuantificar síncopa perceptual. La densidad se mide en onsets por compás; la fuerza del downbeat como proporción de onsets que caen exactamente en el primer tiempo.",
"c": "El modelo LHL de síncopa y el nPVI de variabilidad rítmica son ambos herramientas tomadas directamente de la literatura académica de cognición musical y lingüística computacional respectivamente, aplicadas aquí como métricas cuantitativas objetivas sobre datos MIDI crudos, allí donde tradicionalmente un analista humano describiría estas propiedades de forma cualitativa (“esta pieza sincopa mucho”, “el ritmo es muy regular”).",
"ex": [
"python metric_analyzer.py obra.mid",
"python metric_analyzer.py obra.mid --subdiv 4",
"python metric_analyzer.py obra.mid --track 0",
"python metric_analyzer.py obra.mid --json obra.metric.json --csv m.csv"
],
"fam": false
},
{
"n": "midi2yaml",
"st": "ensamblaje",
"pa": "infra",
"i": "MIDI",
"o": "bloques partitura.yaml",
"les": [
"representacion",
"taller"
],
"rel": [
"generar_midi"
],
"lines": 477,
"t": "Conversión de fragmentos MIDI a sintaxis de partitura.yaml",
"p": "Herramienta de “ida y vuelta” para el sistema declarativo de generar_midi.py: lee un MIDI producido por cualquier herramienta del ecosistema y produce bloques YAML listos para insertar de vuelta en partitura.yaml (melodía, armonía y/o marcato), en la sintaxis [compás, beat, duración, nota, velocidad] que ese sistema espera.",
"a": "El proceso es esencialmente una serialización estructurada: convierte eventos MIDI absolutos a la representación relativa (compás, beat) usada por el YAML declarativo, con parámetros de redondeo rítmico (--redondear, para cuantizar a una rejilla legible en vez de valores de tiempo exactos con ruido de interpretación humana) y un umbral de silencio (-umbral-silencio) para decidir cuándo un hueco entre notas se considera una pausa explícita frente a simplemente el final de una nota.",
"c": "Esta herramienta cierra el ciclo del flujo de trabajo compositivo de Pablo para su obra orquestal a medida: permite generar material con cualquier herramienta algorítmica del ecosistema (que produce MIDI) y luego incorporarlo de vuelta a la fuente de verdad declarativa (partitura.yaml) editada a mano, en vez de que ambos flujos de trabajo —algorítmico y declarativo manual— permanezcan separados e incompatibles.",
"ex": [
"python midi2yaml.py fragmento.mid",
"python midi2yaml.py fragmento.mid --compas-inicio 15",
"python midi2yaml.py fragmento.mid --modo melodia",
"python midi2yaml.py fragmento.mid --modo armonia"
],
"fam": false
},
{
"n": "midi_align",
"st": "ensamblaje",
"pa": "infra",
"i": "MIDI + anclajes",
"o": "MIDI realineado",
"les": [
"representacion"
],
"rel": [
"midi_concat"
],
"lines": 634,
"t": "Alineación temporal de MIDIs mediante puntos de anclaje",
"p": "Recibe un MIDI y una lista de pares de tiempos (origen→destino) y reescala cada segmento del MIDI para que sus bordes temporales coincidan con los tiempos de destino especificados — pensado explícitamente para alinear stems exportados de un generador de audio externo (Suno, mencionado explícitamente) con el MIDI original de referencia que los originó, cuando ambos han derivado temporalmente por razones de renderizado.",
"a": "Cada “anclaje” es un par de instantes en formato minuto:segundo.milisegundo; el primer anclaje debe ser necesariamente 0:00.000→0:00.000, y el último segmento se estira hasta el final del MIDI de referencia. Dos modos de reescalado por segmento: tempo (cambia el BPM efectivo de cada segmento entre dos anclajes consecutivos, preservando el ritmo interno relativo —solo cambia la “velocidad” global del segmento, como un time-stretch uniforme) y linear (redistribuye las notas proporcionalmente en el tiempo dentro del segmento, útil cuando los desajustes internos del segmento son irregulares y un simple cambio de tempo uniforme no bastaría para realinear cada nota individual con precisión).",
"c": "El problema que resuelve es el de alineación temporal no uniforme entre dos representaciones del mismo contenido musical que han derivado en el tiempo — un problema estructuralmente análogo al de alineación de audio a partitura (score-following) en recuperación de información musical, aquí resuelto de forma simplificada mediante interpolación por tramos entre puntos de anclaje dados manualmente en vez de mediante alineación automática (p. ej. DTW).",
"ex": [
"python midi_align.py stem.mid --anchors \"0:00.000 0:00.000\"",
"python midi_align.py stem.mid --ref original.mid",
"python midi_align.py stem.mid --anchors-file anclajes.txt",
"python midi_align.py stem.mid --anchors ... --mode linear"
],
"fam": false
},
{
"n": "midi_concat",
"st": "ensamblaje",
"pa": "infra",
"i": "MIDIs",
"o": "MIDI en serie",
"les": [
"representacion"
],
"rel": [
"midi_merge"
],
"lines": 747,
"t": "Composición temporal y espacial de MIDIs",
"p": "Dos utilidades complementarias de bajo nivel: midi_concat.py (v2.0) encadena N MIDIs en serie (uno reproducido a continuación del anterior), útil para unir frases, variaciones o secciones generadas por separado en una única pieza continua; midi_merge.py (v1.0) los combina en paralelo, convirtiendo cada MIDI de entrada (stem) en una pista distinta de un único MIDI multi-pista simultáneo.",
"a": "",
"c": "Ambas herramientas formalizan las dos operaciones básicas de composición de material musical discreto: concatenación temporal (forma A-B-C, secciones sucesivas) y superposición simultánea (textura polifónica, varias voces a la vez) — los dos ejes ortogonales sobre los que se construye cualquier estructura musical compleja a partir de fragmentos más simples.",
"ex": [
"python midi_concat.py frase1.mid frase2.mid frase3.mid",
"python midi_concat.py partes/*.mid --output cancion.mid",
"python midi_concat.py partes/*.mid --gap 2",
"python midi_concat.py partes/*.mid --tpb 480"
],
"fam": false
},
{
"n": "midi_dna_unified",
"st": "ensamblaje",
"pa": "estadistica",
"i": "MIDIs fuente + curvas --mt-*",
"o": "MIDI nuevo + .fingerprint.json",
"les": [
"taller",
"maquinas",
"forma"
],
"rel": [
"stitcher",
"evolver",
"tension_designer"
],
"lines": 5683,
"t": "Mezclador unificado de “ADN” musical (v1.4, fusión de tres generaciones)",
"p": "El motor central de generación estilística del ecosistema, descrito explícitamente como la fusión de “lo mejor de tres generaciones” de mezcladores MIDI anteriores: dados MIDIs fuente, extrae su “ADN” musical (ritmo, emoción, forma, armonía, ornamentación, groove) y lo recombina para producir nuevo material estilísticamente fiel.",
"a": "",
"c": "El propio nombre “ADN musical” es la metáfora organizadora de toda la herramienta: cada MIDI fuente se descompone en un conjunto de “genes” estilísticos independientes (ritmo, emoción, forma, ornamentación, groove) que pueden combinarse, mutarse y heredarse de forma modular — la misma metáfora que sustenta a evolver.py y counterexample.py, que consumen directamente el sistema de scoring de esta herramienta.",
"ex": [
"python midi_dna_unified.py midi1.mid midi2.mid [midi3.mid ...] [opciones]",
"python midi_dna_unified.py --melody a.mid --harmony b.mid --rhythm c.mid",
"python midi_dna_unified.py seccion_daw.mid --fingerprint-only",
"python midi_dna_unified.py bach.mid jazz.mid"
],
"fam": false
},
{
"n": "midi_merge",
"st": "ensamblaje",
"pa": "infra",
"i": "stems MIDI",
"o": "MIDI multipista",
"les": [
"representacion"
],
"rel": [
"midi_concat"
],
"lines": 493,
"t": "Composición temporal y espacial de MIDIs",
"p": "Dos utilidades complementarias de bajo nivel: midi_concat.py (v2.0) encadena N MIDIs en serie (uno reproducido a continuación del anterior), útil para unir frases, variaciones o secciones generadas por separado en una única pieza continua; midi_merge.py (v1.0) los combina en paralelo, convirtiendo cada MIDI de entrada (stem) en una pista distinta de un único MIDI multi-pista simultáneo.",
"a": "",
"c": "Ambas herramientas formalizan las dos operaciones básicas de composición de material musical discreto: concatenación temporal (forma A-B-C, secciones sucesivas) y superposición simultánea (textura polifónica, varias voces a la vez) — los dos ejes ortogonales sobre los que se construye cualquier estructura musical compleja a partir de fragmentos más simples.",
"ex": [
"python midi_merge.py stem_violin.mid stem_viola.mid stem_cello.mid",
"python midi_merge.py stems/*.mid --output merged.mid",
"python midi_merge.py stems/*.mid --tpb 480",
"python midi_merge.py stems/*.mid --channels violin:0 viola:1 cello:2"
],
"fam": false
},
{
"n": "midi_pianoroll_analyzer",
"st": "analisis",
"pa": "reglas",
"i": "MIDI multipista",
"o": "informe HTML interactivo",
"les": [
"representacion",
"forma"
],
"rel": [
"piano_duo_analyzer_v5"
],
"lines": 1961,
"t": "Análisis multi-pista con visualización HTML interactiva",
"p": "Toma un MIDI multi-pista, identifica automáticamente el rol de cada pista (melodía, contra-melodía, armonía, bajo, acompañamiento) y genera un informe HTML interactivo con piano roll por instrumento, fila de acordes con función armónica, fila de sección global y métricas por compás, todo alineado en el mismo eje temporal — una especie de “panel de control” visual que integra en una sola vista información que otras herramientas del ecosistema producen por separado (harmonic_analyzer, arc_supervisor,…",
"a": "El piano roll de cada pista se colorea por frase según la gramática Re-Pair individual de esa pista (cada instrumento tiene su propia segmentación motívica, no una compartida), los acordes se etiquetan con función armónica (Tónica/Predominante/Dominante/Dominante secundario), la sección global se detecta por SSM y curva de novedad (la misma técnica de harvester.py), y las métricas por compás (tensión, densidad, velocidad, contorno) se calculan con las mismas fórmulas usadas en otras herramientas de análisis del ecosistema, unificadas aquí en una sola visualización temporal sincronizada.",
"c": "El diseño de “todo alineado en el mismo eje temporal” refleja la práctica de análisis de partitura orquestal, donde un analista examina simultáneamente varias capas de información (qué instrumento toca qué, qué armonía suena, en qué sección formal estamos) sincronizadas visualmente por compás — aquí automatizado y hecho interactivo en un navegador.",
"ex": [
"python3 midi_pianoroll_analyzer.py archivo.mid",
"python3 midi_pianoroll_analyzer.py archivo.mid config.yaml",
"python3 midi_pianoroll_analyzer.py archivo.mid -o informe.html",
"python3 midi_pianoroll_analyzer.py --test"
],
"fam": false
},
{
"n": "midi_split_harmony",
"st": "captura",
"pa": "estadistica",
"i": "MIDI polifónico",
"o": "melodía.mid + acordes.mid",
"les": [
"armonia",
"representacion"
],
"rel": [
"pitch_transcriber"
],
"lines": 1813,
"t": "Separación automática de melodía y acordes",
"p": "Dado un MIDI de entrada (monofónico o polifónico, con armonía limpia o mal transcrita — p. ej. proveniente de una transcripción automática de audio ruidosa), separa la voz melódica principal de la progresión armónica subyacente, produciendo un MIDI de melodía limpio y continuo y otro de acordes cuantizado y corregido.",
"a": "Pipeline de cinco etapas: (1) pre-análisis (tempo, compás, tonalidad, canales); (2) separación de melodía mediante un algoritmo skyline mejorado —no la simple regla “nota más aguda gana” del skyline clásico, sino ponderado por continuidad temporal y por verosimilitud interválica (penaliza saltos melódicos implausibles, prefiriendo una línea que se mueva de forma musicalmente coherente aunque eso signifique no elegir siempre la nota más aguda);",
"c": "El uso de un HMM para el reconocimiento de acordes es una técnica bien establecida en Music Information Retrieval: modela la progresión armónica como una cadena de estados ocultos (los acordes reales) que emiten observaciones ruidosas (el chroma medido), y el algoritmo de Viterbi (o similar) encuentra la secuencia de estados más probable dado el chroma observado completo, aprovechando el contexto temporal completo en vez de decisiones instantáneas independientes.",
"ex": [
"python midi_split_harmony.py entrada.mid",
"python midi_split_harmony.py entrada.mid --out-dir salidas/",
"python midi_split_harmony.py entrada.mid --split-files",
"python midi_split_harmony.py entrada.mid --key \"A minor\" --verbose"
],
"fam": false
},
{
"n": "midi_test_generators",
"st": "analisis",
"pa": "infra",
"i": "—",
"o": "10 MIDIs sintéticos de prueba",
"les": [
"forma"
],
"rel": [
"midi_pianoroll_analyzer"
],
"lines": 549,
"t": "Generadores de MIDIs sintéticos multi-pista para pruebas",
"p": "Genera diez MIDIs sintéticos de referencia (cinco pistas cada uno: melodía, contra-melodía, armonía, bajo, acompañamiento), cubriendo diez estilos y formas musicales distintas, específicamente diseñados como conjunto de pruebas para validar midi_pianoroll_analyzer.py y, por extensión, cualquier otra herramienta de análisis del ecosistema.",
"a": "",
"c": "El propio diseño del conjunto de pruebas es una lección implícita de formas musicales: cada MIDI sintético está elegido para ejercitar una estructura formal o un rasgo armónico/rítmico específico y bien documentado de la práctica compositiva occidental (rondó, blues de doce compases, fuga, forma AABA de jazz), garantizando que cualquier algoritmo de análisis del ecosistema se valide contra ejemplos representativos de la diversidad real de la música que se espera que analice.",
"ex": [
"python3 midi_test_generators.py",
"python3 midi_test_generators.py -o ./salida",
"python3 midi_test_generators.py --no-report",
"python3 midi_test_generators.py --list"
],
"fam": false
},
{
"n": "midinet_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "acordes",
"o": "melodía compás a compás (GAN)",
"les": [
"maquinas"
],
"rel": [
"musegan"
],
"lines": 1089,
"t": "Generación de melodía condicionada en acordes mediante GAN bar-a-bar (MidiNet)",
"p": "Reimplementación de MidiNet (Yang, Chou & Yang, 2017): una GAN condicional que genera melodía compás a compás, condicionada tanto en el acorde activo de ese compás como en el compás anterior ya generado, produciendo continuidad entre compases consecutivos sin necesidad de un modelo recurrente completo.",
"a": "El discriminador es condicional (evalúa la coherencia del piano roll generado tanto con el acorde como con el compás anterior, no solo su realismo absoluto). La función de pérdida del generador combina tres términos: pérdida adversarial estándar, feature matching (en vez de solo intentar engañar al discriminador en su salida final, el generador también se entrena para que las activaciones internas del discriminador ante ejemplos generados coincidan estadísticamente con las de ejemplos reales — una técnica de estabilización de entrenamiento GAN bien documentada, que reduce el colapso de modo) y un término de “matching de medias” adicional.",
"c": "El condicionamiento explícito en el compás anterior (en vez de en toda la historia mediante una RNN) refleja una simplificación deliberada del original MidiNet: apostar a que la coherencia melódica de compás a compás (continuidad local) captura la mayor parte de la naturalidad percibida, sin necesitar memoria de largo alcance — una hipótesis razonable para melodías populares de estructura relativamente repetitiva.",
"ex": [
"python midinet_composer.py prepare",
"python midinet_composer.py train",
"python midinet_composer.py generate",
"python midinet_composer.py round-trip --input midis/cancion.mid"
],
"fam": false
},
{
"n": "miditok_algoritmos",
"st": "neuronal",
"pa": "infra",
"i": "MIDI",
"o": "tokenizaciones MidiTok",
"les": [
"representacion"
],
"rel": [
"token_composer"
],
"lines": 721,
"t": "Los 9 algoritmos de tokenización de MIDI (MIDI-Like, TSD, REMI,",
"p": "Structured, CPWord, Octuple, MuMIDI, MMM, PerTok) REIMPLEMENTADOS DESDE CERO, en Python puro sobre `mido`, para poder leer y entender el algoritmo real de cada uno -- sin la caja negra de la librería miditok. Este fichero es la versión \"para entender cómo funciona\"; para uso productivo (fidelidad exacta, BPE, etc.) usa miditok_composer.py, que envuelve la librería original.",
"a": "",
"c": "",
"ex": [],
"fam": false
},
{
"n": "miditok_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "generación sobre tokens MidiTok",
"les": [
"representacion"
],
"rel": [
"token_composer"
],
"lines": 322,
"t": "Tokenizador de música para modelos de secuencias (Transformer, etc).",
"p": "Convierte MIDI <-> tokens usando cualquiera de los esquemas clásicos (REMI, TSD, MIDI-Like, Structured, CPWord, Octuple, MuMIDI, MMM, PerTok), entrena vocabularios sub-token (BPE / Unigram / WordPiece) sobre un corpus, e inspecciona MIDIs o tokenizadores ya entrenados. Adaptación al estilo mutopia de MidiTok (Nathan Fradet, MIT License).",
"a": "",
"c": "",
"ex": [],
"fam": false
},
{
"n": "mix_evolver",
"st": "sonido",
"pa": "evolutivo",
"i": "WAV + corpus de referencia",
"o": "mejor cadena de efectos",
"les": [
"sonido",
"maquinas"
],
"rel": [
"audio_effects",
"audio_reference_scorer"
],
"lines": 493,
"t": "Algoritmo genético para encontrar la mejor cadena de efectos de mezcla",
"p": "Busca, mediante algoritmo genético, la mejor Chain de efectos de audio_effects.py para un WAV concreto, puntuada por audio_reference_scorer.py contra un corpus de referencia — sin implementar ningún efecto DSP propio: importa directamente apply_chain de audio_effects.py para renderizar cada candidato y load_manifest para saber qué genes (parámetros de efecto) son válidos al mutar/inicializar, ilustrando el patrón de composición modular característico del ecosistema (herramientas de “búsqueda”/“evolución” que…",
"a": "Cada individuo de la población genética es una cadena completa de efectos (una lista ordenada de EffectGene, la misma estructura de audio_effects.py); el fitness de cada individuo se calcula renderizando el WAV con esa cadena y puntuándolo con la distancia de Mahalanobis de audio_reference_scorer.py contra el corpus de referencia (y opcionalmente contra un “floor” de calibración). El algoritmo genético opera sobre este espacio de cadenas de efectos con los operadores estándar (selección, cruce, mutación, elitismo), explorando automáticamente el espacio combinatorio de qué efectos aplicar, en qué orden y con qué parámetros, para maximizar la afinidad tímbrica con el corpus de referencia.",
"c": "Automatiza una tarea que un ingeniero de mezcla resolvería por prueba y error guiada por la experiencia (qué cadena de EQ+compresor+reverb hace que esta mezcla suene “como” mis referencias favoritas), convirtiendo la búsqueda en un proceso de optimización exploratoria del espacio combinatorio completo de configuraciones de efectos, en vez de ajuste manual iterativo.",
"ex": [],
"fam": false
},
{
"n": "ml_architect",
"st": "plan",
"pa": "estadistica",
"i": "corpus MIDI",
"o": "obra estructurada MIDI",
"les": [
"forma",
"maquinas"
],
"rel": [
"narrator",
"harvester"
],
"lines": 3695,
"t": "Composición estructural dirigida por gramáticas aprendidas de corpus (v8.0)",
"p": "Aprende, de un corpus de MIDIs reales, la gramática estructural típica de ese corpus (secciones, roles instrumentales, transiciones) y genera obras completas nuevas siguiendo esa gramática aprendida, con capacidad de actualización incremental del modelo y exploración sistemática del espacio de resultados.",
"a": "segment detecta las secciones formales de un MIDI de entrada (compartiendo la técnica de segmentación estructural de harvester.py/midi_pianoroll_analyzer.py). train/update construyen y actualizan incrementalmente un modelo sobre un corpus (añadir MIDIs nuevos sin reentrenar desde cero — importante quando el corpus de referencia crece con el tiempo). variants (novedad v8) genera N variantes de una obra, las puntúa automáticamente y las ordena por score, presentando al usuario ya solo las mejores en vez de una única salida no comparada.",
"c": "El barrido arco-vs-variedad formaliza una tensión compositiva real y bien reconocida: la coherencia narrativa de una obra (un arco emocional claro y predecible) compite parcialmente con su interés como material (variedad y sorpresa), y presentar explícitamente ese trade-off como un espacio explorable en vez de una única salida “óptima” reconoce que la elección entre ambos extremos es, en última instancia, una decisión estética del usuario.",
"ex": [],
"fam": false
},
{
"n": "ml_expander",
"st": "arreglo",
"pa": "neuronal",
"i": "corpus orquestal / boceto",
"o": "orquestación aprendida",
"les": [
"interpretacion",
"maquinas"
],
"rel": [
"piano_expander"
],
"lines": 2769,
"t": "Expansión orquestal de bocetos pianísticos mediante ML entrenado por reducción sintética",
"p": "Aprende la transformación piano→orquesta a partir de partituras orquestales reales, mediante un truco de generación de datos de entrenamiento: colapsa (reduce sintéticamente) obras orquestales reales a una versión de piano, generando así pares de entrenamiento (piano_reducido, orquesta_original) sin necesitar un corpus emparejado piano↔orquesta ya existente (que sería muy escaso) — un ejemplo de generación sintética de datos de entrenamiento por proceso inverso, análogo en espíritu a como se generan pares de…",
"a": "Tras la predicción de los tres modelos ML, se aplica una corrección idiomática post-ML basada en reglas (no en aprendizaje): reutiliza chord_tone_category/admissible_pcs de melody_harmonizer.py, _best_candidate/_motion_type de counterpoint.py, classify_articulation de orchestrator.py, y rangos idiomáticos por instrumento de piano_expander.py — un patrón híbrido explícito donde el ML decide el contenido general y las reglas deterministas garantizan que el resultado final respete restricciones idiomáticas duras (rango del instrumento, tonos de acorde válidos) que el ML por sí solo no puede garantizar de forma fiable.",
"c": "El patrón “ML genera, reglas corrigen” refleja una estrategia de diseño pragmática y recurrente en sistemas de composición asistida: el aprendizaje automático es bueno capturando patrones estadísticos complejos (qué textura orquestal es plausible dado un contexto), pero las restricciones duras de viabilidad instrumental (un violín no puede tocar por debajo de su cuerda más grave) se garantizan mejor con reglas explícitas verificables, no dejadas a la esperanza de que el modelo las haya aprendido implícitamente.",
"ex": [
"python ml_expander.py train /datos/maestro/",
"python ml_expander.py train /datos/maestro/ --epochs 80 --lr 5e-4",
"python ml_expander.py train /datos/ --hidden-dim 256 --batch-size 64",
"python ml_expander.py train /datos/ --delta-bins 16 --pitch-bins 48"
],
"fam": false
},
{
"n": "ml_inpainter",
"st": "ensamblaje",
"pa": "estadistica",
"i": "obra con huecos",
"o": "compases rellenados",
"les": [
"maquinas"
],
"rel": [
"completer"
],
"lines": 2775,
"t": "Relleno inteligente de compases vacíos (v2.0)",
"p": "Detecta compases vacíos o de densidad anormalmente baja en una obra MIDI multi-pista y los rellena usando una combinación de análisis de estilo por pista, cadenas de Markov bidireccionales y, opcionalmente, un modelo PyTorch autorregresivo entrenado sobre corpus, coordinando múltiples pistas simultáneamente mediante una restricción armónica compartida entre ellas.",
"a": "El uso de cadenas de Markov bidireccionales (en vez de solo hacia adelante) es la elección algorítmica central: al rellenar un hueco, el sistema tiene información tanto del material que lo precede como del que lo sigue (a diferencia de una generación puramente autorregresiva hacia adelante, que solo puede condicionar en el pasado) — un problema estructuralmente más parecido al inpainting de imágenes (rellenar una región dado su contexto completo circundante) que a la generación secuencial estándar, de ahí el nombre de la herramienta tomado directamente de esa analogía.",
"c": "El planteamiento como “inpainting” (tomado directamente de visión por computador) formaliza correctamente la diferencia entre “continuar” una pieza (solo pasado disponible) y “rellenar un hueco interno” (pasado y futuro disponibles como contexto) — dos problemas de generación condicionada con información disponible estructuralmente distinta, que requieren, como aquí, algoritmos de condicionamiento diferentes (autorregresivo unidireccional vs. bidireccional).",
"ex": [
"python ml_inpainter.py scan obra.mid",
"python ml_inpainter.py scan obra.mid --min-density 0.1",
"python ml_inpainter.py scan obra.mid --report gaps.txt",
"python ml_inpainter.py fill obra.mid"
],
"fam": false
},
{
"n": "modulator",
"st": "expresion",
"pa": "reglas",
"i": "MIDI + parámetro + curva",
"o": "MIDI modulado",
"les": [
"forma",
"interpretacion"
],
"rel": [
"tension_designer"
],
"lines": 1234,
"t": "Modulación continua y musicalmente informada de parámetros MIDI (v2.0)",
"p": "Aplica curvas de modulación continua (crescendo, arcos de tensión, cambios de densidad, etc.) a parámetros musicales de un MIDI existente —densidad, tensión, dinámica, ritmo, registro, articulación, dispersión (spread), contorno, tempo, brillo— de forma “musicalmente informada”: consciente de la armonía, la separación de voces y la estructura formal, en vez de aplicar transformaciones puramente matemáticas ciegas al contenido musical.",
"a": "Las mejoras de la v2.0 sobre v1.0 son todas instancias del mismo principio general —sustituir una transformación matemática ciega por una musicalmente consciente— : el análisis armónico por compás (tonalidad local vía perfiles Krumhansl) permite que la modulación de un parámetro no rompa la coherencia tonal local; la separación de voces (melodía/bajo/armonía tratadas individualmente) permite aplicar la misma curva de modulación con distinta intensidad o fase a cada capa textural; la modulación de densidad respeta una rejilla rítmica coherente al añadir/quitar notas de paso (no las coloca en posiciones métricamente arbitrarias);",
"c": "La lista de nueve parámetros modulables junto con doce formas de curva define, en efecto, un pequeño lenguaje declarativo de automatización musical (similar en espíritu a la automatización de parámetros en un DAW, pero operando sobre contenido MIDI simbólico con consciencia armónica en vez de sobre audio o control MIDI CC crudo), donde cada combinación parámetro×curva codifica un gesto expresivo distinto (p. ej. densidad con curva arc = crescendo-decrescendo de textura).",
"ex": [
"python modulator.py obra.mid --param density --curve arc",
"python modulator.py obra.mid --params dynamics tension --curve sigmoid",
"python modulator.py obra.mid --param tension --voice melody",
"python modulator.py obra.mid --param all --curve s_curve --preview"
],
"fam": false
},
{
"n": "morpher",
"st": "ensamblaje",
"pa": "reglas",
"i": "A.mid + B.mid",
"o": "N pasos intermedios",
"les": [
"maquinas"
],
"rel": [
"style_blender",
"analyzer"
],
"lines": 710,
"t": "Morphing gradual entre dos obras MIDI",
"p": "Dado A.mid y B.mid, genera N pasos intermedios donde el “ADN” musical de A se transforma gradualmente en B — a diferencia de una transferencia de estilo puntual (un salto directo A→B), produce una secuencia continua de estados intermedios explorables.",
"a": "Seis dimensiones de morphing, controlables independientemente: contorno melódico y secuencia de notas, patrón rítmico/groove, progresión y complejidad armónica, curvas emocionales (tensión/activación/valencia), envolvente dinámica de velocidades, y tempo — permitiendo, por ejemplo, morphear la armonía rápidamente mientras el ritmo cambia gradualmente.",
"c": "Separar el morphing en seis ejes independientes con curvas temporales propias por eje permite composiciones de transición mucho más sofisticadas que una simple mezcla lineal de dos piezas: p. ej. una transición donde el ritmo cambia de forma abrupta (sigmoide muy pronunciada) pero la armonía evoluciona con una exponencial lenta, simulando una modulación tonal gradual bajo un cambio de textura rítmica repentino.",
"ex": [
"python morpher.py A.mid B.mid",
"python morpher.py A.mid B.mid --steps 8",
"python morpher.py A.mid B.mid --steps 10 --mode sigmoid",
"python morpher.py A.mid B.mid --steps 6 --dims pitch rhythm"
],
"fam": false
},
{
"n": "mosaic_composer",
"st": "ensamblaje",
"pa": "busqueda",
"i": "corpus MIDI + arco",
"o": "collage dramático MIDI",
"les": [
"forma"
],
"rel": [
"harvester",
"morpher",
"stitcher"
],
"lines": 2894,
"t": "Collage y ensamblaje dramático de fragmentos musicales (v2.0)",
"p": "Segmenta un corpus completo de MIDIs en fragmentos etiquetados, los indexa por función dramática, tensión, estilo y compatibilidad de “costura”, y los reensambla creativamente siguiendo un arco narrativo explícito — con el resultado deliberadamente irreconocible respecto a las fuentes originales, no una simple concatenación de citas.",
"a": "Pipeline de siete etapas orquestando varias otras herramientas del ecosistema: (1) HARVEST, segmentación del corpus (con harvester.py o internamente); (2) INDEX, etiquetado de cada fragmento por tensión, rol dramático, tipo de cadencia y estilo; (3) PLAN, diseño del arco dramático completo como una secuencia de “slots” con función y tensión objetivo; (4) SELECT, para cada slot se eligen dos fragmentos de fuentes distintas (no uno); (5) BLEND, fusión genuina de sus “ADNs” (des-identificación del material original + injerto + mezcla vía midi_dna_unified.py) — melodía de uno, ritmo del otro, por ejemplo, en vez de alternar bloques completos de cada fuente;",
"c": "La técnica de fusionar deliberadamente “melodía de A + ritmo de B” en vez de alternar bloques enteros de material citado formaliza el concepto de collage compositivo genuino (frente al pastiche por yuxtaposición): el objetivo explícito es que el resultado sea nuevo material derivado, no una simple recombinación reconocible de sus fuentes — un principio estético distinto del muestreo/sampling literal.",
"ex": [
"python mosaic_composer.py build --corpus midis/ --arc sonata --bars 80",
"python mosaic_composer.py build --corpus midis/ --arc rondo  --bars 96",
"python mosaic_composer.py build --corpus midis/ --arc wave   --bars 48"
],
"fam": false
},
{
"n": "motif_table",
"st": "melodia",
"pa": "reglas",
"i": "búsqueda por emoción/contorno",
"o": "motivo / frase MIDI",
"les": [
"melodia"
],
"rel": [
"chord_table",
"rhythm_table"
],
"lines": 1720,
"t": "Catálogo curado de 100 motivos y frases melódicas (v2.0)",
"p": "Complemento melódico de chord_table.py y rhythm_table.py: en vez de progresiones de acordes o patrones rítmicos, ofrece un catálogo curado de 100 gestos melódicos (motivos cortos de 2-5 notas, y frases más largas de 6-9 notas con arco antecedente-consecuente), descritos por grados de escala y etiquetados con tensión (escala 1-10), contorno y emoción, buscables y exportables.",
"a": "",
"c": "La distinción explícita entre “motivo” (material bruto de construcción, para desarrollarse), “frase” (unidad retórica completa lista para usarse) y “escala” (material de estudio sin función retórica) formaliza tres niveles distintos de organización melódica reconocidos en la teoría de la forma musical: la célula, la frase, y el material escalar puramente técnico.",
"ex": [
"python motif_table.py --list",
"python motif_table.py --emocion angustia",
"python motif_table.py --style flamenco --tipo frase",
"python motif_table.py --contorno ascendente --mode dorian"
],
"fam": false
},
{
"n": "mscz2vec",
"st": "analisis",
"pa": "reglas",
"i": "MusicXML / MSCZ / MIDI",
"o": "vectores perceptuales (12 familias)",
"les": [
"representacion",
"maquinas"
],
"rel": [
"analyzer",
"counterexample"
],
"lines": 7472,
"t": "Vectorización perceptual de partituras (7.472 líneas)",
"p": "El motor de vectorización musical central del ecosistema (invocado como subproceso por analyzer.py, counterexample.py y otras herramientas): analiza una partitura (MusicXML, MSCZ, MIDI) y extrae vectores de características a múltiples niveles perceptuales simultáneamente.",
"a": "",
"c": "El fichero es, en efecto, la “API” de traducción entre música simbólica y espacio vectorial que consume el resto del ecosistema: cualquier herramienta que necesite comparar, agrupar o medir similitud entre obras (analyzer, counterexample, evolver a través de midi_dna_unified) delega en última instancia en las representaciones vectoriales que produce este fichero, haciendo de él la pieza de infraestructura compartida más reutilizada de todo el proyecto.",
"ex": [
"python mscz2vec.py partitura.musicxml",
"python mscz2vec.py partitura.mscz --vector melodic",
"python mscz2vec.py partitura.xml --vector harmonic rhythmic",
"python mscz2vec.py partitura.xml --vector all --output vec.json"
],
"fam": false
},
{
"n": "muscriptor_transcribe",
"st": "captura",
"pa": "neuronal",
"i": "WAV",
"o": "MIDI por instrumento",
"les": [
"sonido"
],
"rel": [
"pitch_transcriber"
],
"lines": 4158,
"t": "Transcripción de audio a MIDI con transformer decoder-only (MuScriptor)",
"p": "Puerto de un único fichero del modelo MuScriptor (Kyutai × Mirelo, CC BY-NC 4.0): transcribe una grabación de audio real a notas MIDI por instrumento, usando un transformer decoder-only que decodifica un flujo de tokens al estilo MT3 (Multi-Task Multitrack Music Transcription, Google Magenta), con soporte de streaming por fragmentos (chunks) mediante un mecanismo de “tie-prologue” entre ellos.",
"a": "La adaptación deliberadamente reduce el alcance del proyecto original: el repositorio de MuScriptor completo incluye también exportación a partitura vía MuseScore y un servidor FastAPI con visualización de piano roll en vivo, ambos excluidos explícitamente en esta adaptación “por no encajar con el estilo mutopia” (fichero único, CLI simple, sin servidor) — un ejemplo explícito de la disciplina arquitectónica que se autoimpone el ecosistema incluso al adaptar proyectos externos con más funcionalidad disponible.",
"c": "La tarea de transcripción automática de audio polifónico a notas discretas por instrumento (piano transcription, más generalmente multitrack music transcription) es uno de los problemas centrales y más difíciles del MIR (Music Information Retrieval): requiere separar simultáneamente qué instrumento suena, qué nota, cuándo empieza y cuándo termina, a partir de una única señal de audio mezclada.",
"ex": [],
"fam": false
},
{
"n": "musegan",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus multipista",
"o": "piano rolls de 5 pistas",
"les": [
"maquinas"
],
"rel": [
"midinet_composer"
],
"lines": 1550,
"t": "Generación multi-pista mediante GAN sobre piano rolls binarios (BinaryMuseGAN, PyTorch)",
"p": "Reimplementación de BinaryMuseGAN (Dong et al., ISMIR 2018): genera música multi-pista (batería, bajo, guitarra, cuerdas, piano) directamente como piano rolls binarios de cinco dimensiones, mediante una GAN entrenada con la pérdida de Wasserstein.",
"a": "El generador comparte una deconvolución 3D (transposed convolution) inicial entre todas las pistas, seguida de ramas separadas por pista con dos orientaciones de procesamiento complementarias —“pitch-time” y “time-pitch”— que capturan patrones tanto a lo largo del eje temporal como del eje de alturas para cada instrumento individualmente. El discriminador usa ramas simétricas por pista más dos streams adicionales especializados: uno de chroma (resumen armónico agregado sobre las 12 clases de altura, ignorando la octava, para juzgar coherencia armónica global) y uno de onset/offset (patrón de ataques y finales de nota, para juzgar coherencia rítmica).",
"c": "Los dos streams discriminadores especializados (chroma y onset/offset) formalizan explícitamente que la “coherencia musical” de un piano roll multi-pista generado depende tanto de su coherencia armónica global (qué notas suenan juntas, independientemente de su ritmo exacto) como de su coherencia rítmica (cuándo atacan y terminan las notas, independientemente de su altura exacta) — dos aspectos parcialmente independientes que un único discriminador genérico podría no aprender a evaluar por separado con la misma…",
"ex": [
"python musegan.py prepare",
"python musegan.py train",
"python musegan.py train  --data data/train.npz  --model-dir model/",
"python musegan.py generate"
],
"fam": false
},
{
"n": "music_transformer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "continuación / generación",
"les": [
"representacion",
"maquinas"
],
"rel": [
"remi",
"token_composer"
],
"lines": 1090,
"t": "Generación con estructura a largo plazo mediante atención relativa (Huang et al. 2019)",
"p": "Reimplementación del Music Transformer original de Google Magenta (Huang et al., 2019): un Transformer autorregresivo decoder-only capaz de generar música con coherencia estructural a largo plazo (hasta 2048 eventos MIDI), gracias a su mecanismo de atención relativa.",
"a": "La innovación central del paper original, replicada aquí, es la atención relativa con el “truco de skewing” (relative attention with skewing trick): la atención estándar de un Transformer calcula compatibilidad entre posiciones absolutas, pero para música (donde los patrones se repiten en relaciones relativas de posición, no en posiciones absolutas concretas) es más útil una atención que dependa de la distancia entre dos posiciones, no de sus índices absolutos. Calcular esto de la forma ingenua requeriría una matriz de sesgos de tamaño O(N²D) (N=longitud de secuencia, D=dimensión), prohibitivamente costosa para secuencias largas;",
"c": "La atención relativa captura directamente una propiedad estructural fundamental de la música: la repetición y variación de patrones a intervalos temporales relativos (un motivo que reaparece “4 compases después”, independientemente de en qué compás absoluto se encuentre la pieza) es mucho más común y perceptualmente relevante que relaciones de posición absoluta, y el mecanismo de atención relativa modela esto de forma nativa en vez de tener que aprenderlo indirectamente de datos como tendría que hacer un…",
"ex": [
"python music_transformer.py preprocess --input midis/ --output data/",
"python music_transformer.py train --data data/ --model-dir runs/exp1/",
"python music_transformer.py preprocess --input . --output data_mt/ --verbose",
"python music_transformer.py inspect --data data_mt/"
],
"fam": false
},
{
"n": "musiclm",
"st": "neuronal",
"pa": "neuronal",
"i": "texto",
"o": "audio musical",
"les": [
"maquinas"
],
"rel": [
"audiolm",
"openmusic"
],
"lines": 1801,
"t": "Generación de música a partir de texto (MusicLM, pipeline completo)",
"p": "Implementación de MusicLM (Agostinelli et al., Google, 2023): combina MuLaN (aprendizaje contrastivo audio-texto al estilo CLIP) con la arquitectura en cascada de AudioLM (ya presente como audiolm.py en el ecosistema) para generar música a partir de descripciones en lenguaje natural libre.",
"a": "El flujo completo encadena seis etapas: entrenamiento contrastivo de MuLaN sobre pares (audio, texto); ajuste del cuantizador residual sobre los embeddings de audio de MuLaN entrenado; extracción de embeddings (de audio o de texto — ambos viven en el mismo espacio tras el entrenamiento contrastivo, permitiendo usar el embedding de un texto como si fuera el embedding de un audio “objetivo” nunca escuchado); generación de música condicionada en la descripción de texto, delegando en la arquitectura en cascada de tres transformers de AudioLM (semántico→grueso→fino) pero condicionando cada etapa en los tokens MuLaN derivados del texto en vez de (o además de) en un audio de referencia;",
"c": "El principio de MusicLM es que un espacio de embedding compartido audio-texto (MuLaN), entrenado sobre una tarea puramente discriminativa (¿este audio y este texto corresponden?), puede reutilizarse después como condicionamiento para una tarea completamente distinta (generación), simplemente porque el texto y el audio correspondiente ya viven cerca en ese espacio — una técnica de condicionamiento por espacio compartido mucho más flexible que entrenar un modelo texto→audio de extremo a extremo directamente sobre…",
"ex": [
"python musiclm.py prepare --audio-dir ./wavs --manifest manifest.csv",
"python musiclm.py train-mulan --manifest manifest.csv --steps 50000",
"python musiclm.py quantize --mulan mulan.pt --manifest manifest.csv",
"python musiclm.py generate \"una pieza de piano melancólica\""
],
"fam": false
},
{
"n": "mutator",
"st": "ensamblaje",
"pa": "llm",
"i": "MIDI + instrucción en lenguaje natural",
"o": "MIDI mutado + árbol de historial",
"les": [
"maquinas"
],
"rel": [
"mscz2vec",
"variation_engine"
],
"lines": 1967,
"t": "Mutación semántica de MIDIs guiada por lenguaje natural",
"p": "Traduce instrucciones libres en lenguaje natural (“más oscuro”, “añade urgencia en el clímax”, “que suene como lluvia”) en parámetros concretos del pipeline midi_dna_unified.py y las aplica sobre un MIDI existente, con verificación automática de que el resultado efectivamente se movió en la dirección semántica pedida.",
"a": "El flujo de seis etapas es notable por su bucle de verificación cerrado: (1) lee el MIDI fuente y calcula su “fingerprint” (estado vectorial actual); (2) parsea la instrucción combinando un diccionario semántico interno (mapeo directo de frases comunes a deltas de parámetros) con un LLM como fallback/enriquecimiento para instrucciones no cubiertas por el diccionario; (3) resuelve los deltas de parámetro como cambios relativos al estado actual (no valores absolutos — “más oscuro” desplaza el estado actual hacia lo oscuro, no lo fija a un valor de oscuridad predeterminado);",
"c": "El paso de verificación (4→5) es conceptualmente el más interesante: convierte una instrucción subjetiva en lenguaje natural en una hipótesis vectorial verificable (“más oscuro” implica un desplazamiento medible en ciertas dimensiones del vector perceptual de mscz2vec), cerrando el bucle entre intención expresada en lenguaje y resultado medible, en vez de confiar ciegamente en que la transformación aplicada logró el efecto pedido.",
"ex": [
"python mutator.py obra.mid \"más oscuro\"",
"python mutator.py obra.mid \"añade urgencia en los últimos 8 compases\"",
"python mutator.py obra.mid \"hazlo más lento y melancólico\"",
"python mutator.py obra.mid \"quiero que suene como si lloviera\""
],
"fam": false
},
{
"n": "narrator",
"st": "plan",
"pa": "reglas",
"i": "arco narrativo",
"o": "obra_plan.json · curvas · plan.yaml",
"les": [
"forma",
"taller"
],
"rel": [
"theorist",
"runner",
"tension_designer",
"leitmotif_tracker"
],
"lines": 845,
"t": "Diseñador de arquitectura narrativa para obras musicales",
"p": "Define la estructura dramática completa de una obra antes de generar ningún MIDI, actuando como “director de orquesta” de todo el pipeline: convierte una narrativa emocional (en lenguaje natural o mediante GUI) en forma musical concreta (secciones A/B/C, duraciones, cadencias), curvas exportables a tension_designer.py, un plan de ejecución completo (plan.yaml, consumido por runner.py) y un mapa tonal explícito.",
"a": "El fichero funciona como capa de planificación de más alto nivel del ecosistema: en vez de generar contenido musical directamente, produce las especificaciones (curvas de tensión, mapa tonal, estructura formal, plan.yaml) que consumen otras herramientas generativas (tension_designer.py, cadence_designer.py, runner.py), separando explícitamente la decisión de “qué forma dramática tendrá la obra” de “cómo se genera el contenido concreto para cada sección” — una separación de responsabilidades entre planificación de alto nivel y ejecución de bajo nivel.",
"c": "El mapeo directo entre arcos narrativos literarios (el viaje del héroe, la tragedia, el misterio) y formas musicales clásicas (rondó, sonata) formaliza la intuición, común en la crítica musical, de que las formas musicales tradicionales codifican en sí mismas arquetipos narrativos — la forma sonata como un “viaje” con partida (exposición), conflicto (desarrollo) y retorno transformado (reexposición).",
"ex": [
"python narrator.py",
"python narrator.py --arc hero --bars 64",
"python narrator.py --arc sonata --bars 96 --key Dm --output plan.json",
"python narrator.py --load plan.json --edit"
],
"fam": false
},
{
"n": "openmusic",
"st": "neuronal",
"pa": "neuronal",
"i": "texto",
"o": "audio musical (QA-MDT)",
"les": [
"maquinas"
],
"rel": [
"musiclm"
],
"lines": 1192,
"t": "Text-to-Music con QA-MDT (Quality-Aware Masked Diffusion Transformer)",
"p": "Genera audio musical de alta calidad directamente a partir de una descripción textual, mediante una reimplementación autocontenida de QA-MDT (Quality-Aware MDT), sin depender de ningún otro script del ecosistema.",
"a": "El comando describe usa un LLM o heurísticas para traducir una “intención libre” del usuario (lenguaje coloquial, posiblemente vago) a un prompt técnico más estructurado y efectivo para el modelo de difusión — reconociendo que los modelos de difusión textoaudio, como los de texto-imagen, suelen responder mejor a prompts con vocabulario técnico específico (instrumentación, género, tempo) que a descripciones puramente coloquiales.",
"c": "El token de calidad MOS es la contribución distintiva de QA-MDT frente a modelos de difusión texto-audio más simples: permite que el modelo aprenda de un corpus de calidad heterogénea (mezclas profesionales junto a grabaciones amateur) sin que la generación resultante “regrese a la media” de calidad del corpus completo, porque el modelo puede condicionar explícitamente en “quiero calidad alta” en el momento de generar.",
"ex": [
"python openmusic.py setup --ckpt-dir checkpoints/",
"python openmusic.py describe \"algo melancólico que suene a lluvia de otoño\"",
"python openmusic.py describe \"jazz nocturno relajado\" --llm-provider openai",
"python openmusic.py describe \"batalla épica medieval\" --no-llm"
],
"fam": false
},
{
"n": "orchestral_colorist",
"st": "arreglo",
"pa": "reglas",
"i": "MIDI + emoción",
"o": "MIDI con paleta tímbrica",
"les": [
"interpretacion"
],
"rel": [
"orchestrator"
],
"lines": 339,
"t": "Color tímbrico emocional para obras MIDI",
"p": "Mientras orchestrator.py asigna instrumentos de forma mecánica/idiomática (según rango y textura), este fichero lo hace por semántica emocional: cada emoción define una paleta orquestal completa (instrumento por rol, registro objetivo, rango dinámico) extraída de convenciones reales de la práctica orquestal — melancolía → violonchelo en registro medio, fragilidad → flauta sola pianissimo con arpa, angustia → registros extremos con trémolo de cuerda, triunfo → metales fortissimo.",
"a": "Pipeline de cuatro etapas: (1) detección de rol por pista (melodía/bajo/armonía/contrapunto/per —canal 10, el estándar General MIDI para batería); (2) selección de la paleta —instrumento General MIDI, registro y dinámica— según la emoción solicitada; (3) aplicación mediante program change MIDI, transposición de octavas hacia el registro objetivo mientras se permanece dentro del rango físico real del instrumento (validado contra el catálogo de rangos idiomáticos de playability_auditor.py, evitando asignar a un instrumento notas fuera de su tesitura físicamente ejecutable) y reescalado de las velocidades de nota al rango dinámico de la paleta;",
"c": "El catálogo de asociaciones emoción→timbre codifica convenciones orquestales bien establecidas en la práctica compositiva romántica y de música de cine (el violonchelo como voz de melancolía introspectiva, el trémolo de cuerda grave como recurso estándar de tensión/angustia, los metales en fortissimo como signo convencional de triunfo), formalizando explícitamente un vocabulario semántico-tímbrico que un orquestador humano aplicaría por convención estilística aprendida, no por regla mecánica de rango instrumental.",
"ex": [
"python orchestral_colorist.py obra.mid --emotion melancolia",
"python orchestral_colorist.py obra.mid --emotion triunfo --output t.mid",
"python orchestral_colorist.py obra.mid --emotion angustia --keep 0",
"python orchestral_colorist.py --list-emotions"
],
"fam": false
},
{
"n": "orchestrator",
"st": "arreglo",
"pa": "reglas",
"i": "MIDI + fingerprints",
"o": "MIDI orquestal (keyswitches, CC1/CC11)",
"les": [
"interpretacion",
"taller"
],
"rel": [
"stitcher",
"piano_to_orchestra"
],
"lines": 2768,
"t": "Orquestación automática y percusión para mocks orquestales",
"p": "Lee el MIDI de stitcher.py junto con sus fingerprints JSON y genera un MIDI multi-pista listo para importar en FL Studio con distribución de material a una plantilla orquestal completa (cuerdas, maderas, metales, percusión), keyswitches, automatización de expresión y un informe de sesión.",
"a": "La distribución de material por sección orquestal se basa en el rol detectado de cada línea (melodía, contramelodía, bajo, armonía). Los keyswitches —el mecanismo estándar de las librerías de samples orquestales virtuales para cambiar de técnica de ejecución (legato, staccato, pizzicato…) mediante notas MIDI fuera de rango dedicadas a ese propósito— se seleccionan automáticamente según la duración y el contexto de cada nota (classify_articulation, reutilizada por ml_expander.py).",
"c": "El fichero automatiza el trabajo típicamente manual y tedioso de un compositor de música para medios preparando un mock (maqueta orquestal con samples) para escucha previa: asignación de instrumentos, articulaciones y automatización de expresión — tareas que consumen gran parte del tiempo de producción en composición para cine/videojuegos y que aquí se derivan directamente del contenido musical y de su curva de tensión ya calculada.",
"ex": [
"python orchestrator.py obra_final.mid [fingerprints...] [opciones]",
"python orchestrator.py obra_final.mid --auto-fingerprints",
"python orchestrator.py obra_final.mid --report-only",
"python orchestrator.py obra_final.mid --ks-config my_ks.json"
],
"fam": false
},
{
"n": "part_extractor",
"st": "arreglo",
"pa": "reglas",
"i": "MIDI orquestal",
"o": "partes individuales transpuestas",
"les": [
"interpretacion"
],
"rel": [
"piano_reducer"
],
"lines": 373,
"t": "Extracción de partes instrumentales individuales con transposición",
"p": "Cubre un hueco explícito del ecosistema: mientras varias herramientas generan MIDIs orquestales multi-pista, ninguna producía las partes individuales que necesita cada intérprete real para leer su música. Separa cada pista en su propio MIDI autónomo, aplicando la transposición del instrumento transpositor correspondiente, y reporta rango y compases de silencio (tacet).",
"a": "Es la operación inversa exacta de piano_reducer.py (que fusiona voces en dos pentagramas) y de midi_merge.py (que combina stems en uno): aquí se divide una partitura multi-pista en partes de lectura individual. Las transposiciones estándar de instrumentos transpositores están codificadas explícitamente (trompeta/clarinete/saxofón en si♭: escrito = sonante + 2 semitonos; trompa/corno inglés en fa: +7 semitonos; flautín y contrabajo con transposición de octava), siguiendo la convención universal de notación orquestal donde el intérprete lee una nota distinta de la que realmente suena, para que la digitación sea uniforme entre instrumentos de la misma familia afinados en tonalidades distintas.",
"c": "La transposición de instrumentos transpositores es una convención centenaria de la notación orquestal occidental, motivada históricamente por la construcción física de los instrumentos (el largo del tubo determina su tonalidad fundamental) y mantenida por tradición pedagógica (una misma digitación produce el mismo patrón de lectura en toda la familia de instrumentos, independientemente de su afinación de transposición concreta) — automatizarla correctamente es indispensable para que una parte impresa sea…",
"ex": [
"python part_extractor.py orquesta.mid",
"python part_extractor.py orquesta.mid --list",
"python part_extractor.py orquesta.mid --concert",
"python part_extractor.py orquesta.mid --transpose 3:9 --as 5:trompeta"
],
"fam": false
},
{
"n": "performer",
"st": "expresion",
"pa": "reglas",
"i": "MIDI cuantizado",
"o": "MIDI expresivo (rubato, CC64/11/1)",
"les": [
"interpretacion",
"taller"
],
"rel": [
"tempo_designer",
"expressive_injector"
],
"lines": 432,
"t": "Renderizado expresivo de interpretación para MIDI cuantizado",
"p": "Los compositores algorítmicos del ecosistema producen MIDI cuantizado y de velocidad uniforme; esta herramienta reconoce explícitamente que gran parte de la emoción percibida en una interpretación musical no está en qué notas suenan sino en cómo suenan, aplicando reglas interpretativas locales inspiradas en las reglas KTH / Director Musices (el sistema de reglas de interpretación expresiva desarrollado en el KTH Royal Institute of Technology de Estocolmo, una de las referencias académicas más consolidadas de la…",
"a": "Siete reglas aplicadas de forma consciente de la estructura de frase (no globalmente uniforme): rubato por frase (arco agógico: arranque contenido, aceleración hacia el pico, ritardando en el cierre, más un ritardando final de la pieza completa); agógica (alargamiento temporal deliberado de la nota que constituye el pico melódico de cada frase — un recurso interpretativo estándar para señalar el punto culminante); dinámica (crescendo hacia el pico de frase, combinado con una jerarquía métrica que refuerza los tiempos fuertes y atenúa los contratiempos, más un jitter aleatorio de pequeña magnitud para evitar mecanicidad perfecta);",
"c": "El fichero es una implementación computacional directa de un modelo académico consolidado de interpretación musical expresiva, formalizando precisamente los micro-ajustes de tiempo, dinámica y articulación que distinguen una interpretación “humana” convincente de una ejecución mecánicamente literal de la partitura — el problema central de la síntesis de interpretación expresiva en informática musical.",
"ex": [
"python performer.py obra.mid",
"python performer.py obra.mid --style romantico --intensity 0.8",
"python performer.py obra.mid --no-pedal --no-vibrato",
"python performer.py obra.mid --melody-track 1 --seed 7"
],
"fam": false
},
{
"n": "phrase_builder",
"st": "melodia",
"pa": "reglas",
"i": "motivo MIDI",
"o": "frase/periodo 4-16 compases",
"les": [
"melodia",
"taller"
],
"rel": [
"harvester",
"song_architect"
],
"lines": 1351,
"t": "Motor de sintaxis melódica: antecedente/consecuente",
"p": "Toma un motivo corto (2-4 compases, idealmente extraído por harvester.py) y lo expande en frases completas de 4, 8 o 16 compases aplicando la lógica sintáctica clásica de la frase musical occidental: antecedente→consecuente, pregunta→respuesta, semicadencia→cadencia auténtica — el propio docstring señala que el resultado suena “inevitablemente correcto” porque sigue la gramática con la que el oído occidental está entrenado desde la infancia musical.",
"a": "El concepto central formaliza la frase musical como un par estructurado: el antecedente (A) presenta la idea y termina en tensión (semicadencia, sobre V); el consecuente (C) responde a esa idea y termina en reposo (cadencia auténtica, sobre I). Cuatro tipos de relación A→C, cada uno asociado a una práctica compositiva histórica concreta: parallel (C es casi idéntico a A salvo la cadencia final — el modelo bachiano de “pregunta y respuesta casi idéntica”), contrasting (C introduce material nuevo pero comparte el mismo final — el modelo clásico vienés de Haydn/Mozart), sequential (C transpone literalmente el material de A a otro grado — el recurso de la secuencia armónica) y developmental (C…",
"c": "La taxonomía de cuatro tipos de relación antecedente-consecuente es, en efecto, una breve historia comprimida de la evolución de la técnica de frase en la música tonal occidental —de la simetría casi literal del barroco a la elaboración desarrollante del clasicismo tardío— formalizada aquí como cuatro estrategias generativas intercambiables sobre el mismo par estructural A→C.",
"ex": [
"python phrase_builder.py --motif motivo.mid",
"python phrase_builder.py --motif motivo.mid --form period --type parallel",
"python phrase_builder.py --motif motivo.mid --form sentence --key Am",
"python phrase_builder.py --motif motivo.mid --form binary --tempo 120"
],
"fam": false
},
{
"n": "piano_autocomplete",
"st": "neuronal",
"pa": "neuronal",
"i": "interpretación de piano",
"o": "continuación en tiempo real",
"les": [
"maquinas"
],
"rel": [
"music_transformer"
],
"lines": 1532,
"t": "Autocompletado de interpretaciones de piano en tiempo real",
"p": "Inspirado en el proyecto “Training a 125M-parameter Model to Autocomplete Piano”: un Transformer decoder-only pequeño que continúa una interpretación pianística nota a nota en tiempo real, aprendida sobre datos de interpretación reales (no partitura cuantizada), con post-entrenamiento por preferencias.",
"a": "La arquitectura del Transformer usa RMSNorm (normalización más simple y barata que LayerNorm, que prescinde de restar la media, usada en arquitecturas modernas como LLaMA), atención causal estándar y SwiGLU como función de activación de las capas feed-forward (una variante gated de GLU con SiLU, también popularizada por LLaMA/PaLM, generalmente superior a ReLU/GELU en modelos de lenguaje modernos) — la misma receta arquitectónica de los LLMs de texto contemporáneos, aplicada aquí a secuencias de notas de piano.",
"c": "Modelar el pedal implícitamente en la duración de la nota (en vez de como evento explícito) es una simplificación de representación que sacrifica fidelidad física (el pedal afecta también a notas no directamente pulsadas por resonancia simpática) a cambio de una tokenización mucho más compacta y directamente aprovechable por un modelo de secuencia estándar.",
"ex": [
"python piano_autocomplete.py preprocess --input midis/ --output data/",
"python piano_autocomplete.py train --data data/ --model-dir runs/exp1/",
"python piano_autocomplete.py preprocess --input midis_sinteticos/ --output data/",
"python piano_autocomplete.py inspect --data data/"
],
"fam": false
},
{
"n": "piano_duo_analyzer",
"st": "practica",
"pa": "reglas",
"i": "MIDI 2 manos",
"o": "HTML coloreado por acorde",
"les": [
"practica",
"armonia"
],
"rel": [
"piano_duo_analyzer_v5"
],
"lines": 1362,
"t": "Visualizador HTML de piano a dos manos con análisis armónico (v2.0 → v5)",
"p": "Cuatro versiones (base v2.0, v3, v4, v5) del mismo visualizador: toma un MIDI de dos pistas (mano izquierda/derecha) y genera un informe HTML interactivo con tres filas sincronizadas — piano roll de la mano derecha coloreado según la posición de cada nota dentro del acorde detectado en la mano izquierda en ese instante (azul: nota fundamental/más grave del acorde; amarillo, verde, blanco: resto de notas del acorde;",
"a": "",
"c": "El esquema de color —fundamental/tonos del acorde vs. notas ajenas al acorde— es una codificación visual directa e inmediata del análisis armónico funcional aplicado nota a nota, pensada explícitamente como herramienta didáctica para que un estudiante de piano visualice de un vistazo qué notas de la mano derecha son “estructurales” (parte del acorde) y cuáles son ornamentales/de paso en relación con la armonía que sostiene la mano izquierda.",
"ex": [
"python3 piano_duo_analyzer.py archivo.mid",
"python3 piano_duo_analyzer.py archivo.mid -o informe.html",
"python3 piano_duo_analyzer.py archivo.mid --right 0 --left 1",
"python3 piano_duo_analyzer.py --test"
],
"fam": true
},
{
"n": "piano_duo_analyzer_v3",
"st": "practica",
"pa": "reglas",
"i": "MIDI 2 manos",
"o": "HTML coloreado por acorde",
"les": [
"practica"
],
"rel": [
"piano_duo_analyzer_v5"
],
"lines": 2107,
"t": "Visualizador HTML de piano a dos manos con análisis armónico (v2.0 → v5)",
"p": "Cuatro versiones (base v2.0, v3, v4, v5) del mismo visualizador: toma un MIDI de dos pistas (mano izquierda/derecha) y genera un informe HTML interactivo con tres filas sincronizadas — piano roll de la mano derecha coloreado según la posición de cada nota dentro del acorde detectado en la mano izquierda en ese instante (azul: nota fundamental/más grave del acorde; amarillo, verde, blanco: resto de notas del acorde;",
"a": "",
"c": "El esquema de color —fundamental/tonos del acorde vs. notas ajenas al acorde— es una codificación visual directa e inmediata del análisis armónico funcional aplicado nota a nota, pensada explícitamente como herramienta didáctica para que un estudiante de piano visualice de un vistazo qué notas de la mano derecha son “estructurales” (parte del acorde) y cuáles son ornamentales/de paso en relación con la armonía que sostiene la mano izquierda.",
"ex": [],
"fam": true
},
{
"n": "piano_duo_analyzer_v4",
"st": "practica",
"pa": "reglas",
"i": "MIDI 2 manos",
"o": "HTML coloreado por acorde",
"les": [
"practica"
],
"rel": [
"piano_duo_analyzer_v5"
],
"lines": 2563,
"t": "Visualizador HTML de piano a dos manos con análisis armónico (v2.0 → v5)",
"p": "Cuatro versiones (base v2.0, v3, v4, v5) del mismo visualizador: toma un MIDI de dos pistas (mano izquierda/derecha) y genera un informe HTML interactivo con tres filas sincronizadas — piano roll de la mano derecha coloreado según la posición de cada nota dentro del acorde detectado en la mano izquierda en ese instante (azul: nota fundamental/más grave del acorde; amarillo, verde, blanco: resto de notas del acorde;",
"a": "",
"c": "El esquema de color —fundamental/tonos del acorde vs. notas ajenas al acorde— es una codificación visual directa e inmediata del análisis armónico funcional aplicado nota a nota, pensada explícitamente como herramienta didáctica para que un estudiante de piano visualice de un vistazo qué notas de la mano derecha son “estructurales” (parte del acorde) y cuáles son ornamentales/de paso en relación con la armonía que sostiene la mano izquierda.",
"ex": [],
"fam": true
},
{
"n": "piano_duo_analyzer_v5",
"st": "practica",
"pa": "reglas",
"i": "MIDI 2 manos",
"o": "HTML coloreado por acorde",
"les": [
"practica",
"armonia"
],
"rel": [
"fingering_v6"
],
"lines": 2659,
"t": "Visualizador HTML de piano a dos manos con análisis armónico (v2.0 → v5)",
"p": "Cuatro versiones (base v2.0, v3, v4, v5) del mismo visualizador: toma un MIDI de dos pistas (mano izquierda/derecha) y genera un informe HTML interactivo con tres filas sincronizadas — piano roll de la mano derecha coloreado según la posición de cada nota dentro del acorde detectado en la mano izquierda en ese instante (azul: nota fundamental/más grave del acorde; amarillo, verde, blanco: resto de notas del acorde;",
"a": "",
"c": "El esquema de color —fundamental/tonos del acorde vs. notas ajenas al acorde— es una codificación visual directa e inmediata del análisis armónico funcional aplicado nota a nota, pensada explícitamente como herramienta didáctica para que un estudiante de piano visualice de un vistazo qué notas de la mano derecha son “estructurales” (parte del acorde) y cuáles son ornamentales/de paso en relación con la armonía que sostiene la mano izquierda.",
"ex": [],
"fam": true
},
{
"n": "piano_expander",
"st": "arreglo",
"pa": "reglas",
"i": "boceto de piano",
"o": "MIDI multipista línea a línea",
"les": [
"interpretacion"
],
"rel": [
"ml_expander",
"piano_reducer"
],
"lines": 1116,
"t": "Expansión orquestal de bocetos pianísticos (v2.0, línea por línea)",
"p": "Lee un MIDI de piano y genera un MIDI multi-pista con orquestación idiomática, donde cada instrumento genera su propia línea musical independiente de principio a fin — no una copia transpuesta mecánica del piano— siguiendo arquetipos rítmicos y de textura específicos de cada familia orquestal.",
"a": "La mejora central de la v2.0 es la arquitectura línea-por-línea: cada instrumento se genera de forma coherente e independiente a lo largo de toda la pieza (en vez de derivarse compás a compás de forma local, lo que produciría inconsistencia estilística entre secciones), con generadores rítmicos específicos por familia y arquetipo — las cuerdas generan figuraciones de arpegio, las maderas generan “colchones” armónicos sostenidos, los metales entran estratégicamente en los clímax formales, reflejando convenciones orquestales bien establecidas de qué familia instrumental cumple qué función textural.",
"c": "La reserva estratégica de los metales para el clímax formal es una convención orquestal muy consolidada (los metales tienen el mayor poder dinámico bruto de la orquesta y “gastarlos” pronto reduce el contraste disponible para el punto culminante), y las funciones texturales asignadas por familia (cuerdas=arpegio/movimiento, maderas=colchón armónico, metales=momento climático) reflejan convenciones de orquestación estándar enseñadas en cualquier tratado de orquestación desde Rimsky-Korsakov en adelante.",
"ex": [
"python piano_expander.py boceto.mid",
"python piano_expander.py boceto.mid --template full --style romantic",
"python piano_expander.py boceto.mid --split G4 --counter-density 0.5",
"python piano_expander.py boceto.mid --export-fingerprint --verbose"
],
"fam": false
},
{
"n": "piano_reducer",
"st": "arreglo",
"pa": "reglas",
"i": "MIDI orquestal / YAML",
"o": "reducción a 2 pentagramas",
"les": [
"interpretacion",
"practica"
],
"rel": [
"piano_expander"
],
"lines": 1298,
"t": "Reducción pianística de obras orquestales",
"p": "Lee un MIDI multi-pista (o un partitura.yaml) y genera una reducción pianística idiomática a dos pentagramas (mano derecha/izquierda), lista para evaluar en FL Studio o imprimir con MuseScore/LilyPond — la operación inversa exacta de piano_expander.py.",
"a": "Cinco estrategias de asignación de material a cada mano: smart (asignación inteligente según el rol musical detectado de cada pista, por defecto), register (mano derecha = notas por encima de un umbral de altura configurable, mano izquierda = por debajo — la partición más simple), layer (capas impares a la mano derecha, pares a la izquierda), priority (lista explícita de pistas prioritarias dada por el usuario) y melody+bass (la melodía principal siempre a la mano derecha, bajo y armonía combinados en la izquierda). Sobre la asignación de material se aplican técnicas pianísticas explícitas de reducción: reducción de notas simultáneas al límite polifónico ejecutable por una mano;",
"c": "El repertorio de técnicas (octavación, Alberti, compresión armónica) es exactamente el vocabulario estándar del “reductor” profesional que adapta una partitura orquestal a una versión de piano tocable por un único intérprete — una habilidad tradicionalmente aprendida por estudio de reducciones publicadas de repertorio orquestal y operístico.",
"ex": [
"python piano_reducer.py obra.mid",
"python piano_reducer.py obra.mid --strategy melody+bass --verbose",
"python piano_reducer.py obra.mid --split C4 --strategy register",
"python piano_reducer.py obra.mid --rh-tracks \"Violin I,Flute\""
],
"fam": false
},
{
"n": "piano_synth",
"st": "sonido",
"pa": "dsp",
"i": "MIDI / referencias",
"o": "piano modal, Rhodes FM, WAV",
"les": [
"sonido"
],
"rel": [
"ddsp_synth"
],
"lines": 5096,
"t": "Síntesis física de piano y teclados, con optimización espectral (5.096 líneas)",
"p": "Herramienta consolidada de fichero único (fusión de varios scripts previos generators/*.py) para síntesis basada en física de piano de cola (síntesis modal), Rhodes (síntesis FM), un sintetizador propio llamado “Prism”, comparación con DDSP, extracción de respuesta al impulso (IR) de referencia, y optimizadores de gradiente/evolución diferencial para ajustar parámetros de síntesis contra grabaciones reales.",
"a": "La síntesis modal del piano de cola modela cada cuerda percutida como una superposición de modos de vibración (armónicos con frecuencia, amortiguación y fase propios, derivados de un modelo físico simplificado de cuerda golpeada por un martillo, capturando fenómenos como la ligera inarmonicidad de las cuerdas de piano reales debida a su rigidez) — un enfoque de síntesis basada en física (physical modeling) más costoso computacionalmente pero más fiel al comportamiento acústico real que la síntesis aditiva pura.",
"c": "El contraste explícito entre síntesis modal basada en física (parámetros con significado físico directo: rigidez de cuerda, amortiguación) y síntesis DDSP (parámetros aprendidos, sin interpretación física directa necesaria) ilustra dos filosofías completas de modelado del sonido de un instrumento acústico: modelar las leyes físicas que lo producen, frente a aprender estadísticamente su comportamiento a partir de ejemplos.",
"ex": [
"python3 piano_synth.py <command> [options]",
"python3 piano_synth.py generate-grand --velocity-layers",
"python3 piano_synth.py optimize-phases --iters 400",
"python3 piano_synth.py compare-grand"
],
"fam": false
},
{
"n": "piano_to_orchestra",
"st": "arreglo",
"pa": "reglas",
"i": "MIDI de piano",
"o": "orquesta completa MIDI",
"les": [
"interpretacion"
],
"rel": [
"orchestrator",
"piano_expander"
],
"lines": 4007,
"t": "Piano MIDI → orquesta completa, autónomo (v2.3, 4.007 líneas)",
"p": "Recibe un MIDI de piano (melodía + armonía, 1 o 2 pistas) y genera directamente un MIDI orquestal completo con instrumentos reales, keyswitches, automatización CC1/CC11 y percusión — sin requerir orchestrator.py ni ningún otro módulo externo, deliberadamente autocontenido.",
"a": "El diseño en componentes encadenados —carga → extracción melódica → análisis armónico → generación de voces SATB → orquestación con timbre— reproduce, dentro de un único fichero autocontenido, el mismo pipeline conceptual que en el resto del ecosistema está distribuido entre varias herramientas independientes (midi_split_harmony, harmonic_analyzer, voice_leader, orchestrator/piano_expander), una decisión de diseño explícita para que esta herramienta funcione de forma completamente autónoma sin depender de la presencia del resto del ecosistema.",
"c": "Al integrar en un solo flujo la separación melodía/bajo, el análisis armónico funcional y la generación de un voicing SATB completo antes de orquestar, formaliza el proceso compositivo clásico de “armonización a cuatro voces primero, orquestación después” que se enseña en los cursos de orquestación tradicional, donde el arreglista parte de una reducción armónica correcta antes de distribuir las voces entre los instrumentos reales.",
"ex": [
"python piano_to_orchestra.py pieza.mid",
"python piano_to_orchestra.py pieza.mid --caracter romántico",
"python piano_to_orchestra.py pieza.mid --caracter épico",
"python piano_to_orchestra.py pieza.mid --caracter lúgubre"
],
"fam": false
},
{
"n": "pitch_transcriber",
"st": "captura",
"pa": "neuronal",
"i": "WAV",
"o": "MIDI (+pitch bends)",
"les": [
"sonido",
"representacion"
],
"rel": [
"muscriptor_transcribe",
"midi_split_harmony"
],
"lines": 852,
"t": "Adaptación de Basic Pitch (Spotify): audio → MIDI",
"p": "Adaptación al estilo mutopia de Basic Pitch (Spotify Research): un modelo ligero de transcripción polifónica audio→MIDI, ejecutado vía onnxruntime (sin dependencia de TensorFlow), validado explícitamente por equivalencia numérica exacta frente a la implementación original.",
"a": "El modelo produce tres posteriogramas (mapas de probabilidad tiempofrecuencia): uno de onsets (ataques de nota), uno de frames activos (presencia continua de nota) y uno de contorno de altura fino (para pitch bends). output_to_notes_polyphonic convierte estos posteriogramas en eventos de nota discretos mediante umbralización de onset/frame con un parámetro de duración mínima de nota, e incluye el “melodia trick” — una heurística tomada directamente del algoritmo de extracción de melodía predominante Melodia (Salamon & Gómez), que favorece la continuidad de una línea melódica sobre detecciones aisladas espurias.",
"c": "La distinción entre onset, frame y contorno de altura fino refleja tres aspectos perceptualmente distintos de una nota tocada: cuándo empieza exactamente, si sigue sonando, y con qué microvariaciones de afinación — la extracción de pitch bends explícitos es lo que permite que la transcripción capture matices expresivos de un instrumento real (una guitarra con bends, una voz con vibrato) que una transcripción puramente cuantizada a semitono descartaría por completo.",
"ex": [],
"fam": false
},
{
"n": "playability_auditor",
"st": "arreglo",
"pa": "reglas",
"i": "MIDI multipista",
"o": "informe de tocabilidad (+fix)",
"les": [
"interpretacion",
"practica"
],
"rel": [
"orchestral_colorist",
"performer"
],
"lines": 1172,
"t": "Auditoría de tocabilidad idiomática instrumental",
"p": "Cubre un hueco explícito: el ecosistema genera abundante material orquestal y evalúa su calidad musical (quality_scorer, section_score, voice_aligner), pero ninguna herramienta verificaba si un intérprete humano real podría físicamente tocar cada parte generada. Audita cada pista contra el perfil físico y técnico del instrumento asignado, y opcionalmente corrige lo corregible.",
"a": "Seis categorías de comprobación, cada una codificando una restricción física o técnica real de ejecución instrumental: rango (notas fuera del rango físico absoluto del instrumento —error duro— o fuera de su tesitura “cómoda”/idiomática —aviso, técnicamente posible pero forzado—); polifonía (acordes en instrumentos monofónicos por naturaleza — un instrumento de viento no puede tocar dos notas a la vez—, o dobles/triples cuerdas no idiomáticas en instrumentos de cuerda frotada, que solo pueden ejecutar ciertos intervalos dobles cómodamente según las cuerdas al aire disponibles);",
"c": "El catálogo de restricciones formaliza el conocimiento práctico de orquestación instrumental que un compositor aprende tradicionalmente estudiando tratados de orquestación e interactuando con intérpretes reales: cada familia instrumental tiene limitaciones físicas específicas (el fuelle/aliento de los vientos, la polifonía natural limitada de la cuerda frotada, la velocidad de articulación de cada técnica) que una generación puramente algorítmica, sin conocimiento explícito de estas restricciones, violaría…",
"ex": [
"python playability_auditor.py obra.mid",
"python playability_auditor.py obra.mid --verbose",
"python playability_auditor.py obra.mid --fix --output obra_fixed.mid",
"python playability_auditor.py obra.mid --json informe.json"
],
"fam": false
},
{
"n": "practice_tutor",
"st": "practica",
"pa": "reglas",
"i": "pieza de piano",
"o": "grado + plan de estudio",
"les": [
"practica"
],
"rel": [
"fingering_v6",
"tempo_designer"
],
"lines": 441,
"t": "Graduador de dificultad y generador de plan de estudio",
"p": "Completa el trío playability_auditor (¿es tocable?) + fingering (¿con qué dedos?) + este fichero (¿qué tan difícil es, y cómo practicarlo?): estima el nivel de dificultad de una pieza de piano, localiza los compases más difíciles y genera material de estudio estructurado — manos separadas, versión lenta (delegando en tempo_designer.py) y bucles de práctica de los compases más exigentes.",
"a": "El comando grade estima una nota de dificultad (escala 1-8, compartida con la familia combined_simplifier) descomponiéndola en factores explícitos: velocidad exigida (notas por segundo, resultado de tempo × densidad), extensión (amplitud de acordes/intervalos dentro de una sola mano), polifonía (número de notas simultáneas por mano) y saltos (distancia melódica grande dentro de una mano, que exige reposicionamiento rápido) — el mismo vocabulario de factores de dificultad que usa combined_simplifier.py para medir el grado resultante de una simplificación, aquí aplicado como herramienta de diagnóstico en vez de como función objetivo de una reducción.",
"c": "El pipeline “graduar dificultad → practicar manos separadas → practicar lento → hacer bucles de los pasajes difíciles” es exactamente la metodología de estudio pianístico estándar enseñada en cualquier conservatorio, automatizada aquí a partir del análisis objetivo de la partitura en vez de depender del criterio subjetivo del estudiante o profesor para decidir qué compases requieren atención especial.",
"ex": [
"python practice_tutor.py grade pieza.mid",
"python practice_tutor.py grade pieza.mid --split 60",
"python practice_tutor.py plan pieza.mid --slow-factor 0.6 --hard 3",
"python practice_tutor.py plan pieza.mid --outdir estudio/"
],
"fam": false
},
{
"n": "preference_trainer",
"st": "analisis",
"pa": "estadistica",
"i": "corpus + etiquetas",
"o": "modelo de gusto personal",
"les": [
"maquinas"
],
"rel": [
"select",
"counterexample"
],
"lines": 3847,
"t": "Aprendizaje de preferencias musicales personales (v1.2)",
"p": "Pipeline autónomo de siete comandos (index → train → eval → rank → set → validate → info) que aprende las preferencias musicales del usuario a partir de una colección de MIDIs indexada, y después evalúa/rankea obras nuevas según cuán bien encajan con ese perfil aprendido — uno de los cuatro EvalProvider mencionados en audio_reference_scorer.py, aquí en su forma nativa sobre MIDI simbólico.",
"a": "index vectoriza el corpus completo (con el mismo patrón de “una sola vez, cacheado” visto en corpus_explorer.py y analyzer.py: 100.000 MIDIs en 1-3 horas), con features opcionalmente extendidas o específicamente melódicas según el flag elegido. train ajusta un modelo (presumiblemente un clasificador o regresor sobre el espacio vectorial indexado, dado el flujo posterior de eval/rank) que aprende a distinguir obras “preferidas” de “no preferidas” a partir de las etiquetas que el usuario proporciona durante el entrenamiento. eval puntúa un MIDI nuevo contra ese modelo aprendido; rank ordena varios candidatos por esa puntuación;",
"c": "A diferencia de quality_scorer.py (que mide calidad musical según criterios teóricos generales) o audio_reference_scorer.py (que mide afinidad a un corpus de referencia externo fijo), este fichero aprende específicamente el gusto individual del usuario concreto —una función de preferencia personalizada, no una noción universal de “buena música”— lo cual lo convierte en el componente de evaluación más directamente subjetivo y personalizado del ecosistema, apropiado como señal de recompensa en bucles de refinamiento…",
"ex": [
"python preference_trainer.py index ./midis/",
"python preference_trainer.py index ./midis/ --output corpus.npz",
"python preference_trainer.py index ./midis/ --extended-features",
"python preference_trainer.py index ./melodias/ --melodic-features"
],
"fam": false
},
{
"n": "quality_scorer",
"st": "analisis",
"pa": "estadistica",
"i": "MIDI (+corpus)",
"o": "calidad en 5 dimensiones",
"les": [
"maquinas"
],
"rel": [
"section_score",
"preference_trainer"
],
"lines": 2912,
"t": "Evaluación multidimensional de calidad musical (v1.2)",
"p": "Evalúa una o varias obras MIDI en cinco dimensiones de calidad —formal (corrección de conducción de voces e intervalos), coherencia (homogeneidad interna entre secciones), arco (estructura del arco emocional/tensión), melódica (interés y variedad) y corpus (similitud estilística a una colección de referencia)— con un score final relativo (percentil dentro de un corpus dado) y un fallback absoluto (0.0-1.0) cuando no hay corpus disponible.",
"a": "La combinación de las cinco dimensiones en un score único no usa pesos fijos: los pesos efectivos se modulan automáticamente por la confianza de cada dimensión — si, por ejemplo, la dimensión “corpus” no tiene suficientes referencias fiables para producir una estimación confiable, su peso en el score combinado se reduce automáticamente en favor de las dimensiones que sí tienen una estimación sólida, en vez de contribuir con un número potencialmente ruidoso al mismo peso nominal que las demás — una forma de ponderación bayesiana implícita por incertidumbre, evitando que una dimensión mal estimada arrastre el resultado combinado tanto como una bien estimada.",
"c": "Las cinco dimensiones cubren sistemáticamente los ejes de evaluación musical más citados en la literatura de composición asistida por IA (corrección técnica, coherencia estructural, arco dramático, interés melódico, fidelidad estilística), ofreciendo tanto un score absoluto interpretable (para obras aisladas) como uno relativo (percentil, más informativo cuando se dispone de un corpus de comparación amplio y representativo del estilo objetivo).",
"ex": [
"python quality_scorer.py obra.mid",
"python quality_scorer.py obra.mid --plan obra.theorist.json",
"python quality_scorer.py obra.mid --corpus ./midis/",
"python quality_scorer.py obra.mid --corpus ./midis/ --save-cache c.qcache"
],
"fam": false
},
{
"n": "reharmonizer",
"st": "armonia",
"pa": "reglas",
"i": "melodía MIDI",
"o": "N reharmonizaciones MIDI",
"les": [
"armonia"
],
"rel": [
"tonicization_engine",
"melody_adapter"
],
"lines": 1219,
"t": "Reharmonización guiada de melodías con progresiones alternativas (v1.1)",
"p": "Toma una melodía fija y genera N versiones con progresiones armónicas alternativas, aplicando técnicas de reharmonización clásica, jazzística y modal, validando en cada caso la compatibilidad de cada nota melódica con la nueva armonía propuesta.",
"a": "Once estrategias de reharmonización, cada una un procedimiento armónico histórico o técnico bien documentado: sustitución diatónica simple; sustitución de tritono (bII7 en vez de V7 — ambos acordes comparten el mismo tritono característico entre tercera y séptima, la sustitución armónica más emblemática del jazz moderno); dominantes secundarios (V/ii, V/IV, V/V…, tonicización temporal de grados no tónicos); préstamo modal (tomar acordes del modo paralelo —bVII, bIII, iv en mayor— un recurso extensamente usado en pop/rock y romanticismo); mediante cromática (III, bVI, bII usados como mediantes cromáticas en vez de diatónicas, un recurso central del lenguaje armónico romántico tardío);",
"c": "El catálogo de once estrategias constituye, en efecto, un pequeño compendio histórico de técnicas de reharmonización occidentales desde el barroco (napolitana) hasta el jazz moderno más avanzado armónicamente (ciclos de Coltrane), cada una con su propia lógica de sustitución y su propio “sabor” estilístico reconocible, validadas todas contra la restricción común de que la melodía original siga siendo consonante o al menos plausible sobre la nueva armonía propuesta.",
"ex": [
"python reharmonizer.py melodia.mid",
"python reharmonizer.py melodia.mid --strategy tritone secondary",
"python reharmonizer.py melodia.mid --strategy all --out-dir salidas/",
"python reharmonizer.py melodia.mid --key \"D minor\" --bars 16"
],
"fam": false
},
{
"n": "remi",
"st": "neuronal",
"pa": "neuronal",
"i": "MIDI / corpus",
"o": "tokens REMI, piano pop",
"les": [
"representacion",
"maquinas"
],
"rel": [
"remi_diffusion_v2"
],
"lines": 1533,
"t": "Pop Music Transformer (REMI): generación y continuación de piano pop",
"p": "Implementación del paper “Pop Music Transformer: Beat-Based Modeling and Generation of Expressive Pop Piano Compositions” (Huang & Yang, ACM MM 2020): genera y continúa piezas de piano pop expresivo usando la representación REMI y un TransformerXL.",
"a": "La arquitectura es un Transformer-XL (12 capas, d_model=512, 8 cabezas): a diferencia de un Transformer estándar con contexto fijo, Transformer-XL mantiene una memoria recurrente de los últimos 512 tokens de segmentos anteriores, reutilizada (sin recalcular) como contexto adicional al procesar el segmento actual — extendiendo efectivamente el contexto disponible mucho más allá de la ventana de atención nominal del segmento actual, y evitando el problema de fragmentación de contexto que sufriría un Transformer estándar al procesar una pieza larga en trozos independientes sin memoria entre ellos.",
"c": "El anclaje explícito a la rejilla métrica (Bar/Position) en vez de a deltas de tiempo continuos formaliza directamente la intuición de que la música popular occidental tiene una estructura métrica muy regular y perceptualmente central (el pulso, el compás), y que darle al modelo esa estructura como información explícita en el vocabulario de tokens —en vez de esperar que la infiera puramente de los datos— mejora significativamente la coherencia rítmica percibida de la generación resultante.",
"ex": [
"python remi.py convert entrada.mid",
"python remi.py convert entrada.mid --chord --output tokens.json",
"python remi.py convert corpus/ --chord --vocab vocab_chord.json",
"python remi.py inspect entrada.mid"
],
"fam": false
},
{
"n": "remi_diffusion",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus REMI",
"o": "generación por difusión discreta",
"les": [
"maquinas"
],
"rel": [
"remi"
],
"lines": 1332,
"t": "Modelo de lenguaje de difusión enmascarada sobre tokens REMI (v1 y v2)",
"p": "Dos versiones aplican modelos de lenguaje de difusión (en vez de generación autorregresiva) al mismo vocabulario de tokens REMI de remi.py, siguiendo directamente la guía técnica del grupo de investigación de Kuleshov (“How to Build a Diffusion Language Model”).",
"a": "",
"c": "La capacidad de “remasking”/“re-ruido” durante el muestreo —ausente en cualquier generación puramente autorregresiva— es la ventaja conceptual central de aplicar difusión a la generación musical simbólica: permite que el modelo revise y corrija decisiones armónicas o melódicas ya tomadas si resultan inconsistentes con material generado después, un tipo de “edición durante la composición” que ningún modelo estrictamente izquierda→derecha puede realizar sin regenerar desde el punto de inconsistencia.",
"ex": [
"python remi_diffusion.py convert corpus/ --vocab vocab_chord.json",
"python remi_diffusion.py inspect --input prompt.mid --canvas-len 48"
],
"fam": true
},
{
"n": "remi_diffusion_v2",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus REMI",
"o": "generación por difusión discreta",
"les": [
"maquinas"
],
"rel": [
"remi"
],
"lines": 1617,
"t": "Modelo de lenguaje de difusión enmascarada sobre tokens REMI (v1 y v2)",
"p": "Dos versiones aplican modelos de lenguaje de difusión (en vez de generación autorregresiva) al mismo vocabulario de tokens REMI de remi.py, siguiendo directamente la guía técnica del grupo de investigación de Kuleshov (“How to Build a Diffusion Language Model”).",
"a": "",
"c": "La capacidad de “remasking”/“re-ruido” durante el muestreo —ausente en cualquier generación puramente autorregresiva— es la ventaja conceptual central de aplicar difusión a la generación musical simbólica: permite que el modelo revise y corrija decisiones armónicas o melódicas ya tomadas si resultan inconsistentes con material generado después, un tipo de “edición durante la composición” que ningún modelo estrictamente izquierda→derecha puede realizar sin regenerar desde el punto de inconsistencia.",
"ex": [
"python remi_diffusion_v2.py convert corpus/ --vocab vocab_chord.json"
],
"fam": true
},
{
"n": "rhythm_table",
"st": "ritmo",
"pa": "reglas",
"i": "búsqueda por estilo/emoción",
"o": "patrón rítmico MIDI",
"les": [
"ritmo"
],
"rel": [
"chord_table",
"drummer"
],
"lines": 1568,
"t": "Catálogo curado de patrones rítmicos con tensión y emoción",
"p": "Complemento rítmico de chord_table.py: catálogo curado de patrones rítmicos —tanto células de una sola línea de onsets como grooves multi-voz completos— con etiquetas de tensión (1-10) y emoción, buscables y exportables; un patrón puede usarse como base percusiva independiente o como “ritmo armónico” (puntos de cambio de acorde) aplicado sobre una progresión de chord_table.py.",
"a": "",
"c": "El uso dual de un mismo patrón rítmico —como base percusiva directa, o como “ritmo armónico” que determina en qué instantes cambia el acorde de una progresión— formaliza una idea poco frecuente pero musicalmente rica: el ritmo de cambio armónico (harmonic rhythm) de una pieza es en sí mismo un patrón rítmico con su propia identidad estilística, tan característico de un género como su patrón de batería literal — el ritmo armónico sincopado de un tango no es casual, comparte la misma “sensación” rítmica que su…",
"ex": [
"python rhythm_table.py --list",
"python rhythm_table.py --emocion euforia",
"python rhythm_table.py --style flamenco --tipo celula",
"python rhythm_table.py --uso ritmo_armonico"
],
"fam": false
},
{
"n": "runner",
"st": "plan",
"pa": "infra",
"i": "plan.yaml",
"o": "ejecución de todo el pipeline",
"les": [
"taller"
],
"rel": [
"theorist",
"narrator"
],
"lines": 1391,
"t": "Ejecutor de pipelines de composición",
"p": "Lee un plan .yaml producido por theorist.py o narrator.py y ejecuta cada paso del pipeline compositivo en orden, con logging, gestión de errores, puntos de pausa interactivos y capacidad de reanudar pipelines interrumpidos — el “orquestador de orquestadores” que convierte un plan declarativo de alto nivel en una secuencia real de invocaciones a las demás herramientas del ecosistema.",
"a": "Cinco etapas: (1) carga, detecta automáticamente si el YAML proviene del formato de theorist.py o de narrator.py (formatos de plan potencialmente distintos, manejados de forma transparente); (2) validación, verifica que todos los scripts referenciados en el plan existen realmente en el sistema de ficheros y que sus inputs están disponibles antes de lanzar nada, evitando fallos a mitad de una ejecución larga por un error trivial de configuración detectable de antemano; (3) ejecución, lanza cada paso como proceso, registrando stdout/stderr y midiendo duración;",
"c": "Aunque el contenido es de infraestructura de ejecución más que de teoría musical, refleja la naturaleza intrínsecamente secuencial y dependiente del proceso compositivo modelado por el ecosistema: un plan narrativo determina la estructura formal, que determina las curvas de tensión, que determinan la armonía, que determina la melodía — una cadena de dependencias donde cada paso consume la salida del anterior, exactamente el tipo de flujo de trabajo que un ejecutor de pipeline con checkpointing está diseñado para…",
"ex": [
"python runner.py obra_plan.yaml",
"python runner.py obra_plan.yaml --pause-after tension_designer",
"python runner.py obra_plan.yaml --from midi_dna_unified",
"python runner.py obra_plan.yaml --only midi_dna_unified reharmonizer"
],
"fam": false
},
{
"n": "schenker_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "nivel reducido",
"o": "elaboración hacia la superficie",
"les": [
"maquinas"
],
"rel": [
"schenkerian_reducer"
],
"lines": 1502,
"t": "Elaboración generativa y reducción analítica schenkeriana",
"p": "Un par complementario que aborda la reducción schenkeriana en direcciones opuestas: schenkerian_reducer.py (v1.0) parte de una obra ya compuesta (superficie / Vordergrund) y produce reducciones progresivas hacia una estructura fundamental candidata (Ursatz: una línea melódica descendente por grados conjuntos —Urlinie, con anclaje típico en el tercer grado— sobre un bajo I-V-I, Bassbrechung, el arpegio de bajo fundamental de la teoría schenkeriana);",
"a": "La reducción se basa en una heurística de puntuación combinada de peso métrico, peso armónico (pertenencia al acorde activo) y duración de cada nota, usada para decidir qué notas pertenecen a cada nivel jerárquico de reducción — la aproximación computacionalmente tratable a un proceso que en la práctica analítica humana depende de juicio experto no formalizable completamente.",
"c": "El par de herramientas formaliza los dos sentidos del análisis schenkeriano clásico —análisis (reducir una superficie a su estructura profunda) y, especulativamente, síntesis (elaborar una estructura profunda hacia una superficie plausible)— con la honestidad epistemológica explícita de que ambos procesos son heurísticos, no algorítmicamente exactos, reflejando fielmente el estatus real de la teoría schenkeriana en la musicología académica: una herramienta analítica poderosa e influyente pero no un sistema formal…",
"ex": [
"python schenker_composer.py synth-corpus corpus/ --n 40",
"python schenker_composer.py prepare corpus/ --out dataset.npz",
"python schenker_composer.py train dataset.npz --model-dir modelo/",
"python schenker_composer.py inspect obra.mid"
],
"fam": false
},
{
"n": "schenkerian_reducer",
"st": "analisis",
"pa": "busqueda",
"i": "obra MIDI",
"o": "niveles de reducción",
"les": [
"melodia",
"forma"
],
"rel": [
"schenker_composer"
],
"lines": 1249,
"t": "Elaboración generativa y reducción analítica schenkeriana",
"p": "Un par complementario que aborda la reducción schenkeriana en direcciones opuestas: schenkerian_reducer.py (v1.0) parte de una obra ya compuesta (superficie / Vordergrund) y produce reducciones progresivas hacia una estructura fundamental candidata (Ursatz: una línea melódica descendente por grados conjuntos —Urlinie, con anclaje típico en el tercer grado— sobre un bajo I-V-I, Bassbrechung, el arpegio de bajo fundamental de la teoría schenkeriana);",
"a": "La reducción se basa en una heurística de puntuación combinada de peso métrico, peso armónico (pertenencia al acorde activo) y duración de cada nota, usada para decidir qué notas pertenecen a cada nivel jerárquico de reducción — la aproximación computacionalmente tratable a un proceso que en la práctica analítica humana depende de juicio experto no formalizable completamente.",
"c": "El par de herramientas formaliza los dos sentidos del análisis schenkeriano clásico —análisis (reducir una superficie a su estructura profunda) y, especulativamente, síntesis (elaborar una estructura profunda hacia una superficie plausible)— con la honestidad epistemológica explícita de que ambos procesos son heurísticos, no algorítmicamente exactos, reflejando fielmente el estatus real de la teoría schenkeriana en la musicología académica: una herramienta analítica poderosa e influyente pero no un sistema formal…",
"ex": [
"python schenkerian_reducer.py obra.mid",
"python schenkerian_reducer.py obra.mid --key Cmaj --window 1",
"python schenkerian_reducer.py obra.mid --max-levels 4 --threshold 0.35",
"python schenkerian_reducer.py obra.mid --candidates 3 --explain"
],
"fam": false
},
{
"n": "section_score",
"st": "analisis",
"pa": "estadistica",
"i": "obra MIDI",
"o": "secciones incoherentes",
"les": [
"forma"
],
"rel": [
"quality_scorer",
"harvester"
],
"lines": 1640,
"t": "Detección de secciones musicalmente incoherentes",
"p": "Segmenta una obra MIDI, construye un perfil global de la pieza y puntúa cada segmento en cuatro ejes de coherencia musical, permitiendo detectar automáticamente qué secciones “no encajan” con el resto de la obra — útil para auditar material generado algorítmicamente que puede producir incoherencias locales invisibles a una inspección superficial.",
"a": "Cuatro ejes de coherencia, cada uno capturando un tipo distinto de “encaje”: tonal (compatibilidad de la melodía/armonía del segmento con la tonalidad global estimada de toda la obra — un segmento que modula sin resolución a una tonalidad lejana puntuaría bajo aquí); estructural (distancia vectorial del segmento respecto al perfil vectorial medio de toda la obra — detecta segmentos “atípicos” en un sentido estadístico general, no solo tonal);",
"c": "La distinción entre coherencia “estructural” (respecto al perfil global) y “vecinal” (respecto a los vecinos inmediatos) formaliza dos nociones distintas y a veces contradictorias de “encajar” en una obra: una sección puede ser estadísticamente típica de la pieza en su conjunto pero sonar como una transición brusca en su contexto local inmediato, o viceversa —típica de sus vecinos pero atípica del carácter general de la obra.",
"ex": [
"python section_score.py obra.mid",
"python section_score.py obra.mid --granularity form --weights harmonic",
"python section_score.py obra.mid --granularity fixed 8 --top 3",
"python section_score.py obra.mid --granularity hybrid --weights custom 0.4,0.2,0.3,0.1"
],
"fam": false
},
{
"n": "select",
"st": "analisis",
"pa": "estadistica",
"i": "carpeta de MIDIs",
"o": "selección curada (UMAP+KMeans)",
"les": [
"maquinas"
],
"rel": [
"preference_trainer"
],
"lines": 524,
"t": "Selección interactiva de MIDIs por clustering UMAP + KMeans",
"p": "Vectoriza una colección completa de MIDIs, los agrupa por similitud musical mediante clustering, y presenta muestras representativas de cada grupo para escucha y selección manual — una herramienta de curación asistida para explorar grandes colecciones (p. ej. la salida masiva de un generador algorítmico) sin tener que escuchar cada fichero individualmente.",
"a": "El flujo combina dos técnicas complementarias de análisis multivariante no supervisado: KMeans particiona el espacio vectorial de la colección en N grupos (clusters) según similitud, mientras UMAP (la misma técnica de reducción de dimensionalidad no lineal usada en analyzer.py) proyecta ese mismo espacio de alta dimensión a 2D, coloreado por cluster o por score emocional, para dar una visión de conjunto navegable de toda la colección.",
"c": "El clustering musical automático antes de la escucha manual reduce drásticamente el esfuerzo de curación: en vez de escuchar cada uno de, por ejemplo, cientos de fragmentos generados por mosaic_composer.py o evolver.py, el usuario escucha solo unas pocas muestras representativas de cada grupo estilísticamente coherente, confiando en que el resto de miembros de ese cluster son musicalmente similares a las muestras ya evaluadas.",
"ex": [
"python select.py                          (usa carpeta actual)",
"python select.py --folder ./midis/        (carpeta específica)",
"python select.py --clusters 30 --samples 5",
"python select.py --ref ref1.mid ref2.mid  (ordenar por referencia)"
],
"fam": false
},
{
"n": "silence_designer",
"st": "expresion",
"pa": "reglas",
"i": "obra MIDI",
"o": "luftpausen, pausas, fermata",
"les": [
"forma"
],
"rel": [
"climax_engineer"
],
"lines": 320,
"t": "El silencio como recurso dramático deliberado",
"p": "Observación de diseño explícita: los compositores automáticos del ecosistema tienden a “rellenar” —textura continua, sin respiraciones— y el silencio es el recurso emotivo más barato y menos aprovechado en generación algorítmica. Esta herramienta audita la saturación textural de una obra y abre espacio donde la narrativa lo pide, con la restricción explícita de nunca insertar tiempo (los huecos se crean acortando notas existentes, preservando la métrica original intacta).",
"a": "Cuatro operaciones, cada una un recurso retórico del silencio distinto: luftpause (respiraciones breves en las fronteras de sección, detectadas por novedad armónica combinada con cambio de densidad — el mismo tipo de detección de frontera usado por harvester.py, aquí aplicado para decidir dónde respirar en vez de dónde segmentar); pausa (silencio dramático general antes de un compás clave, especificado manualmente o colocado automáticamente antes del pico de energía de la obra);",
"c": "La restricción de “nunca insertar tiempo, solo acortar” es una decisión de diseño deliberada que preserva la forma métrica global de la obra intacta mientras crea la sensación perceptual de espacio y aire —el silencio como elemento expresivo activo, no como ausencia de contenido—, un recurso retórico central en la práctica compositiva madura (el silencio antes de una entrada dramática, la respiración de frase) que un generador puramente aditivo tiende sistemáticamente a pasar por alto.",
"ex": [
"python silence_designer.py obra.mid --report",
"python silence_designer.py obra.mid",
"python silence_designer.py obra.mid --pause-before 21 --gap 1.0",
"python silence_designer.py obra.mid --auto --thin --fermata"
],
"fam": false
},
{
"n": "song_architect",
"st": "plan",
"pa": "reglas",
"i": "frases MIDI",
"o": "canción completa MIDI",
"les": [
"forma",
"taller"
],
"rel": [
"phrase_builder",
"variation_engine"
],
"lines": 1670,
"t": "De frases sueltas a estructura de canción popular completa (v2.0)",
"p": "Toma un número reducido de frases musicales (fragmentos MIDI) y genera una obra completa con estructura de canción popular estándar —Intro, Verso, Pre-estribillo, Estribillo, Verso 2, Puente, Solo, Outro— con coherencia musical genuina entre secciones, no una simple yuxtaposición de las frases dadas.",
"a": "La coherencia entre secciones se garantiza mediante varios mecanismos combinados: tonalidad y modo unificados para toda la obra; conducción de voces entre secciones y entre acordes consecutivos (evitando saltos armónicos abruptos en las fronteras de sección); curvas de tensión dramática asignadas por sección (siguiendo la función retórica esperada de cada una: un estribillo típicamente en mayor tensión/energía que un verso); transformaciones motívicas coherentes (variación, inversión, aumentación —el mismo catálogo contrapuntístico de leitmotif_analyst.py/variation_engine.py— aplicadas a las frases fuente para generar material derivado pero relacionado en cada sección nueva);",
"c": "La plantilla formal (Intro-Verso-Pre-Estribillo-Estribillo-Verso2Puente-Solo-Outro) es la estructura canónica de la canción popular anglosajona contemporánea, y asignar una función retórica y un nivel de tensión característico a cada etiqueta formal (el estribillo como punto de máxima memorabilidad/energía, el puente como sección de contraste armónico) formaliza convenciones de songwriting ampliamente documentadas en manuales de composición de canciones populares.",
"ex": [
"python song_architect.py frase1.mid frase2.mid frase3.mid",
"python song_architect.py *.mid --key Am --tempo 120",
"python song_architect.py frases/*.mid --style pop --out-dir cancion/",
"python song_architect.py *.mid --no-solo --no-bridge --bars-per-section 8"
],
"fam": false
},
{
"n": "spectro_midi",
"st": "captura",
"pa": "neuronal",
"i": "NPZ / WAV",
"o": "MIDI",
"les": [
"sonido"
],
"rel": [
"audio_lab"
],
"lines": 1858,
"t": "Transcripción de espectrogramas NPZ a MIDI (CNN + Transformer, agnóstico de instrumento)",
"p": "Transcribe espectrogramas (formato .npz compartido con audio_lab.py) o audio WAV directamente a MIDI, mediante un modelo entrenado CNN+Transformer agnóstico del instrumento fuente, con un bucle autónomo (autotrain) que genera datos, entrena, evalúa e itera sin supervisión constante — además de dos modos deterministas sin aprendizaje automático (melody/harmony, por pico espectral puro) como alternativa ligera.",
"a": "La arquitectura combina una CNN (para extraer features espaciales locales del espectrograma, análogo a su uso estándar en visión por computador aplicado aquí a la “imagen” tiempo-frecuencia) con un Transformer (para modelar dependencias de más largo alcance sobre la secuencia de features extraídas por la CNN) — un patrón arquitectónico híbrido CNN+Transformer común en transcripción de audio, donde la CNN captura patrones espectrales locales (la forma de un armónico, un ataque) y el Transformer captura la estructura temporal global (cuándo empiezan y terminan las notas en relación unas con otras).",
"c": "Ofrecer explícitamente tanto un camino de aprendizaje profundo (preciso pero requiere entrenamiento) como un camino puramente de procesamiento de señal (melody/harmony, sin ML, inmediato) para el mismo problema de transcripción refleja un patrón recurrente y deliberado del ecosistema: proporcionar siempre un fallback determinista y sin dependencias pesadas junto a la opción neuronal más potente.",
"ex": [
"python spectro_midi.py prepare --midi-dir midis/ --out-dir corpus/",
"python spectro_midi.py eval --predicted out.mid --reference orig.mid",
"python spectro_midi.py melody audio.npz --output melodia.mid"
],
"fam": false
},
{
"n": "stem_separator",
"st": "captura",
"pa": "neuronal",
"i": "WAV mezclado",
"o": "4 stems WAV",
"les": [
"sonido"
],
"rel": [
"pitch_transcriber",
"muscriptor_transcribe"
],
"lines": 1242,
"t": "Separación de fuentes de audio (HTDemucs, sin la librería demucs)",
"p": "Reimplementación autocontenida (un único fichero, dependencias mínimas) de Hybrid Transformer Demucs v4 (Rouard et al., Meta AI): separa un WAV mezclado en cuatro stems (batería, bajo, resto, voces) cargando el checkpoint preentrenado oficial “htdemucs”, sin depender del paquete demucs completo ni de su cadena de dependencias (dora, omegaconf, einops…).",
"a": "La arquitectura híbrida procesa la mezcla por dos ramas paralelas: una rama de frecuencia que opera sobre la representación STFT (tratando la parte real e imaginaria del espectro complejo como canales separados, “complex-as-channels”) mediante una U-Net, y una rama de forma de onda cruda (dominio temporal directo) mediante otra U-Net paralela — combinando así las ventajas de ambos dominios de representación, ya que ciertos tipos de separación (p. ej. transitorios percusivos nítidos) se benefician de la resolución temporal directa mientras otros (separación tonal) se benefician de la estructura espectral.",
"c": "La combinación híbrida frecuencia+tiempo refleja que ningún dominio de representación único es óptimo para todos los tipos de fuente de audio a separar: la batería (contenido transitorio, ataques nítidos) se beneficia de la resolución temporal directa, mientras que la voz o instrumentos armónicos sostenidos se benefician de la estructura espectral clara del dominio de frecuencia — combinar ambas ramas con un mecanismo de fusión (el Transformer del cuello de botella) permite que el modelo aproveche lo mejor de cada…",
"ex": [
"python stem_separator.py install",
"python stem_separator.py install --output ~/mis_modelos/htdemucs.th",
"python stem_separator.py separate cancion.wav",
"python stem_separator.py separate cancion.wav --output-dir stems/"
],
"fam": false
},
{
"n": "stitcher",
"st": "ensamblaje",
"pa": "busqueda",
"i": "fragmentos + fingerprints",
"o": "obra ensamblada con puentes",
"les": [
"forma",
"taller"
],
"rel": [
"midi_dna_unified",
"orchestrator"
],
"lines": 1165,
"t": "Orquestador de fragmentos MIDI con coherencia armónica (“Coherence Stitcher”)",
"p": "Usa los fingerprints (.fingerprint.json) generados por midi_dna_unified.py para tomar un conjunto de fragmentos MIDI dispersos, analizarlos, ordenarlos en la secuencia más coherente posible (o respetar un orden manual), puntuar cada transición posible entre fragmentos, generar puentes automáticos entre fragmentos incompatibles, y ensamblar el MIDI final.",
"a": "El “puntuado” de cada transición posible entre dos fragmentos combina compatibilidad armónica, de registro, de tempo y de tensión — es decir, el problema de encontrar el mejor orden de una colección de fragmentos para ensamblarlos coherentemente es estructuralmente un problema de camino de coste mínimo sobre un grafo completo donde los nodos son fragmentos y las aristas están ponderadas por el coste (incompatibilidad) de la transición entre cada par — análogo en estructura al problema del viajante (TSP) aunque probablemente resuelto aquí con una heurística voraz o de inserción en vez de una solución exacta, dada la naturaleza del dominio.",
"c": "El fichero formaliza el trabajo de un editor de “collage” musical experimentado: decidir en qué orden suenan mejor juntos varios fragmentos independientes, y cuándo un fragmento necesita un puente de transición explícito (una modulación, un enlace armónico) en vez de encajar directamente con el siguiente — un problema combinatorio con una lectura musical clara de compatibilidad tonal y de tensión.",
"ex": [
"python stitcher.py seccion_A.fingerprint.json seccion_B.fingerprint.json seccion_C.fingerprint.json",
"python stitcher.py seccion_A.mid seccion_B.mid seccion_C.mid",
"python stitcher.py *.fingerprint.json --fixed-order",
"python stitcher.py *.fingerprint.json --analyze-only"
],
"fam": false
},
{
"n": "style_blender",
"st": "ensamblaje",
"pa": "reglas",
"i": "contenido + 2 estilos + curva",
"o": "fusión progresiva",
"les": [
"maquinas"
],
"rel": [
"style_transfer",
"tension_designer"
],
"lines": 1019,
"t": "Fusión dinámica de dos estilos a lo largo de una obra",
"p": "A diferencia de style_transfer.py (un único estilo aplicado a toda la obra con una intensidad fija), mezcla dos fuentes de estilo simultáneamente usando una curva de mezcla (blend) que cambia compás a compás — permitiendo fusiones progresivas como “pop→tango” o “clásico→jazz”, un viaje continuo entre dos mundos sonoros en vez de un punto fijo intermedio.",
"a": "",
"c": "Que la curva de mezcla pueda importarse de tension_designer.py conecta directamente el eje puramente estilístico (qué “suena a” cada fuente) con el eje dramático-emocional del resto del ecosistema: una transición de estilo pop→tango podría, por ejemplo, coincidir deliberadamente con una curva de tensión creciente, de modo que el cambio estilístico refuerce perceptualmente el arco dramático de la obra en vez de ser un efecto puramente decorativo independiente de la narrativa musical.",
"ex": [],
"fam": false
},
{
"n": "style_transfer",
"st": "ensamblaje",
"pa": "reglas",
"i": "contenido.mid + estilo.mid",
"o": "contenido con ADN del estilo",
"les": [
"maquinas"
],
"rel": [
"style_blender",
"midi_dna_unified"
],
"lines": 756,
"t": "Transferencia de estilo: aplica el ADN de un MIDI a otro",
"p": "Dado un MIDI de “contenido” (la idea melódica del usuario) y un MIDI de “estilo”, preserva la esencia melódica del primero mientras aplica el ADN rítmico, armónico, emocional y de textura del segundo — un “filtro de estilo” musical explícitamente diseñado para mantener la voz creativa original del usuario, no para sustituirla.",
"a": "Seis dimensiones de transferencia controlables independientemente (ritmo/groove, armonía, emoción, timbre/textura de acompañamiento, dinámica, tonalidad — con transposición opcional del contenido a la tonalidad del estilo) permiten decidir exactamente cuánto de cada aspecto del estilo se importa, dejando el resto fiel al contenido original. Dos estrategias de preservación melódica explícitas: preservar contorno (mantiene la dirección ascendente/descendente de la melodía original, pero permite que los intervalos exactos se ajusten para encajar con la nueva armonía del estilo) frente a preservar intervalos (mantiene los saltos melódicos exactos del original, aceptando potencialmente más…",
"c": "La distinción preservar-contorno vs. preservar-intervalos formaliza una tensión real en cualquier reharmonización o transferencia de estilo: el contorno (forma general de la línea) y los intervalos exactos (su contenido preciso) son ambos candidatos razonables a “lo esencial” de una melodía, y cuál se prioriza depende de si se valora más la silueta reconocible de la idea o su contenido armónico literal.",
"ex": [
"python style_transfer.py contenido.mid estilo.mid",
"python style_transfer.py mi_melodia.mid bach.mid --strength 0.8",
"python style_transfer.py mi_melodia.mid jazz.mid --no-key-transfer",
"python style_transfer.py mi_melodia.mid estilo.mid --verbose"
],
"fam": false
},
{
"n": "synth_forge",
"st": "sonido",
"pa": "dsp",
"i": "MIDI + parámetros",
"o": "WAV (6 paradigmas de síntesis)",
"les": [
"sonido"
],
"rel": [
"audio_lab",
"genopatch_v2"
],
"lines": 719,
"t": "Motor de síntesis multi-paradigma (seis técnicas clásicas en Python puro)",
"p": "Implementa en NumPy puro (sin Csound, SuperCollider ni Faust externos) seis paradigmas clásicos de síntesis sonora, cada uno accesible como subcomando independiente con su propio conjunto de parámetros.",
"a": "Los seis paradigmas: sample (síntesis por muestras con keymap y capas de velocidad, al estilo del formato ligero SFZ — la técnica estándar de sampler profesional: distintas grabaciones reales disparadas según rango de altura y de velocidad de la nota tocada); waveguide (modelado físico por guía de onda, una extensión del algoritmo Karplus-Strong —simulación de una cuerda pulsada mediante una línea de retardo realimentada con filtrado— con modos adicionales plucked (pulsada) y bowed (frotada, modelando explícitamente la fricción stick-slip entre el arco y la cuerda, el mecanismo físico real por el que un arco de violín excita la vibración de la cuerda mediante ciclos alternos de adherencia y…",
"c": "El catálogo cubre sistemáticamente las grandes familias históricas de síntesis de sonido —muestreo, modelado físico, aditiva, modulación de frecuencia, y granular—, cada una con un modelo matemático y una intuición física o perceptual distinta de cómo se genera o simula el timbre de un instrumento, ofreciendo una comparación directa de las mismas notas MIDI renderizadas bajo paradigmas de síntesis radicalmente distintos.",
"ex": [],
"fam": false
},
{
"n": "tempo_designer",
"st": "expresion",
"pa": "reglas",
"i": "MIDI + puntos compás:BPM",
"o": "mapa de tempo horneado",
"les": [
"interpretacion"
],
"rel": [
"performer"
],
"lines": 445,
"t": "Diseño de la arquitectura de tempo (agógica global)",
"p": "Mientras performer.py aplica rubato local por frase mediante reglas automáticas, este fichero diseña la agógica global de toda la obra y la “hornea” directamente en el mapa de tempo del MIDI (meta-evento 0x51, el estándar MIDI para cambios de tempo) — el equivalente temporal de tension_designer.py (curva de tensión) y climax_engineer.py (arquitectura de energía): aquí se diseña específicamente la arquitectura del tiempo.",
"a": "El modelo de tempo se define por puntos de control (pares compás:BPM), interpolados según tres formas seleccionables: step (terrazas discretas, cambios abruptos de tempo entre secciones, sin transición gradual), linear (rampas de accelerando/ritardando a tasa constante entre puntos de control) y smooth (interpolación coseno, con aceleración/desaceleración suave en los extremos de cada tramo, evitando el cambio de velocidad perceptualmente brusco de una rampa puramente lineal en sus fronteras). Se añaden calderones (--fermata, ralentización local puntual de un instante concreto) y un ritardando final configurable como desaceleración progresiva en los últimos compases.",
"c": "El tempo global de una obra es en sí mismo un parámetro expresivo con su propia arquitectura narrativa —terrazas de tempo entre secciones contrastantes, aceleraciones hacia un clímax, el ritardando final convencional de cierre— tratado aquí con el mismo rigor de diseño paramétrico que el ecosistema aplica a la tensión armónica o a la energía dinámica, en vez de dejarlo como un valor constante o como resultado incidental de otras decisiones compositivas.",
"ex": [
"python tempo_designer.py obra.mid --point 1:60 --point 8:96 --shape linear",
"python tempo_designer.py obra.mid --section 1:72 --section 9:120",
"python tempo_designer.py obra.mid --fermata 16 --final-rit 4",
"python tempo_designer.py obra.mid --plan agogica.tempo.json"
],
"fam": false
},
{
"n": "tension_designer",
"st": "plan",
"pa": "reglas",
"i": "MIDI(s) fuente",
"o": ".curves.json · flags --mt-*",
"les": [
"forma",
"taller"
],
"rel": [
"narrator",
"midi_dna_unified",
"arc_supervisor"
],
"lines": 684,
"t": "Diseñador visual interactivo de curvas de tensión",
"p": "Permite dibujar a mano, de forma interactiva, la curva de tensión (y otras curvas emocionales relacionadas) de una obra completa antes de generar ningún MIDI; las curvas resultantes se convierten directamente en flags --mt-* para midi_dna_unified.py, cerrando el ciclo entre diseño visual y generación paramétrica.",
"a": "",
"c": "Es el “lienzo” gráfico directo de todo el sistema de curvas emocionales paramétricas que consumen midi_dna_unified.py, arc_supervisor.py y varias otras herramientas: en vez de razonar sobre las curvas mediante parámetros numéricos abstractos, el compositor puede dibujarlas directamente como formas a mano alzada, con la traducción automática a los parámetros CLI exactos que las reproducirán.",
"ex": [
"python tension_designer.py fuente.mid [fuente2.mid]",
"python tension_designer.py a.mid b.mid --bars 32",
"python tension_designer.py a.mid --load curvas.json",
"python tension_designer.py a.mid --preset arch --auto-generate"
],
"fam": false
},
{
"n": "theme_transformer",
"st": "melodia",
"pa": "reglas",
"i": "tema MIDI",
"o": "tema en otras escalas / armonía negativa",
"les": [
"melodia",
"armonia"
],
"rel": [
"variation_engine"
],
"lines": 1802,
"t": "Mapeo escalar y transformación temática, incluyendo armonía negativa (v2.1)",
"p": "Implementa técnicas de “thematic transformation via scalar mapping”: traslada una melodía MIDI a otras escalas o modos preservando su identidad reconocible, con armonización y orquestación coherentes con cada estilo destino.",
"a": "La novedad central de la v2.1 es el estilo negative_harmony: la armonía negativa (Ernst Levy, popularizada recientemente por Jacob Collier) refleja tanto la melodía como los acordes sobre un eje tónica-dominante — matemáticamente, una reflexión (inversión especular) del espacio de alturas alrededor de un eje fijo entre la tónica y la dominante de la tonalidad, que transforma sistemáticamente cada intervalo en su “opuesto” especular preservando ciertas relaciones estructurales (la tónica y la dominante se intercambian mutuamente bajo esta reflexión, mientras que acordes mayores tienden a transformarse en sus relativos menores y viceversa).",
"c": "La armonía negativa es un marco teórico relativamente reciente y algo controvertido en la teoría musical contemporánea (defendido con entusiasmo por algunos músicos populares, recibido con escepticismo por parte de la teoría académica tradicional) que reinterpreta las relaciones tonales como simetrías especulares en vez de como jerarquías funcionales — su inclusión aquí junto a técnicas de transformación temática más establecidas refleja la amplitud deliberada del ecosistema a la hora de incorporar tanto teoría…",
"ex": [
"python theme_transformer.py tema.mid",
"python theme_transformer.py tema.mid --style octatonic chromatic_magical",
"python theme_transformer.py tema.mid --style got_fragment --verbose",
"python theme_transformer.py tema.mid --style elvish --start-degree 2"
],
"fam": false
},
{
"n": "theorist",
"st": "plan",
"pa": "reglas",
"i": "texto (intención)",
"o": ".theorist.json · .curves.json · plan.yaml",
"les": [
"forma",
"taller"
],
"rel": [
"narrator",
"runner",
"tension_designer",
"chord_progression_generator"
],
"lines": 2696,
"t": "De intención musical vaga a plan de composición fundamentado",
"p": "El “cerebro” de planificación de más alto nivel del ecosistema: traduce descripciones vagas de intención musical en lenguaje natural en planes de composición completos, justificados paso a paso en lenguaje teórico musical explícito — actúa como un teórico/compositor que razona en voz alta antes de producir ningún número, primero estableciendo semántica, después teoría, y solo entonces parámetros concretos.",
"a": "El flujo de seis etapas es notable por hacer explícito el razonamiento intermedio que normalmente permanece implícito en un sistema de generación por parámetros: (1) semántica, interpreta la descripción libre y detecta explícitamente contradicciones en la petición del usuario (p. ej. pedir algo simultáneamente “calmado” y “frenético” sin resolver la tensión entre ambos); (2) marco teórico, elige una escuela compositiva, referencias estilísticas y reglas asociadas coherentes con la intención detectada; (3) decisiones, cada parámetro concreto del pipeline se fija con su justificación teórica explícita (no solo el valor, sino el razonamiento musical que lo motiva);",
"c": "La detección explícita de contradicciones en la intención del usuario, antes de comprometerse con ningún parámetro, formaliza una práctica de diseño poco común pero valiosa: en vez de resolver silenciosamente una ambigüedad o contradicción con una elección arbitraria del sistema, la hace explícita y la razona, tratando el diseño de un plan compositivo como un proceso de argumentación teórica justificable, no como una simple aplicación mecánica de reglas.",
"ex": [
"python theorist.py \"una pieza que suene a esperar algo que nunca llega\"",
"python theorist.py \"melancolía urbana\" --key Dm --bars 32 --tempo 72",
"python theorist.py \"hazlo más oscuro\" --from obra.mid",
"python theorist.py --interactive"
],
"fam": false
},
{
"n": "token_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "corpus MIDI",
"o": "generación / infill",
"les": [
"representacion",
"maquinas"
],
"rel": [
"music_transformer"
],
"lines": 1444,
"t": "Transformer autoregresivo sobre las 9 tokenizaciones de miditok_algoritmos",
"p": "Un único modelo GPT-style (bloques causales pre-LN, posición aprendida) que se adapta a la forma del esquema elegido con --scheme: ESCALARES  (MIDILike, TSD, REMI, Structured, PerTok, MMM) secuencia plana de tokens → un embedding, una cabeza de salida. COMPUESTOS (CPWord, Octuple, MuMIDI) cada paso es un vector de varios campos (Bar/Position/Pitch/...) → un embedding y una cabeza POR CAMPO sobre un backbone compartido.",
"a": "",
"c": "",
"ex": [
"python token_composer.py prepare --input-dir midis/ --output-dir data_remi/ --scheme REMI",
"python token_composer.py train     --data-dir data_remi/ --model-dir runs/remi1/     --dim 256 --layers 6 --heads 4 --max-seq 512     --batch-size 8 --epochs 100",
"python token_composer.py compose --model-dir runs/remi1/     --output generado.mid --length 512 --temperature 0.9",
"python token_composer.py compose --model-dir runs/remi1/ --output continuacion.mid     --prime referencia.mid --prime-length 128 --length 512"
],
"fam": false
},
{
"n": "tonicization_engine",
"st": "armonia",
"pa": "reglas",
"i": "progresión MIDI",
"o": "progresión con V/x",
"les": [
"armonia"
],
"rel": [
"tonicizer",
"chord_progression_generator"
],
"lines": 473,
"t": "Inserción quirúrgica de dominantes secundarios",
"p": "Toma una progresión de acordes ya escrita (MIDI de acordes en bloque, del tipo que exportan chord_progression_generator.py/reharmonizer.py) y decide en qué compases y de qué manera introducir dominantes secundarios (V/x) que tonicen sus acordes diatónicos, sin tocar el resto de la obra — el análogo armónico de expectation_engine.py (que manipula expectativas en cadencias V→I) pero para tonicización: en vez de negar o retrasar una resolución esperada, introduce una tensión nueva y localizada (la quinta de un grado…",
"a": "La mecánica central consiste en, para cada acorde diatónico candidato a tonicizar, calcular su quinta superior (la dominante de ese grado) y comprobar si insertarla inmediatamente antes —como acorde de dominante secundaria de duración parcial dentro del mismo compás o en el tiempo anterior— es armónicamente viable dado el contexto (el grado no debe ser ya por sí mismo inestable, y la nota añadida no debe entrar en conflicto grave con la melodía existente si la hay).",
"c": "La tonicización secundaria —sonar momentáneamente “como si” estuviéramos en la tonalidad de un grado distinto del I, sin modular realmente— es uno de los recursos de enriquecimiento armónico más comunes de la práctica tonal común, desde el barroco hasta el pop contemporáneo, y esta herramienta la formaliza como una operación local e insertable quirúrgicamente sobre una progresión ya compuesta.",
"ex": [
"python tonicization_engine.py progresion.mid",
"python tonicization_engine.py progresion.mid --targets ii IV V vi",
"python tonicization_engine.py progresion.mid --density 0.6 --seed 7",
"python tonicization_engine.py progresion.mid --curve obra.curves.json"
],
"fam": false
},
{
"n": "tonicizer",
"st": "armonia",
"pa": "reglas",
"i": "tonalidad A → B / melodía",
"o": "puente modulante MIDI",
"les": [
"armonia"
],
"rel": [
"tonicization_engine"
],
"lines": 1107,
"t": "Motor de modulación tonal y puentes armónicos entre tonalidades",
"p": "Construye (y, sobre melodías reales, inserta) el puente armónico que lleva de una tonalidad A a una tonalidad B, usando una técnica de modulación clásica concreta — cada técnica se modela con su propia lógica armónica, no como variaciones cosméticas de una única plantilla genérica de transición.",
"a": "Siete técnicas de modulación, cada una un procedimiento armónico históricamente documentado y estructuralmente distinto: pivot (acorde pivote diatónico común a ambas tonalidades — la modulación más suave, donde un acorde perteneciente a ambas tonalidades sirve de bisagra); common_tone (modulación por nota común vía mediante cromática); diatonic (modulación a una tonalidad cercana, encadenando saltos de quinta o relativa si B no es directamente cercana a A); chromatic (acorde de aproximación cromática, fuera de ambas tonalidades, como bisagra disruptiva);",
"c": "El catálogo de siete técnicas constituye un compendio representativo de las estrategias de modulación tonal documentadas en cualquier tratado de armonía funcional, desde la más conservadora (pivote diatónico) hasta la más disruptiva (modulación directa), cada una con su propio efecto retórico característico: el pivote se percibe como una transición natural e inevitable, la modulación directa como un salto deliberado y marcado.",
"ex": [
"python tonicizer.py analyze obra_modulante.mid --window 2",
"python tonicizer.py catalog",
"python tonicizer.py selftest"
],
"fam": false
},
{
"n": "unifier",
"st": "ensamblaje",
"pa": "reglas",
"i": "secciones-ancla MIDI",
"o": "obra unificada",
"les": [
"forma"
],
"rel": [
"unifier_v3",
"stitcher"
],
"lines": 1752,
"t": "Unificación coherente de secciones-ancla (v1.1 → v3.0)",
"p": "Tres versiones abordan el mismo problema de diseño reconocido explícitamente: cuando se compone pegando secciones de obras distintas como “anclas emocionales”, la unión suele sonar a collage —faltan motivos comunes, la armonía no encaja, cambia el pulso, la instrumentación es inconexa— y unifier.py establece un ADN musical compartido que inyecta de forma dosificada en cada sección, cosiéndolas con transiciones coherentes.",
"a": "",
"c": "La distinción entre “unificar” (v1/v2: coser y suavizar material ya dado) y “recombinar” (v3: usar material dado como donante genético para una síntesis nueva) formaliza dos estrategias editoriales genuinamente distintas frente al mismo problema de origen —fragmentos musicalmente dispares que deben convivir en una obra— y ofrecerlas ambas explícitamente como modos reconoce que la elección entre “editar con respeto al original” y “reinventar libremente a partir del original” es una decisión estética, no técnica.",
"ex": [
"python unifier.py a.mid b.mid c.mid --emotions serenidad,angustia,triunfo",
"python unifier.py a.mid b.mid c.mid --mode auto",
"python unifier.py a.mid b.mid c.mid --mode recombine --recombine-bars 8"
],
"fam": true
},
{
"n": "unifier_v2",
"st": "ensamblaje",
"pa": "reglas",
"i": "secciones-ancla MIDI",
"o": "obra unificada",
"les": [
"forma"
],
"rel": [
"unifier_v3"
],
"lines": 1477,
"t": "Unificación coherente de secciones-ancla (v1.1 → v3.0)",
"p": "Tres versiones abordan el mismo problema de diseño reconocido explícitamente: cuando se compone pegando secciones de obras distintas como “anclas emocionales”, la unión suele sonar a collage —faltan motivos comunes, la armonía no encaja, cambia el pulso, la instrumentación es inconexa— y unifier.py establece un ADN musical compartido que inyecta de forma dosificada en cada sección, cosiéndolas con transiciones coherentes.",
"a": "",
"c": "La distinción entre “unificar” (v1/v2: coser y suavizar material ya dado) y “recombinar” (v3: usar material dado como donante genético para una síntesis nueva) formaliza dos estrategias editoriales genuinamente distintas frente al mismo problema de origen —fragmentos musicalmente dispares que deben convivir en una obra— y ofrecerlas ambas explícitamente como modos reconoce que la elección entre “editar con respeto al original” y “reinventar libremente a partir del original” es una decisión estética, no técnica.",
"ex": [],
"fam": true
},
{
"n": "unifier_v3",
"st": "ensamblaje",
"pa": "reglas",
"i": "secciones-ancla MIDI",
"o": "obra unificada / recombinada",
"les": [
"forma"
],
"rel": [
"stitcher",
"mosaic_composer"
],
"lines": 1858,
"t": "Unificación coherente de secciones-ancla (v1.1 → v3.0)",
"p": "Tres versiones abordan el mismo problema de diseño reconocido explícitamente: cuando se compone pegando secciones de obras distintas como “anclas emocionales”, la unión suele sonar a collage —faltan motivos comunes, la armonía no encaja, cambia el pulso, la instrumentación es inconexa— y unifier.py establece un ADN musical compartido que inyecta de forma dosificada en cada sección, cosiéndolas con transiciones coherentes.",
"a": "",
"c": "La distinción entre “unificar” (v1/v2: coser y suavizar material ya dado) y “recombinar” (v3: usar material dado como donante genético para una síntesis nueva) formaliza dos estrategias editoriales genuinamente distintas frente al mismo problema de origen —fragmentos musicalmente dispares que deben convivir en una obra— y ofrecerlas ambas explícitamente como modos reconoce que la elección entre “editar con respeto al original” y “reinventar libremente a partir del original” es una decisión estética, no técnica.",
"ex": [
"python unifier_v3.py intro.mid nudo.mid climax.mid final.mid",
"python unifier_v3.py a.mid b.mid c.mid --key Dm --anchor 1",
"python unifier_v3.py a.mid b.mid --glue motif=0.8,harmony=0.7,rhythm=0.3",
"python unifier_v3.py a.mid b.mid c.mid --glue-preset fuerte"
],
"fam": true
},
{
"n": "variation_engine",
"st": "melodia",
"pa": "reglas",
"i": "MIDI fuente",
"o": "catálogo de variaciones V01…",
"les": [
"melodia"
],
"rel": [
"leitmotif_analyst",
"theme_transformer"
],
"lines": 956,
"t": "Motor de variaciones musicales automáticas (catálogo de referencia)",
"p": "Dado un MIDI fuente, genera un catálogo completo de variaciones musicales clásicas y contemporáneas manteniendo la identidad temática reconocible — el módulo de referencia que otras herramientas del ecosistema (leitmotif_analyst.py, leitmotif_tracker.py, song_architect.py, completer.py) importan para aplicar transformaciones motívicas de forma consistente en todo el sistema.",
"a": "El catálogo cubre las transformaciones contrapuntísticas canónicas —inversión (refleja el contorno melódico), retrógrado (invierte el orden temporal), inversión retrógrada (combina ambas), aumentación y diminución rítmicas (duplica/reduce a la mitad las duraciones), ornamentación (añade notas de paso, apoyaturas, mordentes), reharmonización del patrón de acompañamiento, transposición, cambio modal (mayor↔menor u otros modos), y reinterpretación rítmica— formalizando en un único módulo reutilizable el vocabulario completo de variación temática que el resto del ecosistema referencia constantemente por nombre (V01, V02, etc., el mismo esquema de numeración usado en leitmotif_analyst.py para…",
"c": "Al ser el punto único de implementación de todo el catálogo de transformaciones temáticas, garantiza que “inversión” o “retrógrado” signifiquen exactamente lo mismo (la misma implementación algorítmica concreta) en cualquier herramienta del ecosistema que las use, evitando inconsistencias entre, por ejemplo, la inversión que genera variation_engine.py y la inversión que leitmotif_analyst.py intenta reconocer como ya presente en una obra.",
"ex": [
"python variation_engine.py fuente.mid",
"python variation_engine.py fuente.mid --variations V01 V02 V04",
"python variation_engine.py fuente.mid --all",
"python variation_engine.py fuente.mid --list"
],
"fam": false
},
{
"n": "voice_aligner",
"st": "arreglo",
"pa": "busqueda",
"i": "voces MIDI independientes",
"o": "voces sin choques",
"les": [
"voces"
],
"rel": [
"harmony_checker"
],
"lines": 1187,
"t": "Alineación de consonancia entre voces MIDI independientes (v2.0)",
"p": "Dadas múltiples voces MIDI generadas independientemente (p. ej. por distintas herramientas del ecosistema sin coordinación explícita entre sí), detecta y resuelve colisiones de disonancia no intencionadas entre ellas, ajustando el mínimo posible para preservar tanto la verticalidad consonante como el contorno melódico horizontal de cada voz.",
"a": "La v2.0 añade ocho mejoras sustanciales sobre v1.0: un índice de importancia por nota que protege las notas estructurales de ser desplazadas (el mismo principio de “suelo protegido” que combined_simplifier.py); una métrica de choque ponderada por duración (no solo por presencia binaria — una disonancia sostenida durante todo un compás pesa más que una de paso instantánea); un score combinado de coste vertical (disonancia armónica) más coste melódico (preservación del contorno horizontal de cada voz, para que la resolución de un choque vertical no destroce la línea melódica de la voz ajustada);",
"c": "El problema que resuelve —coordinar voces generadas independientemente sin que produzcan disonancias accidentales no intencionadas— es estructuralmente el mismo que enfrentaría un arreglista humano combinando partes escritas por distintos colaboradores sin coordinación previa: la optimización conjunta (“nudge”) en vez de resolución voraz secuencial es la diferencia clave entre una solución localmente parcheada y una genuinamente coherente en su conjunto.",
"ex": [
"python voice_aligner.py voz1.mid voz2.mid [voz3.mid ...]",
"python voice_aligner.py *.mid --freeze-voice 0 --verbose --report",
"python voice_aligner.py *.mid --melody-weight 0.4 --max-iter 5",
"python voice_aligner.py *.mid --allow-zone-shift --allow-ornament"
],
"fam": false
},
{
"n": "voice_leader",
"st": "armonia",
"pa": "busqueda",
"i": "cifrado / MIDI acordes",
"o": "coral SATB MIDI",
"les": [
"voces"
],
"rel": [
"harmony_checker",
"counterpoint"
],
"lines": 1036,
"t": "Motor de voice leading SATB para bloques de acordes",
"p": "Toma una progresión de acordes (texto o MIDI de acordes en bloque) y genera el voicing SATB (Soprano-Alto-Tenor-Bajo) óptimo compás a compás, aplicando las reglas clásicas de conducción de voces: movimiento mínimo, ausencia de quintas paralelas, sin cruzamientos de voz, rangos vocales idiomáticos y resolución correcta de tensiones — a diferencia de counterpoint.py (una voz contra un cantus firmus dado) y de midi_dna_unified.py (voicing interno de acompañamiento incidental), este módulo razona explícitamente sobre…",
"a": "El problema de encontrar, para cada acorde de la progresión, la disposición de las cuatro voces que (a) respeta los rangos vocales idiomáticos de cada una (soprano aguda, alto media-aguda, tenor media-grave, bajo grave y armónicamente fundacional), (b) minimiza el movimiento total entre el acorde actual y el siguiente, y (c) nunca produce quintas u octavas paralelas ni cruces de voz, es estructuralmente un problema de optimización combinatoria con restricciones sobre el conjunto (pequeño pero no trivial) de disposiciones válidas de cada acorde — la misma clase de problema que counterpoint.py resuelve mediante backtracking CSP para una sola voz contra un cantus firmus, aquí generalizado a…",
"c": "Es la formalización algorítmica directa del ejercicio central de cualquier curso de armonía a cuatro voces de conservatorio: dado un cifrado armónico, encontrar la realización vocal SATB que sea a la vez correcta (sin errores de conducción de voces) y elegante (movimiento mínimo, sin saltos innecesarios) — el mismo problema que harmony_checker.py evalúa retrospectivamente sobre un intento ya escrito, aquí resuelto de forma prospectiva y generativa.",
"ex": [
"python voice_leader.py --chords \"C Am F G7\"",
"python voice_leader.py --chords \"Dm:2 G7:2 CM7:4\" --key Dm",
"python voice_leader.py --chords \"C Am F G\" --style jazz --tempo 120",
"python voice_leader.py --soprano melodia.mid --chords \"C F G C\""
],
"fam": false
},
{
"n": "wfc_composer",
"st": "ensamblaje",
"pa": "busqueda",
"i": "tonalidad + parámetros",
"o": "textura polifónica MIDI",
"les": [
"maquinas",
"voces"
],
"rel": [
"counterpoint"
],
"lines": 1092,
"t": "Composición mediante Wave Function Collapse + SMT solver (v3.0)",
"p": "Aplica Wave Function Collapse (WFC, un algoritmo de generación procedimental popularizado en el diseño de niveles de videojuegos, que “colapsa” progresivamente las posibilidades de un grafo de restricciones locales hasta obtener una configuración global consistente) combinado con un solver SMT (Satisfiability Modulo Theories) real — Z3, de Microsoft Research — a la generación de una textura polifónica de varias voces, modelada como un grafo de ventana temporal con tres tipos de arista tipados: MELÓDICA, ARMÓNICA y…",
"a": "A diferencia de una implementación WFC clásica (que resuelve las restricciones locales mediante propagación de restricciones y backtracking heurístico), aquí las restricciones se codifican como fórmulas lógicas de primer orden y se delegan directamente en Z3, un solver SMT de propósito general capaz de encontrar (o demostrar la inexistencia de) una asignación que satisfaga simultáneamente todas las restricciones declaradas — entre las corregidas explícitamente en v3 respecto a v2: una restricción global c_no_voice_overlap que ahora se aplica universalmente y no solo a las aristas armónicas (corrigiendo un caso donde voces podían solaparse ilegalmente sin que ninguna arista existente lo…",
"c": "Usar un solver SMT exacto en vez de una heurística de propagación de restricciones aproximada es una elección deliberada de corrección garantizada: si Z3 encuentra una solución, esa solución satisface con certeza matemática absoluta todas las restricciones de conducción de voces y armonía declaradas simultáneamente (no “en su mayoría” o “con alta probabilidad” como produciría una heurística), al coste de que el problema pueda ser computacionalmente costoso o, en el peor caso, resultar insatisfacible si las…",
"ex": [
"python wfc_composer.py",
"python wfc_composer.py --key 2 --mode minor --beats 32 --nodes 32 --window 2",
"python wfc_composer.py --tempo 80 --seed 42 --verbose"
],
"fam": false
},
{
"n": "yue_composer",
"st": "neuronal",
"pa": "neuronal",
"i": "letra + género",
"o": "canción con voz",
"les": [
"maquinas"
],
"rel": [
"lyrics_writer"
],
"lines": 1772,
"t": "Generación de canciones completas con letra mediante YuE",
"p": "Adaptación del modelo open-source YuE (música generativa lyrics→canción): dado un texto de letra y etiquetas de género, genera una canción completa de varios minutos con voz y acompañamiento instrumental separados.",
"a": "El comando generate opera en modo CoT (Chain-of-Thought): la generación procede en varios pasos razonados en vez de un único salto directo de letra+género a audio completo — coherente con la tendencia reciente de aplicar razonamiento paso a paso, popularizado originalmente en LLMs de texto, a tareas de generación de contenido más largo y estructuralmente complejo como una canción completa. El modo icl (in-context learning) extiende generate aceptando además un audio de referencia como ejemplo dentro del propio contexto de generación, guiando el estilo del resultado por demostración directa en vez de solo por descripción textual.",
"c": "La separación de decoders de voz e instrumental desde una representación de tokens compartida permite un grado de control post-generación —remezclar el balance voz/instrumental, o incluso sustituir uno de los dos componentes— que un modelo que generara la mezcla completa directamente como una única señal de audio no ofrecería, preservando cierta modularidad de producción incluso dentro de un pipeline de generación end-to-end.",
"ex": [
"python yue_composer.py install",
"python yue_composer.py install --model-dir ~/mis_modelos/yue/",
"python yue_composer.py generate --genre genre.txt --lyrics lyrics.txt",
"python yue_composer.py tags tango"
],
"fam": false
}
];
