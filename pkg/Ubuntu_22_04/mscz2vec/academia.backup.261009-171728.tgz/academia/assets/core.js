/* ═══════════════════════════════════════════════════════════════════
   Academia Mutopia — núcleo compartido
   · teoría musical (notas, escalas, acordes, tonalidad Krumhansl)
   · motor de audio Web Audio (instrumentos, percusión, secuenciador)
   · widgets: piano roll, teclado, pentagrama, curvas
   · utilidades: exportación MIDI (SMF), quizzes, progreso, enlaces a herramientas
   ═══════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const M = window.M = {};

/* ─────────────────────────── ETAPAS Y LECCIONES ─────────────────────────── */
M.STAGES = {
  plan:       {name:'Intención y plan',        color:'#b48cf2', short:'Plan'},
  armonia:    {name:'Armonía',                 color:'#f2b950', short:'Armonía'},
  melodia:    {name:'Melodía y motivo',        color:'#f27fa8', short:'Melodía'},
  ritmo:      {name:'Ritmo, bajo y textura',   color:'#7fd88f', short:'Ritmo'},
  ensamblaje: {name:'Ensamblaje y transformación', color:'#5fd3d3', short:'Ensamblaje'},
  arreglo:    {name:'Arreglo y orquestación',  color:'#7fa8f2', short:'Arreglo'},
  expresion:  {name:'Expresión e interpretación', color:'#f2945f', short:'Expresión'},
  sonido:     {name:'Sonido, síntesis y mezcla', color:'#4fd1b0', short:'Sonido'},
  captura:    {name:'Captura: audio → símbolo', color:'#9fb6d0', short:'Captura'},
  analisis:   {name:'Análisis y evaluación',   color:'#c2cad8', short:'Análisis'},
  neuronal:   {name:'Modelos generativos aprendidos', color:'#e07ff2', short:'Neuronal'},
  practica:   {name:'Aprender y tocar',        color:'#c8e86a', short:'Práctica'},
};
M.PARADIGMS = {
  reglas:      {name:'Reglas / teoría explícita', color:'#f2b950'},
  estadistica: {name:'Estadística (Markov, n-gramas, HMM, vectores)', color:'#6cc3e0'},
  busqueda:    {name:'Búsqueda y optimización (A*, DP, CSP, SMT)', color:'#7fd88f'},
  evolutivo:   {name:'Evolutivo (algoritmos genéticos)', color:'#f2945f'},
  neuronal:    {name:'Redes neuronales', color:'#e07ff2'},
  dsp:         {name:'Procesado de señal (DSP)', color:'#4fd1b0'},
  llm:         {name:'LLM / lenguaje natural', color:'#b48cf2'},
  infra:       {name:'Infraestructura / utilidades', color:'#9aa4b8'},
};
M.LESSONS = [
  {id:'sonido',         file:'01-sonido.html',         n:'01', title:'El sonido',                    sub:'timbre, síntesis y mezcla',        stages:['sonido','captura']},
  {id:'representacion', file:'02-representacion.html', n:'02', title:'De la nota al dato',          sub:'MIDI, piano roll, tokens y vectores', stages:['ensamblaje','analisis','neuronal']},
  {id:'armonia',        file:'03-armonia.html',        n:'03', title:'Tonalidad y armonía',         sub:'escalas, funciones, cadencias',     stages:['armonia','analisis']},
  {id:'voces',          file:'04-voces.html',          n:'04', title:'Voces y contrapunto',         sub:'SATB, Fux, quintas paralelas',      stages:['armonia','melodia','practica']},
  {id:'melodia',        file:'05-melodia.html',        n:'05', title:'Melodía, motivo y frase',     sub:'contorno, variación, Markov',       stages:['melodia','analisis']},
  {id:'ritmo',          file:'06-ritmo.html',          n:'06', title:'Ritmo, groove y bajo',        sub:'arquetipos, síncopa, walking bass', stages:['ritmo']},
  {id:'forma',          file:'07-forma.html',          n:'07', title:'Forma, tensión y narrativa',  sub:'arcos, clímax áureo, segmentación', stages:['plan','expresion','analisis']},
  {id:'interpretacion', file:'08-interpretacion.html', n:'08', title:'Interpretación y orquesta',   sub:'rubato, dinámica, tocabilidad',     stages:['expresion','arreglo']},
  {id:'maquinas',       file:'09-maquinas.html',       n:'09', title:'Máquinas que componen',       sub:'de las reglas a la difusión',       stages:['ensamblaje','neuronal']},
  {id:'practica',       file:'10-practica.html',       n:'10', title:'Aprender a tocar',            sub:'dificultad, digitación, oído',      stages:['practica']},
  {id:'taller',         file:'taller.html',            n:'★',  title:'Taller: el flujo completo',   sub:'de una frase a un MIDI expresivo',  stages:['plan','armonia','melodia','ritmo','expresion']},
];
M.FLOW_ORDER = ['plan','armonia','melodia','ritmo','ensamblaje','arreglo','expresion','sonido','analisis'];

/* ─────────────────────────── TEORÍA MUSICAL ─────────────────────────── */
const SH = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
const FL = ['C','D♭','D','E♭','E','F','G♭','G','A♭','A','B♭','B'];
const ES = ['Do','Do♯','Re','Mi♭','Mi','Fa','Fa♯','Sol','La♭','La','Si♭','Si'];
M.SH = SH; M.FL = FL; M.ES = ES;
M.pcName = (pc, flats) => (flats ? FL : SH)[((pc % 12) + 12) % 12];
M.noteName = (m, flats) => M.pcName(m, flats) + (Math.floor(m / 12) - 1);
M.esName = pc => ES[((pc % 12) + 12) % 12];
M.freq = m => 440 * Math.pow(2, (m - 69) / 12);
M.parseNote = s => {
  const mm = /^([A-Ga-g])([#♯sb♭]*)(-?\d)$/.exec(String(s).trim());
  if (!mm) return null;
  const base = {C:0,D:2,E:4,F:5,G:7,A:9,B:11}[mm[1].toUpperCase()];
  let acc = 0; for (const c of mm[2]) acc += (c === 'b' || c === '♭') ? -1 : 1;
  return base + acc + (parseInt(mm[3]) + 1) * 12;
};
M.INTERVALS = ['unísono','2ª menor','2ª mayor','3ª menor','3ª mayor','4ª justa','tritono','5ª justa','6ª menor','6ª mayor','7ª menor','7ª mayor','octava'];
M.INTERVALS_SHORT = ['U','2m','2M','3m','3M','4J','TT','5J','6m','6M','7m','7M','8J'];

/* Las 15 escalas/modos que declara generar_midi.py (14 + mayor/menor alias) */
M.SCALES = {
  major:          {name:'Mayor (jónico)',        iv:[0,2,4,5,7,9,11], mood:'luminoso, estable'},
  dorian:         {name:'Dórico',                iv:[0,2,3,5,7,9,10], mood:'menor con 6ª mayor: melancolía con esperanza'},
  phrygian:       {name:'Frigio',                iv:[0,1,3,5,7,8,10], mood:'oscuro, 2ª menor: aire español/oriental'},
  lydian:         {name:'Lidio',                 iv:[0,2,4,6,7,9,11], mood:'mayor con 4ª aumentada: flotante, mágico'},
  mixolydian:     {name:'Mixolidio',             iv:[0,2,4,5,7,9,10], mood:'mayor con 7ª menor: rock, folk, blues'},
  minor:          {name:'Menor natural (eolio)', iv:[0,2,3,5,7,8,10], mood:'triste, introspectivo'},
  locrian:        {name:'Locrio',                iv:[0,1,3,5,6,8,10], mood:'inestable: la tónica es disminuida'},
  harmonic_minor: {name:'Menor armónica',        iv:[0,2,3,5,7,8,11], mood:'menor con sensible: dramático, barroco'},
  melodic_minor:  {name:'Menor melódica',        iv:[0,2,3,5,7,9,11], mood:'menor suave, jazz'},
  phrygian_dominant:{name:'Frigio dominante',    iv:[0,1,4,5,7,8,10], mood:'flamenco, cadencia andaluza'},
  pent_major:     {name:'Pentatónica mayor',     iv:[0,2,4,7,9],      mood:'sin semitonos: folk, pop'},
  pent_minor:     {name:'Pentatónica menor',     iv:[0,3,5,7,10],     mood:'blues, rock'},
  blues:          {name:'Blues',                 iv:[0,3,5,6,7,10],   mood:'pentatónica menor + "blue note"'},
  double_harmonic:{name:'Doble armónica',        iv:[0,1,4,5,7,8,11], mood:'dos 2ª aumentadas: sonoridad "oriental"'},
  acoustic:       {name:'Acústica (lidio ♭7)',   iv:[0,2,4,6,7,9,10], mood:'serie armónica natural, Bartók'},
  octatonic:      {name:'Octatónica (T-S)',      iv:[0,2,3,5,6,8,9,11], mood:'simétrica: Stravinsky, jazz modal'},
  whole_tone:     {name:'Tonos enteros',         iv:[0,2,4,6,8,10],   mood:'impresionista, sin centro: Debussy'},
};

/* Calidades de acorde */
M.QUAL = {
  '':     {iv:[0,4,7],    name:'mayor'},
  'm':    {iv:[0,3,7],    name:'menor'},
  'dim':  {iv:[0,3,6],    name:'disminuido'},
  'aug':  {iv:[0,4,8],    name:'aumentado'},
  'sus2': {iv:[0,2,7],    name:'sus2'},
  'sus4': {iv:[0,5,7],    name:'sus4'},
  '7':    {iv:[0,4,7,10], name:'séptima de dominante'},
  'maj7': {iv:[0,4,7,11], name:'séptima mayor'},
  'm7':   {iv:[0,3,7,10], name:'menor séptima'},
  'm7b5': {iv:[0,3,6,10], name:'semidisminuido'},
  'dim7': {iv:[0,3,6,9],  name:'disminuido séptima'},
  'mmaj7':{iv:[0,3,7,11], name:'menor con 7ª mayor'},
  '6':    {iv:[0,4,7,9],  name:'sexta'},
  'm6':   {iv:[0,3,7,9],  name:'menor sexta'},
  '9':    {iv:[0,4,7,10,14], name:'novena'},
  'add9': {iv:[0,4,7,14], name:'add9'},
  'm9':   {iv:[0,3,7,10,14], name:'menor novena'},
  'maj9': {iv:[0,4,7,11,14], name:'mayor novena'},
  '13':   {iv:[0,4,7,10,14,21], name:'trecena'},
  '7b9':  {iv:[0,4,7,10,13], name:'séptima con 9ª menor'},
};
M.qualityFromPcs = (root, pcs) => {
  const rel = [...new Set(pcs.map(p => ((p - root) % 12 + 12) % 12))].sort((a, b) => a - b).join(',');
  for (const [q, d] of Object.entries(M.QUAL)) {
    const k = [...new Set(d.iv.map(x => x % 12))].sort((a, b) => a - b).join(',');
    if (k === rel) return q;
  }
  return '?';
};
M.chordName = (root, q, flats) => M.pcName(root, flats) + (q === '' ? '' : q === 'm7b5' ? 'm7♭5' : q === 'dim' ? '°' : q === 'dim7' ? '°7' : q);
M.parseChord = s => {
  const mm = /^([A-G])([#♯b♭]?)(maj7|m7b5|mmaj7|dim7|dim|aug|sus2|sus4|add9|m7|m6|m|7|6|9|°7|°|ø7|ø)?(?:\/([A-G][#♯b♭]?))?$/.exec(String(s).trim());
  if (!mm) return null;
  let root = {C:0,D:2,E:4,F:5,G:7,A:9,B:11}[mm[1]];
  if (mm[2] === '#' || mm[2] === '♯') root++; if (mm[2] === 'b' || mm[2] === '♭') root--;
  root = (root + 12) % 12;
  let q = mm[3] || '';
  if (q === '°') q = 'dim'; if (q === '°7') q = 'dim7'; if (q === 'ø' || q === 'ø7') q = 'm7b5';
  let bass = null;
  if (mm[4]) { bass = {C:0,D:2,E:4,F:5,G:7,A:9,B:11}[mm[4][0]]; if (/[#♯]/.test(mm[4])) bass++; if (/[b♭]/.test(mm[4])) bass--; bass = (bass + 12) % 12; }
  return {root, q, pcs: M.QUAL[q].iv.map(i => (root + i) % 12), iv: M.QUAL[q].iv, bass};
};
/* Acorde por grado dentro de un modo (como build_chord_from_degree de generar_midi.py):
   apila terceras de la propia escala, de modo que el mismo grado da calidades distintas según el modo */
M.degreeChord = (tonic, scaleIv, deg, size = 3) => {
  const n = scaleIv.length, pcs = [];
  for (let k = 0; k < size; k++) {
    const idx = deg + 2 * k;
    pcs.push((tonic + scaleIv[idx % n] + 12 * Math.floor(idx / n)));
  }
  const root = ((pcs[0] % 12) + 12) % 12;
  const q = M.qualityFromPcs(root, pcs.map(p => p % 12));
  return {root, q, pcs: pcs.map(p => ((p % 12) + 12) % 12), abs: pcs};
};
const ROM = ['I','II','III','IV','V','VI','VII'];
M.roman = (deg, q, prefix = '') => {
  let r = ROM[deg % 7];
  const minorish = ['m','dim','m7','m7b5','dim7','m6','mmaj7','m9'].includes(q);
  if (minorish) r = r.toLowerCase();
  const suf = {'dim':'°','dim7':'°7','m7b5':'ø7','aug':'+','7':'7','maj7':'Δ7','m7':'7','m6':'6','6':'6','9':'9','m9':'9','maj9':'Δ9','13':'13','7b9':'7♭9','sus4':'sus4','sus2':'sus2'}[q] || '';
  return prefix + r + suf;
};
/* Numerales romanos → acorde, con la MISMA convención que chord_table.py (resolve_custom_numeral):
   · calidad por capitalización y sufijo (7, M7, ø7, °, °7, +, sus2/4, 6, 9, 13, b9) y dominantes secundarias V/x;
   · grado CON alteración (b/#): se mide sobre la escala mayor (bVII = 10, bII = 1…);
   · grado SIN alteración: se lee sobre la escala del modo en menor, dórico, mixolidio y frigio dominante
     (i–VI–III–VII en La menor = Am F C G); el frigio y el lidio se escriben con alteraciones sobre la mayor
     (bII, bIII, bVII…, #IV), así que sin alterar se leen como en mayor;
   · vii° y vii°7 son siempre la sensible disminuida. */
const MAJ = [0, 2, 4, 5, 7, 9, 11], DEGS = ['VII', 'III', 'IV', 'VI', 'II', 'V', 'I'], DIDX = {I:0, II:1, III:2, IV:3, V:4, VI:5, VII:6};
M.parseNumeral = (num, mode = 'major', tonic = 0) => {
  let s = String(num).trim();
  const sec = /^(V7?|V|vii°7?|vii°)\/(.+)$/.exec(s);
  if (sec) { const tg = M.parseNumeral(sec[2], mode, tonic); if (!tg) return null; const dim = sec[1].startsWith('vii'); const iv = (tg.iv + (dim ? 11 : 7)) % 12, q = dim ? (sec[1].endsWith('7') ? 'dim7' : 'dim') : '7'; return {iv, q, root: (tonic + iv) % 12, pcs: M.QUAL[q].iv.map(i => (tonic + iv + i) % 12), func: 'AD', num}; }
  let acc = 0; if (s[0] === 'b' || s[0] === '♭') { acc = -1; s = s.slice(1); } else if (s[0] === '#' || s[0] === '♯') { acc = 1; s = s.slice(1); }
  const d = DEGS.find(x => s.slice(0, x.length).toUpperCase() === x && (s.slice(0, x.length) === x || s.slice(0, x.length) === x.toLowerCase()));
  if (!d) return null;
  const lower = s.slice(0, d.length) === d.toLowerCase(), suf = s.slice(d.length), deg = DIDX[d];
  const sc = (mode !== 'phrygian' && mode !== 'lydian' && M.SCALES[mode] && M.SCALES[mode].iv.length === 7) ? M.SCALES[mode].iv : MAJ;
  const leadingDim = s === 'vii°' || s === 'vii°7';
  const iv = ((acc || leadingDim ? MAJ[deg] + acc : sc[deg]) + 12) % 12;
  const SUF = {'': lower ? 'm' : '', '°': 'dim', 'o': 'dim', 'dim': 'dim', '°7': 'dim7', 'dim7': 'dim7', 'ø7': 'm7b5', 'ø': 'm7b5', 'hdim7': 'm7b5', '+': 'aug', 'aug': 'aug',
    '7': lower ? 'm7' : '7', 'M7': lower ? 'mmaj7' : 'maj7', 'Δ7': 'maj7', 'maj7': 'maj7', 'm7': 'm7', '9': lower ? 'm9' : '9', 'M9': 'maj9', 'm9': 'm9', '6': lower ? 'm6' : '6', 'm6': 'm6', '13': '13', 'b9': '7b9', '7b9': '7b9', 'sus4': 'sus4', 'sus2': 'sus2', 'm': 'm'};
  const q = (s === 'ii°7') ? 'm7b5' : SUF[suf];   // como NUMERAL_TO_INTERVAL: ii°7 es el semidisminuido del ii en menor
  if (q == null) return null;
  const func = acc ? 'AD' : (lower && deg === 4 ? 'D' : M.FUNC_OF_DEG[deg]);
  return {iv, q, root: (tonic + iv) % 12, pcs: M.QUAL[q].iv.map(i => (tonic + iv + i) % 12), func: acc ? (iv === 1 ? (q === '7' ? 'D' : 'S') : 'B') : func, deg, num};
};
/* Enlace de voces por movimiento mínimo: bajo + 3 voces superiores (como un voice_leader.py muy simplificado) */
M.voiceChord = (pcs, prev, o = {}) => {
  const lo = o.lo ?? 55, hi = o.hi ?? 76, bassPc = o.bass ?? pcs[0];
  const pb = prev ? prev[0] : 43; let bass = 0, bd = 99;
  for (let m = 36; m <= 52; m++) if (m % 12 === bassPc && Math.abs(m - pb) < bd) { bd = Math.abs(m - pb); bass = m; }
  const need = pcs.length >= 4 ? [pcs[1], pcs[3], pcs[4] ?? pcs[2]] : [pcs[1], pcs[2], pcs[0]];
  const cand = []; for (let m = lo; m <= hi; m++) if (pcs.includes(m % 12)) cand.push(m);
  const pu = prev ? prev.slice(1) : [60, 64, 67]; let best = null;
  for (let a = 0; a < cand.length; a++) for (let b = a + 1; b < cand.length; b++) for (let c = b + 1; c < cand.length; c++) {
    const v = [cand[a], cand[b], cand[c]], ps = v.map(x => x % 12);
    let cost = need.filter(n => !ps.includes(n)).length * 12 + (new Set(ps).size < 3 ? 4 : 0) + (v[2] - v[0] > 12 ? 6 : 0);
    cost += v.reduce((s, x, i) => s + Math.abs(x - (pu[i] ?? x)), 0);
    if (!best || cost < best.cost) best = {v, cost};
  }
  return [bass].concat(best ? best.v : pcs.slice(0, 3).map(p => 60 + p));
};
/* Función armónica tonal (T/S/D) por grado */
M.FUNC_OF_DEG = ['T','S','T','S','D','T','D'];
M.FUNC_COLOR = {T:'#6fd39a', S:'#f2b950', D:'#ef7a7a', AD:'#e07ff2', B:'#7fa8f2', '?':'#9aa4b8'};
M.FUNC_NAME = {T:'Tónica (reposo)', S:'Subdominante (alejamiento)', D:'Dominante (tensión que pide resolver)', AD:'Dominante secundaria (tensión prestada)', B:'Préstamo modal / cromático (color)'};

/* Krumhansl-Kessler: perfiles de estabilidad tonal percibida */
M.KK_MAJOR = [6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88];
M.KK_MINOR = [6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17];
M.pearson = (a, b) => {
  const n = a.length; let ma = 0, mb = 0; for (let i = 0; i < n; i++) { ma += a[i]; mb += b[i]; } ma /= n; mb /= n;
  let num = 0, da = 0, db = 0; for (let i = 0; i < n; i++) { const x = a[i] - ma, y = b[i] - mb; num += x * y; da += x * x; db += y * y; }
  return da && db ? num / Math.sqrt(da * db) : 0;
};
M.detectKey = hist => {
  const res = [];
  for (let t = 0; t < 12; t++) {
    const rot = p => p.map((_, i) => p[((i - t) % 12 + 12) % 12]);
    res.push({tonic: t, mode: 'major', r: M.pearson(hist, rot(M.KK_MAJOR))});
    res.push({tonic: t, mode: 'minor', r: M.pearson(hist, rot(M.KK_MINOR))});
  }
  return res.sort((a, b) => b.r - a.r);
};
M.histogram = notes => { const h = new Array(12).fill(0); for (const n of notes) h[((n.m % 12) + 12) % 12] += (n.d || 1); return h; };
M.keyName = k => M.esName(k.tonic) + (k.mode === 'major' ? ' mayor' : ' menor');

/* Consonancia (contrapunto clásico) */
M.isConsonant = iv => [0, 3, 4, 7, 8, 9].includes(((iv % 12) + 12) % 12);
M.isPerfect = iv => [0, 7].includes(((iv % 12) + 12) % 12);
/* Disonancia sensorial aproximada de un intervalo (0 = consonante, 1 = muy disonante) */
M.DISS = [0, 1, .8, .25, .2, .35, .9, .05, .3, .25, .7, .95];

/* utilidades numéricas */
M.clamp = (x, a, b) => Math.max(a, Math.min(b, x));
M.lerp = (a, b, t) => a + (b - a) * t;
M.rng = seed => { let s = (seed >>> 0) || 1; return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 1e9) / 1e9; }; };
M.choice = (arr, r = Math.random) => arr[Math.floor(r() * arr.length)];
M.wchoice = (arr, w, r = Math.random) => { const s = w.reduce((a, b) => a + b, 0); let x = r() * s; for (let i = 0; i < arr.length; i++) { x -= w[i]; if (x <= 0) return arr[i]; } return arr[arr.length - 1]; };
M.smoothstep = t => t * t * (3 - 2 * t);
M.PHI = 0.6180339887;

/* ─────────────────────────── AUDIO ─────────────────────────── */
let ctx = null, master = null, comp = null, noiseBuf = null;
M.analyser = null;
M.ctx = () => {
  if (!ctx) {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    master = ctx.createGain(); master.gain.value = 0.7;
    M.analyser = ctx.createAnalyser(); M.analyser.fftSize = 4096; M.analyser.smoothingTimeConstant = 0.6;
    master.connect(comp); comp.connect(M.analyser); M.analyser.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 1.5, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
};
M.master = () => { M.ctx(); return master; };
M.setVolume = v => { M.ctx(); master.gain.value = v; };
const vel01 = v => v == null ? 0.7 : (v > 1 ? v / 127 : v);

function env(g, t, a, peak, tau, dur, rel) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(peak, t + a);
  if (tau) g.gain.setTargetAtTime(peak * 0.0001, t + a, tau);
  g.gain.setTargetAtTime(0.0001, t + dur, rel);
}
function osc(type, f, t, stop) { const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; o.start(t); o.stop(stop); return o; }
function noise(t, stop) { const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true; s.start(t, Math.random()); s.stop(stop); return s; }
const waveCache = {};
function periodic(harm) {
  const key = harm.map(x => x.toFixed(3)).join(',');
  if (waveCache[key]) return waveCache[key];
  const re = new Float32Array(harm.length + 1), im = new Float32Array(harm.length + 1);
  harm.forEach((a, i) => im[i + 1] = a);
  return (waveCache[key] = ctx.createPeriodicWave(re, im, {disableNormalization: false}));
}

/* Instrumentos melódicos */
const INST = {
  piano(dest, f, t, dur, v) {
    const g = ctx.createGain(), lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(900 + v * 5200, t); lp.frequency.setTargetAtTime(700 + v * 1200, t, 0.4);
    const tau = M.clamp(1.1 * Math.sqrt(262 / f), 0.25, 2.6), end = t + dur + 0.6;
    const o1 = osc('triangle', f, t, end), o2 = osc('sine', f * 2.002, t, end), o3 = osc('sine', f * 3.006, t, end);
    const g2 = ctx.createGain(), g3 = ctx.createGain(); g2.gain.value = 0.3; g3.gain.value = 0.1;
    o1.connect(g); o2.connect(g2).connect(g); o3.connect(g3).connect(g);
    g.connect(lp).connect(dest);
    env(g, t, 0.004, 0.33 * v + 0.03, tau, dur, 0.09);
  },
  epiano(dest, f, t, dur, v) { // FM tipo Rhodes (piano_synth.py)
    const end = t + dur + 0.8, car = osc('sine', f, t, end), mod = osc('sine', f, t, end);
    const mg = ctx.createGain(); mg.gain.setValueAtTime(f * (1.5 + 3 * v), t); mg.gain.setTargetAtTime(f * 0.3, t, 0.25);
    mod.connect(mg).connect(car.frequency);
    const g = ctx.createGain(); car.connect(g).connect(dest);
    env(g, t, 0.003, 0.3 * v + 0.03, 1.4, dur, 0.15);
  },
  strings(dest, f, t, dur, v) {
    const end = t + dur + 0.6, g = ctx.createGain(), lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 1200 + 2500 * v; lp.Q.value = 0.5;
    const a = osc('sawtooth', f * 0.997, t, end), b = osc('sawtooth', f * 1.003, t, end);
    const lfo = osc('sine', 5.2, t, end), lg = ctx.createGain(); lg.gain.value = f * 0.004; lfo.connect(lg); lg.connect(a.frequency); lg.connect(b.frequency);
    a.connect(g); b.connect(g); g.connect(lp).connect(dest);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.11 * v + 0.01, t + Math.min(0.12, dur * 0.4));
    g.gain.setTargetAtTime(0.0001, t + dur, 0.18);
  },
  pad(dest, f, t, dur, v) {
    const end = t + dur + 1.2, g = ctx.createGain(), lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 900 + 900 * v;
    const a = osc('sawtooth', f * 0.995, t, end), b = osc('triangle', f * 1.005, t, end), c = osc('sine', f / 2, t, end);
    a.connect(g); b.connect(g); c.connect(g); g.connect(lp).connect(dest);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.07 * v + 0.01, t + Math.min(0.5, dur * 0.5));
    g.gain.setTargetAtTime(0.0001, t + dur, 0.35);
  },
  bass(dest, f, t, dur, v) {
    const end = t + dur + 0.4, g = ctx.createGain(), lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(300 + 900 * v, t); lp.frequency.setTargetAtTime(220, t, 0.15); lp.Q.value = 2;
    const a = osc('sawtooth', f, t, end), b = osc('sine', f, t, end);
    a.connect(g); b.connect(g); g.connect(lp).connect(dest);
    env(g, t, 0.006, 0.4 * v + 0.05, 0.9, dur * 0.92, 0.05);
  },
  organ(dest, f, t, dur, v) {
    const end = t + dur + 0.3, g = ctx.createGain(), o = ctx.createOscillator();
    o.setPeriodicWave(periodic([1, .6, .4, .3, 0, .2, 0, .15])); o.frequency.value = f; o.start(t); o.stop(end);
    o.connect(g).connect(dest);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.09 * v + 0.02, t + 0.02); g.gain.setTargetAtTime(0.0001, t + dur, 0.04);
  },
  flute(dest, f, t, dur, v) {
    const end = t + dur + 0.4, g = ctx.createGain(), o = osc('sine', f, t, end), o2 = osc('sine', f * 2, t, end), g2 = ctx.createGain(); g2.gain.value = 0.12;
    const lfo = osc('sine', 5, t, end), lg = ctx.createGain(); lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(f * 0.006, t + 0.4); lfo.connect(lg).connect(o.frequency);
    const n = noise(t, end), bp = ctx.createBiquadFilter(), ng = ctx.createGain(); bp.type = 'bandpass'; bp.frequency.value = f * 2; bp.Q.value = 3; ng.gain.value = 0.05;
    n.connect(bp).connect(ng).connect(g); o.connect(g); o2.connect(g2).connect(g); g.connect(dest);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.22 * v + 0.02, t + 0.06); g.gain.setTargetAtTime(0.0001, t + dur, 0.07);
  },
  brass(dest, f, t, dur, v) {
    const end = t + dur + 0.4, g = ctx.createGain(), lp = ctx.createBiquadFilter(), o = osc('sawtooth', f, t, end);
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(f * 1.5, t); lp.frequency.linearRampToValueAtTime(f * (3 + 6 * v), t + 0.08); lp.frequency.setTargetAtTime(f * (2 + 3 * v), t + 0.1, 0.3);
    o.connect(lp).connect(g).connect(dest);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.16 * v + 0.02, t + 0.05); g.gain.setTargetAtTime(0.0001, t + dur, 0.08);
  },
  pluck(dest, f, t, dur, v) { // Karplus-Strong (synth_forge.py waveguide / genopatch)
    const sr = ctx.sampleRate, len = Math.floor(sr * Math.min(dur + 1, 3)), buf = ctx.createBuffer(1, len, sr), d = buf.getChannelData(0);
    const N = Math.max(2, Math.round(sr / f)), line = new Float32Array(N);
    for (let i = 0; i < N; i++) line[i] = Math.random() * 2 - 1;
    let p = 0; const damp = 0.996;
    for (let i = 0; i < len; i++) { const nx = (p + 1) % N; const y = line[p]; line[p] = damp * 0.5 * (line[p] + line[nx]); d[i] = y; p = nx; }
    const s = ctx.createBufferSource(); s.buffer = buf; const g = ctx.createGain();
    s.connect(g).connect(dest); s.start(t); s.stop(t + len / sr);
    g.gain.setValueAtTime(0.3 * v + 0.03, t); g.gain.setTargetAtTime(0.0001, t + dur, 0.12);
  },
  sine(dest, f, t, dur, v) { const g = ctx.createGain(), o = osc('sine', f, t, t + dur + 0.3); o.connect(g).connect(dest); env(g, t, 0.01, 0.3 * v, 0, dur, 0.05); },
};
/* Percusión (General MIDI: 36 bombo, 38 caja, 42 hh cerrado, 46 hh abierto, 75 clave, 51 ride, 70 maracas, 49 crash, 37 rim) */
const DRUM = {
  kick(dest, t, v) { const o = osc('sine', 150, t, t + 0.5), g = ctx.createGain(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.13); o.connect(g).connect(dest); g.gain.setValueAtTime(0.9 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.38); },
  snare(dest, t, v) { const n = noise(t, t + 0.25), hp = ctx.createBiquadFilter(), g = ctx.createGain(); hp.type = 'highpass'; hp.frequency.value = 1200; n.connect(hp).connect(g).connect(dest); g.gain.setValueAtTime(0.45 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    const o = osc('triangle', 190, t, t + 0.12), g2 = ctx.createGain(); o.connect(g2).connect(dest); g2.gain.setValueAtTime(0.35 * v, t); g2.gain.exponentialRampToValueAtTime(0.001, t + 0.09); },
  hihat(dest, t, v, open) { const n = noise(t, t + 0.5), hp = ctx.createBiquadFilter(), g = ctx.createGain(); hp.type = 'highpass'; hp.frequency.value = 7500; n.connect(hp).connect(g).connect(dest); g.gain.setValueAtTime(0.22 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + (open ? 0.32 : 0.05)); },
  clave(dest, t, v) { const o = osc('sine', 2500, t, t + 0.08), g = ctx.createGain(); o.connect(g).connect(dest); g.gain.setValueAtTime(0.3 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.06); },
  rim(dest, t, v) { const o = osc('square', 1700, t, t + 0.05), g = ctx.createGain(), bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1700; o.connect(bp).connect(g).connect(dest); g.gain.setValueAtTime(0.25 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.04); },
  maracas(dest, t, v) { const n = noise(t, t + 0.08), bp = ctx.createBiquadFilter(), g = ctx.createGain(); bp.type = 'bandpass'; bp.frequency.value = 6000; bp.Q.value = 1.5; n.connect(bp).connect(g).connect(dest); g.gain.setValueAtTime(0.25 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.05); },
  ride(dest, t, v) { const n = noise(t, t + 0.6), bp = ctx.createBiquadFilter(), g = ctx.createGain(); bp.type = 'bandpass'; bp.frequency.value = 8000; bp.Q.value = 2; n.connect(bp).connect(g).connect(dest);
    const o = osc('square', 5100, t, t + 0.4), g2 = ctx.createGain(); g2.gain.value = 0.015 * v; o.connect(g2).connect(dest); g2.gain.exponentialRampToValueAtTime(0.0005, t + 0.35);
    g.gain.setValueAtTime(0.16 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.45); },
  crash(dest, t, v) { const n = noise(t, t + 1.4), hp = ctx.createBiquadFilter(), g = ctx.createGain(); hp.type = 'highpass'; hp.frequency.value = 4000; n.connect(hp).connect(g).connect(dest); g.gain.setValueAtTime(0.25 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 1.2); },
};
M.DRUM_NAMES = {kick:'Bombo', snare:'Caja', hihat_c:'Hi-hat', hihat_o:'Hi-hat abierto', hihat_p:'Hi-hat pedal', ride:'Ride', clave:'Clave', maracas:'Maracas', crash:'Crash', rim:'Aro'};
M.DRUM_GM = {kick:36, snare:38, hihat_c:42, hihat_o:46, hihat_p:44, ride:51, clave:75, maracas:70, crash:49, rim:37};
M.INSTRUMENTS = Object.keys(INST);
M.GM_PROGRAM = {piano:0, epiano:4, strings:48, pad:89, bass:33, organ:19, flute:73, brass:61, pluck:24, sine:80};

/* voz genérica: inst puede ser nombre, nombre de percusión, o {harm:[], a,d,s,r} aditivo, o {fm:{ratio,index}} */
M.voice = (inst, m, t, dur, v, dest) => {
  M.ctx(); dest = dest || master; v = vel01(v);
  if (typeof inst === 'string' && inst.startsWith('drum:')) {
    const k = inst.slice(5);
    if (k === 'hihat_c' || k === 'hihat_p') DRUM.hihat(dest, t, k === 'hihat_p' ? v * 0.6 : v, false);
    else if (k === 'hihat_o') DRUM.hihat(dest, t, v, true);
    else (DRUM[k] || DRUM.clave)(dest, t, v);
    return;
  }
  const f = typeof m === 'number' && m > 0 && m < 200 ? M.freq(m) : m;
  if (typeof inst === 'object') {
    const p = inst, g = ctx.createGain(), end = t + dur + (p.r || 0.2) * 4 + 0.1;
    if (p.fm) {
      const car = osc('sine', f, t, end), mod = osc('sine', f * p.fm.ratio, t, end), mg = ctx.createGain();
      mg.gain.setValueAtTime(f * p.fm.index, t); if (p.fm.decay) mg.gain.setTargetAtTime(f * p.fm.index * 0.1, t, p.fm.decay);
      mod.connect(mg).connect(car.frequency); car.connect(g);
    } else {
      const o = ctx.createOscillator(); o.setPeriodicWave(periodic(p.harm || [1])); o.frequency.value = f; o.start(t); o.stop(end); o.connect(g);
    }
    let out = g;
    if (p.cutoff) { const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = p.cutoff; g.connect(lp); out = lp; }
    out.connect(dest);
    const a = p.a ?? 0.01, d = p.d ?? 0.2, s = p.s ?? 0.6, r = p.r ?? 0.2, peak = 0.3 * v;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.setTargetAtTime(peak * s + 0.0001, t + a, d / 3);
    g.gain.setTargetAtTime(0.0001, t + Math.max(dur, a), r / 3);
    return;
  }
  (INST[inst] || INST.piano)(dest, f, t, dur, v);
};
M.note = (m, dur = 0.6, inst = 'piano', v = 0.75) => { M.ctx(); M.voice(inst, m, ctx.currentTime + 0.02, dur, v); };
M.chord = (ms, dur = 1.2, inst = 'piano', v = 0.6, arp = 0) => { M.ctx(); const t = ctx.currentTime + 0.02; ms.forEach((m, i) => M.voice(inst, m, t + i * arp, dur, v)); };
M.drum = (k, v = 0.8) => { M.ctx(); M.voice('drum:' + k, 0, ctx.currentTime + 0.01, 0.1, v); };

/* Secuenciador con lookahead.
   events: {t: beat, d: beats, m: midi, v, inst} — o con tiempos absolutos {ts: seg, ds: seg}.
   opts: {bpm, loop, onBeat(beat), onEnd, length(beats), swing(0.5-0.75)} */
let current = null;
M.play = (events, opts = {}) => {
  M.ctx(); M.stop();
  const bpm = opts.bpm || 100, spb = 60 / bpm, bus = ctx.createGain(); bus.connect(opts.dest || master);
  const evs = events.slice().sort((a, b) => (a.ts ?? a.t * spb) - (b.ts ?? b.t * spb));
  const lenSec = opts.length != null ? opts.length * spb : Math.max(0, ...evs.map(e => (e.ts ?? e.t * spb) + (e.ds ?? e.d * spb)));
  let t0 = ctx.currentTime + 0.1, i = 0, stopped = false, raf = 0;
  const sw = opts.swing || 0.5;
  const timeOf = e => {
    if (e.ts != null) return e.ts;
    let b = e.t;
    if (sw !== 0.5) { const fr = b % 1; if (Math.abs(fr - 0.5) < 1e-6) b = Math.floor(b) + sw; else if (Math.abs(fr - 0.25) < 1e-6 || Math.abs(fr - 0.75) < 1e-6) { /* semicorcheas sin swing */ } }
    return b * spb;
  };
  const tick = () => {
    if (stopped) return;
    const now = ctx.currentTime;
    while (i < evs.length && t0 + timeOf(evs[i]) < now + 0.3) {
      const e = evs[i++], st = t0 + timeOf(e) + (e.off || 0);
      if (st >= now - 0.02 && !e.mute) M.voice(e.inst || opts.inst || 'piano', e.m, Math.max(st, now), e.ds ?? e.d * spb, e.v, bus);
    }
    if (i >= evs.length && now > t0 + lenSec + 0.05) {
      if (opts.loop) { t0 += lenSec; i = 0; } else { handle.stop(true); }
    }
  };
  const iv = setInterval(tick, 25);
  const frame = () => { if (stopped) return; if (opts.onBeat) opts.onBeat((ctx.currentTime - t0) / spb, (ctx.currentTime - t0)); raf = requestAnimationFrame(frame); };
  const handle = current = {
    stop(natural) {
      if (stopped) return; stopped = true; clearInterval(iv); cancelAnimationFrame(raf);
      const n = ctx.currentTime; bus.gain.setTargetAtTime(0, n, natural ? 0.4 : 0.02); setTimeout(() => bus.disconnect(), 1500);
      if (current === handle) current = null;
      if (opts.onBeat) opts.onBeat(-1, -1);
      if (opts.onEnd) opts.onEnd(!natural);
    },
    get playing() { return !stopped; }, bpm, spb,
  };
  tick(); raf = requestAnimationFrame(frame);
  return handle;
};
M.stop = () => { if (current) current.stop(); };
M.isPlaying = () => !!current;
/* botón play/stop reutilizable */
M.playButton = (btn, getEvents, getOpts = () => ({})) => {
  const label = btn.innerHTML;
  btn.addEventListener('click', () => {
    if (btn.classList.contains('on')) { M.stop(); return; }
    const o = getOpts();
    const ev = getEvents(); if (!ev || !ev.length) return;
    document.querySelectorAll('button.playing').forEach(b => { b.classList.remove('on', 'playing'); if (b._label) b.innerHTML = b._label; });
    btn._label = label; btn.classList.add('on', 'playing'); btn.innerHTML = '■ Parar';
    M.play(ev, {...o, onEnd: () => { btn.classList.remove('on', 'playing'); btn.innerHTML = label; o.onEnd && o.onEnd(); }});
  });
};

/* ─────────────────────────── UTILIDADES DOM ─────────────────────────── */
M.$ = (s, r = document) => r.querySelector(s);
M.$$ = (s, r = document) => [...r.querySelectorAll(s)];
M.h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'html') e.innerHTML = v;
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(k));
  return e;
};
M.esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
M.canvas = (cv, w, h) => {
  const dpr = window.devicePixelRatio || 1;
  w = w || cv.clientWidth || cv.width; h = h || cv.clientHeight || cv.height;
  cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); cv.style.width = w + 'px'; cv.style.height = h + 'px';
  const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.W = w; c.H = h; return c;
};
M.fit = (cv, h) => M.canvas(cv, cv.parentElement.clientWidth - 2, h);

/* Herramientas: chips con tooltip a partir de tools.js */
M.toolByName = n => (window.MUTOPIA_TOOLS || []).find(t => t.n === n);
M.tool = (n, label) => {
  const t = M.toolByName(n), st = t ? M.STAGES[t.st] : null;
  const base = location.pathname.includes('/academia/') || true ? 'index.html' : 'index.html';
  return `<a class="tool" data-tool="${n}" href="${base}#t=${n}" style="--c:${st ? st.color : '#6cc3e0'}">${label || n + '.py'}</a>`;
};
M.cmd = (s, nop) => `<div class="cmd${nop ? ' nop' : ''}">${M.esc(s)}<button class="copy small">copiar</button></div>`;
M.inMutopia = (html, tools = [], cmds = []) =>
  `<div class="inmut"><div class="h">En mutopia</div>${html ? `<p>${html}</p>` : ''}${tools.length ? `<div>${tools.map(t => M.tool(t)).join(' ')}</div>` : ''}${cmds.map(c => M.cmd(c)).join('')}</div>`;

let tipEl = null;
function initTips() {
  tipEl = M.h('div', {class: 'tip'}); document.body.append(tipEl);
  document.addEventListener('mouseover', e => {
    const a = e.target.closest('a.tool'); if (!a) return;
    const t = M.toolByName(a.dataset.tool); if (!t) return;
    const st = M.STAGES[t.st];
    tipEl.innerHTML = `<b>${t.n}.py</b> <span class="badge" style="background:${st.color};color:#111">${st.short}</span><br><i>${M.esc(t.t)}</i><br><span style="font-size:.82em">${M.esc(t.p.slice(0, 260))}${t.p.length > 260 ? '…' : ''}</span><br><span style="font-size:.78em;color:#7d889e">entrada: ${M.esc(t.i)} → salida: ${M.esc(t.o)}</span>`;
    tipEl.style.display = 'block';
  });
  document.addEventListener('mousemove', e => { if (tipEl.style.display === 'block') { const x = Math.min(e.clientX + 14, innerWidth - 400), y = Math.min(e.clientY + 16, innerHeight - tipEl.offsetHeight - 10); tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px'; } });
  document.addEventListener('mouseout', e => { if (e.target.closest('a.tool')) tipEl.style.display = 'none'; });
  document.addEventListener('click', e => {
    const b = e.target.closest('.cmd .copy'); if (!b) return;
    const txt = b.parentElement.firstChild.textContent;
    const fallback = () => { const ta = M.h('textarea', {style: {position: 'fixed', opacity: 0}}); ta.value = txt.trim(); document.body.append(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); };
    if (navigator.clipboard && window.isSecureContext !== false) navigator.clipboard.writeText(txt.trim()).catch(fallback); else fallback();
    b.textContent = '¡copiado!'; setTimeout(() => b.textContent = 'copiar', 1200);
  });
}

/* Progreso (localStorage) */
const PKEY = 'mutopia_academia_v1';
M.progress = () => { try { return JSON.parse(localStorage.getItem(PKEY)) || {}; } catch (e) { return {}; } };
M.saveProgress = p => { try { localStorage.setItem(PKEY, JSON.stringify(p)); } catch (e) {} };
M.markSeen = id => { const p = M.progress(); p[id] = p[id] || {}; p[id].seen = true; M.saveProgress(p); };
M.markQuiz = (id, qid, ok) => { const p = M.progress(); p[id] = p[id] || {}; p[id].quiz = p[id].quiz || {}; p[id].quiz[qid] = ok; M.saveProgress(p); };

/* Cabecera, navegación y pie */
M.page = (id) => {
  M.markSeen(id);
  const p = M.progress();
  const nav = M.LESSONS.map(l => {
    const q = p[l.id] && p[l.id].quiz, done = q && Object.values(q).filter(Boolean).length >= 2;
    const cls = [l.id === id ? 'cur' : '', done ? 'done' : (p[l.id] && p[l.id].seen ? 'seen' : '')].join(' ');
    return `<a class="${cls}" href="${l.file}" title="${l.title}: ${l.sub}"><span class="dot"></span>${l.n} ${l.title}</a>`;
  }).join('');
  const bar = M.h('div', {class: 'topbar', html: `<a class="brand" href="index.html">Mutopia <b>·</b> Academia</a><nav class="lessonnav">${nav}</nav><button class="small" id="mstop" title="Detener todo el audio">■ silencio</button>`});
  document.body.prepend(bar);
  M.$('#mstop').onclick = () => M.stop();
  const cur = M.$('.lessonnav a.cur'); if (cur) cur.scrollIntoView({inline: 'center', block: 'nearest'});
  initTips();
  // breadcrumb de etapas
  const L = M.LESSONS.find(l => l.id === id);
  const fc = M.$('.flowcrumb');
  if (fc && L) fc.innerHTML = '<small style="margin-right:.4rem">Etapas del flujo que trabaja esta lección:</small>' + M.FLOW_ORDER.concat(['captura', 'neuronal', 'practica']).map(s => `<span class="${L.stages.includes(s) ? 'on' : ''}" style="${L.stages.includes(s) ? 'background:' + M.STAGES[s].color : ''}">${M.STAGES[s].short}</span>`).join('');
  // pager
  const i = M.LESSONS.findIndex(l => l.id === id), pg = M.$('.pager');
  if (pg && i >= 0) {
    const pr = M.LESSONS[i - 1], nx = M.LESSONS[i + 1];
    pg.innerHTML = (pr ? `<a href="${pr.file}"><small>← anterior</small>${pr.n} · ${pr.title}</a>` : `<a href="index.html"><small>← volver</small>Mapa del flujo</a>`) +
      (nx ? `<a href="${nx.file}" style="text-align:right"><small>siguiente →</small>${nx.n} · ${nx.title}</a>` : `<a href="index.html" style="text-align:right"><small>fin →</small>Mapa del flujo</a>`);
  }
  // quizzes
  M.$$('.quiz[data-q]').forEach(el => M.quiz(el, id));
};

/* Quiz: <div class="quiz" data-q='[{"q":"..","o":["a","b"],"a":0,"e":"explicación"}]'> */
M.quiz = (el, lessonId) => {
  const qs = JSON.parse(el.dataset.q);
  el.innerHTML = '<div class="h">Comprueba lo aprendido</div>';
  qs.forEach((q, qi) => {
    const qid = (el.id || 'q') + '_' + qi;
    const box = M.h('div', {class: 'q'}, M.h('p', {html: q.q}));
    const opts = M.h('div', {class: 'opts'});
    q.o.forEach((o, oi) => {
      const b = M.h('button', {html: o, onclick: () => {
        if (box.classList.contains('answered')) return;
        box.classList.add('answered');
        b.classList.add(oi === q.a ? 'right' : 'wrong');
        if (oi !== q.a) opts.children[q.a].classList.add('right');
        M.markQuiz(lessonId, qid, oi === q.a);
      }});
      opts.append(b);
    });
    box.append(opts, M.h('div', {class: 'expl', html: q.e}));
    el.append(box);
  });
};

/* ─────────────────────────── PIANO ROLL ─────────────────────────── */
/* new M.PianoRoll(canvas, {lo, hi, beats, bpb, grid, editable, notes, h, onChange, color(n), labelKey}) */
M.PianoRoll = class {
  constructor(cv, o = {}) {
    this.cv = cv; this.o = Object.assign({lo: 48, hi: 84, beats: 16, bpb: 4, grid: 0.5, editable: false, h: 260, defDur: 1, keyW: 34}, o);
    this.notes = o.notes || []; this.play = -1; this.marks = []; this.hl = null; this.scalePcs = o.scalePcs || null;
    this.resize(); window.addEventListener('resize', () => this.resize());
    if (this.o.editable) this.bindEdit();
  }
  resize() { this.c = M.canvas(this.cv, Math.max(300, this.cv.parentElement.clientWidth - 2), this.o.h); this.draw(); }
  geom() { const o = this.o, W = this.c.W, H = this.c.H, kw = o.keyW, rows = o.hi - o.lo + 1; return {W, H, kw, rows, rh: H / rows, bw: (W - kw) / o.beats}; }
  set(notes) { this.notes = notes; this.draw(); }
  draw() {
    const c = this.c, o = this.o, g = this.geom(); if (!c) return;
    c.clearRect(0, 0, g.W, g.H); c.fillStyle = '#0b0f18'; c.fillRect(0, 0, g.W, g.H);
    for (let m = o.lo; m <= o.hi; m++) {
      const y = (o.hi - m) * g.rh, pc = m % 12, black = [1, 3, 6, 8, 10].includes(pc);
      const inScale = this.scalePcs ? this.scalePcs.includes(pc) : true;
      c.fillStyle = black ? '#0d121d' : '#121a28'; if (this.scalePcs && inScale) c.fillStyle = black ? '#152036' : '#18233a';
      c.fillRect(g.kw, y, g.W - g.kw, g.rh);
      c.fillStyle = black ? '#222' : '#ddd'; c.fillRect(0, y + 0.5, g.kw - (black ? 12 : 2), g.rh - 1);
      if (pc === 0 || (g.rh > 11)) { c.fillStyle = black ? '#999' : '#333'; c.font = `${Math.min(10, g.rh - 1)}px ${'system-ui'}`; c.textBaseline = 'middle'; if (!black || g.rh > 13) c.fillText(M.noteName(m), 2, y + g.rh / 2); }
      if (pc === 0) { c.fillStyle = '#2a3650'; c.fillRect(g.kw, y + g.rh - 1, g.W - g.kw, 1); }
    }
    for (let b = 0; b <= o.beats; b += o.grid) {
      const x = g.kw + b * g.bw; c.fillStyle = b % o.bpb === 0 ? '#3a4a6a' : (b % 1 === 0 ? '#1f2a40' : '#161f30'); c.fillRect(x, 0, 1, g.H);
      if (b % o.bpb === 0 && b < o.beats) { c.fillStyle = '#56627c'; c.font = '10px system-ui'; c.textBaseline = 'top'; c.fillText(String(b / o.bpb + 1), x + 3, 2); }
    }
    for (const mk of this.marks) { c.fillStyle = mk.color || 'rgba(242,185,80,.12)'; c.fillRect(g.kw + mk.t * g.bw, 0, mk.d * g.bw, g.H); if (mk.label) { c.fillStyle = mk.text || '#f2b950'; c.font = '11px system-ui'; c.textBaseline = 'bottom'; c.fillText(mk.label, g.kw + mk.t * g.bw + 3, g.H - 3); } }
    for (const n of this.notes) {
      if (n.m < o.lo || n.m > o.hi) continue;
      const x = g.kw + n.t * g.bw, y = (o.hi - n.m) * g.rh, w = Math.max(3, n.d * g.bw - 1.5);
      const col = this.o.color ? this.o.color(n) : (n.color || '#f2b950');
      c.globalAlpha = n.ghost ? 0.3 : (0.55 + 0.45 * vel01(n.v ?? 0.8));
      c.fillStyle = col; c.beginPath(); c.roundRect ? c.roundRect(x + 0.5, y + 1, w, Math.max(2, g.rh - 2), 3) : c.rect(x + 0.5, y + 1, w, Math.max(2, g.rh - 2)); c.fill();
      c.globalAlpha = 1;
      if (n.label && g.rh > 9) { c.fillStyle = '#111'; c.font = `${Math.min(10, g.rh - 2)}px system-ui`; c.textBaseline = 'middle'; c.fillText(n.label, x + 3, y + g.rh / 2); }
      if (n === this.hl) { c.strokeStyle = '#fff'; c.lineWidth = 2; c.strokeRect(x, y + 0.5, w + 1, g.rh - 1); }
    }
    if (this.play >= 0) { const x = g.kw + this.play * g.bw; c.fillStyle = '#fff'; c.fillRect(x, 0, 2, g.H); }
  }
  setPlayhead(b) { this.play = b; this.draw(); }
  hit(px, py) {
    const g = this.geom(), b = (px - g.kw) / g.bw, m = this.o.hi - Math.floor(py / g.rh);
    const n = this.notes.find(n => n.m === m && b >= n.t && b <= n.t + n.d);
    return {b, m, n};
  }
  bindEdit() {
    let drag = null;
    const pos = e => { const r = this.cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    this.cv.style.cursor = 'crosshair';
    this.cv.addEventListener('pointerdown', e => {
      const [x, y] = pos(e), g = this.geom(); if (x < g.kw) { M.note(this.o.hi - Math.floor(y / g.rh), 0.5, this.o.inst || 'piano'); return; }
      const h = this.hit(x, y); this.cv.setPointerCapture(e.pointerId);
      if (h.n) {
        const nearEnd = (h.b - h.n.t) > h.n.d * 0.7 && h.n.d >= this.o.grid;
        drag = {n: h.n, mode: nearEnd ? 'resize' : 'move', b0: h.b, t0: h.n.t, m0: h.n.m, d0: h.n.d, moved: false};
      } else {
        const t = Math.max(0, Math.floor(h.b / this.o.grid) * this.o.grid);
        if (t >= this.o.beats) return;
        const n = {t, d: this.o.grid, m: h.m, v: 0.8};
        if (this.o.mono) this.notes = this.notes.filter(k => !(k.t < t + n.d && k.t + k.d > t));
        this.notes.push(n); drag = {n, mode: 'new', b0: h.b, t0: t, moved: true};
        M.note(h.m, 0.4, this.o.inst || 'piano');
      }
      this.draw();
    });
    this.cv.addEventListener('pointermove', e => {
      if (!drag) return; const [x, y] = pos(e), h = this.hit(x, y), gr = this.o.grid;
      if (drag.mode === 'new' || drag.mode === 'resize') { const end = Math.max(drag.n.t + gr, Math.ceil(h.b / gr) * gr); drag.n.d = Math.min(end, this.o.beats) - drag.n.t; }
      else { const dt = Math.round((h.b - drag.b0) / gr) * gr; const nt = M.clamp(drag.t0 + dt, 0, this.o.beats - drag.n.d); if (nt !== drag.n.t || h.m !== drag.n.m) { drag.moved = true; if (h.m !== drag.n.m) M.note(h.m, 0.25, this.o.inst || 'piano'); drag.n.t = nt; drag.n.m = M.clamp(h.m, this.o.lo, this.o.hi); } }
      this.draw();
    });
    this.cv.addEventListener('pointerup', () => {
      if (!drag) return;
      if (drag.mode === 'move' && !drag.moved) this.notes = this.notes.filter(n => n !== drag.n);
      drag = null; this.notes.sort((a, b) => a.t - b.t || a.m - b.m); this.draw(); this.o.onChange && this.o.onChange(this.notes);
    });
    this.cv.addEventListener('contextmenu', e => e.preventDefault());
  }
};

/* ─────────────────────────── TECLADO ─────────────────────────── */
/* M.keyboard(el, {lo, hi, marks: {midi or 'pc:N': {color,label}}, onPress}) */
M.keyboard = (el, o = {}) => {
  const lo = o.lo ?? 48, hi = o.hi ?? 84, whites = [];
  for (let m = lo; m <= hi; m++) if (![1, 3, 6, 8, 10].includes(m % 12)) whites.push(m);
  const W = o.width || Math.max(320, (el.clientWidth || 600) - 2), ww = W / whites.length, H = o.height || 110, bh = H * 0.62, bw = ww * 0.62;
  const mk = m => (o.marks && (o.marks[m] || o.marks['pc:' + (m % 12)])) || null;
  let s = `<svg class="kbd" viewBox="0 0 ${W} ${H + (o.labels ? 16 : 0)}" width="100%" style="max-width:${W}px">`;
  whites.forEach((m, i) => {
    const k = mk(m);
    s += `<rect data-m="${m}" x="${i * ww}" y="0" width="${ww - 1}" height="${H}" rx="3" fill="${k ? k.color : '#e9e6df'}" stroke="#222"/>`;
    if (k && k.label) s += `<text x="${i * ww + ww / 2}" y="${H - 8}" font-size="${Math.min(12, ww * 0.42)}" text-anchor="middle" fill="#111" pointer-events="none" font-weight="600">${k.label}</text>`;
    if (o.labels && m % 12 === 0) s += `<text x="${i * ww + 2}" y="${H + 12}" font-size="10" fill="#7d889e">C${m / 12 - 1}</text>`;
  });
  whites.forEach((m, i) => {
    const b = m + 1; if (b > hi || ![1, 3, 6, 8, 10].includes(b % 12)) return;
    const k = mk(b);
    s += `<rect data-m="${b}" x="${(i + 1) * ww - bw / 2}" y="0" width="${bw}" height="${bh}" rx="2" fill="${k ? k.color : '#1a1a1a'}" stroke="#000"/>`;
    if (k && k.label) s += `<text x="${(i + 1) * ww}" y="${bh - 6}" font-size="${Math.min(10, bw * 0.5)}" text-anchor="middle" fill="#111" pointer-events="none" font-weight="600">${k.label}</text>`;
  });
  s += '</svg>';
  el.innerHTML = s;
  el.querySelectorAll('rect').forEach(r => r.addEventListener('pointerdown', () => { const m = +r.dataset.m; if (o.onPress) o.onPress(m); else M.note(m, 0.8, o.inst || 'piano'); }));
};

/* ─────────────────────────── PENTAGRAMA ─────────────────────────── */
/* M.staff(el, cols, {flats, width, h}) — cols: [{notes:[{m,color,staff:'T'|'B'}], label, sub, marks:[]}] */
const LETTER_OF_PC_SH = [0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6], ACC_SH = [0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0];
const LETTER_OF_PC_FL = [0, 1, 1, 2, 2, 3, 4, 4, 5, 5, 6, 6], ACC_FL = [0, -1, 0, -1, 0, 0, -1, 0, -1, 0, -1, 0];
M.spell = (m, flats) => { const pc = ((m % 12) + 12) % 12, oct = Math.floor(m / 12) - 1; const L = flats ? LETTER_OF_PC_FL : LETTER_OF_PC_SH, A = flats ? ACC_FL : ACC_SH; return {step: oct * 7 + L[pc], acc: A[pc]}; };
M.staff = (el, cols, o = {}) => {
  const sp = 9, h = sp / 2, colW = o.colW || 70, left = 46, W = left + cols.length * colW + 20;
  const topT = 30, topB = topT + 4 * sp + 62, H = topB + 4 * sp + 44;
  const yT = st => topT + (38 - st) * h, yB = st => topB + (26 - st) * h;
  let s = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W * 1.25}px;background:#f4f1e8;border-radius:8px">`;
  for (let i = 0; i < 5; i++) { s += `<line x1="10" x2="${W - 10}" y1="${topT + i * sp}" y2="${topT + i * sp}" stroke="#444" stroke-width="1"/>`; s += `<line x1="10" x2="${W - 10}" y1="${topB + i * sp}" y2="${topB + i * sp}" stroke="#444" stroke-width="1"/>`; }
  s += `<line x1="10" x2="10" y1="${topT}" y2="${topB + 4 * sp}" stroke="#444" stroke-width="2"/>`;
  s += `<text x="14" y="${topT + 4 * sp + 6}" font-size="46" fill="#333" font-family="serif">𝄞</text>`;
  s += `<text x="14" y="${topB + 3 * sp + 2}" font-size="34" fill="#333" font-family="serif">𝄢</text>`;
  cols.forEach((col, ci) => {
    const cx = left + ci * colW + colW / 2;
    if (col.bg) s += `<rect x="${cx - colW / 2 + 2}" y="6" width="${colW - 4}" height="${H - 12}" fill="${col.bg}" rx="6"/>`;
    s += `<line x1="${cx + colW / 2}" x2="${cx + colW / 2}" y1="${topT}" y2="${topB + 4 * sp}" stroke="#bbb" stroke-width="${col.bar ? 1.2 : 0}"/>`;
    const seen = {};
    (col.notes || []).forEach((n, ni) => {
      const sp_ = M.spell(n.m, o.flats), staff = n.staff || (n.m >= 60 ? 'T' : 'B');
      const y = staff === 'T' ? yT(sp_.step) : yB(sp_.step), refTop = staff === 'T' ? 38 : 26, refBot = staff === 'T' ? 30 : 18;
      // líneas adicionales
      for (let st = refTop + 2; st <= sp_.step; st += 2) { const yy = staff === 'T' ? yT(st) : yB(st); s += `<line x1="${cx - 11}" x2="${cx + 11}" y1="${yy}" y2="${yy}" stroke="#444"/>`; }
      for (let st = refBot - 2; st >= sp_.step; st -= 2) { const yy = staff === 'T' ? yT(st) : yB(st); s += `<line x1="${cx - 11}" x2="${cx + 11}" y1="${yy}" y2="${yy}" stroke="#444"/>`; }
      const key = staff + sp_.step, dx = seen[key] ? 10 : (seen[staff + (sp_.step + 1)] || seen[staff + (sp_.step - 1)] ? (ni % 2 ? 9 : 0) : 0); seen[key] = 1;
      s += `<ellipse cx="${cx + dx}" cy="${y}" rx="6.2" ry="4.4" transform="rotate(-20 ${cx + dx} ${y})" fill="${n.color || '#222'}" stroke="#111" stroke-width="1"/>`;
      if (sp_.acc) s += `<text x="${cx + dx - 17}" y="${y + 4}" font-size="13" fill="#222">${sp_.acc > 0 ? '♯' : '♭'}</text>`;
      if (n.mark) s += `<text x="${cx + dx + 9}" y="${y + 4}" font-size="10" fill="${n.markColor || '#a33'}" font-weight="700">${n.mark}</text>`;
    });
    if (col.label) s += `<text x="${cx}" y="${H - 22}" font-size="13" text-anchor="middle" fill="${col.labelColor || '#222'}" font-family="serif" font-weight="600">${M.esc(col.label)}</text>`;
    if (col.sub) s += `<text x="${cx}" y="${H - 8}" font-size="10" text-anchor="middle" fill="#666">${M.esc(col.sub)}</text>`;
  });
  (o.lines || []).forEach(L => { // conectores entre notas (p.ej. quintas paralelas)
    const y = n => { const sp_ = M.spell(n.m, o.flats), staff = n.staff || (n.m >= 60 ? 'T' : 'B'); return staff === 'T' ? yT(sp_.step) : yB(sp_.step); };
    s += `<line x1="${left + L.c1 * colW + colW / 2 + 7}" y1="${y(L.n1)}" x2="${left + L.c2 * colW + colW / 2 - 7}" y2="${y(L.n2)}" stroke="${L.color || '#d33'}" stroke-width="2" stroke-dasharray="4 2"/>`;
  });
  s += '</svg>'; el.innerHTML = s;
};

/* ─────────────────────────── CURVAS ─────────────────────────── */
/* M.CurveEditor(canvas, {curves:{name:{data:[],color,label}}, active, n, h, editable, onChange, marks}) */
M.CurveEditor = class {
  constructor(cv, o) {
    this.cv = cv; this.o = Object.assign({h: 200, editable: true, pad: 28}, o); this.active = o.active || Object.keys(o.curves)[0]; this.marks = o.marks || []; this.vlines = [];
    this.resize(); window.addEventListener('resize', () => this.resize());
    if (this.o.editable) this.bind();
  }
  resize() { this.c = M.canvas(this.cv, Math.max(300, this.cv.parentElement.clientWidth - 2), this.o.h); this.draw(); }
  get n() { return this.o.curves[this.active].data.length; }
  xy(i, v) { const p = this.o.pad, c = this.c, n = this.n; return [p + (i / (n - 1)) * (c.W - p - 8), 8 + (1 - v) * (c.H - 8 - p)]; }
  draw() {
    const c = this.c, p = this.o.pad; if (!c) return; c.clearRect(0, 0, c.W, c.H); c.fillStyle = '#0b0f18'; c.fillRect(0, 0, c.W, c.H);
    const n = this.n;
    for (const mk of this.marks) { const [x1] = this.xy(mk.a, 0), [x2] = this.xy(mk.b, 0); c.fillStyle = mk.color || 'rgba(255,255,255,.04)'; c.fillRect(x1, 8, x2 - x1, c.H - 8 - p); if (mk.label) { c.fillStyle = mk.text || '#aeb7c9'; c.font = '11px system-ui'; c.textBaseline = 'top'; c.fillText(mk.label, x1 + 4, 10); } }
    c.strokeStyle = '#1f2a40'; c.lineWidth = 1;
    for (let k = 0; k <= 4; k++) { const y = 8 + k / 4 * (c.H - 8 - p); c.beginPath(); c.moveTo(p, y); c.lineTo(c.W - 8, y); c.stroke(); }
    c.fillStyle = '#56627c'; c.font = '10px system-ui'; c.textBaseline = 'middle'; c.fillText('1', 8, 8); c.fillText('0', 8, c.H - p);
    const step = Math.max(1, Math.round(n / 16));
    c.textBaseline = 'top'; for (let i = 0; i < n; i += step) { const [x] = this.xy(i, 0); c.fillText(String(i + 1), x - 3, c.H - p + 6); }
    for (const vl of this.vlines) { const [x] = this.xy(vl.i, 0); c.strokeStyle = vl.color; c.setLineDash([4, 3]); c.beginPath(); c.moveTo(x, 8); c.lineTo(x, c.H - p); c.stroke(); c.setLineDash([]); if (vl.label) { c.fillStyle = vl.color; c.fillText(vl.label, x + 4, 12); } }
    for (const [name, cu] of Object.entries(this.o.curves)) {
      if (cu.hidden) continue;
      const act = name === this.active;
      c.strokeStyle = cu.color; c.lineWidth = act ? 2.6 : 1.3; c.globalAlpha = act ? 1 : 0.55; if (cu.dash) c.setLineDash(cu.dash);
      c.beginPath(); cu.data.forEach((v, i) => { const [x, y] = this.xy(i, v); i ? c.lineTo(x, y) : c.moveTo(x, y); }); c.stroke(); c.setLineDash([]);
      if (act && cu.dots !== false) { c.fillStyle = cu.color; cu.data.forEach((v, i) => { const [x, y] = this.xy(i, v); c.beginPath(); c.arc(x, y, 2.4, 0, 7); c.fill(); }); }
      c.globalAlpha = 1;
    }
    if (this.play >= 0 && this.play != null) { const [x] = this.xy(this.play, 0); c.fillStyle = '#fff'; c.fillRect(x, 8, 2, c.H - 8 - p); }
  }
  bind() {
    let down = false, last = null;
    const apply = e => {
      const r = this.cv.getBoundingClientRect(), p = this.o.pad, n = this.n;
      const i = Math.round(((e.clientX - r.left - p) / (this.c.W - p - 8)) * (n - 1)), v = M.clamp(1 - (e.clientY - r.top - 8) / (this.c.H - 8 - p), 0, 1);
      if (i < 0 || i >= n) return;
      const d = this.o.curves[this.active].data;
      if (last && last.i !== i) { const a = Math.min(last.i, i), b = Math.max(last.i, i); for (let k = a; k <= b; k++) d[k] = M.lerp(last.i < i ? last.v : v, last.i < i ? v : last.v, b === a ? 1 : (k - a) / (b - a)); }
      d[i] = v; last = {i, v}; this.draw();
    };
    this.cv.style.cursor = 'crosshair';
    this.cv.addEventListener('pointerdown', e => { down = true; last = null; this.cv.setPointerCapture(e.pointerId); apply(e); });
    this.cv.addEventListener('pointermove', e => { if (down) apply(e); });
    this.cv.addEventListener('pointerup', () => { down = false; last = null; this.o.onChange && this.o.onChange(this.o.curves); });
  }
};

/* ─────────────────────────── MIDI (SMF) ─────────────────────────── */
/* tracks: [{name, ch, program, notes:[{t,d,m,v}] (beats), drums:bool}] */
M.smf = (tracks, bpm = 120, opts = {}) => {
  const ppq = 480, bytes = [];
  const str = s => [...s].map(c => c.charCodeAt(0) & 0xff);
  const u32 = n => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255], u16 = n => [(n >> 8) & 255, n & 255];
  const vlq = n => { n = Math.max(0, Math.round(n)); const b = [n & 0x7f]; while ((n >>= 7)) b.unshift((n & 0x7f) | 0x80); return b; };
  const chunk = (id, data) => [...str(id), ...u32(data.length), ...data];
  const utf8 = s => [...s].map(c => { const k = c.charCodeAt(0); return k < 256 ? k : 63; });   // MIDI usa latin-1 por convención
  const trk = evs => { evs.sort((a, b) => a.tick - b.tick || a.ord - b.ord); let last = 0, d = []; for (const e of evs) { d.push(...vlq(e.tick - last), ...e.data); last = e.tick; } d.push(0, 0xff, 0x2f, 0); return chunk('MTrk', d); };
  const us = Math.round(60000000 / bpm), [num, den] = opts.timeSig || [4, 4];
  const t0 = [{tick: 0, ord: 0, data: [0xff, 0x51, 3, (us >> 16) & 255, (us >> 8) & 255, us & 255]}, {tick: 0, ord: 0, data: [0xff, 0x58, 4, num, Math.log2(den), 24, 8]}];
  if (opts.title) { const t = utf8(opts.title); t0.push({tick: 0, ord: 0, data: [0xff, 0x03, ...vlq(t.length), ...t]}); }
  (opts.tempoMap || []).forEach(tm => { const u = Math.round(60000000 / tm.bpm); t0.push({tick: Math.round(tm.t * ppq), ord: 0, data: [0xff, 0x51, 3, (u >> 16) & 255, (u >> 8) & 255, u & 255]}); });
  const out = [...chunk('MThd', [...u16(1), ...u16(tracks.length + 1), ...u16(ppq)]), ...trk(t0)];
  tracks.forEach((tr, ti) => {
    const ch = tr.drums ? 9 : (tr.ch ?? (ti >= 9 ? ti + 1 : ti)) & 15, nm = utf8(tr.name || 'Pista ' + (ti + 1));
    const evs = [{tick: 0, ord: 0, data: [0xff, 0x03, ...vlq(nm.length), ...nm]}];
    if (!tr.drums) evs.push({tick: 0, ord: 1, data: [0xc0 | ch, (tr.program || 0) & 127]});
    (tr.cc || []).forEach(c => evs.push({tick: Math.round(c.t * ppq), ord: 1, data: [0xb0 | ch, c.c & 127, M.clamp(Math.round(c.v), 0, 127)]}));
    for (const n of tr.notes) {
      const on = Math.round(n.t * ppq), off = Math.max(on + 1, Math.round((n.t + n.d) * ppq)), v = M.clamp(Math.round(n.v > 1 ? n.v : (n.v ?? 0.75) * 127), 1, 127);
      evs.push({tick: on, ord: 3, data: [0x90 | ch, n.m & 127, v]}, {tick: off, ord: 2, data: [0x80 | ch, n.m & 127, 0]});
    }
    out.push(...trk(evs));
  });
  return new Uint8Array(out);
};
M.download = (name, data, type = 'audio/midi') => {
  const url = URL.createObjectURL(new Blob([data], {type})); const a = M.h('a', {href: url, download: name}); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
};

/* ─────────────────────────── MELODÍA: crítica (port de melody_critic.py) ─────────────────────────── */
M.critiqueMelody = (notes) => {
  const ns = notes.slice().sort((a, b) => a.t - b.t);
  if (ns.length < 4) return null;
  const P = ns.map(n => n.m), I = P.slice(1).map((p, i) => p - P[i]);
  const ambit = Math.max(...P) - Math.min(...P);
  const steps = I.filter(x => Math.abs(x) <= 2).length, leaps = I.filter(x => Math.abs(x) > 2).length;
  const stepRatio = steps / Math.max(1, I.length);
  let unresolved = 0;
  for (let i = 0; i < I.length - 1; i++) if (Math.abs(I[i]) >= 5) { const c = I[i + 1]; if (!(Math.sign(c) === -Math.sign(I[i]) && Math.abs(c) <= 2)) unresolved++; }
  const mx = Math.max(...P), peakIdx = P.indexOf(mx), peakPos = peakIdx / Math.max(1, ns.length - 1), peakN = P.filter(p => p === mx).length;
  const dirs = I.filter(x => x !== 0).map(Math.sign); let dch = 0; for (let i = 1; i < dirs.length; i++) if (dirs[i] !== dirs[i - 1]) dch++;
  const dirRatio = dch / Math.max(1, dirs.length - 1);
  const repRatio = I.filter(x => x === 0).length / Math.max(1, I.length);
  const bounds = []; for (let i = 1; i < ns.length; i++) if (ns[i].t - (ns[i - 1].t + ns[i - 1].d) >= 1) bounds.push(i);
  const lens = [0, ...bounds, ns.length].map((b, i, a) => i ? b - a[i - 1] : null).slice(1);
  const nPh = bounds.length + 1, bal = lens.length > 1 ? Math.min(...lens) / Math.max(...lens) : 1;
  const E = [], S = [];
  if (ambit >= 7 && ambit <= 17) E.push(`Ámbito cantábile (${ambit} semitonos): fácil de cantar y recordar.`);
  else if (ambit < 5) S.push(`El ámbito es muy estrecho (${ambit} st): prueba a ampliar el registro para dar más recorrido a la melodía.`);
  else if (ambit > 21) S.push(`El ámbito es muy amplio (${ambit} st, más de 1½ 8ª): puede costar de cantar/tocar; considera acotarlo.`);
  if (stepRatio >= 0.55 && stepRatio <= 0.85) E.push(`Buen equilibrio grados/saltos (${Math.round(stepRatio * 100)}% por grado): fluye pero no es plana.`);
  else if (stepRatio > 0.9) S.push('Casi todo va por grados conjuntos: introduce algún salto expresivo (4ª, 5ª, 6ª) para crear interés.');
  else if (stepRatio < 0.4) S.push('Predominan los saltos: añade movimiento por grados para que la línea sea más cantábile y conecte las notas.');
  if (unresolved === 0 && leaps > 0) E.push('Todos los saltos grandes se compensan con paso contrario: conducción melódica muy sólida.');
  else if (unresolved > 0) S.push(`${unresolved} salto(s) grande(s) sin compensar: tras un salto amplio, suele sonar mejor moverse por grado en dirección contraria.`);
  if (peakPos >= 0.55 && peakPos <= 0.8 && peakN <= 2) E.push(`Clímax bien colocado (≈${Math.round(peakPos * 100)}% de la frase) y único: da una curva dramática clara.`);
  else if (peakN > 3) S.push(`La nota más alta aparece ${peakN} veces: reservarla para un solo momento haría el clímax más impactante.`);
  else if (peakPos < 0.3) S.push('El punto culminante llega muy pronto: retrasarlo hacia el último tercio suele dar más tensión narrativa.');
  if (dirRatio >= 0.25 && dirRatio <= 0.6) E.push('El contorno alterna subidas y bajadas con naturalidad.');
  else if (dirRatio > 0.7) S.push('El contorno cambia de dirección casi en cada nota (zigzag): prueba tramos más largos en una misma dirección.');
  else if (dirRatio < 0.15) S.push('La línea es muy unidireccional: alterna más subidas y bajadas.');
  if (repRatio > 0.35) S.push(`Muchas notas repetidas (${Math.round(repRatio * 100)}%): variar la altura evita que suene estática.`);
  if (nPh >= 2 && bal >= 0.6) E.push(`${nPh} frases de longitud equilibrada: buena sintaxis antecedente/consecuente.`);
  else if (nPh >= 2 && bal < 0.4) S.push('Las frases son muy desiguales en longitud: equilibrarlas (p.ej. 4+4 compases) da sensación de pregunta/respuesta.');
  else if (nPh === 1) S.push('Parece una sola frase larga: dividirla con una respiración crearía estructura de pregunta/respuesta.');
  const overall = Math.max(0, Math.min(1, 0.25 + 0.12 * E.length - 0.05 * S.length));
  return {ambit, stepRatio, leaps, unresolved, peakPos, peakIdx, peakN, dirRatio, repRatio, nPh, bal, elogios: E, sugerencias: S, overall};
};

/* ─────────────────────────── DATOS COMPARTIDOS ─────────────────────────── */
/* Arquetipos de batería: transcripción literal de STYLE_ARCHETYPES (drummer.py) para tensión t */
M.DRUM_ARCHETYPES = {
  rock_straight: {desc:'Rock clásico: corcheas en hi-hat, backbeat seco en 2 y 4', swing:.5, fn: t => { const k = z(), s = z(), h = z(), o = z(), cr = z(); k[0] = .9; k[8] = .85; if (t > .4) k[6] = .7; if (t > .65) k[10] = .65; if (t > .8) k[14] = .6; s[4] = .85; s[12] = .85; if (t > .5) s[10] = .3; const st = t > .5 ? 2 : 4; for (let i = 0; i < 16; i += st) h[i] = i % 4 ? .55 : .65; if (t > .3) o[14] = .6; cr[0] = .85; return {kick: k, snare: s, hihat_c: h, hihat_o: o, crash: cr}; }},
  funk_16th: {desc:'Funk de semicorcheas, ghost notes de caja, síncopa fuerte', swing:.52, fn: t => { const k = z(), s = z(), h = z(), o = z(); k[0] = .95; k[6] = .75; k[10] = .65; if (t > .5) { k[3] = .55; k[13] = .5; } if (t > .7) k[15] = .45; s[4] = .9; s[12] = .85; for (const g of [2, 6, 9, 11, 14]) if (t > .2) s[g] = .22 + t * .12; for (let i = 0; i < 16; i++) h[i] = i % 2 ? .5 : .6; o[10] = .55; o[14] = .5; return {kick: k, snare: s, hihat_c: h, hihat_o: o}; }},
  jazz_ride: {desc:'Jazz: ride con triplillo (swing), hi-hat de pedal en 2 y 4', swing:.67, fn: t => { const r = z(), k = z(), p = z(), s = z(); r[0] = .7; r[4] = .65; r[6] = .55; r[8] = .7; r[12] = .65; r[14] = .55; k[0] = .6; if (t > .4) k[10] = .45; if (t > .65) k[6] = .4; p[4] = .55; p[12] = .55; s[4] = .65; s[12] = .7; if (t > .5) { s[2] = .2; s[10] = .18; } return {kick: k, snare: s, ride: r, hihat_p: p}; }},
  bossa_nova: {desc:'Bossa nova: clave 3-2 en maracas, bombo suave', swing:.5, fn: t => { const k = z(), s = z(), h = z(), m = z(); k[0] = .7; k[6] = .55; k[9] = .5; if (t > .5) k[12] = .45; s[4] = .55; s[12] = .6; s[9] = t > .3 ? .35 : 0; for (const i of [0, 4, 8, 12]) h[i] = .5; for (const i of [0, 3, 6, 8, 11]) m[i] = .55 + t * .15; return {kick: k, snare: s, hihat_c: h, maracas: m}; }},
  reggae_one_drop: {desc:'Reggae one-drop: el bombo cae en el tiempo 3, no en el 1', swing:.5, fn: t => { const k = z(), s = z(), h = z(), o = z(), c = z(); k[8] = .9; if (t > .5) k[13] = .55; s[8] = .8; s[12] = .75; if (t > .4) s[10] = .3; for (let i = 0; i < 16; i += 4) h[i] = .55; o[4] = .6; for (const i of [0, 6, 9, 12]) c[i] = .45; return {kick: k, snare: s, hihat_c: h, hihat_o: o, clave: c}; }},
  afrobeat: {desc:'Afrobeat: clave yoruba y doble bombo a contratiempo', swing:.5, fn: t => { const k = z(), s = z(), h = z(), o = z(), c = z(); k[0] = .85; k[3] = .6; k[8] = .8; k[11] = .55; if (t > .5) { k[5] = .5; k[14] = .45; } s[4] = .75; s[12] = .7; if (t > .4) { s[6] = .35; s[10] = .3; } for (let i = 0; i < 16; i += 2) h[i] = .5; o[6] = .6; o[14] = .55; for (const i of [0, 3, 6, 9, 12]) c[i] = .55 + t * .1; return {kick: k, snare: s, hihat_c: h, hihat_o: o, clave: c}; }},
  latin_clave: {desc:'Latino: clave 2-3, bombo sincopado', swing:.5, fn: t => { const k = z(), s = z(), h = z(), m = z(), c = z(); k[0] = .9; k[7] = .7; k[10] = .6; if (t > .5) { k[3] = .5; k[13] = .45; } s[4] = .8; s[12] = .8; if (t > .4) s[8] = .35; for (let i = 0; i < 16; i += 2) h[i] = .52; for (const i of [0, 4, 8, 11, 14]) m[i] = .6; for (const i of [3, 7, 10, 12, 15]) c[i] = .55 + t * .1; return {kick: k, snare: s, hihat_c: h, maracas: m, clave: c}; }},
  tango: {desc:'Tango: habanera en el bombo (pasos 0·6·8·12)', swing:.5, fn: t => { const k = z(), s = z(), h = z(), c = z(); k[0] = .9; k[6] = .7; k[8] = .8; k[12] = .75; if (t > .5) k[14] = .55; s[4] = .75; s[12] = .8; if (t > .4) s[10] = .3; for (const i of [0, 4, 8, 12]) h[i] = .55; for (const i of [0, 6, 8, 12, 14]) c[i] = .5 + t * .15; return {kick: k, snare: s, hihat_c: h, clave: c}; }},
  half_time: {desc:'Half-time: la caja en el 3 hace sentir el tempo a la mitad', swing:.5, fn: t => { const k = z(), s = z(), h = z(), o = z(); k[0] = .9; k[6] = .7; k[10] = .6; if (t > .5) { k[3] = .55; k[14] = .5; } s[8] = .9; if (t > .4) s[12] = .4; for (let i = 0; i < 16; i += 2) h[i] = .52; o[6] = .55; o[14] = .5; return {kick: k, snare: s, hihat_c: h, hihat_o: o}; }},
  shuffle: {desc:'Blues shuffle: corcheas de triplillo', swing:.62, fn: t => { const k = z(), s = z(), h = z(), o = z(); k[0] = .9; k[8] = .8; if (t > .4) k[6] = .6; s[4] = .85; s[12] = .85; for (let i = 0; i < 16; i += 2) h[i] = .55; if (t > .3) o[14] = .6; return {kick: k, snare: s, hihat_c: h, hihat_o: o}; }},
  brushes: {desc:'Escobillas: ride suave y muchas ghost notes', swing:.65, fn: t => { const r = z(), k = z(), p = z(), s = z(); for (const i of [0, 4, 6, 8, 12, 14]) r[i] = .45 + t * .1; k[0] = .55; if (t > .5) k[10] = .4; p[4] = .45; p[12] = .45; s[4] = .45; s[12] = .5; for (const i of [1, 3, 6, 9, 11, 14]) s[i] = .15 + t * .08; return {kick: k, snare: s, ride: r, hihat_p: p}; }},
  trap: {desc:'Trap: hi-hat denso, bombo sincopado, palmas', swing:.5, fn: t => { const k = z(), s = z(), h = z(), o = z(); k[0] = .95; k[3] = .75; k[7] = .65; k[11] = .6; if (t > .5) { k[5] = .55; k[13] = .5; } if (t > .75) k[15] = .45; s[4] = .85; s[12] = .8; if (t > .4) s[8] = .5; for (let i = 0; i < 16; i++) h[i] = .4 + (i % 4 ? 0 : .2); for (const i of [2, 6, 10, 14]) if (t > .3) o[i] = .35 + t * .15; return {kick: k, snare: s, hihat_c: h, hihat_o: o}; }},
};
function z() { return new Array(16).fill(0); }
/* convierte un patrón de 16 pasos (1 compás 4/4) en eventos */
M.drumEvents = (pat, bars = 1, offset = 0) => {
  const ev = [];
  for (let b = 0; b < bars; b++) for (const [k, arr] of Object.entries(pat)) { if (!arr) continue; arr.forEach((v, i) => { if (v > 0) ev.push({t: offset + b * 4 + i / 4, d: 0.25, m: M.DRUM_GM[k] || 75, v, inst: 'drum:' + k}); }); }
  return ev;
};

/* Curvas de arco narrativo — port de build_arc_curves (narrator.py) */
const lin = (a, b, n) => Array.from({length: n}, (_, i) => n === 1 ? a : a + (b - a) * i / (n - 1));
const clip = (arr, a, b) => arr.map(x => M.clamp(x, a, b));
M.arcCurves = (arc, N) => {
  const t = lin(0, 1, N), S = Math.sin, PI = Math.PI;
  const q = Math.floor(N / 4), hlf = Math.floor(N / 2), c65 = Math.floor(N * 0.65), th = Math.floor(N / 3);
  const cat = (...xs) => [].concat(...xs).slice(0, N);
  const A = {
    hero: {tension: cat(lin(.1, .3, q), lin(.3, .95, hlf - q), lin(.95, .15, N - hlf)).map(x => .1 + .85 * x),
           activity: clip(cat(lin(.2, .5, q), lin(.5, 1, hlf - q), lin(1, .3, N - hlf)), 0, 1).map(x => .2 + .7 * x),
           register: clip(cat(lin(.4, .5, q), lin(.5, .9, hlf - q), lin(.9, .4, N - hlf)), 0, 1),
           harmony: clip(t.map(x => Math.pow(x, 1.5) * .8 + .1), 0, 1), swing: t.map(() => .1)},
    tragedy: {tension: clip(cat(lin(.2, .95, c65), lin(.95, .05, N - c65)), 0, 1), activity: clip(cat(lin(.3, .9, c65), lin(.9, .1, N - c65)), 0, 1),
           register: clip(cat(lin(.5, .95, c65), lin(.95, .1, N - c65)), 0, 1), harmony: clip(t.map(x => x * .9 + .1), 0, 1), swing: t.map(() => .05)},
    romance: {tension: clip(t.map(x => .3 + .4 * S(PI * x) + .1 * S(3 * PI * x)), .1, .9), activity: clip(t.map(x => .35 + .4 * S(PI * x * .8)), .2, .85),
           register: clip(t.map(x => .4 + .4 * S(PI * x)), .3, .9), harmony: clip(t.map(x => .3 + .3 * x + .2 * S(2 * PI * x)), .2, .8), swing: clip(t.map(x => .1 + .3 * S(PI * x)), 0, .6)},
    mystery: {tension: clip(t.map(x => .5 + .4 * S(2 * PI * x + .5) * x), .2, .95), activity: clip(t.map(x => .2 + .5 * x + .15 * S(4 * PI * x)), .1, .85),
           register: clip(t.map(x => .5 + .3 * S(3 * PI * x) * (1 - x * .3)), .2, .85), harmony: clip(t.map(x => .6 + .3 * x), .4, 1), swing: t.map(() => .05)},
    meditation: {tension: clip(t.map(x => .25 + .15 * S(2 * PI * x * 2)), .05, .5), activity: clip(t.map(x => .2 + .1 * S(PI * x)), .1, .4),
           register: clip(t.map(x => .4 + .1 * S(PI * x * 1.5)), .3, .6), harmony: clip(t.map(x => .2 + .15 * S(PI * x)), .1, .45), swing: clip(t.map(x => .2 + .1 * S(PI * x)), .1, .4)},
    rondo: {tension: clip(t.map((x, i) => .4 + .05 * S(10 * PI * i / (N - 1)) + .35 * (1 - Math.abs(2 * ((i / (N - 1)) % (1 / 5)) - 1 / 5))), .1, .9),
           activity: clip(t.map((x, i) => .4 + .25 * S(4 * PI * i / (N - 1))), .2, .85), register: clip(t.map((x, i) => .45 + .2 * Math.cos(4 * PI * i / (N - 1))), .2, .8),
           harmony: clip(t.map(x => .3 + .2 * S(3 * PI * x)), .2, .7), swing: clip(t.map(x => .15 + .1 * S(2 * PI * x)), .05, .4)},
    sonata: {tension: clip(t.map((x, i) => i < th ? .3 + .2 * (i / (N - 1)) : i < 2 * th ? .5 + .4 * S(PI * (i - th) / th) : .5 - .2 * ((i - 2 * th) / th)), .1, .95),
           activity: clip(t.map((x, i) => i < th ? .3 + .1 * (i / (N - 1)) : i < 2 * th ? .4 + .5 * (i - th) / th : .7 - .1 * ((i - 2 * th) / th)), .2, 1),
           register: clip(t.map((x, i) => i < th ? .45 + .1 * (i / th) : i < 2 * th ? .55 + .35 * S(PI * (i - th) / th) : .55 + .1 * (1 - (i - 2 * th) / th)), .3, 1),
           harmony: clip(t.map((x, i) => i < th ? .3 : i < 2 * th ? .3 + .6 * ((i - th) / th) : .4), .2, 1), swing: t.map(() => .08)},
  };
  return A[arc] || A.hero;
};
M.ARC_FORMS = {
  hero: [['A','Llamada',.20],['B','Prueba',.30],['C','Clímax',.25],['A','Resolución',.25]],
  tragedy: [['A','Ascenso',.35],['B','Punto alto',.30],['C','Caída',.35]],
  romance: [['A','Encuentro',.25],['B','Tensión',.30],['C','Unión',.25],['A','Reafirmación',.20]],
  mystery: [['A','Ambigüedad',.20],['B','Pistas',.25],['C','Crisis',.30],['A','Resolución',.25]],
  meditation: [['A','Reposo',.20],['B','Ondulación',.40],['A','Retorno',.40]],
  rondo: [['A','Tema',.15],['B','Episodio 1',.20],['A','Tema',.10],['C','Episodio 2',.20],['A','Tema',.10],['D','Episodio 3',.15],['A','Coda',.10]],
  sonata: [['A','Exposición',.33],['B','Desarrollo',.34],['A','Reexposición',.33]],
};
M.ARC_TONAL = {hero:['base','parallel','dominant','base'], tragedy:['base','relative','parallel'], romance:['base','relative','dominant','base'], mystery:['base','relative','parallel','base'], meditation:['base','relative','base'], rondo:['base','dominant','base','relative','base','subdominant','base'], sonata:['base','dominant','base']};
M.ARC_NAMES = {hero:'Héroe', tragedy:'Tragedia', romance:'Romance', mystery:'Misterio', meditation:'Meditación', rondo:'Rondó', sonata:'Sonata'};
M.CURVE_INFO = {tension:{label:'Tensión', color:'#ef7a7a', flag:'--mt-tension'}, activity:{label:'Actividad', color:'#7fd88f', flag:'--mt-density'}, register:{label:'Registro', color:'#6cc3e0', flag:'--mt-register'}, harmony:{label:'Complejidad armónica', color:'#f2b950', flag:'--mt-harmony-complexity'}, swing:{label:'Swing', color:'#b48cf2', flag:'--mt-swing'}};
/* Divide N compases en secciones según ARC_FORMS, como narrator.py */
M.arcSections = (arc, N) => {
  const f = M.ARC_FORMS[arc] || M.ARC_FORMS.hero; let acc = 0; const out = [];
  f.forEach(([id, label, p], i) => { const bars = i === f.length - 1 ? N - acc : Math.max(1, Math.round(N * p)); out.push({id, label, start: acc, bars}); acc += bars; });
  return out;
};

})();
