# Academia Mutopia

Recurso educativo interactivo sobre el ecosistema mutopia: fundamentos musicales y técnicos
de sus herramientas y cómo se encadenan en un flujo creativo.

**Uso:** abrir `index.html` en un navegador moderno (Chrome, Firefox, Edge, Safari).
No necesita servidor, conexión ni dependencias: todo (audio incluido) funciona desde `file://`.

## Contenido

| Fichero | Qué enseña | Herramientas cuya lógica se ejecuta en el navegador |
|---|---|---|
| `index.html` | Mapa interactivo del flujo, 8 recetas que lo recorren, ideas transversales, atlas de las 163 herramientas | — |
| `01-sonido.html` | Altura, serie armónica, aditiva, FM, Karplus-Strong, problema inverso, cadena de efectos, Mahalanobis, transcripción | genopatch (GA), audio_effects (orden de la cadena), audio_reference_scorer |
| `02-representacion.html` | Evento MIDI, 6 tokenizaciones, partitura.yaml, piano roll y chroma, vectores | music_transformer/remi/clara/piano_autocomplete/anticipation (tokens), midi2yaml, corpus_explorer (10 dims), analyzer nearest/diff |
| `03-armonia.html` | Modos, Krumhansl-Schmuckler, grados y funciones, progresiones, n-gramas, cadencias, expectativa, armonía negativa, pivote | chord_table (catálogo real de 101 entradas), chord_copilot (add-k), cadence_designer (12 tipos), leadsheet_realizer |
| `04-voces.html` | SATB, paralelas, corrección, contrapunto de Fux | voice_leader (DP), harmony_checker, counterpoint `_species1_csp` (H1–H6 + P1) |
| `05-melodia.html` | Contorno y crítica, transformaciones motívicas, periodo, Markov | melody_critic (port literal), variation_engine, leitmotif_analyst (juego inverso), phrase_builder |
| `06-ritmo.html` | Arquetipos de batería, síncopa, bajo como voz, cambio de compás | drummer `STYLE_ARCHETYPES` (literal), metric_analyzer (LHL, nPVI), bass_line_composer, meter_adapter |
| `07-forma.html` | Arcos narrativos, curvas, clímax áureo, verificación del plan, SSM | narrator `build_arc_curves` (literal), tension_designer, climax_engineer, silence_designer, arc_supervisor, harvester |
| `08-interpretacion.html` | Reglas de interpretación, tempo global, color orquestal, tocabilidad, transposición | performer, tempo_designer, orchestral_colorist `EMOTION_PALETTES` (literal), playability_auditor `INSTRUMENT_DB`, part_extractor |
| `09-maquinas.html` | Paradigmas, temperatura/top-p, genético, Re-Pair, difusión DDIM, morphing, familias neuronales | evolver/counterexample, grammar_composer (Re-Pair), diffusion_composer (DDIM x₀), morpher |
| `10-practica.html` | Dificultad, simplificación, digitación, plan de estudio, ejercicios, oído | practice_tutor, combined_simplifier, fingering (Viterbi), piano_duo_analyzer, etude_generator, ear_trainer |
| `taller.html` | El flujo completo: intención → plan → armonía → melodía → textura → expresión → crítica → exportación (MIDI, curves.json, partitura.yaml, receta.sh) | theorist (léxico), narrator, chord_progression_generator, melody_conditioned, drummer, climax_engineer, performer |

## Estructura técnica

- `assets/core.js`: teoría musical, motor Web Audio (instrumentos y percusión sintetizados), secuenciador,
  piano roll, teclado, pentagrama, editor de curvas, escritor SMF (MIDI), quizzes y progreso (localStorage).
- `assets/composer.js`: mini-pipeline compositivo compartido por las lecciones 07, 08, 10 y el taller.
- `assets/tools.js`: catálogo generado a partir de `mutopia_compendio.pdf` y de los docstrings de cada script.
- `assets/chord_table.js`: el `TABLE` de `chord_table.py`.

Comprobado: las 101 progresiones de `chord_table.py` resuelven igual en Python y en la academia
(4.920 acordes, 12 tónicas); el `melody_critic.py` real puntúa un MIDI exportado por el taller con el mismo valor que el port
en JavaScript, y `harmonic_analyzer.py` reconoce su armonía.

## Discrepancias entre el compendio y el código

- El compendio habla de 154 herramientas y de 70 progresiones en chord_table; el directorio tiene 163 scripts
  y el catálogo 101 entradas. El compendio cita `motif_table_v2.py`; el fichero es `motif_table.py`.
