"""
Entrenamiento autoresearch sobre corpus ABC — variante DIFUSIÓN (denoising discreto).

Intercambiable con abc_train.py dentro del mismo bucle autónomo:
- Misma infraestructura de datos: usa abc_prepare.py sin modificarlo
  (mismo tokenizer, mismo corpus, mismo MAX_SEQ_LEN, mismo TIME_BUDGET).
- Mismo formato de salida por consola (los mismos campos que grep
  "^phase:\\|^val_bpb:\\|^pref_score:\\|^validity_ratio:\\|^combined_score:"
  espera en abc_program.md), así que el agente que ya sabe leer
  run.log de abc_train.py puede leer el de este script sin cambios.
- Mismo formato de checkpoint (model_checkpoint.pt) más dos campos nuevos:
  "arch" y "mask_token_id", para que generate.py sepa qué reconstruir.

Autocontenido: NO importa abc_model.py. La arquitectura (atención
bidireccional + rotary + QK-norm + MLP ReLU²) está definida aquí mismo,
inspirada en tiny-diffusion (github.com/nathan-barry/tiny-diffusion) pero
adaptada a tokens BPE (no caracteres) y al empaquetado por documentos ABC
que ya usa abc_train.py.

Diferencias de fondo respecto al GPT autoregresivo (abc_train.py):
  - Atención bidireccional (is_causal=False), no causal.
  - El "ruido" es enmascarado aleatorio de tokens (no siguiente-token).
  - La pérdida solo se computa sobre posiciones enmascaradas.
  - La generación es paralela por bloque con decodificación por confianza,
    no autoregresiva token a token.
  - "val_bpb" aquí es un PROXY (denoising con la fila 100% enmascarada,
    análogo a "generar desde cero"), no una verosimilitud autoregresiva
    real. Es comparable en orden de magnitud pero NO idéntico en semántica
    al val_bpb del GPT — trátalo como métrica de otra familia al comparar
    commits GPT vs. difusión en results.tsv (anótalo en "description").

Uso:
    uv run abc_train_diffusion.py
    ABC_TIME_BUDGET=20 uv run abc_train_diffusion.py     # smoke test rápido
"""

import gc
import json
import math
import os
import subprocess
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

from abc_prepare import (
    EVAL_TOKENS,
    MAX_SEQ_LEN,
    SEP_TOKEN,
    TIME_BUDGET as DEFAULT_TIME_BUDGET,
    Tokenizer,
    get_token_bytes,
)

# Permite acortar el presupuesto de entrenamiento para smoke tests sin tocar
# abc_prepare.py (que es "no modificar" según el README del proyecto).
TIME_BUDGET = int(os.environ.get("ABC_TIME_BUDGET", DEFAULT_TIME_BUDGET))

# ---------------------------------------------------------------------------
# Fase de entrenamiento  ← EL AGENTE MODIFICA ESTO (igual que en abc_train.py)
# ---------------------------------------------------------------------------

PHASE = 1

# ---------------------------------------------------------------------------
# Configuración de preferencias (solo relevante en PHASE = 2)
# ---------------------------------------------------------------------------

PREF_TRAINER_PATH = "./preference_trainer.py"
PREF_MODEL        = "prefs"
PREF_CORPUS       = "./corpus.npz"
PREF_EVAL_SAMPLES = 20
PREF_SAMPLE_LEN   = 256
PREF_TEMPERATURE  = 0.85
PREF_WEIGHT       = 0.3

# ---------------------------------------------------------------------------
# Hiperparámetros  ← EL AGENTE MODIFICA ESTA SECCIÓN
# ---------------------------------------------------------------------------

# Arquitectura
DEPTH        = 4    # capas transformer
HEAD_DIM     = 32   # dimensión por cabeza de atención
ASPECT_RATIO = 24   # model_dim = max(DEPTH * ASPECT_RATIO, HEAD_DIM)

# Optimizador
LR             = 1e-3
WEIGHT_DECAY   = 0.1
ADAM_BETAS     = (0.9, 0.95)
WARMUP_RATIO   = 0.05
WARMDOWN_RATIO = 0.4
FINAL_LR_FRAC  = 0.0

# Batch — igual restricción que en abc_train.py:
# TOTAL_BATCH_SIZE debe ser múltiplo de DEVICE_BATCH_SIZE * MAX_SEQ_LEN
TOTAL_BATCH_SIZE  = 2**10
DEVICE_BATCH_SIZE = 2

# Específico de difusión: proporción de tokens enmascarados por fila de
# entrenamiento se muestrea uniformemente en [MASK_RATIO_MIN, 1.0] por fila
# (igual que tiny-diffusion). Un mínimo > 0 evita filas sin señal de pérdida.
MASK_RATIO_MIN = 0.1

# Nombre del token especial reutilizado como MASK. Ya existe en el
# vocabulario BPE entrenado por abc_prepare.py (reserved_0=BOS,
# reserved_1=SEP, reserved_2 y reserved_3 estaban libres) — no hace falta
# reentrenar el tokenizador.
MASK_TOKEN = "<|reserved_2|>"


# ---------------------------------------------------------------------------
# Arquitectura — transformer bidireccional (denoising)
# ---------------------------------------------------------------------------

@dataclass
class DiffusionConfig:
    sequence_len:   int = 512
    vocab_size:     int = 512
    n_layer:        int = 4
    n_head:         int = 4
    n_embd:         int = 128
    mask_token_id:  int = 0


def norm(x):
    return F.rms_norm(x, (x.size(-1),))


def apply_rotary_emb(x, cos, sin):
    assert x.ndim == 4
    d = x.shape[3] // 2
    x1, x2 = x[..., :d], x[..., d:]
    y1 = x1 * cos + x2 * sin
    y2 = x1 * (-sin) + x2 * cos
    return torch.cat([y1, y2], 3)


class BidirectionalSelfAttention(nn.Module):
    """Idéntica a la atención de abc_model.py salvo is_causal=False: esta es
    LA diferencia arquitectónica que convierte el GPT en modelo de difusión."""

    def __init__(self, config):
        super().__init__()
        self.n_head   = config.n_head
        self.n_embd   = config.n_embd
        self.head_dim = self.n_embd // self.n_head
        assert self.n_embd % self.n_head == 0
        self.c_q    = nn.Linear(self.n_embd, self.n_embd, bias=False)
        self.c_k    = nn.Linear(self.n_embd, self.n_embd, bias=False)
        self.c_v    = nn.Linear(self.n_embd, self.n_embd, bias=False)
        self.c_proj = nn.Linear(self.n_embd, self.n_embd, bias=False)

    def forward(self, x, cos_sin):
        B, T, C = x.size()
        q = self.c_q(x).view(B, T, self.n_head, self.head_dim)
        k = self.c_k(x).view(B, T, self.n_head, self.head_dim)
        v = self.c_v(x).view(B, T, self.n_head, self.head_dim)

        cos, sin = cos_sin
        q, k = apply_rotary_emb(q, cos, sin), apply_rotary_emb(k, cos, sin)
        q, k = norm(q), norm(k)

        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)
        y = F.scaled_dot_product_attention(q, k, v, is_causal=False)
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.c_proj(y)


class MLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.c_fc   = nn.Linear(config.n_embd, 4 * config.n_embd, bias=False)
        self.c_proj = nn.Linear(4 * config.n_embd, config.n_embd, bias=False)

    def forward(self, x):
        return self.c_proj(F.relu(self.c_fc(x)).square())


class Block(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.attn = BidirectionalSelfAttention(config)
        self.mlp  = MLP(config)

    def forward(self, x, cos_sin):
        x = x + self.attn(norm(x), cos_sin)
        x = x + self.mlp(norm(x))
        return x


class DiffusionGPT(nn.Module):
    """Mismo contrato público que abc_model.GPT: init_weights(),
    num_scaling_params(), setup_optimizer(), forward(idx, targets, reduction),
    y config con .sequence_len/.vocab_size/.n_layer/.n_head/.n_embd."""

    def __init__(self, config: DiffusionConfig):
        super().__init__()
        self.config = config
        self.wte     = nn.Embedding(config.vocab_size, config.n_embd)
        self.blocks  = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)

        head_dim = config.n_embd // config.n_head
        self.rotary_seq_len = config.sequence_len * 2
        cos, sin = self._precompute_rotary_embeddings(self.rotary_seq_len, head_dim)
        self.register_buffer("cos", cos, persistent=False)
        self.register_buffer("sin", sin, persistent=False)

    def init_weights(self):
        nn.init.normal_(self.wte.weight, mean=0.0, std=1.0)
        nn.init.normal_(self.lm_head.weight, mean=0.0, std=0.001)
        s = 3**0.5 * self.config.n_embd**-0.5
        for block in self.blocks:
            nn.init.uniform_(block.attn.c_q.weight, -s, s)
            nn.init.uniform_(block.attn.c_k.weight, -s, s)
            nn.init.uniform_(block.attn.c_v.weight, -s, s)
            nn.init.zeros_(block.attn.c_proj.weight)
            nn.init.uniform_(block.mlp.c_fc.weight, -s, s)
            nn.init.zeros_(block.mlp.c_proj.weight)

    def _precompute_rotary_embeddings(self, seq_len, head_dim, base=10000):
        channel_range = torch.arange(0, head_dim, 2, dtype=torch.float32)
        inv_freq      = 1.0 / (base ** (channel_range / head_dim))
        t     = torch.arange(seq_len, dtype=torch.float32)
        freqs = torch.outer(t, inv_freq)
        cos, sin = freqs.cos(), freqs.sin()
        return cos[None, :, None, :], sin[None, :, None, :]

    def forward(self, idx, targets=None, reduction="mean", mask=None):
        B, T = idx.size()
        x = norm(self.wte(idx))
        cos = self.cos[:, :T]
        sin = self.sin[:, :T]

        for block in self.blocks:
            x = block(x, (cos, sin))

        logits = self.lm_head(norm(x))

        if targets is None:
            return logits

        loss_flat = F.cross_entropy(
            logits.view(-1, logits.size(-1)), targets.view(-1), reduction="none",
        )
        if mask is not None:
            mask_flat = mask.reshape(-1).float()
            if reduction == "mean":
                return (loss_flat * mask_flat).sum() / mask_flat.sum().clamp(min=1.0)
            return loss_flat * mask_flat

        return loss_flat.mean() if reduction == "mean" else loss_flat

    def num_scaling_params(self):
        total = sum(p.numel() for p in self.parameters())
        emb   = self.wte.weight.numel()
        return {"total": total, "non_embedding": total - emb}

    def setup_optimizer(self, lr, weight_decay, betas):
        decay_params   = [p for n, p in self.named_parameters() if p.ndim >= 2]
        nodecay_params = [p for n, p in self.named_parameters() if p.ndim < 2]
        return torch.optim.AdamW(
            [
                {"params": decay_params,   "weight_decay": weight_decay},
                {"params": nodecay_params, "weight_decay": 0.0},
            ],
            lr=lr, betas=betas,
        )


# ---------------------------------------------------------------------------
# Dataloader de difusión — mismo empaquetado por documentos que abc_train.py,
# pero SIN el shift de siguiente-token, y con enmascarado aleatorio por fila.
# ---------------------------------------------------------------------------

def make_dataloader_diffusion_cpu(tokenizer, B, T, split, mask_token_id, buffer_size=500):
    from abc_prepare import _text_chunks
    assert split in ["train", "val"]
    bos_token  = tokenizer.get_bos_token_id()
    doc_buffer = []
    chunk_iter = _text_chunks(split, chunk_size=T * 3)
    epoch      = 1

    def refill():
        nonlocal epoch
        chunk = next(chunk_iter)
        docs  = [d.strip() for d in chunk.split(SEP_TOKEN) if d.strip()] or [chunk]
        doc_buffer.extend(tokenizer.encode(docs, prepend=bos_token))

    row_buffer = torch.empty((B, T), dtype=torch.long)

    while True:
        for row_idx in range(B):
            pos = 0
            while pos < T:
                while len(doc_buffer) < buffer_size:
                    refill()
                remaining = T - pos
                best_idx, best_len = -1, 0
                for i, doc in enumerate(doc_buffer):
                    if len(doc) <= remaining and len(doc) > best_len:
                        best_idx, best_len = i, len(doc)
                if best_idx >= 0:
                    doc = doc_buffer.pop(best_idx)
                    row_buffer[row_idx, pos:pos + len(doc)] = torch.tensor(doc, dtype=torch.long)
                    pos += len(doc)
                else:
                    shortest = min(range(len(doc_buffer)), key=lambda i: len(doc_buffer[i]))
                    doc = doc_buffer.pop(shortest)
                    row_buffer[row_idx, pos:pos + remaining] = torch.tensor(doc[:remaining], dtype=torch.long)
                    pos += remaining

        y = row_buffer.clone()
        mask_probs = torch.empty(B, 1).uniform_(MASK_RATIO_MIN, 1.0)
        mask = torch.rand(B, T) < mask_probs
        x = y.clone()
        x[mask] = mask_token_id

        yield x, y, mask, epoch


# ---------------------------------------------------------------------------
# Evaluación "val_bpb" — proxy de difusión (enmascarado total = generar
# desde cero). Ver nota en la cabecera del fichero sobre su semántica.
# ---------------------------------------------------------------------------

@torch.no_grad()
def evaluate_bpb_diffusion_cpu(model, tokenizer, batch_size, mask_token_id):
    token_bytes = get_token_bytes(device="cpu")
    val_loader  = make_dataloader_diffusion_cpu(tokenizer, batch_size, MAX_SEQ_LEN, "val", mask_token_id)
    steps       = max(1, EVAL_TOKENS // (batch_size * MAX_SEQ_LEN))
    total_nats  = 0.0
    total_bytes = 0
    model.eval()
    for _ in range(steps):
        _, y, _, _ = next(val_loader)
        x_full = torch.full_like(y, mask_token_id)
        loss_flat = model(x_full, y, reduction="none").view(-1)
        nbytes    = token_bytes[y.view(-1)]
        keep      = nbytes > 0
        total_nats  += (loss_flat * keep).sum().item()
        total_bytes += nbytes[keep].sum().item()
    return total_nats / (math.log(2) * max(total_bytes, 1))


# ---------------------------------------------------------------------------
# Generación — decodificación paralela por confianza (un bloque de tamaño
# MAX_SEQ_LEN es suficiente: las piezas ABC son cortas). Mismo contrato de
# entrada/salida que abc_model.generate_abc_sample para que generate.py y
# el bucle de preferencias no necesiten distinguir la arquitectura.
# ---------------------------------------------------------------------------

@torch.no_grad()
def generate_abc_sample(model, tokenizer, max_new_tokens=256, temperature=0.85,
                         confidence_threshold=0.9, top_k=4):
    model.eval()
    mask_id = model.config.mask_token_id
    bos_id  = tokenizer.get_bos_token_id()
    T       = min(model.config.sequence_len, max_new_tokens + 1)

    stop_ids = set()
    for special in ["<|reserved_0|>", "<|reserved_1|>"]:
        try:
            stop_ids.add(tokenizer.enc.encode_single_token(special))
        except Exception:
            pass

    x = torch.full((1, T), mask_id, dtype=torch.long)
    x[0, 0] = bos_id
    masked = torch.zeros(1, T, dtype=torch.bool)
    masked[0, 1:] = True

    max_steps = T * 2  # cota de seguridad: nunca debería hacer falta más
    for _ in range(max_steps):
        if not masked.any():
            break
        logits = model(x)
        probs  = F.softmax(logits / temperature, dim=-1)
        top_k_probs, top_k_idx = torch.topk(probs, k=top_k, dim=-1)
        confidences = top_k_probs.sum(dim=-1)

        decode_mask = (confidences >= confidence_threshold) & masked
        if not decode_mask.any():
            masked_conf = torch.where(masked, confidences, torch.tensor(-float("inf")))
            decode_mask.view(-1)[masked_conf.argmax()] = True

        top_k_probs_norm = top_k_probs / top_k_probs.sum(dim=-1, keepdim=True)
        sampled_k = torch.multinomial(top_k_probs_norm.view(-1, top_k), 1).view(1, T)
        sampled   = torch.gather(top_k_idx, -1, sampled_k.unsqueeze(-1)).squeeze(-1)

        x = torch.where(decode_mask, sampled, x)
        masked = masked & ~decode_mask

    ids = x[0, 1:].tolist()  # excluir BOS
    for i, tok in enumerate(ids):
        if tok in stop_ids:
            ids = ids[:i]
            break
    return tokenizer.decode(ids)


def is_valid_abc(text: str) -> bool:
    """Idéntica a abc_model.is_valid_abc — copiada para mantener el fichero
    autocontenido (sin importar abc_model.py)."""
    lines      = text.splitlines()
    has_header = any(line.startswith(("X:", "T:", "K:", "M:")) for line in lines)
    has_notes  = any(c in text for c in "ABCDEFGabcdefg")
    has_bar    = "|" in text
    return has_header and has_notes and has_bar


# ---------------------------------------------------------------------------
# Evaluación de preferencias (PHASE = 2) — copiada de abc_train.py sin
# cambios de lógica, solo referenciando el generate_abc_sample de este fichero.
# ---------------------------------------------------------------------------

def convert_abc_to_midi(abc_text, midi_path):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".abc",
                                    delete=False, encoding="utf-8") as f:
        f.write(abc_text)
        abc_path = f.name
    try:
        result = subprocess.run(
            ["abc2midi", abc_path, "-o", midi_path],
            capture_output=True, timeout=10,
        )
        return result.returncode == 0 and Path(midi_path).exists()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False
    finally:
        try: os.unlink(abc_path)
        except OSError: pass


def evaluate_preference_score(midi_files):
    if not midi_files:
        return {"pref_score": None, "n_valid": 0, "n_total": 0}

    model_file = f"{PREF_MODEL}.prefs.json"
    if not Path(model_file).exists():
        for suffix in ["linear.json", "neural.json", "kernel.json", "gp.json", "svm.json"]:
            if Path(f"{PREF_MODEL}.prefs.{suffix}").exists():
                model_file = f"{PREF_MODEL}.prefs.{suffix}"
                break
        else:
            print(f"  [pref] No se encontró {PREF_MODEL}.prefs.json — saltando")
            return {"pref_score": None, "n_valid": 0, "n_total": len(midi_files)}

    cmd = ["python", PREF_TRAINER_PATH, "eval", *midi_files, "--model", PREF_MODEL, "--json"]
    if PREF_CORPUS and Path(PREF_CORPUS).exists():
        cmd += ["--corpus", PREF_CORPUS]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        output = result.stdout
        j0, j1 = output.rfind("{"), output.rfind("}") + 1
        if j0 >= 0 and j1 > j0:
            data   = json.loads(output[j0:j1])
            scores = [
                val["score"] if isinstance(val, dict) and "score" in val else val
                for val in data.values()
                if isinstance(val, (int, float)) or (isinstance(val, dict) and "score" in val)
            ]
            if scores:
                return {"pref_score": round(sum(scores) / len(scores), 4),
                        "n_valid": len(midi_files), "n_total": len(midi_files)}
    except Exception as e:
        print(f"  [pref] Error: {e}")

    return {"pref_score": None, "n_valid": 0, "n_total": len(midi_files)}


def run_preference_evaluation(model, tokenizer):
    print(f"\n  [pref] Generando {PREF_EVAL_SAMPLES} muestras ABC...")
    valid_samples = []
    for _ in range(PREF_EVAL_SAMPLES):
        text = generate_abc_sample(model, tokenizer,
                                   max_new_tokens=PREF_SAMPLE_LEN,
                                   temperature=PREF_TEMPERATURE)
        if is_valid_abc(text):
            valid_samples.append(text)

    n_valid = len(valid_samples)
    print(f"  [pref] {n_valid}/{PREF_EVAL_SAMPLES} válidas ({100*n_valid//PREF_EVAL_SAMPLES}%)")

    if n_valid == 0:
        return {"pref_score": None, "validity_ratio": 0.0}

    tmpdir     = tempfile.mkdtemp(prefix="abc_eval_")
    midi_files = []
    for i, abc_text in enumerate(valid_samples):
        midi_path = os.path.join(tmpdir, f"sample_{i:03d}.mid")
        if convert_abc_to_midi(abc_text, midi_path):
            midi_files.append(midi_path)

    print(f"  [pref] {len(midi_files)}/{n_valid} convertidos a MIDI")
    result = evaluate_preference_score(midi_files)

    for f in midi_files:
        try: os.unlink(f)
        except OSError: pass
    try: os.rmdir(tmpdir)
    except OSError: pass

    result["validity_ratio"] = round(n_valid / PREF_EVAL_SAMPLES, 3)
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    t_start = time.time()
    torch.manual_seed(42)
    torch.set_float32_matmul_precision("high")

    tokenizer  = Tokenizer.from_directory()
    vocab_size = tokenizer.get_vocab_size()
    mask_token_id = tokenizer.enc.encode_single_token(MASK_TOKEN)
    print(f"Vocab size: {vocab_size:,} | mask_token_id: {mask_token_id}")

    base_dim  = DEPTH * ASPECT_RATIO
    model_dim = max(base_dim, HEAD_DIM)
    model_dim = ((model_dim + HEAD_DIM - 1) // HEAD_DIM) * HEAD_DIM
    num_heads = model_dim // HEAD_DIM

    config = DiffusionConfig(
        sequence_len=MAX_SEQ_LEN, vocab_size=vocab_size,
        n_layer=DEPTH, n_head=num_heads, n_embd=model_dim,
        mask_token_id=mask_token_id,
    )
    print(f"Model config: {asdict(config)}")

    model = DiffusionGPT(config)
    model.init_weights()

    param_counts = model.num_scaling_params()
    print("Parameter counts:")
    for key, value in param_counts.items():
        print(f"  {key:24s}: {value:,}")
    num_params = param_counts["total"]

    tokens_per_step = DEVICE_BATCH_SIZE * MAX_SEQ_LEN
    assert TOTAL_BATCH_SIZE % tokens_per_step == 0, \
        f"TOTAL_BATCH_SIZE={TOTAL_BATCH_SIZE} no divisible por {tokens_per_step}"
    grad_accum_steps = TOTAL_BATCH_SIZE // tokens_per_step

    optimizer    = model.setup_optimizer(LR, WEIGHT_DECAY, ADAM_BETAS)
    train_loader = make_dataloader_diffusion_cpu(tokenizer, DEVICE_BATCH_SIZE, MAX_SEQ_LEN, "train", mask_token_id)
    x, y, mask, epoch = next(train_loader)

    print(f"Time budget: {TIME_BUDGET}s | grad_accum_steps: {grad_accum_steps}")

    def get_lr(progress):
        if progress < WARMUP_RATIO:
            return LR * (progress / WARMUP_RATIO) if WARMUP_RATIO > 0 else LR
        elif progress < 1.0 - WARMDOWN_RATIO:
            return LR
        else:
            cooldown = (1.0 - progress) / WARMDOWN_RATIO
            return LR * (cooldown + (1 - cooldown) * FINAL_LR_FRAC)

    # ── Bucle de entrenamiento ────────────────────────────────────────────────

    t_start_training    = time.time()
    smooth_train_loss   = 0.0
    total_training_time = 0.0
    step                = 0

    while True:
        t0 = time.time()

        model.train()
        for _ in range(grad_accum_steps):
            loss = model(x, y, mask=mask) / grad_accum_steps
            loss.backward()
            x, y, mask, epoch = next(train_loader)

        train_loss_f = loss.item() * grad_accum_steps
        if math.isnan(train_loss_f) or train_loss_f > 100:
            print("FAIL")
            raise SystemExit(1)

        progress   = min(total_training_time / TIME_BUDGET, 1.0)
        current_lr = get_lr(progress)
        for group in optimizer.param_groups:
            group["lr"] = current_lr

        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        optimizer.zero_grad()

        t1 = time.time()
        dt = t1 - t0
        if step > 5:
            total_training_time += dt

        ema_beta          = 0.9
        smooth_train_loss = ema_beta * smooth_train_loss + (1 - ema_beta) * train_loss_f
        debiased          = smooth_train_loss / (1 - ema_beta**(step + 1))
        remaining         = max(0, TIME_BUDGET - total_training_time)

        print(
            f"\rstep {step:04d} ({100*progress:.1f}%) | loss: {debiased:.4f} | "
            f"lr: {current_lr:.2e} | dt: {dt*1000:.0f}ms | epoch: {epoch} | remaining: {remaining:.0f}s    ",
            end="", flush=True,
        )

        if step == 0:
            gc.collect()

        step += 1
        if step > 5 and total_training_time >= TIME_BUDGET:
            break

    print()
    total_tokens = step * TOTAL_BATCH_SIZE

    # ── Evaluación final ──────────────────────────────────────────────────────

    model.eval()
    val_bpb = evaluate_bpb_diffusion_cpu(model, tokenizer, DEVICE_BATCH_SIZE, mask_token_id)

    if PHASE == 1:
        pref_score = validity_ratio = combined_score = None
    else:
        print("\nEvaluando preferencias musicales...")
        pref_result    = run_preference_evaluation(model, tokenizer)
        pref_score     = pref_result.get("pref_score")
        validity_ratio = pref_result.get("validity_ratio", 0.0)
        if pref_score is not None:
            combined_score = ((1 - PREF_WEIGHT) * (1.0 / max(val_bpb, 1e-6))
                              + PREF_WEIGHT * (pref_score / 5.0))
        else:
            combined_score = None

    # ── Guardar checkpoint ────────────────────────────────────────────────────

    torch.save({
        "model_state":    model.state_dict(),
        "config":         asdict(config),
        "val_bpb":        val_bpb,
        "step":           step,
        "depth":          DEPTH,
        "model_dim":      model_dim,
        "head_dim":       HEAD_DIM,
        "vocab_size":     vocab_size,
        "arch":           "diffusion",
        "mask_token_id":  mask_token_id,
    }, "model_checkpoint.pt")
    print("Checkpoint guardado: model_checkpoint.pt")

    # ── Resumen ───────────────────────────────────────────────────────────────

    def fmt(val, d=6):
        return f"{val:.{d}f}" if val is not None else "N/A"

    t_end = time.time()
    print("---")
    print(f"arch:             diffusion")
    print(f"phase:            {PHASE}")
    print(f"val_bpb:          {val_bpb:.6f}")
    print(f"pref_score:       {fmt(pref_score, 4)}")
    print(f"validity_ratio:   {fmt(validity_ratio, 3)}")
    print(f"combined_score:   {fmt(combined_score, 6)}")
    print(f"training_seconds: {total_training_time:.1f}")
    print(f"total_seconds:    {t_end - t_start:.1f}")
    print(f"total_tokens_M:   {total_tokens / 1e6:.3f}")
    print(f"num_steps:        {step}")
    print(f"num_params_M:     {num_params / 1e6:.3f}")
    print(f"depth:            {DEPTH}")
    print(f"model_dim:        {model_dim}")
