# terminal

Package terminal is a vt10x terminal emulation backend, influenced
largely by st, rxvt, xterm, and iTerm as reference. Use it for terminal
muxing, a terminal emulation frontend, or wherever else you need
terminal emulation.

## Installation

	go get j4k.co/terminal

New to Go? Have a look at how [import paths work](http://golang.org/doc/code.html#remote).

_Vendored at 0aabd5e5da824b33403ebde1df03776a0d45c7b2 on Nov 26th 2017._
