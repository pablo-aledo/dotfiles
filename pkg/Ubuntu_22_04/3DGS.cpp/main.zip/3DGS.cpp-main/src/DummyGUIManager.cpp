#include "GUIManager.h"

#include <iostream>

GUIManager::GUIManager() {

}

void GUIManager::init() {

}

void GUIManager::buildGui() {

}

void GUIManager::pushTextMetric(const std::string& name, float value) {

}

void GUIManager::pushMetric(const std::string& name, float value) {

}

void GUIManager::pushMetric(const std::unordered_map<std::string, float>& name) {

}

bool GUIManager::wantCaptureMouse() {
    return false;
}

bool GUIManager::wantCaptureKeyboard() {
    return false;
}
