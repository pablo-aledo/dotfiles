## schema -> ui generation

https://json-schema.org/implementations.html#web-ui-generation

-   https://github.com/guillotinaweb/ngx-schema-form
-   https://github.com/hamzahamidi/ajsf angular igh
-   https://github.com/dashjoin/json-schema-form
-   https://github.com/json-editor/json-editor
-   https://github.com/jsonform/jsonform
-   https://github.com/vazco/uniforms

## json schema is ridiculous

    "mimetypes": {
        "description": "if not null and --rga-accurate is enabled, mime type matching is used instead of file name matching",
        "type": [
            "array",
            "null"
        ],
        "items": {
            "type": "string"
        }
    },

    what the fuck????
    this is the only thing required to see that json schema has horrible design
