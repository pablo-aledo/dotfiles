# Changelog

## 0.11.9

- **Aligned chat.** User messages and agent replies have two columns of padding on both sides, lining up with Lua output, `show()` blocks, and other chat entries.
- **Scoped selection.** Ctrl+A / Cmd+A selects the draft. Mouse drags stay within the draft or one message, excluding events, Lua tool blocks, and UI. Copying a message preserves real line breaks and indentation without adding visual wraps.

## 0.11.8

- **More open handlers.** `settings.open` keys can now be masks matched against the file name (`*.test.lua`, `.env*`), `*` for any file or folder without a better handler, `@dir` for folders, and `@url` for `http://`, `https://`, and `mailto:` links. A file uses its extension, then the most specific mask, then `*`; a folder uses `@dir`, then `*`. Other keys fail loading, and `/config` lists the new keys as written.

## 0.11.7

- **Boxed input padding.** The draft and status row now leave one blank column inside each side border, without widening the box.

## 0.11.6

- **Commands take arguments.** A `commands` entry is a function or `{ args?, desc?, run }`, like a prompt plus `desc`. `desc` shows in the `/` picker. Without `args`, `/mv a.txt "b c"` passes the typed words (quotes keep spaces) to `run(from, to)`; with `args`, one word from the list is accepted and the TUI opens a picker for it. JSON-RPC `commands.run` takes `argv`, and `commands.list` returns `{name, desc, args, params}` objects (**breaking** for clients that read names).
- **Pickers below the input.** Pickers, questions, and panels open under the input: under the box or rules with `lines` and `boxed`, and between the input and the status line, closed by a rule, with `fill` and `bar`. Every style keeps one empty row above the input.
- **New `bar` input style.** `settings.ui.input_style = "bar"` puts an accent `▌` before each input row, then a blank row and the status line.
- **Aligned columns in lists.** `/history` shows index, role, and text in columns, command and model lists align their descriptions, and the Models section of `/config` lines up its details.
- **Terminal redraw fix.** Output from another writer (such as a hook writing to `/dev/tty`) could leave stray text, scroll the screen, and duplicate the input. Frames are now written at once, line wrap is off while Tuse runs, and every row is repainted every five seconds.
- **The agent knows where to look.** The system prompt now tells it to answer questions about Tuse from `docs()` and how to change behavior or the UI through the Lua config. The config docs also cover name rules and color aliases, and a test keeps them complete.

## 0.11.5

- **Hooks never block a turn.** Hooks run fully in the background: a message, a reply, and a launch no longer wait for them, so the activity indicator no longer appears seconds after you press Enter. On quit, Tuse still waits for running hooks.
- **Three input styles.** `settings.ui.input_style` is now `boxed` (the new default), `lines` (the old `classic`, which still works as an alias), and `fill`, an input on a `border`-colored background with the status line below it. The boxed input has no left padding, so its text lines up with the status.
- **Project directory in the status.** When no indicator or notice is shown, the input shows the current directory in `muted`.
- **Lua syntax colors.** `theme.lua` has 15 tokens (`keyword`, `operator`, `function`, `parameter`, `field`, `escape`, and more). The highlighter now parses definitions, parameters, calls, methods, table keys, and standard functions, so `=` no longer looks like a function name.
- **User text color.** `theme.user` colors your messages and the input; `fg` stays for the agent's text.

## 0.11.4

- Boxed input drops the prompt arrow, grows with the draft like the classic input, and keeps one blank row above its status bar. Its status labels keep a three-column gap and are no longer clipped while they fit.

## 0.11.3

- The terminal draws the first streamed content without waiting for keyboard polling. Empty Lua previews no longer flash in the chat.
- The activity indicator distinguishes provider wait, streaming, and foreground Lua execution.
- Set `settings.ui.input_style = "boxed"` for a five-row composer with a built-in status bar.

## 0.11.2

- **Faster streaming.** Long replies no longer slow down while they stream: lists, code blocks, reasoning, and `lua` tool code re-render only their unfinished end, and file path checks for clickable links are cached. Up to 150x less work per frame on long replies.
- **Markdown images** (`![alt](path)`) render as a clickable link instead of the bare alt text.
- **Docs.** Fixed the `settings.open` example in Config, and documented `e.event` in hooks.

## 0.11.1

- **Fix: task notices wake the agent.** A background task that ends while the session is idle now starts a turn instead of waiting for your next message.
- **Input rule labels** (scroll mark, status, model) are no longer limited to half of the width.

## 0.11.0

- **Breaking: persistent session history.** SQLite is now the source of truth. New sessions are saved immediately; only started sessions appear in resume lists. Old database data is not migrated. Back up `~/.tuse/tuse.db` before upgrading and re-add your providers with `tuse connect`.
- **Breaking: history APIs.** `/history`, `settings.ui.hide_history`, `session().history`, and JSON-RPC `session.history` replace trace and raw records. Lua can edit history and session metadata with `set_session`; `set_title` and `config.set` were removed.
- **Breaking: hooks.** The new process and session lifecycle hooks run in the TUI and JSON mode, with smaller event payloads. See the Lua docs for the new names and fields.
- **Compaction is now opt-in Lua.** Built-in compaction and `compact_at` were removed. See `examples/compaction.lua` for a replacement.

## 0.10.5

- **Examples.** New `examples/` folder (skills, MCP, themes, rename, notifications, tmux, Zellij, cmux, Herdr, Orca, Rex, web search, sandbox, commands, open handlers, OpenSpec, project config) and a new `examples` docs topic that links them.
- **Esc stops everything.** Esc, the new `/stop`, and `turn.cancel` stop the turn, the running `lua` call (`[cancelled]`), background tasks, hooks, commands, and open prompts. Steering still hands the running call off to `/tasks`.
- **Task messages wait.** A task that finishes while the session is idle no longer starts a turn. Its message goes with your next message.
- **Prompts with args.** `prompts = { openspec = { args = { "propose", "apply" }, run = function(arg) ... end } }`. Pick `#openspec propose` in the TUI or send `"openspec propose"` over JSON-RPC. The model only sees what `run` returns.
- **Breaking: `open` moved to `settings.open`.** A top-level `open` key now fails with `open: moved to settings.open`.
- **New UI settings.** `settings.ui.hide_trace` hides trace roles in `/trace`, and `settings.ui.scope_models` limits `/models`.
- **Full trace.** The trace now also shows task, command, and `open` runs (with code), compaction, usage, model changes, turn ends, titles, `show()` blocks, and `pick`/`ask` answers.
- **TUI.** `/tasks` shows task details with its source and elapsed time. `/config` lists models and every setting. The chat no longer jumps to new output while you are scrolled up.

## 0.10.4

- **New docs.** Six pages in `docs/` (`usage`, `connect`, `config`, `lua`, `session`, `json`) plus the README. The agent reads the same pages with `docs("<topic>")`, and the site is built from them with mdBook (`make site`). Old `docs()` topics such as `functions`, `tool`, `commands`, and `hooks` are gone.
- **The prompt is shown in full.** `docs("lua")` and the site end with the exact system prompt and `lua` tool description. The prompt template moved into the code. A test keeps the docs and the prompt in sync.

## 0.10.3

- **Background Lua handoff.** Steering or pressing Esc during an agent Lua call moves the whole call to `/tasks`. The current shell process keeps running and later Lua statements still execute. Use `/tasks` to stop the task.
- **Async agent behavior.** The default prompt favors asynchronous work and tells agents to end the turn rather than poll. Task completion messages use `<task>` without renaming JSON-RPC events or history records. Live Lua calls show a star spinner.
- **Removed settings and Lua API.** Remove `settings.retries` and `settings.max_image_bytes` from older configs. Completion requests still retry up to five times, and Lua `read()` keeps its 5 MiB image limit. Use cooperative host calls or `spawn()` instead of the removed `sleep()` helper.

## 0.10.2

- **Breaking: removed all plugins.** Git and local plugins, `welcome`, and `tuse/default` (its palette and the `/subs` proxy integration) are gone. Remove `plugins` from existing Lua configs before updating; it is now an unknown key. Lua modules, hooks, custom commands, and theme overrides still work.
- **Installer.** Installs only the binary. There is no interactive setup or `--no-setup` flag, and existing config files are left untouched.
- **Terminal and file operations.** Simplified terminal rendering, editor navigation, and file operations.

## 0.10.1

- **Docs drive the prompt.** The agent's system prompt and the `docs()` topics are now built from `docs/` (`docs/system-prompt.md`), so the docs, the site, and the agent all read one source.
- **Internal refactor.** Clearer module boundaries in `core`, `tui`, `config`, `lua`, `api`, and `cli` (private fields, no module cycles, narrower public surface). No behavior changes.

## 0.10.0

- **Four API types.** Providers can use `openai-chat` (default; existing providers keep working), `openai-responses`, `anthropic-messages`, or `google-gemini`: `tuse connect --api TYPE`. Streaming, tool calls, reasoning replay, usage, and errors are handled per adapter; unsupported capabilities fail early with a clear message. New `tuse connect --replace`/`--key-stdin` and `tuse providers --json`.
- **Bundled `tuse/default` plugin.** `theme` gives a curated palette (your overrides still win); `subs` wraps CLIProxyAPI v8.1.2 as a loopback-only provider via `/subs`. Install, login, and proxy start are explicit opt-ins.
- **Breaking: configured `functions`.** `functions = { name = function(...) end }` (the `{ run, args, description, show_agent }` form is removed). They exist only in the agent's `lua` tool and are not listed in the prompt. Override built-ins (originals via `require("tuse")`) or disable them with `false`.
- **Plugins sync on reload.** `/reload`, `config.reload`, and `reload()` clone missing Git plugins and update moving refs; commit pins stay fixed, local changes are never overwritten, and a failed sync keeps the previous config. Startup stays offline.
- **UI history.** `show` blocks and answered `pick`/`ask` prompts are saved and restored on resume (TUI and JSON-RPC), outside the model context.
- **TUI.** Left/Right step through `/trace` entries; the working indicator is just spinner + time; `diff_line = 0` hides the whole diff block; links are `accent` and `fg` on hover.
- **Installer.** Interactive first-run setup offers `theme` and `subs` and creates `~/.config/tuse/init.lua` without touching existing configs; `CI`, `TUSE_NO_SETUP=1`, `--no-setup`, or no terminal install only the binary.
- **Docs.** `docs/` is now the full source of truth, with setup and plugin-authoring guides, published at https://ethanhamilthon.github.io/tuse/ with a landing page. README rewritten.

## 0.9.2

- **Breaking:** Removed `tuse plugins`. Manage plugin checkouts with Git in `~/.tuse/plugins` and declare them in `tuse.lua`; a missing checkout prints the `git clone` to run. Startup stays offline.
- **Breaking:** Renamed `show_markdown`, `show_picker`, and `show_question` to `show`, `pick`, and `ask`.
- **Breaking:** Dropped pre-0.9.0 migrations: `include`, `model`, `provider`, `effort`, `*.modes`, `process_start`/`process_end`, `TUSE_MODE`, price aliases `in`/`out`/`cache`, and grep `paths` now fail as unknown keys or are ignored.
- New Lua functions: `reload()` (same reload as `/reload`; deferred until a hook returns when called from one) and `llm(prompt, model, effort)` for tool-less requests. `llm()` cost is tracked as `$llm`; `session().usage.cost` is `$main + $llm` and `/session` shows both.
- `/new` and `/resume` are transactional: an invalid config or a locked session fails before the current session closes.
- A successful reload removes config helpers the new config dropped and updates the rest; agent globals stay. A failed reload changes nothing.
- CLI: every command handles `-h`/`--help` first and rejects unknown flags and extra arguments; `tuse models` accepts `-c/--config`.
- JSON-RPC: `initialize` rejects unsupported `protocolVersion` (omitted means 1); `config.set` is validated like `model.set` and deprecated; `model.list {cached: true}` reads without fetching; new `reloaded` event. Docs add a capability table and the `ui.cancel` contract.
- Config validation runs once through serde with full key paths (`models[2].prices.input: ...`); `{}` is an empty list on any list field.
- Token counts use one compact format (`200k`, `1.5m`) everywhere.
- `tuse update` verifies and unpacks releases in-process (no `sha256sum`/`tar`).

## 0.9.1

- Restored the Lua `models` list for model display names, context windows, prices, and compaction thresholds. Model metadata from the 0.9.0 database is no longer used; put it in the config. SQLite still remembers the selected model and effort.
- `tuse models` lists configured metadata and the saved default, without subcommands. JSON-RPC exposes metadata through `config.get` instead of `model.meta.*`.
- Link detection is limited to agent messages, agent/system/user trace details, `show_markdown`, `/config`, and `/session`. No links are parsed in Lua code, tool output, or diffs.

## 0.9.0

- **Single Lua session API (`require("tuse").session()`):**
  - Returns a fresh runtime snapshot with `mode`, `configpath`, `cwd`, `home`, `id`, `name`, `model`, `provider`, `effort`, `ctx`, `ctx_size`, `usage` (`input`, `output`, `cache_read`, `cache_write`, `cost`), `model_info` (including `prices`), `steps`, `turns`, and full untruncated `trace` (including resumed history), without exposing credentials.
  - Consistent pre-session semantics (`{mode, configpath, cwd, home}`, session fields `nil`) during initial config load and `/reload`.
  - Replaced `/usage` in the TUI with `/session`, displaying every field of `tuse.session()` except `trace`; `/trace` keeps full trace browsing. JSON-RPC adds `session.snapshot`.
  - **Breaking:** Removed `require("tuse").env` and old `TUSE_*` environment variables (`TUSE_MODE`, `TUSE_SESSION`, `TUSE_CWD`, `TUSE_MODEL`, `TUSE_CURRENT_CONFIG`, `TUSE_HOME`, `TUSE_GLOBAL_CONFIG`), including injection into `sh` and tasks. Only `THIS_PATH` (Lua-only) and `TUSE_RELEASE_URL` remain; ordinary process environment variables are untouched. See `docs/env.md` for migration.
- **Hooks overhaul:**
  - **Breaking:** Replaced `process_start` and `process_end` with `start` (`reason`, `is_new`, `restored`) and `close` (`reason`, keeping the session readable while `close` runs).
  - Hook payloads now carry only `event` and event-specific fields; callbacks call `tuse.session()` for session data.
  - Added `model_change`, `name_change`, `lua_start`, and `lua_end` (covering `tool`, `command`, `task`, and `open` jobs without recursion), and added `tool_calls` to `agent_message`.
  - Updated bundled `welcome` plugin to use `start` (`e.is_new`) and `tuse.session()` without inspecting lock files.
- **Interactive links, file paths, and `open` config:**
  - URLs, local file paths (absolute, `~/`, relative, optional `:line[:col]`), and Markdown links are clickable and highlighted on hover across chat, custom Markdown blocks, tool output, diffs, and panels (`/session`, `/config`, `/trace`, `/tasks`), including wrapped links.
  - Added `open = { ext = function(path) ... end }` for local file extensions (without the dot), keeping URL handling separate, falling back to the OS default opener (`open` / `xdg-open` / `cmd /C start`), and reporting open failures in the UI.
- **Model settings moved to SQLite:**
  - **Breaking:** Removed `model`, `provider`, `effort`, and `models` from `tuse.lua`; selection and model metadata now live in `~/.tuse/tuse.db` while saved sessions retain their own active selection on resume.
  - Added `tuse models [list|use|set|remove|import]` CLI and `model.meta.*` JSON-RPC methods (`tuse models import [PATH]` migrates legacy configs).
- **Strict config & plugin validation:**
  - User config and each plugin are validated before merging/applying at load and `/reload`, reporting unknown/removed keys, wrong types, invalid values, and malformed `hooks`, `commands`, or `open` handlers with source and full key path.
  - Failed `/reload` preserves the previous working config, modules, and callbacks.

## 0.8.6

- `@` picker: Tab completes a folder, Enter attaches the highlighted entry (a folder too) as a token. A folder reaches the model as `<dir path="...">` with its entries.
- `tuse init` creates `./tuse.lua` that starts from the global config.
- Steering shows a bouncing dot before `steering…`.

## 0.8.5

- `/config` starts with the path of the loaded config file. JSON-RPC `config.get` returns it as `path`.

## 0.8.4

- `/config` shows a **Plugins** section: each loaded plugin with its `ref`, commit (or `local`) and folder. JSON-RPC `config.get` returns them as `plugins`.

## 0.8.3

- **Plugins:** `plugins = { "owner/repo", { "owner/repo/sub/path", opts = {...}, ref = "v1" }, { "name", dir = "..." } }` loads `init.lua` (else `tuse.lua`) from GitHub clones in `~/.tuse/plugins` or local folders. A plugin returns a config table or `function(opts)`; tables merge under the user's config (lists concatenate, named entries must not collide between plugins, plugins cannot set `model`, `provider` or `effort`). Startup never touches the network.
- `tuse plugins [list | add NAME [--ref REF] | remove NAME | install | update [NAME] | clean] [-c PATH]`; `add` edits the config Tuse would load.
- `os.getenv("THIS_PATH")` returns the path of the calling Lua file.
- Bundled plugin `ethanhamilthon/tuse/plugins/welcome`: a startup banner with model, folder, git state and version.

## 0.8.2

- **Breaking:** Config files and Lua modules (including hooks, commands, and helpers defined in them) must import host functions with `require("tuse")`. Host functions remain globals in the agent's `lua` tool.
- `require("tuse").read(...)` can read files while the startup config loads.

## 0.8.1

- The mouse wheel scrolls the chat, panel, or picker under the pointer. PageUp/PageDown scroll chat history even when a panel is open; hold Shift to page through the panel.
- Lua question and picker results start with an accent-colored `?`. Pinned and unpinned `show_markdown` blocks start with `◆`.
- End-of-turn timing and model summaries use the `muted` theme color.

## 0.8.0

- **Lua UI:** Added `show_markdown(name, text, pin)`, `show_picker(options)`, and `show_question(text)`.
  - `show_markdown` renders/updates named Markdown blocks (`pin = true` keeps them together at the end of the chat after new messages; `show_markdown(name, "", false)` removes a block).
  - `show_picker` reuses the `/models` picker layout with the input editor disabled (including search) and restores the previous draft on Enter/Esc.
  - `show_question` renders a Markdown panel in the picker slot and uses the editor separately from the previous draft without submitting to the model.
  - Submitted choices/answers leave UI-only chat entries (cancelled prompts leave none); all live UI entries and `show_markdown` blocks survive `/reload` (with pin state) and are excluded from model history and session resume.
  - Picker and question requests share one FIFO queue, pause the calling Lua coroutine's timeout while waiting, keep both front ends and other Lua jobs responsive, never deadlock `/reload` on interactive hooks, and clear pending requests on session close.
- **Custom slash commands:** Added `commands = { name = function() ... end }` in Lua config. Custom `/name` commands appear in `/` autocomplete, update on `/reload`, run as non-blocking Lua jobs, and cannot override built-in commands.
- **Breaking (Lua file helpers):** `read(path)` now returns raw text by default (without line numbers or pagination notes); use `read(path, {lines = true, offset = 1, limit = 2000})` for numbered, paginated lines. Added `append(path, text)` and `delete(path)` (single file only) with diff reporting, extended `grep` for multiple paths and `literal = true` search, and updated the `lua` tool description to prefer file helpers and `sh([=[…]=])`.
- **Trace and config views:** `/trace` now opens a selectable list (`index  role  first line`) whose Enter detail panel renders `system`/`user`/`agent` as Markdown, `lua` as full syntax-highlighted source without preview limits, and other roles as plain text, with Esc returning to the selected row. `/config` now shows a styled, scrollable sectioned view without provider secrets or Lua function bodies while JSON-RPC `config.get` stays structured.
- **TUI and JSON-RPC feature parity:** Added `session.new`, `session.resume`, `commands.list`, `commands.run`, `ui.state`, `ui.reply`, and `ui.cancel` methods, `prompts` support on `turn.submit`, single-call `model.set` validation and persistence, and `ui_markdown`/`ui_request`/`ui_clear`/`ui_result` events. Verified cross-front-end session resume in both directions (JSON-RPC ↔ TUI) sharing the same store and lock.

## 0.7.5

- **Breaking:** Removed config `include`. Use `require(...)` directly (for example `require("global")` in a project `tuse.lua`); configs that still return an `include` key fail with a clear error.
- `require` now resolves relative module names against the file that calls `require` (falling back to the working directory for inline code in the `lua` tool). File modules are cached by canonical path, and cyclic `require` calls raise an error.
- **Breaking:** Global config lookup now checks only `$TUSE_GLOBAL_CONFIG`, `~/.config/tuse.lua`, and `~/.config/tuse/init.lua` (`~/.config/tuse/main.lua` is no longer read as an entry; only `./tuse.lua` is looked up in the working directory).
- Removed the default 1-column left padding on user messages in the TUI.

## 0.7.4

- Tuse no longer keeps running at 100% CPU after its terminal is closed. If the UI does not stop within 2 seconds of a hangup, or after the terminal goes away, Tuse closes the session (with `process_end` hooks) and exits.
- `sh` runs commands in their own session, without a controlling terminal. An interactive shell such as `zsh -ic` can no longer take the terminal and leave Tuse suspended (`suspended (tty input)`) with mouse codes printed in the shell.
- `require("tuse")` gives the host functions (`sh`, `read`, `write`, `edit`, `grep`, `spawn`, ...) and `env`: `require("tuse").env.TUSE_MODE` reads any variable, with Tuse's own ones (`TUSE_MODE`, `TUSE_CWD`, `TUSE_GLOBAL_CONFIG`, ...).
- **Breaking:** `TUSE_MODE` is no longer a Lua global; use `os.getenv("TUSE_MODE")` or `require("tuse").env.TUSE_MODE`. Reading the old global raises an error that says so.
- `require` finds more: `require("name")` loads `./name.lua` or `./name/init.lua`; `require("global")` the global config; `require("~/path")` `~/path.lua` or `~/path/init.lua`; `require("~/path/file.lua")` that file. `/reload` loads changed modules again.
- The global config is `$TUSE_GLOBAL_CONFIG` (a file or a module path), else `~/.config/tuse.lua`, else `~/.config/tuse/init.lua`. `~/.config/tuse/main.lua` still works.
- Files, prompts and images picked into the input are drawn in `accent`; typed `#name` and `@path` stay plain until Enter picks them.
- Lists and panels (`/models`, `/trace`, `/config`, `/usage`, `/resume`, tasks) have no title line, like `Model 3/12`.
- Release scripts are inlined into the workflow; `release/main.lua` is no longer shipped.

## 0.7.3

- Simplified the TUI: one `lines` input design, a scrollable `/trace` log, substring search and normal `@dir/name` paths. Removed `/childrens` and child-session tracking.
- Added `include = { os.getenv("TUSE_GLOBAL_CONFIG") }` for sharing Lua config across projects. `require` looks in the session's working directory. Use `TUSE_MODE` (`tui` or `json`) instead of per-entry `modes`.
- `tuse connect` is non-interactive: `--base URL --key '$ENV' --name NAME`. The installer no longer prompts or edits your config. Removed `tuse reset`.
- Existing SQLite history and providers still work. Use 0.7.2 to import pre-SQLite `session.jsonl` history before updating.
- Faster CI: no duplicate release builds, pinned Rust, and native smoke tests for the four release targets. Linux archives require glibc 2.35 or newer; macOS archives target macOS 11 or newer.

## 0.7.2

- New default theme colors (from the author's Ghostty palette): `bg` `#121212`, `fg` `#DEDEDE`, `accent` `#BDDEAB`, `ok` `#94B979`, `err` `#E27373`, `info` `#97BEDC`, and greys for `surface`, `dim`, `muted`, `border`.
- `@` takes absolute paths: `@/etc/` and `@~/` list those folders as you type, and the picked file is attached from there.
- The status bars are colored by part: spinner, time and the used context (`x` of `x/y`) are `accent`; the action, model, effort, `/y`, cost and `steering…` are `muted`. Flash notices stay `accent`.
- Each status label takes at most half the input width and is cut with `…`.
- Tool output is `muted`; `…` and `… N more lines` under code, output and diffs are `border`.
- The `fill` input is a straight `surface` block (no half-block edges and notched corners). `fill` and `bar` have no `›`, and user messages in the chat are a `surface` block without `›`.
- A wrong `settings.ui.input_design` now names the allowed values in the error.

## 0.7.1

- The `lua` tool is `lua(code)`: `title` and `timeout` are gone. A call is stopped after 120 seconds; `settings.tool_timeout` is removed.
- The working indicator shows what the agent is doing (`reading PATH...`, `writing PATH...`, `editing PATH...`, `searching PATTERN...`, `running CMD...`) instead of a title. Each action stays at least 100 ms.
- Inactive list items use `muted` instead of `border`.
- The working animation and `settings.ui.motion` are removed.
- Hooks have no time limit: `settings.hook_timeout` is removed. Tuse still waits for `process_end` until its runs end.
- The config has one theme, `theme = {...}`, and the UI cannot switch it: `/theme`, `settings.theme`, `themes` and `extend` are removed. `/models` still remembers the model and effort in the database (`config.set` takes `model` or `effort`).
- `/maxsize` is removed: the maximum context shown in the status is the model's `window`.

## 0.7.0

- The agent's tool is `lua(code, title, timeout)`: Lua 5.4 (mlua) instead of Python (Monty). The model picks the timeout of each call, with no upper limit; `settings.tool_timeout` is the default.
- Nothing is cut: tool output, `sh().out` and task logs are kept whole. `settings.max_output` is gone.
- One VM per session runs the config, the agent's code, hooks and tasks as coroutines. `sh`, `sleep` and waits yield, so hooks and tasks keep running while a call waits.
- `spawn(fn, name)` runs a function as a background task in the same VM. `task_run`, `task_add` and process tasks are gone; `sh` kills its process at the timeout instead of handing it over.
- The config is `tuse.lua` / `~/.config/tuse/main.lua`, returning a table. Hooks and helpers are Lua functions; `include`, `$VAR` and `#{{cmd}}` give way to `require`, `os.getenv` and `io.popen`. `/reload` runs the file again in the same VM and keeps the agent's globals.
- Sessions, providers and the last picked model, effort and theme live in SQLite (`~/.tuse/tuse.db`). Old `session.jsonl` sessions move in on the first start. `tuse connect` saves providers there; `tuse providers` and `tuse disconnect NAME` are new.
- Removed: `ask`, `draw_ui`, the `ask` hook event, headless mode (`tuse -p`), and model calls of functions as separate tools.

## 0.6.5

- Config includes accept `only` to import selected top-level keys from a file.
- Hooks, functions, connections, system texts, prompts and includes accept per-entry `modes` (`tui`, `headless`, `json`). Model availability follows the active connections.
- `draw_ui(..., pin=True)` keeps a new block at the bottom of the chat. `draw_ui("", id=...)` removes a block, and redraws and removals preserve the scroll position where possible.
- `/childrens` shows the tree of sessions linked by `TUSE_PARENT`, with token usage, spend and a detail panel.
- `/childrens` stops counting elapsed time when a child session finishes.
- The `agent_message` hook receives `tasks` and `children`, listing only running background tasks and descendant sessions.

## 0.6.4

- `draw_ui` accepts ANSI SGR styling (bold, dim, italic, underline, 16 colors mapped to the theme, 256 and truecolor). Other escape sequences are dropped.
- Links are clickable: hover highlights them and a left click opens them (`open` / `xdg-open`). This covers Markdown links, bare `https://` URLs and OSC 8 hyperlinks in `draw_ui`; only `http`, `https` and `mailto` open.
- Functions in the config accept `show_agent: false`: the agent is not told about the helper, but other functions, hooks and tasks can still call it.
- The `python` tool no longer has a `timeout` argument. A call is stopped after `settings.tool_timeout`; the system prompt tells the agent to run long jobs with `task_run`.

## 0.6.3

- The input status shows context use as `used/max` (`5.2k/1m`) instead of `tok` or a percentage. `/maxsize 200k` sets the maximum, `/maxsize off` returns to the model's window, and without any it shows `5.2k/?`.
- Tool call headers show elapsed time in milliseconds under one second (`302ms/10s`).
- `draw_ui` blocks are drawn in the `accent` color.
- Fix: a question that arrived while another picker (`/tasks`, `/resume`, ...) was open stayed hidden after it closed; it now appears.
- The system prompt has a `Rules` section: prefer short multi-step scripts over one huge call.

## 0.6.2

- Tool call titles use `dim`, elapsed/timeout uses `accent`, and output and diff paths use `border`. Terminal tab OSC sequences have been removed.
- Hooks share the agent host API, can adopt shell tasks and respond to cancellation. Hook questions expire at the hook deadline, and old queues cannot survive a configuration reload.
- Added subsets of `glob`, `shlex` and `shutil`. The remaining Monty limitations are documented in `docs/tool.md`.

## 0.6.1

- Configure `events: [ask]` to run a hook when the main agent needs an answer in the TUI or JSON client. Hooks receive the question, options and ask ID, not the answer.
- The TUI wraps multiline questions above the options and keeps the question visible while writing a custom answer. Page Up and Page Down scroll longer questions.
- Python tool titles appear above their code in live and restored chat. `tool_line: 0` hides the title and code without hiding the result.
- Background task notifications no longer add TUI chat entries. They remain available in `/trace`, session records, the agent context and JSON-RPC.

## 0.6.0

- Picked `#prompts`, `@files` and `[Image #N]` stay as typed in the chat, title and hooks. The model receives their context separately; `/trace` shows it. Text attachments are capped at 1 KiB. Tokens typed by hand stay literal. See `docs("prompts")`.
- Search modal pickers in the input field with normal editing keys. Closing a picker restores the draft. `/models` keeps the filter across refreshes and no longer duplicates unnamed models’ IDs.
- Pickers and panels use the main background; selection uses the accent foreground, inactive rows the border color.
- Tool output fits the configured byte limit, including its omission marker. `/reload` updates the live interpreter’s budget.
- Early session events are buffered for the first subscriber; JSON clients receive the initialize response before startup notices.

- A crashed interpreter (a Monty panic) is recreated: the agent's next `python` call starts a clean one (the failed call says variables and imports are lost), hooks get a fresh one, and a crashed REPL task ends as `exited` instead of staying `idle`.
- Fix the tab state (OSC 9;4) disappearing on long turns and `ask` waits: it is re-sent every 5s while working or asking. Error and paused now send 100% so terminals draw a visible bar. Turning off `settings.ui.tab_status` with `/reload` restores the title and clears the state.
- **Fix**: the TUI now resets the terminal (mouse modes, bracketed paste, alt-screen, raw mode) when it exits on SIGINT, SIGTERM or SIGHUP, and on any early return. Before, mouse events leaked into the shell as `18M65;25;18M64;...`. SIGKILL cannot be handled; run `reset` if it happens.

## 0.5.4

Breaking: hook events and `run:` expansion changed, OSC 7501 was replaced (see below).

- **Hooks have four events**: `process_start` and `process_end` (`reason`: `launch`, `new`, `resume`, `reload`, `exit`), `user_message` (`text`, `is_first`) and `agent_message` (`text`, `status`: `working`, `finished`, `cancelled`). `session_start`, `session_end`, `turn_start`, `turn_end`, `tool_start`, `tool_end` and `error` are removed without aliases, as are the `tool`, `input`, `title`, `output`, `code`, `error` and `cancelled` variables; a hook with an unknown event shows a notice. `/reload`, `/new` and `/resume` now run `process_end` and `process_start`.
- **`tuse json`**: a JSON-RPC 2.0 session over stdin/stdout (NDJSON) with the TUI's full access: submit, cancel, withdraw, answer asks, model, config, tasks, trace and stats; every session event arrives as an `event` notification. See `docs("json")`.
- `/trace` lists hook runs (`hook` items with the event, its variables, the result and the duration); they are saved with the session and never sent to the model.
- `/trace` query filters by type: `+python+agent` keeps those types, `-hook` hides one, other words search the rows.
- **OSC 7501 is replaced by standard sequences**: the tab title (OSC 2, `tuse · <session title>`) and the tab state (OSC 9;4: working, a question, an error). `settings.ui.osc_status` is renamed `settings.ui.tab_status`; the old key is ignored. The previous title is restored on exit.
- **`$VAR` and `#{{cmd}}` are no longer expanded in `hooks.*.run` and `functions.*.run`**, so `$` in Python code (f-strings, templates) stays as written. Use `os.environ` or `sh` there.
- A built-in function called as a tool of its own (`ask`, `grep`, `sh`...) now runs as `python` code `name(**args)` instead of failing with "unknown tool".
- A new session creates its folder in `~/.tuse` with the first message; sessions closed before it leave nothing. Tests no longer write to `~/.tuse`.
- An unknown `effort` in the config shows a notice with the valid values (it still falls back to `default`).
- Compaction is on by default: without `compact_at`, it starts at 60% of the model's `window` from `models:`. `compact_at: 0` turns it off.
- Headless mode (`tuse -p`): the system prompt tells the agent there is no user, and `ask`/`draw_ui` raise a clear `RuntimeError`. New `docs("headless")` page; `-c/--config` and `-r/--resume` are documented.
- Faster status line on long sessions: usage totals are kept up to date instead of being recomputed from the whole history on every frame.
- Streaming long replies no longer re-renders the whole Markdown on every frame: finished blocks are cached and only the last one is parsed again (a 30 KB reply: 497 ms → 68 ms of rendering in total). Reasoning wraps only the lines it shows.
- Resize, `/theme` and `/reload` render only the messages on screen, from the bottom up (4000 messages, 20 resizes: 263 ms → 1.5 ms). `/reload` no longer copies the history.
- Fixed: a notice or a hook record between the tool results of one step no longer splits them with the images message.
- Fixed: assistant text that had already streamed was shown twice when a tool call started in the same step.

## 0.5.3

- Each hook processes events in order in a persistent interpreter. Hooks receive turn context and can set the session title. Configured Python helpers are available to the agent, tasks and hooks.
- Full-screen status is reported via OSC 7501 (disable with `settings.ui.osc_status`). Short notices appear in the status row; the turn footer shows elapsed time and model/effort.
- Russian-layout shortcuts work in supported terminals. Pasted images have compact labels; their paths expand on send.
- Markdown tables wrap within columns or switch to records on narrow screens. The README now includes benchmark results and is available through `docs("README.md")`.

- Tool code now streams into the chat, with the title shown as soon as it arrives.
- Removed `prelude`; import a `.py` file from the config folder or use a hook instead.
- Removed the `VERSION` file; the version now comes only from `Cargo.toml`.

## 0.5.2

- Inspect the effective YAML with `/config`. Expanded credentials are visible. Slash commands now work mid-draft without clearing surrounding text.
- Drag to select and copy chat or panel text. In the editor, use Shift+movement to select, Ctrl/Cmd+A to select all, and Ctrl/Cmd+X to cut.
- Custom `ask` answers use the multiline editor and restore the original draft. Task notifications appear separately from user messages.
- Rename Python `show()` to `draw_ui()` (no alias). The built-in prompt no longer injects environment details or `AGENTS.md`; use `systems` for project instructions.

## 0.5.1

- **Topic-based `docs(topic=None)`.** Split `docs/` into 7 focused topic files (`tool`,
  `functions`, `commands`, `env`, `config`, `hooks`, `theme`), each under 4 KB. `docs()` lists
  available topics; `docs("<topic>")` returns that section; unknown topics return an error message
  with the topic list.
- **Reuse HTTP connection pool.** `Session` keeps a shared `ureq::Agent` across steps via
  `Client::with_agent`, enabling HTTP keep-alive and TLS session reuse.
- **Lower Python thread stack.** Reduced the per-call Python interpreter thread stack from 128 MB
  to 16 MB.
- **TUI rendering & event loop optimizations.** Visible-window chat slicing (`Chat::window`) avoids
  cloning off-screen history; streaming redraws throttle to `FRAME_MS`; line-level screen diff and
  minimal ANSI style transitions skip unchanged rows and redundant resets; event loop caches
  terminal size via `Resize` events and ignores unhandled mouse/focus events.
- **Theme cache invalidation.** `/theme` now invalidates the chat and panel render caches so
  existing messages immediately switch to the new palette.
- **Persistent working indicator `title`.** The active tool `title` stays visible in the working
  indicator until a new `title` arrives (or the turn ends).
- **`tuse update` version output.** Prints `old -> new` (e.g. `0.5.1 -> 0.5.2`) after updating.
- **`/trace` highlighting.** Opened `user`, `agent` and `system` trace items render with Markdown
  highlighting; `python` items render with syntax highlighting matching the chat.
- **`settings.ui.fold_strings` (default `true`).** Folds multiline triple-quoted Python strings in
  chat tool calls to a single line (`"""first line…"""`), while `/trace` shows the full code.

## 0.5.0

Breaking config change: simplified UI configuration.

- **10-color themes + `settings.ui`.** Replaced the 92-token `Theme` with 10 base colors
  (`bg`, `surface`, `fg`, `dim`, `muted`, `border`, `accent`, `ok`, `err`, `info`) with `extend`
  support. Behavior and layout preferences (`input_design`, `motion`, `tool_line`, `diff_line`,
  `output_line`, `reasoning_line`, `scroll_step`, `pad_x`, `message_gap`, `list_max_height`,
  `input_max_height`) moved to `settings.ui` so `/theme` does not overwrite them. Symbols,
  prefixes, status labels and internal constants moved into code.
- **Working indicator shows only tool `title`.** Removed `Host::status` (`reading ...`,
  `writing ...`, `asking user...`, etc.). While the model thinks, the indicator shows only the
  spinner and elapsed time; during a tool call it shows the call's `title` (and `steering…` when a
  queued message waits).
- **`/trace` navigation.** `Left` and `Right` step through opened `/trace` items (with full
  `Trace N/total role` title) when the input is empty. Both the `/trace` list and opened items
  clamp at the start and end instead of wrapping.
- **Styled `/usage` panel.** Multi-color layout using the 10-color palette (`border` keys, `dim`
  labels and session ID, `fg` model and counts, `info` effort and window, bold `accent` context
  size, bold `ok` cost) and no duplicate model name when `display == model`.

## 0.4.1 - 2026-11-19

One tool, a built-in system prompt, one look for every list. **Breaking** for hooks and configs;
read the notes at the end.

- **One tool: `python`.** `read`, `write` and `edit` are functions inside it, next to the new
  `grep(pattern, path, glob, ignore_case, context, limit)` (a regex search that respects
  `.gitignore`). Errors are Python exceptions (`ValueError`, `FileNotFoundError`, ...). The files a
  call changed are shown as a diff at the end of the call (a change at the end of a long line stays
  visible); the model gets a short confirmation. `read` stops at `max_output` and says which
  `offset` continues.
- **`title` and a status in the working indicator.** Every `python` call has a `title`. The
  indicator shows `thinking...` at the start of a turn, then the title, `reading PATH`,
  `writing PATH`, `editing PATH`, `searching PATTERN`, `running CMD`, `asking user...` or
  `reading docs...`; the last status stays until a new one comes. The call counter left the
  indicator (it stays in `/usage`). Texts are theme tokens (`thinking_label`, `read_label`, ...).
- **`sh` does not die at its timeout.** A command still running at its own timeout or the call's
  goes on as a background process task; `.task` is its ID, `.out` has what it printed so far.
- **`task_run(code)` runs Python.** A task is a background REPL (new interpreter, same functions,
  no access to your variables) that stays alive and `idle`. `task_add(id, code)` queues more code in
  it. `task_get` and `task_list` show `.kind`, `.code`, `.status`, `.exit` and `.queue`. The agent
  gets a message each time a REPL goes idle.
- **`ask` always blocks** (no `wait`) and the call's timeout does not run while the user thinks.
  The user can always write their own answer: typing is the answer, Enter without text takes the
  selected option. To ask without waiting, call it from a task.
- **One look for every list.** `/models`, `/resume`, `/theme`, `/tasks`, `/trace`, `ask` and the
  `/`, `#` and `@` pickers share the `/trace` design (a rule, a title with the position, rows),
  drawn over the bottom of the chat. `/trace` filters too. Tokens: `list_*` replace `picker_*`
  and `panel_*`.
- **Python is highlighted** in tool calls and in ```` ```python ```` blocks (`syntax_*` tokens).
- **Mouse.** The wheel scrolls the chat (or the open list); a click in the input puts the cursor
  there. The arrows only move in the input. Select text with Shift (Option in iTerm2 and
  Terminal.app) while the mouse is captured.
- **The system prompt is built in** (`crates/core/prompts/system.md`) and tells the agent the
  real `max_output` and `tool_timeout`. The `systems` of your config come after it. `default.yaml`
  is gone; `tuse update` only replaces the binary.
- **New defaults.** `max_output` 4096, `tool_timeout` 10, `input_max_height` -1 (no limit),
  `tool_line` -1, `output_line` 1, `reasoning_line` -1, `pad_x`, `input_pad_x` and `list_pad_x`
  0, `tool_prefix` `* `, `notice_prefix` `✓ `, spinner `◐ ◓ ◑ ◒`.
- The chat no longer prints `Model ..., effort ...` and `Theme ...` after `/models` and `/theme`.

Notes for an existing install:

- Run `tuse update`, then delete `include: [default.yaml]` from `~/.config/tuse/main.yaml` (or
  run `tuse reset`). Until then `default.yaml` is an empty file, so nothing breaks.
- Removed with no replacement: the old names `max_bash_output`, `bash_timeout`, `bash_line`, the
  top-level `theme` (use `settings.theme`), `bins`, the `wait` argument of `ask`, and `task_run`
  of a shell command (use `task_run('sh("cmd")')`). Sessions written before 0.4 are not shown
  with a tool name.
- Hooks: `tool` is always `python`, `input` is its code, `title` is new. A hook that looked for
  `tool == "edit"` has to look at the code instead.
- `Record::Tool` has `title` and `diffs`; a session written by 0.4.0 still opens.
- The theme tokens `picker_*`, `panel_*` and the two `*_max_height` of lists are renamed; use `list_fg`, `list_bg`, `list_title`, `list_selected_fg`, `list_selected_bg`,
  `list_detail`, `list_selected_prefix`, `list_pad_x`, `list_max_height`.
