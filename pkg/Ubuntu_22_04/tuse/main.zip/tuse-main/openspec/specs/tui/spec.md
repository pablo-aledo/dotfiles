# tui

## Purpose
Terminal UI behavior.

## Requirements

1

### Requirement: Task details
Enter on a task in `/tasks` SHALL open a panel with id, name, status, started, ended, elapsed time (live while running), the source of the task's function, and the last 200 log lines. When the source is unknown it shows `(source unavailable)`. `task_get`, `tasks.list`, and `tasks.get` SHALL include `code`.

#### Scenario: Running task
- **WHEN** the agent ran `spawn(function() sh("sleep 60") end, "nap")` and the user presses Enter on it
- **THEN** the panel shows `nap`, `running`, the elapsed time, and `function() sh("sleep 60") end`

### Requirement: Prompt arg input
Picking a prompt with `args` in the `#` picker SHALL insert the prompt atom and open a picker of its `args`. A space typed right after such an atom SHALL reopen that picker, filtered by the typed text. The chosen arg joins the atom, as `#openspec propose`. Esc leaves the atom without an arg. The prompt name and its arg SHALL be drawn in the accent color.

#### Scenario: Pick an arg
- **WHEN** the user picks `#openspec`, then `propose`
- **THEN** the input holds one atom `#openspec propose` in the accent color

#### Scenario: Type an arg
- **WHEN** after the `#openspec` atom the user types ` pro` and presses Enter
- **THEN** the atom becomes `#openspec propose`

### Requirement: Stop command
`/stop` SHALL be a built-in command that stops everything, the same as Esc, and works when the session is idle. `stop` is a reserved command name.

#### Scenario: Idle stop
- **WHEN** no turn runs, two tasks run, and the user types `/stop`
- **THEN** both tasks are `stopped`

### Requirement: Chat scroll follows only at the bottom
The chat SHALL stick to the newest content only while the view is at the bottom. When the user has scrolled up, new messages, streamed text, tool output, and resizes MUST NOT move the visible lines. Scrolling back to the bottom (wheel, `PageDown`, or sending a message) SHALL turn following back on.

#### Scenario: At the bottom
- **WHEN** the view is at the bottom and the agent streams text
- **THEN** the view keeps showing the newest line

#### Scenario: Scrolled up
- **WHEN** the user scrolled up and new messages arrive
- **THEN** the same lines stay on screen

#### Scenario: Back to the bottom
- **WHEN** the user scrolls down to the end
- **THEN** new content is followed again

### Requirement: History command
`/history` SHALL list the session history from the database, minus roles in `hide_history`; `flash` entries are listed like any other role. `trace` is no longer a built-in command and `history` is a reserved command name. JSON-RPC `session.trace` and `session.records` are replaced by `session.history`, which returns the same structured records as `session().history`, and `session.list` returns only started sessions.

#### Scenario: Open history
- **WHEN** the user types `/history`
- **THEN** a list of every history record opens, starting with `system`

#### Scenario: Old command
- **WHEN** the user types `/trace`
- **THEN** it is an unknown command

#### Scenario: Old method
- **WHEN** a client calls `session.trace` or `session.records`
- **THEN** it gets a method-not-found error

### Requirement: Resume lists started sessions
The `/resume` picker SHALL list only sessions of the current directory with `started = true`, newest first.

#### Scenario: Unstarted session
- **WHEN** a session was opened and closed without a message
- **THEN** `/resume` does not list it

### Requirement: TUI and JSON-RPC parity
The TUI and JSON-RPC SHALL offer the same features, one to one: sending, withdrawing, and stopping input (`turn.*`), the session panel and history (`session.snapshot`, `session.history`), new and resume (`session.new`, `session.list`, `session.resume`), models (`model.get`, `model.set`, `model.list`), config view and reload (`config.get`, `config.reload`), tasks (`tasks.*`), commands (`commands.*`), `pick`/`ask`/`show` (`ui.*`), and quit (`shutdown`). Neither SHALL have a way to edit history directly; `set_session` is a Lua host function only, reachable from both through commands, hooks, and agent `lua` calls.

#### Scenario: Edit through a command
- **WHEN** a config command calls `set_session{ history = ... }` and it is run with `/name` in the TUI or `commands.run` over JSON-RPC
- **THEN** both change the history the same way

#### Scenario: No direct write
- **WHEN** a client calls `session.set`
- **THEN** it gets a method-not-found error

#### Scenario: config.set removed
- **WHEN** a client calls `config.set`
- **THEN** it gets a method-not-found error; `model.set` covers model and effort

### Requirement: Streaming renders incrementally
While a reply, reasoning, or `lua` tool call streams, the TUI SHALL re-render only the unfinished tail and reuse the lines of the finished part. The streamed view MUST equal a full render of the same text at every point. Once the reply ends, the entry SHALL be rendered once in full.

#### Scenario: Long list or code block
- **WHEN** the agent streams a long list, a long fenced code block, or long tool code
- **THEN** each frame renders only the last item or the last code lines, and the output matches a full render

#### Scenario: Path probes
- **WHEN** streamed text mentions file paths
- **THEN** each path is checked on disk at most once per second

### Requirement: Markdown images
A Markdown image `![alt](target)` SHALL render as a link to `target` with `alt` as its text, or with `target` as its text when `alt` is empty.

#### Scenario: Image in a reply
- **WHEN** a reply contains `![Photo](/tmp/a.png)`
- **THEN** the chat shows `Photo` as a clickable link that opens `/tmp/a.png`

### Requirement: Lua syntax highlighting
Lua code in tool calls, panels, and `lua` code blocks SHALL be colored by the `theme.lua` tokens using the code's structure. Function definition and call names SHALL be `function`, names after `:` SHALL be `method`, names after `.` and table keys SHALL be `field`, names in a function's parameter list and their uses inside that function SHALL be `parameter`, standard library and Tuse functions SHALL be `builtin`, and other names SHALL be `variable`. `local` and `function` SHALL be `storage`; `nil`, `true`, and `false` SHALL be `constant`; `and`, `or`, `not`, and symbol operators SHALL be `operator`; brackets, `,`, `;`, `.`, and `:` SHALL be `punctuation`; escapes inside strings SHALL be `escape`. Long strings and long comments SHALL continue across lines.

#### Scenario: Assignment and calls
- **WHEN** the code is `x = read("a"):upper() .. y`
- **THEN** `=` and `..` are `operator`, `read` is `builtin`, `upper` is `method`, and `x` and `y` are `variable`

#### Scenario: Parameters and table keys
- **WHEN** the code defines `function M.go(self, n) return n end` and a table `{ run = function() local y = 1 end }`
- **THEN** `go` is `function`, `self` and both `n` are `parameter`, `run` is `field`, and `y` is `variable`

### Requirement: User message color
User messages and the input text SHALL use `theme.user`; agent text SHALL use `fg`.

#### Scenario: Different colors
- **WHEN** `theme.user` differs from `theme.fg`
- **THEN** a user message and the draft in the input differ in color from an agent reply

### Requirement: Wake the TUI on streaming updates
The TUI SHALL wake when session events arrive, without waiting for terminal input or a periodic poll. The first displayable streaming update of each model attempt MUST be drawn at the next render opportunity, without waiting for a frame-rate timer, a later delta, or the final reply. Later updates MAY share a frame, but the last pending update MUST be drawn even if the stream pauses. Stream processing MUST preserve event order and leave opportunities to handle terminal input.

#### Scenario: First delta in an idle terminal
- **WHEN** a provider sends one displayable delta, then holds the connection open without sending another event, and the user does not press a key
- **THEN** the TUI draws the delta without waiting for the frame pacing deadline or the response to finish

#### Scenario: Burst followed by a pause
- **WHEN** many deltas arrive, the user presses a key, and then the provider pauses
- **THEN** the TUI handles input during the burst and renders the accumulated content in order, including the last delta, without waiting for another event

### Requirement: Show the foreground activity in the composer
Both input styles SHALL distinguish provider wait with the existing spinner, foreground Lua execution with the Lua block's animated star, and model streaming with a fixed-width dot that pulses through progressively larger and smaller glyphs. The elapsed timer SHALL remain available with the activity. Streaming SHALL begin at the first displayable text, reasoning, or Lua code update; empty announcements alone MUST NOT activate the pulse or the Lua execution star. A pause between chunks MUST NOT switch the indicator back to waiting. Activity changes MUST NOT insert rows into the chat. The TUI SHALL preserve steering and retry notices and MUST NOT keep showing an old retry notice over a new attempt. Ending, stopping, or switching sessions MUST clear stale activity.

#### Scenario: Wait, stream, run Lua
- **WHEN** the model request is sent, the provider announces a tool without code, then sends displayable code, and the foreground Lua function starts after the reply
- **THEN** the spinner remains through the empty announcement, the dot pulses while code streams, and the indicator changes to a star only when Lua executes

#### Scenario: Reasoning and text arrive intermittently
- **WHEN** displayable reasoning or reply text arrives and the provider pauses mid-response
- **THEN** the pulse begins with the first displayed content and continues through the pause without changing the composer height

#### Scenario: Retry and stop
- **WHEN** a partial response is retried and the new attempt is then stopped
- **THEN** the retry notice replaces stale activity during the wait for retry, the provider spinner returns for the new attempt, and stopping clears its indicator

### Requirement: Show the Lua preview only with code
The TUI MUST NOT reserve a chat row or show an inline Lua star for a tool announcement or whitespace-only code. The inline star and the first displayable Lua code MUST appear together in the same frame, whether the code first arrives in a delta or at tool start. A hidden preview discarded on reset, cancellation, or session switch MUST NOT flash on screen.

#### Scenario: Metadata and whitespace arrive before code
- **WHEN** the provider announces a Lua call, sends whitespace-only code, and then sends its first displayable code chunk
- **THEN** the announcement and whitespace create no chat row, gap, or star, and the inline star first appears beside code in the same frame

#### Scenario: No displayable code streams
- **WHEN** a Lua call has no displayable streaming delta but its tool start carries displayable code
- **THEN** the TUI shows the inline star and code together at tool start, without a prior placeholder

#### Scenario: Reset before code arrives
- **WHEN** the attempt is reset before a pending Lua preview gets displayable code
- **THEN** the pending preview is discarded without ever appearing in chat

### Requirement: Boxed input composer
When `settings.ui.input_style` is `boxed` and the viewport fits, the composer SHALL consist of a top border, the editor rows, one blank row, a status row, and a bottom border. Editor rows SHALL have no prompt arrow. Every editor row and the status row SHALL reserve exactly one blank display column immediately inside each side border. The padding SHALL be inside the existing frame width and separate from the outer `pad_x` margin. The editor SHALL use the remaining content width for wrapping, cursor placement, mouse hit testing, and selection. It SHALL grow with the draft, limited by `input_max_height` and the viewport, and scroll beyond that with the cursor visible. Exactly one blank row SHALL separate the last editor row from the status row. Side borders SHALL enclose all interior rows. The status row SHALL place activity and notices at the left edge of the content area and the model/context label at its right edge; labels MUST be clipped to fit without overlapping or using the padding. The box SHALL require room for the two side borders, the two padding columns, and at least two content columns after accounting for `pad_x`. The `lines` composer SHALL be used when the box cannot fit, without changing the configured style or losing the draft. All styles SHALL retain editing, completion, mouse and selection behavior.

#### Scenario: Boxed composer with a multiline draft
- **WHEN** boxed input is configured in a terminal with sufficient space and the draft wraps to more than one row at the padded content width
- **THEN** every editor row keeps one blank column just inside each side border, including when the draft fills the content width
- **AND** the box grows by one row per draft row within its height limits, and one blank row stays above the status row
- **AND** the cursor and mouse selection align with the inset text on the wrapped rows

#### Scenario: Long status labels
- **WHEN** the left status and right model/context labels together exceed the content width in a visible box
- **THEN** the labels are clipped within the content area without overlapping, and the column next to each side border stays blank

#### Scenario: Resize or reload
- **WHEN** the terminal becomes too small for the padded box, grows again, or `/reload` changes the input style
- **THEN** insufficient space uses `lines`, and the padded box returns when it fits again if `boxed` remains configured
- **AND** layout and input hit testing update together, preserving the draft and logical cursor position

### Requirement: Lines input composer
When `settings.ui.input_style` is `lines`, or a framed style does not fit, the composer SHALL be a rule with the activity on its right, the editor rows with the prompt arrow on the first row, and a rule with the model/context label on its right.

#### Scenario: Small terminal
- **WHEN** the style is `boxed` or `fill` and the terminal is too small for the frame
- **THEN** the lines composer is drawn and the configured style is unchanged

### Requirement: Fill input composer
When `settings.ui.input_style` is `fill` and the viewport fits, the composer SHALL draw one blank row, the editor rows, and one blank row, all with the `border` color as background across the full width. The first editor row SHALL start with the prompt arrow. One row without background SHALL follow, then the status row with the activity on the left and the model/context label on the right. While a picker, question, or panel is open, its rows and one border rule row SHALL take the place of that unfilled row.

#### Scenario: Fill composer with a multiline draft
- **WHEN** fill input is configured in a terminal with sufficient space and the draft wraps to more than one row
- **THEN** the filled block grows by one row per draft row, one unfilled row separates it from the status row, and the cursor and mouse hit testing match the editor rows

#### Scenario: Fill composer with an open list
- **WHEN** fill input is configured and a picker is open
- **THEN** the list is drawn between the filled block and the status row, and one border rule row closes it

### Requirement: Idle status shows the project directory
When no activity indicator or notice is shown and no turn is running, the composer SHALL show the session working directory in the `muted` color without an icon, with the home directory written as `~`, in the place of the indicator in every input style.

#### Scenario: Idle and working
- **WHEN** no turn is running and no notice is shown
- **THEN** the status shows the directory
- **WHEN** a turn starts or a notice appears
- **THEN** the indicator or notice replaces the directory

### Requirement: Lists open below the input
A picker, question, or panel SHALL open below the input, never between the chat and the input. With `lines` and `boxed` its rows SHALL follow the last row of the composer. With `fill` and `bar` its rows SHALL sit between the editor block and the status row, followed by one row drawn as a rule in the `border` color. Its height SHALL stay limited by `list_max_height` and the viewport, and the chat SHALL keep the rows that remain. The wheel over the list and paging SHALL use the rows where the list is drawn.

#### Scenario: Picker with boxed input
- **WHEN** the style is `boxed` and the user types `/`
- **THEN** the command list is drawn directly under the bottom border of the box and the chat above is not covered

#### Scenario: Picker with fill input
- **WHEN** the style is `fill` and the user types `/`
- **THEN** the order from the top is the filled block, the command list, one border rule row, and the status row

### Requirement: Blank row above the composer
Every input style SHALL draw one empty row above the first row of the composer: the top rule, the top border, the filled block, or the first bar row. The row holds no text and no color other than the terminal background. It MUST NOT count toward `input_max_height`. When the viewport is too small, this row SHALL be the first one dropped.

#### Scenario: All styles
- **WHEN** the style is `lines`, `boxed`, `fill`, or `bar`
- **THEN** one blank row separates the chat from the composer

#### Scenario: Tiny terminal
- **WHEN** the viewport has no room for the blank row
- **THEN** the composer is drawn without it and the draft is kept

### Requirement: Bar input composer
When `settings.ui.input_style` is `bar` and the viewport fits, the composer SHALL draw each editor row as `▌` in the `accent` color at column 0 with no padding before it, one space, then the text, without a prompt arrow. The height SHALL follow the draft, limited by `input_max_height` and the viewport, and scroll beyond that with the cursor visible. One blank row SHALL follow the editor rows, then the status row as in `fill`, with the activity and notices on the left and the model/context label on the right. The lines composer SHALL be used when the bar cannot fit, without changing the configured style or losing the draft.

#### Scenario: Multiline draft
- **WHEN** bar input is configured and the draft wraps to three rows
- **THEN** three rows each start with `▌ `, one blank row follows, and then the status row

#### Scenario: Small terminal
- **WHEN** the terminal is too small for the bar
- **THEN** the lines composer is drawn and the configured style is unchanged

### Requirement: Picker columns are aligned
A picker list SHALL draw each item as columns. Every cell of a column SHALL start at the same display column on every row, padded to the widest cell of that column among all items of the picker, with two spaces between columns. The last column is free text clipped at the row end. A column wider than half of the row width SHALL be clipped with the ellipsis so the next column keeps its room. `/history` rows SHALL have the columns index, role, and summary. Items with a label and a detail SHALL align the detail as the second column. Search SHALL match the cells joined by a space.

#### Scenario: History rows
- **WHEN** `/history` lists records 0 to 14
- **THEN** the roles start at one column and the summaries at one column, for example `0   system  …` and `10  hook    …`

#### Scenario: Command list
- **WHEN** the user types `/`
- **THEN** every command description starts at the same column

#### Scenario: Scrolling and filtering
- **WHEN** the list scrolls or the search narrows it
- **THEN** the column positions stay the same

#### Scenario: Narrow terminal
- **WHEN** the first column is wider than half of the row
- **THEN** it is clipped with the ellipsis and the second column still starts at one column on every row

### Requirement: Config models are aligned
The `Models` section of the `/config` panel SHALL pad every model name to the widest name in the section and start the details (`display=…`, `window=…`, `prices=…`) at one column after two spaces. The other sections of `/config` and the `/session` panel keep their current alignment.

#### Scenario: Models of different length
- **WHEN** the config has `openai/gpt-6.2-sol` and `claude/claude-sonnet-5-5`
- **THEN** both `window=…` details start at the same column

### Requirement: Command descriptions and words
The `/` picker SHALL show the `desc` of a custom command as its detail. Picking a command with `args` SHALL put `/name ` in the input and open a picker of its `args`; a space typed after `/name` SHALL reopen that picker, filtered by the typed text. Choosing an arg SHALL clear the input and run the command with it. Esc in that picker SHALL leave `/name ` in the input, and Enter then SHALL run the command with no arg. Enter on `/name` followed by words SHALL run the command with those words as the config spec describes, and a word list the command does not accept MUST NOT run it and MUST NOT be sent as a message. Enter on the exact `/name`, or picking a command without `args` from the `/` picker, SHALL run it with no words. JSON-RPC `commands.run` SHALL accept `{name, argv?}` with a list of words, apply the same checks, and fail with `-32000` when they fail; `commands.list` SHALL return `[{name, desc, args, params}]`.

#### Scenario: Pick an arg
- **WHEN** the user picks `/deploy` and then `prod`
- **THEN** `run("prod")` is called and the input is cleared

#### Scenario: Esc then Enter
- **WHEN** the user picks `/deploy`, presses Esc in the arg picker, and presses Enter
- **THEN** `run(nil)` is called

#### Scenario: Type words
- **WHEN** the user types `/mv a.txt b.txt` and presses Enter
- **THEN** `run("a.txt", "b.txt")` is called and the text is not sent to the agent

#### Scenario: Rejected words
- **WHEN** the user sends `/deploy nope`
- **THEN** nothing runs and an error naming the command is shown

#### Scenario: Description in the picker
- **WHEN** the user types `/`
- **THEN** `/deploy` is listed with `ship it` as its description

#### Scenario: JSON-RPC
- **WHEN** a client calls `commands.run` with `{"name": "mv", "argv": ["a.txt", "b.txt"]}`
- **THEN** `run("a.txt", "b.txt")` is called; `{"name": "deploy", "argv": ["nope"]}` fails with `-32000`

### Requirement: Frames stay in sync with the terminal
The TUI SHALL write each frame with a single write. It SHALL turn the terminal's automatic line wrap off while it runs and on again when it exits or panics, so text that overflows a row is clipped and MUST NOT scroll the screen. It SHALL repaint every row, not only the changed ones, at least every five seconds.

#### Scenario: One write per frame
- **WHEN** the TUI draws a frame
- **THEN** the whole frame, from the synchronized-update start to its end, reaches the output in one write

#### Scenario: Stray text
- **WHEN** another writer leaves text on a row that the renderer considers unchanged
- **THEN** the row is repainted within five seconds

#### Scenario: Line wrap
- **WHEN** the TUI starts
- **THEN** it sends the sequence that turns line wrap off, and it sends the one that turns it on when it exits or panics

### Requirement: Aligned chat entry text
User and agent message rows SHALL reserve two display columns on each side for padding, inside the chat width and separate from the outer `pad_x` margin. Messages SHALL wrap at the remaining content width. The top-level text of every chat entry SHALL start at the same left content column after any entry marker, on both first and continuation rows. This applies to messages, reasoning, Lua code and output, diff blocks, notices, errors, turn summaries, pinned and unpinned `show()` blocks, and recorded picker and question results. Intentional indentation within an entry, such as Markdown nesting or code indentation, SHALL be preserved. When the chat is too narrow to fit the padding and content, the padding SHALL yield as needed without overflowing the row.

#### Scenario: Mixed chat history
- **WHEN** the chat shows user and agent messages alongside Lua blocks, events, `show()` blocks, and picker or question results
- **THEN** their top-level text starts two display columns past the outer left margin, with any entry marker in those two columns
- **AND** user and agent messages leave two columns of right padding even when a row fills the available content width
- **AND** wrapped lines keep the same left inset, while nested lists and indented code keep their internal indentation

#### Scenario: Narrow terminal
- **WHEN** the chat width is too small for both two-column insets and message text
- **THEN** the insets shrink so the row stays within the viewport
- **AND** widening the terminal restores the two-column insets

#### Scenario: Restore history
- **WHEN** a session is reopened
- **THEN** restored entries use the same text alignment and wrapping as live entries at the same width

### Requirement: Selection is limited to one text target
Ctrl+A and Cmd+A SHALL clear any chat selection and select the entire editable input, including draft lines outside the viewport. Mouse selection SHALL be limited to the input or a single user or agent message. A drag moving outside its starting target SHALL stop at that target's boundary and MUST NOT add text from another target. Starting a new selection SHALL replace the previous one. Reasoning, Lua tool blocks, event entries, UI output, overlays, and layout decorations MUST NOT be selectable. The highlight SHALL match the selected text rather than the whole screen row.

#### Scenario: Select all with a message selected
- **WHEN** a chat message is selected and the user presses Ctrl+A or Cmd+A with an editable multiline draft
- **THEN** the chat selection clears and only the entire draft is selected, including any hidden editor lines

#### Scenario: Drag across messages or into the input
- **WHEN** the user starts a drag in an agent message and drags through a different message, a Lua block, a UI result, or the input
- **THEN** only the range within the original agent message is highlighted, in either drag direction

#### Scenario: Drag out of the input
- **WHEN** the user starts a drag in the input and moves into the chat or a panel
- **THEN** the selection stays in the input and no other text is highlighted

#### Scenario: Drag from non-selectable UI
- **WHEN** the user starts a selection drag on reasoning, Lua output, an event, a `show()` block, or an overlay and moves into a message
- **THEN** neither that UI text nor the message is selected

### Requirement: Copy logical text without layout whitespace
Ctrl+C and Cmd+C with a selection SHALL copy only the selected text. Chat selections SHALL copy plain text as displayed, without styles, layout padding, message gaps, or newlines introduced solely by visual wrapping. A soft wrap SHALL preserve the original word separation without inserting a space inside a wrapped word. Logical line breaks, paragraph breaks, and intentional indentation within the selected range SHALL be preserved. Editor selections SHALL copy the exact selected draft text, unaffected by wrapping or composer style.

#### Scenario: Copy a visually wrapped range
- **WHEN** the user selects a message paragraph that wraps at a space and also wraps a long word across rows
- **THEN** copying produces one logical line with the original word separation and no extra whitespace inside the long word
- **AND** the same logical range copies identically at a different terminal width

#### Scenario: Copy intentionally multiline text
- **WHEN** the user selects across a paragraph break or across indented lines of a code block in an agent message
- **THEN** copying preserves the paragraph break or code line breaks and indentation, without adding leading or trailing padding from the highlighted rows

#### Scenario: Copy a draft
- **WHEN** the user selects a wrapped draft containing explicit newlines, spaces, or indentation
- **THEN** copying returns exactly that part of the draft, without the composer prompt, borders, or visual wraps
