package main

func main() {
	panic("This executable should not be available. If you're seeing this message than there was an issue building this version of oatmeal.")
}
