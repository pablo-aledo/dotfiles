# Hardware Support

| Recipe | Crates | Categories |
|--------|--------|------------|
| [Check number of logical cpu cores][ex-check-cpu-cores] | [![num_cpus-badge]][num_cpus] | [![cat-hardware-support-badge]][cat-hardware-support] |

[ex-check-cpu-cores]: hardware/processor.html#check-number-of-logical-cpu-cores

{{#include links.md}}
