# Working with Tarballs

{{#include tar/tar-decompress.md}}

{{#include tar/tar-compress.md}}

{{#include tar/tar-strip-prefix.md}}

{{#include ../links.md}}
