# Working with Postgres

{{#include postgres/create_tables.md}}

{{#include postgres/insert_query_data.md}}

{{#include postgres/aggregate_data.md}}

{{#include ../links.md}}
