# Character Sets

{{#include string/percent-encode.md}}

{{#include string/url-encode.md}}

{{#include string/hex.md}}

{{#include string/base64.md}}

{{#include ../links.md}}
