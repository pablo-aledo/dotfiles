# Structured Data

{{#include complex/json.md}}

{{#include complex/toml.md}}

{{#include complex/endian-byte.md}}

{{#include ../links.md}}
