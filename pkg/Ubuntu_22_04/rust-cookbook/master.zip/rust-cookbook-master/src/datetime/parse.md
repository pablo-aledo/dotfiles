# Parsing and Displaying

{{#include parse/current.md}}

{{#include parse/timestamp.md}}

{{#include parse/format.md}}

{{#include parse/string.md}}

{{#include ../links.md}}
