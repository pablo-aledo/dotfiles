# Calling a Web API

{{#include api/rest-get.md}}

{{#include api/rest-head.md}}

{{#include api/rest-post.md}}

{{#include api/paginated.md}}

{{#include ../../links.md}}
