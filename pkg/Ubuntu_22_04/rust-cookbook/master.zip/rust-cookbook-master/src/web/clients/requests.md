# Making Requests

{{#include requests/get.md}}

{{#include ../../links.md}}
