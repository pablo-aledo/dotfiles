# Media Types

{{#include mime/string.md}}

{{#include mime/filename.md}}

{{#include mime/request.md}}

{{#include ../links.md}}
