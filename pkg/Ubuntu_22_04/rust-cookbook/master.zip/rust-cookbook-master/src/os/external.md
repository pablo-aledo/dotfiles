# External Command

{{#include external/process-output.md}}

{{#include external/send-input.md}}

{{#include external/piped.md}}

{{#include external/error-file.md}}

{{#include external/continuous.md}}

{{#include external/read-env-variable.md}}

{{#include ../links.md}}
