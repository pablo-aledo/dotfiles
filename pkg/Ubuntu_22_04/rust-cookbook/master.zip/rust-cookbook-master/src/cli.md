# Command Line

| Recipe | Crates | Categories |
|--------|--------|------------|
| [Parse command line arguments][ex-clap-basic] | [![clap-badge]][clap] | [![cat-command-line-badge]][cat-command-line] |
| [ANSI Terminal][ex-ansi_term-basic] | [![ansi_term-badge]][ansi_term]| [![cat-command-line-badge]][cat-command-line] |

[ex-clap-basic]: cli/arguments.html#parse-command-line-arguments
[ex-ansi_term-basic]: cli/ansi_terminal.html#ansi-terminal

{{#include links.md}}