# Clap basic

{{#include arguments/clap-basic.md}}

{{#include ../links.md}}
