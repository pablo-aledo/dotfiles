# Versioning

{{#include versioning/semver-increment.md}}

{{#include versioning/semver-complex.md}}

{{#include versioning/semver-prerelease.md}}

{{#include versioning/semver-latest.md}}

{{#include versioning/semver-command.md}}

{{#include ../links.md}}
