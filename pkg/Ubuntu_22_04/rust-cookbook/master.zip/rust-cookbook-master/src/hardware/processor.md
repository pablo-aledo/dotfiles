# Processor

{{#include processor/cpu-count.md}}

{{#include ../links.md}}
