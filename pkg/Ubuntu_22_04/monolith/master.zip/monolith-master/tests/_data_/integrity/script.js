function noop() {
    console.log("monolith");
}
