document.body.style.backgroundColor = "green";
document.body.style.color = "red";
