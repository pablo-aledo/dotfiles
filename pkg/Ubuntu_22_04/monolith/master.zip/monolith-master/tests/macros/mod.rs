mod empty_image;
mod str;
