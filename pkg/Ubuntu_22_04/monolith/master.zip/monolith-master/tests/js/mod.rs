mod attr_is_event_handler;
