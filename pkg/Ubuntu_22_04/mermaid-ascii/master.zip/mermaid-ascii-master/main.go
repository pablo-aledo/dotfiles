package main

import "github.com/AlexanderGrooff/mermaid-ascii/cmd"

func main() {
	cmd.Execute()
}
