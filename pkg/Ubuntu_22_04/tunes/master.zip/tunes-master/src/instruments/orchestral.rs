//! Orchestral and acoustic instrument presets

use super::Instrument;
use crate::synthesis::effects::{Distortion, Reverb};
use crate::synthesis::envelope::Envelope;
use crate::synthesis::filter::Filter;
use crate::synthesis::lfo::{LFO, ModRoute, ModTarget};
use crate::synthesis::waveform::Waveform;

impl Instrument {
    /// Strings - violin/cello ensemble sound
    pub fn strings() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.5, 0.3); // Natural string vibrato
        Self {
            name: "Strings".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.15, 0.3, 0.85, 0.6), // Slow attack, sustained
            filter: Filter::low_pass(4000.0, 0.25),        // Warm, not too bright
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.15)],
            delay: None,
            reverb: Some(Reverb::new(0.6, 0.6, 0.45)), // Concert hall ambience
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Brass - trumpet/horn section sound
    pub fn brass() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 6.0, 0.25);
        Self {
            name: "Brass".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.05, 0.15, 0.8, 0.4), // Moderate attack for brass punch
            filter: Filter::low_pass(5000.0, 0.5),         // Bright and brassy
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.12)],
            delay: None,
            reverb: Some(Reverb::new(0.35, 0.5, 0.25)),
            distortion: Some(Distortion::new(1.3, 0.2)), // Slight grit for realism
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Flute - soft, breathy woodwind sound
    pub fn flute() -> Self {
        let breath_lfo = LFO::new(Waveform::Sine, 4.0, 0.2); // Subtle breath modulation
        Self {
            name: "Flute".to_string(),
            waveform: Waveform::Sine,
            envelope: Envelope::new(0.08, 0.2, 0.7, 0.5), // Gentle attack
            filter: Filter::low_pass(6000.0, 0.2),        // Soft, airy
            modulation: vec![ModRoute::new(breath_lfo, ModTarget::Volume, 0.08)],
            delay: None,
            reverb: Some(Reverb::new(0.4, 0.5, 0.3)),
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Clarinet - warm, woody wind sound
    pub fn clarinet() -> Self {
        Self {
            name: "Clarinet".to_string(),
            waveform: Waveform::Square, // Square wave for hollow tone
            envelope: Envelope::new(0.06, 0.2, 0.75, 0.4), // Moderate attack
            filter: Filter::low_pass(3500.0, 0.3), // Warm, woody
            modulation: Vec::new(),
            delay: None,
            reverb: Some(Reverb::new(0.35, 0.45, 0.25)),
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Oboe - nasal, reedy double-reed woodwind
    pub fn oboe() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.8, 0.3); // Moderate vibrato
        Self {
            name: "Oboe".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.04, 0.18, 0.8, 0.45), // Relatively quick attack
            filter: Filter::low_pass(2800.0, 0.55),         // Nasal, reedy range with resonance
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.15)],
            delay: None,
            reverb: Some(Reverb::new(0.35, 0.45, 0.25)),
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Bassoon - deep, woody double-reed woodwind
    pub fn bassoon() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 4.5, 0.2); // Subtle vibrato
        Self {
            name: "Bassoon".to_string(),
            waveform: Waveform::Triangle,
            envelope: Envelope::new(0.08, 0.25, 0.75, 0.5), // Gentle attack
            filter: Filter::low_pass(1200.0, 0.4),          // Deep, woody tone
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.12)],
            delay: None,
            reverb: Some(Reverb::new(0.4, 0.5, 0.3)),
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// French horn - warm, mellow brass instrument
    pub fn french_horn() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.0, 0.25);
        Self {
            name: "French Horn".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.1, 0.2, 0.82, 0.5), // Smooth, mellow attack
            filter: Filter::low_pass(3800.0, 0.38),       // Warm, not too bright
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.1)],
            delay: None,
            reverb: Some(Reverb::new(0.55, 0.6, 0.4)), // Concert hall
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Harp - plucked string instrument with bright, shimmering tone
    pub fn harp() -> Self {
        let shimmer = LFO::new(Waveform::Sine, 0.3, 0.15); // Slow shimmer
        Self {
            name: "Harp".to_string(),
            waveform: Waveform::Triangle,
            envelope: Envelope::new(0.002, 0.35, 0.15, 0.7), // Very fast attack, quick decay
            filter: Filter::low_pass(7000.0, 0.25),          // Bright, clear
            modulation: vec![ModRoute::new(shimmer, ModTarget::FilterCutoff, 0.08)],
            delay: None,
            reverb: Some(Reverb::new(0.5, 0.55, 0.35)), // Hall reverb for sparkle
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Alto saxophone - bright, expressive, mid-range jazz and classical
    pub fn alto_sax() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.5, 0.35); // Expressive vibrato
        Self {
            name: "Alto Sax".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.03, 0.15, 0.85, 0.4), // Quick attack, long sustain
            filter: Filter::low_pass(3200.0, 0.48),         // Bright, reedy
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.15)],
            delay: None,
            reverb: Some(Reverb::new(0.3, 0.4, 0.25)),
            distortion: Some(Distortion::new(1.2, 0.15)), // Slight breath/reed character
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Tenor saxophone - warm, smooth, lower jazz tone
    pub fn tenor_sax() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.0, 0.3); // Smooth vibrato
        Self {
            name: "Tenor Sax".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.04, 0.18, 0.88, 0.45), // Smooth, sustained
            filter: Filter::low_pass(2400.0, 0.45),          // Warm, full
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.12)],
            delay: None,
            reverb: Some(Reverb::new(0.35, 0.45, 0.3)),
            distortion: Some(Distortion::new(1.15, 0.12)), // Subtle warmth
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Soprano saxophone - high, piercing, straight horn tone
    pub fn soprano_sax() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 6.0, 0.4); // Faster vibrato
        Self {
            name: "Soprano Sax".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.025, 0.12, 0.85, 0.35), // Quick, bright attack
            filter: Filter::low_pass(4200.0, 0.5),            // Piercing, clear
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.18)],
            delay: None,
            reverb: Some(Reverb::new(0.28, 0.38, 0.22)),
            distortion: Some(Distortion::new(1.25, 0.18)), // Edgy tone
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Baritone saxophone - very low, full-bodied, foundational
    pub fn baritone_sax() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 4.5, 0.25); // Slower, subtle vibrato
        Self {
            name: "Baritone Sax".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.05, 0.2, 0.9, 0.5), // Slower attack, very sustained
            filter: Filter::low_pass(1800.0, 0.42),       // Deep, full
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.1)],
            delay: None,
            reverb: Some(Reverb::new(0.4, 0.5, 0.35)),
            distortion: Some(Distortion::new(1.1, 0.1)), // Very subtle warmth
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Trombone - smooth, sliding brass with warm, mellow tone
    pub fn trombone() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.2, 0.28);
        Self {
            name: "Trombone".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.06, 0.18, 0.82, 0.45), // Smooth, warm attack
            filter: Filter::low_pass(2800.0, 0.42),          // Warm, not too bright
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.12)],
            delay: None,
            reverb: Some(Reverb::new(0.4, 0.5, 0.32)),
            distortion: Some(Distortion::new(1.25, 0.18)), // Slight brass character
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Tuba - very deep foundational brass instrument
    pub fn tuba() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 4.0, 0.2); // Slow, subtle vibrato
        Self {
            name: "Tuba".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.08, 0.25, 0.88, 0.6), // Deep, sustained
            filter: Filter::low_pass(1200.0, 0.38),         // Very low, foundational
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.08)],
            delay: None,
            reverb: Some(Reverb::new(0.45, 0.52, 0.38)),
            distortion: Some(Distortion::new(1.15, 0.12)), // Subtle depth
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Piccolo - very high, piercing flute (octave above flute)
    pub fn piccolo() -> Self {
        let breath = LFO::new(Waveform::Sine, 4.5, 0.18); // Quick breath variation
        Self {
            name: "Piccolo".to_string(),
            waveform: Waveform::Sine,
            envelope: Envelope::new(0.05, 0.15, 0.7, 0.4), // Quick, bright attack
            filter: Filter::low_pass(8000.0, 0.25),        // Very high, piercing
            modulation: vec![ModRoute::new(breath, ModTarget::Volume, 0.1)],
            delay: None,
            reverb: Some(Reverb::new(0.35, 0.42, 0.28)),
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// English horn - melancholy, nasal woodwind (lower than oboe)
    pub fn english_horn() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.2, 0.3);
        Self {
            name: "English Horn".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.06, 0.22, 0.78, 0.5), // Gentle, expressive
            filter: Filter::low_pass(2200.0, 0.52),         // Melancholy, nasal
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.14)],
            delay: None,
            reverb: Some(Reverb::new(0.38, 0.48, 0.32)),
            distortion: None,
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Muted trumpet - trumpet with mute (darker, closed, distant sound)
    pub fn muted_trumpet() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.8, 0.22); // Subtle vibrato
        Self {
            name: "Muted Trumpet".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.04, 0.15, 0.75, 0.35), // Slightly muffled attack
            filter: Filter::low_pass(2400.0, 0.38),          // Darker, muted tone
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.1)],
            delay: None,
            reverb: Some(Reverb::new(0.3, 0.38, 0.22)),
            distortion: Some(Distortion::new(1.15, 0.12)), // Subtle brass texture
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Flugelhorn - darker, mellower than trumpet, warm and lyrical
    pub fn flugelhorn() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.2, 0.3); // Expressive vibrato
        Self {
            name: "Flugelhorn".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.06, 0.18, 0.82, 0.45), // Smooth, warm attack
            filter: Filter::low_pass(3200.0, 0.35),          // Warm, dark brass
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.12)],
            delay: None,
            reverb: Some(Reverb::new(0.42, 0.52, 0.35)),
            distortion: Some(Distortion::new(1.2, 0.15)), // Warm brass character
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Euphonium - darker than trombone, brighter than tuba, rich tenor brass
    pub fn euphonium() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 4.8, 0.25);
        Self {
            name: "Euphonium".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.07, 0.2, 0.85, 0.5), // Smooth, rich attack
            filter: Filter::low_pass(2000.0, 0.4),         // Warm tenor range
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.1)],
            delay: None,
            reverb: Some(Reverb::new(0.45, 0.52, 0.38)),
            distortion: Some(Distortion::new(1.18, 0.14)), // Rich brass warmth
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Brass section - full orchestral brass ensemble (trumpets, trombones, horns)
    pub fn brass_section() -> Self {
        let ensemble_vibrato = LFO::new(Waveform::Sine, 5.5, 0.28); // Ensemble vibrato
        Self {
            name: "Brass Section".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.08, 0.2, 0.85, 0.5), // Powerful section attack
            filter: Filter::low_pass(4500.0, 0.48),        // Full, powerful brass
            modulation: vec![ModRoute::new(ensemble_vibrato, ModTarget::FilterCutoff, 0.15)],
            delay: None,
            reverb: Some(Reverb::new(0.55, 0.62, 0.45)), // Large hall
            distortion: Some(Distortion::new(1.35, 0.22)), // Full brass character
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Solo trumpet - bright, soloistic trumpet (more articulate than section)
    pub fn solo_trumpet() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 6.2, 0.35); // Expressive solo vibrato
        Self {
            name: "Solo Trumpet".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.03, 0.15, 0.8, 0.38), // Clear, articulate attack
            filter: Filter::low_pass(5200.0, 0.52),         // Bright, cutting
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.18)],
            delay: None,
            reverb: Some(Reverb::new(0.32, 0.42, 0.28)),
            distortion: Some(Distortion::new(1.28, 0.2)), // Solo brass presence
            volume: 1.0,
            pan: 0.0,
        }
    }

    /// Muted trombone - trombone with mute (darker, jazzy, intimate)
    pub fn muted_trombone() -> Self {
        let vibrato = LFO::new(Waveform::Sine, 5.0, 0.25);
        Self {
            name: "Muted Trombone".to_string(),
            waveform: Waveform::Sawtooth,
            envelope: Envelope::new(0.05, 0.18, 0.78, 0.42), // Smooth, muted attack
            filter: Filter::low_pass(2200.0, 0.4),           // Dark, jazzy mute
            modulation: vec![ModRoute::new(vibrato, ModTarget::FilterCutoff, 0.12)],
            delay: None,
            reverb: Some(Reverb::new(0.35, 0.45, 0.3)),
            distortion: Some(Distortion::new(1.22, 0.16)), // Subtle brass texture
            volume: 1.0,
            pan: 0.0,
        }
    }
}
