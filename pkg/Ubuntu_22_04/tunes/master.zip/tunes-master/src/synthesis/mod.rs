//! Advanced synthesis techniques and modulation

pub mod waveform;
pub mod envelope;
pub mod lfo;
pub mod filter;
pub mod noise;
pub mod automation;
pub mod sample;
pub mod slice;
pub mod effects;
pub mod fm_synthesis;
pub mod granular;
pub mod wavetable;
pub mod filter_envelope;
pub mod karplus_strong;
pub mod additive;
pub mod spatial;
pub mod simd;
pub mod spectral;
pub mod synthesis_builder;

// Re-export main types for convenience
pub use waveform::Waveform;
pub use lfo::{LFO, ModRoute, ModTarget};
pub use filter::{Filter, FilterType};
pub use noise::{
    NoiseType, NoiseGenerator, WhiteNoise, BrownNoise, PinkNoise, BlueNoise, GreenNoise,
    PerlinNoise,
};
pub use automation::{Automation, Interpolation};
pub use sample::Sample;
pub use slice::SampleSlice;
pub use effects::*;
pub use envelope::Envelope;
pub use fm_synthesis::FMParams;
pub use granular::GranularParams;
pub use wavetable::Wavetable;
pub use filter_envelope::FilterEnvelope;
pub use karplus_strong::KarplusStrong;
pub use additive::{AdditiveSynth, Partial};
pub use spatial::{
    Vec3, SpatialPosition, ListenerConfig, SpatialParams, SpatialResult, AttenuationModel,
    calculate_spatial, calculate_attenuation, calculate_azimuth, azimuth_to_pan,
    calculate_doppler,
};
pub use simd::{SimdDispatcher, SimdLanes, SimdWidth, SIMD};
pub use spectral::{Window, WindowType, ComplexOps, STFT, PhaseVocoder, SpectralFreeze, SpectralGate, SpectralCompressor, SpectralRobotize, SpectralDelay};
pub use synthesis_builder::SynthesisBuilder;
