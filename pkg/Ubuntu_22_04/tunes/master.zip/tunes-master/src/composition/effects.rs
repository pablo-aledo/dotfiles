use super::TrackBuilder;
use crate::synthesis::effects::{
    AutoPan, BitCrusher, Chorus, Compressor, ConvolutionReverb, Delay, Distortion, EQ, Flanger,
    FormantShifter, Gate, Limiter, PhaseVocoder, Phaser,
    Reverb, RingModulator, Saturation, SpectralFreeze, SpectralGate, SpectralCompressor,
    SpectralHarmonizer, SpectralPanner, SpectralResonator, SpectralRobotize, SpectralDelay,
    SpectralFilter, SpectralBlur, SpectralShift, SpectralExciter, SpectralInvert, SpectralWiden,
    SpectralMorph, SpectralDynamics, SpectralScramble, Tremolo,
};
use crate::synthesis::filter::Filter;
use crate::synthesis::lfo::ModRoute;

/// Builder for audio effects (accessed via `.effects()`)
///
/// Provides a scoped namespace for all 23 audio effect methods.
/// Use with closure syntax for clean, organized code:
///
/// ```rust
/// # use tunes::composition::Composition;
/// # use tunes::composition::timing::Tempo;
/// # use tunes::synthesis::effects::*;
/// # use tunes::synthesis::filter::*;
/// # let mut comp = Composition::new(Tempo::new(120.0));
/// comp.track("synth")
///     .note(&[440.0], 1.0)
///     .effects(|e| e
///         .filter(Filter::low_pass(1000.0, 0.7))
///         .reverb(Reverb::new(0.8, 0.5, 0.3))
///         .delay(Delay::new(0.25, 0.4, 0.5))
///     );
/// ```
pub struct EffectsBuilder<'a> {
    inner: TrackBuilder<'a>,
}

impl<'a> EffectsBuilder<'a> {
    /// Unwrap back to the inner TrackBuilder
    fn into_inner(self) -> TrackBuilder<'a> {
        self.inner
    }

    /// Set the filter for this track
    pub fn filter(mut self, filter: Filter) -> Self {
        self.inner = self.inner.filter(filter);
        self
    }

    /// Add delay effect
    pub fn delay(mut self, delay: Delay) -> Self {
        self.inner = self.inner.delay(delay);
        self
    }

    /// Add reverb effect
    pub fn reverb(mut self, reverb: Reverb) -> Self {
        self.inner = self.inner.reverb(reverb);
        self
    }

    /// Add convolution reverb effect
    pub fn convolution_reverb(mut self, convolution_reverb: ConvolutionReverb) -> Self {
        self.inner = self.inner.convolution_reverb(convolution_reverb);
        self
    }

    /// Add distortion effect
    pub fn distortion(mut self, distortion: Distortion) -> Self {
        self.inner = self.inner.distortion(distortion);
        self
    }

    /// Add bitcrusher effect
    pub fn bitcrusher(mut self, bitcrusher: BitCrusher) -> Self {
        self.inner = self.inner.bitcrusher(bitcrusher);
        self
    }

    /// Add compressor effect
    pub fn compressor(mut self, compressor: Compressor) -> Self {
        self.inner = self.inner.compressor(compressor);
        self
    }

    /// Add chorus effect
    pub fn chorus(mut self, chorus: Chorus) -> Self {
        self.inner = self.inner.chorus(chorus);
        self
    }

    /// Add EQ effect
    pub fn eq(mut self, eq: EQ) -> Self {
        self.inner = self.inner.eq(eq);
        self
    }

    /// Add saturation effect
    pub fn saturation(mut self, saturation: Saturation) -> Self {
        self.inner = self.inner.saturation(saturation);
        self
    }

    /// Add phaser effect
    pub fn phaser(mut self, phaser: Phaser) -> Self {
        self.inner = self.inner.phaser(phaser);
        self
    }

    /// Add flanger effect
    pub fn flanger(mut self, flanger: Flanger) -> Self {
        self.inner = self.inner.flanger(flanger);
        self
    }

    /// Add ring modulator effect
    pub fn ring_mod(mut self, ring_mod: RingModulator) -> Self {
        self.inner = self.inner.ring_mod(ring_mod);
        self
    }

    /// Add tremolo effect
    pub fn tremolo(mut self, tremolo: Tremolo) -> Self {
        self.inner = self.inner.tremolo(tremolo);
        self
    }

    /// Add autopan effect
    pub fn autopan(mut self, autopan: AutoPan) -> Self {
        self.inner = self.inner.autopan(autopan);
        self
    }

    /// Add gate effect
    pub fn gate(mut self, gate: Gate) -> Self {
        self.inner = self.inner.gate(gate);
        self
    }

    /// Add limiter effect
    pub fn limiter(mut self, limiter: Limiter) -> Self {
        self.inner = self.inner.limiter(limiter);
        self
    }

    /// Add phase vocoder effect for time-stretching and pitch-shifting
    pub fn phase_vocoder(mut self, phase_vocoder: PhaseVocoder) -> Self {
        self.inner = self.inner.phase_vocoder(phase_vocoder);
        self
    }

    /// Add spectral freeze effect for capturing and holding frequency spectrum
    pub fn spectral_freeze(mut self, spectral_freeze: SpectralFreeze) -> Self {
        self.inner = self.inner.spectral_freeze(spectral_freeze);
        self
    }

    /// Add spectral gate effect for frequency-selective noise gating
    pub fn spectral_gate(mut self, spectral_gate: SpectralGate) -> Self {
        self.inner = self.inner.spectral_gate(spectral_gate);
        self
    }

    /// Add spectral compressor effect for frequency-selective dynamic range compression
    pub fn spectral_compressor(mut self, spectral_compressor: SpectralCompressor) -> Self {
        self.inner = self.inner.spectral_compressor(spectral_compressor);
        self
    }

    /// Add spectral robotize effect for robotic/synthesized voice
    pub fn spectral_robotize(mut self, spectral_robotize: SpectralRobotize) -> Self {
        self.inner = self.inner.spectral_robotize(spectral_robotize);
        self
    }

    /// Add spectral delay with frequency-dependent delay times
    pub fn spectral_delay(mut self, spectral_delay: SpectralDelay) -> Self {
        self.inner = self.inner.spectral_delay(spectral_delay);
        self
    }

    /// Add spectral filter for frequency-domain filtering
    pub fn spectral_filter(mut self, spectral_filter: SpectralFilter) -> Self {
        self.inner = self.inner.spectral_filter(spectral_filter);
        self
    }

    /// Add spectral blur for temporal smoothing in frequency domain
    pub fn spectral_blur(mut self, spectral_blur: SpectralBlur) -> Self {
        self.inner = self.inner.spectral_blur(spectral_blur);
        self
    }

    /// Add spectral shift for frequency shifting
    pub fn spectral_shift(mut self, spectral_shift: SpectralShift) -> Self {
        self.inner = self.inner.spectral_shift(spectral_shift);
        self
    }

    /// Add formant shifter for vocal character transformation
    pub fn formant_shifter(mut self, formant_shifter: FormantShifter) -> Self {
        self.inner = self.inner.formant_shifter(formant_shifter);
        self
    }

    /// Add spectral harmonizer for pitch-shifted harmonies
    pub fn spectral_harmonizer(mut self, spectral_harmonizer: SpectralHarmonizer) -> Self {
        self.inner = self.inner.spectral_harmonizer(spectral_harmonizer);
        self
    }

    /// Add spectral resonator for resonant peaks
    pub fn spectral_resonator(mut self, spectral_resonator: SpectralResonator) -> Self {
        self.inner = self.inner.spectral_resonator(spectral_resonator);
        self
    }

    /// Add spectral panner for frequency-based spatial positioning
    pub fn spectral_panner(mut self, spectral_panner: SpectralPanner) -> Self {
        self.inner = self.inner.spectral_panner(spectral_panner);
        self
    }

    /// Add spectral exciter for harmonic enhancement
    pub fn spectral_exciter(mut self, spectral_exciter: SpectralExciter) -> Self {
        self.inner = self.inner.spectral_exciter(spectral_exciter);
        self
    }

    /// Add spectral invert for frequency spectrum reversal
    pub fn spectral_invert(mut self, spectral_invert: SpectralInvert) -> Self {
        self.inner = self.inner.spectral_invert(spectral_invert);
        self
    }

    /// Add spectral widen for stereo widening via phase manipulation
    pub fn spectral_widen(mut self, spectral_widen: SpectralWiden) -> Self {
        self.inner = self.inner.spectral_widen(spectral_widen);
        self
    }

    /// Add spectral morph for morphing spectrum toward target shapes
    pub fn spectral_morph(mut self, spectral_morph: SpectralMorph) -> Self {
        self.inner = self.inner.spectral_morph(spectral_morph);
        self
    }

    /// Add spectral dynamics effect (frequency-dependent compression/expansion)
    pub fn spectral_dynamics(mut self, spectral_dynamics: SpectralDynamics) -> Self {
        self.inner = self.inner.spectral_dynamics(spectral_dynamics);
        self
    }

    /// Add spectral scramble effect (glitchy frequency bin randomization)
    pub fn spectral_scramble(mut self, spectral_scramble: SpectralScramble) -> Self {
        self.inner = self.inner.spectral_scramble(spectral_scramble);
        self
    }

    /// Add LFO modulation
    pub fn modulate(mut self, mod_route: ModRoute) -> Self {
        self.inner = self.inner.modulate(mod_route);
        self
    }
}

impl<'a> TrackBuilder<'a> {
    /// Enter effects namespace
    ///
    /// Provides scoped access to all 18 audio effect methods.
    /// The closure receives an `EffectsBuilder` and should return it
    /// after applying effects.
    ///
    /// # Example
    /// ```rust
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::*;
    /// # use tunes::synthesis::filter::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.track("melody")
    ///     .note(&[440.0], 1.0)
    ///     .effects(|e| e
    ///         .filter(Filter::low_pass(1200.0, 0.8))
    ///         .reverb(Reverb::new(0.8, 0.5, 0.3))
    ///         .delay(Delay::new(0.5, 0.4, 0.5))
    ///         .chorus(Chorus::new(1.0, 5.0, 0.5))
    ///     );
    /// ```
    pub fn effects<F>(self, f: F) -> Self
    where
        F: FnOnce(EffectsBuilder<'a>) -> EffectsBuilder<'a>,
    {
        let builder = EffectsBuilder { inner: self };
        let result = f(builder);
        result.into_inner()
    }
}

impl<'a> TrackBuilder<'a> {
    /// Set the filter for this track
    pub fn filter(mut self, filter: Filter) -> Self {
        self.get_track_mut().filter = filter;
        self
    }
    /// Add delay effect to this track
    pub fn delay(mut self, delay: Delay) -> Self {
        let track = self.get_track_mut();
        track.effects.delay = Some(delay);
        track.effects.compute_effect_order();
        self
    }
    /// Add reverb effect to this track
    pub fn reverb(mut self, reverb: Reverb) -> Self {
        let track = self.get_track_mut();
        track.effects.reverb = Some(reverb);
        track.effects.compute_effect_order();
        self
    }
    /// Add convolution reverb effect to this track
    ///
    /// Convolution reverb uses impulse responses to apply realistic room acoustics.
    /// More computationally expensive than algorithmic reverb but more realistic.
    ///
    /// # Arguments
    /// * `convolution_reverb` - ConvolutionReverb effect instance
    ///
    /// # Example
    /// ```no_run
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::convolution;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("piano", &Instrument::acoustic_piano())
    ///     .convolution_reverb(convolution::presets::cathedral(0.5).unwrap())
    ///     .note(&[C4], 1.0);
    /// # Ok::<(), anyhow::Error>(())
    /// ```
    pub fn convolution_reverb(mut self, convolution_reverb: ConvolutionReverb) -> Self {
        let track = self.get_track_mut();
        track.effects.convolution_reverb = Some(convolution_reverb);
        track.effects.compute_effect_order();
        self
    }
    /// Add distortion effect to this track
    pub fn distortion(mut self, distortion: Distortion) -> Self {
        let track = self.get_track_mut();
        track.effects.distortion = Some(distortion);
        track.effects.compute_effect_order();
        self
    }
    /// Add bitcrusher effect to this track
    ///
    /// BitCrusher reduces bit depth and sample rate for lo-fi, retro digital effects.
    ///
    /// # Arguments
    /// * `bitcrusher` - BitCrusher effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::BitCrusher;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("lead", &Instrument::synth_lead())
    ///     .bitcrusher(BitCrusher::new(4.0, 8.0, 0.5))
    ///     .note(&[C4], 1.0);
    /// ```
    pub fn bitcrusher(mut self, bitcrusher: BitCrusher) -> Self {
        let track = self.get_track_mut();
        track.effects.bitcrusher = Some(bitcrusher);
        track.effects.compute_effect_order();
        self
    }
    /// Add compressor effect to this track
    ///
    /// Compressor controls dynamics by reducing the volume of loud signals.
    ///
    /// # Arguments
    /// * `compressor` - Compressor effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Compressor;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("drums", &Instrument::synth_lead())
    ///     .compressor(Compressor::new(-10.0, 4.0, 0.01, 0.1, 2.0))
    ///     .note(&[C4], 1.0);
    /// ```
    pub fn compressor(mut self, compressor: Compressor) -> Self {
        let track = self.get_track_mut();
        track.effects.compressor = Some(compressor);
        track.effects.compute_effect_order();
        self
    }
    /// Add chorus effect to this track
    ///
    /// Chorus creates a richer, doubled sound through delayed and modulated copies.
    ///
    /// # Arguments
    /// * `chorus` - Chorus effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Chorus;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("pad", &Instrument::warm_pad())
    ///     .chorus(Chorus::new(0.5, 0.002, 0.3))
    ///     .note(&[C4, E4, G4], 2.0);
    /// ```
    pub fn chorus(mut self, chorus: Chorus) -> Self {
        let track = self.get_track_mut();
        track.effects.chorus = Some(chorus);
        track.effects.compute_effect_order();
        self
    }
    /// Add EQ effect to this track
    ///
    /// 3-band parametric equalizer for frequency shaping.
    ///
    /// # Arguments
    /// * `eq` - EQ effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::EQ;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("bass", &Instrument::sub_bass())
    ///     .eq(EQ::new(2.0, 1.0, 0.5, 200.0, 2000.0))
    ///     .note(&[C2], 1.0);
    /// ```
    pub fn eq(mut self, eq: EQ) -> Self {
        let track = self.get_track_mut();
        track.effects.eq = Some(eq);
        track.effects.compute_effect_order();
        self
    }
    /// Add saturation effect to this track
    ///
    /// Saturation adds warm, analog-style coloration and harmonics.
    ///
    /// # Arguments
    /// * `saturation` - Saturation effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Saturation;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("guitar", &Instrument::pluck())
    ///     .saturation(Saturation::new(2.0, 0.5, 0.7))
    ///     .note(&[E3], 1.0);
    /// ```
    pub fn saturation(mut self, saturation: Saturation) -> Self {
        let track = self.get_track_mut();
        track.effects.saturation = Some(saturation);
        track.effects.compute_effect_order();
        self
    }
    /// Add phaser effect to this track
    ///
    /// Phaser creates sweeping notches in the frequency spectrum for classic swoosh effects.
    ///
    /// # Arguments
    /// * `phaser` - Phaser effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Phaser;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("synth", &Instrument::synth_lead())
    ///     .phaser(Phaser::new(0.5, 0.7, 0.5, 4, 0.5))
    ///     .note(&[A4], 2.0);
    /// ```
    pub fn phaser(mut self, phaser: Phaser) -> Self {
        let track = self.get_track_mut();
        track.effects.phaser = Some(phaser);
        track.effects.compute_effect_order();
        self
    }
    /// Add flanger effect to this track
    ///
    /// Flanger creates jet-plane/swoosh effects with very short modulated delays.
    ///
    /// # Arguments
    /// * `flanger` - Flanger effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Flanger;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("guitar", &Instrument::pluck())
    ///     .flanger(Flanger::new(0.5, 3.0, 0.6, 0.5))
    ///     .note(&[E4], 2.0);
    /// ```
    pub fn flanger(mut self, flanger: Flanger) -> Self {
        let track = self.get_track_mut();
        track.effects.flanger = Some(flanger);
        track.effects.compute_effect_order();
        self
    }
    /// Add ring modulator effect to this track
    ///
    /// Ring Modulator creates metallic/robotic inharmonic tones by multiplying with a carrier frequency.
    ///
    /// # Arguments
    /// * `ring_mod` - RingModulator effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::RingModulator;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("robot_voice", &Instrument::synth_lead())
    ///     .ring_mod(RingModulator::new(440.0, 0.7))
    ///     .note(&[C4], 1.0);
    /// ```
    pub fn ring_mod(mut self, ring_mod: RingModulator) -> Self {
        let track = self.get_track_mut();
        track.effects.ring_mod = Some(ring_mod);
        track.effects.compute_effect_order();
        self
    }
    /// Add tremolo effect to this track
    ///
    /// Tremolo creates rhythmic amplitude modulation for pulsing volume effects.
    ///
    /// # Arguments
    /// * `tremolo` - Tremolo effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Tremolo;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("synth", &Instrument::synth_lead())
    ///     .tremolo(Tremolo::new(5.0, 0.7))
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn tremolo(mut self, tremolo: Tremolo) -> Self {
        let track = self.get_track_mut();
        track.effects.tremolo = Some(tremolo);
        track.effects.compute_effect_order();
        self
    }

    /// Add auto-pan effect to this track
    ///
    /// AutoPan creates automatic stereo panning modulation for movement in the stereo field.
    ///
    /// # Arguments
    /// * `autopan` - AutoPan effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::AutoPan;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("pad", &Instrument::warm_pad())
    ///     .autopan(AutoPan::new(0.5, 0.8))
    ///     .note(&[C4, E4, G4], 4.0);
    /// ```
    pub fn autopan(mut self, autopan: AutoPan) -> Self {
        let track = self.get_track_mut();
        track.effects.autopan = Some(autopan);
        // Note: AutoPan is not in effect_order (handled separately in stereo stage)
        self
    }

    /// Add gate effect to this track
    ///
    /// Gate reduces the level of signals below a threshold, useful for noise reduction
    /// or creating rhythmic gating effects.
    ///
    /// # Arguments
    /// * `gate` - Gate effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Gate;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("drums", &Instrument::synth_lead())
    ///     .gate(Gate::new(-40.0, 10.0, 0.001, 0.05))
    ///     .note(&[C4], 1.0);
    /// ```
    pub fn gate(mut self, gate: Gate) -> Self {
        let track = self.get_track_mut();
        track.effects.gate = Some(gate);
        track.effects.compute_effect_order();
        self
    }

    /// Add limiter effect to this track
    ///
    /// Limiter prevents the signal from exceeding a threshold, acting as a safety net
    /// against clipping. Typically used as the final stage in the signal chain.
    ///
    /// # Arguments
    /// * `limiter` - Limiter effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::Limiter;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("master", &Instrument::synth_lead())
    ///     .limiter(Limiter::new(-0.1, 0.05))
    ///     .note(&[C4], 1.0);
    /// ```
    pub fn limiter(mut self, limiter: Limiter) -> Self {
        let track = self.get_track_mut();
        track.effects.limiter = Some(limiter);
        track.effects.compute_effect_order();
        self
    }

    /// Add phase vocoder effect for time-stretching and pitch-shifting
    ///
    /// Phase vocoder allows independent control of time and pitch using STFT analysis.
    /// Perfect for creative time/pitch manipulation with phase coherence preservation.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `phase_vocoder` - PhaseVocoder effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::PhaseVocoder;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Pitch up a perfect fifth without changing duration
    /// let vocoder = PhaseVocoder::new(1.0, 7.0, 44100.0);
    ///
    /// comp.instrument("vocals", &Instrument::synth_lead())
    ///     .phase_vocoder(vocoder)
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn phase_vocoder(mut self, phase_vocoder: PhaseVocoder) -> Self {
        let track = self.get_track_mut();
        track.effects.phase_vocoder = Some(phase_vocoder);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral freeze effect for capturing and holding frequency spectrum
    ///
    /// Spectral freeze captures the current frequency content and holds it indefinitely,
    /// creating sustained "frozen" sounds. Perfect for ambient textures, drones, and
    /// evolving soundscapes from transient sounds.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_freeze` - SpectralFreeze effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralFreeze;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Freeze the spectrum and mix with live signal (75% frozen, 25% live)
    /// let freeze = SpectralFreeze::new(true, 0.75, 44100.0);
    ///
    /// comp.instrument("ambient", &Instrument::warm_pad())
    ///     .spectral_freeze(freeze)
    ///     .note(&[A3], 4.0);
    /// ```
    pub fn spectral_freeze(mut self, spectral_freeze: SpectralFreeze) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_freeze = Some(spectral_freeze);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral gate effect for frequency-selective noise gating
    ///
    /// Spectral gate applies independent gating to each frequency bin, enabling surgical
    /// noise reduction. Unlike traditional gates that gate the entire signal, spectral gate
    /// can remove hum, hiss, and unwanted frequencies while preserving the wanted signal.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_gate` - SpectralGate effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::instruments::Instrument;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralGate;
    /// # use tunes::consts::notes::*;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Remove noise below -40 dB per frequency bin
    /// let gate = SpectralGate::new(-40.0, 0.001, 0.050, 0.0, 44100.0);
    ///
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_gate(gate)
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_gate(mut self, spectral_gate: SpectralGate) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_gate = Some(spectral_gate);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral compressor effect for frequency-selective dynamic range compression
    ///
    /// Spectral compressor applies independent compression to each frequency bin, enabling
    /// multiband compression at extreme resolution (1024+ bands). This allows for surgical
    /// dynamic control that can't be achieved with traditional multiband compressors.
    ///
    /// # Use Cases
    ///
    /// - **Multiband Mastering**: 1024-band compression for ultimate control
    /// - **De-essing**: Compress harsh sibilance (6-8 kHz) without affecting rest of vocal
    /// - **Taming Resonances**: Control specific problem frequencies
    /// - **Creative Effects**: Per-frequency dynamics for unique textures
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    ///
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralCompressor;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // De-ess a vocal track
    /// let comp_effect = SpectralCompressor::new(-20.0, 4.0, 5.0, 50.0, 6.0, 44100.0);
    ///
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_compressor(comp_effect)
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_compressor(mut self, spectral_compressor: SpectralCompressor) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_compressor = Some(spectral_compressor);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral robotize effect for robotic/synthesized voice effects
    ///
    /// SpectralRobotize quantizes phase information while preserving magnitude spectrum,
    /// creating classic robot voice, whisper-to-speech, and synthesized vocal effects.
    ///
    /// # Use Cases
    /// - Robot Voice: Classic Kraftwerk/Daft Punk effects
    /// - Whisper to Speech: Convert whispered audio to synthesized speech
    /// - Creative FX: Dehumanize vocals, alien voices
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralRobotize;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// let robotize = SpectralRobotize::new(0.0, 1.0, 44100.0);
    ///
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_robotize(robotize)
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_robotize(mut self, spectral_robotize: SpectralRobotize) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_robotize = Some(spectral_robotize);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral delay effect for frequency-dependent delay times
    ///
    /// SpectralDelay creates shimmer, cascade, and spectral smearing effects by applying
    /// different delay times to different frequency bins in the spectrum.
    ///
    /// # Use Cases
    /// - Shimmer Effects: High frequencies delay longer (frequency_scale > 0)
    /// - Reverse Shimmer: Low frequencies delay longer (frequency_scale < 0)
    /// - Spectral Smearing: Frequency-dependent echo patterns
    /// - Creative Delays: Cascading delays with feedback
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralDelay;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// let delay = SpectralDelay::new(200.0, 0.5, 1.0, 0.7, 44100.0);
    ///
    /// comp.instrument("synth", &Instrument::warm_pad())
    ///     .spectral_delay(delay)
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_delay(mut self, spectral_delay: SpectralDelay) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_delay = Some(spectral_delay);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral filter for frequency-domain filtering
    ///
    /// SpectralFilter applies filtering in the frequency domain, allowing precise control
    /// over the frequency response with minimal artifacts. Unlike time-domain filters,
    /// spectral filtering can achieve brick-wall responses and frequency-dependent effects.
    ///
    /// # Use Cases
    /// - Surgical EQ: Brick-wall filtering with sharp cutoffs
    /// - Creative Effects: Resonant spectral filtering for unique timbres
    /// - Noise Reduction: Precise frequency removal
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_filter` - SpectralFilter effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralFilter;
    /// # use tunes::synthesis::spectral::FilterType;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Using a preset for quick setup
    /// comp.instrument("bass", &Instrument::sub_bass())
    ///     .spectral_filter(SpectralFilter::low_pass())
    ///     .note(&[C2], 2.0);
    ///
    /// // Or create with custom parameters
    /// let filter = SpectralFilter::new(FilterType::LowPass, 1000.0, 2.0, 1.0, 44100.0);
    /// comp.instrument("synth", &Instrument::synth_lead())
    ///     .spectral_filter(filter)
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_filter(mut self, spectral_filter: SpectralFilter) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_filter = Some(spectral_filter);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral blur for temporal smoothing in frequency domain
    ///
    /// Creates smooth, ambient textures by blending current spectrum with previous frames.
    /// Perfect for pads, ambient soundscapes, and ethereal effects.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_blur` - SpectralBlur effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralBlur;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Using a preset for quick setup
    /// comp.instrument("pad", &Instrument::warm_pad())
    ///     .spectral_blur(SpectralBlur::gentle())
    ///     .note(&[C4], 2.0);
    ///
    /// // Or create with custom parameters
    /// let blur = SpectralBlur::new(0.7, 0.5, 0.8, 44100.0);
    /// comp.instrument("ambient", &Instrument::warm_pad())
    ///     .spectral_blur(blur)
    ///     .note(&[A3], 2.0);
    /// ```
    pub fn spectral_blur(mut self, spectral_blur: SpectralBlur) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_blur = Some(spectral_blur);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral shift for frequency shifting
    ///
    /// SpectralShift shifts the entire frequency spectrum up or down, creating pitch-like effects
    /// without time-stretching. Perfect for harmonizer effects, octave doubling, and detuning.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralShift;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("synth", &Instrument::synth_lead())
    ///     .spectral_shift(SpectralShift::subtle())
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_shift(mut self, spectral_shift: SpectralShift) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_shift = Some(spectral_shift);
        track.effects.compute_effect_order();
        self
    }

    /// Add formant shifter for vocal character transformation
    ///
    /// FormantShifter changes the spectral envelope (formants) independently from pitch,
    /// enabling vocal gender/age changes and character effects. Shift formants up for
    /// brighter/feminine sound, down for darker/masculine sound.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::FormantShifter;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .formant_shifter(FormantShifter::male_to_female())
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn formant_shifter(mut self, formant_shifter: FormantShifter) -> Self {
        let track = self.get_track_mut();
        track.effects.formant_shifter = Some(formant_shifter);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral harmonizer for pitch-shifted harmonies
    ///
    /// SpectralHarmonizer adds multiple pitch-shifted voices to create rich harmonies.
    /// Perfect for vocal harmonies, thick synth sounds, and choir effects.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralHarmonizer;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_harmonizer(SpectralHarmonizer::major_chord())
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_harmonizer(mut self, spectral_harmonizer: SpectralHarmonizer) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_harmonizer = Some(spectral_harmonizer);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral resonator for resonant frequency peaks
    ///
    /// SpectralResonator creates narrow resonant peaks at specified frequencies,
    /// perfect for bell timbres, vowel formants, harmonic enhancement, and metallic effects.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::prelude::*;
    /// # use tunes::synthesis::effects::{SpectralResonator, Resonance};
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("bell", &Instrument::warm_pad())
    ///     .spectral_resonator(SpectralResonator::bell())
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_resonator(mut self, spectral_resonator: SpectralResonator) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_resonator = Some(spectral_resonator);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral panner for frequency-based spatial positioning
    ///
    /// SpectralPanner positions different frequency ranges at different points in the
    /// stereo field. Perfect for game audio where you want spatial frequency effects
    /// (e.g., bass centered, highs wide, frequency sweeps).
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::prelude::*;
    /// # use tunes::synthesis::effects::SpectralPanner;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("ambience", &Instrument::warm_pad())
    ///     .spectral_panner(SpectralPanner::circular())
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_panner(mut self, spectral_panner: SpectralPanner) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_panner = Some(spectral_panner);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral exciter for harmonic enhancement
    ///
    /// SpectralExciter adds harmonically-related frequencies to enhance brightness and presence,
    /// similar to classic aural exciters but operating in the frequency domain.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralExciter;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_exciter(SpectralExciter::gentle())
    ///     .note(&[C4], 2.0);
    /// ```
    pub fn spectral_exciter(mut self, spectral_exciter: SpectralExciter) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_exciter = Some(spectral_exciter);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral invert for frequency spectrum reversal
    ///
    /// SpectralInvert flips the frequency spectrum (low ↔ high), creating surreal timbral
    /// transformations. Useful for creative sound design, alien voices, and experimental effects.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_invert` - SpectralInvert effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralInvert;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Using a preset for quick setup
    /// comp.instrument("synth", &Instrument::synth_lead())
    ///     .spectral_invert(SpectralInvert::full())
    ///     .note(&[C4], 2.0);
    ///
    /// // Or create with custom mix amount
    /// let invert = SpectralInvert::moderate();
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_invert(invert)
    ///     .note(&[A3], 2.0);
    /// ```
    pub fn spectral_invert(mut self, spectral_invert: SpectralInvert) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_invert = Some(spectral_invert);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral widen for stereo widening via phase manipulation
    ///
    /// SpectralWiden creates stereo width by applying frequency-dependent phase shifts,
    /// resulting in enhanced stereo imaging. Perfect for pads, synths, and ambient textures.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_widen` - SpectralWiden effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralWiden;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Using a preset for quick setup
    /// comp.instrument("pad", &Instrument::warm_pad())
    ///     .spectral_widen(SpectralWiden::wide())
    ///     .note(&[C4, E4, G4], 2.0);
    ///
    /// // Or create with custom parameters
    /// let widen = SpectralWiden::ultra();
    /// comp.instrument("synth", &Instrument::warm_pad())
    ///     .spectral_widen(widen)
    ///     .note(&[A3], 2.0);
    /// ```
    pub fn spectral_widen(mut self, spectral_widen: SpectralWiden) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_widen = Some(spectral_widen);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral morph for morphing spectrum toward target shapes
    ///
    /// SpectralMorph transforms the spectrum to match different target characteristics:
    /// harmonic structures, noise, whisper-like, or robotic timbres.
    ///
    /// **Note**: This is a block-based spectral effect with ~23ms latency @ 44.1kHz.
    ///
    /// # Arguments
    /// * `spectral_morph` - SpectralMorph effect instance
    ///
    /// # Example
    /// ```
    /// # use tunes::composition::Composition;
    /// # use tunes::composition::timing::Tempo;
    /// # use tunes::synthesis::effects::SpectralMorph;
    /// # use tunes::consts::notes::*;
    /// # use tunes::instruments::Instrument;
    /// # let mut comp = Composition::new(Tempo::new(120.0));
    /// // Using presets for quick setup
    /// comp.instrument("vocal", &Instrument::warm_pad())
    ///     .spectral_morph(SpectralMorph::robot())
    ///     .note(&[C4], 2.0);
    ///
    /// // Other presets available
    /// comp.instrument("synth", &Instrument::synth_lead())
    ///     .spectral_morph(SpectralMorph::harmonic())
    ///     .note(&[A3], 2.0);
    /// ```
    pub fn spectral_morph(mut self, spectral_morph: SpectralMorph) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_morph = Some(spectral_morph);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral dynamics effect for frequency-dependent compression/expansion
    pub fn spectral_dynamics(mut self, spectral_dynamics: SpectralDynamics) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_dynamics = Some(spectral_dynamics);
        track.effects.compute_effect_order();
        self
    }

    /// Add spectral scramble effect for glitchy frequency bin randomization
    pub fn spectral_scramble(mut self, spectral_scramble: SpectralScramble) -> Self {
        let track = self.get_track_mut();
        track.effects.spectral_scramble = Some(spectral_scramble);
        track.effects.compute_effect_order();
        self
    }

    /// Add an LFO modulation route to this track
    pub fn modulate(mut self, mod_route: ModRoute) -> Self {
        self.get_track_mut().modulation.push(mod_route);
        self
    }
}

#[cfg(test)]
mod tests {
    use crate::composition::Composition;
    use crate::synthesis::effects::*;
    use crate::synthesis::filter::{Filter, FilterType};
    use crate::synthesis::lfo::{LFO, ModRoute, ModTarget};
    use crate::consts::notes::*;
    use crate::composition::timing::Tempo;
    use crate::synthesis::waveform::Waveform;

    #[test]
    fn test_filter_sets_track_filter() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let filter = Filter::new(FilterType::LowPass, 1000.0, 0.7);
        comp.track("test").filter(filter);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(matches!(track.filter.filter_type, FilterType::LowPass));
        assert_eq!(track.filter.cutoff, 1000.0);
        assert_eq!(track.filter.resonance, 0.7);
    }

    #[test]
    fn test_delay_sets_track_delay() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let delay = Delay::new(0.5, 0.4, 0.6);
        comp.track("test").delay(delay);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.delay.is_some());
        let track_delay = track.effects.delay.as_ref().unwrap();
        assert_eq!(track_delay.delay_time, 0.5);
        assert_eq!(track_delay.feedback, 0.4);
        assert_eq!(track_delay.mix, 0.6);
    }

    #[test]
    fn test_reverb_sets_track_reverb() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let reverb = Reverb::new(0.8, 0.5, 0.3);
        comp.track("test").reverb(reverb);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.reverb.is_some());
        let track_reverb = track.effects.reverb.as_ref().unwrap();
        assert_eq!(track_reverb.room_size, 0.8);
        assert_eq!(track_reverb.damping, 0.5);
        assert_eq!(track_reverb.mix, 0.3);
    }

    #[test]
    fn test_distortion_sets_track_distortion() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let distortion = Distortion::new(2.0, 0.5);
        comp.track("test").distortion(distortion);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.distortion.is_some());
        let track_dist = track.effects.distortion.as_ref().unwrap();
        assert_eq!(track_dist.drive, 2.0);
        assert_eq!(track_dist.mix, 0.5);
    }

    #[test]
    fn test_bitcrusher_sets_track_bitcrusher() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let bitcrusher = BitCrusher::new(4.0, 8.0, 0.5);
        comp.track("test").bitcrusher(bitcrusher);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.bitcrusher.is_some());
        let track_bc = track.effects.bitcrusher.as_ref().unwrap();
        assert_eq!(track_bc.bit_depth, 4.0);
        assert_eq!(track_bc.sample_rate_reduction, 8.0);
        assert_eq!(track_bc.mix, 0.5);
    }

    #[test]
    fn test_compressor_sets_track_compressor() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let compressor = Compressor::new(0.3, 4.0, 0.01, 0.1, 2.0);
        comp.track("test").compressor(compressor);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.compressor.is_some());
        let track_comp = track.effects.compressor.as_ref().unwrap();
        assert_eq!(track_comp.threshold, 0.3);
        assert_eq!(track_comp.ratio, 4.0);
        assert_eq!(track_comp.attack, 0.01);
        assert_eq!(track_comp.release, 0.1);
        assert_eq!(track_comp.makeup_gain, 2.0);
    }

    #[test]
    fn test_chorus_sets_track_chorus() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let chorus = Chorus::new(0.5, 2.0, 0.3);
        comp.track("test").chorus(chorus);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.chorus.is_some());
        let track_chorus = track.effects.chorus.as_ref().unwrap();
        assert_eq!(track_chorus.rate, 0.5);
        assert_eq!(track_chorus.depth, 2.0);
        assert_eq!(track_chorus.mix, 0.3);
    }

    #[test]
    fn test_eq_sets_track_eq() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let eq = EQ::new(2.0, 1.0, 0.5, 200.0, 2000.0);
        comp.track("test").eq(eq);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.eq.is_some());
        let track_eq = track.effects.eq.as_ref().unwrap();
        assert_eq!(track_eq.low_gain, 2.0);
        assert_eq!(track_eq.mid_gain, 1.0);
        assert_eq!(track_eq.high_gain, 0.5);
        assert_eq!(track_eq.low_freq, 200.0);
        assert_eq!(track_eq.high_freq, 2000.0);
    }

    #[test]
    fn test_saturation_sets_track_saturation() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let saturation = Saturation::new(2.0, 0.5, 0.7);
        comp.track("test").saturation(saturation);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.saturation.is_some());
        let track_sat = track.effects.saturation.as_ref().unwrap();
        assert_eq!(track_sat.drive, 2.0);
        assert_eq!(track_sat.character, 0.5);
        assert_eq!(track_sat.mix, 0.7);
    }

    #[test]
    fn test_phaser_sets_track_phaser() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let phaser = Phaser::new(0.5, 0.7, 0.5, 4, 0.5);
        comp.track("test").phaser(phaser);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.phaser.is_some());
        let track_phaser = track.effects.phaser.as_ref().unwrap();
        assert_eq!(track_phaser.rate, 0.5);
        assert_eq!(track_phaser.depth, 0.7);
        assert_eq!(track_phaser.feedback, 0.5);
        assert_eq!(track_phaser.mix, 0.5);
        assert_eq!(track_phaser.stages, 4);
    }

    #[test]
    fn test_flanger_sets_track_flanger() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let flanger = Flanger::new(0.5, 3.0, 0.6, 0.5);
        comp.track("test").flanger(flanger);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.flanger.is_some());
        let track_flanger = track.effects.flanger.as_ref().unwrap();
        assert_eq!(track_flanger.rate, 0.5);
        assert_eq!(track_flanger.depth, 3.0);
        assert_eq!(track_flanger.feedback, 0.6);
        assert_eq!(track_flanger.mix, 0.5);
    }

    #[test]
    fn test_ring_mod_sets_track_ring_mod() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let ring_mod = RingModulator::new(440.0, 0.7);
        comp.track("test").ring_mod(ring_mod);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.ring_mod.is_some());
        let track_ring = track.effects.ring_mod.as_ref().unwrap();
        assert_eq!(track_ring.carrier_freq, 440.0);
        assert_eq!(track_ring.mix, 0.7);
    }

    #[test]
    fn test_modulate_adds_modulation_route() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let lfo = LFO::new(Waveform::Sine, 5.0, 0.5);
        let mod_route = ModRoute::new(lfo, ModTarget::Pitch, 1.0);
        comp.track("test").modulate(mod_route);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert_eq!(track.modulation.len(), 1);
    }

    #[test]
    fn test_modulate_multiple_routes() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let lfo1 = LFO::new(Waveform::Sine, 5.0, 0.5);
        let lfo2 = LFO::new(Waveform::Triangle, 3.0, 0.3);
        comp.track("test")
            .modulate(ModRoute::new(lfo1, ModTarget::Pitch, 1.0))
            .modulate(ModRoute::new(lfo2, ModTarget::FilterCutoff, 0.5));

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert_eq!(track.modulation.len(), 2);
    }

    #[test]
    fn test_effect_chaining() {
        let mut comp = Composition::new(Tempo::new(120.0));
        comp.track("fx_chain")
            .filter(Filter::new(FilterType::LowPass, 2000.0, 0.5))
            .delay(Delay::new(0.5, 0.3, 0.5))
            .reverb(Reverb::new(0.8, 0.4, 0.4))
            .distortion(Distortion::new(1.5, 0.6));

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(matches!(track.filter.filter_type, FilterType::LowPass));
        assert!(track.effects.delay.is_some());
        assert!(track.effects.reverb.is_some());
        assert!(track.effects.distortion.is_some());
    }

    #[test]
    fn test_all_effects_combined() {
        let mut comp = Composition::new(Tempo::new(120.0));
        comp.track("everything")
            .filter(Filter::new(FilterType::BandPass, 1000.0, 0.7))
            .delay(Delay::new(0.25, 0.5, 0.6))
            .reverb(Reverb::new(0.7, 0.5, 0.3))
            .distortion(Distortion::new(2.0, 0.4))
            .bitcrusher(BitCrusher::new(8.0, 4.0, 0.3))
            .compressor(Compressor::new(0.2, 3.0, 0.01, 0.1, 1.5))
            .chorus(Chorus::new(0.8, 3.0, 0.4))
            .eq(EQ::new(1.5, 1.0, 0.8, 250.0, 3000.0))
            .saturation(Saturation::new(1.8, 0.6, 0.5))
            .phaser(Phaser::new(0.4, 0.6, 0.7, 6, 0.5))
            .flanger(Flanger::new(0.6, 2.5, 0.7, 0.4))
            .ring_mod(RingModulator::new(550.0, 0.3));

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        // Verify all effects are set
        assert!(matches!(track.filter.filter_type, FilterType::BandPass));
        assert!(track.effects.delay.is_some());
        assert!(track.effects.reverb.is_some());
        assert!(track.effects.distortion.is_some());
        assert!(track.effects.bitcrusher.is_some());
        assert!(track.effects.compressor.is_some());
        assert!(track.effects.chorus.is_some());
        assert!(track.effects.eq.is_some());
        assert!(track.effects.saturation.is_some());
        assert!(track.effects.phaser.is_some());
        assert!(track.effects.flanger.is_some());
        assert!(track.effects.ring_mod.is_some());
    }

    #[test]
    fn test_effects_with_notes() {
        let mut comp = Composition::new(Tempo::new(120.0));
        comp.track("effected")
            .delay(Delay::new(0.5, 0.4, 0.6))
            .reverb(Reverb::new(0.6, 0.5, 0.4))
            .note(&[C4], 1.0);

        let mixer = comp.into_mixer();
        assert!(mixer.tracks()[0].effects.delay.is_some());
        assert!(mixer.tracks()[0].effects.reverb.is_some());
        assert_eq!(mixer.tracks()[0].events.len(), 1);
    }

    #[test]
    fn test_filter_different_types() {
        let mut comp = Composition::new(Tempo::new(120.0));

        comp.track("lp")
            .filter(Filter::new(FilterType::LowPass, 1000.0, 0.5));
        comp.track("hp")
            .filter(Filter::new(FilterType::HighPass, 500.0, 0.7));
        comp.track("bp")
            .filter(Filter::new(FilterType::BandPass, 800.0, 0.6));

        let mixer = comp.into_mixer();
        assert_eq!(mixer.tracks().len(), 3);

        // Check that all three filter types exist (HashMap order not guaranteed)
        let has_lowpass = mixer
.tracks()
            .iter()
            .any(|t| matches!(t.filter.filter_type, FilterType::LowPass));
        let has_highpass = mixer
.tracks()
            .iter()
            .any(|t| matches!(t.filter.filter_type, FilterType::HighPass));
        let has_bandpass = mixer
.tracks()
            .iter()
            .any(|t| matches!(t.filter.filter_type, FilterType::BandPass));

        assert!(has_lowpass, "Should have a LowPass filter");
        assert!(has_highpass, "Should have a HighPass filter");
        assert!(has_bandpass, "Should have a BandPass filter");
    }

    #[test]
    fn test_delay_replaces_previous_delay() {
        let mut comp = Composition::new(Tempo::new(120.0));
        comp.track("test")
            .delay(Delay::new(0.5, 0.4, 0.5))
            .delay(Delay::new(0.25, 0.6, 0.7));

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.delay.is_some());
        let delay = track.effects.delay.as_ref().unwrap();
        assert_eq!(delay.delay_time, 0.25);
        assert_eq!(delay.feedback, 0.6);
        assert_eq!(delay.mix, 0.7);
    }

    #[test]
    fn test_reverb_replaces_previous_reverb() {
        let mut comp = Composition::new(Tempo::new(120.0));
        comp.track("test")
            .reverb(Reverb::new(0.8, 0.5, 0.6))
            .reverb(Reverb::new(0.3, 0.2, 0.4));

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        assert!(track.effects.reverb.is_some());
        let reverb = track.effects.reverb.as_ref().unwrap();
        assert_eq!(reverb.room_size, 0.3);
        assert_eq!(reverb.damping, 0.2);
        assert_eq!(reverb.mix, 0.4);
    }

    #[test]
    fn test_effects_dont_affect_cursor() {
        let mut comp = Composition::new(Tempo::new(120.0));
        comp.track("test")
            .delay(Delay::new(0.5, 0.4, 0.5))
            .reverb(Reverb::new(0.8, 0.5, 0.4))
            .distortion(Distortion::new(2.0, 0.5));

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        // Just verify that effects were set successfully
        assert!(track.effects.delay.is_some());
        assert!(track.effects.reverb.is_some());
        assert!(track.effects.distortion.is_some());
    }

    #[test]
    fn test_bitcrusher_parameters() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let bc = BitCrusher::new(6.0, 10.0, 0.8);
        comp.track("crushed").bitcrusher(bc);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        let track_bc = track.effects.bitcrusher.as_ref().unwrap();
        assert_eq!(track_bc.bit_depth, 6.0);
        assert_eq!(track_bc.sample_rate_reduction, 10.0);
        assert_eq!(track_bc.mix, 0.8);
    }

    #[test]
    fn test_compressor_full_parameters() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let comp_fx = Compressor::new(0.25, 6.0, 0.005, 0.2, 3.0);
        comp.track("compressed").compressor(comp_fx);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        let track_comp = track.effects.compressor.as_ref().unwrap();
        assert_eq!(track_comp.threshold, 0.25);
        assert_eq!(track_comp.ratio, 6.0);
        assert_eq!(track_comp.attack, 0.005);
        assert_eq!(track_comp.release, 0.2);
        assert_eq!(track_comp.makeup_gain, 3.0);
    }

    #[test]
    fn test_chorus_parameters() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let chorus = Chorus::new(1.2, 4.0, 0.6);
        comp.track("chorus").chorus(chorus);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        let track_chorus = track.effects.chorus.as_ref().unwrap();
        assert_eq!(track_chorus.rate, 1.2);
        assert_eq!(track_chorus.depth, 4.0);
        assert_eq!(track_chorus.mix, 0.6);
    }

    #[test]
    fn test_eq_boost_and_cut() {
        let mut comp = Composition::new(Tempo::new(120.0));
        // Boost lows, cut mids, boost highs
        let eq = EQ::new(1.5, 0.5, 1.8, 100.0, 5000.0);
        comp.track("eq").eq(eq);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        let track_eq = track.effects.eq.as_ref().unwrap();
        assert_eq!(track_eq.low_gain, 1.5);
        assert_eq!(track_eq.mid_gain, 0.5);
        assert_eq!(track_eq.high_gain, 1.8);
    }

    #[test]
    fn test_saturation_parameters() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let sat = Saturation::new(3.0, 0.8, 0.9);
        comp.track("saturated").saturation(sat);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        let track_sat = track.effects.saturation.as_ref().unwrap();
        assert_eq!(track_sat.drive, 3.0);
        assert_eq!(track_sat.character, 0.8);
        assert_eq!(track_sat.mix, 0.9);
    }

    #[test]
    fn test_phaser_stages() {
        let mut comp = Composition::new(Tempo::new(120.0));
        let phaser = Phaser::new(0.3, 0.8, 0.6, 8, 0.7);
        comp.track("phased").phaser(phaser);

        let mixer = comp.into_mixer();
        let track = &mixer.tracks()[0];
        let track_phaser = track.effects.phaser.as_ref().unwrap();
        assert_eq!(track_phaser.stages, 8);
        assert_eq!(track_phaser.rate, 0.3);
    }

    #[test]
    fn test_flanger_vs_chorus_depth() {
        let mut comp = Composition::new(Tempo::new(120.0));

        // Flanger has larger depth (measured in ms)
        let flanger = Flanger::new(0.5, 5.0, 0.7, 0.5);
        comp.track("flanger").flanger(flanger);

        // Chorus has typical depth (measured in milliseconds)
        let chorus = Chorus::new(0.5, 3.0, 0.5);
        comp.track("chorus").chorus(chorus);

        let mixer = comp.into_mixer();
        assert_eq!(mixer.tracks().len(), 2);

        // Check that both effects exist with correct depths (HashMap order not guaranteed)
        let has_flanger_5 = mixer
.tracks()
            .iter()
            .any(|t| t.effects.flanger.as_ref().map_or(false, |f| f.depth == 5.0));
        let has_chorus_3 = mixer
.tracks()
            .iter()
            .any(|t| t.effects.chorus.as_ref().map_or(false, |c| c.depth == 3.0));

        assert!(has_flanger_5, "Should have flanger with depth 5.0");
        assert!(has_chorus_3, "Should have chorus with depth 3.0");
    }

    #[test]
    fn test_ring_mod_carrier_frequency() {
        let mut comp = Composition::new(Tempo::new(120.0));

        // Test different carrier frequencies
        let ring1 = RingModulator::new(200.0, 0.5);
        comp.track("ring1").ring_mod(ring1);

        let ring2 = RingModulator::new(880.0, 0.8);
        comp.track("ring2").ring_mod(ring2);

        let mixer = comp.into_mixer();
        assert_eq!(mixer.tracks().len(), 2);

        // Check that both ring modulators exist with correct frequencies (HashMap order not guaranteed)
        let has_200hz = mixer.tracks().iter().any(|t| {
            t.effects.ring_mod
                .as_ref()
                .map_or(false, |rm| rm.carrier_freq == 200.0)
        });
        let has_880hz = mixer.tracks().iter().any(|t| {
            t.effects.ring_mod
                .as_ref()
                .map_or(false, |rm| rm.carrier_freq == 880.0)
        });

        assert!(has_200hz, "Should have ring modulator with 200Hz carrier");
        assert!(has_880hz, "Should have ring modulator with 880Hz carrier");
    }
}
