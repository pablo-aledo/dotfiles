# Game Engine Integration

Tunes is **framework-agnostic** and integrates trivially with any Rust game engine. No wrapper crate needed - just store `AudioEngine` in your game state and call `play_sample()`.

> **Universal Pattern:** All Rust game engines follow the same pattern: create `AudioEngine`, store it, call methods.

## Table of Contents

- [Integration Pattern](#integration-pattern)
- [Bevy](#bevy)
  - [Complete Example](#complete-example)
  - [Tips](#tips)
    - [Pre-loading Sounds](#pre-loading-sounds)
    - [Volume Control](#volume-control)
    - [Stopping Sounds](#stopping-sounds)
  - [Performance](#performance)
  - [GPU Acceleration for Games](#gpu-acceleration-for-games)
  - [Advanced: Using Composition System](#advanced-using-composition-system)
- [ggez](#ggez)
- [macroquad](#macroquad)
- [bracket-lib](#bracket-lib)
- [Custom Engine](#custom-engine)
- [Performance Across All Engines](#performance-across-all-engines)

---

## Integration Pattern

The integration pattern is identical across all engines:

1. **Add dependency:** `tunes = "1.1.0"` in `Cargo.toml`
2. **Create engine:** `AudioEngine::new()` or `AudioEngine::new_with_gpu()`
3. **Store in game state:** Engine resource, struct field, or global
4. **Call from game logic:** `engine.play_sample("sound.wav")`

---

## Bevy

Bevy integration uses the ECS resource system.

**1. Add dependencies to `Cargo.toml`:**

```toml
[dependencies]
bevy = "0.14"
tunes = "1.1.0"
```

**2. Create the AudioEngine resource:**

**Option A: Simple (Recommended)**

```rust
use bevy::prelude::*;
use tunes::prelude::*;

fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .insert_resource(AudioEngine::new().expect("Failed to initialize audio engine"))
        .add_systems(Update, game_audio_system)
        .run();
}
```

**Option B: With Startup System**

```rust
fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .add_systems(Startup, setup_audio)
        .add_systems(Update, game_audio_system)
        .run();
}

fn setup_audio(mut commands: Commands) {
    let engine = AudioEngine::new().expect("Failed to initialize audio");
    commands.insert_resource(engine);
}
```

**Option C: With GPU Acceleration (Optional)**

```rust
fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .insert_resource(AudioEngine::new_with_gpu().expect("Failed to initialize audio engine with GPU"))
        .add_systems(Update, game_audio_system)
        .run();
}
```

> **Note:** GPU acceleration provides marginal benefit for typical game audio workloads. Integrated GPUs (Intel HD, AMD Vega) show ~1.0x performance vs CPU. Discrete GPUs (RTX, RX series) may show 2-5x improvement for synthesis-heavy workloads. CPU performance (50-70x realtime) is sufficient for most games.

**3. Play audio from any system:**

```rust
fn game_audio_system(
    engine: Res<AudioEngine>,
    keyboard: Res<ButtonInput<KeyCode>>,
) {
    // Play samples in response to events
    if keyboard.just_pressed(KeyCode::Space) {
        engine.play_sample("assets/audio/jump.wav")
            .expect("Failed to play jump sound");
    }

    if keyboard.just_pressed(KeyCode::KeyF) {
        engine.play_sample("assets/audio/shoot.wav")
            .expect("Failed to play shoot sound");
    }
}
```

The AudioEngine handles:
- Caching (repeated sounds use Arc-based sharing)
- Concurrent playback (100+ sounds simultaneously)
- SIMD acceleration (47x realtime measured)
- Multi-core parallelism (Rayon, 54x realtime measured)
- Automatic mixing (zero-copy where possible)
- Optional GPU acceleration

## Complete Example

```rust
use bevy::prelude::*;
use tunes::prelude::*;

#[derive(Component)]
struct Player;

fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .add_systems(Startup, (setup_audio, setup_game))
        .add_systems(Update, (
            player_movement,
            collision_system,
        ))
        .run();
}

fn setup_audio(mut commands: Commands) {
    let engine = AudioEngine::new().expect("Failed to initialize audio");

    // Optional: Pre-load sounds during startup
    engine.preload_sample("assets/audio/footstep.wav").ok();
    engine.preload_sample("assets/audio/jump.wav").ok();
    engine.preload_sample("assets/audio/coin.wav").ok();

    commands.insert_resource(engine);
}

fn setup_game(mut commands: Commands) {
    // Spawn player
    commands.spawn((
        Player,
        SpriteBundle::default(),
    ));
}

fn player_movement(
    keyboard: Res<ButtonInput<KeyCode>>,
    engine: Res<AudioEngine>,
    mut query: Query<&mut Transform, With<Player>>,
) {
    if let Ok(mut transform) = query.get_single_mut() {
        let speed = 5.0;

        if keyboard.pressed(KeyCode::ArrowLeft) {
            transform.translation.x -= speed;
            if keyboard.just_pressed(KeyCode::ArrowLeft) {
                engine.play_sample("assets/audio/footstep.wav")
                    .expect("Failed to play footstep sound");
            }
        }

        if keyboard.just_pressed(KeyCode::Space) {
            // Jump!
            engine.play_sample("assets/audio/jump.wav")
                .expect("Failed to play jump sound");
        }
    }
}

fn collision_system(
    engine: Res<AudioEngine>,
    // ... your collision logic here
) {
    // Play sound on collision
    engine.play_sample("assets/audio/coin.wav")
        .expect("Failed to play coin sound");
}
```

## Tips

### Pre-loading Sounds

Pre-load frequently-used sounds during `Startup` to avoid first-play delay:

```rust
fn setup_audio(mut commands: Commands) {
    let engine = AudioEngine::new().expect("Failed to initialize audio engine");

    // Pre-load common sounds
    engine.preload_sample("assets/audio/footstep.wav").ok();
    engine.preload_sample("assets/audio/jump.wav").ok();
    engine.preload_sample("assets/audio/hurt.wav").ok();

    commands.insert_resource(engine);
}
```

### Volume Control

Use `play_mixer_realtime()` if you need to control sounds after playing:

```rust
#[derive(Resource)]
struct MusicHandle(SoundId);

fn play_music(mut commands: Commands, engine: Res<AudioEngine>) {
    let mut comp = Composition::new(Tempo::new(120.0));
    comp.instrument("bgm", &Instrument::synth_pad())
        .notes(&[C4, E4, G4], 2.0);

    let mixer = comp.into_mixer();

    // Use play_mixer_realtime() to get a SoundId for later control
    let id = engine.play_mixer_realtime(&mixer)
        .expect("Failed to play music");

    // Store handle for later control
    commands.insert_resource(MusicHandle(id));
}

fn adjust_music_volume(
    engine: Res<AudioEngine>,
    handle: Res<MusicHandle>,
) {
    engine.set_volume(handle.0, 0.5).ok(); // 50% volume
}
```

> **💡 Tip:** `play_sample()` is fire-and-forget. Use `play_mixer_realtime()` when you need a `SoundId` to control volume, panning, or stop the sound later.

### Stopping Sounds

```rust
fn stop_all_audio(engine: Res<AudioEngine>) {
    // Returns Result, handle with .ok() or .expect()
    engine.stop_all().ok();
}

fn stop_specific_sound(
    engine: Res<AudioEngine>,
    handle: Res<MusicHandle>,
) {
    engine.stop(handle.0).ok();
}
```

## Performance

Tunes provides real-time game audio performance:

**Measured on i5-6500 @ 3.2GHz:**
- **47x realtime** with 50 concurrent samples (SIMD acceleration)
- **54x realtime** with multi-core parallelism (Rayon)
- **68x realtime** for CPU synthesis baseline
- **50x realtime** with GPU acceleration on Intel HD 530 (integrated)
- **~100-300x realtime** with GPU acceleration on discrete GPUs (estimated)

**Technical details:**
- Zero allocations in audio callback
- SIMD vectorization (AVX2/SSE/NEON) automatic
- Block processing (512-sample chunks)
- Lock-free sample playback where possible
- Automatic cache management (LRU eviction)

**Your game loop won't be blocked by audio playback.** Audio rendering happens on a dedicated thread with lock-free communication.

## GPU Acceleration for Games

GPU acceleration is available but provides marginal benefit for typical game audio workloads:

```rust
fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .insert_resource(AudioEngine::new_with_gpu().expect("Failed to initialize audio engine with GPU"))
        .add_systems(Update, game_audio)
        .run();
}
```

**Performance reality:**
- **Integrated GPUs (Intel HD, AMD Vega)**: ~1.0x vs CPU (no benefit)
- **Discrete GPUs (RTX, RX)**: ~2-5x vs CPU for synthesis (modest benefit)
- **CPU baseline**: Already 50-70x realtime (excellent!)

**When GPU helps:**
- Pre-rendering 100+ unique sounds at startup
- Extreme polyphony (500+ simultaneous synthesized voices)
- Synthesis-heavy procedural audio

**Example: Procedural laser sounds**

```rust
use tunes::synthesis::fm_synthesis::FMParams;

fn spawn_projectiles(
    mut commands: Commands,
    engine: Res<AudioEngine>,
) {
    for i in 0..100 {
        // Each projectile gets a unique synthesized sound
        let freq = 200.0 + (i as f32 * 5.0);

        let mut comp = Composition::new(Tempo::new(140.0));
        comp.track("laser")
            .note(&[freq], 0.05)
            .fm(FMParams::new(3.0, 8.0));

        engine.play_mixer(&comp.into_mixer_with_gpu()).ok();

        commands.spawn(ProjectileBundle { /* ... */ });
    }
}
```

**Performance comparison:**
- **CPU**: ~1,500 notes/second (Intel HD 530 measured: 243 notes/sec cached)
- **GPU (integrated)**: ~243 notes/second (1.0x speedup)
- **GPU (discrete, estimated)**: ~500-1,200 notes/second (2-5x speedup)

**For most games**: Use `AudioEngine::new()` (CPU-only). The 50-70x realtime performance is already excellent for typical game audio needs. GPU acceleration is optional and provides limited benefit unless you're doing extreme synthesis workloads.

## Advanced: Using Composition System

For dynamic music or complex audio, use the composition system:

```rust
fn play_dynamic_music(
    mut commands: Commands,
    engine: Res<AudioEngine>,
) {
    let mut comp = Composition::new(Tempo::new(120.0));

    // Create adaptive music
    comp.instrument("melody", &Instrument::synth_lead())
        .notes(&[C4, E4, G4, C5], 0.5);

    comp.track("drums")
        .drum_grid(16, 0.125, |g| g
            .sound(DrumType::Kick, &[0, 4, 8, 12])
            .sound(DrumType::Snare, &[4, 12]));

    let mixer = comp.into_mixer();
    engine.play_mixer(&mixer).ok();
}
```

See the [Composition chapter](../concepts/composition.md) for more details.

---

## ggez

ggez integration stores `AudioEngine` in your game state struct.

**Setup:**

```toml
[dependencies]
ggez = "0.9"
tunes = "1.1.0"
```

**Basic Integration:**

```rust
use ggez::event::{self, EventHandler};
use ggez::{Context, GameResult};
use tunes::prelude::*;

struct GameState {
    audio: AudioEngine,
    // ... other game state ...
}

impl GameState {
    fn new() -> GameResult<GameState> {
        Ok(GameState {
            audio: AudioEngine::new_with_gpu().expect("Failed to initialize audio engine with GPU"),
        })
    }
}

impl EventHandler for GameState {
    fn update(&mut self, _ctx: &mut Context) -> GameResult {
        // Play audio from game logic
        if some_collision {
            self.audio.play_sample("assets/explosion.wav")
                .expect("Failed to play explosion sound");
        }
        Ok(())
    }

    fn draw(&mut self, _ctx: &mut Context) -> GameResult {
        Ok(())
    }
}

fn main() -> GameResult {
    let (ctx, event_loop) = ggez::ContextBuilder::new("game", "author")
        .build()?;
    let state = GameState::new()?;
    event::run(ctx, event_loop, state)
}
```

**Key Points:**
- Store `AudioEngine` in `GameState` struct
- Create in `new()` with `AudioEngine::new()` or `new_with_gpu()`
- Call `play_sample()` from `update()` or `draw()`

---

## macroquad

macroquad integration is the simplest - just create `AudioEngine` at the start of `main()`.

**Setup:**

```toml
[dependencies]
macroquad = "0.4"
tunes = "1.1.0"
```

**Basic Integration:**

```rust
use macroquad::prelude::*;
use tunes::prelude::*;

#[macroquad::main("Game")]
async fn main() {
    // Create audio engine (GPU-accelerated for max performance)
    let audio = AudioEngine::new_with_gpu().expect("Failed to initialize audio engine with GPU");

    // Pre-load common sounds
    audio.preload_sample("assets/jump.wav").ok();
    audio.preload_sample("assets/coin.wav").ok();

    loop {
        // Game logic
        if is_key_pressed(KeyCode::Space) {
            audio.play_sample("assets/jump.wav")
                .expect("Failed to play jump sound");
        }

        if is_mouse_button_pressed(MouseButton::Left) {
            audio.play_sample("assets/shoot.wav")
                .expect("Failed to play shoot sound");
        }

        // Draw
        clear_background(BLACK);
        draw_text("Press SPACE to jump", 10.0, 20.0, 30.0, WHITE);

        next_frame().await
    }
}
```

**Key Points:**
- Create `AudioEngine` once at start of `main()`
- Use directly in game loop (no state struct needed)
- Works seamlessly with macroquad's async model

---

## bracket-lib

bracket-lib (formerly RLTK) integration uses the state pattern.

**Setup:**

```toml
[dependencies]
bracket-lib = "0.8"
tunes = "1.1.0"
```

**Basic Integration:**

```rust
use bracket_lib::prelude::*;
use tunes::prelude::*;

struct State {
    audio: AudioEngine,
}

impl GameState for State {
    fn tick(&mut self, ctx: &mut BTerm) {
        // Game logic
        if ctx.key == Some(VirtualKeyCode::Space) {
            self.audio.play_sample("assets/attack.wav")
                .expect("Failed to play attack sound");
        }

        // Rendering...
    }
}

fn main() -> BError {
    let context = BTermBuilder::simple80x50()
        .with_title("Roguelike")
        .build()?;

    let gs = State {
        audio: AudioEngine::new_with_gpu().expect("Failed to initialize audio engine with GPU"),
    };

    main_loop(context, gs)
}
```

**Key Points:**
- Store `AudioEngine` in your `State` struct
- Create during state initialization
- Call from `tick()` method

---

## Custom Engine

If you're building your own engine, the pattern is the same:

```rust
use tunes::prelude::*;

struct GameEngine {
    audio: AudioEngine,
    // ... your engine state ...
}

impl GameEngine {
    fn new() -> Self {
        Self {
            audio: AudioEngine::new_with_gpu().expect("Failed to initialize audio engine with GPU"),
        }
    }

    fn update(&mut self) {
        // Game logic triggers audio
        if self.player_jumped() {
            self.audio.play_sample("jump.wav")
                .expect("Failed to play jump sound");
        }
    }
}

fn main() {
    let mut game = GameEngine::new();

    loop {
        game.update();
        game.render();
    }
}
```

**Key Points:**
- Store `AudioEngine` in your main game/engine struct
- Initialize once during engine creation
- Call methods from your game loop

---


## Performance Across All Engines
**Your choice of engine doesn't affect Tunes performance.** The audio runs on a dedicated thread with lock-free communication regardless of which engine you use.

Tunes integrates with any Rust game engine. No wrapper crates required.

For synthesis and composition, see the [Composition chapter](../concepts/composition.md).
