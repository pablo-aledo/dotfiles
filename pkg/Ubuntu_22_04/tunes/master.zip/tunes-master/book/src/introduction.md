# Introduction

## What is Tunes?

**Tunes is a standalone Rust library for music composition, synthesis, and audio generation** with real-time, concurrent playback and control.

Unlike traditional audio libraries that focus solely on sample playback, Tunes provides:

- **Music composition** - Scales, chords, progressions, arrangements
- **Synthesis** - FM, granular, wavetable, 150+ instruments
- **Real-time playback** - Concurrent mixing with dynamic control
- **Export** - WAV, FLAC, MIDI output
- **Algorithmic generation** - Sequences from chaos theory, primes, cellular automata

**No runtime dependencies.** Compiles to a single binary. Works on Linux, macOS, and Windows out of the box.

---

## Who is it for?

**Tunes is designed for developers who want to create sound or play it back.**

### Game Developers
Build dynamic soundscapes that respond to gameplay. Generate procedural sound effects. Create adaptive music systems. Suitable for:
- Roguelikes with generative soundtracks
- Rhythm games that compose on-the-fly
- Ambient games with evolving audio
- Any game that benefits from synthesis over samples

### Algorithmic Composers
Write music in code using scales, progressions, and patterns. Explore generative techniques like Markov chains, L-systems, and chaos attractors. Export your compositions to standard formats.

### Creative Coders
Build interactive audio installations, visualizers, or standalone music tools. Tunes gives you low-level control with a high-level API.

### Tool Builders
Create command-line music generators, audio processors, or batch rendering tools. Tunes works great in headless environments.

---

## Why Tunes?

**If you need:**
- Synthesis and composition in Rust (100x realtime synthesis)
- Real-time concurrent playback (hundreds of samples concurrently)
- Export to WAV/FLAC/MIDI/STEM
- Algorithmic/generative music
- No runtime dependencies

**Tunes addresses these requirements.**

**If you need:**
- Visual live coding interface → Consider [Sonic Pi](https://sonic-pi.net/)
- Browser-based collaboration → Consider [Strudel](https://strudel.tidalcycles.org/)
- Extreme synthesis flexibility → Consider [SuperCollider](https://supercollider.github.io/)
- Other tools worth exploring: [Kira](https://github.com/tesselode/kira), [Rodio](https://github.com/RustAudio/rodio), Leipzig, ChucK, PureData, Max/MSP, TidalCycles, CSound, Faust, OverTone, Alda, Music21

---

---

**Next:** [Installation & First Sound](./getting-started/installation.md)
