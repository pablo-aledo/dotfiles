//the same test as asm_filter but compiled with different -funtrace-* flags - we want to see that we get a different trace that way
#include "asm_filter.cpp"
