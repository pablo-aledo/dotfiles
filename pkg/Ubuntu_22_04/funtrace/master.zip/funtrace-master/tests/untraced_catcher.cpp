#define UNTRACED_CATCHER
#include "exceptions.cpp"
