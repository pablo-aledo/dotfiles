from .vllm import register_vllm_photon


register_vllm_photon()
