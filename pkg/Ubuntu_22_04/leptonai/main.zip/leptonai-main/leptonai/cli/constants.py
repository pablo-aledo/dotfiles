# flake8: noqa
"""
Constants for the CLI.
"""

# Storage
STORAGE_DISPLAY_PREFIX_MIDDLE = "├──"
STORAGE_DISPLAY_PREFIX_LAST = "└──"
