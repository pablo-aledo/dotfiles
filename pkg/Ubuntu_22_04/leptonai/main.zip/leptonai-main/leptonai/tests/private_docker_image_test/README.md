This is a test file that is used in e2e-tests/deployment_test.go:TestPrivateContainerRegistry().

