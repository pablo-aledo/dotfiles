# 👀Segment Something

Entity extraction with CLIP and SAM model. For more detailed instructions, please refer to this [link](https://www.lepton.ai/docs/examples/segment_something).