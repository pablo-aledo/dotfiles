"""
A simple module to demonstrate how to use a dependency in a photon.
"""


def content() -> str:
    """
    A simple function to return a string for demo purpose.
    """
    return "Hello world from dependency.py!"
