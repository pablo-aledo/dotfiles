---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**What is the bug?**



**What did you do to get the bug?**



**What behaviour were you expecting?**



**Screenshots (if applicable)**



