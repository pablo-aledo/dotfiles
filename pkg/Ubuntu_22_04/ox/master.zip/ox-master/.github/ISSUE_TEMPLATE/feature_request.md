---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**What feature would you like to see? (give details)**



**Are there any alternatives you have considered?**



