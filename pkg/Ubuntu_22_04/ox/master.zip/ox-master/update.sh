git pull
cargo build --release
sudo cp target/release/ox /usr/bin/ox
echo "Ox has been updated!"

