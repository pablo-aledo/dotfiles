
-- Configure Colours --
colors.editor_bg = 'transparent'
colors.line_number_bg = 'transparent'

colors.info_bg = 'transparent'
colors.warning_bg = 'transparent'
colors.error_bg = 'transparent'
