cargo tarpaulin -o Html --ignore-tests --skip-clean --workspace --exclude-files src/* src/editor/* src/config/* kaolinite/examples/cactus/src/*
