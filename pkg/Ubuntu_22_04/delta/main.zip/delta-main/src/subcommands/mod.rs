pub mod diff;
pub mod generate_completion;
pub mod list_syntax_themes;
pub mod parse_ansi;
mod sample_diff;
pub mod show_colors;
pub mod show_config;
pub mod show_syntax_themes;
pub mod show_themes;
