# Using Delta on Windows

Delta works on Windows. However, it is essential to use a recent version of `less.exe`: you can download one from <https://github.com/jftuga/less-Windows/releases/latest>. If you see incorrect colors and/or strange characters in Delta output, then it is probably because Delta is picking up an old version of `less.exe` on your system.
