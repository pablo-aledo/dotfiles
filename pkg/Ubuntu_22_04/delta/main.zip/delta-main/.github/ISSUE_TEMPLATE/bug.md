---
name: Bug
about: Create a bug report
title: "\U0001F41B "
labels: ''
assignees: ''

---

- [ ] Please include the raw text output from git, so that we can reproduce the problem.
      (You can use `git --no-pager` to produce the raw text output.)
- [ ] A screenshot of Delta's output is often helpful also.

Thanks for filing a Delta bug report!
