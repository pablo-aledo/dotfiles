package internal

import _ "embed"

//go:embed icon.svg
var Icon []byte
