package version

// Name for this.
const Name string = "octocov"

// Version for this.
var Version = "0.62.1" //nostyle:repetition
