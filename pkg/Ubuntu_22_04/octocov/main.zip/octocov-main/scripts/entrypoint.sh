#!/bin/sh -l

octocov $@
