# badge

Package for rendering badges.
