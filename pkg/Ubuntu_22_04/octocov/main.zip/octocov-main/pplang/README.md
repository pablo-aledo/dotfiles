# pplang

**P**roject **p**rogramming **lang**uage detecter
