# Security Policy

## Reporting a Vulnerability

Contact [@nikolaydubina](https://github.com/nikolaydubina) over email or linkedin.
