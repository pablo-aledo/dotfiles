https://github.com/jspanchu/webgpu-dawn-binaries
commit hash:
c0602d5d0466040f6e080d6cb7209860538f9f8d

Built with clang:
cmake .. -DCMAKE_C_COMPILER=clang DCMAKE_CXX_COMPILER=clang++
