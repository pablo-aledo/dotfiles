package ui

const (
	keyEnter = "enter"
	keyEsc   = "esc"
)
