package main

import (
	platform "golang.org/x/sys/windows"
)

const PLATFORM_SIGTERM = platform.SIGTERM
