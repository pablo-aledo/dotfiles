package main

import (
	"fmt"
)

func main() {
	var b, c int = 1, 2
	fmt.Println(b, c)

	fruit := "apple"
	fmt.Println(fruit)
}
