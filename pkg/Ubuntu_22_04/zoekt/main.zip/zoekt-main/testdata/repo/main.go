package main

import "fmt"

var (
	num     = 5
	message = "hello"
)

func main() {
	fmt.Println(message, num)
}
