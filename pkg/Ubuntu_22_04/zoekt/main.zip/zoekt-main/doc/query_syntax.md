# Query syntax

Query syntax examples can be found on the index page of a running Zoekt webserver.
These
[example queries can also be viewed in the corresponding HTML template](../web/templates.go#L158).
