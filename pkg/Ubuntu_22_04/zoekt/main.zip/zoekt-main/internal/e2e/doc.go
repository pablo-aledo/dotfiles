// package e2e contains end to end tests
package e2e
