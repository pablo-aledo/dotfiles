// Package reaper contains logic for reaping subprocesses. It is
// specifically used in the agent to avoid the accumulation of
// zombie processes.
package reaper
