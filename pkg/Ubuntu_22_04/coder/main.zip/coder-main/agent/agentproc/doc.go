// Package agentproc contains logic for interfacing with local
// processes running in the same context as the agent.
package agentproc
