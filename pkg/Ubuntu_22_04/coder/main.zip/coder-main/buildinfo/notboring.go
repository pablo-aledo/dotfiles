//go:build !boringcrypto

package buildinfo

var boringcrypto = false
