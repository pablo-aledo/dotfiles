//go:build slim

package buildinfo

func init() {
	slim = true
}
