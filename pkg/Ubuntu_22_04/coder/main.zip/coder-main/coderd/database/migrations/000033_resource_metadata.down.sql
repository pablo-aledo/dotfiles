DROP TABLE IF EXISTS workspace_resource_metadata;
