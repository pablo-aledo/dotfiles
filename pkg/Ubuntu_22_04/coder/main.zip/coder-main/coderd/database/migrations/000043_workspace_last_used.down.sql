ALTER TABLE workspaces
    DROP COLUMN last_used_at;
