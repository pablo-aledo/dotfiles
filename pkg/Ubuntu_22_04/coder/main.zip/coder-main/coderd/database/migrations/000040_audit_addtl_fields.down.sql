ALTER TABLE audit_logs 
    DROP COLUMN additional_fields,
    DROP COLUMN request_id,
    DROP COLUMN resource_icon;
