ALTER TABLE workspace_builds
    ADD COLUMN name character varying(64) NOT NULL DEFAULT '';
