DROP TABLE site_configs;
