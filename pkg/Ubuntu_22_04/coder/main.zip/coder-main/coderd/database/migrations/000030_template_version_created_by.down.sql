ALTER TABLE ONLY template_versions DROP COLUMN IF EXISTS created_by;
