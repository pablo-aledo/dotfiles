ALTER TABLE users
    DROP COLUMN avatar_url;
