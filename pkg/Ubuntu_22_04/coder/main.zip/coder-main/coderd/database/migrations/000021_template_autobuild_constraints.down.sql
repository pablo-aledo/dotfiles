ALTER TABLE ONLY templates DROP COLUMN IF EXISTS max_ttl;
ALTER TABLE ONLY templates DROP COLUMN IF EXISTS min_autostart_interval;
