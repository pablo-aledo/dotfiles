DROP TABLE agent_stats;
