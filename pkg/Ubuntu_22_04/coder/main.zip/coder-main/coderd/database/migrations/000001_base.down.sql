DROP TABLE licenses;
DROP TABLE api_keys;
DROP TABLE organization_members;
DROP TABLE organizations;
DROP TABLE users;

DROP TYPE login_type;

