ALTER TABLE ONLY api_keys
    DROP COLUMN IF EXISTS ip_address;
