DROP TABLE gitsshkeys;
