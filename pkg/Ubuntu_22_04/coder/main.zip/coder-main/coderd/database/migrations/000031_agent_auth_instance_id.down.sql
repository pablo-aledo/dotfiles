ALTER TABLE workspace_agents ALTER COLUMN auth_instance_id TYPE character varying(64);
