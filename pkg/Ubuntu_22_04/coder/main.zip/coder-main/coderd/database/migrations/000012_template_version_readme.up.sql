ALTER TABLE template_versions RENAME description TO readme;
