ALTER TABLE workspace_resources
    ADD COLUMN hide boolean DEFAULT false NOT NULL;
