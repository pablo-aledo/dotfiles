ALTER TABLE workspace_agents
    DROP COLUMN wireguard_node_ipv6,
    DROP COLUMN wireguard_node_public_key,
    DROP COLUMN wireguard_disco_public_key;
