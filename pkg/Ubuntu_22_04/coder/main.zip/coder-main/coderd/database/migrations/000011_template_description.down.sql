ALTER TABLE templates DROP COLUMN description;
