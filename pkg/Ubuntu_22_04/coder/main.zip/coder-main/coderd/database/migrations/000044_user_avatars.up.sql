ALTER TABLE users
    ADD COLUMN avatar_url text;
