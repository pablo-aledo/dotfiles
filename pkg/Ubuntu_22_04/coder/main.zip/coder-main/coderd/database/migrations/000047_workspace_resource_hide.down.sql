ALTER TABLE workspace_resources
    DROP COLUMN hide;
