DROP TABLE template_versions;

DROP TABLE templates;
DROP TYPE provisioner_type;

DROP TABLE files;
