ALTER TABLE parameter_schemas DROP COLUMN index;
