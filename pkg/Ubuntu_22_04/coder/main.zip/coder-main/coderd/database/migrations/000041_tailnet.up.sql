ALTER TABLE workspace_agents DROP COLUMN wireguard_node_ipv6;
ALTER TABLE workspace_agents DROP COLUMN wireguard_node_public_key;
ALTER TABLE workspace_agents DROP COLUMN wireguard_disco_public_key;
