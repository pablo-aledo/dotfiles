DROP TABLE audit_logs;
DROP TYPE audit_action;
DROP TYPE resource_type;
