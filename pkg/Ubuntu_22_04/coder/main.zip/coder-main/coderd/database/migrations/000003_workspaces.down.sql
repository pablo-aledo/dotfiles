DROP TYPE workspace_transition;
DROP TABLE workspaces
