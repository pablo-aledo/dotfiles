ALTER TABLE ONLY users
	DROP COLUMN last_seen_at;
