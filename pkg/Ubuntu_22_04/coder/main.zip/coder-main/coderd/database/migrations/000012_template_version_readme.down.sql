ALTER TABLE template_versions RENAME README TO description;
