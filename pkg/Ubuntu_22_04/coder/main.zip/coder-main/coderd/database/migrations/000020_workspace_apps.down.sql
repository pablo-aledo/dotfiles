DROP TABLE workspace_apps;
