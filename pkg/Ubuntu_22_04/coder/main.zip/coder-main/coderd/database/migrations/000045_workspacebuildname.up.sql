ALTER TABLE workspace_builds
    DROP COLUMN name;
