ALTER TABLE ONLY workspace_agents DROP COLUMN version;
