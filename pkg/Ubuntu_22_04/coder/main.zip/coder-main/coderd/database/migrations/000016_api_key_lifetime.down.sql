ALTER TABLE api_keys DROP COLUMN lifetime_seconds;
