ALTER TABLE users
    DROP COLUMN deleted;
