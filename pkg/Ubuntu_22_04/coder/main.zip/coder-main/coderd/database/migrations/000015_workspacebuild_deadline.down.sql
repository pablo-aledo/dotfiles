ALTER TABLE ONLY workspace_builds DROP COLUMN deadline;
