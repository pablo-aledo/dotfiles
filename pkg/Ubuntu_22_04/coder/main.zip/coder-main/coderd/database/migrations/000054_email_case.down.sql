DROP INDEX users_email_lower_idx;
