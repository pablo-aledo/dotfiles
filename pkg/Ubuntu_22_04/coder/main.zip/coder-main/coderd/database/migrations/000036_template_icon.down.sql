ALTER TABLE templates DROP COLUMN icon;
