// Package autobuild contains logic for scheduling workspace
// builds in the background.
package autobuild
