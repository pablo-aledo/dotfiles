//go:build windows

package cli

// Must be a var for unit tests to conform behavior
var hideForceUnixSlashes = false
