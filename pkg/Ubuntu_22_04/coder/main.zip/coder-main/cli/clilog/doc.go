// Package clilog provides a fluent API for configuring structured logging.
package clilog
