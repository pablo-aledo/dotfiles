//go:build !windows

package cli

var hideForceUnixSlashes = true
