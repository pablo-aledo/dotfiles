/**
 * Layout module for flowchart and state diagrams.
 *
 * Uses ELK.js for graph layout — battle-tested, full subgraph support,
 * orthogonal edge routing, and direction overrides.
 */

export { layoutGraphSync } from './layout-engine.ts'
