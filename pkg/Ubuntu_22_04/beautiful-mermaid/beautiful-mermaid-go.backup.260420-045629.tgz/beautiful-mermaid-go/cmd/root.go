package cmd

import (
	"fmt"
	"io"
	"os"

	"github.com/beautiful-mermaid/go/pkg/diagram"
	"github.com/spf13/cobra"
)

var (
	verbose          bool
	useAscii         bool
	showCoords       bool
	boxBorderPadding = 1
	paddingX         = 5
	paddingY         = 5
	graphDirection   = "LR"
)

var rootCmd = &cobra.Command{
	Use:   "beautiful-mermaid",
	Short: "Render Mermaid diagrams as beautiful ASCII/Unicode art.",
	Long: `beautiful-mermaid converts Mermaid diagram text to ASCII or Unicode art.

Supports flowcharts (graph TD/LR), state diagrams (stateDiagram-v2),
and sequence diagrams (sequenceDiagram).

Read from a file:
  beautiful-mermaid -f diagram.mmd

Read from stdin:
  echo "graph LR; A --> B" | beautiful-mermaid`,
	RunE: func(cmd *cobra.Command, args []string) error {
		var mermaid []byte
		var err error

		filePath := cmd.Flag("file").Value.String()
		if filePath == "" || filePath == "-" {
			mermaid, err = io.ReadAll(os.Stdin)
			if err != nil {
				return fmt.Errorf("failed to read stdin: %w", err)
			}
		} else {
			mermaid, err = os.ReadFile(filePath)
			if err != nil {
				return fmt.Errorf("failed to read %s: %w", filePath, err)
			}
		}

		config, err := diagram.NewCLIConfig(
			useAscii,
			showCoords,
			verbose,
			boxBorderPadding,
			paddingX,
			paddingY,
			graphDirection,
		)
		if err != nil {
			return fmt.Errorf("invalid configuration: %w", err)
		}

		output, err := RenderDiagram(string(mermaid), config)
		if err != nil {
			return err
		}
		fmt.Print(output)
		return nil
	},
}

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}

func init() {
	rootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", false, "Verbose debug output")
	rootCmd.PersistentFlags().BoolVarP(&useAscii, "ascii", "a", false, "Use ASCII characters instead of Unicode box-drawing")
	rootCmd.PersistentFlags().BoolVarP(&showCoords, "coords", "c", false, "Show coordinate debug overlay")
	rootCmd.PersistentFlags().IntVarP(&paddingX, "paddingX", "x", paddingX, "Horizontal space between nodes")
	rootCmd.PersistentFlags().IntVarP(&paddingY, "paddingY", "y", paddingY, "Vertical space between nodes")
	rootCmd.PersistentFlags().IntVarP(&boxBorderPadding, "borderPadding", "p", boxBorderPadding, "Padding between node text and border")
	rootCmd.Flags().StringP("file", "f", "", "Mermaid file to render (use '-' for stdin)")
}
