package cmd

import (
	"fmt"
	"strings"

	"github.com/beautiful-mermaid/go/pkg/ascii"
	"github.com/beautiful-mermaid/go/pkg/class"
	"github.com/beautiful-mermaid/go/pkg/diagram"
	"github.com/beautiful-mermaid/go/pkg/er"
	"github.com/beautiful-mermaid/go/pkg/sequence"
	"github.com/beautiful-mermaid/go/pkg/xychart"
)

// RenderDiagram auto-detects diagram type and renders to ASCII.
func RenderDiagram(input string, config *diagram.Config) (string, error) {
	if config == nil {
		config = diagram.DefaultConfig()
	}
	input = strings.TrimSpace(input)

	switch {
	case sequence.IsSequenceDiagram(input):
		sd, err := sequence.Parse(input)
		if err != nil {
			return "", fmt.Errorf("failed to parse sequence diagram: %w", err)
		}
		return sequence.Render(sd, config)

	case class.IsClassDiagram(input):
		cd, err := class.Parse(input)
		if err != nil {
			return "", fmt.Errorf("failed to parse class diagram: %w", err)
		}
		return class.Render(cd, config)

	case er.IsERDiagram(input):
		erd, err := er.Parse(input)
		if err != nil {
			return "", fmt.Errorf("failed to parse ER diagram: %w", err)
		}
		return er.Render(erd, config)

	case xychart.IsXYChart(input):
		chart, err := xychart.Parse(input)
		if err != nil {
			return "", fmt.Errorf("failed to parse XY chart: %w", err)
		}
		return xychart.Render(chart, config)

	default:
		// Flowchart, state diagram, and anything else
		return ascii.RenderFlowchart(input, config)
	}
}
