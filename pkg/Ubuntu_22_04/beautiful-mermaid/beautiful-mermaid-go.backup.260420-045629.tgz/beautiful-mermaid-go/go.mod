module github.com/beautiful-mermaid/go

go 1.20

require (
	github.com/elliotchance/orderedmap/v2 v2.2.0
	github.com/mattn/go-runewidth v0.0.15
	github.com/spf13/cobra v1.6.1
)

require (
	github.com/inconshreveable/mousetrap v1.0.1 // indirect
	github.com/rivo/uniseg v0.2.0 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
)
