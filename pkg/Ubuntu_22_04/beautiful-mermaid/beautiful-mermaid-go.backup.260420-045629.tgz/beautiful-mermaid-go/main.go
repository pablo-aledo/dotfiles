package main

import "github.com/beautiful-mermaid/go/cmd"

func main() {
	cmd.Execute()
}
