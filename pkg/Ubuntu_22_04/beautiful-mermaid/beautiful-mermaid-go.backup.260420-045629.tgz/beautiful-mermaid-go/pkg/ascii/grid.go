package ascii

// ============================================================================
// Grid coordinate → drawing coordinate
// ============================================================================

// GridToDrawingCoord converts a grid coord to a character canvas coord.
func GridToDrawingCoord(g *Graph, c GridCoord) DrawingCoord {
	x := 0
	for col := 0; col < c.X; col++ {
		x += g.ColumnWidth[col]
	}
	y := 0
	for row := 0; row < c.Y; row++ {
		y += g.RowHeight[row]
	}
	colW := g.ColumnWidth[c.X]
	rowH := g.RowHeight[c.Y]
	return DrawingCoord{
		X: x + colW/2 + g.OffsetX,
		Y: y + rowH/2 + g.OffsetY,
	}
}

// LineToDrawing converts a slice of grid coords to drawing coords.
func LineToDrawing(g *Graph, line []GridCoord) []DrawingCoord {
	out := make([]DrawingCoord, len(line))
	for i, c := range line {
		out[i] = GridToDrawingCoord(g, c)
	}
	return out
}

// ============================================================================
// Grid occupancy
// ============================================================================

// ReserveSpotInGrid reserves a 3×3 block for node on the grid.
// If the requested cell is occupied, shifts perpendicular to graphDirection until free.
func ReserveSpotInGrid(g *Graph, node *Node, requested GridCoord, effectiveDir ...string) GridCoord {
	dir := g.GraphDirection
	if len(effectiveDir) > 0 && effectiveDir[0] != "" {
		dir = effectiveDir[0]
	}

	if g.Grid[requested.Key()] != nil {
		// Shift perpendicular to flow
		var next GridCoord
		if dir == "LR" {
			next = GridCoord{X: requested.X, Y: requested.Y + 4}
		} else {
			next = GridCoord{X: requested.X + 4, Y: requested.Y}
		}
		return ReserveSpotInGrid(g, node, next, dir)
	}

	// Reserve the 3×3 block
	for dx := 0; dx < 3; dx++ {
		for dy := 0; dy < 3; dy++ {
			rc := GridCoord{X: requested.X + dx, Y: requested.Y + dy}
			g.Grid[rc.Key()] = node
		}
	}
	node.GridCoord = &GridCoord{X: requested.X, Y: requested.Y}
	return requested
}

// ============================================================================
// Column / row sizing
// ============================================================================

// SetColumnWidth computes column widths and row heights for a node's 3×3 block.
func SetColumnWidth(g *Graph, node *Node) {
	gc := node.GridCoord
	pad := g.BoxBorderPadding

	label := node.DisplayLabel
	labelW := len(label) // simplified; runewidth used in label.go
	col1 := 1
	col2 := 2*pad + labelW
	col3 := 1
	cols := []int{col1, col2, col3}

	lines := splitLines(label)
	contentH := len(lines) + (len(lines)-1)*labelLineGap
	row1 := 1
	row2 := contentH + 2*pad
	row3 := 1
	rows := []int{row1, row2, row3}

	for i, w := range cols {
		xc := gc.X + i
		if cur := g.ColumnWidth[xc]; w > cur {
			g.ColumnWidth[xc] = w
		}
	}
	for i, h := range rows {
		yc := gc.Y + i
		if cur := g.RowHeight[yc]; h > cur {
			g.RowHeight[yc] = h
		}
	}
	if gc.X > 0 {
		if cur := g.ColumnWidth[gc.X-1]; g.PaddingX > cur {
			g.ColumnWidth[gc.X-1] = g.PaddingX
		}
	}
	if gc.Y > 0 {
		basePad := g.PaddingY
		if hasIncomingEdgeFromOutsideSubgraph(g, node) {
			basePad += 4
		}
		if cur := g.RowHeight[gc.Y-1]; basePad > cur {
			g.RowHeight[gc.Y-1] = basePad
		}
	}
}

// IncreaseGridSizeForPath ensures column/row entries exist for all cells on a path.
func IncreaseGridSizeForPath(g *Graph, path []GridCoord) {
	for _, c := range path {
		if _, ok := g.ColumnWidth[c.X]; !ok {
			g.ColumnWidth[c.X] = g.PaddingX / 2
		}
		if _, ok := g.RowHeight[c.Y]; !ok {
			g.RowHeight[c.Y] = g.PaddingY / 2
		}
	}
}

// splitLines splits a label on newlines (including \n literals and <br> tags).
func splitLines(label string) []string {
	return NewGraphLabel(label).Lines
}

// ============================================================================
// Subgraph helpers
// ============================================================================

func isNodeInAnySubgraph(g *Graph, node *Node) bool {
	for _, sg := range g.Subgraphs {
		for _, n := range sg.Nodes {
			if n == node {
				return true
			}
		}
	}
	return false
}

func getNodeSubgraph(g *Graph, node *Node) *Subgraph {
	var innermost *Subgraph
	for _, sg := range g.Subgraphs {
		for _, n := range sg.Nodes {
			if n == node {
				if innermost == nil || isAncestorOrSelf(innermost, sg) {
					innermost = sg
				}
			}
		}
	}
	return innermost
}

func isAncestorOrSelf(candidate, target *Subgraph) bool {
	cur := target
	for cur != nil {
		if cur == candidate {
			return true
		}
		cur = cur.Parent
	}
	return false
}

func hasIncomingEdgeFromOutsideSubgraph(g *Graph, node *Node) bool {
	nodeSg := getNodeSubgraph(g, node)
	if nodeSg == nil {
		return false
	}
	hasExternal := false
	for _, e := range g.Edges {
		if e.To == node {
			srcSg := getNodeSubgraph(g, e.From)
			if srcSg != nodeSg {
				hasExternal = true
				break
			}
		}
	}
	if !hasExternal {
		return false
	}
	for _, other := range nodeSg.Nodes {
		if other == node || other.GridCoord == nil {
			continue
		}
		otherHasExternal := false
		for _, e := range g.Edges {
			if e.To == other {
				srcSg := getNodeSubgraph(g, e.From)
				if srcSg != nodeSg {
					otherHasExternal = true
					break
				}
			}
		}
		if otherHasExternal && other.GridCoord.Y < node.GridCoord.Y {
			return false
		}
	}
	return true
}

// ============================================================================
// Subgraph bounding boxes
// ============================================================================

func calculateSubgraphBoundingBox(g *Graph, sg *Subgraph) {
	if len(sg.Nodes) == 0 {
		return
	}
	minX, minY := 1_000_000, 1_000_000
	maxX, maxY := -1_000_000, -1_000_000

	for _, child := range sg.Children {
		calculateSubgraphBoundingBox(g, child)
		if len(child.Nodes) > 0 {
			minX = minInt(minX, child.MinX)
			minY = minInt(minY, child.MinY)
			maxX = maxInt(maxX, child.MaxX)
			maxY = maxInt(maxY, child.MaxY)
		}
	}
	for _, node := range sg.Nodes {
		if node.DrawingCoord == nil || node.Drawing == nil {
			continue
		}
		nMinX := node.DrawingCoord.X
		nMinY := node.DrawingCoord.Y
		nMaxX := nMinX + len(node.Drawing) - 1
		nMaxY := nMinY + len(node.Drawing[0]) - 1
		minX = minInt(minX, nMinX)
		minY = minInt(minY, nMinY)
		maxX = maxInt(maxX, nMaxX)
		maxY = maxInt(maxY, nMaxY)
	}

	// Ensure subgraph label fits
	curW := maxX - minX
	innerW := curW + 3
	if innerW < sg.Label.Width {
		extra := sg.Label.Width - innerW
		minX -= extra / 2
		maxX += extra - extra/2
	}

	const subgraphPadding = 2
	subgraphLabelSpace := sg.Label.ContentHeight() + 1
	sg.MinX = minX - subgraphPadding
	sg.MinY = minY - subgraphPadding - subgraphLabelSpace
	sg.MaxX = maxX + subgraphPadding
	sg.MaxY = maxY + subgraphPadding
}

func ensureSubgraphSpacing(g *Graph) {
	const minSpacing = 1
	var roots []*Subgraph
	for _, sg := range g.Subgraphs {
		if sg.Parent == nil && len(sg.Nodes) > 0 {
			roots = append(roots, sg)
		}
	}
	for i := 0; i < len(roots); i++ {
		for j := i + 1; j < len(roots); j++ {
			sg1, sg2 := roots[i], roots[j]
			// Horizontal overlap → vertical adjust
			if sg1.MinX < sg2.MaxX && sg1.MaxX > sg2.MinX {
				if sg1.MaxY >= sg2.MinY-minSpacing && sg1.MinY < sg2.MinY {
					sg2.MinY = sg1.MaxY + minSpacing + 1
				} else if sg2.MaxY >= sg1.MinY-minSpacing && sg2.MinY < sg1.MinY {
					sg1.MinY = sg2.MaxY + minSpacing + 1
				}
			}
			// Vertical overlap → horizontal adjust
			if sg1.MinY < sg2.MaxY && sg1.MaxY > sg2.MinY {
				if sg1.MaxX >= sg2.MinX-minSpacing && sg1.MinX < sg2.MinX {
					sg2.MinX = sg1.MaxX + minSpacing + 1
				} else if sg2.MaxX >= sg1.MinX-minSpacing && sg2.MinX < sg1.MinX {
					sg1.MinX = sg2.MaxX + minSpacing + 1
				}
			}
		}
	}
}

func CalculateSubgraphBoundingBoxes(g *Graph) {
	for _, sg := range g.Subgraphs {
		calculateSubgraphBoundingBox(g, sg)
	}
	ensureSubgraphSpacing(g)
}

func OffsetDrawingForSubgraphs(g *Graph) {
	if len(g.Subgraphs) == 0 {
		return
	}
	minX, minY := 0, 0
	for _, sg := range g.Subgraphs {
		minX = minInt(minX, sg.MinX)
		minY = minInt(minY, sg.MinY)
	}
	offX := -minX
	offY := -minY
	if offX == 0 && offY == 0 {
		return
	}
	g.OffsetX = offX
	g.OffsetY = offY
	for _, sg := range g.Subgraphs {
		sg.MinX += offX
		sg.MinY += offY
		sg.MaxX += offX
		sg.MaxY += offY
	}
	for _, node := range g.Nodes {
		if node.DrawingCoord != nil {
			node.DrawingCoord.X += offX
			node.DrawingCoord.Y += offY
		}
	}
}

// ============================================================================
// Graph traversal
// ============================================================================

func getChildren(g *Graph, node *Node) []*Node {
	var children []*Node
	for _, e := range g.Edges {
		if e.From.Name == node.Name {
			children = append(children, e.To)
		}
	}
	return children
}

// ============================================================================
// Main layout orchestrator
// ============================================================================

// CreateMapping performs the full grid layout:
// 1. Place root nodes  2. Place children level by level
// 3. Compute sizes  4. Route edges via A*  5. Convert to drawing coords
func CreateMapping(g *Graph) {
	dir := g.GraphDirection
	highestPerLevel := make([]int, 100)

	// Identify root nodes (not target of any edge)
	nodesFound := map[string]bool{}
	var initialRoots []*Node
	for _, node := range g.Nodes {
		if !nodesFound[node.Name] {
			initialRoots = append(initialRoots, node)
		}
		nodesFound[node.Name] = true
		for _, child := range getChildren(g, node) {
			nodesFound[child.Name] = true
		}
	}

	// Filter: subgraph nodes with external incoming edges are not roots
	var rootNodes []*Node
	for _, node := range initialRoots {
		nodeSg := getNodeSubgraph(g, node)
		if nodeSg == nil {
			rootNodes = append(rootNodes, node)
			continue
		}
		isRoot := true
		for _, e := range g.Edges {
			if e.To == node {
				srcSg := getNodeSubgraph(g, e.From)
				if srcSg != nodeSg {
					isRoot = false
					break
				}
			}
		}
		if isRoot {
			rootNodes = append(rootNodes, node)
		}
	}

	// Decide whether to separate external vs subgraph roots (LR mode)
	var hasExternalRoots, hasSubgraphRootsWithEdges bool
	for _, node := range rootNodes {
		if isNodeInAnySubgraph(g, node) {
			if len(getChildren(g, node)) > 0 {
				hasSubgraphRootsWithEdges = true
			}
		} else {
			hasExternalRoots = true
		}
	}
	shouldSeparate := dir == "LR" && hasExternalRoots && hasSubgraphRootsWithEdges

	var externalRoots, subgraphRoots []*Node
	if shouldSeparate {
		for _, n := range rootNodes {
			if isNodeInAnySubgraph(g, n) {
				subgraphRoots = append(subgraphRoots, n)
			} else {
				externalRoots = append(externalRoots, n)
			}
		}
	} else {
		externalRoots = rootNodes
	}

	// Place external roots at level 0
	for _, node := range externalRoots {
		var req GridCoord
		if dir == "LR" {
			req = GridCoord{X: 0, Y: highestPerLevel[0]}
		} else {
			req = GridCoord{X: highestPerLevel[0], Y: 0}
		}
		ReserveSpotInGrid(g, g.Nodes[node.Index], req)
		highestPerLevel[0] += 4
	}

	// Place subgraph roots at level 4
	if shouldSeparate && len(subgraphRoots) > 0 {
		const subgraphLevel = 4
		for _, node := range subgraphRoots {
			var req GridCoord
			if dir == "LR" {
				req = GridCoord{X: subgraphLevel, Y: highestPerLevel[subgraphLevel]}
			} else {
				req = GridCoord{X: highestPerLevel[subgraphLevel], Y: subgraphLevel}
			}
			ReserveSpotInGrid(g, g.Nodes[node.Index], req)
			highestPerLevel[subgraphLevel] += 4
		}
	}

	// Place children level by level (multi-pass for non-topological order)
	placedCount := len(externalRoots) + len(subgraphRoots)
	for placedCount < len(g.Nodes) {
		prev := placedCount
		for _, node := range g.Nodes {
			if node.GridCoord == nil {
				continue
			}
			gc := node.GridCoord
			for _, child := range getChildren(g, node) {
				if child.GridCoord != nil {
					continue
				}
				// Determine effective direction for this edge
				parentSg := getNodeSubgraph(g, node)
				childSg := getNodeSubgraph(g, child)
				edgeDir := g.GraphDirection
				if parentSg != nil && parentSg == childSg && parentSg.Direction != "" {
					edgeDir = parentSg.Direction
				}

				var childLevel int
				if edgeDir == "LR" {
					childLevel = gc.X + 4
				} else {
					childLevel = gc.Y + 4
				}

				var highestPos int
				if edgeDir != g.GraphDirection {
					if edgeDir == "LR" {
						highestPos = gc.Y
					} else {
						highestPos = gc.X
					}
				} else {
					highestPos = highestPerLevel[childLevel]
				}

				var req GridCoord
				if edgeDir == "LR" {
					req = GridCoord{X: childLevel, Y: highestPos}
				} else {
					req = GridCoord{X: highestPos, Y: childLevel}
				}
				ReserveSpotInGrid(g, g.Nodes[child.Index], req, edgeDir)

				if edgeDir == g.GraphDirection {
					highestPerLevel[childLevel] = highestPos + 4
				}
				placedCount++
			}
		}
		if placedCount == prev {
			break // no progress — disconnected subgraph
		}
	}

	// Compute column and row sizes
	for _, node := range g.Nodes {
		SetColumnWidth(g, node)
	}

	// Route edges
	for _, e := range g.Edges {
		DeterminePath(g, e)
		IncreaseGridSizeForPath(g, e.Path)
		DetermineLabelLine(g, e)
	}

	// Convert grid → drawing coords and build node box drawings
	for _, node := range g.Nodes {
		dc := GridToDrawingCoord(g, *node.GridCoord)
		node.DrawingCoord = &dc
		node.Drawing = DrawBox(node, g)
	}

	g.Drawing = SetCanvasSizeToGrid(g.Drawing, g.ColumnWidth, g.RowHeight)
	CalculateSubgraphBoundingBoxes(g)
	OffsetDrawingForSubgraphs(g)
}
