package ascii

// corners holds the four corner characters for a box shape.
type corners struct{ TL, TR, BL, BR string }

// getCorners returns the corner characters for the given node shape.
// All shapes render as rectangles; the corners distinguish the type visually.
func getCorners(shape NodeShape, useAscii bool) corners {
	if useAscii {
		// ASCII fallback: all shapes use +
		switch shape {
		case ShapeRounded:
			return corners{"/", "\\", "\\", "/"}
		case ShapeDiamond:
			return corners{"*", "*", "*", "*"}
		default:
			return corners{"+", "+", "+", "+"}
		}
	}
	// Unicode box-drawing
	switch shape {
	case ShapeRounded:
		return corners{"╭", "╮", "╰", "╯"}
	case ShapeDiamond:
		return corners{"◇", "◇", "◇", "◇"}
	case ShapeCircle, ShapeDoubleCircle:
		return corners{"○", "○", "○", "○"}
	case ShapeStadium:
		return corners{"(", ")", "(", ")"}
	case ShapeHexagon:
		return corners{"⬡", "⬡", "⬡", "⬡"}
	case ShapeSubroutine:
		return corners{"╔", "╗", "╚", "╝"}
	case ShapeStateStart:
		return corners{"●", "●", "●", "●"}
	case ShapeStateEnd:
		return corners{"◎", "◎", "◎", "◎"}
	default:
		return corners{"┌", "┐", "└", "┘"}
	}
}
