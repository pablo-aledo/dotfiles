package ascii

// ============================================================================
// Direction utilities
// ============================================================================

func dirEquals(a, b Direction) bool { return a.X == b.X && a.Y == b.Y }

// determineDirection returns one of 8 named directions from `from` to `to`.
func determineDirection(from, to GridCoord) Direction {
	switch {
	case from.X == to.X:
		if from.Y < to.Y {
			return Down
		}
		return Up
	case from.Y == to.Y:
		if from.X < to.X {
			return Right
		}
		return Left
	case from.X < to.X:
		if from.Y < to.Y {
			return LowerRight
		}
		return UpperRight
	default:
		if from.Y < to.Y {
			return LowerLeft
		}
		return UpperLeft
	}
}

// ============================================================================
// Start/end direction selection
// ============================================================================

func selfReferenceDirection(graphDir string) (Direction, Direction, Direction, Direction) {
	if graphDir == "LR" {
		return Right, Down, Down, Right
	}
	return Down, Right, Right, Down
}

// determineStartAndEndDir returns [prefStart, prefEnd, altStart, altEnd] for an edge.
func determineStartAndEndDir(e *Edge, graphDir string) (Direction, Direction, Direction, Direction) {
	if e.From == e.To {
		return selfReferenceDirection(graphDir)
	}

	d := determineDirection(*e.From.GridCoord, *e.To.GridCoord)

	isBackwards := false
	if graphDir == "LR" {
		isBackwards = dirEquals(d, Left) || dirEquals(d, UpperLeft) || dirEquals(d, LowerLeft)
	} else {
		isBackwards = dirEquals(d, Up) || dirEquals(d, UpperLeft) || dirEquals(d, UpperRight)
	}

	var pref, prefOpp, alt, altOpp Direction

	switch {
	case dirEquals(d, LowerRight):
		if graphDir == "LR" {
			pref, prefOpp = Down, Left
			alt, altOpp = Right, Up
		} else {
			pref, prefOpp = Right, Up
			alt, altOpp = Down, Left
		}
	case dirEquals(d, UpperRight):
		if graphDir == "LR" {
			pref, prefOpp = Up, Left
			alt, altOpp = Right, Down
		} else {
			pref, prefOpp = Right, Down
			alt, altOpp = Up, Left
		}
	case dirEquals(d, LowerLeft):
		if graphDir == "LR" {
			pref, prefOpp = Down, Down
			alt, altOpp = Left, Up
		} else {
			pref, prefOpp = Left, Up
			alt, altOpp = Down, Right
		}
	case dirEquals(d, UpperLeft):
		if graphDir == "LR" {
			pref, prefOpp = Down, Down
			alt, altOpp = Left, Down
		} else {
			pref, prefOpp = Right, Right
			alt, altOpp = Up, Right
		}
	case isBackwards:
		if graphDir == "LR" && dirEquals(d, Left) {
			pref, prefOpp = Down, Down
			alt, altOpp = Left, Right
		} else if graphDir == "TD" && dirEquals(d, Up) {
			pref, prefOpp = Right, Right
			alt, altOpp = Up, Down
		} else {
			pref, prefOpp = d, d.Opposite()
			alt, altOpp = d, d.Opposite()
		}
	default:
		pref, prefOpp = d, d.Opposite()
		alt, altOpp = d, d.Opposite()
	}
	return pref, prefOpp, alt, altOpp
}

// ============================================================================
// Edge path determination
// ============================================================================

// DeterminePath routes an edge via A* (preferred + alternative) and picks the shorter path.
func DeterminePath(g *Graph, e *Edge) {
	graphDir := g.GraphDirection

	// Determine effective direction: respect subgraph override if both nodes are in the same subgraph
	effectiveDir := graphDir
	sourceSg := getNodeSubgraph(g, e.From)
	targetSg := getNodeSubgraph(g, e.To)
	if sourceSg != nil && sourceSg == targetSg && sourceSg.Direction != "" {
		effectiveDir = sourceSg.Direction
	}

	// Temporarily use effective direction for direction selection
	savedDir := g.GraphDirection
	g.GraphDirection = effectiveDir
	pref, prefOpp, alt, altOpp := determineStartAndEndDir(e, effectiveDir)
	g.GraphDirection = savedDir

	prefFrom := e.From.GridCoord.Apply(pref)
	prefTo := e.To.GridCoord.Apply(prefOpp)
	altFrom := e.From.GridCoord.Apply(alt)
	altTo := e.To.GridCoord.Apply(altOpp)

	preferredPath := GetPath(g.Grid, prefFrom, prefTo)
	alternativePath := GetPath(g.Grid, altFrom, altTo)

	if preferredPath != nil && alternativePath != nil {
		preferredPath = MergePath(preferredPath)
		alternativePath = MergePath(alternativePath)
		if len(preferredPath) <= len(alternativePath) {
			e.StartDir, e.EndDir, e.Path = pref, prefOpp, preferredPath
		} else {
			e.StartDir, e.EndDir, e.Path = alt, altOpp, alternativePath
		}
		return
	}
	if preferredPath != nil {
		e.StartDir, e.EndDir, e.Path = pref, prefOpp, MergePath(preferredPath)
		return
	}
	if alternativePath != nil {
		e.StartDir, e.EndDir, e.Path = alt, altOpp, MergePath(alternativePath)
		return
	}
	// Fallback: direct path
	e.StartDir, e.EndDir = pref, prefOpp
	e.Path = []GridCoord{prefFrom, prefTo}
}

// DetermineLabelLine selects the best segment of an edge path to place its label.
func DetermineLabelLine(g *Graph, e *Edge) {
	if len(e.Text) == 0 {
		return
	}
	lenLabel := len(e.Text)

	type seg struct {
		line  [2]GridCoord
		width int
		idx   int
	}

	var segs []seg
	for i := 1; i < len(e.Path); i++ {
		p1, p2 := e.Path[i-1], e.Path[i]
		w := calcLineWidth(g, p1, p2)
		segs = append(segs, seg{[2]GridCoord{p1, p2}, w, i})
	}

	var chosen *seg
	// Prefer segments near the end that are wide enough, skipping first
	for i := len(segs) - 1; i >= 1; i-- {
		if segs[i].width >= lenLabel {
			s := segs[i]
			chosen = &s
			break
		}
	}
	if chosen == nil {
		for i := len(segs) - 1; i >= 0; i-- {
			if segs[i].width >= lenLabel {
				s := segs[i]
				chosen = &s
				break
			}
		}
	}
	if chosen == nil && len(segs) > 0 {
		best := segs[0]
		for _, s := range segs[1:] {
			if s.width > best.width {
				best = s
			}
		}
		chosen = &best
	}
	if chosen == nil {
		return
	}

	minX := minInt(chosen.line[0].X, chosen.line[1].X)
	maxX := maxInt(chosen.line[0].X, chosen.line[1].X)
	midX := minX + (maxX-minX)/2
	cur := g.ColumnWidth[midX]
	if lenLabel+2 > cur {
		g.ColumnWidth[midX] = lenLabel + 2
	}
	e.LabelLine = []GridCoord{chosen.line[0], chosen.line[1]}
}

func calcLineWidth(g *Graph, a, b GridCoord) int {
	total := 0
	x0, x1 := minInt(a.X, b.X), maxInt(a.X, b.X)
	for x := x0; x <= x1; x++ {
		total += g.ColumnWidth[x]
	}
	return total
}
