// Package ascii implements the ASCII/Unicode renderer for Mermaid diagrams.
// Ported from AlexanderGrooff/mermaid-ascii (Go) and extended with the
// improvements from beautiful-mermaid (TypeScript).
package ascii

import "fmt"

// ============================================================================
// Coordinate types
// ============================================================================

// GridCoord is a logical grid coordinate.
// Each node occupies a 3×3 block on this grid.
type GridCoord struct{ X, Y int }

// DrawingCoord is a character-level coordinate on the 2D text canvas.
type DrawingCoord struct{ X, Y int }

func (c GridCoord) Equals(o GridCoord) bool     { return c.X == o.X && c.Y == o.Y }
func (c DrawingCoord) Equals(o DrawingCoord) bool { return c.X == o.X && c.Y == o.Y }

// Key returns a map key for a GridCoord.
func (c GridCoord) Key() string { return fmt.Sprintf("%d,%d", c.X, c.Y) }

// Direction models a position within a node's 3×3 block (used as edge attachment offsets).
//
//	(0,0) UL   (1,0) Up   (2,0) UR
//	(0,1) Left (1,1) Mid  (2,1) Right
//	(0,2) LL   (1,2) Down (2,2) LR
type Direction struct{ X, Y int }

var (
	Up         = Direction{1, 0}
	Down       = Direction{1, 2}
	Left       = Direction{0, 1}
	Right      = Direction{2, 1}
	UpperRight = Direction{2, 0}
	UpperLeft  = Direction{0, 0}
	LowerRight = Direction{2, 2}
	LowerLeft  = Direction{0, 2}
	Middle     = Direction{1, 1}
)

// Opposite returns the direction that faces the opposite side of the node block.
func (d Direction) Opposite() Direction {
	switch d {
	case Up:
		return Down
	case Down:
		return Up
	case Left:
		return Right
	case Right:
		return Left
	case UpperRight:
		return LowerLeft
	case UpperLeft:
		return LowerRight
	case LowerRight:
		return UpperLeft
	case LowerLeft:
		return UpperRight
	}
	return Middle
}

// Apply shifts a GridCoord by a Direction offset.
func (c GridCoord) Apply(d Direction) GridCoord {
	return GridCoord{X: c.X + d.X, Y: c.Y + d.Y}
}

// Apply shifts a DrawingCoord by a Direction offset.
func (c DrawingCoord) Apply(d Direction) DrawingCoord {
	return DrawingCoord{X: c.X + d.X, Y: c.Y + d.Y}
}

// ============================================================================
// Canvas
// ============================================================================

// Canvas is a column-major 2D grid of single-character strings.
// canvas[x][y] gives the character at column x, row y.
type Canvas [][]string

// MkCanvas creates a blank canvas of dimensions (x+1) × (y+1) filled with spaces.
func MkCanvas(x, y int) Canvas {
	c := make(Canvas, x+1)
	for i := range c {
		col := make([]string, y+1)
		for j := range col {
			col[j] = " "
		}
		c[i] = col
	}
	return c
}

// CopyCanvas returns a blank canvas of the same size as src.
func CopyCanvas(src Canvas) Canvas {
	if len(src) == 0 {
		return MkCanvas(0, 0)
	}
	return MkCanvas(len(src)-1, len(src[0])-1)
}

// Size returns (maxX, maxY) — the last valid indices.
func (c Canvas) Size() (int, int) {
	if len(c) == 0 {
		return 0, 0
	}
	return len(c) - 1, len(c[0]) - 1
}

// ============================================================================
// Node types
// ============================================================================

// NodeShape identifies the visual shape of a node.
type NodeShape string

const (
	ShapeRectangle   NodeShape = "rectangle"
	ShapeRounded     NodeShape = "rounded"
	ShapeDiamond     NodeShape = "diamond"
	ShapeStadium     NodeShape = "stadium"
	ShapeCircle      NodeShape = "circle"
	ShapeSubroutine  NodeShape = "subroutine"
	ShapeDoubleCircle NodeShape = "doublecircle"
	ShapeHexagon     NodeShape = "hexagon"
	ShapeCylinder    NodeShape = "cylinder"
	ShapeAsymmetric  NodeShape = "asymmetric"
	ShapeTrapezoid   NodeShape = "trapezoid"
	ShapeTrapezoidAlt NodeShape = "trapezoid-alt"
	ShapeStateStart  NodeShape = "state-start"
	ShapeStateEnd    NodeShape = "state-end"
)

// StyleClass holds classDef styling information for a node.
type StyleClass struct {
	Name   string
	Styles map[string]string
}

// Node represents a positioned node in the ASCII render graph.
type Node struct {
	Name           string
	DisplayLabel   string
	Shape          NodeShape
	Index          int
	GridCoord      *GridCoord
	DrawingCoord   *DrawingCoord
	Drawing        Canvas
	Drawn          bool
	StyleClassName string
	StyleClass     StyleClass
}

// ============================================================================
// Edge types
// ============================================================================

// EdgeStyle controls the visual line style of an edge.
type EdgeStyle string

const (
	EdgeSolid  EdgeStyle = "solid"
	EdgeDotted EdgeStyle = "dotted"
	EdgeThick  EdgeStyle = "thick"
)

// Edge represents a directed connection between two nodes.
type Edge struct {
	From         *Node
	To           *Node
	Text         string
	Path         []GridCoord
	LabelLine    []GridCoord
	StartDir     Direction
	EndDir       Direction
	Style        EdgeStyle
	HasArrowStart bool
	HasArrowEnd  bool
}

// ============================================================================
// Subgraph
// ============================================================================

// Subgraph is a named group of nodes rendered with a bounding box.
type Subgraph struct {
	Name      string
	Label     GraphLabel
	Nodes     []*Node
	Parent    *Subgraph
	Children  []*Subgraph
	Direction string // "LR" or "TD" override, empty = inherit
	MinX, MinY, MaxX, MaxY int
}

// ============================================================================
// Graph — full render state
// ============================================================================

// Graph holds all state required for layout and ASCII rendering.
type Graph struct {
	Nodes    []*Node
	Edges    []*Edge
	Drawing  Canvas
	Grid     map[string]*Node // key = GridCoord.Key()
	EdgeCounts map[edgePair]int
	ColumnWidth map[int]int
	RowHeight   map[int]int
	StyleClasses map[string]StyleClass
	StyleType    string
	BoxBorderPadding int
	GraphDirection   string
	PaddingX         int
	PaddingY         int
	Subgraphs        []*Subgraph
	OffsetX, OffsetY int
	UseAscii         bool
}

type edgePair struct{ From, To int }

func newEdgePair(a, b int) edgePair {
	if a < b {
		return edgePair{a, b}
	}
	return edgePair{b, a}
}

// ============================================================================
// GraphLabel — multi-line display text
// ============================================================================

// GraphLabel holds a parsed multi-line node or subgraph label.
type GraphLabel struct {
	Lines []string
	Width int
}

const labelLineGap = 1

// ContentHeight returns the rendered height including inter-line gaps.
func (l GraphLabel) ContentHeight() int {
	if len(l.Lines) == 0 {
		return 0
	}
	return len(l.Lines) + (len(l.Lines)-1)*labelLineGap
}
