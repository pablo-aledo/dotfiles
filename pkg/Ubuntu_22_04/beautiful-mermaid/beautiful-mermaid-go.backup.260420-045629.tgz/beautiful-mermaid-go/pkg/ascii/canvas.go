package ascii

import "strings"

// ============================================================================
// Canvas growth
// ============================================================================

// IncreaseSize grows canvas to fit at least (newX, newY), preserving existing content.
func IncreaseSize(c Canvas, newX, newY int) Canvas {
	maxX, maxY := c.Size()
	if newX <= maxX && newY <= maxY {
		return c
	}
	tx := maxInt(newX, maxX)
	ty := maxInt(newY, maxY)
	grown := MkCanvas(tx, ty)
	for x := 0; x < len(c); x++ {
		for y := 0; y < len(c[x]); y++ {
			grown[x][y] = c[x][y]
		}
	}
	return grown
}

// ============================================================================
// Canvas merge
// ============================================================================

// junction characters for T/cross merging
var junctionChars = map[string]bool{
	"─": true, "│": true, "┌": true, "┐": true, "└": true, "┘": true,
	"├": true, "┤": true, "┬": true, "┴": true, "┼": true,
	"╴": true, "╵": true, "╶": true, "╷": true,
}

func isJunction(s string) bool { return junctionChars[s] }

// mergeJunctions combines two overlapping box-drawing characters into the
// appropriate combined form (e.g. ┤ + ├ → ┼).
func mergeJunctions(base, overlay string) string {
	type pair struct{ a, b string }
	mergeTable := map[pair]string{
		{"─", "│"}: "┼", {"│", "─"}: "┼",
		{"┌", "┘"}: "┼", {"┘", "┌"}: "┼",
		{"┐", "└"}: "┼", {"└", "┐"}: "┼",
		{"─", "┌"}: "┬", {"─", "┐"}: "┬",
		{"─", "└"}: "┴", {"─", "┘"}: "┴",
		{"│", "┌"}: "├", {"│", "┐"}: "┤",
		{"│", "└"}: "├", {"│", "┘"}: "┤",
		{"├", "┤"}: "┼", {"┤", "├"}: "┼",
		{"┬", "┴"}: "┼", {"┴", "┬"}: "┼",
		{"─", "├"}: "┼", {"─", "┤"}: "┼",
		{"│", "┬"}: "┼", {"│", "┴"}: "┼",
	}
	if v, ok := mergeTable[pair{base, overlay}]; ok {
		return v
	}
	return overlay
}

func isAlphanumeric(s string) bool {
	if len(s) != 1 {
		return false
	}
	r := rune(s[0])
	return (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') ||
		(r >= '0' && r <= '9') || r > 127
}

// MergeCanvases overlays one or more canvases onto base at the given offset.
// Non-space characters in overlays overwrite base; junction chars are merged.
func MergeCanvases(base Canvas, offset DrawingCoord, useAscii bool, overlays ...Canvas) Canvas {
	maxX, maxY := base.Size()
	for _, ov := range overlays {
		ox, oy := ov.Size()
		maxX = maxInt(maxX, ox+offset.X)
		maxY = maxInt(maxY, oy+offset.Y)
	}

	merged := MkCanvas(maxX, maxY)
	// Copy base
	for x := 0; x < len(base); x++ {
		for y := 0; y < len(base[x]); y++ {
			merged[x][y] = base[x][y]
		}
	}
	// Apply overlays
	for _, ov := range overlays {
		for x := 0; x < len(ov); x++ {
			for y := 0; y < len(ov[x]); y++ {
				c := ov[x][y]
				if c == " " {
					continue
				}
				mx := x + offset.X
				my := y + offset.Y
				if mx >= len(merged) || my >= len(merged[mx]) {
					continue
				}
				cur := merged[mx][my]
				if !useAscii && isJunction(c) && isJunction(cur) {
					merged[mx][my] = mergeJunctions(cur, c)
				} else if isAlphanumeric(cur) && isAlphanumeric(c) {
					// first label wins
				} else {
					merged[mx][my] = c
				}
			}
		}
	}
	return merged
}

// ============================================================================
// Text drawing
// ============================================================================

// DrawText writes text into the canvas starting at start, expanding if needed.
// Spaces in text do not overwrite existing non-space characters unless forceOverwrite.
func DrawText(c Canvas, start DrawingCoord, text string, forceOverwrite bool) Canvas {
	c = IncreaseSize(c, start.X+len(text), start.Y)
	for i, ch := range text {
		x := start.X + i
		cur := c[x][start.Y]
		if forceOverwrite || cur == " " {
			c[x][start.Y] = string(ch)
		}
	}
	return c
}

// DrawTextOnLine centres text on a horizontal or vertical line segment.
func DrawTextOnLine(c Canvas, line []DrawingCoord, label string) Canvas {
	if len(line) < 2 {
		return c
	}
	minX, maxX := line[0].X, line[1].X
	if minX > maxX {
		minX, maxX = maxX, minX
	}
	minY, maxY := line[0].Y, line[1].Y
	if minY > maxY {
		minY, maxY = maxY, minY
	}
	midX := minX + (maxX-minX)/2
	midY := minY + (maxY-minY)/2
	start := DrawingCoord{X: midX - len(label)/2, Y: midY}
	return DrawText(c, start, label, false)
}

// ============================================================================
// Canvas sizing from grid
// ============================================================================

// SetCanvasSizeToGrid grows the canvas to cover all grid columns and rows.
func SetCanvasSizeToGrid(c Canvas, colWidths, rowHeights map[int]int) Canvas {
	totalX := 0
	for _, w := range colWidths {
		totalX += w
	}
	totalY := 0
	for _, h := range rowHeights {
		totalY += h
	}
	return IncreaseSize(c, totalX, totalY)
}

// ============================================================================
// Canvas → string
// ============================================================================

// CanvasToString converts the canvas to a human-readable string.
// Each row becomes one line; trailing spaces are trimmed per row.
func CanvasToString(c Canvas) string {
	if len(c) == 0 {
		return ""
	}
	_, maxY := c.Size()
	lines := make([]string, maxY+1)
	maxX := len(c) - 1
	for y := 0; y <= maxY; y++ {
		var sb strings.Builder
		for x := 0; x <= maxX; x++ {
			if x < len(c) && y < len(c[x]) {
				sb.WriteString(c[x][y])
			} else {
				sb.WriteString(" ")
			}
		}
		lines[y] = strings.TrimRight(sb.String(), " ")
	}
	// Trim trailing blank lines
	end := len(lines)
	for end > 0 && lines[end-1] == "" {
		end--
	}
	return strings.Join(lines[:end], "\n")
}
