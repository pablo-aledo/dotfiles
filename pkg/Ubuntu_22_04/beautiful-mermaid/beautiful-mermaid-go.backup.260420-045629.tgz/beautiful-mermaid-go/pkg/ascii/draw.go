package ascii

import "strings"

// ============================================================================
// Node box drawing
// ============================================================================

// DrawBox renders a node as a box on a standalone canvas using grid-determined dimensions.
func DrawBox(node *Node, g *Graph) Canvas {
	gc := node.GridCoord
	useAscii := g.UseAscii

	// Width: sum of 2 grid columns (border + content)
	w := 0
	for i := 0; i < 2; i++ {
		w += g.ColumnWidth[gc.X+i]
	}
	// Height: sum of 2 grid rows (border + content)
	h := 0
	for i := 0; i < 2; i++ {
		h += g.RowHeight[gc.Y+i]
	}
	if w < 2 {
		w = 2
	}
	if h < 2 {
		h = 2
	}

	box := MkCanvas(w, h)
	cr := getCorners(node.Shape, useAscii)

	isDoubleBox := node.Shape == ShapeStateEnd
	var hChar, vChar string
	if useAscii {
		if isDoubleBox {
			hChar, vChar = "=", "|"
		} else {
			hChar, vChar = "-", "|"
		}
	} else {
		if isDoubleBox {
			hChar, vChar = "═", "║"
		} else {
			hChar, vChar = "─", "│"
		}
	}

	var effCorners corners
	if isDoubleBox && !useAscii {
		effCorners = corners{"╔", "╗", "╚", "╝"}
	} else {
		effCorners = cr
	}

	// Draw border
	for x := 1; x < w; x++ {
		box[x][0] = hChar
		box[x][h] = hChar
	}
	for y := 1; y < h; y++ {
		box[0][y] = vChar
		box[w][y] = vChar
	}
	box[0][0] = effCorners.TL
	box[w][0] = effCorners.TR
	box[0][h] = effCorners.BL
	box[w][h] = effCorners.BR

	// Center the multi-line label
	lines := NewGraphLabel(node.DisplayLabel).Lines
	textCenterY := h / 2
	startY := textCenterY - (len(lines)-1)/2
	for i, line := range lines {
		tx := w/2 - len(line)/2 + 1
		for j, ch := range line {
			xi := tx + j
			yi := startY + i
			if xi >= 0 && xi <= w && yi >= 0 && yi <= h {
				box[xi][yi] = string(ch)
			}
		}
	}
	return box
}

// ============================================================================
// Subgraph border drawing
// ============================================================================

// DrawSubgraphBox draws a bordered rectangle for a subgraph.
func DrawSubgraphBox(sg *Subgraph, g *Graph) Canvas {
	width := sg.MaxX - sg.MinX
	height := sg.MaxY - sg.MinY
	if width <= 0 || height <= 0 {
		return MkCanvas(0, 0)
	}

	c := MkCanvas(width, height)
	var hChar, vChar, tl, tr, bl, br string
	if g.UseAscii {
		hChar, vChar = "-", "|"
		tl, tr, bl, br = "+", "+", "+", "+"
	} else {
		hChar, vChar = "─", "│"
		tl, tr, bl, br = "┌", "┐", "└", "┘"
	}

	// Draw border
	for x := 1; x < width; x++ {
		c[x][0] = hChar
		c[x][height] = hChar
	}
	for y := 1; y < height; y++ {
		c[0][y] = vChar
		c[width][y] = vChar
	}
	c[0][0] = tl
	c[width][0] = tr
	c[0][height] = bl
	c[width][height] = br

	return c
}

// DrawSubgraphLabel draws the name of a subgraph near the top of its bounding box.
func DrawSubgraphLabel(sg *Subgraph, g *Graph) (Canvas, DrawingCoord) {
	width := sg.MaxX - sg.MinX
	height := sg.MaxY - sg.MinY
	if width <= 0 || height <= 0 {
		return MkCanvas(0, 0), DrawingCoord{}
	}

	c := MkCanvas(width, height)
	lines := strings.Split(sg.Name, "\n")
	for i, line := range lines {
		labelY := 1 + i
		labelX := width/2 - len(line)/2
		if labelX < 1 {
			labelX = 1
		}
		for j, ch := range line {
			xi := labelX + j
			yi := labelY
			if xi < width && yi < height {
				c[xi][yi] = string(ch)
			}
		}
	}
	return c, DrawingCoord{X: sg.MinX, Y: sg.MinY}
}

// ============================================================================
// Arrow drawing
// ============================================================================

// arrowHead returns the arrow-head character for a given direction.
func arrowHead(d Direction, useAscii bool) string {
	if useAscii {
		switch d {
		case Up:
			return "^"
		case Down:
			return "v"
		case Left:
			return "<"
		case Right:
			return ">"
		}
		return "*"
	}
	switch d {
	case Up:
		return "▲"
	case Down:
		return "▼"
	case Left:
		return "◄"
	case Right:
		return "►"
	case UpperRight:
		return "◥"
	case UpperLeft:
		return "◤"
	case LowerRight:
		return "◢"
	case LowerLeft:
		return "◣"
	}
	return "●"
}

// DrawArrow renders all visual parts of an edge, returning 5 canvases:
// path, boxStart, arrowHeadEnd, arrowHeadStart, corners, label.
func DrawArrow(g *Graph, e *Edge) (path, boxStart, arrowEnd, arrowStart, corners, label Canvas) {
	path = CopyCanvas(g.Drawing)
	boxStart = CopyCanvas(g.Drawing)
	arrowEnd = CopyCanvas(g.Drawing)
	arrowStart = CopyCanvas(g.Drawing)
	corners = CopyCanvas(g.Drawing)
	label = CopyCanvas(g.Drawing)

	if len(e.Path) == 0 {
		return
	}

	// Draw the path lines
	path = drawPath(g, e, path)
	// Box start connector
	boxStart = drawBoxStart(g, e, boxStart)
	// Arrow heads
	arrowEnd = drawArrowHead(g, e, arrowEnd, false)
	if e.HasArrowStart {
		arrowStart = drawArrowHead(g, e, arrowStart, true)
	}
	// Corners at bends
	corners = drawCorners(g, e, corners)
	// Edge label
	label = drawEdgeLabel(g, e, label)
	return
}

func drawPath(g *Graph, e *Edge, d Canvas) Canvas {
	prev := e.Path[0]
	for _, next := range e.Path[1:] {
		prevDC := GridToDrawingCoord(g, prev)
		nextDC := GridToDrawingCoord(g, next)
		if prevDC.Equals(nextDC) {
			prev = next
			continue
		}
		dir := determineDirection(prev, next)
		d = drawLine(g, d, prevDC, nextDC, dir)
		prev = next
	}
	return d
}

func drawLine(g *Graph, d Canvas, from, to DrawingCoord, dir Direction) Canvas {
	useAscii := g.UseAscii
	var hChar, vChar string
	if useAscii {
		hChar, vChar = "-", "|"
	} else {
		hChar, vChar = "─", "│"
	}

	switch dir {
	case Up:
		for y := from.Y - 1; y >= to.Y+1; y-- {
			d = IncreaseSize(d, from.X, y)
			d[from.X][y] = vChar
		}
	case Down:
		for y := from.Y + 1; y <= to.Y-1; y++ {
			d = IncreaseSize(d, from.X, y)
			d[from.X][y] = vChar
		}
	case Left:
		for x := from.X - 1; x >= to.X+1; x-- {
			d = IncreaseSize(d, x, from.Y)
			d[x][from.Y] = hChar
		}
	case Right:
		for x := from.X + 1; x <= to.X-1; x++ {
			d = IncreaseSize(d, x, from.Y)
			d[x][from.Y] = hChar
		}
	}
	return d
}

func drawBoxStart(g *Graph, e *Edge, d Canvas) Canvas {
	if g.UseAscii || len(e.Path) < 2 {
		return d
	}
	dir := determineDirection(e.Path[0], e.Path[1])
	from := GridToDrawingCoord(g, e.Path[0].Apply(e.StartDir))

	var char string
	switch dir {
	case Up:
		char = "┴"
		from.Y++
	case Down:
		char = "┬"
		from.Y--
	case Left:
		char = "┤"
		from.X++
	case Right:
		char = "├"
		from.X--
	}
	if char != "" {
		d = IncreaseSize(d, from.X, from.Y)
		d[from.X][from.Y] = char
	}
	return d
}

func drawArrowHead(g *Graph, e *Edge, d Canvas, atStart bool) Canvas {
	if len(e.Path) == 0 {
		return d
	}
	var pos DrawingCoord
	var dir Direction
	if atStart {
		pos = GridToDrawingCoord(g, e.Path[0])
		if len(e.Path) >= 2 {
			dir = determineDirection(e.Path[1], e.Path[0]) // reversed
		} else {
			dir = e.StartDir
		}
	} else {
		last := e.Path[len(e.Path)-1]
		pos = GridToDrawingCoord(g, last)
		if len(e.Path) >= 2 {
			prev := e.Path[len(e.Path)-2]
			dir = determineDirection(prev, last)
		} else {
			dir = e.EndDir
		}
	}
	char := arrowHead(dir, g.UseAscii)
	d = IncreaseSize(d, pos.X, pos.Y)
	d[pos.X][pos.Y] = char
	return d
}

func drawCorners(g *Graph, e *Edge, d Canvas) Canvas {
	useAscii := g.UseAscii
	for i := 1; i < len(e.Path)-1; i++ {
		dc := GridToDrawingCoord(g, e.Path[i])
		prevDir := determineDirection(e.Path[i-1], e.Path[i])
		nextDir := determineDirection(e.Path[i], e.Path[i+1])

		var char string
		if !useAscii {
			switch {
			case (dirEquals(prevDir, Right) && dirEquals(nextDir, Down)) ||
				(dirEquals(prevDir, Up) && dirEquals(nextDir, Left)):
				char = "┐"
			case (dirEquals(prevDir, Right) && dirEquals(nextDir, Up)) ||
				(dirEquals(prevDir, Down) && dirEquals(nextDir, Left)):
				char = "┘"
			case (dirEquals(prevDir, Left) && dirEquals(nextDir, Down)) ||
				(dirEquals(prevDir, Up) && dirEquals(nextDir, Right)):
				char = "┌"
			case (dirEquals(prevDir, Left) && dirEquals(nextDir, Up)) ||
				(dirEquals(prevDir, Down) && dirEquals(nextDir, Right)):
				char = "└"
			default:
				char = "+"
			}
		} else {
			char = "+"
		}

		d = IncreaseSize(d, dc.X, dc.Y)
		d[dc.X][dc.Y] = char
	}
	return d
}

func drawEdgeLabel(g *Graph, e *Edge, d Canvas) Canvas {
	if len(e.Text) == 0 || len(e.LabelLine) < 2 {
		return d
	}
	line := LineToDrawing(g, e.LabelLine)
	return DrawTextOnLine(d, line, e.Text)
}

// ============================================================================
// Subgraph depth sort
// ============================================================================

func subgraphDepth(sg *Subgraph) int {
	if sg.Parent == nil {
		return 0
	}
	return 1 + subgraphDepth(sg.Parent)
}

func sortSubgraphsByDepth(sgs []*Subgraph) []*Subgraph {
	sorted := make([]*Subgraph, len(sgs))
	copy(sorted, sgs)
	for i := 0; i < len(sorted); i++ {
		for j := i + 1; j < len(sorted); j++ {
			if subgraphDepth(sorted[i]) > subgraphDepth(sorted[j]) {
				sorted[i], sorted[j] = sorted[j], sorted[i]
			}
		}
	}
	return sorted
}

// ============================================================================
// Top-level draw orchestrator
// ============================================================================

// DrawGraph renders the full graph onto g.Drawing and returns it.
func DrawGraph(g *Graph) Canvas {
	useAscii := g.UseAscii

	// Draw subgraph borders (outermost first)
	for _, sg := range sortSubgraphsByDepth(g.Subgraphs) {
		sgCanvas := DrawSubgraphBox(sg, g)
		offset := DrawingCoord{X: sg.MinX, Y: sg.MinY}
		g.Drawing = MergeCanvases(g.Drawing, offset, useAscii, sgCanvas)
	}

	// Draw node boxes
	for _, node := range g.Nodes {
		if !node.Drawn && node.DrawingCoord != nil && node.Drawing != nil {
			g.Drawing = MergeCanvases(g.Drawing, *node.DrawingCoord, useAscii, node.Drawing)
			node.Drawn = true
		}
	}

	// Collect edge drawing layers
	var lineCanvases, cornerCanvases, arrowEndCanvases, arrowStartCanvases, boxStartCanvases, labelCanvases []Canvas

	for _, e := range g.Edges {
		path, boxStart, arrowEnd, arrowStart, corners, label := DrawArrow(g, e)
		lineCanvases = append(lineCanvases, path)
		cornerCanvases = append(cornerCanvases, corners)
		arrowEndCanvases = append(arrowEndCanvases, arrowEnd)
		arrowStartCanvases = append(arrowStartCanvases, arrowStart)
		boxStartCanvases = append(boxStartCanvases, boxStart)
		labelCanvases = append(labelCanvases, label)
	}

	// Merge in the correct order: lines → corners → arrowheads → box starts → labels
	g.Drawing = MergeCanvases(g.Drawing, DrawingCoord{}, useAscii, lineCanvases...)
	g.Drawing = MergeCanvases(g.Drawing, DrawingCoord{}, useAscii, cornerCanvases...)
	g.Drawing = MergeCanvases(g.Drawing, DrawingCoord{}, useAscii, arrowEndCanvases...)
	g.Drawing = MergeCanvases(g.Drawing, DrawingCoord{}, useAscii, arrowStartCanvases...)
	g.Drawing = MergeCanvases(g.Drawing, DrawingCoord{}, useAscii, boxStartCanvases...)
	g.Drawing = MergeCanvases(g.Drawing, DrawingCoord{}, useAscii, labelCanvases...)

	// Draw subgraph labels on top (so they are not overwritten by arrows)
	for _, sg := range g.Subgraphs {
		if len(sg.Nodes) == 0 {
			continue
		}
		labelCanvas, offset := DrawSubgraphLabel(sg, g)
		g.Drawing = MergeCanvases(g.Drawing, offset, useAscii, labelCanvas)
	}

	return g.Drawing
}
