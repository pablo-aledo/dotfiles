package ascii

import "container/heap"

// ============================================================================
// Priority queue for A*
// ============================================================================

type pqItem struct {
	coord    GridCoord
	priority int
	index    int
}

type priorityQueue []*pqItem

func (pq priorityQueue) Len() int            { return len(pq) }
func (pq priorityQueue) Less(i, j int) bool  { return pq[i].priority < pq[j].priority }
func (pq priorityQueue) Swap(i, j int)       { pq[i], pq[j] = pq[j], pq[i]; pq[i].index = i; pq[j].index = j }
func (pq *priorityQueue) Push(x interface{}) { item := x.(*pqItem); item.index = len(*pq); *pq = append(*pq, item) }
func (pq *priorityQueue) Pop() interface{}   { old := *pq; n := len(old); item := old[n-1]; old[n-1] = nil; *pq = old[:n-1]; return item }

// ============================================================================
// A* heuristic
// ============================================================================

// heuristic is Manhattan distance with a +1 corner penalty to prefer straight lines.
func heuristic(a, b GridCoord) int {
	dx := absInt(a.X - b.X)
	dy := absInt(a.Y - b.Y)
	if dx == 0 || dy == 0 {
		return dx + dy
	}
	return dx + dy + 1
}

// ============================================================================
// A* pathfinding
// ============================================================================

var moveDirs = []GridCoord{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}

func isFreeInGrid(grid map[string]*Node, c GridCoord) bool {
	if c.X < 0 || c.Y < 0 {
		return false
	}
	return grid[c.Key()] == nil
}

// GetPath finds the shortest path from `from` to `to` on the grid using A*.
// Returns nil if no path exists.
func GetPath(grid map[string]*Node, from, to GridCoord) []GridCoord {
	pq := &priorityQueue{}
	heap.Init(pq)
	heap.Push(pq, &pqItem{coord: from, priority: 0})

	costSoFar := map[string]int{from.Key(): 0}
	cameFrom := map[string]*GridCoord{from.Key(): nil}

	for pq.Len() > 0 {
		current := heap.Pop(pq).(*pqItem).coord

		if current.Equals(to) {
			// Reconstruct path
			path := []GridCoord{}
			c := &current
			for c != nil {
				path = append([]GridCoord{*c}, path...)
				c = cameFrom[c.Key()]
			}
			return path
		}

		curCost := costSoFar[current.Key()]
		for _, dir := range moveDirs {
			next := GridCoord{X: current.X + dir.X, Y: current.Y + dir.Y}
			if !isFreeInGrid(grid, next) && !next.Equals(to) {
				continue
			}
			newCost := curCost + 1
			nextKey := next.Key()
			if existing, ok := costSoFar[nextKey]; !ok || newCost < existing {
				costSoFar[nextKey] = newCost
				priority := newCost + heuristic(next, to)
				heap.Push(pq, &pqItem{coord: next, priority: priority})
				cameFrom[nextKey] = &current
			}
		}
	}
	return nil // no path
}

// MergePath removes intermediate waypoints on straight segments.
func MergePath(path []GridCoord) []GridCoord {
	if len(path) <= 2 {
		return path
	}
	remove := map[int]bool{}
	s0 := path[0]
	s1 := path[1]
	for i := 2; i < len(path); i++ {
		s2 := path[i]
		pdx := s1.X - s0.X
		pdy := s1.Y - s0.Y
		dx := s2.X - s1.X
		dy := s2.Y - s1.Y
		if pdx == dx && pdy == dy {
			remove[i-1] = true
		}
		s0 = s1
		s1 = s2
	}
	out := path[:0:0]
	for i, p := range path {
		if !remove[i] {
			out = append(out, p)
		}
	}
	return out
}
