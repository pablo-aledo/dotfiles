package ascii

import (
	"regexp"
	"strings"

	"github.com/mattn/go-runewidth"
)

var htmlBreak = regexp.MustCompile(`(?i)<br\s*/?>`)

// NewGraphLabel parses a raw label string into a GraphLabel.
// Handles HTML <br> tags and literal \n escape sequences.
func NewGraphLabel(raw string) GraphLabel {
	s := htmlBreak.ReplaceAllString(raw, "\n")
	s = strings.ReplaceAll(s, `\n`, "\n")
	lines := strings.Split(s, "\n")
	if len(lines) == 0 {
		lines = []string{""}
	}
	w := 0
	for _, line := range lines {
		if rw := runewidth.StringWidth(line); rw > w {
			w = rw
		}
	}
	return GraphLabel{Lines: lines, Width: w}
}
