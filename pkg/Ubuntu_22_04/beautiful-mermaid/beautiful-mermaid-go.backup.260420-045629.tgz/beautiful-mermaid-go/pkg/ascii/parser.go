package ascii

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"github.com/elliotchance/orderedmap/v2"
)

// ============================================================================
// Raw parse types (intermediate representation)
// ============================================================================

type textNode struct {
	name       string
	label      GraphLabel
	hasLabel   bool
	shape      NodeShape
	styleClass string
}

type graphNodeSpec struct {
	label          GraphLabel
	labelIsExplicit bool
	styleClass     string
	shape          NodeShape
}

type textEdge struct {
	parent    textNode
	child     textNode
	label     string
	style     EdgeStyle
	hasArrowStart bool
	hasArrowEnd   bool
}

type textSubgraph struct {
	id       string
	name     string
	label    GraphLabel
	nodes    []string
	parent   *textSubgraph
	children []*textSubgraph
}

// graphProperties holds the raw parsed data before building the graph.
type graphProperties struct {
	data             *orderedmap.OrderedMap[string, []textEdge]
	nodeSpecs        map[string]graphNodeSpec
	styleClasses     map[string]StyleClass
	boxBorderPadding int
	graphDirection   string
	paddingX         int
	paddingY         int
	subgraphs        []*textSubgraph
	useAscii         bool
}

// ============================================================================
// Text splitting (respects bracket nesting and quoted strings)
// ============================================================================

func splitGraphLines(mermaid string) []string {
	var lines []string
	var current strings.Builder
	bracketDepth := 0
	inQuotes := false

	for i := 0; i < len(mermaid); i++ {
		ch := mermaid[i]
		switch ch {
		case '"':
			inQuotes = !inQuotes
		case '[':
			if !inQuotes {
				bracketDepth++
			}
		case ']':
			if !inQuotes && bracketDepth > 0 {
				bracketDepth--
			}
		case '\n':
			if bracketDepth == 0 {
				lines = append(lines, current.String())
				current.Reset()
				continue
			}
		case '\\':
			if i+1 < len(mermaid) && mermaid[i+1] == 'n' && bracketDepth == 0 {
				lines = append(lines, current.String())
				current.Reset()
				i++
				continue
			}
		}
		current.WriteByte(ch)
	}
	return append(lines, current.String())
}

// ============================================================================
// Node shape patterns (ordered: most-specific first)
// ============================================================================

type nodePattern struct {
	re    *regexp.Regexp
	shape NodeShape
}

var nodePatterns = []nodePattern{
	{regexp.MustCompile(`^([\w-]+)\(\(\((.+?)\)\)\)`), ShapeDoubleCircle},
	{regexp.MustCompile(`^([\w-]+)\(\[(.+?)\]\)`),     ShapeStadium},
	{regexp.MustCompile(`^([\w-]+)\(\((.+?)\)\)`),     ShapeCircle},
	{regexp.MustCompile(`^([\w-]+)\[\[(.+?)\]\]`),     ShapeSubroutine},
	{regexp.MustCompile(`^([\w-]+)\[\((.+?)\)\]`),     ShapeCylinder},
	{regexp.MustCompile(`^([\w-]+)\[\/(.+?)\\\]`),     ShapeTrapezoid},
	{regexp.MustCompile(`^([\w-]+)\[\\(.+?)\/\]`),     ShapeTrapezoidAlt},
	{regexp.MustCompile(`^([\w-]+)>(.+?)\]`),          ShapeAsymmetric},
	{regexp.MustCompile(`^([\w-]+)\{\{(.+?)\}\}`),     ShapeHexagon},
	{regexp.MustCompile(`^([\w-]+)\[(.+?)\]`),         ShapeRectangle},
	{regexp.MustCompile(`^([\w-]+)\((.+?)\)`),         ShapeRounded},
	{regexp.MustCompile(`^([\w-]+)\{(.+?)\}`),         ShapeDiamond},
}

var (
	bareNodeRe      = regexp.MustCompile(`^([\w-]+)`)
	classShorthandRe = regexp.MustCompile(`^:::([\w][\w-]*)`)
	arrowRe         = regexp.MustCompile(`^(<)?(-->|-.->|==>|---|\.-.|-\.\-|===)(?:\|([^|]*)\|)?`)
	textArrowRe     = regexp.MustCompile(`^(<)?(--|-.|\==)\s+(.+?)\s+(-->|---|\.-\>|-\.-|==>|===)`)
)

// ============================================================================
// Node parsing
// ============================================================================

func parseNode(line string) textNode {
	trimmed := strings.TrimSpace(line)
	styleClass := ""
	if idx := strings.LastIndex(trimmed, ":::"); idx != -1 {
		styleClass = strings.TrimSpace(trimmed[idx+3:])
		trimmed = strings.TrimSpace(trimmed[:idx])
	}

	for _, pat := range nodePatterns {
		m := pat.re.FindStringSubmatch(trimmed)
		if m != nil {
			return textNode{
				name:       m[1],
				label:      NewGraphLabel(strings.Trim(m[2], `"`)),
				hasLabel:   true,
				shape:      pat.shape,
				styleClass: styleClass,
			}
		}
	}
	return textNode{name: trimmed, label: NewGraphLabel(trimmed), shape: ShapeRectangle, styleClass: styleClass}
}

// ============================================================================
// Edge style helpers
// ============================================================================

func arrowStyleFromOp(op string) (EdgeStyle, bool) {
	switch op {
	case "-.-.", "-.->":
		return EdgeDotted, true
	case "==>", "===":
		return EdgeThick, true
	}
	return EdgeSolid, strings.HasSuffix(op, ">")
}

// ============================================================================
// Line parser
// ============================================================================

func (gp *graphProperties) parseString(line string) ([]textNode, error) {
	// Patterns in priority order
	type handler struct {
		re  *regexp.Regexp
		fn  func([]string) ([]textNode, error)
	}

	handlers := []handler{
		// Empty line
		{regexp.MustCompile(`^\s*$`), func(_ []string) ([]textNode, error) {
			return nil, nil
		}},
		// Edge with pipe label: A -->|label| B
		{regexp.MustCompile(`(?s)^(.+)\s+-->\|(.+)\|\s+(.+)$`), func(m []string) ([]textNode, error) {
			lhs := gp.resolveNodeGroup(m[0])
			rhs := gp.resolveNodeGroup(m[2])
			return gp.setArrowWithLabel(lhs, rhs, m[1], EdgeSolid, false, true), nil
		}},
		// Plain arrow: A --> B
		{regexp.MustCompile(`(?s)^(.+)\s+-->\s+(.+)$`), func(m []string) ([]textNode, error) {
			lhs := gp.resolveNodeGroup(m[0])
			rhs := gp.resolveNodeGroup(m[1])
			return gp.setArrow(lhs, rhs), nil
		}},
		// classDef
		{regexp.MustCompile(`^classDef\s+(\S+)\s+(.+)$`), func(m []string) ([]textNode, error) {
			gp.styleClasses[m[0]] = parseStyleClass(m[0], m[1])
			return nil, nil
		}},
		// & grouping: A & B
		{regexp.MustCompile(`(?s)^(.+) & (.+)$`), func(m []string) ([]textNode, error) {
			lhs := gp.resolveNodeGroup(m[0])
			rhs := gp.resolveNodeGroup(m[1])
			return append(lhs, rhs...), nil
		}},
	}

	for _, h := range handlers {
		m := h.re.FindStringSubmatch(line)
		if m != nil {
			return h.fn(m[1:])
		}
	}
	return nil, fmt.Errorf("cannot parse: %s", line)
}

func (gp *graphProperties) resolveNodeGroup(s string) []textNode {
	s = strings.TrimSpace(s)
	nodes, err := gp.parseString(s)
	if err != nil || len(nodes) == 0 {
		return []textNode{parseNode(s)}
	}
	return nodes
}

func (gp *graphProperties) setArrow(lhs, rhs []textNode) []textNode {
	return gp.setArrowWithLabel(lhs, rhs, "", EdgeSolid, false, true)
}

func (gp *graphProperties) setArrowWithLabel(lhs, rhs []textNode, label string, style EdgeStyle, hasStart, hasEnd bool) []textNode {
	for _, l := range lhs {
		for _, r := range rhs {
			rememberNode(l, gp.nodeSpecs)
			rememberNode(r, gp.nodeSpecs)
			if children, ok := gp.data.Get(l.name); ok {
				gp.data.Set(l.name, append(children, textEdge{l, r, label, style, hasStart, hasEnd}))
			} else {
				gp.data.Set(l.name, []textEdge{{l, r, label, style, hasStart, hasEnd}})
			}
			if _, ok := gp.data.Get(r.name); !ok {
				gp.data.Set(r.name, nil)
			}
		}
	}
	return rhs
}

func rememberNode(n textNode, specs map[string]graphNodeSpec) {
	spec := specs[n.name]
	if n.hasLabel || len(spec.label.Lines) == 0 {
		spec.label = n.label
		spec.labelIsExplicit = n.hasLabel
	}
	if n.styleClass != "" {
		spec.styleClass = n.styleClass
	}
	if n.shape != "" {
		spec.shape = n.shape
	}
	specs[n.name] = spec
}

func addNode(n textNode, data *orderedmap.OrderedMap[string, []textEdge], specs map[string]graphNodeSpec) {
	rememberNode(n, specs)
	if _, ok := data.Get(n.name); !ok {
		data.Set(n.name, nil)
	}
}

func parseStyleClass(name, styles string) StyleClass {
	m := make(map[string]string)
	for _, kv := range strings.Split(styles, ",") {
		parts := strings.SplitN(kv, ":", 2)
		if len(parts) == 2 {
			m[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}
	return StyleClass{Name: name, Styles: m}
}

// ============================================================================
// Subgraph header parser
// ============================================================================

var subgraphHeaderRe = regexp.MustCompile(`^(\S+)\s*\[(.+)\]$`)

func parseSubgraphHeader(header string) textSubgraph {
	trimmed := strings.TrimSpace(header)
	labelText := trimmed
	id := ""
	if m := subgraphHeaderRe.FindStringSubmatch(trimmed); m != nil {
		id = strings.TrimSpace(m[1])
		labelText = strings.Trim(strings.TrimSpace(m[2]), `"`)
	}
	return textSubgraph{
		id:    id,
		name:  labelText,
		label: NewGraphLabel(labelText),
	}
}

// ============================================================================
// Main parse entry point
// ============================================================================

var (
	paddingRe   = regexp.MustCompile(`^(?i)padding([xy])\s*=\s*(\d+)$`)
	subgraphRe  = regexp.MustCompile(`^\s*subgraph\s+(.+)$`)
	endRe       = regexp.MustCompile(`^\s*end\s*$`)
	classAssignRe = regexp.MustCompile(`^class\s+([\w,]+)\s+(\w+)$`)
)

// MermaidFileToMap parses a Mermaid flowchart/state diagram into a graphProperties.
func MermaidFileToMap(mermaid string) (*graphProperties, error) {
	rawLines := splitGraphLines(mermaid)

	// Strip comments and separator
	var lines []string
	for _, line := range rawLines {
		if line == "---" {
			break
		}
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "%%") {
			continue
		}
		if idx := strings.Index(line, "%%"); idx != -1 {
			line = strings.TrimSpace(line[:idx])
		}
		if strings.TrimSpace(line) != "" {
			lines = append(lines, line)
		}
	}

	data := orderedmap.NewOrderedMap[string, []textEdge]()
	gp := &graphProperties{
		data:             data,
		nodeSpecs:        make(map[string]graphNodeSpec),
		styleClasses:     make(map[string]StyleClass),
		boxBorderPadding: 1,
		paddingX:         5,
		paddingY:         5,
	}

	// Consume optional padding directives before the graph header
	for len(lines) > 0 {
		trimmed := strings.TrimSpace(lines[0])
		if m := paddingRe.FindStringSubmatch(trimmed); m != nil {
			val, _ := strconv.Atoi(m[2])
			if strings.EqualFold(m[1], "x") {
				gp.paddingX = val
			} else {
				gp.paddingY = val
			}
			lines = lines[1:]
			continue
		}
		break
	}

	if len(lines) == 0 {
		return gp, fmt.Errorf("missing graph definition")
	}

	// Parse header direction
	switch lines[0] {
	case "graph LR", "flowchart LR":
		gp.graphDirection = "LR"
	case "graph TD", "flowchart TD", "graph TB", "flowchart TB":
		gp.graphDirection = "TD"
	default:
		return gp, fmt.Errorf("unsupported graph type %q", lines[0])
	}
	lines = lines[1:]

	// Parse body
	var subgraphStack []*textSubgraph

	for _, line := range lines {
		trimmed := strings.TrimSpace(line)

		if m := subgraphRe.FindStringSubmatch(trimmed); m != nil {
			header := parseSubgraphHeader(m[1])
			sg := &textSubgraph{
				id:    header.id,
				name:  header.name,
				label: header.label,
			}
			if len(subgraphStack) > 0 {
				parent := subgraphStack[len(subgraphStack)-1]
				sg.parent = parent
				parent.children = append(parent.children, sg)
			}
			subgraphStack = append(subgraphStack, sg)
			gp.subgraphs = append(gp.subgraphs, sg)
			continue
		}

		if endRe.MatchString(trimmed) {
			if len(subgraphStack) > 0 {
				subgraphStack = subgraphStack[:len(subgraphStack)-1]
			}
			continue
		}

		// Snapshot existing nodes to detect new ones
		existingNodes := map[string]bool{}
		for el := data.Front(); el != nil; el = el.Next() {
			existingNodes[el.Key] = true
		}

		nodes, err := gp.parseString(line)
		if err != nil {
			node := parseNode(line)
			addNode(node, data, gp.nodeSpecs)
		} else {
			for _, n := range nodes {
				addNode(n, data, gp.nodeSpecs)
			}
		}

		// Add new nodes to active subgraphs
		if len(subgraphStack) > 0 {
			for el := data.Front(); el != nil; el = el.Next() {
				if existingNodes[el.Key] {
					continue
				}
				for _, sg := range subgraphStack {
					found := false
					for _, id := range sg.nodes {
						if id == el.Key {
							found = true
							break
						}
					}
					if !found {
						sg.nodes = append(sg.nodes, el.Key)
					}
				}
			}
		}
	}
	return gp, nil
}

// ============================================================================
// Build Graph from parsed properties
// ============================================================================

// BuildGraph converts parsed graphProperties into a renderable Graph.
func BuildGraph(gp *graphProperties) *Graph {
	g := &Graph{
		Drawing:          MkCanvas(0, 0),
		Grid:             make(map[string]*Node),
		EdgeCounts:       make(map[edgePair]int),
		ColumnWidth:      make(map[int]int),
		RowHeight:        make(map[int]int),
		StyleClasses:     gp.styleClasses,
		StyleType:        "cli",
		BoxBorderPadding: gp.boxBorderPadding,
		GraphDirection:   gp.graphDirection,
		PaddingX:         gp.paddingX,
		PaddingY:         gp.paddingY,
		UseAscii:         gp.useAscii,
	}

	index := 0
	nodeByName := make(map[string]*Node)

	for el := gp.data.Front(); el != nil; el = el.Next() {
		nodeName := el.Key
		edges := el.Value
		spec := gp.nodeSpecs[nodeName]

		parent := nodeByName[nodeName]
		if parent == nil {
			parent = &Node{
				Name:           nodeName,
				DisplayLabel:   strings.Join(spec.label.Lines, "\n"),
				Shape:          spec.shape,
				Index:          index,
				StyleClassName: spec.styleClass,
			}
			if parent.Shape == "" {
				parent.Shape = ShapeRectangle
			}
			g.Nodes = append(g.Nodes, parent)
			nodeByName[nodeName] = parent
			index++
		}

		for _, te := range edges {
			childSpec := gp.nodeSpecs[te.child.name]
			child := nodeByName[te.child.name]
			if child == nil {
				child = &Node{
					Name:           te.child.name,
					DisplayLabel:   strings.Join(childSpec.label.Lines, "\n"),
					Shape:          childSpec.shape,
					Index:          index,
					StyleClassName: childSpec.styleClass,
				}
				if child.Shape == "" {
					child.Shape = ShapeRectangle
				}
				g.Nodes = append(g.Nodes, child)
				nodeByName[te.child.name] = child
				index++
			}
			g.Edges = append(g.Edges, &Edge{
				From:          parent,
				To:            child,
				Text:          te.label,
				Style:         te.style,
				HasArrowStart: te.hasArrowStart,
				HasArrowEnd:   te.hasArrowEnd,
			})
		}
	}

	// Apply style classes to nodes
	for _, node := range g.Nodes {
		if node.StyleClassName != "" {
			if sc, ok := gp.styleClasses[node.StyleClassName]; ok {
				node.StyleClass = sc
			}
		}
	}

	// Build subgraphs
	for _, tsg := range gp.subgraphs {
		sg := &Subgraph{
			Name:  tsg.name,
			Label: tsg.label,
		}
		for _, nodeName := range tsg.nodes {
			if n := nodeByName[nodeName]; n != nil {
				sg.Nodes = append(sg.Nodes, n)
			}
		}
		g.Subgraphs = append(g.Subgraphs, sg)
	}

	// Wire up parent/child relationships
	for i, tsg := range gp.subgraphs {
		if tsg.parent != nil {
			for j, other := range gp.subgraphs {
				if other == tsg.parent {
					g.Subgraphs[i].Parent = g.Subgraphs[j]
					break
				}
			}
		}
		for _, childTsg := range tsg.children {
			for j, other := range gp.subgraphs {
				if other == childTsg {
					g.Subgraphs[i].Children = append(g.Subgraphs[i].Children, g.Subgraphs[j])
					break
				}
			}
		}
	}

	return g
}
