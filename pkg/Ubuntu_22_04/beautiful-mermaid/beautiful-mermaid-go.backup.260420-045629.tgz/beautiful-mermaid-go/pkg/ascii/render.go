package ascii

import (
	"strings"

	"github.com/beautiful-mermaid/go/pkg/diagram"
)

// RenderFlowchart parses and renders a Mermaid flowchart/state diagram to ASCII.
func RenderFlowchart(input string, config *diagram.Config) (string, error) {
	if config == nil {
		config = diagram.DefaultConfig()
	}

	gp, err := MermaidFileToMap(input)
	if err != nil {
		return "", err
	}
	gp.boxBorderPadding = config.BoxBorderPadding
	gp.paddingX = config.PaddingBetweenX
	gp.paddingY = config.PaddingBetweenY
	gp.useAscii = config.UseAscii

	g := BuildGraph(gp)

	CreateMapping(g)
	DrawGraph(g)

	out := CanvasToString(g.Drawing)
	return strings.TrimRight(out, "\n") + "\n", nil
}
