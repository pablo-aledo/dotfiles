// Package xychart implements parsing and ASCII rendering of Mermaid xychart-beta.
package xychart

import (
	"fmt"
	"math"
	"regexp"
	"strconv"
	"strings"

	"github.com/beautiful-mermaid/go/pkg/diagram"
)

// ============================================================================
// Types
// ============================================================================

type SeriesType string

const (
	SeriesBar  SeriesType = "bar"
	SeriesLine SeriesType = "line"
)

type Series struct {
	Type   SeriesType
	Values []float64
}

type XYChart struct {
	Title      string
	Horizontal bool
	XLabels    []string   // categorical labels
	XMin, XMax float64    // numeric range (if no labels)
	YLabel     string
	YMin, YMax float64
	HasYRange  bool
	Series     []Series
}

// ============================================================================
// Parser
// ============================================================================

var (
	titleRe    = regexp.MustCompile(`(?i)^\s*title\s+"([^"]+)"\s*$`)
	xAxisRe    = regexp.MustCompile(`(?i)^\s*x-axis\s+(.+)$`)
	yAxisRe    = regexp.MustCompile(`(?i)^\s*y-axis\s+(?:"([^"]+)"\s+)?(\d+(?:\.\d+)?)\s*-->\s*(\d+(?:\.\d+)?)\s*$`)
	yAxisLabelRe = regexp.MustCompile(`(?i)^\s*y-axis\s+"([^"]+)"\s*$`)
	barRe      = regexp.MustCompile(`(?i)^\s*bar\s+\[([^\]]+)\]\s*$`)
	lineRe     = regexp.MustCompile(`(?i)^\s*line\s+\[([^\]]+)\]\s*$`)
	numListRe  = regexp.MustCompile(`\[([^\]]+)\]`)
	numRangeRe = regexp.MustCompile(`^(\d+(?:\.\d+)?)\s*-->\s*(\d+(?:\.\d+)?)$`)
)

func IsXYChart(input string) bool {
	for _, line := range strings.Split(input, "\n") {
		t := strings.TrimSpace(line)
		if t == "" || strings.HasPrefix(t, "%%") {
			continue
		}
		return strings.HasPrefix(strings.ToLower(t), "xychart")
	}
	return false
}

func parseNumbers(s string) []float64 {
	var nums []float64
	for _, tok := range strings.Split(s, ",") {
		tok = strings.TrimSpace(tok)
		if v, err := strconv.ParseFloat(tok, 64); err == nil {
			nums = append(nums, v)
		}
	}
	return nums
}

func parseLabels(s string) []string {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		s = s[1 : len(s)-1]
	}
	var labels []string
	for _, tok := range strings.Split(s, ",") {
		labels = append(labels, strings.TrimSpace(tok))
	}
	return labels
}

func Parse(input string) (*XYChart, error) {
	lines := strings.Split(strings.TrimSpace(input), "\n")
	chart := &XYChart{YMin: 0, YMax: 100}

	for _, raw := range lines {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "%%") {
			continue
		}
		lower := strings.ToLower(line)

		// Header
		if strings.HasPrefix(lower, "xychart") {
			chart.Horizontal = strings.Contains(lower, "horizontal")
			continue
		}

		// Title
		if m := titleRe.FindStringSubmatch(line); m != nil {
			chart.Title = m[1]
			continue
		}

		// X-axis
		if m := xAxisRe.FindStringSubmatch(line); m != nil {
			rest := strings.TrimSpace(m[1])
			// Strip optional label string before the list
			if strings.HasPrefix(rest, `"`) {
				end := strings.Index(rest[1:], `"`)
				if end >= 0 {
					rest = strings.TrimSpace(rest[end+2:])
				}
			}
			// Numeric range?
			if rm := numRangeRe.FindStringSubmatch(rest); rm != nil {
				chart.XMin, _ = strconv.ParseFloat(rm[1], 64)
				chart.XMax, _ = strconv.ParseFloat(rm[2], 64)
			} else {
				chart.XLabels = parseLabels(rest)
			}
			continue
		}

		// Y-axis with range
		if m := yAxisRe.FindStringSubmatch(line); m != nil {
			if m[1] != "" {
				chart.YLabel = m[1]
			}
			chart.YMin, _ = strconv.ParseFloat(m[2], 64)
			chart.YMax, _ = strconv.ParseFloat(m[3], 64)
			chart.HasYRange = true
			continue
		}

		// Y-axis label only
		if m := yAxisLabelRe.FindStringSubmatch(line); m != nil {
			chart.YLabel = m[1]
			continue
		}

		// Bar series
		if m := barRe.FindStringSubmatch(line); m != nil {
			vals := parseNumbers(m[1])
			chart.Series = append(chart.Series, Series{Type: SeriesBar, Values: vals})
			continue
		}

		// Line series
		if m := lineRe.FindStringSubmatch(line); m != nil {
			vals := parseNumbers(m[1])
			chart.Series = append(chart.Series, Series{Type: SeriesLine, Values: vals})
			continue
		}
	}

	// Auto-compute Y range from data if not explicitly set
	if !chart.HasYRange {
		for _, s := range chart.Series {
			for _, v := range s.Values {
				if v > chart.YMax {
					chart.YMax = v
				}
				if v < chart.YMin {
					chart.YMin = v
				}
			}
		}
	}

	return chart, nil
}

// ============================================================================
// ASCII Renderer
// ============================================================================

const (
	chartHeight = 12 // rows of the plot area
	chartWidth  = 60 // columns of the plot area
	barChars    = "█▇▆▅▄▃▂▁"
)

func Render(chart *XYChart, config *diagram.Config) (string, error) {
	if chart == nil {
		return "", fmt.Errorf("nil chart")
	}
	useAscii := config != nil && config.UseAscii

	var sb strings.Builder

	// Title
	if chart.Title != "" {
		title := "  " + chart.Title
		sb.WriteString(title + "\n")
		sb.WriteString("  " + strings.Repeat("─", len(title)-2) + "\n")
		if useAscii {
			sb.WriteString("  " + strings.Repeat("-", len(title)-2) + "\n")
		}
	}

	if len(chart.Series) == 0 {
		sb.WriteString("  (no data)\n")
		return sb.String(), nil
	}

	yRange := chart.YMax - chart.YMin
	if yRange == 0 {
		yRange = 1
	}

	// Determine x labels
	xLabels := chart.XLabels
	if len(xLabels) == 0 {
		// Generate from first series length
		n := 0
		for _, s := range chart.Series {
			if len(s.Values) > n {
				n = len(s.Values)
			}
		}
		for i := 0; i < n; i++ {
			xLabels = append(xLabels, fmt.Sprintf("%d", i))
		}
	}
	nBuckets := len(xLabels)
	if nBuckets == 0 {
		sb.WriteString("  (no x-axis data)\n")
		return sb.String(), nil
	}

	// Build a grid: rows = chartHeight, cols = nBuckets
	// Each cell contains a character to render
	type cell struct{ ch string }
	grid := make([][]cell, chartHeight)
	for i := range grid {
		grid[i] = make([]cell, nBuckets)
		for j := range grid[i] {
			grid[i][j] = cell{" "}
		}
	}

	// Render series into grid (bars use full-block, lines use dots/asterisks)
	seriesChars := []string{"█", "░", "▒", "▓"}
	seriesASCII := []string{"#", "=", "*", "+"}

	for si, s := range chart.Series {
		barChar := seriesChars[si%len(seriesChars)]
		lineChar := "●"
		if useAscii {
			barChar = seriesASCII[si%len(seriesASCII)]
			lineChar = "*"
		}

		for xi := 0; xi < nBuckets && xi < len(s.Values); xi++ {
			v := s.Values[xi]
			// Normalise to [0, chartHeight]
			normalised := (v - chart.YMin) / yRange
			heightCells := int(math.Round(normalised * float64(chartHeight)))
			if heightCells < 0 {
				heightCells = 0
			}
			if heightCells > chartHeight {
				heightCells = chartHeight
			}

			if s.Type == SeriesBar {
				for row := chartHeight - 1; row >= chartHeight-heightCells; row-- {
					grid[row][xi] = cell{barChar}
				}
			} else {
				// Line: just mark the top point
				row := chartHeight - heightCells
				if row < 0 {
					row = 0
				}
				if row >= chartHeight {
					row = chartHeight - 1
				}
				grid[row][xi] = cell{lineChar}
			}
		}
	}

	// Compute y-axis label width
	yAxisW := len(fmt.Sprintf("%.0f", chart.YMax)) + 1
	if yAxisW < 5 {
		yAxisW = 5
	}

	// Render rows
	vChar := "│"
	if useAscii {
		vChar = "|"
	}

	// Y-axis ticks
	for row := 0; row < chartHeight; row++ {
		// Y value for this row
		yVal := chart.YMax - (float64(row)/float64(chartHeight-1))*(chart.YMax-chart.YMin)
		var yLabel string
		if row == 0 || row == chartHeight/2 || row == chartHeight-1 {
			yLabel = fmt.Sprintf("%*.0f", yAxisW-1, yVal)
		} else {
			yLabel = strings.Repeat(" ", yAxisW-1)
		}
		sb.WriteString(yLabel + " " + vChar)

		// Each bucket
		colW := chartWidth / nBuckets
		if colW < 2 {
			colW = 2
		}
		for xi := 0; xi < nBuckets; xi++ {
			ch := grid[row][xi].ch
			sb.WriteString(strings.Repeat(ch, colW))
		}
		sb.WriteString("\n")
	}

	// X-axis line
	xLine := strings.Repeat(" ", yAxisW) + "+"
	if !useAscii {
		xLine = strings.Repeat(" ", yAxisW) + "└"
	}
	colW := chartWidth / nBuckets
	if colW < 2 {
		colW = 2
	}
	xLine += strings.Repeat("─", nBuckets*colW)
	if useAscii {
		xLine = strings.Repeat(" ", yAxisW) + "+" + strings.Repeat("-", nBuckets*colW)
	}
	sb.WriteString(xLine + "\n")

	// X labels
	labelLine := strings.Repeat(" ", yAxisW+1)
	for _, lbl := range xLabels {
		cell := lbl
		if len(cell) > colW {
			cell = cell[:colW]
		}
		labelLine += fmt.Sprintf("%-*s", colW, cell)
	}
	sb.WriteString(strings.TrimRight(labelLine, " ") + "\n")

	// Legend
	if len(chart.Series) > 1 {
		sb.WriteString("\n")
		for si, s := range chart.Series {
			ch := seriesChars[si%len(seriesChars)]
			if useAscii {
				ch = seriesASCII[si%len(seriesASCII)]
			}
			sb.WriteString(fmt.Sprintf("  %s %s\n", ch, string(s.Type)))
		}
	}

	return sb.String(), nil
}
