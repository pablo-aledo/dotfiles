package diagram

// Diagram is the common interface for all diagram types.
// Implementations: GraphDiagram, SequenceDiagram.
type Diagram interface {
	Parse(input string) error
	Render(config *Config) (string, error)
	Type() string
}
