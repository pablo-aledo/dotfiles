package diagram

import "fmt"

// Config holds all configuration for diagram rendering.
// Thread-safe: pass copies, never share pointers across goroutines.
type Config struct {
	// UseAscii selects ASCII characters (+,-,|) vs Unicode box-drawing (┌,─,│).
	UseAscii bool

	// ShowCoords renders coordinate debug overlays (development use).
	ShowCoords bool

	// Verbose enables debug logging.
	Verbose bool

	// --- Graph-specific ---

	// BoxBorderPadding is the padding between node text and its border.
	BoxBorderPadding int

	// PaddingBetweenX is the horizontal space between nodes.
	PaddingBetweenX int

	// PaddingBetweenY is the vertical space between nodes.
	PaddingBetweenY int

	// GraphDirection overrides layout direction ("LR" or "TD").
	GraphDirection string

	// StyleType selects the output format ("cli" plain text, "html" colored spans).
	StyleType string

	// --- Sequence diagram-specific ---

	// SequenceParticipantSpacing is the horizontal gap between participants.
	SequenceParticipantSpacing int

	// SequenceMessageSpacing is the vertical gap between messages.
	SequenceMessageSpacing int

	// SequenceSelfMessageWidth is the loop width for self-referencing messages.
	SequenceSelfMessageWidth int
}

// DefaultConfig returns a Config with sensible defaults suitable for CLI use.
func DefaultConfig() *Config {
	return &Config{
		UseAscii:                   false,
		ShowCoords:                 false,
		Verbose:                    false,
		BoxBorderPadding:           1,
		PaddingBetweenX:            5,
		PaddingBetweenY:            5,
		GraphDirection:             "LR",
		StyleType:                  "cli",
		SequenceParticipantSpacing: 5,
		SequenceMessageSpacing:     1,
		SequenceSelfMessageWidth:   4,
	}
}

// NewConfig creates and validates a Config for the given parameters.
func NewConfig(useAscii bool, graphDirection, styleType string) (*Config, error) {
	c := &Config{
		UseAscii:                   useAscii,
		BoxBorderPadding:           1,
		PaddingBetweenX:            5,
		PaddingBetweenY:            5,
		GraphDirection:             graphDirection,
		StyleType:                  styleType,
		SequenceParticipantSpacing: 5,
		SequenceMessageSpacing:     1,
		SequenceSelfMessageWidth:   4,
	}
	if err := c.Validate(); err != nil {
		return nil, err
	}
	return c, nil
}

// NewCLIConfig creates a CLI-targeted Config with all knobs exposed.
func NewCLIConfig(useAscii, showCoords, verbose bool, boxBorderPadding, paddingX, paddingY int, graphDirection string) (*Config, error) {
	d := DefaultConfig()
	c := &Config{
		UseAscii:                   useAscii,
		ShowCoords:                 showCoords,
		Verbose:                    verbose,
		BoxBorderPadding:           boxBorderPadding,
		PaddingBetweenX:            paddingX,
		PaddingBetweenY:            paddingY,
		GraphDirection:             graphDirection,
		StyleType:                  "cli",
		SequenceParticipantSpacing: d.SequenceParticipantSpacing,
		SequenceMessageSpacing:     d.SequenceMessageSpacing,
		SequenceSelfMessageWidth:   d.SequenceSelfMessageWidth,
	}
	if err := c.Validate(); err != nil {
		return nil, err
	}
	return c, nil
}

// Validate returns an error if any field has an invalid value.
func (c *Config) Validate() error {
	if c.BoxBorderPadding < 0 {
		return &ConfigError{"BoxBorderPadding", c.BoxBorderPadding, "must be non-negative"}
	}
	if c.PaddingBetweenX < 0 {
		return &ConfigError{"PaddingBetweenX", c.PaddingBetweenX, "must be non-negative"}
	}
	if c.PaddingBetweenY < 0 {
		return &ConfigError{"PaddingBetweenY", c.PaddingBetweenY, "must be non-negative"}
	}
	if c.GraphDirection != "LR" && c.GraphDirection != "TD" {
		return &ConfigError{"GraphDirection", c.GraphDirection, `must be "LR" or "TD"`}
	}
	if c.StyleType != "cli" && c.StyleType != "html" {
		return &ConfigError{"StyleType", c.StyleType, `must be "cli" or "html"`}
	}
	if c.SequenceParticipantSpacing < 0 {
		return &ConfigError{"SequenceParticipantSpacing", c.SequenceParticipantSpacing, "must be non-negative"}
	}
	if c.SequenceMessageSpacing < 0 {
		return &ConfigError{"SequenceMessageSpacing", c.SequenceMessageSpacing, "must be non-negative"}
	}
	if c.SequenceSelfMessageWidth < 2 {
		return &ConfigError{"SequenceSelfMessageWidth", c.SequenceSelfMessageWidth, "must be at least 2"}
	}
	return nil
}

// ConfigError describes a single invalid configuration value.
type ConfigError struct {
	Field   string
	Value   interface{}
	Message string
}

func (e *ConfigError) Error() string {
	return fmt.Sprintf("invalid config: %s = %v (%s)", e.Field, e.Value, e.Message)
}
