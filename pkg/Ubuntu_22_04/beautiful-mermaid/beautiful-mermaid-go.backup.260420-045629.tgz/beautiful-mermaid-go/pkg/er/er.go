// Package er implements parsing and ASCII rendering of Mermaid erDiagram.
package er

import (
	"fmt"
	"regexp"
	"strings"

	"github.com/beautiful-mermaid/go/pkg/diagram"
)

// ============================================================================
// Types
// ============================================================================

type AttrKey string

const (
	KeyPK AttrKey = "PK"
	KeyFK AttrKey = "FK"
	KeyUK AttrKey = "UK"
)

type Attribute struct {
	Type string
	Name string
	Key  AttrKey
}

type Entity struct {
	Name       string
	Attributes []Attribute
}

// Cardinality markers
type Cardinality struct {
	Left  string // ||, |o, }|, o{, }o ...
	Right string
	Dash  string // -- (solid) or .. (dashed)
}

type Relationship struct {
	From        string
	To          string
	Cardinality string // raw e.g. "||--o{"
	Label       string
	Identifying bool // solid line = identifying
}

type ERDiagram struct {
	Entities      []*Entity
	Relationships []Relationship
}

// ============================================================================
// Parser
// ============================================================================

var (
	entityHeaderRe = regexp.MustCompile(`^\s*([A-Z_][A-Z0-9_]*)\s*\{?\s*$`)
	attributeRe    = regexp.MustCompile(`^\s*(\w+)\s+(\w+)(?:\s+(PK|FK|UK))?\s*$`)
	relRe          = regexp.MustCompile(`^\s*([A-Z_]\w*)\s+(\|{1,2}o?|o?\|{1,2}|\}?\|+|o?\{|\}o?)\s*(-{2}|\.{2})\s*(\|{1,2}o?|o?\|{1,2}|\}?\|+|o?\{|\}o?)\s+([A-Z_]\w*)(?:\s*:\s*"?([^"]*)"?)?\s*$`)
	relSimpleRe    = regexp.MustCompile(`^\s*([A-Z_]\w*)\s+(\S+)\s+([A-Z_]\w*)(?:\s*:\s*"?([^"]*)"?)?\s*$`)
)

func IsERDiagram(input string) bool {
	for _, line := range strings.Split(input, "\n") {
		t := strings.TrimSpace(line)
		if t == "" || strings.HasPrefix(t, "%%") {
			continue
		}
		return strings.HasPrefix(t, "erDiagram")
	}
	return false
}

func Parse(input string) (*ERDiagram, error) {
	lines := strings.Split(strings.TrimSpace(input), "\n")
	erd := &ERDiagram{}
	entityMap := map[string]*Entity{}

	getOrCreate := func(name string) *Entity {
		if e, ok := entityMap[name]; ok {
			return e
		}
		e := &Entity{Name: name}
		erd.Entities = append(erd.Entities, e)
		entityMap[name] = e
		return e
	}

	var currentEntity *Entity
	inEntity := false

	for _, raw := range lines {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "%%") || line == "erDiagram" {
			continue
		}

		if line == "}" {
			inEntity = false
			currentEntity = nil
			continue
		}

		if inEntity && currentEntity != nil {
			if m := attributeRe.FindStringSubmatch(line); m != nil {
				attr := Attribute{Type: m[1], Name: m[2]}
				if len(m) > 3 {
					attr.Key = AttrKey(m[3])
				}
				currentEntity.Attributes = append(currentEntity.Attributes, attr)
			}
			continue
		}

		// Entity header with opening brace
		if strings.HasSuffix(line, "{") {
			name := strings.TrimSuffix(strings.TrimSpace(line), "{")
			name = strings.TrimSpace(name)
			if regexp.MustCompile(`^[A-Z_][A-Z0-9_]*$`).MatchString(name) {
				currentEntity = getOrCreate(name)
				inEntity = true
				continue
			}
		}

		// Try relationship patterns
		if m := relRe.FindStringSubmatch(line); m != nil {
			from, leftCard, dash, rightCard, to := m[1], m[2], m[3], m[4], m[5]
			label := ""
			if len(m) > 6 {
				label = strings.TrimSpace(m[6])
			}
			getOrCreate(from)
			getOrCreate(to)
			erd.Relationships = append(erd.Relationships, Relationship{
				From:        from,
				To:          to,
				Cardinality: leftCard + dash + rightCard,
				Label:       label,
				Identifying: dash == "--",
			})
			continue
		}

		// Simple relationship: ENTITY1 ||--o{ ENTITY2 : label
		if m := relSimpleRe.FindStringSubmatch(line); m != nil {
			from, card, to := m[1], m[2], m[3]
			label := ""
			if len(m) > 4 {
				label = strings.TrimSpace(m[4])
			}
			// Only if card looks like a cardinality marker
			if strings.ContainsAny(card, "|-o{.") {
				getOrCreate(from)
				getOrCreate(to)
				erd.Relationships = append(erd.Relationships, Relationship{
					From:        from,
					To:          to,
					Cardinality: card,
					Label:       label,
					Identifying: strings.Contains(card, "--"),
				})
			}
		}
	}
	return erd, nil
}

// ============================================================================
// Cardinality notation
// ============================================================================

// cardLabel converts a raw cardinality string to human-readable notation.
func cardLabel(card string) string {
	// Normalise common patterns
	r := strings.NewReplacer(
		"||--||", "1─1",
		"||--o{", "1─*",
		"||--|{", "1─+",
		"|o--|{", "?─+",
		"}|--o{", "+─*",
		"|o--o{", "?─*",
		"||..o{", "1┈*",
		"||..|{", "1┈+",
	)
	if s := r.Replace(card); s != card {
		return s
	}
	return card
}

// ============================================================================
// ASCII Renderer
// ============================================================================

func renderEntity(e *Entity, useAscii bool) []string {
	var hChar, vChar, tl, tr, bl, br, div, divR string
	if useAscii {
		hChar, vChar = "-", "|"
		tl, tr, bl, br = "+", "+", "+", "+"
		div, divR = "+", "+"
	} else {
		hChar, vChar = "─", "│"
		tl, tr, bl, br = "┌", "┐", "└", "┘"
		div, divR = "├", "┤"
	}

	// Compute column widths: type | name | key
	maxType, maxName, maxKey := len("Type"), len("Name"), 2
	for _, a := range e.Attributes {
		if len(a.Type) > maxType {
			maxType = len(a.Type)
		}
		if len(a.Name) > maxName {
			maxName = len(a.Name)
		}
		if len(string(a.Key)) > maxKey {
			maxKey = len(string(a.Key))
		}
	}

	// Header width = entity name or column total
	colTotal := maxType + maxName + maxKey + 4 // spaces
	headerW := len(e.Name)
	if colTotal > headerW {
		headerW = colTotal
	}
	innerW := headerW + 2
	border := strings.Repeat(hChar, innerW)

	var lines []string
	lines = append(lines, tl+border+tr)
	// Entity name row
	nameStr := e.Name
	pad := innerW - len(nameStr)
	lines = append(lines, vChar+" "+nameStr+strings.Repeat(" ", pad-1)+vChar)

	if len(e.Attributes) > 0 {
		lines = append(lines, div+border+divR)
		for _, a := range e.Attributes {
			keyStr := string(a.Key)
			row := fmt.Sprintf(" %-*s %-*s %*s ", maxType, a.Type, maxName, a.Name, maxKey, keyStr)
			// Pad to innerW
			if len(row) < innerW {
				row += strings.Repeat(" ", innerW-len(row))
			}
			lines = append(lines, vChar+row+vChar)
		}
	}
	lines = append(lines, bl+border+br)
	return lines
}

func Render(erd *ERDiagram, config *diagram.Config) (string, error) {
	if erd == nil || len(erd.Entities) == 0 {
		return "", fmt.Errorf("no entities")
	}
	useAscii := config != nil && config.UseAscii

	var sb strings.Builder

	for _, e := range erd.Entities {
		boxLines := renderEntity(e, useAscii)
		for _, l := range boxLines {
			sb.WriteString(l + "\n")
		}
		sb.WriteString("\n")
	}

	if len(erd.Relationships) > 0 {
		sb.WriteString("Relationships:\n")
		for _, r := range erd.Relationships {
			dash := "──"
			if !r.Identifying {
				dash = "╌╌"
			}
			if useAscii {
				if r.Identifying {
					dash = "--"
				} else {
					dash = ".."
				}
			}
			card := cardLabel(r.Cardinality)
			if r.Label != "" {
				sb.WriteString(fmt.Sprintf("  %s %s[%s]%s %s : %s\n", r.From, dash, card, dash, r.To, r.Label))
			} else {
				sb.WriteString(fmt.Sprintf("  %s %s[%s]%s %s\n", r.From, dash, card, dash, r.To))
			}
		}
	}

	return sb.String(), nil
}
