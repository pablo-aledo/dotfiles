// Package class implements parsing and ASCII rendering of Mermaid classDiagram.
package class

import (
	"fmt"
	"regexp"
	"strings"

	"github.com/beautiful-mermaid/go/pkg/diagram"
)

// ============================================================================
// Types
// ============================================================================

type Visibility string

const (
	VisPublic    Visibility = "+"
	VisPrivate   Visibility = "-"
	VisProtected Visibility = "#"
	VisPackage   Visibility = "~"
)

type Member struct {
	Visibility Visibility
	Type       string
	Name       string
	IsMethod   bool
}

type Annotation string // <<interface>>, <<abstract>>, <<enumeration>>

type Class struct {
	Name       string
	Annotation Annotation
	Members    []Member
}

type RelType string

const (
	RelInheritance RelType = "<|--"
	RelComposition RelType = "*--"
	RelAggregation RelType = "o--"
	RelAssociation RelType = "-->"
	RelDependency  RelType = "..>"
	RelRealization RelType = "..|>"
)

type Relationship struct {
	From  string
	To    string
	Rel   RelType
	Label string
}

type ClassDiagram struct {
	Classes       []*Class
	Relationships []Relationship
}

// ============================================================================
// Parser
// ============================================================================

var (
	classHeaderRe  = regexp.MustCompile(`^\s*class\s+(\w+)\s*(\{)?\s*$`)
	annotationRe   = regexp.MustCompile(`^\s*<<(\w+)>>\s*$`)
	memberRe       = regexp.MustCompile(`^\s*([+\-#~])\s*(.+)$`)
	relationshipRe = regexp.MustCompile(`^\s*(\w+)\s+(<\|--|<\|\.\.|\*--|o--|-->|\.\.|\.\.>|\.\.\|>|\.\.>\s*|<--|\|>)\s*(\w+)(?:\s*:\s*(.+))?\s*$`)
	relAltRe       = regexp.MustCompile(`^\s*(\w+)\s+([\*o<|.]+--[\*o>|.]*|[\*o<|.]*--[\*o>|.]+)\s*(\w+)(?:\s*:\s*(.+))?\s*$`)
)

// normaliseRel maps various arrow syntaxes to canonical RelType
func normaliseRel(arrow string) RelType {
	arrow = strings.TrimSpace(arrow)
	switch arrow {
	case "<|--", "<|..":
		return RelInheritance
	case "*--", "--*":
		return RelComposition
	case "o--", "--o":
		return RelAggregation
	case "-->", "<--":
		return RelAssociation
	case "..>", "<..":
		return RelDependency
	case "..|>":
		return RelRealization
	}
	// fallback
	if strings.Contains(arrow, "<|") || strings.Contains(arrow, "|>") {
		return RelInheritance
	}
	if strings.Contains(arrow, "*") {
		return RelComposition
	}
	if strings.Contains(arrow, "o") {
		return RelAggregation
	}
	if strings.Contains(arrow, "..") {
		return RelDependency
	}
	return RelAssociation
}

func parseMember(line string) (Member, bool) {
	m := memberRe.FindStringSubmatch(line)
	if m == nil {
		return Member{}, false
	}
	vis := Visibility(m[1])
	rest := strings.TrimSpace(m[2])
	isMethod := strings.Contains(rest, "(")

	// Split "Type name" or "name() ReturnType"
	parts := strings.Fields(rest)
	member := Member{Visibility: vis, IsMethod: isMethod}
	if len(parts) >= 2 {
		member.Type = parts[0]
		member.Name = strings.Join(parts[1:], " ")
	} else {
		member.Name = rest
	}
	return member, true
}

func IsClassDiagram(input string) bool {
	for _, line := range strings.Split(input, "\n") {
		t := strings.TrimSpace(line)
		if t == "" || strings.HasPrefix(t, "%%") {
			continue
		}
		return strings.HasPrefix(t, "classDiagram")
	}
	return false
}

func Parse(input string) (*ClassDiagram, error) {
	lines := strings.Split(strings.TrimSpace(input), "\n")
	cd := &ClassDiagram{}
	classMap := map[string]*Class{}

	getOrCreate := func(name string) *Class {
		if c, ok := classMap[name]; ok {
			return c
		}
		c := &Class{Name: name}
		cd.Classes = append(cd.Classes, c)
		classMap[name] = c
		return c
	}

	var currentClass *Class
	inClass := false

	for _, raw := range lines {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "%%") || line == "classDiagram" {
			continue
		}

		// End of class block
		if line == "}" {
			inClass = false
			currentClass = nil
			continue
		}

		// Inside a class block
		if inClass && currentClass != nil {
			// Annotation
			if m := annotationRe.FindStringSubmatch(line); m != nil {
				currentClass.Annotation = Annotation(m[1])
				continue
			}
			// Member
			if mem, ok := parseMember(line); ok {
				currentClass.Members = append(currentClass.Members, mem)
				continue
			}
			// Bare member without visibility
			if line != "" {
				currentClass.Members = append(currentClass.Members, Member{Name: line})
			}
			continue
		}

		// Class header: "class Foo {" or "class Foo"
		if m := classHeaderRe.FindStringSubmatch(line); m != nil {
			cls := getOrCreate(m[1])
			if m[2] == "{" {
				inClass = true
				currentClass = cls
			}
			continue
		}

		// Relationship line — try multiple patterns
		parsed := false
		for _, re := range []*regexp.Regexp{relationshipRe, relAltRe} {
			if m := re.FindStringSubmatch(line); m != nil {
				from, arrow, to := m[1], m[2], m[3]
				label := ""
				if len(m) > 4 {
					label = strings.TrimSpace(m[4])
				}
				// Ensure both classes exist
				getOrCreate(from)
				getOrCreate(to)
				cd.Relationships = append(cd.Relationships, Relationship{
					From:  from,
					To:    to,
					Rel:   normaliseRel(arrow),
					Label: label,
				})
				parsed = true
				break
			}
		}
		if !parsed {
			// Try "A <|-- B : label" free-form
			parts := strings.Fields(line)
			if len(parts) >= 3 {
				// find arrow token
				for i, p := range parts {
					if strings.ContainsAny(p, "<>|.*o") && strings.ContainsAny(p, "-") {
						if i > 0 && i < len(parts)-1 {
							from := strings.Join(parts[:i], " ")
							to := parts[i+1]
							label := ""
							if i+2 < len(parts) && parts[i+2] == ":" && i+3 < len(parts) {
								label = strings.Join(parts[i+3:], " ")
							}
							getOrCreate(from)
							getOrCreate(to)
							cd.Relationships = append(cd.Relationships, Relationship{
								From: from, To: to, Rel: normaliseRel(p), Label: label,
							})
							break
						}
					}
				}
			}
		}
	}
	return cd, nil
}

// ============================================================================
// ASCII Renderer
// ============================================================================

func relSymbol(r RelType, useAscii bool) string {
	if useAscii {
		switch r {
		case RelInheritance:
			return "<|--"
		case RelComposition:
			return "*--"
		case RelAggregation:
			return "o--"
		case RelAssociation:
			return "-->"
		case RelDependency:
			return "..>"
		case RelRealization:
			return "..|>"
		}
		return "--"
	}
	switch r {
	case RelInheritance:
		return "◁──"
	case RelComposition:
		return "◆──"
	case RelAggregation:
		return "◇──"
	case RelAssociation:
		return "───►"
	case RelDependency:
		return "···►"
	case RelRealization:
		return "···▷"
	}
	return "───"
}

func renderClass(c *Class, useAscii bool) []string {
	var lines []string
	var hChar, vChar, tl, tr, bl, br, div string
	if useAscii {
		hChar, vChar = "-", "|"
		tl, tr, bl, br = "+", "+", "+", "+"
		div = "+"
	} else {
		hChar, vChar = "─", "│"
		tl, tr, bl, br = "┌", "┐", "└", "┘"
		div = "├"
	}

	// Collect all text lines to compute width
	var sections [][]string
	// Section 0: annotation (if any) + name
	var headerSection []string
	if c.Annotation != "" {
		headerSection = append(headerSection, fmt.Sprintf("<<%s>>", string(c.Annotation)))
	}
	headerSection = append(headerSection, c.Name)
	sections = append(sections, headerSection)

	// Section 1: members
	var memberLines []string
	for _, m := range c.Members {
		line := string(m.Visibility) + m.Name
		if m.Type != "" && !m.IsMethod {
			line = string(m.Visibility) + m.Type + " " + m.Name
		}
		memberLines = append(memberLines, line)
	}
	if len(memberLines) > 0 {
		sections = append(sections, memberLines)
	}

	// Compute max width
	maxW := 0
	for _, sec := range sections {
		for _, l := range sec {
			if len(l) > maxW {
				maxW = len(l)
			}
		}
	}
	if maxW < 8 {
		maxW = 8
	}
	innerW := maxW + 2 // 1 padding each side
	fullW := innerW + 2 // borders

	border := strings.Repeat(hChar, innerW)

	lines = append(lines, tl+border+tr)
	for i, sec := range sections {
		if i > 0 {
			// Divider
			divLine := div + border
			if useAscii {
				divLine += div
			} else {
				divLine += "┤"
			}
			lines = append(lines, divLine)
		}
		for _, l := range sec {
			pad := innerW - len(l)
			lines = append(lines, vChar+" "+l+strings.Repeat(" ", pad-1)+vChar)
		}
	}
	lines = append(lines, bl+border+br)

	_ = fullW
	return lines
}

func Render(cd *ClassDiagram, config *diagram.Config) (string, error) {
	if cd == nil || len(cd.Classes) == 0 {
		return "", fmt.Errorf("no classes")
	}
	useAscii := config != nil && config.UseAscii

	var sb strings.Builder

	// Render each class box
	for _, cls := range cd.Classes {
		boxLines := renderClass(cls, useAscii)
		for _, l := range boxLines {
			sb.WriteString(l + "\n")
		}
		sb.WriteString("\n")
	}

	// Render relationships
	if len(cd.Relationships) > 0 {
		sb.WriteString("Relationships:\n")
		for _, r := range cd.Relationships {
			sym := relSymbol(r.Rel, useAscii)
			if r.Label != "" {
				sb.WriteString(fmt.Sprintf("  %s %s %s : %s\n", r.From, sym, r.To, r.Label))
			} else {
				sb.WriteString(fmt.Sprintf("  %s %s %s\n", r.From, sym, r.To))
			}
		}
	}

	return sb.String(), nil
}
