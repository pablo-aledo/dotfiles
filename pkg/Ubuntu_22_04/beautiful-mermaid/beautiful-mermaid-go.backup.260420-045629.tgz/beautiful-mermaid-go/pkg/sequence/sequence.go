// Package sequence implements parsing and ASCII rendering of Mermaid sequence diagrams.
// Ported directly from AlexanderGrooff/mermaid-ascii pkg/sequence.
package sequence

import (
	"fmt"
	"regexp"
	"strings"

	"github.com/beautiful-mermaid/go/pkg/diagram"
	"github.com/mattn/go-runewidth"
)

// ============================================================================
// Types
// ============================================================================

const (
	SequenceDiagramKeyword = "sequenceDiagram"
	SolidArrowSyntax       = "->>"
	DottedArrowSyntax      = "-->>"
)

type ArrowType int

const (
	SolidArrow  ArrowType = iota
	DottedArrow ArrowType = iota
)

type Participant struct {
	ID    string
	Label string
	Index int
}

type Message struct {
	From      *Participant
	To        *Participant
	Label     string
	ArrowType ArrowType
	Number    int
}

type SequenceDiagram struct {
	Participants []*Participant
	Messages     []*Message
	Autonumber   bool
}

// ============================================================================
// Box characters
// ============================================================================

type boxChars struct {
	TopLeft, TopRight, BottomLeft, BottomRight rune
	Horizontal, Vertical                       rune
	TeeDown, TeeRight, TeeLeft, Cross          rune
	ArrowRight, ArrowLeft                      rune
	SolidLine, DottedLine                      rune
	SelfTopRight, SelfBottom                   rune
}

var asciiChars = boxChars{
	TopLeft: '+', TopRight: '+', BottomLeft: '+', BottomRight: '+',
	Horizontal: '-', Vertical: '|',
	TeeDown: '+', TeeRight: '+', TeeLeft: '+', Cross: '+',
	ArrowRight: '>', ArrowLeft: '<',
	SolidLine: '-', DottedLine: '.',
	SelfTopRight: '+', SelfBottom: '+',
}

var unicodeChars = boxChars{
	TopLeft: '┌', TopRight: '┐', BottomLeft: '└', BottomRight: '┘',
	Horizontal: '─', Vertical: '│',
	TeeDown: '┬', TeeRight: '├', TeeLeft: '┤', Cross: '┼',
	ArrowRight: '►', ArrowLeft: '◄',
	SolidLine: '─', DottedLine: '┈',
	SelfTopRight: '┐', SelfBottom: '┘',
}

// ============================================================================
// Parser
// ============================================================================

var (
	participantRegex = regexp.MustCompile(`^\s*participant\s+(?:"([^"]+)"|(\S+))(?:\s+as\s+(.+))?$`)
	messageRegex     = regexp.MustCompile(`^\s*(?:"([^"]+)"|([^\s\->]+))\s*(-->>|->?>)\s*(?:"([^"]+)"|([^\s\->]+))\s*:\s*(.*)$`)
	autonumberRegex  = regexp.MustCompile(`^\s*autonumber\s*$`)
)

func IsSequenceDiagram(input string) bool {
	for _, line := range strings.Split(input, "\n") {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" || strings.HasPrefix(trimmed, "%%") {
			continue
		}
		return strings.HasPrefix(trimmed, SequenceDiagramKeyword)
	}
	return false
}

func removeComments(lines []string) []string {
	var out []string
	for _, line := range lines {
		if strings.HasPrefix(strings.TrimSpace(line), "%%") {
			continue
		}
		if idx := strings.Index(line, "%%"); idx != -1 {
			line = strings.TrimSpace(line[:idx])
		}
		if strings.TrimSpace(line) != "" {
			out = append(out, line)
		}
	}
	return out
}

func Parse(input string) (*SequenceDiagram, error) {
	input = strings.TrimSpace(input)
	if input == "" {
		return nil, fmt.Errorf("empty input")
	}
	rawLines := regexp.MustCompile(`\n|\\n`).Split(input, -1)
	lines := removeComments(rawLines)
	if len(lines) == 0 {
		return nil, fmt.Errorf("no content found")
	}
	if !strings.HasPrefix(strings.TrimSpace(lines[0]), SequenceDiagramKeyword) {
		return nil, fmt.Errorf("expected %q keyword", SequenceDiagramKeyword)
	}
	lines = lines[1:]

	sd := &SequenceDiagram{}
	participantMap := make(map[string]*Participant)

	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}
		if autonumberRegex.MatchString(trimmed) {
			sd.Autonumber = true
			continue
		}
		if matched, err := sd.parseParticipant(trimmed, participantMap); err != nil {
			return nil, fmt.Errorf("line %d: %w", i+2, err)
		} else if matched {
			continue
		}
		if matched, err := sd.parseMessage(trimmed, participantMap); err != nil {
			return nil, fmt.Errorf("line %d: %w", i+2, err)
		} else if matched {
			continue
		}
		return nil, fmt.Errorf("line %d: invalid syntax: %q", i+2, trimmed)
	}
	if len(sd.Participants) == 0 {
		return nil, fmt.Errorf("no participants found")
	}
	return sd, nil
}

func (sd *SequenceDiagram) parseParticipant(line string, pm map[string]*Participant) (bool, error) {
	m := participantRegex.FindStringSubmatch(line)
	if m == nil {
		return false, nil
	}
	id := m[2]
	if m[1] != "" {
		id = m[1]
	}
	label := m[3]
	if label == "" {
		label = id
	}
	label = strings.Trim(label, `"`)
	if _, exists := pm[id]; exists {
		return true, fmt.Errorf("duplicate participant %q", id)
	}
	p := &Participant{ID: id, Label: label, Index: len(sd.Participants)}
	sd.Participants = append(sd.Participants, p)
	pm[id] = p
	return true, nil
}

func (sd *SequenceDiagram) parseMessage(line string, pm map[string]*Participant) (bool, error) {
	m := messageRegex.FindStringSubmatch(line)
	if m == nil {
		return false, nil
	}
	fromID := m[2]
	if m[1] != "" {
		fromID = m[1]
	}
	arrow := m[3]
	toID := m[5]
	if m[4] != "" {
		toID = m[4]
	}
	label := strings.TrimSpace(m[6])
	from := sd.getParticipant(fromID, pm)
	to := sd.getParticipant(toID, pm)

	aType := DottedArrow
	if arrow == SolidArrowSyntax {
		aType = SolidArrow
	}
	msgNum := 0
	if sd.Autonumber {
		msgNum = len(sd.Messages) + 1
	}
	sd.Messages = append(sd.Messages, &Message{From: from, To: to, Label: label, ArrowType: aType, Number: msgNum})
	return true, nil
}

func (sd *SequenceDiagram) getParticipant(id string, pm map[string]*Participant) *Participant {
	if p, ok := pm[id]; ok {
		return p
	}
	p := &Participant{ID: id, Label: id, Index: len(sd.Participants)}
	sd.Participants = append(sd.Participants, p)
	pm[id] = p
	return p
}

// ============================================================================
// Renderer
// ============================================================================

const (
	boxPaddingLR    = 2
	minBoxWidth     = 3
	boxBorderWidth  = 2
	labelLeftMargin = 2
	labelBuffer     = 10
)

type diagramLayout struct {
	participantWidths  []int
	participantCenters []int
	totalWidth         int
	messageSpacing     int
	selfMessageWidth   int
}

func calculateLayout(sd *SequenceDiagram, config *diagram.Config) *diagramLayout {
	spacing := config.SequenceParticipantSpacing
	if spacing <= 0 {
		spacing = 5
	}
	widths := make([]int, len(sd.Participants))
	for i, p := range sd.Participants {
		w := runewidth.StringWidth(p.Label) + boxPaddingLR
		if w < minBoxWidth {
			w = minBoxWidth
		}
		widths[i] = w
	}
	centers := make([]int, len(sd.Participants))
	currentX := 0
	for i := range sd.Participants {
		bw := widths[i] + boxBorderWidth
		if i == 0 {
			centers[i] = bw / 2
			currentX = bw
		} else {
			currentX += spacing
			centers[i] = currentX + bw/2
			currentX += bw
		}
	}
	last := len(sd.Participants) - 1
	totalWidth := centers[last] + (widths[last]+boxBorderWidth)/2

	msgSpacing := config.SequenceMessageSpacing
	if msgSpacing <= 0 {
		msgSpacing = 1
	}
	selfWidth := config.SequenceSelfMessageWidth
	if selfWidth <= 0 {
		selfWidth = 4
	}
	return &diagramLayout{
		participantWidths:  widths,
		participantCenters: centers,
		totalWidth:         totalWidth,
		messageSpacing:     msgSpacing,
		selfMessageWidth:   selfWidth,
	}
}

// Render converts a parsed SequenceDiagram to an ASCII string.
func Render(sd *SequenceDiagram, config *diagram.Config) (string, error) {
	if sd == nil || len(sd.Participants) == 0 {
		return "", fmt.Errorf("no participants")
	}
	if config == nil {
		config = diagram.DefaultConfig()
	}
	chars := unicodeChars
	if config.UseAscii {
		chars = asciiChars
	}
	layout := calculateLayout(sd, config)
	var lines []string

	// Top border
	lines = append(lines, buildLine(sd.Participants, layout, func(i int) string {
		return string(chars.TopLeft) + strings.Repeat(string(chars.Horizontal), layout.participantWidths[i]) + string(chars.TopRight)
	}))
	// Label row
	lines = append(lines, buildLine(sd.Participants, layout, func(i int) string {
		w := layout.participantWidths[i]
		lw := runewidth.StringWidth(sd.Participants[i].Label)
		pad := (w - lw) / 2
		return string(chars.Vertical) + strings.Repeat(" ", pad) + sd.Participants[i].Label +
			strings.Repeat(" ", w-pad-lw) + string(chars.Vertical)
	}))
	// Bottom + lifeline connector
	lines = append(lines, buildLine(sd.Participants, layout, func(i int) string {
		w := layout.participantWidths[i]
		return string(chars.BottomLeft) + strings.Repeat(string(chars.Horizontal), w/2) +
			string(chars.TeeDown) + strings.Repeat(string(chars.Horizontal), w-w/2-1) + string(chars.BottomRight)
	}))

	for _, msg := range sd.Messages {
		for i := 0; i < layout.messageSpacing; i++ {
			lines = append(lines, buildLifeline(layout, chars))
		}
		if msg.From == msg.To {
			lines = append(lines, renderSelfMessage(msg, layout, chars)...)
		} else {
			lines = append(lines, renderMessage(msg, layout, chars)...)
		}
	}
	lines = append(lines, buildLifeline(layout, chars))
	return strings.Join(lines, "\n") + "\n", nil
}

func buildLine(participants []*Participant, layout *diagramLayout, draw func(int) string) string {
	var sb strings.Builder
	for i := range participants {
		bw := layout.participantWidths[i] + boxBorderWidth
		left := layout.participantCenters[i] - bw/2
		needed := left - len([]rune(sb.String()))
		if needed > 0 {
			sb.WriteString(strings.Repeat(" ", needed))
		}
		sb.WriteString(draw(i))
	}
	return sb.String()
}

func buildLifeline(layout *diagramLayout, chars boxChars) string {
	line := make([]rune, layout.totalWidth+1)
	for i := range line {
		line[i] = ' '
	}
	for _, c := range layout.participantCenters {
		if c < len(line) {
			line[c] = chars.Vertical
		}
	}
	return strings.TrimRight(string(line), " ")
}

func renderMessage(msg *Message, layout *diagramLayout, chars boxChars) []string {
	var lines []string
	from := layout.participantCenters[msg.From.Index]
	to := layout.participantCenters[msg.To.Index]

	label := msg.Label
	if msg.Number > 0 {
		label = fmt.Sprintf("%d. %s", msg.Number, msg.Label)
	}

	if label != "" {
		start := minInt(from, to) + labelLeftMargin
		lw := runewidth.StringWidth(label)
		w := maxInt(layout.totalWidth, start+lw) + labelBuffer
		line := []rune(buildLifeline(layout, chars))
		for len(line) < w {
			line = append(line, ' ')
		}
		col := start
		for _, r := range label {
			if col < len(line) {
				line[col] = r
				col++
			}
		}
		lines = append(lines, strings.TrimRight(string(line), " "))
	}

	line := []rune(buildLifeline(layout, chars))
	style := chars.SolidLine
	if msg.ArrowType == DottedArrow {
		style = chars.DottedLine
	}
	if from < to {
		line[from] = chars.TeeRight
		for i := from + 1; i < to; i++ {
			line[i] = style
		}
		line[to-1] = chars.ArrowRight
		line[to] = chars.Vertical
	} else {
		line[to] = chars.Vertical
		line[to+1] = chars.ArrowLeft
		for i := to + 2; i < from; i++ {
			line[i] = style
		}
		line[from] = chars.TeeLeft
	}
	return append(lines, strings.TrimRight(string(line), " "))
}

func renderSelfMessage(msg *Message, layout *diagramLayout, chars boxChars) []string {
	var lines []string
	center := layout.participantCenters[msg.From.Index]
	width := layout.selfMessageWidth

	ensure := func(s string) []rune {
		target := layout.totalWidth + width + 1
		r := []rune(s)
		for len(r) < target {
			r = append(r, ' ')
		}
		return r
	}

	label := msg.Label
	if msg.Number > 0 {
		label = fmt.Sprintf("%d. %s", msg.Number, msg.Label)
	}

	if label != "" {
		line := ensure(buildLifeline(layout, chars))
		start := center + labelLeftMargin
		lw := runewidth.StringWidth(label)
		needed := start + lw + labelBuffer
		for len(line) < needed {
			line = append(line, ' ')
		}
		col := start
		for _, c := range label {
			if col < len(line) {
				line[col] = c
				col++
			}
		}
		lines = append(lines, strings.TrimRight(string(line), " "))
	}

	l1 := ensure(buildLifeline(layout, chars))
	l1[center] = chars.TeeRight
	for i := 1; i < width; i++ {
		l1[center+i] = chars.Horizontal
	}
	l1[center+width-1] = chars.SelfTopRight
	lines = append(lines, strings.TrimRight(string(l1), " "))

	l2 := ensure(buildLifeline(layout, chars))
	l2[center+width-1] = chars.Vertical
	lines = append(lines, strings.TrimRight(string(l2), " "))

	l3 := ensure(buildLifeline(layout, chars))
	l3[center] = chars.Vertical
	l3[center+1] = chars.ArrowLeft
	for i := 2; i < width-1; i++ {
		l3[center+i] = chars.Horizontal
	}
	l3[center+width-1] = chars.SelfBottom
	return append(lines, strings.TrimRight(string(l3), " "))
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
