# beautiful-mermaid-go

Renderiza diagramas Mermaid como arte ASCII/Unicode en Go puro.

Port de [AlexanderGrooff/mermaid-ascii](https://github.com/AlexanderGrooff/mermaid-ascii) extendido con el parser mejorado de [lukilabs/beautiful-mermaid](https://github.com/lukilabs/beautiful-mermaid).

---

## Instalación

```bash
git clone https://github.com/tu-usuario/beautiful-mermaid-go
cd beautiful-mermaid-go
go mod tidy
go build -o beautiful-mermaid .
```

---

## Uso

```bash
# Desde stdin
echo "graph LR; A --> B --> C" | ./beautiful-mermaid

# Desde archivo
./beautiful-mermaid -f diagrama.mmd

# ASCII puro (sin Unicode)
./beautiful-mermaid -a -f diagrama.mmd

# Más espacio entre nodos
./beautiful-mermaid -x 8 -y 8 -f diagrama.mmd
```

### Flags

| Flag | Corto | Default | Descripción |
|------|-------|---------|-------------|
| `--file` | `-f` | stdin | Archivo `.mmd` a renderizar |
| `--ascii` | `-a` | false | Usar `+-\|` en vez de `┌─│` |
| `--verbose` | `-v` | false | Logging de debug |
| `--coords` | `-c` | false | Mostrar coordenadas de debug |
| `--paddingX` | `-x` | 5 | Espacio horizontal entre nodos |
| `--paddingY` | `-y` | 5 | Espacio vertical entre nodos |
| `--borderPadding` | `-p` | 1 | Padding interior de cajas |

### Como librería

```go
import (
    "github.com/beautiful-mermaid/go/cmd"
    "github.com/beautiful-mermaid/go/pkg/diagram"
    "github.com/beautiful-mermaid/go/pkg/class"
    "github.com/beautiful-mermaid/go/pkg/er"
    "github.com/beautiful-mermaid/go/pkg/xychart"
    "github.com/beautiful-mermaid/go/pkg/sequence"
    "github.com/beautiful-mermaid/go/pkg/ascii"
)

config := diagram.DefaultConfig()

// Auto-detect (cualquier tipo soportado)
out, err := cmd.RenderDiagram(input, config)

// O por tipo específico:
ascii.RenderFlowchart(input, config)
sd, _ := sequence.Parse(input); sequence.Render(sd, config)
cd, _ := class.Parse(input);    class.Render(cd, config)
erd, _ := er.Parse(input);      er.Render(erd, config)
chart, _ := xychart.Parse(input); xychart.Render(chart, config)
```

---

## Diagramas soportados

### 1. Flowchart

Soporta `graph TD`, `graph LR`, `flowchart TD`, `flowchart LR` y variantes (`TB`, `BT`, `RL`).

```
graph TD
  A[Start] --> B{Decision}
  B -->|Yes| C[Action]
  B -->|No| D[End]
```

```
          ┌───────┐
          │ Start │
          └───┬───┘
              │
          ┌───▼───┐
          │  ◇    │
          │Decision│
          └───┬───┘
       Yes /     \ No
          /         \
    ┌────▼───┐   ┌───▼──┐
    │ Action │   │ End  │
    └────────┘   └──────┘
```

**Formas de nodo:**

| Sintaxis | Forma | Esquinas |
|----------|-------|---------|
| `A[texto]` | Rectángulo | `┌┐└┘` |
| `A(texto)` | Redondeado | `╭╮╰╯` |
| `A{texto}` | Diamante | `◇◇◇◇` |
| `A((texto))` | Círculo | `○○○○` |
| `A([texto])` | Estadio | `()()` |
| `A[[texto]]` | Subrutina | `╔╗╚╝` |
| `A(((texto)))` | Doble círculo | `◎` |
| `A{{texto}}` | Hexágono | `⬡` |
| `A[(texto)]` | Cilindro | |
| `A>texto]` | Asimétrico | |
| `A[/texto\]` | Trapecio | |
| `A[\texto/]` | Trapecio inverso | |

**Estilos de arista:** `-->` sólida, `-.->` punteada, `==>` gruesa

**Subgrafos anidados:**

```
graph LR
  subgraph Backend
    API --> DB
  end
  Cliente --> API
```

---

### 2. State Diagram

```
stateDiagram-v2
  [*] --> Idle
  Idle --> Active : start
  Active --> Idle : cancel
  Active --> Done : complete
  Done --> [*]
```

```
    ●
    │
    ▼
┌──────┐  start   ┌────────┐  complete  ┌──────┐
│ Idle │─────────►│ Active │───────────►│ Done │──► ◎
└──────┘          └────────┘            └──────┘
    ▲                 │ cancel
    └─────────────────┘
```

Soporta estados compuestos (`state X { ... }`), pseudoestados `[*]` de inicio y fin, y transiciones con etiqueta.

---

### 3. Sequence Diagram

```
sequenceDiagram
  participant A as Alice
  participant B as Bob
  participant C as Charlie
  A->>B: Hello
  B->>C: Forward
  C-->>A: Reply
```

```
┌───────┐       ┌─────┐       ┌─────────┐
│ Alice │       │ Bob │       │ Charlie │
└───┬───┘       └──┬──┘       └────┬────┘
    │               │               │
    │  Hello        │               │
    ├──────────────►│               │
    │               │  Forward      │
    │               ├──────────────►│
    │  Reply        │               │
    │◄┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┤
    │               │               │
```

Soporta `participant`, `actor`, alias con `as`, flechas sólidas (`->>`), punteadas (`-->>`), y `autonumber`.

---

### 4. Class Diagram

```
classDiagram
  class Animal {
    <<abstract>>
    +String name
    +eat() void
  }
  class Dog {
    +String breed
    +bark() void
  }
  Animal <|-- Dog : extends
```

```
┌────────────────┐
│ <<abstract>>   │
│ Animal         │
├────────────────┤
│ +String name   │
│ +eat() void    │
└────────────────┘

┌────────────────┐
│ Dog            │
├────────────────┤
│ +String breed  │
│ +bark() void   │
└────────────────┘

Relationships:
  Animal ◁── Dog : extends
```

**Visibilidad:** `+` público · `-` privado · `#` protegido · `~` paquete

**Anotaciones:** `<<interface>>` · `<<abstract>>` · `<<enumeration>>`

**Tipos de relación:**

| Sintaxis | Tipo | Símbolo |
|----------|------|---------|
| `A <\|-- B` | Herencia | `◁──` |
| `A *-- B` | Composición | `◆──` |
| `A o-- B` | Agregación | `◇──` |
| `A --> B` | Asociación | `───►` |
| `A ..> B` | Dependencia | `···►` |
| `A ..\|> B` | Realización | `···▷` |

---

### 5. ER Diagram

```
erDiagram
  CUSTOMER {
    int id PK
    string name
    string email UK
  }
  ORDER {
    int id PK
    int customer_id FK
    date created
  }
  CUSTOMER ||--o{ ORDER : places
```

```
┌─────────────────────────┐
│ CUSTOMER                │
├─────────────────────────┤
│  int    id         PK   │
│  string name            │
│  string email      UK   │
└─────────────────────────┘

┌──────────────────────────────┐
│ ORDER                        │
├──────────────────────────────┤
│  int    id            PK     │
│  int    customer_id   FK     │
│  date   created              │
└──────────────────────────────┘

Relationships:
  CUSTOMER ──[1─*]── ORDER : places
```

**Cardinalidades:**

| Sintaxis | Significado |
|----------|-------------|
| `\|\|--\|\|` | Exactamente uno a exactamente uno |
| `\|\|--o{` | Uno a cero-o-muchos |
| `\|\|--\|{` | Uno a uno-o-muchos |
| `\|o--\|{` | Cero-o-uno a uno-o-muchos |
| `}\|--o{` | Uno-o-más a cero-o-muchos |

**Claves:** `PK` · `FK` · `UK`  
**Relaciones:** sólidas (identifying `--`) y punteadas (non-identifying `..`)

---

### 6. XY Chart

```
xychart-beta
  title "Ventas 2024"
  x-axis [Q1, Q2, Q3, Q4]
  y-axis "Revenue" 0 --> 400
  bar [200, 280, 320, 350]
  line [200, 280, 320, 350]
```

```
  Ventas 2024
  ──────────────────────────────────────
400 │                               ●●●●
    │                         ●●●●██████
    │                   ●●●●████████████
200 │██████████████████████████████████
  0 │
    └──────────────────────────────────
      Q1          Q2         Q3      Q4

  █ bar
  ● line
```

**Variantes:**

```
xychart-beta horizontal   # barras horizontales
xychart-beta              # barras verticales (default)

bar [...]                 # serie de barras
line [...]                # serie de línea

x-axis 0 --> 100          # rango numérico en X
y-axis "Label" 0 --> 1000 # rango personalizado en Y
x-axis "Mes" [Ene, Feb]   # etiqueta + labels categóricos
```

Soporta múltiples series `bar` y `line` en el mismo gráfico.

---

## Arquitectura

```
beautiful-mermaid-go/
├── main.go
├── cmd/
│   ├── root.go          — CLI (cobra): flags, stdin/file
│   └── render.go        — RenderDiagram(): detección automática de tipo
├── pkg/
│   ├── diagram/
│   │   ├── config.go    — Config, DefaultConfig, Validate
│   │   └── interface.go — interfaz Diagram
│   ├── ascii/           — flowchart + state diagram
│   │   ├── parser.go    — MermaidFileToMap, BuildGraph
│   │   ├── grid.go      — CreateMapping, layout con A*
│   │   ├── draw.go      — DrawBox, DrawArrow, DrawGraph
│   │   ├── pathfinder.go — A* getPath + mergePath
│   │   ├── edgerouting.go — direction logic, DeterminePath
│   │   ├── canvas.go    — MkCanvas, MergeCanvases, CanvasToString
│   │   ├── shapes.go    — esquinas por NodeShape
│   │   └── types.go     — GridCoord, Node, Edge, Graph, Canvas…
│   ├── sequence/
│   │   └── sequence.go  — Parse + Render para sequenceDiagram
│   ├── class/
│   │   └── class.go     — Parse + Render para classDiagram
│   ├── er/
│   │   └── er.go        — Parse + Render para erDiagram
│   └── xychart/
│       └── xychart.go   — Parse + Render para xychart-beta
└── go.mod
```

---

## Comparativa con el original

| Característica | mermaid-ascii (Go) | beautiful-mermaid-go |
|---|---|---|
| Flowchart TD/LR | ✅ | ✅ |
| State diagram | ❌ | ✅ |
| Sequence diagram | ✅ | ✅ |
| Class diagram | ❌ | ✅ |
| ER diagram | ❌ | ✅ |
| XY Chart | ❌ | ✅ |
| Formas de nodo | 4 básicas | 12 formas |
| Edge labels | ✅ | ✅ mejorado |
| Subgrafos anidados | ✅ | ✅ + direction override |
| Esquinas Unicode | `+` | `┌┐└┘` con merge de junctions |
| Routing de aristas | A* básico | A* con penalización de esquinas |
