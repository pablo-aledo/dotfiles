#include <time.h>

int main(int argc, char *argv[]) {
  clock_settime(-1, 0);
}
