// checks for sched.h header
#include <sched.h>

int main(int argc, char *argv[]) {
  return 0;
}
