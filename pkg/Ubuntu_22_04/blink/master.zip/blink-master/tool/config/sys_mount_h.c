#include <sys/types.h>
// ordering matters on openbsd
// checks for sys/mount.h header
#include <sys/mount.h>

int main(int argc, char *argv[]) {
  return 0;
}
