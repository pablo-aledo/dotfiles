#ifndef BLINK_DEVFS_H_
#define BLINK_DEVFS_H_

#include "blink/vfs.h"

extern struct VfsSystem g_devfs;

#endif  // BLINK_DEVFS_H_
