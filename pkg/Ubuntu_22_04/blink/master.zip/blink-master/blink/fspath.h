#ifndef BLINK_FSPATH_H_
#define BLINK_FSPATH_H_

char *JoinPath(const char *, const char *);
char *ExpandUser(const char *);

#endif /* BLINK_FSPATH_H_ */
