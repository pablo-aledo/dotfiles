#ifndef BLINK_TIME_H_
#define BLINK_TIME_H_
#include "blink/machine.h"

void OpPause(P);
void OpRdtsc(P);
void OpRdtscp(P);
void OpRdpid(P);

#endif /* BLINK_TIME_H_ */
