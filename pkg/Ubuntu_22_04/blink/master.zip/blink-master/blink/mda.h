#ifndef BLINK_MDA_H_
#define BLINK_MDA_H_
#include "blink/panel.h"
#include "blink/types.h"

void DrawMda(struct Panel *, u8[25][80][2], int, int);

#endif /* BLINK_MDA_H_ */
