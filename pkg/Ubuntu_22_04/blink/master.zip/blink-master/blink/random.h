#ifndef BLINK_RANDOM_H_
#define BLINK_RANDOM_H_
#include <sys/types.h>

ssize_t GetRandom(void *, size_t, int);

#endif /* BLINK_RANDOM_H_ */
