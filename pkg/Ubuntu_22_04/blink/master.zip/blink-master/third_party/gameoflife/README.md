# Game Of Life

This is an implementation of Conway's game of life that runs in x86_64
bare metal freestanding environment.

### Origin

<https://github.com/glitzflitz/gameoflife/blob/ac17b5987f845f242bc7c9f8f4aea38e8a98f92f/gameoflife.bin>

### Author

[Amey Narkhede](https://github.com/glitzflitz)

### License

GPL v2.0
