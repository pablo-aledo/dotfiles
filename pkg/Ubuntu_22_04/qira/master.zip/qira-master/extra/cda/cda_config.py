#ci.Config.set_library_file(basedir+"/clang/build/Release+Asserts/lib/libclang.so")
#ci.Config.set_library_file(basedir+"/libclang.so")
LIBCLANG_PATH = '/usr/lib/x86_64-linux-gnu/libclang.so.1'
#args.append(basedir+"/clang-latest/build/Release+Asserts/lib/clang/3.4.2/include")
#args.append(basedir+"/include")
CLANG_INCLUDES = '/usr/lib/llvm-3.4/lib/clang/3.4/include'

