#!/bin/bash
docker build -t qira -f Dockerfile ../
