#include <stdio.h>
#include <math.h>

int main(int argc) {
  printf("hello: %f\n", sin(argc));
}


