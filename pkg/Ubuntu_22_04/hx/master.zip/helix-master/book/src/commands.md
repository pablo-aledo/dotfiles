# Commands

Command mode can be activated by pressing `:`. The built-in commands are:

{{#include ./generated/typable-cmd.md}}
