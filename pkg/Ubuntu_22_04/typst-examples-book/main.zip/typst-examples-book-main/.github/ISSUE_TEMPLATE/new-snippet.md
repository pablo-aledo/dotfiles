---
name: New snippet
about: Add new snippet to the book
title: "[Snippet(s) name here]"
labels: new snippet
assignees: sitandr

---

**Location**: [where in the book should be snippet located]

**Importance**: [why should it be in the book]

**Snippet**:
```typ
[The code there]
```

<!-- If possible, attach rendered image from snippet, plese. -->
