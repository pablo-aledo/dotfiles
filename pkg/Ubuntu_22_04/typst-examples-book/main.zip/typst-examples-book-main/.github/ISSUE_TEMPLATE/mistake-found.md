---
name: Mistake found
about: Point a problem in example, language, rendering or anything else
title: "[What mistake you've found?]"
labels: mistake
assignees: sitandr

---

**Issue**: [what problem have you found]

**Location**: [where in the book the mistake is located, attach the url and specify the example if possible]
