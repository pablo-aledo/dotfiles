# Typstonomicon, or The Code You Should Not Write
Totally cursed examples with lots of quires, measure and other things to hack around current Typst limitations.
Generally you should use this code only if you really need it.

<div class="warning">
    Code in this chapter may break in lots of circumstances and debugging it will be very painful. You are warned.
</div>

I think that this chapter will slowly die as Typst matures.
