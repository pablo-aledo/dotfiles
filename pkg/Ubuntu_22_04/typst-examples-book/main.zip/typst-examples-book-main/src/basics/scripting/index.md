# Scripting
**Typst** has a complete interpreted language inside. One of key aspects of working with your document in a nicer way
