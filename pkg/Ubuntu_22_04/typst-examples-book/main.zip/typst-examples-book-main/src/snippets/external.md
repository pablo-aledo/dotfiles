# Use with external tools
Currently the best ways to communicate is using

1. Preprocessing. The tool should generate Typst file
2. Typst Query (CLI). See the docs [there](https://typst.app/docs/reference/meta/query#command-line-queries).
3. WebAssembly plugins. See the docs [there](https://typst.app/docs/reference/foundations/plugin/).

In some time there will be examples of successful usage of first two methods. For the third one, see [packages](../packages/index.md).
