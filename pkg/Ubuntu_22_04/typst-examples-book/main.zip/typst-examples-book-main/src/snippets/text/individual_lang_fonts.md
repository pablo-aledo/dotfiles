# Individual language fonts

```typ
A cat แปลว่า แมว

#show regex("\p{Thai}+"): text.with(font: "Noto Serif Thai")

A cat แปลว่า แมว
```
