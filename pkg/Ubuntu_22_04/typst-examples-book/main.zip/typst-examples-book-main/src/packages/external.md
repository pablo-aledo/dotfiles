# External
These are not official packages. Maybe once they will become one.

However, they may be very useful.

## Treemap display
[Code Link](https://gist.github.com/taylorh140/9e353fdf737f1ef51aacb332efdd9516)

![Treemap diagram](img/treemap.png)
