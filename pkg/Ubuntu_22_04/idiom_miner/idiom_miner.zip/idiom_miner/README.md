# idiom_miner — minero de idioms de codigo -> snippets

Prototipo agnostico de lenguaje y de proyecto. Analiza una base de codigo,
encuentra fragmentos estructuralmente repetidos (funciones, if/for/try/match...)
y genera automaticamente un fichero de snippets en formato snipMate con las
partes que varian convertidas en placeholders (${1:...}, ${2:...}).

Lenguajes soportados: Rust, Python, C, C++, Go, JavaScript, Scala, Bash.

## Instalacion

    pip install "tree_sitter==0.21.3" tree_sitter_languages --break-system-packages

(la version de tree_sitter esta fijada porque tree_sitter_languages 1.10.x
todavia usa la API antigua `Language(path, name)`, incompatible con
tree_sitter >= 0.22)

## Uso

Minar un directorio:

    python cli.py mine --path /ruta/a/tu/repo \
        --langs rust,python \
        --min-support 3 \
        --min-tokens 6 --max-tokens 150 \
        --top 100 \
        --output mined.snippets

    --langs vacio (por defecto) = analiza todos los lenguajes soportados
    --min-support = cuantas veces tiene que repetirse un patron como minimo
    --min-tokens / --max-tokens = filtro de tamano (evita trivialidades y
        clusters gigantes de codigo casi-unico)
    --top = cuantos clusters (ordenados por frecuencia) volcar al fichero

Calibrar los tipos de nodo para un lenguaje (si un patron esperado no
aparece, o aparecen demasiados):

    python cli.py inspect --file ejemplo.rs --lang rust

Esto vuelca todos los tipos de nodo tree-sitter encontrados en el fichero,
marcando cuales estan ahora mismo configurados como [MINEABLE], [ID] o [LIT]
en lang_config.py, para poder ajustar los sets a mano.

## Como funciona (resumen)

1. `core/extract.py` recorre el AST (tree-sitter) y saca todos los subarboles
   cuyo tipo de nodo esta en `mineable_types` (por lenguaje, en lang_config.py).
2. `core/shape.py` normaliza cada subarbol a una "forma": la secuencia de
   tipos de sus hojas, sustituyendo identificadores por ID y literales por
   LIT. Dos fragmentos con la misma forma son el mismo idiom aunque los
   nombres de variables sean distintos. Se hashea esa forma.
3. `core/cluster.py` agrupa por (lenguaje, tipo de nodo, hash de forma) y
   filtra por soporte minimo.
4. `core/template.py` alinea todas las instancias de un cluster hoja a hoja;
   donde el texto coincide en todas las instancias lo deja fijo, donde varia
   lo convierte en un placeholder numerado (reutilizando el numero si el
   mismo texto aparece en varias posiciones dentro de la misma instancia).
5. `core/report.py` vuelca todo en formato snipMate.

## Extension a otros lenguajes

Anadir un lenguaje nuevo es solo una entrada en `lang_config.py` (nombre de
gramatica tree-sitter, extensiones de fichero, y los tres sets de tipos de
nodo). El resto del pipeline (core/) no necesita tocarse.

## Limitaciones conocidas del prototipo

- Al extraer un nodo anidado (p.ej. un `try` dentro de una funcion), el
  snippet resultante conserva la indentacion original relativa al fichero,
  no la reindenta a nivel 0.
- Clusters a distinta granularidad que se solapan (una funcion completa Y
  su bucle interior, como dos clusters separados) no se colapsan todavia;
  el hook `core/cluster.dedupe_nested` esta preparado pero sin implementar.
- La reutilizacion de numero de placeholder es por texto identico exacto
  dentro del cluster; no detecta alias (dos nombres distintos jugando el
  mismo "rol" semantico).
- No hay deduplicacion de comentarios: si el texto de un comentario varia
  entre instancias, hoy se queda fijo con el texto de la primera instancia
  (silenciosamente incorrecto en ese caso concreto).
