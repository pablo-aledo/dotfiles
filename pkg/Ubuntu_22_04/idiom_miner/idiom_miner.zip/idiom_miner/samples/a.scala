def buscarUsuario(id: Int): Option[Usuario] = {
  repositorio.find(id) match {
    case Some(valor) => Some(valor)
    case None =>
      logger.warn(s"no encontrado: $id")
      None
  }
}

def buscarProducto(codigo: Int): Option[Producto] = {
  catalogo.find(codigo) match {
    case Some(valor) => Some(valor)
    case None =>
      logger.warn(s"no encontrado: $codigo")
      None
  }
}
