def leer_config(ruta):
    try:
        with open(ruta) as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error("no existe el fichero: %s", ruta)
        return {}

def leer_cache(ruta):
    try:
        with open(ruta) as fh:
            return json.load(fh)
    except FileNotFoundError:
        logging.error("no existe el fichero: %s", ruta)
        return {}

def leer_metadatos(archivo):
    try:
        with open(archivo) as g:
            return json.load(g)
    except FileNotFoundError:
        logging.error("no existe el fichero: %s", archivo)
        return {}
