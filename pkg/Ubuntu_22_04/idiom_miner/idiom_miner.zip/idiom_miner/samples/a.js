async function obtenerUsuario(id) {
    try {
        const respuesta = await fetch(`/api/usuarios/${id}`);
        return await respuesta.json();
    } catch (error) {
        console.error("fallo la peticion", error);
        return null;
    }
}

async function obtenerProducto(id) {
    try {
        const respuesta = await fetch(`/api/productos/${id}`);
        return await respuesta.json();
    } catch (error) {
        console.error("fallo la peticion", error);
        return null;
    }
}

async function obtenerPedido(id) {
    try {
        const respuesta = await fetch(`/api/pedidos/${id}`);
        return await respuesta.json();
    } catch (error) {
        console.error("fallo la peticion", error);
        return null;
    }
}
