fn total_ventas(items: &Vec<Venta>) -> f64 {
    let mut suma = 0.0;
    for item in items.iter() {
        suma += item.monto;
    }
    suma
}

fn total_gastos(lineas: &Vec<Gasto>) -> f64 {
    let mut acumulado = 0.0;
    for linea in lineas.iter() {
        acumulado += linea.monto;
    }
    acumulado
}
