func obtenerUsuario(id int) (*Usuario, error) {
    fila := db.QueryRow("SELECT * FROM usuarios WHERE id = ?", id)
    var u Usuario
    if err := fila.Scan(&u); err != nil {
        log.Printf("error consultando usuario: %v", err)
        return nil, err
    }
    return &u, nil
}

func obtenerProducto(id int) (*Producto, error) {
    fila := db.QueryRow("SELECT * FROM productos WHERE id = ?", id)
    var p Producto
    if err := fila.Scan(&p); err != nil {
        log.Printf("error consultando producto: %v", err)
        return nil, err
    }
    return &p, nil
}

func obtenerPedido(id int) (*Pedido, error) {
    fila := db.QueryRow("SELECT * FROM pedidos WHERE id = ?", id)
    var ped Pedido
    if err := fila.Scan(&ped); err != nil {
        log.Printf("error consultando pedido: %v", err)
        return nil, err
    }
    return &ped, nil
}
