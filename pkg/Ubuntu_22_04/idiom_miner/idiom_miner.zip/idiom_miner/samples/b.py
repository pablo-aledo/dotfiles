def reintentar_conexion(cliente, intentos=3):
    for intento in range(intentos):
        try:
            return cliente.conectar()
        except ConnectionError:
            time.sleep(1)
    raise RuntimeError("no se pudo conectar")

def reintentar_descarga(descargador, intentos=3):
    for intento in range(intentos):
        try:
            return descargador.descargar()
        except ConnectionError:
            time.sleep(1)
    raise RuntimeError("no se pudo conectar")

def reintentar_envio(emisor, intentos=3):
    for intento in range(intentos):
        try:
            return emisor.enviar()
        except ConnectionError:
            time.sleep(1)
    raise RuntimeError("no se pudo conectar")
