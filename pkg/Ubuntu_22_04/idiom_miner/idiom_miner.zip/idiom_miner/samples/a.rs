fn cargar_usuario(id: u32) -> Result<Usuario, Error> {
    match repositorio.obtener(id) {
        Ok(valor) => Ok(valor),
        Err(e) => {
            eprintln!("fallo: {}", e);
            Err(e)
        }
    }
}

fn cargar_producto(codigo: u32) -> Result<Producto, Error> {
    match catalogo.obtener(codigo) {
        Ok(valor) => Ok(valor),
        Err(e) => {
            eprintln!("fallo: {}", e);
            Err(e)
        }
    }
}

fn cargar_pedido(numero: u32) -> Result<Pedido, Error> {
    match pedidos.obtener(numero) {
        Ok(valor) => Ok(valor),
        Err(e) => {
            eprintln!("fallo: {}", e);
            Err(e)
        }
    }
}
