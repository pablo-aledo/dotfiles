double promedio(const std::vector<double>& datos) {
    double suma = 0.0;
    for (const auto& x : datos) {
        suma += x;
    }
    return suma / datos.size();
}

double maximo_acumulado(const std::vector<double>& valores) {
    double suma = 0.0;
    for (const auto& v : valores) {
        suma += v;
    }
    return suma / valores.size();
}
