int suma_array(int *datos, int n) {
    int total = 0;
    for (int i = 0; i < n; i++) {
        total += datos[i];
    }
    return total;
}

int producto_array(int *valores, int m) {
    int total = 0;
    for (int j = 0; j < m; j++) {
        total += valores[j];
    }
    return total;
}
