comprobar_docker() {
    if ! command -v docker &> /dev/null; then
        echo "error: docker no esta instalado" >&2
        exit 1
    fi
}

comprobar_git() {
    if ! command -v git &> /dev/null; then
        echo "error: git no esta instalado" >&2
        exit 1
    fi
}

comprobar_python() {
    if ! command -v python3 &> /dev/null; then
        echo "error: python3 no esta instalado" >&2
        exit 1
    fi
}
