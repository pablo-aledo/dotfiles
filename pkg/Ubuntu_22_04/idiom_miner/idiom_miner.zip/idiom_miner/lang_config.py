"""
Configuracion por lenguaje para el minero de idioms.

Cada entrada es deliberadamente delgada: nombre de gramatica tree-sitter,
extensiones de fichero, y tres conjuntos de tipos de nodo:

- mineable_types: tipos de nodo que consideramos "unidad" candidata a snippet
  (funciones, bloques de control, etc.)
- identifier_types: tipos de nodo que son NOMBRES (variables, funciones,
  campos...) y por tanto se sustituyen por un placeholder al generalizar.
- literal_types: tipos de nodo que son LITERALES (numeros, strings, booleanos)
  y tambien se sustituyen por un placeholder.

Los nombres exactos de tipo de nodo dependen de la gramatica tree-sitter
concreta. Si un patron no aparece donde lo esperas, corre:

    python cli.py inspect --file tu_fichero --lang tu_lenguaje

para volcar los tipos de nodo reales y ajustar los sets de abajo.
"""

LANGUAGES = {
    "rust": {
        "ts_name": "rust",
        "extensions": [".rs"],
        "mineable_types": {
            "function_item", "closure_expression", "if_expression",
            "match_expression", "for_expression", "while_expression",
            "loop_expression", "let_declaration",
        },
        "identifier_types": {"identifier", "field_identifier", "type_identifier", "shorthand_field_identifier"},
        "literal_types": {"integer_literal", "float_literal", "string_literal", "char_literal", "boolean_literal"},
        "labels": {
            "function_item": "funcion",
            "closure_expression": "closure",
            "if_expression": "if/else",
            "match_expression": "match",
            "for_expression": "bucle for",
            "while_expression": "bucle while",
            "loop_expression": "loop",
            "let_declaration": "declaracion let",
        },
    },
    "python": {
        "ts_name": "python",
        "extensions": [".py"],
        "mineable_types": {
            "function_definition", "if_statement", "for_statement",
            "while_statement", "try_statement", "with_statement",
            "class_definition", "decorated_definition", "lambda",
            "list_comprehension", "dictionary_comprehension",
            "set_comprehension", "generator_expression",
            "conditional_expression", "match_statement",
            "assert_statement", "augmented_assignment",
        },
        "identifier_types": {"identifier"},
        "literal_types": {"integer", "float", "string", "true", "false", "none"},
        "labels": {
            "function_definition": "funcion",
            "if_statement": "if/else",
            "for_statement": "bucle for",
            "while_statement": "bucle while",
            "try_statement": "try/except",
            "with_statement": "context manager (with)",
            "class_definition": "clase",
            "decorated_definition": "definicion decorada",
            "lambda": "lambda",
            "list_comprehension": "list comprehension",
            "dictionary_comprehension": "dict comprehension",
            "set_comprehension": "set comprehension",
            "generator_expression": "generator expression",
            "conditional_expression": "ternario",
            "match_statement": "match",
            "assert_statement": "assert",
            "augmented_assignment": "asignacion aumentada",
        },
    },
    "c": {
        "ts_name": "c",
        "extensions": [".c", ".h"],
        "mineable_types": {
            "function_definition", "if_statement", "for_statement",
            "while_statement", "switch_statement",
        },
        "identifier_types": {"identifier", "field_identifier"},
        "literal_types": {"number_literal", "string_literal", "char_literal"},
        "labels": {
            "function_definition": "funcion",
            "if_statement": "if/else",
            "for_statement": "bucle for",
            "while_statement": "bucle while",
            "switch_statement": "switch",
        },
    },
    "cpp": {
        "ts_name": "cpp",
        "extensions": [".cpp", ".cc", ".cxx", ".hpp", ".hh"],
        "mineable_types": {
            "function_definition", "if_statement", "for_statement",
            "while_statement", "switch_statement", "try_statement",
            "lambda_expression",
        },
        "identifier_types": {"identifier", "field_identifier"},
        "literal_types": {"number_literal", "string_literal", "char_literal"},
        "labels": {
            "function_definition": "funcion",
            "if_statement": "if/else",
            "for_statement": "bucle for",
            "while_statement": "bucle while",
            "switch_statement": "switch",
            "try_statement": "try/catch",
            "lambda_expression": "lambda",
        },
    },
    "go": {
        "ts_name": "go",
        "extensions": [".go"],
        "mineable_types": {
            "function_declaration", "method_declaration", "if_statement",
            "for_statement", "type_switch_statement", "expression_switch_statement",
            "go_statement", "select_statement",
        },
        "identifier_types": {"identifier", "field_identifier"},
        "literal_types": {"int_literal", "float_literal", "interpreted_string_literal", "raw_string_literal"},
        "labels": {
            "function_declaration": "funcion",
            "method_declaration": "metodo",
            "if_statement": "if/else",
            "for_statement": "bucle for",
            "type_switch_statement": "type switch",
            "expression_switch_statement": "switch",
            "go_statement": "goroutine (go)",
            "select_statement": "select",
        },
    },
    "javascript": {
        "ts_name": "javascript",
        "extensions": [".js", ".jsx", ".mjs"],
        "mineable_types": {
            "function_declaration", "function_expression", "arrow_function",
            "method_definition", "if_statement", "for_statement",
            "for_in_statement", "while_statement", "try_statement",
        },
        "identifier_types": {"identifier", "property_identifier", "shorthand_property_identifier"},
        "literal_types": {"number", "string", "true", "false", "null", "undefined"},
        "labels": {
            "function_declaration": "funcion",
            "function_expression": "funcion (expresion)",
            "arrow_function": "arrow function",
            "method_definition": "metodo",
            "if_statement": "if/else",
            "for_statement": "bucle for",
            "for_in_statement": "bucle for..of/in",
            "while_statement": "bucle while",
            "try_statement": "try/catch",
        },
    },
    "scala": {
        "ts_name": "scala",
        "extensions": [".scala"],
        "mineable_types": {
            "function_definition", "if_expression", "for_expression",
            "match_expression", "try_expression",
        },
        "identifier_types": {"identifier"},
        "literal_types": {"integer_literal", "floating_point_literal", "string", "boolean_literal"},
        "labels": {
            "function_definition": "funcion (def)",
            "if_expression": "if/else",
            "for_expression": "for comprehension",
            "match_expression": "match",
            "try_expression": "try/catch",
        },
    },
    "bash": {
        "ts_name": "bash",
        "extensions": [".sh", ".bash"],
        "mineable_types": {
            "function_definition", "if_statement", "for_statement",
            "while_statement", "case_statement", "c_style_for_statement",
        },
        "identifier_types": {"variable_name"},
        "literal_types": {"string", "raw_string", "number"},
        "labels": {
            "function_definition": "funcion",
            "if_statement": "if/else",
            "for_statement": "bucle for",
            "while_statement": "bucle while",
            "case_statement": "case",
            "c_style_for_statement": "bucle for (estilo C)",
        },
    },
}


def detect_language(filename: str):
    for lang, cfg in LANGUAGES.items():
        for ext in cfg["extensions"]:
            if filename.endswith(ext):
                return lang
    return None
