#!/usr/bin/env python3
import argparse
import os
import sys

from lang_config import LANGUAGES, detect_language
from core.extract import extract_units, inspect_node_types
from core.cluster import build_clusters, filter_by_support, diversify_top, content_score
from core.report import clusters_to_snipmate


def iter_files(root: str, langs: set[str]):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (
            ".git", "node_modules", "target", "__pycache__", "venv", ".venv", "build", "dist",
        )]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            lang = detect_language(fn)
            if lang and (not langs or lang in langs):
                yield full, lang


def cmd_mine(args):
    langs = set(args.langs.split(",")) if args.langs else set()
    for l in langs:
        if l not in LANGUAGES:
            sys.exit(f"lenguaje desconocido: {l} (soportados: {', '.join(LANGUAGES)})")

    all_units = []
    n_files = 0
    for path, lang in iter_files(args.path, langs):
        cfg = LANGUAGES[lang]
        try:
            units = extract_units(path, lang, cfg)
        except Exception as e:
            print(f"[aviso] no se pudo parsear {path}: {e}", file=sys.stderr)
            continue
        all_units.extend(units)
        n_files += 1

    print(f"[info] {n_files} ficheros analizados, {len(all_units)} unidades candidatas extraidas", file=sys.stderr)

    clusters = build_clusters(
        all_units, LANGUAGES,
        min_tokens=args.min_tokens, max_tokens=args.max_tokens,
    )
    clusters = filter_by_support(
        clusters,
        min_support=args.min_support,
        min_support_skeleton=args.min_support_skeleton,
        min_family_support=args.min_family_support,
    )

    n_promovidos = sum(1 for c in clusters if c.promoted_family_support is not None)
    n_skeleton = sum(1 for c in clusters if c.is_skeleton)
    print(f"[info] {len(clusters)} clusters con soporte >= {args.min_support} "
          f"({n_promovidos} promovidos por familia, {n_skeleton} por patron estructural)", file=sys.stderr)
    for c in clusters[:15]:
        print(f"        {c.lang:11s} {c.node_type:22s} x{c.support:<4d} {c.key}", file=sys.stderr)

    if args.diversify:
        top_clusters = diversify_top(
            clusters, top=args.top, max_per_type=args.max_per_type,
            cfg_by_lang=LANGUAGES, min_content_score=args.min_content_score,
            content_weight=args.content_weight,
            min_guaranteed_skeleton=args.min_structural,
        )
    else:
        for c in clusters:
            c.content_score = content_score(c, LANGUAGES[c.lang])
        top_clusters = clusters[:args.top] if args.top else clusters

    from collections import Counter
    reparto = Counter(c.node_type for c in top_clusters)
    print(f"[info] reparto en el top-{args.top}: {dict(reparto)}", file=sys.stderr)
    genericos = sum(1 for c in top_clusters if c.content_score == 0)
    print(f"[info] {genericos}/{len(top_clusters)} snippets sin vocabulario de dominio fijo (content_score=0)",
          file=sys.stderr)

    output = clusters_to_snipmate(top_clusters, LANGUAGES, top=None)

    with open(args.output, "w") as f:
        f.write(output)
    print(f"[info] escrito {args.output}", file=sys.stderr)


def cmd_inspect(args):
    lang = args.lang or detect_language(args.file)
    if not lang:
        sys.exit("no se pudo detectar el lenguaje, especifica --lang")
    cfg = LANGUAGES[lang]
    counts = inspect_node_types(args.file, cfg["ts_name"])
    for node_type, n in counts.items():
        marca = ""
        if node_type in cfg["mineable_types"]:
            marca = " [MINEABLE]"
        elif node_type in cfg["identifier_types"]:
            marca = " [ID]"
        elif node_type in cfg["literal_types"]:
            marca = " [LIT]"
        print(f"{n:6d}  {node_type}{marca}")


def main():
    p = argparse.ArgumentParser(description="Minero de idioms de codigo -> snippets snipMate")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_mine = sub.add_parser("mine", help="analiza un directorio y genera un fichero de snippets")
    p_mine.add_argument("--path", required=True)
    p_mine.add_argument("--langs", default="", help="lista separada por comas, vacio = todos")
    p_mine.add_argument("--min-support", type=int, default=3)
    p_mine.add_argument("--min-support-skeleton", type=int, default=2,
                         help="umbral de soporte propio para clusters 'skeleton' (funciones/clases/decoradas con "
                              "matching borroso, ver structural_types en lang_config.py); exigir 3 identicas es "
                              "demasiado estricto para funciones/clases grandes, por defecto 2")
    p_mine.add_argument("--min-structural", type=int, default=5,
                         help="cuantos clusters skeleton (funcion/clase/decorada 'borrosa') como minimo se "
                              "garantizan en el --top, por encima del minimo de 1-por-tipo; sube esto si quieres "
                              "ver mas patrones de arquitectura y no solo el mejor de cada uno")
    p_mine.add_argument("--min-family-support", type=int, default=None,
                         help="soporte minimo AGREGADO de la 'familia' estructural (if/for/while/try/with, o "
                              "funciones/clases de un lenguaje sin skeleton especifico, con la misma secuencia de "
                              "statements aunque no sean clones exactos) para promover un idiom aunque su soporte "
                              "exacto no llegue a --min-support; por defecto usa el mismo valor que --min-support")
    p_mine.add_argument("--min-content-score", type=int, default=0,
                         help="descarta clusters sin vocabulario de dominio fijo (idioms puramente genericos "
                              "tipo 'lambda e: e[0]'). Prueba 1 o 2.")
    p_mine.add_argument("--content-weight", type=float, default=1.0,
                         help="0.0 = ranking solo por frecuencia (comportamiento antiguo); valores mayores "
                              "priorizan mas los idioms con nombres fijos anclados al dominio (mido, pitch, "
                              "chord...) frente a esqueletos de sintaxis puramente genericos (lambda, ternario...)")
    p_mine.add_argument("--min-tokens", type=int, default=6)
    p_mine.add_argument("--max-tokens", type=int, default=150)
    p_mine.add_argument("--top", type=int, default=100)
    p_mine.add_argument("--max-per-type", type=int, default=None,
                         help="tope de snippets por tipo de nodo (funcion, if/else...) dentro del --top; por defecto se calcula automaticamente")
    p_mine.add_argument("--no-diversify", dest="diversify", action="store_false",
                         help="desactiva el reparto por tipo y vuelve al ranking plano por frecuencia global")
    p_mine.add_argument("--output", default="mined.snippets")
    p_mine.set_defaults(func=cmd_mine)

    p_inspect = sub.add_parser("inspect", help="vuelca los tipos de nodo de un fichero (calibracion)")
    p_inspect.add_argument("--file", required=True)
    p_inspect.add_argument("--lang", default=None)
    p_inspect.set_defaults(func=cmd_inspect)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
