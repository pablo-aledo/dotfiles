#!/usr/bin/env python3
import argparse
import os
import sys

from lang_config import LANGUAGES, detect_language
from core.extract import extract_units, inspect_node_types
from core.cluster import build_clusters, filter_by_support, diversify_top
from core.report import clusters_to_snipmate


def iter_files(root: str, langs: set[str]):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (
            ".git", "node_modules", "target", "__pycache__", "venv", ".venv", "build", "dist",
        )]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            lang = detect_language(fn)
            if lang and (not langs or lang in langs):
                yield full, lang


def cmd_mine(args):
    langs = set(args.langs.split(",")) if args.langs else set()
    for l in langs:
        if l not in LANGUAGES:
            sys.exit(f"lenguaje desconocido: {l} (soportados: {', '.join(LANGUAGES)})")

    all_units = []
    n_files = 0
    for path, lang in iter_files(args.path, langs):
        cfg = LANGUAGES[lang]
        try:
            units = extract_units(path, lang, cfg)
        except Exception as e:
            print(f"[aviso] no se pudo parsear {path}: {e}", file=sys.stderr)
            continue
        all_units.extend(units)
        n_files += 1

    print(f"[info] {n_files} ficheros analizados, {len(all_units)} unidades candidatas extraidas", file=sys.stderr)

    clusters = build_clusters(
        all_units, LANGUAGES,
        min_tokens=args.min_tokens, max_tokens=args.max_tokens,
    )
    clusters = filter_by_support(clusters, min_support=args.min_support)

    print(f"[info] {len(clusters)} clusters con soporte >= {args.min_support}", file=sys.stderr)
    for c in clusters[:15]:
        print(f"        {c.lang:11s} {c.node_type:22s} x{c.support:<4d} {c.key}", file=sys.stderr)

    if args.diversify:
        top_clusters = diversify_top(clusters, top=args.top, max_per_type=args.max_per_type)
    else:
        top_clusters = clusters[:args.top] if args.top else clusters

    from collections import Counter
    reparto = Counter(c.node_type for c in top_clusters)
    print(f"[info] reparto en el top-{args.top}: {dict(reparto)}", file=sys.stderr)

    output = clusters_to_snipmate(top_clusters, LANGUAGES, top=None)

    with open(args.output, "w") as f:
        f.write(output)
    print(f"[info] escrito {args.output}", file=sys.stderr)


def cmd_inspect(args):
    lang = args.lang or detect_language(args.file)
    if not lang:
        sys.exit("no se pudo detectar el lenguaje, especifica --lang")
    cfg = LANGUAGES[lang]
    counts = inspect_node_types(args.file, cfg["ts_name"])
    for node_type, n in counts.items():
        marca = ""
        if node_type in cfg["mineable_types"]:
            marca = " [MINEABLE]"
        elif node_type in cfg["identifier_types"]:
            marca = " [ID]"
        elif node_type in cfg["literal_types"]:
            marca = " [LIT]"
        print(f"{n:6d}  {node_type}{marca}")


def main():
    p = argparse.ArgumentParser(description="Minero de idioms de codigo -> snippets snipMate")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_mine = sub.add_parser("mine", help="analiza un directorio y genera un fichero de snippets")
    p_mine.add_argument("--path", required=True)
    p_mine.add_argument("--langs", default="", help="lista separada por comas, vacio = todos")
    p_mine.add_argument("--min-support", type=int, default=3)
    p_mine.add_argument("--min-tokens", type=int, default=6)
    p_mine.add_argument("--max-tokens", type=int, default=150)
    p_mine.add_argument("--top", type=int, default=100)
    p_mine.add_argument("--max-per-type", type=int, default=None,
                         help="tope de snippets por tipo de nodo (funcion, if/else...) dentro del --top; por defecto se calcula automaticamente")
    p_mine.add_argument("--no-diversify", dest="diversify", action="store_false",
                         help="desactiva el reparto por tipo y vuelve al ranking plano por frecuencia global")
    p_mine.add_argument("--output", default="mined.snippets")
    p_mine.set_defaults(func=cmd_mine)

    p_inspect = sub.add_parser("inspect", help="vuelca los tipos de nodo de un fichero (calibracion)")
    p_inspect.add_argument("--file", required=True)
    p_inspect.add_argument("--lang", default=None)
    p_inspect.set_defaults(func=cmd_inspect)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
