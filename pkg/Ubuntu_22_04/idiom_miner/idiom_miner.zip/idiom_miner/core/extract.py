"""
Extrae "unidades mineables" (subarboles candidatos a snippet) de un fichero
fuente, usando tree-sitter. Es agnostico al lenguaje: solo consulta los
sets de configuracion (mineable_types) que le pasan.
"""
from dataclasses import dataclass
from tree_sitter_languages import get_parser


@dataclass
class Unit:
    file: str
    lang: str
    node_type: str
    node: object  # tree_sitter.Node vivo (necesario para recorrer el subarbol)
    start_line: int
    source: bytes  # bytes completos del fichero (para poder recortar luego)

    @property
    def start_byte(self):
        return self.node.start_byte

    @property
    def end_byte(self):
        return self.node.end_byte

    @property
    def text(self) -> str:
        return self.source[self.start_byte:self.end_byte].decode("utf-8", errors="replace")


_parser_cache = {}


def _get_parser(ts_name: str):
    if ts_name not in _parser_cache:
        _parser_cache[ts_name] = get_parser(ts_name)
    return _parser_cache[ts_name]


def parse_file(path: str, ts_name: str):
    with open(path, "rb") as f:
        source = f.read()
    parser = _get_parser(ts_name)
    tree = parser.parse(source)
    return tree, source


def extract_units(path: str, lang: str, cfg: dict) -> list[Unit]:
    """Recorre el AST completo y devuelve todos los nodos cuyo tipo esta
    en cfg['mineable_types']."""
    tree, source = parse_file(path, cfg["ts_name"])
    mineable = cfg["mineable_types"]
    units = []

    def walk(node):
        if node.type in mineable:
            units.append(Unit(
                file=path,
                lang=lang,
                node_type=node.type,
                node=node,
                start_line=node.start_point[0] + 1,
                source=source,
            ))
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return units


def inspect_node_types(path: str, ts_name: str) -> dict:
    """Utilidad de calibracion: cuenta cuantas veces aparece cada tipo de
    nodo en un fichero, para ayudar a rellenar lang_config.py."""
    tree, _source = parse_file(path, ts_name)
    counts: dict[str, int] = {}

    def walk(node):
        counts[node.type] = counts.get(node.type, 0) + 1
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return dict(sorted(counts.items(), key=lambda kv: -kv[1]))
