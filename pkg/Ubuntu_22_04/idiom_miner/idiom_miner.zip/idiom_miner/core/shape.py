"""
Normaliza el subarbol de una Unit a una "forma" (shape) que ignora nombres
de variables y valores de literales, pero conserva la estructura sintactica
exacta (tipos de nodo, orden, anidamiento, keywords y puntuacion literal).

Dos unidades con la misma forma son, a efectos de este minero, "el mismo
idiom" aunque usen nombres de variables distintos.
"""
import hashlib


def leaves(node):
    """Devuelve la lista de nodos hoja (sin hijos) en orden de aparicion.
    Incluye tanto hojas nombradas (identificadores, literales) como no
    nombradas (keywords, puntuacion: 'if', '(', '{', ...)."""
    if node.child_count == 0:
        return [node]
    result = []
    for child in node.children:
        result.extend(leaves(child))
    return result


def node_shape_token(node, cfg) -> str:
    """Que token representa esta hoja en la 'forma' generalizada."""
    if node.type in cfg["identifier_types"]:
        return "ID"
    if node.type in cfg["literal_types"]:
        return "LIT"
    if node.type == "comment":
        return "COMMENT"
    # keyword o puntuacion: el tipo ES el texto literal (p.ej. 'if', '(', '{')
    return node.type


def compute_shape(unit, cfg) -> str:
    """Cadena de forma generalizada: secuencia de tokens de las hojas."""
    hojas = leaves(unit.node)
    return " ".join(node_shape_token(h, cfg) for h in hojas)


def shape_hash(shape: str) -> str:
    return hashlib.sha256(shape.encode("utf-8")).hexdigest()[:12]


def token_count(unit) -> int:
    return len(leaves(unit.node))


def _walk_bounded(node, cfg, depth, out):
    """Recorre el arbol hasta `depth` niveles; a partir de ahi, colapsa
    cada subarbol restante a un unico token (su node.type), sin bajar a
    sus hojas. Asi dos statements del mismo tipo cuentan como "iguales"
    para la familia aunque su contenido interno difiera."""
    if node.child_count == 0:
        out.append(node_shape_token(node, cfg))
        return
    if depth <= 0:
        out.append(node.type)
        return
    out.append(node.type)
    out.append("(")
    for child in node.children:
        _walk_bounded(child, cfg, depth - 1, out)
    out.append(")")


def family_shape(unit, cfg, depth: int = 3) -> str:
    """Forma "gruesa": igual que compute_shape pero solo baja `depth`
    niveles de profundidad; mas alla de eso, cada subarbol se colapsa a
    su tipo de nodo en vez de expandirse hoja a hoja.

    Sirve para agrupar construcciones grandes (funciones, clases, bloques
    if/for/while/try/with con cuerpo real) que tienen la MISMA secuencia
    de tipos de statement (mismo "esqueleto") aunque el contenido de cada
    statement varie -- cosa que compute_shape jamas agruparia porque exige
    coincidencia exacta hoja a hoja en TODO el subarbol, incluido el
    interior de cada statement.
    """
    out: list[str] = []
    _walk_bounded(unit.node, cfg, depth, out)
    return " ".join(out)


# ---------------------------------------------------------------------------
# Skeleton matching: para function_definition/class_definition/
# decorated_definition, exigir forma LITERAL identica (compute_shape) casi
# nunca produce clusters, porque dos funciones/clases raramente comparten
# exactamente el mismo cuerpo hoja a hoja aunque sigan "el mismo patron".
#
# compute_skeleton() genera una forma mas gruesa y semanticamente informada
# (a diferencia de family_shape, que es generica/ciega al lenguaje): describe
# la FIRMA (nombre de decoradores, num. parametros) y, para el cuerpo, solo
# el TIPO de cada sentencia de primer nivel (sin bajar a sus hojas). Para
# clases, describe la lista de miembros: metodos dunder por nombre
# (__init__, __len__...), resto de metodos como "METHOD" generico, etc.
#
# Es especifica de la gramatica tree-sitter-python (los nombres de nodo
# 'function_definition', 'block', 'parameters'... son de ese lenguaje), asi
# que solo se activa para los node_type que cada configuracion de lenguaje
# liste en cfg['structural_types']. Para el resto de lenguajes (o de tipos
# de nodo) seguimos apoyandonos en family_shape, mas tosca pero generica.
# ---------------------------------------------------------------------------

_GENERIC_DECORATORS = {
    "staticmethod", "classmethod", "property", "abstractmethod",
    "dataclass", "overload", "cached_property", "wraps", "functools",
}


def _child_of_type(node, types):
    for c in node.children:
        if c.type in types:
            return c
    return None


def _decorator_name(decorator_node, source: bytes) -> str:
    # decorator: '@' + (identifier | attribute | call). Nos quedamos con
    # el nombre "de fondo" sin argumentos, p.ej. '@app.route(...)' -> 'route'
    for c in decorator_node.children:
        if c.type == "@":
            continue
        text = source[c.start_byte:c.end_byte].decode("utf-8", errors="replace")
        text = text.split("(")[0]  # quitar argumentos de llamada si los hay
        return text.split(".")[-1]
    return "?"


def _param_count(function_node) -> int:
    params = _child_of_type(function_node, {"parameters"})
    if params is None:
        return 0
    interesting = {
        "identifier", "typed_parameter", "default_parameter",
        "typed_default_parameter", "list_splat_pattern", "dictionary_splat_pattern",
    }
    names_seen = 0
    for c in params.children:
        if c.type in interesting:
            names_seen += 1
    return names_seen


def _statement_skeleton(block_node) -> list[str]:
    if block_node is None:
        return []
    return [c.type for c in block_node.children if c.type not in ("comment",)]


def _skeleton_function(function_node) -> str:
    n_params = _param_count(function_node)
    body = _child_of_type(function_node, {"block"})
    stmts = _statement_skeleton(body)
    return f"def(params={n_params}) {{ " + " ".join(stmts) + " }"


def _skeleton_class(class_node, source: bytes) -> str:
    body = _child_of_type(class_node, {"block"})
    members = []
    if body is not None:
        for c in body.children:
            if c.type == "function_definition":
                name_node = _child_of_type(c, {"identifier"})
                name = source[name_node.start_byte:name_node.end_byte].decode("utf-8", errors="replace") if name_node else "?"
                if name.startswith("__") and name.endswith("__"):
                    members.append(f"DUNDER:{name}")
                else:
                    members.append("METHOD")
            elif c.type == "decorated_definition":
                inner = _child_of_type(c, {"function_definition", "class_definition"})
                members.append("DEC_METHOD" if inner is not None else "DEC")
            elif c.type == "comment":
                continue
            else:
                members.append(c.type.upper())
    return "class { " + " ".join(members) + " }"


def compute_skeleton(unit, cfg) -> str:
    """Forma 'borrosa' para node_types en cfg['structural_types']."""
    node = unit.node

    if node.type == "decorated_definition":
        decorators = [c for c in node.children if c.type == "decorator"]
        dec_names = sorted(_decorator_name(d, unit.source) for d in decorators)
        inner = _child_of_type(node, {"function_definition", "class_definition"})
        if inner is None:
            return "DECORATED[" + ",".join(dec_names) + "]"
        inner_skel = (
            _skeleton_function(inner) if inner.type == "function_definition"
            else _skeleton_class(inner, unit.source)
        )
        return "DECORATED[" + ",".join(dec_names) + "] " + inner_skel

    if node.type == "class_definition":
        return _skeleton_class(node, unit.source)

    if node.type == "function_definition":
        return _skeleton_function(node)

    # tipo no reconocido como estructural: no deberia llegar aqui si
    # structural_types esta bien configurado, pero por seguridad caemos
    # a la forma literal.
    return compute_shape(unit, cfg)
