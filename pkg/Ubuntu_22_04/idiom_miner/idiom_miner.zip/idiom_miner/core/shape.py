"""
Normaliza el subarbol de una Unit a una "forma" (shape) que ignora nombres
de variables y valores de literales, pero conserva la estructura sintactica
exacta (tipos de nodo, orden, anidamiento, keywords y puntuacion literal).

Dos unidades con la misma forma son, a efectos de este minero, "el mismo
idiom" aunque usen nombres de variables distintos.
"""
import hashlib


def leaves(node):
    """Devuelve la lista de nodos hoja (sin hijos) en orden de aparicion.
    Incluye tanto hojas nombradas (identificadores, literales) como no
    nombradas (keywords, puntuacion: 'if', '(', '{', ...)."""
    if node.child_count == 0:
        return [node]
    result = []
    for child in node.children:
        result.extend(leaves(child))
    return result


def node_shape_token(node, cfg) -> str:
    """Que token representa esta hoja en la 'forma' generalizada."""
    if node.type in cfg["identifier_types"]:
        return "ID"
    if node.type in cfg["literal_types"]:
        return "LIT"
    if node.type == "comment":
        return "COMMENT"
    # keyword o puntuacion: el tipo ES el texto literal (p.ej. 'if', '(', '{')
    return node.type


def compute_shape(unit, cfg) -> str:
    """Cadena de forma generalizada: secuencia de tokens de las hojas."""
    hojas = leaves(unit.node)
    return " ".join(node_shape_token(h, cfg) for h in hojas)


def shape_hash(shape: str) -> str:
    return hashlib.sha256(shape.encode("utf-8")).hexdigest()[:12]


def token_count(unit) -> int:
    return len(leaves(unit.node))
