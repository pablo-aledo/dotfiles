import re
from .template import build_template, build_skeleton_template


def _slug(text: str, maxlen=24) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "_", text).strip("_").lower()
    return text[:maxlen] or "x"


def _indent_body(template: str) -> str:
    lines = template.split("\n")
    return "\n".join("\t" + l if l.strip() else l for l in lines)


def clusters_to_snipmate(clusters, cfg_by_lang, top=None) -> str:
    if top:
        clusters = clusters[:top]

    out_lines = [
        "# Snippets minados automaticamente de la base de codigo",
        "# Formato: snipMate (garbas/vim-snipmate)",
        "# Generado por idiom_miner.py -- revisar antes de usar en produccion",
        "",
    ]

    seen_prefixes = set()

    for c in clusters:
        cfg = cfg_by_lang[c.lang]
        template = build_skeleton_template(c, cfg) if c.is_skeleton else build_template(c, cfg)
        if template is None:
            continue

        label = cfg["labels"].get(c.node_type, c.node_type)
        example_file = c.units[0].file
        example_line = c.units[0].start_line

        prefix_base = f"mined-{c.lang[:2]}-{_slug(label, 12)}"
        prefix = prefix_base
        n = 2
        while prefix in seen_prefixes:
            prefix = f"{prefix_base}{n}"
            n += 1
        seen_prefixes.add(prefix)

        detalle = f"x{c.support}"
        if getattr(c, "promoted_family_support", None):
            detalle += f", familia x{c.promoted_family_support}"
        detalle += f", vocab.dominio={getattr(c, 'content_score', 0)}"

        tag = " [patron estructural]" if c.is_skeleton else ""
        desc = f"{label}{tag} recurrente en {c.lang} ({detalle}, ej. {example_file}:{example_line})"

        out_lines.append(f"snippet {prefix} \"{desc}\"")
        out_lines.append(_indent_body(template))
        out_lines.append("")

    return "\n".join(out_lines)
