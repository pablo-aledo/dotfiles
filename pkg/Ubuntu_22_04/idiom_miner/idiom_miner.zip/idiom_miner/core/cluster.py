from dataclasses import dataclass, field
from .shape import compute_shape, shape_hash, token_count


@dataclass
class Cluster:
    key: str            # (lang, node_type, shape_hash)
    lang: str
    node_type: str
    shape: str
    units: list = field(default_factory=list)

    @property
    def support(self) -> int:
        return len(self.units)


def build_clusters(units, cfg_by_lang, min_tokens=6, max_tokens=150) -> list[Cluster]:
    clusters: dict[str, Cluster] = {}

    for u in units:
        cfg = cfg_by_lang[u.lang]
        n = token_count(u)
        if n < min_tokens or n > max_tokens:
            continue
        shape = compute_shape(u, cfg)
        h = shape_hash(shape)
        key = f"{u.lang}:{u.node_type}:{h}"
        if key not in clusters:
            clusters[key] = Cluster(key=key, lang=u.lang, node_type=u.node_type, shape=shape)
        clusters[key].units.append(u)

    return list(clusters.values())


def filter_by_support(clusters, min_support=3) -> list[Cluster]:
    filtrados = [c for c in clusters if c.support >= min_support]
    # unidades mas frecuentes primero
    filtrados.sort(key=lambda c: -c.support)
    return filtrados


def dedupe_nested(clusters: list[Cluster]) -> list[Cluster]:
    """Si dos clusters aparecen exactamente en las mismas ubicaciones
    (uno anidado trivialmente dentro del otro para TODAS sus instancias),
    nos quedamos con el mas especifico (el de mayor node_type distinto,
    heuristica simple: el de mas tokens en la forma)."""
    # Prototipo: no eliminamos nada todavia, solo devolvemos igual.
    # (dejado como punto de extension documentado)
    return clusters


def diversify_top(clusters, top, max_per_type=None):
    """Selecciona hasta `top` clusters repartiendo el cupo entre node_types,
    en vez de coger sin mas los `top` de mayor soporte global.

    Sin esto, un tipo de nodo intrinsecamente mas frecuente (p.ej.
    if_statement) acapara casi todo el --top y el resultado parece "poco
    variado" aunque existan clusters interesantes de otros tipos con
    soporte suficiente (>= min_support) pero fuera del corte.

    Estrategia: por cada tipo de nodo, ordenar sus clusters por soporte
    descendente. Ir seleccionando en round-robin el mejor candidato
    disponible (mayor soporte) de entre los tipos que no hayan alcanzado
    su cuota todavia. Si todos los tipos con clusters restantes ya
    agotaron su cuota, se relaja el limite para no desperdiciar hueco.
    """
    from collections import defaultdict

    by_type: dict[str, list[Cluster]] = defaultdict(list)
    for c in clusters:
        by_type[c.node_type].append(c)
    for lst in by_type.values():
        lst.sort(key=lambda c: -c.support)

    if not by_type:
        return []

    if max_per_type is None:
        # cuota por defecto: no dejar que un solo tipo pase de ~1/3 del
        # top, pero garantizando al menos unos pocos huecos por tipo.
        max_per_type = max(3, (top // max(1, len(by_type))) * 2)

    remaining = {t: list(lst) for t, lst in by_type.items()}
    counts: dict[str, int] = defaultdict(int)
    selected: list[Cluster] = []

    while len(selected) < top and any(remaining.values()):
        candidatos = [
            (remaining[t][0].support, t)
            for t in remaining
            if remaining[t] and counts[t] < max_per_type
        ]
        if not candidatos:
            # todos los tipos con clusters restantes agotaron su cuota:
            # relajamos el limite para no dejar huecos vacios en el top
            candidatos = [(remaining[t][0].support, t) for t in remaining if remaining[t]]
            if not candidatos:
                break
        candidatos.sort(reverse=True)
        _, t = candidatos[0]
        selected.append(remaining[t].pop(0))
        counts[t] += 1

    return selected
