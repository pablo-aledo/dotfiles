from dataclasses import dataclass, field
from collections import defaultdict
import re

from .shape import compute_shape, compute_skeleton, shape_hash, token_count, family_shape, leaves

# nombres tan cortos/genericos que aparecer fijos en un cluster no dice nada
# sobre la tematica del repositorio (bucles, indices, self, etc.)
_GENERIC_STOPWORDS = {
    "self", "cls", "i", "j", "k", "n", "x", "y", "z", "f", "p", "c", "t",
    "s", "d", "v", "e", "a", "b", "_", "idx", "val", "tmp", "obj", "data",
    "true", "false", "none", "0", "1", "2",
}

_GENERIC_DECORATOR_NAMES = {
    "staticmethod", "classmethod", "property", "abstractmethod",
    "dataclass", "overload", "cached_property", "wraps",
}

# a partir de este numero de tokens una unidad "grande" pero NO cubierta por
# cfg['structural_types'] (if/for/while/try/with, o funciones/clases en un
# lenguaje que no tiene compute_skeleton implementado) recibe ademas una
# forma de familia (mas gruesa, generica) para agruparla de forma aproximada.
FAMILY_MIN_TOKENS = 20
FAMILY_DEPTH = 3


@dataclass
class Cluster:
    key: str            # (lang, node_type, shape_hash)
    lang: str
    node_type: str
    shape: str
    units: list = field(default_factory=list)
    is_skeleton: bool = False          # True si el shape viene de compute_skeleton()
    family: str | None = None          # hash de family_shape, solo si NO es skeleton y es "grande"
    promoted_family_support: int | None = None  # soporte agregado de la familia, si fue promovido
    content_score: int = 0             # se rellena despues de filtrar (ver content_score())

    @property
    def support(self) -> int:
        return len(self.units)


def build_clusters(units, cfg_by_lang, min_tokens=6, max_tokens=150) -> list[Cluster]:
    """Construye clusters combinando tres estrategias de forma, de mas a
    menos precisa:

    1. compute_skeleton(): para node_types en cfg['structural_types']
       (funciones/clases/decoradas en python, ver shape.py) -- forma
       semanticamente informada (firma, dunders, decoradores, tipos de
       statement de primer nivel). Es la mas "borrosa" a proposito: agrupa
       cosas que NUNCA coincidirian byte a byte.
    2. compute_shape() literal (como siempre) + family_shape() como
       metadato adicional para las unidades "grandes" que no caen en (1)
       -- bloques if/for/while/try/with, o funciones/clases de un lenguaje
       sin compute_skeleton especifico. family_shape() no cambia la key de
       agrupacion (eso lo sigue haciendo el hash literal), solo permite
       promover en filter_by_support() un cluster exacto minoritario si
       sus "primos" estructurales, sumados, superan el minimo.
    3. compute_shape() literal a secas para todo lo demas (lambdas,
       comprehensions, ternarios...): aqui la coincidencia exacta SI es la
       señal correcta, son constructos pequeños y rigidos.
    """
    clusters: dict[str, Cluster] = {}

    for u in units:
        cfg = cfg_by_lang[u.lang]
        n = token_count(u)
        if n < min_tokens or n > max_tokens:
            continue

        es_skeleton = u.node_type in cfg.get("structural_types", set())
        if es_skeleton and u.node_type == "function_definition" and n < FAMILY_MIN_TOKENS:
            # una funcion de una linea es lo bastante pequeña como para que
            # el matching literal (exacto) siga siendo la señal correcta;
            # el skeleton borroso solo aporta a partir de cierto tamaño de
            # cuerpo, si no agruparia sin criterio cualquier funcion trivial
            # de una sola sentencia.
            es_skeleton = False
        if es_skeleton:
            shape = compute_skeleton(u, cfg)
        else:
            shape = compute_shape(u, cfg)

        h = shape_hash(shape)
        key = f"{u.lang}:{u.node_type}:{h}"
        if key not in clusters:
            c = Cluster(key=key, lang=u.lang, node_type=u.node_type, shape=shape, is_skeleton=es_skeleton)
            if not es_skeleton and n >= FAMILY_MIN_TOKENS:
                fam_shape = family_shape(u, cfg, depth=FAMILY_DEPTH)
                c.family = shape_hash(fam_shape)
            clusters[key] = c
        clusters[key].units.append(u)

    return list(clusters.values())


def filter_by_support(
    clusters,
    min_support: int = 3,
    min_support_skeleton: int | None = None,
    min_family_support: int | None = None,
    min_exact_support_for_family: int = 2,
    max_variants_per_family: int = 1,
) -> list[Cluster]:
    """Selecciona clusters por soporte, con dos mecanismos de rescate para
    construcciones grandes (que rara vez son clones byte a byte):

    - Clusters skeleton (is_skeleton=True): usan su PROPIO umbral, mas bajo
      por defecto (min_support_skeleton), porque su forma ya es aproximada
      -- exigir 3 clases con arquitectura identica es mas dificil que exigir
      3 if_statement identicos.
    - Clusters literales "grandes" (family is not None): se promueven
      aunque su soporte EXACTO no llegue a min_support, si la suma de
      soporte de toda su "familia" estructural (variantes con la misma
      secuencia de statements pero contenido interno distinto) SI alcanza
      min_family_support. Ver family_shape() en shape.py para el porque.
    """
    if min_support_skeleton is None:
        min_support_skeleton = min_support
    if min_family_support is None:
        min_family_support = min_support

    exactos = [
        c for c in clusters
        if c.support >= (min_support_skeleton if c.is_skeleton else min_support)
    ]
    exactos_keys = {c.key for c in exactos}

    familias: dict[tuple, list[Cluster]] = defaultdict(list)
    for c in clusters:
        if c.family is not None:
            familias[(c.lang, c.node_type, c.family)].append(c)

    promovidos: list[Cluster] = []
    for miembros in familias.values():
        soporte_familia = sum(c.support for c in miembros)
        if soporte_familia < min_family_support:
            continue
        candidatos = sorted(
            (c for c in miembros
             if c.support >= min_exact_support_for_family and c.key not in exactos_keys),
            key=lambda c: -c.support,
        )
        for c in candidatos[:max_variants_per_family]:
            c.promoted_family_support = soporte_familia
            promovidos.append(c)

    filtrados = exactos + promovidos
    filtrados.sort(key=lambda c: -c.support)
    return filtrados


def _content_score_skeleton(shape: str) -> int:
    """Señal de vocabulario de dominio codificada en la propia FORMA (no
    en el cuerpo): nombres de metodos dunder implementados (protocolo
    real, p.ej. __len__/__getitem__) y decoradores no genericos
    (p.ej. @app.route en vez de @staticmethod).

    Para clases/decoradas esto ya es una señal razonable. Para una
    funcion suelta sin decorar NUNCA hay DUNDER: ni DECORATED[...] en su
    forma (no aplica), asi que esta funcion sola siempre devuelve 0 para
    ese caso -- ver _content_score_skeleton_body() para el complemento
    que cubre justo ese caso.
    """
    score = 0
    for _ in re.findall(r"DUNDER:(\w+)", shape):
        score += 1  # implementar un protocolo (dunder) siempre es señal de arquitectura
    for bloque in re.findall(r"DECORATED\[([^\]]*)\]", shape):
        for dec in bloque.split(","):
            dec = dec.strip()
            if dec and len(dec) >= 4 and dec.lower() not in _GENERIC_DECORATOR_NAMES:
                score += 1
    return score


def _content_score_skeleton_body(cluster: Cluster, cfg: dict) -> int:
    """Complementa _content_score_skeleton() para clusters skeleton cuya
    forma no lleva dunders ni decoradores (el caso mas comun: una funcion
    normal y corriente sin decorar). Sin esto, CUALQUIER funcion suelta
    puntuaria 0 siempre por diseño -- aunque su cuerpo este lleno de
    vocabulario de dominio (p.ej. `return NOTE_NAMES[n % 12] + ...`) --
    porque _content_score_skeleton() solo mira la forma, no el cuerpo, y
    la forma de una funcion sin decorar no registra nada de eso.

    Como las instancias de un cluster skeleton NO tienen el mismo numero
    de hojas, no podemos exigir "texto fijo en TODAS las instancias" como
    en el caso literal. En su lugar, contamos el vocabulario de dominio
    presente en el cuerpo de la instancia representativa (la misma que
    usara build_skeleton_template: tamaño mediano), con el mismo filtro de
    longitud >= 4 y stopwords genericos. Se acota a 6 para no dejar que
    una funcion muy larga domine el ranking solo por tener mas texto.
    """
    if not cluster.units:
        return 0
    instances = sorted(cluster.units, key=token_count)
    base = instances[len(instances) // 2]
    score = 0
    for leaf in leaves(base.node):
        if leaf.type not in cfg["identifier_types"] and leaf.type not in cfg["literal_types"]:
            continue
        text = base.source[leaf.start_byte:leaf.end_byte].decode("utf-8", errors="replace")
        norm = text.strip("'\"").lower()
        if len(norm) < 4 or norm in _GENERIC_STOPWORDS:
            continue
        score += 1
        if score >= 6:
            break
    return score


def content_score(cluster: Cluster, cfg: dict) -> int:
    """Cuenta cuanto vocabulario de dominio "fijo" sobrevive en un cluster.

    - Clusters literales: hojas identificador/literal identicas en TODAS
      las instancias (longitud >= 4, fuera de la lista de nombres
      genericos self/i/n/tmp/data...). Es el texto que sobrevive porque es
      tuyo: .offset, .pitch, mido, 'cuda', claves de dict...
    - Clusters skeleton: combina la señal de forma (dunders/decoradores,
      _content_score_skeleton) con el vocabulario del cuerpo de la
      instancia representativa (_content_score_skeleton_body), porque una
      funcion suelta sin decorar y sin dunders -- el caso mas frecuente --
      no deja NINGUNA señal en la forma, solo en su cuerpo.
    """
    if cluster.is_skeleton:
        return _content_score_skeleton(cluster.shape) + _content_score_skeleton_body(cluster, cfg)

    instances = cluster.units
    if len(instances) < 2:
        return 0

    base = instances[0]
    base_leaves = leaves(base.node)
    other_leaf_lists = []
    for inst in instances[1:]:
        ls = leaves(inst.node)
        if len(ls) == len(base_leaves):
            other_leaf_lists.append((inst, ls))
    if not other_leaf_lists:
        return 0

    score = 0
    for i, leaf in enumerate(base_leaves):
        if leaf.type not in cfg["identifier_types"] and leaf.type not in cfg["literal_types"]:
            continue
        base_text = base.source[leaf.start_byte:leaf.end_byte].decode("utf-8", errors="replace")
        norm = base_text.strip("'\"").lower()
        if len(norm) < 4 or norm in _GENERIC_STOPWORDS:
            continue
        fijo = all(
            inst.source[ls[i].start_byte:ls[i].end_byte].decode("utf-8", errors="replace") == base_text
            for inst, ls in other_leaf_lists
        )
        if fijo:
            score += 1
    return score


def dedupe_nested(clusters: list[Cluster]) -> list[Cluster]:
    """Si dos clusters aparecen exactamente en las mismas ubicaciones
    (uno anidado trivialmente dentro del otro para TODAS sus instancias),
    nos quedamos con el mas especifico (el de mayor node_type distinto,
    heuristica simple: el de mas tokens en la forma)."""
    # Prototipo: no eliminamos nada todavia, solo devolvemos igual.
    # (dejado como punto de extension documentado)
    return clusters


def diversify_top(clusters, top, max_per_type=None, cfg_by_lang=None,
                   min_content_score=0, content_weight=1.0,
                   min_guaranteed_skeleton=1):
    """Selecciona hasta `top` clusters repartiendo el cupo entre node_types,
    priorizando dentro de cada tipo por relevancia (soporte x vocabulario
    de dominio) en vez de solo frecuencia, y garantizando presencia minima
    tanto por tipo de nodo como -- reforzada -- para clusters skeleton.

    `min_content_score` descarta clusters LITERALES sin ningun rastro de
    vocabulario propio (p.ej. `lambda e: e[0]`). Los clusters skeleton no
    se descartan por esto: que 2+ clases/funciones compartan exactamente
    la misma arquitectura (mismos dunders, misma secuencia de statements)
    ya es una señal estructural real aunque no lleve nombres "largos".

    `min_guaranteed_skeleton` fuerza un minimo de clusters is_skeleton en
    el resultado, por encima de la garantia base de 1-por-tipo: son mas
    caros de conseguir (exigen que 2+ funciones/clases coincidan en
    arquitectura entera) que un if/lambda, y sin esto nunca ganarian la
    competicion directa contra tipos con soporte en cientos.
    """
    if cfg_by_lang is not None:
        for c in clusters:
            c.content_score = content_score(c, cfg_by_lang[c.lang])
        if min_content_score > 0:
            clusters = [c for c in clusters if c.is_skeleton or c.content_score >= min_content_score]

    def relevance(c):
        return c.support * (1 + content_weight * c.content_score)

    by_type: dict[str, list[Cluster]] = defaultdict(list)
    for c in clusters:
        by_type[c.node_type].append(c)
    for lst in by_type.values():
        lst.sort(key=lambda c: -relevance(c))

    if not by_type:
        return []

    if max_per_type is None:
        max_per_type = max(3, (top // max(1, len(by_type))) * 2)

    remaining = {t: list(lst) for t, lst in by_type.items()}
    counts: dict[str, int] = defaultdict(int)
    selected: list[Cluster] = []

    # FASE 1 -- garantia de presencia: nos llevamos el mejor candidato de
    # CADA tipo que tenga al menos un cluster, antes de competir por
    # relevancia global. Sin esto, un tipo raro pero real (2-3 clusters de
    # class_definition) nunca gana la comparacion directa contra miles de
    # if_statement/lambda con soporte en cientos, y desaparece del top-N
    # aunque exista y tenga cuota libre.
    for t in list(remaining.keys()):
        if remaining[t] and len(selected) < top:
            selected.append(remaining[t].pop(0))
            counts[t] += 1

    # FASE 1b -- garantia reforzada para clusters skeleton: seguimos
    # sacando el siguiente mejor candidato SOLO de entre clusters
    # is_skeleton (de cualquier tipo: funcion, clase, decorada...) hasta
    # llegar a min_guaranteed_skeleton en total, sin competir todavia
    # contra el resto de tipos.
    total_skeleton = sum(1 for c in selected if c.is_skeleton)
    tipos_skeleton = [t for t in remaining if remaining[t] and remaining[t][0].is_skeleton]
    while total_skeleton < min_guaranteed_skeleton and len(selected) < top:
        candidatos = [
            (relevance(remaining[t][0]), t)
            for t in tipos_skeleton
            if remaining[t] and remaining[t][0].is_skeleton and counts[t] < max_per_type
        ]
        if not candidatos:
            break
        candidatos.sort(reverse=True)
        _, t = candidatos[0]
        selected.append(remaining[t].pop(0))
        counts[t] += 1
        total_skeleton += 1

    # FASE 2 -- el resto del cupo se reparte por relevancia (soporte x
    # vocabulario de dominio), respetando el tope max_per_type por tipo.
    while len(selected) < top and any(remaining.values()):
        candidatos = [
            (relevance(remaining[t][0]), t)
            for t in remaining
            if remaining[t] and counts[t] < max_per_type
        ]
        if not candidatos:
            candidatos = [(relevance(remaining[t][0]), t) for t in remaining if remaining[t]]
            if not candidatos:
                break
        candidatos.sort(key=lambda x: -x[0])
        _, t = candidatos[0]
        selected.append(remaining[t].pop(0))
        counts[t] += 1

    return selected
