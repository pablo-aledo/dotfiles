"""
Dado un Cluster (varias instancias con la misma 'forma' estructural),
genera una plantilla de snippet parametrizada:

- Se usa la primera instancia como base para el texto/formato.
- Se recorren las hojas de TODAS las instancias en paralelo (misma
  posicion estructural = mismo indice en la lista de hojas, porque la
  forma es identica por construccion).
- En cada posicion de identificador/literal: si el texto es igual en
  todas las instancias -> se deja fijo. Si varia -> se convierte en un
  placeholder numerado ${n:texto_de_ejemplo}, reutilizando el numero si
  el mismo texto de la instancia base ya aparecio antes en esta unidad
  (para que 'i' se sustituya siempre por el mismo placeholder dentro de
  un mismo snippet, por ejemplo).
- El texto entre hojas (espacios, indentacion, saltos de linea) se copia
  tal cual de la instancia base, para conservar el formato original.
"""
from .shape import leaves


def _escape(text: str) -> str:
    # snipMate usa $ y llaves para placeholders; escapamos los que
    # pudieran aparecer en el texto de ejemplo.
    return text.replace("$", r"\$").replace("}", r"\}")


def build_template(cluster, cfg) -> str | None:
    instances = cluster.units
    base = instances[0]
    base_leaves = leaves(base.node)

    other_leaf_lists = []
    for inst in instances[1:]:
        ls = leaves(inst.node)
        if len(ls) != len(base_leaves):
            # estructura no encaja perfectamente (no deberia pasar si el
            # hash de forma es correcto, pero nos protegemos igualmente)
            continue
        other_leaf_lists.append((inst, ls))

    # exigimos que sobrevivan suficientes instancias tras el filtro
    if len(other_leaf_lists) + 1 < 2:
        return None

    placeholder_num = {}   # texto_base -> numero de placeholder ya asignado
    next_num = 1

    out = []
    cursor = base.start_byte
    base_src = base.source

    for i, leaf in enumerate(base_leaves):
        # texto entre la hoja anterior y esta (espacios/indentacion), tal cual
        out.append(base_src[cursor:leaf.start_byte].decode("utf-8", errors="replace"))

        base_text = base_src[leaf.start_byte:leaf.end_byte].decode("utf-8", errors="replace")

        is_placeholder_type = (leaf.type in cfg["identifier_types"]) or (leaf.type in cfg["literal_types"])

        if not is_placeholder_type:
            out.append(base_text)
            cursor = leaf.end_byte
            continue

        # comparar con el mismo indice de hoja en las demas instancias
        varia = False
        for inst, ls in other_leaf_lists:
            otro_texto = inst.source[ls[i].start_byte:ls[i].end_byte].decode("utf-8", errors="replace")
            if otro_texto != base_text:
                varia = True
                break

        if not varia:
            out.append(base_text)
        else:
            if base_text not in placeholder_num:
                placeholder_num[base_text] = next_num
                next_num += 1
            num = placeholder_num[base_text]
            out.append(f"${{{num}:{_escape(base_text)}}}")

        cursor = leaf.end_byte

    out.append(base_src[cursor:base.end_byte].decode("utf-8", errors="replace"))
    plantilla = "".join(out)

    if next_num == 1:
        # nada parametrizado -> añadimos tabstop final para que sea un
        # snippet valido y utilizable igualmente
        plantilla += "${0}"
    else:
        plantilla += "${0}"

    return plantilla
