"""
Dado un Cluster (varias instancias con la misma 'forma' estructural),
genera una plantilla de snippet parametrizada:

- Se usa la primera instancia como base para el texto/formato.
- Se recorren las hojas de TODAS las instancias en paralelo (misma
  posicion estructural = mismo indice en la lista de hojas, porque la
  forma es identica por construccion).
- En cada posicion de identificador/literal: si el texto es igual en
  todas las instancias -> se deja fijo. Si varia -> se convierte en un
  placeholder numerado ${n:texto_de_ejemplo}, reutilizando el numero si
  el mismo texto de la instancia base ya aparecio antes en esta unidad
  (para que 'i' se sustituya siempre por el mismo placeholder dentro de
  un mismo snippet, por ejemplo).
- El texto entre hojas (espacios, indentacion, saltos de linea) se copia
  tal cual de la instancia base, para conservar el formato original.
"""
from .shape import leaves, token_count


def _escape(text: str) -> str:
    # snipMate usa $ y llaves para placeholders; escapamos los que
    # pudieran aparecer en el texto de ejemplo.
    return text.replace("$", r"\$").replace("}", r"\}")


def build_template(cluster, cfg) -> str | None:
    instances = cluster.units
    base = instances[0]
    base_leaves = leaves(base.node)

    other_leaf_lists = []
    for inst in instances[1:]:
        ls = leaves(inst.node)
        if len(ls) != len(base_leaves):
            # estructura no encaja perfectamente (no deberia pasar si el
            # hash de forma es correcto, pero nos protegemos igualmente)
            continue
        other_leaf_lists.append((inst, ls))

    # exigimos que sobrevivan suficientes instancias tras el filtro
    if len(other_leaf_lists) + 1 < 2:
        return None

    placeholder_num = {}   # texto_base -> numero de placeholder ya asignado
    next_num = 1

    out = []
    cursor = base.start_byte
    base_src = base.source

    for i, leaf in enumerate(base_leaves):
        # texto entre la hoja anterior y esta (espacios/indentacion), tal cual
        out.append(base_src[cursor:leaf.start_byte].decode("utf-8", errors="replace"))

        base_text = base_src[leaf.start_byte:leaf.end_byte].decode("utf-8", errors="replace")

        is_placeholder_type = (leaf.type in cfg["identifier_types"]) or (leaf.type in cfg["literal_types"])

        if not is_placeholder_type:
            out.append(base_text)
            cursor = leaf.end_byte
            continue

        # comparar con el mismo indice de hoja en las demas instancias
        varia = False
        for inst, ls in other_leaf_lists:
            otro_texto = inst.source[ls[i].start_byte:ls[i].end_byte].decode("utf-8", errors="replace")
            if otro_texto != base_text:
                varia = True
                break

        if not varia:
            out.append(base_text)
        else:
            if base_text not in placeholder_num:
                placeholder_num[base_text] = next_num
                next_num += 1
            num = placeholder_num[base_text]
            out.append(f"${{{num}:{_escape(base_text)}}}")

        cursor = leaf.end_byte

    out.append(base_src[cursor:base.end_byte].decode("utf-8", errors="replace"))
    plantilla = "".join(out)

    if next_num == 1:
        # nada parametrizado -> añadimos tabstop final para que sea un
        # snippet valido y utilizable igualmente
        plantilla += "${0}"
    else:
        plantilla += "${0}"

    return plantilla


def _child_of_type(node, types):
    for c in node.children:
        if c.type in types:
            return c
    return None


def build_skeleton_template(cluster, cfg) -> str | None:
    """Renderer para clusters skeleton (function/class/decorated
    "borrosos"): a diferencia de build_template, las instancias del
    cluster NO tienen la misma cantidad de hojas (solo comparten la
    arquitectura general -- misma secuencia de tipos de statement, mismos
    dunders, mismos decoradores no genericos...), asi que no podemos
    diffear hoja a hoja.

    En su lugar: elegimos la instancia de tamaño MEDIANO como ejemplo
    representativo (ni la mas trivial ni un monstruo de 300 lineas), y
    parametrizamos unicamente lo que sabemos con certeza que es
    especifico de esa instancia -- el nombre de la funcion/clase y sus
    parametros (excepto self/cls) -- dejando el resto del cuerpo literal,
    tal cual aparece en el repositorio. Es el unico renderer razonable
    aqui: inventar una alineacion hoja a hoja entre cuerpos de longitud
    distinta produciria placeholders sin sentido.
    """
    instances = sorted(cluster.units, key=token_count)
    base = instances[len(instances) // 2]
    node = base.node
    if node.type == "decorated_definition":
        inner = _child_of_type(node, {"function_definition", "class_definition"})
    else:
        inner = node
    if inner is None:
        return None

    placeholder_spans = []  # (start_byte, end_byte, label)
    if inner.type == "function_definition":
        name_node = _child_of_type(inner, {"identifier"})
        if name_node is not None:
            placeholder_spans.append((name_node.start_byte, name_node.end_byte, "nombre"))
        params_node = _child_of_type(inner, {"parameters"})
        if params_node is not None:
            for c in params_node.children:
                if c.type == "identifier":
                    text = base.source[c.start_byte:c.end_byte].decode("utf-8", errors="replace")
                    if text not in ("self", "cls"):
                        placeholder_spans.append((c.start_byte, c.end_byte, text))
                elif c.type in ("typed_parameter", "default_parameter", "typed_default_parameter"):
                    g = _child_of_type(c, {"identifier"})
                    if g is not None:
                        text = base.source[g.start_byte:g.end_byte].decode("utf-8", errors="replace")
                        placeholder_spans.append((g.start_byte, g.end_byte, text))
    elif inner.type == "class_definition":
        name_node = _child_of_type(inner, {"identifier"})
        if name_node is not None:
            placeholder_spans.append((name_node.start_byte, name_node.end_byte, "nombre"))

    placeholder_spans.sort(key=lambda t: t[0])

    out = []
    cursor = base.start_byte
    num = 1
    for start, end, label in placeholder_spans:
        out.append(base.source[cursor:start].decode("utf-8", errors="replace"))
        text = base.source[start:end].decode("utf-8", errors="replace")
        out.append(f"${{{num}:{_escape(text)}}}")
        num += 1
        cursor = end
    out.append(base.source[cursor:base.end_byte].decode("utf-8", errors="replace"))
    out.append("${0}")
    return "".join(out)
