// @generated

pub mod sentencepiece_model;
