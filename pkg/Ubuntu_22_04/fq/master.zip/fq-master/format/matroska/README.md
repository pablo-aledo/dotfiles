Generated code is based on ebml_matroska.xml from http://ietf-wg-cellar.github.io/matroska-specification/

It's licensed under the Creative Commons Attribution 4.0 International (CC BY 4.0). See http://ietf-wg-cellar.github.io/matroska-specification/LICENSE.html