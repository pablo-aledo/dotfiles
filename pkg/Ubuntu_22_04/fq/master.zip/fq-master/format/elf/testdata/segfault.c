void main()
{
    (*(int *)0) = 0;
}