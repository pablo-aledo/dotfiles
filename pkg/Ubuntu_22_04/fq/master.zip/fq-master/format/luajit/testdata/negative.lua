f1 = function(x)
	return x * -2973289
end

f2 = function(x)
	return x * -38793457897
end
