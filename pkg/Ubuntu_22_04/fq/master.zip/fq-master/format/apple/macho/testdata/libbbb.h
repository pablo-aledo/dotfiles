void libbbb_bbb();
