#include <stdio.h>
#include "libbbb.h"

void aaa()
{
    printf("aaa\n");
}

int main()
{
    aaa();
    libbbb_bbb();
}
