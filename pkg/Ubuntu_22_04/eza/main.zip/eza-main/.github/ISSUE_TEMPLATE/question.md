---
name: Question
about: Ask a question about eza
title: ''
labels: question
assignees: ''

---

This should be posted in Q&A in discussions
