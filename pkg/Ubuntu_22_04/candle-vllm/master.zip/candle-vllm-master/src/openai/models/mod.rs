use std::fmt;
pub mod deepseek;
pub mod gemma;
pub mod gemma3;
pub mod gemma3_vl;
pub mod gemma4;
pub mod glm4;
pub mod glm4_moe_lite;
pub mod layers;
pub mod linear;
pub mod llama;
pub mod llama4;
pub mod minimax;
pub mod mistral;
pub mod mistral3_vl;
pub mod phi2;
pub mod phi4;
pub mod quantized_deepseek;
pub mod quantized_glm4;
pub mod quantized_llama;
pub mod quantized_phi3;
pub mod quantized_qwen;
pub mod quantized_qwen3_5;
pub mod quantized_qwen3_5_moe;
pub mod quantized_qwen3_moe;
pub mod qwen;
pub mod qwen3_5;
pub mod qwen3_5_moe;
pub mod qwen3_moe;
pub mod qwen3_vl;
pub mod stable_lm;
pub mod utils;
pub mod yi;
use crate::openai::distributed::Comm;
use crate::{InputMetadata, PagedAttention};
use candle_core::{Device, Result, Tensor};
use either::Either;
pub use layers::{attention, mask, mlp, rotary_emb};
use serde::Deserialize;
use std::cell::RefCell;
use std::collections::HashMap;
use std::path::PathBuf;
use std::rc::Rc;

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum KvCacheDtype {
    Auto,
    Fp8,
    Turbo8,
    Turbo4,
    Turbo3,
}

static GLOBAL_KVCACHE_DTYPE: std::sync::atomic::AtomicU8 = std::sync::atomic::AtomicU8::new(0);

impl KvCacheDtype {
    pub fn is_turboquant(&self) -> bool {
        matches!(self, Self::Turbo8 | Self::Turbo4 | Self::Turbo3)
    }

    pub fn is_fp8_keys(&self) -> bool {
        matches!(self, Self::Fp8 | Self::Turbo8)
    }

    pub fn from_str_opt(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "auto" | "bf16" | "bfloat16" => Some(Self::Auto),
            "fp8" | "e4m3" => Some(Self::Fp8),
            "turbo8" | "k8v4" => Some(Self::Turbo8),
            "turbo4" | "4bit" => Some(Self::Turbo4),
            "turbo3" | "k3v4" => Some(Self::Turbo3),
            _ => None,
        }
    }

    fn to_u8(self) -> u8 {
        match self {
            Self::Auto => 0,
            Self::Fp8 => 1,
            Self::Turbo8 => 2,
            Self::Turbo4 => 3,
            Self::Turbo3 => 4,
        }
    }

    fn from_u8(v: u8) -> Self {
        match v {
            1 => Self::Fp8,
            2 => Self::Turbo8,
            3 => Self::Turbo4,
            4 => Self::Turbo3,
            _ => Self::Auto,
        }
    }

    pub fn set_global(dtype: Self) {
        GLOBAL_KVCACHE_DTYPE.store(dtype.to_u8(), std::sync::atomic::Ordering::SeqCst);
    }

    pub fn get_global() -> Self {
        Self::from_u8(GLOBAL_KVCACHE_DTYPE.load(std::sync::atomic::Ordering::SeqCst))
    }
}

impl Default for KvCacheDtype {
    fn default() -> Self {
        Self::Auto
    }
}

impl std::fmt::Display for KvCacheDtype {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Auto => write!(f, "auto"),
            Self::Fp8 => write!(f, "fp8"),
            Self::Turbo8 => write!(f, "turbo8"),
            Self::Turbo4 => write!(f, "turbo4"),
            Self::Turbo3 => write!(f, "turbo3"),
        }
    }
}

#[derive(Deserialize, Debug, Clone)]
#[serde(untagged)]
pub enum ScalingValue {
    Single(f64),
    Vec(Vec<f64>),
    String(String),
    Bool(bool),
}

#[derive(Deserialize, Debug, Clone)]
pub struct TokenID(
    #[serde(with = "either::serde_untagged")] pub Either<Option<u32>, Option<Vec<u32>>>,
);

/// Match a module path against an ignore pattern.
/// Supports three pattern types:
///   - `re:` prefix -> regex match
///   - Contains `*` -> glob match (converted to regex: `*` becomes `.*`)
///   - Otherwise -> literal suffix matching
pub fn match_ignore_pattern(module_path: &str, pattern: &str) -> bool {
    if let Some(re_pat) = pattern.strip_prefix("re:") {
        if let Ok(re) = regex::Regex::new(re_pat) {
            return re.is_match(module_path);
        }
        return false;
    }
    if pattern.contains('*') {
        let re_pat = format!("^{}$", regex::escape(pattern).replace(r"\*", ".*"));
        if let Ok(re) = regex::Regex::new(&re_pat) {
            return re.is_match(module_path);
        }
        return false;
    }
    let module_path = module_path.trim_end_matches(".weight");
    let item = pattern.trim_end_matches(".weight");
    module_path == item
        || module_path.ends_with(item)
        || module_path.ends_with(&format!(".{item}"))
        || item.ends_with(module_path)
        || item.ends_with(&format!(".{module_path}"))
}

#[derive(Deserialize, PartialEq, Clone)]
pub struct QuantConfig {
    #[serde(default)]
    pub quant_method: String,
    #[serde(default)]
    pub activation_scheme: Option<String>,
    #[serde(default)]
    pub weight_per_tensor: Option<bool>,
    #[serde(default)]
    pub act_per_tensor: Option<bool>,
    #[serde(default)]
    pub modules_to_not_convert: Option<Vec<String>>,
    #[serde(default)]
    pub bits: usize,
    #[serde(default)]
    pub group_size: i32,
    pub sym: Option<bool>,
    pub desc_act: Option<bool>,
    pub checkpoint_format: Option<String>,
    pub weight_block_size: Option<Vec<usize>>,
    #[serde(default)]
    pub format: Option<String>,
    #[serde(default)]
    pub config_groups: Option<serde_json::Value>,
    #[serde(default)]
    pub quant_algo: Option<String>,
    #[serde(default)]
    pub mode: Option<String>,
    #[serde(default)]
    pub ignore: Option<Vec<String>>,
    /// MLX NVFP4 stores eight FP4 values in each U32 weight element and uses
    /// FP8 E4M3 block scales. This is distinct from native U8-packed NVFP4.
    #[serde(default)]
    pub is_mlx_nvfp4: bool,
}

impl QuantConfig {
    pub fn normalize_compressed_tensors(&mut self) {
        if let Some(ignore_list) = self.ignore.take() {
            let mods = self.modules_to_not_convert.get_or_insert_with(Vec::new);
            for item in ignore_list {
                if !mods.contains(&item) {
                    mods.push(item);
                }
            }
        }

        // MLX exports use the compact {bits, group_size, mode} schema rather
        // than a quant_method/format field. Keep this marker so loaders can
        // select the U32 -> U8 repack path without affecting native NVFP4.
        if self.quant_method.is_empty() {
            if let Some(mode) = &self.mode {
                if mode.eq_ignore_ascii_case("nvfp4") {
                    self.quant_method = "nvfp4".to_string();
                    self.is_mlx_nvfp4 = true;
                    if self.group_size == 0 {
                        self.group_size = 16;
                    }
                    if self.bits == 0 {
                        self.bits = 4;
                    }
                    return;
                }
            }
        }

        if self.quant_method == "modelopt" {
            if let Some(algo) = &self.quant_algo {
                if algo.eq_ignore_ascii_case("NVFP4") || algo.eq_ignore_ascii_case("FP4") {
                    self.quant_method = "nvfp4".to_string();
                    self.extract_compressed_tensors_params();
                    if self.group_size == 0 {
                        self.group_size = 16;
                    }
                    if self.bits == 0 {
                        self.bits = 4;
                    }
                    return;
                }
            }
            if self.detect_nvfp4_from_config_groups() {
                self.quant_method = "nvfp4".to_string();
                self.extract_compressed_tensors_params();
                if self.group_size == 0 {
                    self.group_size = 16;
                }
                if self.bits == 0 {
                    self.bits = 4;
                }
                return;
            }
        }

        if self.quant_method != "compressed-tensors" {
            return;
        }

        let format_str = self.format.as_deref().unwrap_or("");

        let is_nvfp4 = format_str.contains("nvfp4") || self.detect_nvfp4_from_config_groups();

        if is_nvfp4 {
            self.quant_method = "nvfp4".to_string();
            self.extract_compressed_tensors_params();
            if self.group_size == 0 {
                self.group_size = 16;
            }
            if self.bits == 0 {
                self.bits = 4;
            }
            return;
        }

        let is_mxfp4 = format_str.contains("mxfp4") || self.detect_mxfp4_from_config_groups();

        if is_mxfp4 {
            self.quant_method = "mxfp4".to_string();
            self.extract_compressed_tensors_params();
        }
    }

    fn detect_nvfp4_from_config_groups(&self) -> bool {
        let groups = match &self.config_groups {
            Some(v) => v,
            None => return false,
        };
        if let Some(obj) = groups.as_object() {
            for (_key, group) in obj {
                if let Some(fmt) = group.get("format").and_then(|v| v.as_str()) {
                    if fmt.contains("nvfp4") {
                        return true;
                    }
                }
                if let Some(weights) = group.get("weights") {
                    if let Some(fmt) = weights.get("format").and_then(|v| v.as_str()) {
                        if fmt.contains("nvfp4") {
                            return true;
                        }
                    }
                    if let Some(num_bits) = weights.get("num_bits").and_then(|v| v.as_u64()) {
                        if num_bits == 4 {
                            let is_float = weights
                                .get("type")
                                .and_then(|v| v.as_str())
                                .map(|t| t == "float")
                                .unwrap_or(false);
                            let gs = weights
                                .get("group_size")
                                .and_then(|v| v.as_u64())
                                .unwrap_or(0);
                            if is_float && gs == 16 {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        false
    }

    fn detect_mxfp4_from_config_groups(&self) -> bool {
        let groups = match &self.config_groups {
            Some(v) => v,
            None => return false,
        };
        if let Some(obj) = groups.as_object() {
            for (_key, group) in obj {
                if let Some(fmt) = group.get("format").and_then(|v| v.as_str()) {
                    if fmt.contains("mxfp4") {
                        return true;
                    }
                }
                if let Some(weights) = group.get("weights") {
                    if let Some(fmt) = weights.get("format").and_then(|v| v.as_str()) {
                        if fmt.contains("mxfp4") {
                            return true;
                        }
                    }
                }
            }
        }
        false
    }

    fn extract_compressed_tensors_params(&mut self) {
        let groups = match &self.config_groups {
            Some(v) => v.clone(),
            None => return,
        };
        if let Some(obj) = groups.as_object() {
            for (_key, group) in obj {
                if let Some(weights) = group.get("weights") {
                    if self.group_size == 0 {
                        if let Some(gs) = weights.get("group_size").and_then(|v| v.as_i64()) {
                            self.group_size = gs as i32;
                        }
                    }
                    if self.bits == 0 {
                        if let Some(nb) = weights.get("num_bits").and_then(|v| v.as_u64()) {
                            self.bits = nb as usize;
                        }
                    }
                }
            }
        }
    }

    pub fn should_skip_module(&self, module_path: &str) -> bool {
        if module_path.is_empty() {
            return false;
        }
        let skip_modules = match &self.modules_to_not_convert {
            Some(v) if !v.is_empty() => v,
            _ => return false,
        };
        skip_modules
            .iter()
            .any(|item| match_ignore_pattern(module_path, item))
    }
}

impl fmt::Debug for QuantConfig {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("QuantConfig")
            .field("quant_method", &self.quant_method)
            .field("activation_scheme", &self.activation_scheme)
            .field("weight_per_tensor", &self.weight_per_tensor)
            .field("act_per_tensor", &self.act_per_tensor)
            .field("bits", &self.bits)
            .field("group_size", &self.group_size)
            .field("sym", &self.sym)
            .field("desc_act", &self.desc_act)
            .field("checkpoint_format", &self.checkpoint_format)
            .field("format", &self.format)
            .field("weight_block_size", &self.weight_block_size)
            .field("modules_to_not_convert", &self.modules_to_not_convert)
            .field("is_mlx_nvfp4", &self.is_mlx_nvfp4)
            .finish()
    }
}

#[derive(Deserialize, Clone, Debug)]
pub enum TopkMethod {
    #[serde(rename = "noaux_tc")]
    NoAuxTc,
    #[serde(rename = "greedy")]
    Greedy,
    #[serde(rename = "group_limited_greedy")]
    GroupLimitedGreedy,
}

#[derive(Deserialize, Clone, Debug)]
pub enum ScoringFunc {
    #[serde(rename = "softmax")]
    Softmax,
    #[serde(rename = "sigmoid")]
    Sigmoid,
}

#[derive(Deserialize, Debug, Clone)]
pub struct DeepSeekMoEConfig {
    pub num_experts_per_tok: Option<usize>,
    pub n_routed_experts: usize,
    pub moe_intermediate_size: usize,
    pub scoring_func: ScoringFunc,
    pub topk_method: TopkMethod,
    pub norm_topk_prob: bool,
    pub routed_scaling_factor: f64,
    pub n_shared_experts: Option<usize>,
    pub qk_nope_head_dim: usize,
    pub qk_rope_head_dim: usize,
    pub v_head_dim: usize,
    pub kv_lora_rank: usize,
    pub first_k_dense_replace: usize,
    pub moe_layer_freq: usize,
    pub q_lora_rank: Option<usize>,
    pub rope_scaling: Option<DeepSeekRopeScaling>,
    pub n_group: usize,
    pub topk_group: usize,
    pub num_experts_offload_per_rank: Option<usize>,
}

#[derive(Deserialize, Debug, Clone)]
pub struct QwenMoEConfig {
    pub moe_intermediate_size: usize,
    pub shared_expert_intermediate_size: Option<usize>,
    #[serde(alias = "n_routed_experts", alias = "num_local_experts")]
    pub num_experts: Option<usize>,
    pub mlp_only_layers: Option<Vec<usize>>,
    pub decoder_sparse_step: Option<usize>,
    #[serde(default)]
    pub norm_topk_prob: bool,
    pub num_experts_per_tok: usize,
    pub routed_scaling_factor: Option<f64>,
    /// First layers use dense MLP; remaining layers use MoE (e.g. GLM4 MoE Lite).
    #[serde(default)]
    pub first_k_dense_replace: Option<usize>,
    #[serde(default)]
    pub n_shared_experts: Option<usize>,
    #[serde(default)]
    pub n_group: Option<usize>,
    #[serde(default)]
    pub topk_group: Option<usize>,
    #[serde(default)]
    pub scoring_func: Option<String>,
    #[serde(default)]
    pub topk_method: Option<String>,
}

#[derive(Deserialize, Debug, Clone)]
pub enum MoEConfig {
    DeepSeekMoE(DeepSeekMoEConfig),
    QwenMoE(QwenMoEConfig),
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ScaledRopeType {
    #[serde(alias = "su")]
    #[serde(alias = "longrope")]
    Su,
    #[serde(alias = "yarn")]
    Yarn,
    #[serde(alias = "dynamic")]
    Dynamic,
    #[serde(alias = "linear")]
    Linear,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(untagged)]
pub enum DeepSeekRopeScaling {
    Yarn {
        original_max_position_embeddings: usize,
        beta_fast: f32,
        beta_slow: f32,
        mscale: f32,
        mscale_all_dim: f32,
        factor: f32,
        #[serde(rename = "type")]
        scaling_type: ScaledRopeType,
    },
    LinearOrDynamic {
        #[serde(rename = "type")]
        scaling_type: ScaledRopeType,
        factor: f64,
    },
}

#[derive(Deserialize, Debug, Clone)]
pub struct ModelArch(
    #[serde(with = "either::serde_untagged")] pub Either<Option<String>, Option<Vec<String>>>,
);

#[derive(Deserialize, Debug, Clone)]
pub struct ModelArchConfig {
    pub architectures: Option<ModelArch>,
}

#[derive(Deserialize, Debug, Clone)]
struct MultiModalArchConfig {
    pub architectures: Option<Vec<String>>,
    pub text_config: Option<serde_json::Value>,
    pub vision_config: Option<serde_json::Value>,
}

#[doc(hidden)]
#[macro_export]
macro_rules! serde_default_cfg {
    ($t:ty, $name:ident, $v:expr) => {
        fn $name() -> $t {
            $v
        }
    };
}
serde_default_cfg!(usize, max_seq_len, 8192);
serde_default_cfg!(bool, tie_word_embeddings, false);
serde_default_cfg!(f64, rope_theta, 10_000.0f64);
serde_default_cfg!(bool, qk_layernorm, false);
serde_default_cfg!(usize, intermediate_size, 0);

#[derive(Deserialize, Debug, Clone)]
pub struct Config {
    pub architectures: Option<Vec<String>>,
    pub hidden_size: usize,
    pub head_dim: Option<usize>,
    #[serde(
        default = "intermediate_size",
        alias = "ffn_hidden_size",
        alias = "feed_forward_length"
    )]
    pub intermediate_size: usize,
    pub vocab_size: usize,
    pub num_hidden_layers: usize,
    pub num_attention_heads: usize,
    pub num_key_value_heads: Option<usize>,
    pub rms_norm_eps: f64,
    #[serde(default = "rope_theta")]
    pub rope_theta: f64,
    pub rope_local_base_freq: Option<f64>,
    pub bos_token_id: Option<TokenID>,
    pub eos_token_id: Option<TokenID>,
    #[serde(default = "max_seq_len")]
    pub max_seq_len: usize,
    pub original_max_position_embeddings: Option<usize>,
    pub sliding_window: Option<usize>,
    pub sliding_window_pattern: Option<usize>,
    pub hidden_act: Option<candle_nn::Activation>,
    pub hidden_activation: Option<candle_nn::Activation>,
    #[serde(default = "tie_word_embeddings")]
    pub tie_word_embeddings: bool,
    #[serde(alias = "rope_parameters")]
    pub rope_scaling: Option<HashMap<String, ScalingValue>>,
    pub max_position_embeddings: Option<usize>,
    pub attention_bias: Option<bool>,
    pub partial_rotary_factor: Option<f32>,
    #[serde(default = "qk_layernorm")]
    pub qk_layernorm: bool,
    #[serde(alias = "qkv_bias")]
    pub use_qkv_bias: Option<bool>,
    pub custom_stop_tokens: Option<Vec<String>>,
    pub attn_logit_softcapping: Option<f64>,
    pub final_logit_softcapping: Option<f64>,
    pub moe_config: Option<MoEConfig>,
    pub quantization_config: Option<QuantConfig>,
    pub isq_quant: Option<String>,
    #[serde(default)]
    pub kvcache_dtype: KvCacheDtype,
    pub extra_config_json: Option<String>,
    #[serde(default)]
    pub is_f16_mode: bool,
}

impl Config {
    pub fn derive_yarn_parameters(factor: f64) -> (f64, f64, f64, f64) {
        let factor = factor.max(1.0);

        let beta_fast = if factor <= 4.0 {
            32.0
        } else {
            32.0 * (factor / 4.0).sqrt()
        };
        let beta_slow = 1.0;
        let extrapolation_factor = if factor > 8.0 {
            1.0 + 0.05 * (factor - 8.0).sqrt()
        } else {
            1.0
        };
        let attn_factor = 1.0;

        (beta_fast, beta_slow, extrapolation_factor, attn_factor)
    }

    fn base_max_position_embeddings(&self) -> usize {
        self.max_position_embeddings.unwrap_or(self.max_seq_len)
    }

    pub fn apply_static_rope_scaling(
        yarn_scaling_factor: Option<f64>,
        max_position_embeddings: usize,
    ) -> Option<HashMap<String, ScalingValue>> {
        if let Some(factor) = yarn_scaling_factor {
            let (beta_fast, beta_slow, extrapolation_factor, attn_factor) =
                Self::derive_yarn_parameters(factor);

            return Some(HashMap::from([
                (
                    "rope_type".to_string(),
                    ScalingValue::String("yarn".to_string()),
                ),
                ("factor".to_string(), ScalingValue::Single(factor)),
                (
                    "original_max_position_embeddings".to_string(),
                    ScalingValue::Single(max_position_embeddings as f64),
                ),
                ("beta_fast".to_string(), ScalingValue::Single(beta_fast)),
                ("beta_slow".to_string(), ScalingValue::Single(beta_slow)),
                (
                    "extrapolation_factor".to_string(),
                    ScalingValue::Single(extrapolation_factor),
                ),
                ("attn_factor".to_string(), ScalingValue::Single(attn_factor)),
            ]));
        }

        None
    }

    pub fn higher_precision_required(&self) -> bool {
        self.is_f16_mode
            || self.isq_quant.is_some()
            || self
                .quantization_config
                .as_ref()
                .is_some_and(|cfg| matches!(cfg.quant_method.as_str(), "mxfp4" | "nvfp4"))
    }

    pub fn effective_max_seq_len(&self) -> usize {
        let base_max_position_embeddings = self.base_max_position_embeddings();
        let Some(rope_scaling) = &self.rope_scaling else {
            return base_max_position_embeddings;
        };

        let rope_type = rope_scaling
            .get("rope_type")
            .or_else(|| rope_scaling.get("type"))
            .and_then(|value| match value {
                ScalingValue::String(value) => Some(value.as_str()),
                _ => None,
            });
        let factor = rope_scaling.get("factor").and_then(|value| match value {
            ScalingValue::Single(value) => Some(*value),
            _ => None,
        });
        let original_max_position_embeddings = rope_scaling
            .get("original_max_position_embeddings")
            .and_then(|value| match value {
                ScalingValue::Single(value) => Some(*value),
                _ => None,
            })
            .or_else(|| {
                self.original_max_position_embeddings
                    .map(|value| value as f64)
            });

        match (rope_type, factor, original_max_position_embeddings) {
            (Some("yarn"), Some(factor), Some(original_max_position_embeddings))
                if factor > 1.0 =>
            {
                std::cmp::max(
                    base_max_position_embeddings,
                    (original_max_position_embeddings * factor).round() as usize,
                )
            }
            _ => base_max_position_embeddings,
        }
    }

    pub fn apply_runtime_rope_overrides(&mut self, yarn_scaling_factor: Option<f64>) {
        if let Some(scaling) = Self::apply_static_rope_scaling(
            yarn_scaling_factor,
            self.base_max_position_embeddings(),
        ) {
            self.rope_scaling = Some(scaling);
        }

        self.apply_rope_overrides();
        self.max_seq_len = self.effective_max_seq_len();
    }

    fn apply_rope_overrides(&mut self) {
        if let Some(scaling) = &self.rope_scaling {
            if let Some(ScalingValue::Single(v)) = scaling.get("rope_theta") {
                self.rope_theta = *v;
            }
            if let Some(ScalingValue::Single(v)) = scaling.get("partial_rotary_factor") {
                self.partial_rotary_factor = Some(*v as f32);
            }
            if let Some(ScalingValue::Single(v)) = scaling.get("original_max_position_embeddings") {
                self.original_max_position_embeddings = Some(*v as usize);
            }
        }
        if let Some(raw) = self.extra_config_json.as_ref() {
            if let Ok(root) = serde_json::from_str::<serde_json::Value>(raw) {
                let cfg_root = root.get("text_config").unwrap_or(&root);
                if let Some(rope_params) = cfg_root
                    .get("rope_parameters")
                    .or_else(|| cfg_root.get("rope_scaling"))
                {
                    if let Some(v) = rope_params.get("rope_theta").and_then(|v| v.as_f64()) {
                        self.rope_theta = v;
                    }
                    if let Some(v) = rope_params
                        .get("partial_rotary_factor")
                        .and_then(|v| v.as_f64())
                    {
                        self.partial_rotary_factor = Some(v as f32);
                    }
                    if let Some(v) = rope_params
                        .get("original_max_position_embeddings")
                        .and_then(|v| v.as_u64())
                    {
                        self.original_max_position_embeddings = Some(v as usize);
                    }
                }
            }
        }
    }

    pub fn load_config(filename: PathBuf) -> Result<Config> {
        match std::fs::read(filename.clone()) {
            Ok(f) => {
                let raw = String::from_utf8(f.clone()).map_err(candle_core::Error::wrap)?;
                let top_level_quant_config = serde_json::from_slice::<serde_json::Value>(&f)
                    .ok()
                    .and_then(|root| root.get("quantization_config").cloned())
                    .and_then(|v| serde_json::from_value::<QuantConfig>(v).ok())
                    .map(|mut qcfg| {
                        qcfg.normalize_compressed_tensors();
                        qcfg
                    });
                let mut config: Config =
                    if let Ok(mm_cfg) = serde_json::from_slice::<MultiModalArchConfig>(&f) {
                        if mm_cfg.text_config.is_some() && mm_cfg.vision_config.is_some() {
                            let mut cfg: Config =
                                serde_json::from_value(mm_cfg.text_config.clone().unwrap())
                                    .map_err(candle_core::Error::wrap)?;
                            cfg.architectures = mm_cfg.architectures.clone().or(cfg.architectures);
                            // For multimodal configs, quantization_config (including modules_to_not_convert)
                            // is usually defined at top level rather than under text_config.
                            if let Some(qcfg) = top_level_quant_config.clone() {
                                cfg.quantization_config = Some(qcfg);
                            }
                            cfg
                        } else {
                            match serde_json::from_slice::<Config>(&f) {
                                Ok(cfg) => cfg,
                                Err(root_err) => {
                                    if let Some(text_cfg) = mm_cfg.text_config {
                                        let mut cfg: Config = serde_json::from_value(text_cfg)
                                            .map_err(candle_core::Error::wrap)?;
                                        cfg.architectures =
                                            mm_cfg.architectures.clone().or(cfg.architectures);
                                        if let Some(qcfg) = top_level_quant_config.clone() {
                                            cfg.quantization_config = Some(qcfg);
                                        }
                                        cfg
                                    } else {
                                        return Err(candle_core::Error::wrap(root_err));
                                    }
                                }
                            }
                        }
                    } else {
                        serde_json::from_slice(&f).map_err(candle_core::Error::wrap)?
                    };
                config.extra_config_json = Some(raw);
                config.apply_rope_overrides();
                config.max_seq_len = config.effective_max_seq_len();
                Ok(config)
            }
            Err(e) => panic!(
                "Unable to load config file {:?}\n ***Tips: use `--f` to specify GGUF file path!",
                e
            ),
        }
    }

    pub fn get_model_arch(filename: &PathBuf) -> Result<String> {
        match std::fs::read(filename) {
            Ok(f) => {
                let arch_config: ModelArchConfig =
                    serde_json::from_slice(&f).map_err(candle_core::Error::wrap)?;
                match arch_config.architectures {
                    Some(ModelArch(Either::Left(Some(arch)))) => Ok(arch),
                    Some(ModelArch(Either::Right(Some(archs)))) => {
                        if archs.len() > 1 {
                            candle_core::bail!("Multiple architectures found in config file {:?}, which is not supported!", archs);
                        } else if archs.is_empty() {
                            candle_core::bail!("No architectures found in config file {:?}!", filename);
                        }
                        Ok(archs[0].clone())
                    }
                    _=> {
                        candle_core::bail!(
                            "No architectures found in config file {:?}!",
                            filename
                        );
                    }
                }
            }
            Err(e) => panic!(
                "Unable to get model arch from config file {:?}\n ***Tips: use `--f` to specify GGUF file path!",
                e
            ),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{Config, ScalingValue};
    use std::collections::HashMap;

    fn test_config(max_position_embeddings: usize) -> Config {
        Config {
            architectures: Some(vec!["Qwen2ForCausalLM".to_string()]),
            hidden_size: 4096,
            head_dim: Some(128),
            intermediate_size: 11008,
            vocab_size: 151936,
            num_hidden_layers: 32,
            num_attention_heads: 32,
            num_key_value_heads: Some(32),
            rms_norm_eps: 1e-5,
            rope_theta: 10000.0,
            rope_local_base_freq: None,
            bos_token_id: None,
            eos_token_id: None,
            max_seq_len: max_position_embeddings,
            original_max_position_embeddings: None,
            sliding_window: None,
            sliding_window_pattern: None,
            hidden_act: None,
            hidden_activation: None,
            tie_word_embeddings: false,
            rope_scaling: None,
            max_position_embeddings: Some(max_position_embeddings),
            attention_bias: None,
            partial_rotary_factor: None,
            qk_layernorm: false,
            use_qkv_bias: None,
            custom_stop_tokens: None,
            attn_logit_softcapping: None,
            final_logit_softcapping: None,
            moe_config: None,
            quantization_config: None,
            isq_quant: None,
            kvcache_dtype: KvCacheDtype::Auto,
            extra_config_json: None,
        }
    }

    #[test]
    fn test_effective_max_seq_len_scales_yarn_context() {
        let mut config = test_config(262_144);
        config.rope_scaling = Some(HashMap::from([
            (
                "rope_type".to_string(),
                ScalingValue::String("yarn".to_string()),
            ),
            ("factor".to_string(), ScalingValue::Single(4.0)),
            (
                "original_max_position_embeddings".to_string(),
                ScalingValue::Single(262_144.0),
            ),
        ]));

        assert_eq!(config.effective_max_seq_len(), 1_048_576);
    }

    #[test]
    fn test_apply_runtime_rope_overrides_updates_effective_max_seq_len() {
        let mut config = test_config(262_144);
        config.apply_runtime_rope_overrides(Some(8.0));

        assert_eq!(config.max_position_embeddings, Some(262_144));
        assert_eq!(config.original_max_position_embeddings, Some(262_144));
        assert_eq!(config.max_seq_len, 2_097_152);
    }
}

#[derive(Debug, Clone, Default, Deserialize)]
pub struct Qwen3HybridRawConfig {
    #[serde(alias = "layer_types")]
    pub layers_block_type: Option<Vec<String>>,
    #[serde(alias = "linear_conv_kernel_dim")]
    pub conv_kernel_size: Option<usize>,
    pub full_attention_interval: Option<usize>,
    pub linear_num_heads: Option<usize>,
    #[serde(alias = "linear_num_key_heads")]
    pub linear_num_key_heads: Option<usize>,
    #[serde(alias = "linear_num_value_heads")]
    pub linear_num_value_heads: Option<usize>,
    pub linear_num_key_value_heads: Option<usize>,
    pub linear_key_head_dim: Option<usize>,
    pub linear_value_head_dim: Option<usize>,
}

#[derive(Debug, Clone)]
pub struct Qwen3HybridConfig {
    pub layer_types: Vec<String>,
    pub conv_kernel_size: usize,
    pub num_v_heads: usize,
    pub num_k_heads: usize,
    pub key_head_dim: usize,
    pub value_head_dim: usize,
}

pub fn is_qwen3_hybrid_arch_name(arch: &str) -> bool {
    matches!(
        arch,
        "Qwen3_5ForCausalLM"
            | "Qwen3_5MoeForCausalLM"
            | "Qwen3NextForCausalLM"
            | "Qwen3_5ForConditionalGeneration"
            | "Qwen3_5MoeForConditionalGeneration"
            | "Qwen3NextForConditionalGeneration"
    )
}

fn is_qwen3_hybrid_arch(config: &Config) -> bool {
    let arch = config.architectures.as_ref().and_then(|a| a.first());
    arch.map(|a| is_qwen3_hybrid_arch_name(a)).unwrap_or(false)
}

fn qwen3_hybrid_raw_from_extra_config(config: &Config) -> Option<Qwen3HybridRawConfig> {
    if !is_qwen3_hybrid_arch(config) {
        return None;
    }
    let extra = config.extra_config_json.as_ref()?;
    let root = serde_json::from_str::<serde_json::Value>(extra).ok()?;
    let cfg = root.get("text_config").cloned().unwrap_or(root);
    serde_json::from_value::<Qwen3HybridRawConfig>(cfg).ok()
}

pub fn resolve_qwen3_hybrid_config(config: &Config) -> Qwen3HybridConfig {
    let raw_cfg = qwen3_hybrid_raw_from_extra_config(config).unwrap_or_default();

    let mut layer_types = if let Some(layer_types) = raw_cfg.layers_block_type {
        layer_types
    } else if let Some(interval) = raw_cfg.full_attention_interval {
        if interval > 0 {
            (0..config.num_hidden_layers)
                .map(|idx| {
                    if (idx + 1) % interval == 0 {
                        "full_attention".to_string()
                    } else {
                        "linear_attention".to_string()
                    }
                })
                .collect::<Vec<_>>()
        } else {
            vec!["full_attention".to_string(); config.num_hidden_layers]
        }
    } else {
        vec!["full_attention".to_string(); config.num_hidden_layers]
    };

    for layer_type in layer_types.iter_mut() {
        if layer_type == "attention" {
            *layer_type = "full_attention".to_string();
        }
    }
    if layer_types.len() != config.num_hidden_layers {
        tracing::warn!(
            "Qwen3 hybrid layer_types length {} != num_hidden_layers {}, fallback to full_attention.",
            layer_types.len(),
            config.num_hidden_layers
        );
        layer_types = vec!["full_attention".to_string(); config.num_hidden_layers];
    }

    let num_v_heads = raw_cfg
        .linear_num_value_heads
        .or(raw_cfg.linear_num_heads)
        .unwrap_or(config.num_attention_heads);
    let num_k_heads = raw_cfg
        .linear_num_key_heads
        .or(raw_cfg.linear_num_key_value_heads)
        .unwrap_or(num_v_heads);
    let key_head_dim = raw_cfg.linear_key_head_dim.unwrap_or(
        config
            .head_dim
            .unwrap_or(config.hidden_size / config.num_attention_heads),
    );
    let value_head_dim = raw_cfg.linear_value_head_dim.unwrap_or(key_head_dim);
    let conv_kernel_size = raw_cfg.conv_kernel_size.unwrap_or(4);

    Qwen3HybridConfig {
        layer_types,
        conv_kernel_size,
        num_v_heads,
        num_k_heads,
        key_head_dim,
        value_head_dim,
    }
}

pub fn qwen3_hybrid_layer_types(config: &Config) -> Option<Vec<String>> {
    if !is_qwen3_hybrid_arch(config) {
        return None;
    }
    Some(resolve_qwen3_hybrid_config(config).layer_types)
}

impl Config {
    pub fn kv_cache_num_layers(&self) -> usize {
        if let Some(layer_types) = qwen3_hybrid_layer_types(self) {
            return layer_types
                .iter()
                .filter(|lt| lt.as_str() == "full_attention")
                .count();
        }
        self.num_hidden_layers
    }

    pub fn get_head_size(&self) -> usize {
        self.head_dim
            .unwrap_or(self.hidden_size / self.num_attention_heads)
    }

    pub fn q_head_dim(&self) -> usize {
        match &self.moe_config {
            Some(MoEConfig::DeepSeekMoE(cfg)) => cfg.qk_rope_head_dim + cfg.qk_nope_head_dim,
            _ => self.get_head_size(),
        }
    }

    pub fn k_head_dim(&self) -> usize {
        match &self.moe_config {
            Some(MoEConfig::DeepSeekMoE(cfg)) => {
                //q_head_dim
                cfg.qk_rope_head_dim + cfg.qk_nope_head_dim
            }
            _ => self.get_head_size(),
        }
    }

    pub fn v_head_dim(&self) -> usize {
        match &self.moe_config {
            Some(MoEConfig::DeepSeekMoE(cfg)) => {
                //q_head_dim
                cfg.qk_rope_head_dim + cfg.qk_nope_head_dim
            }
            _ => self.get_head_size(),
        }
    }

    pub fn is_mla(&self) -> bool {
        if let Some(raw) = self.extra_config_json.as_ref() {
            if let Ok(root) = serde_json::from_str::<serde_json::Value>(raw) {
                let cfg_root = root.get("text_config").unwrap_or(&root);
                return cfg_root
                    .get("kv_lora_rank")
                    .and_then(|v| v.as_u64())
                    .is_some();
            }
        }
        false
    }

    pub fn needs_paged_kvcache_layout(&self) -> bool {
        let arch = self
            .architectures
            .as_ref()
            .and_then(|a| a.first())
            .map(|s| s.as_str())
            .unwrap_or("");
        if !arch.contains("Gemma4") {
            return false;
        }
        if let Some(raw) = self.extra_config_json.as_ref() {
            if let Ok(root) = serde_json::from_str::<serde_json::Value>(raw) {
                let cfg = root.get("text_config").unwrap_or(&root);
                let global_head_dim = cfg
                    .get("global_head_dim")
                    .or_else(|| root.get("global_head_dim"))
                    .and_then(|v| v.as_u64())
                    .unwrap_or(0) as usize;
                if global_head_dim > 256 {
                    return true;
                }
            }
        }
        false
    }

    pub fn gemma4_per_layer_cache_config(&self) -> Option<Vec<(usize, usize)>> {
        let arch = self
            .architectures
            .as_ref()
            .and_then(|a| a.first())
            .map(|s| s.as_str())
            .unwrap_or("");
        if !arch.contains("Gemma4") {
            return None;
        }
        let raw = self.extra_config_json.as_ref()?;
        let root: serde_json::Value = serde_json::from_str(raw).ok()?;
        let cfg = root.get("text_config").unwrap_or(&root);

        let layer_types: Vec<String> = cfg
            .get("layer_types")
            .or_else(|| root.get("layer_types"))
            .and_then(|v| serde_json::from_value(v.clone()).ok())?;

        if layer_types.len() != self.num_hidden_layers {
            return None;
        }

        let swa_head_dim = cfg
            .get("swa_head_dim")
            .or_else(|| cfg.get("head_dim"))
            .or_else(|| root.get("head_dim"))
            .and_then(|v| v.as_u64())
            .unwrap_or(256) as usize;

        let global_head_dim = cfg
            .get("global_head_dim")
            .or_else(|| root.get("global_head_dim"))
            .and_then(|v| v.as_u64())
            .unwrap_or(swa_head_dim as u64) as usize;

        let swa_kv_heads = cfg
            .get("num_key_value_heads")
            .or_else(|| root.get("num_key_value_heads"))
            .and_then(|v| v.as_u64())
            .unwrap_or(self.num_key_value_heads.unwrap_or(self.num_attention_heads) as u64)
            as usize;

        let global_kv_heads = cfg
            .get("num_global_key_value_heads")
            .or_else(|| root.get("num_global_key_value_heads"))
            .and_then(|v| v.as_u64())
            .unwrap_or(swa_kv_heads as u64) as usize;

        let per_layer: Vec<(usize, usize)> = layer_types
            .iter()
            .map(|lt| {
                if lt == "full_attention" {
                    (global_kv_heads, global_head_dim)
                } else {
                    (swa_kv_heads, swa_head_dim)
                }
            })
            .collect();

        if per_layer
            .iter()
            .all(|&(kv_heads, head_dim)| kv_heads == swa_kv_heads && head_dim == swa_head_dim)
        {
            return None;
        }

        Some(per_layer)
    }

    pub fn max_head_dim(&self) -> usize {
        if let Some(per_layer) = self.gemma4_per_layer_cache_config() {
            per_layer.iter().map(|(_, hd)| *hd).max().unwrap_or(256)
        } else {
            self.head_dim
                .unwrap_or(self.hidden_size / self.num_attention_heads)
        }
    }

    pub fn mla_kv_lora_rank(&self) -> usize {
        if let Some(raw) = self.extra_config_json.as_ref() {
            if let Ok(root) = serde_json::from_str::<serde_json::Value>(raw) {
                let cfg_root = root.get("text_config").unwrap_or(&root);
                if let Some(v) = cfg_root.get("kv_lora_rank").and_then(|v| v.as_u64()) {
                    return v as usize;
                }
            }
        }
        0
    }

    pub fn mla_qk_rope_head_dim(&self) -> usize {
        if let Some(raw) = self.extra_config_json.as_ref() {
            if let Ok(root) = serde_json::from_str::<serde_json::Value>(raw) {
                let cfg_root = root.get("text_config").unwrap_or(&root);
                if let Some(v) = cfg_root.get("qk_rope_head_dim").and_then(|v| v.as_u64()) {
                    return v as usize;
                }
            }
        }
        64
    }
}

#[derive(Debug, Clone)]
enum KvCache {
    Normal(candle_nn::kv_cache::KvCache),
    Rotating(candle_nn::kv_cache::RotatingKvCache),
}

pub struct NaiveAttention {
    kv_cache: RefCell<KvCache>,
    num_kv_groups: usize,
    scale: f64,
}

fn repeat_kv(x: &Tensor, n_rep: usize) -> Result<Tensor> {
    if n_rep == 1 {
        Ok(x.to_owned())
    } else {
        let (b_sz, n_kv_head, seq_len, head_dim) = x.dims4()?;
        Tensor::cat(&vec![&x; n_rep], 2)?.reshape((b_sz, n_kv_head * n_rep, seq_len, head_dim))
    }
}

impl NaiveAttention {
    pub fn new(cfg: &Config, sliding_window: Option<usize>) -> Self {
        let num_heads = cfg.num_attention_heads;
        let num_kv_heads = cfg.num_key_value_heads.unwrap();
        let num_kv_groups = num_heads / num_kv_heads;
        let scale = 1f64 / f64::sqrt(cfg.head_dim.unwrap() as f64);

        let kv_cache = if let Some(sliding_window) = sliding_window {
            KvCache::Rotating(candle_nn::kv_cache::RotatingKvCache::new(2, sliding_window))
        } else {
            KvCache::Normal(candle_nn::kv_cache::KvCache::new(2, cfg.max_seq_len))
        };
        Self {
            kv_cache: RefCell::new(kv_cache),
            num_kv_groups,
            scale,
        }
    }

    pub fn forward(
        &self,
        q: &Tensor,
        k: &Tensor,
        v: &Tensor,
        attention_mask: Option<&Vec<Tensor>>,
        softcapping: Option<f64>,
    ) -> Result<Tensor> {
        let (b_sz, _, seq_len, _) = q.dims4()?;
        {
            if seq_len > 1 {
                self.clear_kv_cache();
            }
        }
        let mut cache = self.kv_cache.borrow_mut();
        let (k, v) = match &mut *cache {
            KvCache::Normal(c) => c.append(k, v)?,
            KvCache::Rotating(c) => c.append(k, v)?,
        };

        let k = repeat_kv(&k, self.num_kv_groups)?.contiguous()?;
        let v = repeat_kv(&v, self.num_kv_groups)?.contiguous()?;

        let attn_weights = (q.matmul(&k.transpose(2, 3)?)? * self.scale)?;

        let attn_weights = match softcapping {
            None => attn_weights,
            Some(sc) => ((attn_weights / sc)?.tanh()? * sc)?,
        };

        let attn_weights = match attention_mask {
            None => attn_weights,
            Some(mask) => attn_weights.broadcast_add(&mask[0])?,
        };
        let attn_out = candle_nn::ops::softmax_last_dim(&attn_weights)?;
        attn_out
            .matmul(&v)?
            .transpose(1, 2)?
            .reshape((b_sz, seq_len, ()))
    }

    pub fn clear_kv_cache(&self) {
        let mut cache = self.kv_cache.borrow_mut();
        match &mut *cache {
            KvCache::Normal(c) => c.reset(),
            KvCache::Rotating(c) => c.reset(),
        }
    }
}

pub enum AttentionSelect {
    Naive(NaiveAttention),
    Paged(PagedAttention),
}

impl AttentionSelect {
    pub fn new(
        cfg: &Config,
        sliding_window: Option<usize>,
        comm: Rc<Comm>,
        device: &Device,
        paged: bool,
    ) -> Self {
        if !paged {
            AttentionSelect::Naive(NaiveAttention::new(cfg, sliding_window))
        } else {
            let head_dim = cfg.head_dim.unwrap();
            let attention_heads = cfg.num_attention_heads / comm.world_size();
            let kv_heads = (cfg.num_key_value_heads.unwrap() / comm.world_size()).max(1);
            AttentionSelect::Paged(
                PagedAttention::new(
                    attention_heads,
                    head_dim,
                    1. / ((head_dim as f32).sqrt()),
                    Some(kv_heads),
                    sliding_window,
                    device.clone(),
                    None,
                    cfg.kvcache_dtype.is_fp8_keys(),
                )
                .unwrap(),
            )
        }
    }

    pub fn forward(
        &self,
        q: &Tensor,
        k: &Tensor,
        v: &Tensor,
        attention_mask: Option<&Vec<Tensor>>,
        cache: Option<(&Tensor, &Tensor)>,
        input_metadata: &InputMetadata,
        softcapping: Option<f64>,
    ) -> Result<Tensor> {
        match self {
            AttentionSelect::Naive(att) => att.forward(q, k, v, attention_mask, softcapping),
            AttentionSelect::Paged(pag) => {
                let (b_sz, _, seq_len, _) = q.dims4()?;
                pag.forward(
                    q,
                    k,
                    v,
                    attention_mask,
                    cache.map(|(k_, _)| k_.clone()),
                    cache.map(|(_, v_)| v_.clone()),
                    input_metadata,
                    softcapping,
                )?
                .reshape((b_sz, seq_len, ()))
            }
        }
    }
}
