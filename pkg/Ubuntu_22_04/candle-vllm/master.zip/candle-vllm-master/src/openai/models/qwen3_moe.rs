use super::{
    attention::Attention, rotary_emb::ScalingRotaryEmbedding, Config, InputMetadata, MoEConfig,
};
use crate::backend::progress::{ProgressLike, ProgressReporter};
use crate::openai::distributed::{
    embedding, Comm, TensorParallelColumnLinear, TensorParallelRowLinear, VarBuilder,
    VocabParallelLinear,
};
use crate::openai::models::layers::deepstack::ApplyDeepStack;
use crate::openai::models::layers::moe::{
    FusedMoe, FusedMoeFp8, FusedMoeISQ, FusedMoeMxfp4, FusedMoeNvfp4,
};
use crate::openai::models::layers::others::{rms_norm, NormX};
use crate::openai::models::linear::LinearX as Linear;
use crate::openai::models::mask::get_attention_causal_mask;
use crate::openai::models::QwenMoEConfig;
use candle::{DType, Device, Module, Result, Tensor};
use candle_core as candle;
use parking_lot::RwLock;
use std::path::PathBuf;
use std::rc::Rc;
use std::sync::Arc;

impl Qwen3MoE {
    pub fn load_config(filename: &PathBuf, isq: Option<String>) -> Result<Config> {
        let mut config = Config::load_config(filename.clone())?;
        config.head_dim = Some(
            config
                .head_dim
                .unwrap_or(config.hidden_size / config.num_attention_heads),
        );
        config.num_key_value_heads = Some(
            config
                .num_key_value_heads
                .unwrap_or(config.num_attention_heads),
        );
        config.max_seq_len = config.effective_max_seq_len();
        config.attention_bias = Some(
            config
                .use_qkv_bias
                .or(config.attention_bias)
                .unwrap_or(true),
        );
        config.isq_quant = if config.quantization_config.is_some() {
            None
        } else {
            isq
        };

        if config.moe_config.is_none() {
            let f = std::fs::read(filename).map_err(candle::Error::wrap)?;
            let mut from_root: Option<QwenMoEConfig> =
                serde_json::from_slice::<QwenMoEConfig>(&f).ok();
            if from_root.is_none() {
                if let Ok(v) = serde_json::from_slice::<serde_json::Value>(&f) {
                    if let Some(text_config) = v.get("text_config") {
                        from_root =
                            serde_json::from_value::<QwenMoEConfig>(text_config.clone()).ok();
                    }
                }
            }
            if let Some(moe_cfg) = from_root {
                config.moe_config = Some(MoEConfig::QwenMoE(moe_cfg));
            }
        }

        // If config omits norm_topk_prob, align with existing GGUF fallback behavior.
        if let Some(MoEConfig::QwenMoE(moe_cfg)) = config.moe_config.as_mut() {
            if let Some(raw) = config.extra_config_json.as_ref() {
                if let Ok(root) = serde_json::from_str::<serde_json::Value>(raw) {
                    let cfg_root = root.get("text_config").unwrap_or(&root);
                    if cfg_root.get("norm_topk_prob").is_none() {
                        moe_cfg.norm_topk_prob = moe_cfg.shared_expert_intermediate_size.is_none();
                    }
                }
            }
        }

        Ok(config)
    }
}

struct Mlp {
    gate_proj: TensorParallelColumnLinear,
    up_proj: TensorParallelColumnLinear,
    down_proj: TensorParallelRowLinear,
    act_fn: candle_nn::Activation,
}

impl Mlp {
    fn new(cfg: &Config, intermediate_size: usize, vb: VarBuilder, comm: Rc<Comm>) -> Result<Self> {
        let hidden_sz = cfg.hidden_size;
        // let intermediate_sz = cfg.intermediate_size;

        let gate_proj = TensorParallelColumnLinear::load_with_hints(
            hidden_sz,
            intermediate_size,
            false,
            vb.pp("gate_proj"),
            comm.clone(),
            &cfg.isq_quant,
            &cfg.quantization_config,
        )?;
        let up_proj = TensorParallelColumnLinear::load_with_hints(
            hidden_sz,
            intermediate_size,
            false,
            vb.pp("up_proj"),
            comm.clone(),
            &cfg.isq_quant,
            &cfg.quantization_config,
        )?;
        let down_proj = TensorParallelRowLinear::load_with_hints(
            intermediate_size,
            hidden_sz,
            false,
            vb.pp("down_proj"),
            comm,
            &cfg.isq_quant,
            &cfg.quantization_config,
        )?;
        Ok(Self {
            gate_proj,
            up_proj,
            down_proj,
            act_fn: cfg.hidden_act.unwrap(),
        })
    }
}

impl Module for Mlp {
    fn forward(&self, xs: &Tensor) -> Result<Tensor> {
        let lhs = self.act_fn.forward(&self.gate_proj.forward(xs)?)?;
        let rhs = self.up_proj.forward(xs)?;
        self.down_proj.forward(&(&lhs * &rhs)?)
    }
}

enum MoeOrMlp {
    FusedMoe(FusedMoe),
    FusedMoeISQ(FusedMoeISQ),
    FusedMoeFp8(FusedMoeFp8),
    FusedMoeMxfp4(FusedMoeMxfp4),
    FusedMoeNvfp4(FusedMoeNvfp4),
    Mlp(Mlp),
}

impl MoeOrMlp {
    fn forward(&self, xs: &Tensor, is_prefill: bool) -> Result<Tensor> {
        match self {
            Self::Mlp(m) => m.forward(xs),
            Self::FusedMoe(m) => m.forward(xs, is_prefill),
            Self::FusedMoeISQ(m) => m.forward(xs, is_prefill),
            Self::FusedMoeFp8(m) => m.forward(xs, is_prefill),
            Self::FusedMoeMxfp4(m) => m.forward(xs, is_prefill),
            Self::FusedMoeNvfp4(m) => m.forward(xs, is_prefill),
        }
    }
}

struct DecoderLayer {
    self_attn: Attention,
    mlp: MoeOrMlp,
    shared_gate: Option<Linear>,
    shared_expert: Option<Mlp>,
    input_layernorm: NormX,
    post_attention_layernorm: NormX,
}

impl DecoderLayer {
    fn new(
        rotary_emb: Arc<ScalingRotaryEmbedding>,
        cfg: &Config,
        vb: VarBuilder,
        comm: Rc<Comm>,
        dtype: DType,
        layer_idx: usize,
    ) -> Result<Self> {
        let self_attn = Attention::new(
            rotary_emb,
            cfg,
            vb.pp("self_attn"),
            comm.clone(),
            cfg.sliding_window,
        )?;

        let moe_cfg = if let Some(MoEConfig::QwenMoE(moe_cfg)) = &cfg.moe_config {
            moe_cfg.clone()
        } else {
            candle::bail!("Expected QwenMoEConfig")
        };

        let mlp = if !moe_cfg
            .mlp_only_layers
            .as_ref()
            .unwrap_or(&Vec::<usize>::new())
            .contains(&layer_idx)
            && (moe_cfg.num_experts.unwrap_or(0) > 0
                && (layer_idx + 1) % moe_cfg.decoder_sparse_step.unwrap_or(1) == 0)
        {
            if let Some(ref quant_cfg) = cfg.quantization_config {
                if quant_cfg.quant_method == "fp8" {
                    MoeOrMlp::FusedMoeFp8(FusedMoeFp8::new(
                        cfg,
                        vb.pp("mlp").clone(),
                        comm.clone(),
                        dtype,
                        quant_cfg,
                    )?)
                } else if quant_cfg.quant_method == "mxfp4" {
                    MoeOrMlp::FusedMoeMxfp4(FusedMoeMxfp4::new(
                        cfg,
                        vb.pp("mlp").clone(),
                        comm.clone(),
                        dtype,
                    )?)
                } else if quant_cfg.quant_method == "nvfp4" {
                    MoeOrMlp::FusedMoeNvfp4(FusedMoeNvfp4::new(
                        cfg,
                        vb.pp("mlp").clone(),
                        comm.clone(),
                        dtype,
                    )?)
                } else if cfg.isq_quant.is_some() {
                    MoeOrMlp::FusedMoeISQ(FusedMoeISQ::new(
                        cfg,
                        vb.pp("mlp").clone(),
                        comm.clone(),
                        dtype,
                    )?)
                } else {
                    MoeOrMlp::FusedMoe(FusedMoe::new(
                        cfg,
                        vb.pp("mlp").clone(),
                        comm.clone(),
                        dtype,
                    )?)
                }
            } else if cfg.isq_quant.is_some() {
                MoeOrMlp::FusedMoeISQ(FusedMoeISQ::new(
                    cfg,
                    vb.pp("mlp").clone(),
                    comm.clone(),
                    dtype,
                )?)
            } else {
                MoeOrMlp::FusedMoe(FusedMoe::new(
                    cfg,
                    vb.pp("mlp").clone(),
                    comm.clone(),
                    dtype,
                )?)
            }
        } else {
            let mlp = Mlp::new(
                cfg,
                cfg.intermediate_size,
                vb.pp("mlp").clone(),
                comm.clone(),
            )?;

            MoeOrMlp::Mlp(mlp)
        };

        let norm_dtype = if cfg.higher_precision_required() {
            DType::F32
        } else {
            dtype
        };
        let input_layernorm = rms_norm(
            cfg.hidden_size,
            cfg.rms_norm_eps,
            vb.pp("input_layernorm"),
            norm_dtype,
            false,
        )?;
        let post_attention_layernorm = rms_norm(
            cfg.hidden_size,
            cfg.rms_norm_eps,
            vb.pp("post_attention_layernorm"),
            norm_dtype,
            false,
        )?;

        //shared experts weights in Qwen2 MoE models
        let (shared_gate, shared_expert) =
            if let Some(intermediate_size) = moe_cfg.shared_expert_intermediate_size {
                if intermediate_size > 0 {
                    let gate_dtype = if cfg.isq_quant.is_some() {
                        DType::F32
                    } else {
                        dtype
                    };
                    let ws = vb.pp("mlp.shared_expert_gate").get_with_hints_dtype(
                        (1, cfg.hidden_size),
                        "weight",
                        Default::default(),
                        gate_dtype,
                    )?;

                    let shared_gate = Linear::new(ws, None, &None, &None);

                    let mlp = Mlp::new(
                        cfg,
                        intermediate_size,
                        vb.pp("mlp.shared_expert").clone(),
                        comm.clone(),
                    )?;
                    (Some(shared_gate), Some(mlp))
                } else {
                    (None, None)
                }
            } else {
                (None, None)
            };

        Ok(Self {
            self_attn,
            mlp,
            shared_gate,
            shared_expert,
            input_layernorm,
            post_attention_layernorm,
        })
    }

    fn forward(
        &self,
        xs: &Tensor,
        attention_mask: Option<&Vec<Tensor>>,
        input_positions: &Tensor,
        cache: Option<(&Tensor, &Tensor)>,
        input_metadata: &InputMetadata,
    ) -> Result<Tensor> {
        let residual = xs;
        let xs = self.input_layernorm.forward(xs)?;
        let xs =
            self.self_attn
                .forward(&xs, attention_mask, input_positions, cache, input_metadata)?;
        let xs = (xs + residual)?;
        let residual = &xs;
        let xs = self.post_attention_layernorm.forward(&xs)?;
        //shared experts for Qwen2 MoE models
        let shared_output = match (&self.shared_gate, &self.shared_expert) {
            (Some(shared_gate), Some(shared_expert)) => {
                let gate = candle_nn::ops::sigmoid(&shared_gate.forward(&xs)?)?;
                let shared_output = shared_expert.forward(&xs)?;
                Some(gate.broadcast_mul(&shared_output)?)
            }
            _ => None,
        };
        let mlp_output = self.mlp.forward(&xs, input_metadata.is_prefill)?;
        if let Some(shared_output) = shared_output {
            residual + (mlp_output + shared_output)?
        } else {
            residual + mlp_output
        }
    }
}

pub struct Qwen3MoE {
    embed_tokens: candle_nn::Embedding,
    layers: Vec<DecoderLayer>,
    norm: NormX,
    lm_head: VocabParallelLinear,
    device: Device,
    dtype: DType,
    cfg: Config,
    vocab_size: usize,
}

impl Qwen3MoE {
    pub fn new(
        vb: VarBuilder,
        cfg: &Config,
        dtype: DType,
        device: &Device,
        comm: Rc<Comm>,
        progress_reporter: Arc<RwLock<ProgressReporter>>,
    ) -> Result<Self> {
        Self::new_with_prefix(vb, cfg, dtype, device, comm, progress_reporter, None)
    }

    pub fn new_with_prefix(
        vb: VarBuilder,
        cfg: &Config,
        dtype: DType,
        device: &Device,
        comm: Rc<Comm>,
        progress_reporter: Arc<RwLock<ProgressReporter>>,
        prefix: Option<String>,
    ) -> Result<Self> {
        let (vb_m, tie_word_embeddings) = if let Some(prefix) = prefix {
            (vb.pp(prefix.trim_end_matches('.')), cfg.tie_word_embeddings)
        } else if !vb.contains_tensor("model.embed_tokens.weight")
            && vb.contains_tensor("embed_tokens.weight")
        {
            (vb.clone(), true)
        } else {
            (vb.pp("model"), cfg.tie_word_embeddings)
        };
        let embed_tokens = embedding(cfg.vocab_size, cfg.hidden_size, vb_m.pp("embed_tokens"))?;
        let rotary_emb = Arc::new(ScalingRotaryEmbedding::new(DType::F32, cfg, device, true)?);
        let mut layers = Vec::with_capacity(cfg.num_hidden_layers);
        let vb_l = vb_m.pp("layers");
        let reporter = progress_reporter.clone();
        for layer_idx in 0..cfg.num_hidden_layers {
            let layer = DecoderLayer::new(
                rotary_emb.clone(),
                cfg,
                vb_l.pp(layer_idx),
                comm.clone(),
                dtype,
                layer_idx,
            )?;
            layers.push(layer);
            reporter.write().set_progress(layer_idx + 1);
        }
        let norm_dtype = if cfg.higher_precision_required() {
            DType::F32
        } else {
            dtype
        };
        let norm = rms_norm(
            cfg.hidden_size,
            cfg.rms_norm_eps,
            vb_m.pp("norm"),
            norm_dtype,
            false,
        )?;
        let lm_head = VocabParallelLinear::load_no_bias(
            cfg.hidden_size,
            cfg.vocab_size,
            if tie_word_embeddings {
                vb_m.pp("embed_tokens")
            } else {
                vb.pp("lm_head")
            },
            comm.clone(),
            &None,
            &None,
            dtype,
        )?;
        Ok(Self {
            embed_tokens,
            layers,
            norm,
            lm_head,
            device: device.clone(),
            dtype,
            cfg: cfg.clone(),
            vocab_size: cfg.vocab_size,
        })
    }

    pub fn embed_forward(&self, input_ids: &Tensor) -> Result<Tensor> {
        let xs = self.embed_tokens.forward(input_ids)?;
        if self.cfg.isq_quant.is_some() && xs.dtype() != DType::F32 {
            xs.to_dtype(DType::F32)
        } else {
            Ok(xs)
        }
    }

    pub fn forward(
        &self,
        input_ids: &Tensor,
        input_positions: &Tensor,
        kv_caches: Option<&Vec<(Tensor, Tensor)>>,
        input_metadata: &InputMetadata,
    ) -> Result<Tensor> {
        self.forward_inner(
            input_ids,
            input_positions,
            kv_caches,
            input_metadata,
            false,
            &None,
            &None,
            false,
        )
    }

    pub fn forward_embedding(
        &self,
        input_ids: &Tensor,
        input_positions: &Tensor,
        kv_caches: Option<&Vec<(Tensor, Tensor)>>,
        input_metadata: &InputMetadata,
    ) -> Result<Tensor> {
        self.forward_inner(
            input_ids,
            input_positions,
            kv_caches,
            input_metadata,
            false,
            &None,
            &None,
            true,
        )
    }

    fn forward_inner(
        &self,
        input_ids: &Tensor,
        input_positions: &Tensor,
        kv_caches: Option<&Vec<(Tensor, Tensor)>>,
        input_metadata: &InputMetadata,
        embedded_inputs: bool,
        visual_pos_masks: &Option<Tensor>,
        deepstack_visual_embeds: &Option<Vec<Tensor>>,
        return_hidden: bool,
    ) -> Result<Tensor> {
        let seqlens = if let Some(seqlens) = input_metadata.seqlens.as_ref() {
            seqlens.clone()
        } else if input_metadata.cu_seqlens_q.is_some() {
            input_metadata
                .cu_seqlens_q
                .as_ref()
                .unwrap()
                .to_vec1::<u32>()?[1..]
                .to_vec()
        } else {
            Vec::new()
        };
        let attention_mask = get_attention_causal_mask(
            &self.device,
            self.dtype,
            input_positions,
            &seqlens,
            self.cfg.sliding_window,
            input_metadata.is_prefill,
        );
        let mut xs = if embedded_inputs {
            input_ids.to_owned()
        } else {
            self.embed_forward(input_ids)?
        };

        let mut kv_cache_idx = 0usize;
        for (idx, layer) in self.layers.iter().enumerate() {
            let cache = if let Some(kv_caches) = kv_caches {
                let c = &kv_caches[kv_cache_idx];
                kv_cache_idx += 1;
                Some((&c.0, &c.1))
            } else {
                None
            };
            xs = layer.forward(
                &xs,
                attention_mask.as_ref(),
                input_positions,
                cache,
                input_metadata,
            )?;
            if let (Some(pos_mask), Some(deepstacks)) = (visual_pos_masks, deepstack_visual_embeds)
            {
                if idx < deepstacks.len() {
                    xs = xs.apply_deep_stack(pos_mask, &deepstacks[idx])?;
                }
            }
        }

        if !seqlens.is_empty() && !return_hidden {
            let indices: Vec<_> = seqlens.iter().map(|x| x - 1 as u32).collect();
            let batch = indices.len();
            xs = xs.index_select(&Tensor::from_vec(indices, (batch,), xs.device())?, 0)?;
        }
        let xs = self.norm.forward(&xs)?;

        if return_hidden {
            return xs.to_dtype(DType::F32);
        }
        self.lm_head
            .forward(&xs.to_dtype(self.dtype)?)?
            .to_dtype(DType::F32)
    }

    pub fn forward_with_deepstack(
        &self,
        input_ids: &Tensor,
        input_positions: &Tensor,
        kv_caches: Option<&Vec<(Tensor, Tensor)>>,
        input_metadata: &InputMetadata,
        embedded_inputs: bool,
        visual_pos_masks: &Option<Tensor>,
        deepstack_visual_embeds: &Option<Vec<Tensor>>,
    ) -> Result<Tensor> {
        self.forward_inner(
            input_ids,
            input_positions,
            kv_caches,
            input_metadata,
            embedded_inputs,
            visual_pos_masks,
            deepstack_visual_embeds,
            false,
        )
    }

    pub fn dtype(&self) -> DType {
        self.dtype
    }

    pub fn get_vocab_size(&self) -> usize {
        self.vocab_size
    }

    pub fn get_config(&self) -> &Config {
        &self.cfg
    }
}
