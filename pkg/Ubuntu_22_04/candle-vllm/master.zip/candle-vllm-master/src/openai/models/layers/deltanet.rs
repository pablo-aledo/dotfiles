// src/models/layers/deltanet.rs
// Shared Qwen3.5/Qwen3Next GatedDeltaNet linear-attention layer.
// Adapted from https://github.com/guoqingbao/vllm.rs/blob/main/src/models/layers/deltanet.rs

use crate::openai::distributed::{
    shard, Comm, MergedParallelColumnLinear, TensorParallelColumnLinear, TensorParallelRowLinear,
    VarBuilder,
};
use crate::openai::models::{resolve_qwen3_hybrid_config, Config};
use attention_rs::gdn;
use attention_rs::mamba_cache::MambaCache;
use attention_rs::InputMetadata;
use candle_core::{DType, Result, Tensor};
use std::rc::Rc;

enum GdnProjection {
    // Qwen3Next: in_proj_qkvz + in_proj_ba
    FusedQkvzBa {
        in_proj_qkvz: TensorParallelColumnLinear,
        in_proj_ba: TensorParallelColumnLinear,
    },
    // Qwen3.5: in_proj_qkv + in_proj_z + in_proj_ba + in_proj_a
    SplitQkvZaLegacy {
        in_proj_qkv: TensorParallelColumnLinear,
        in_proj_z: TensorParallelColumnLinear,
        in_proj_b: TensorParallelColumnLinear,
        in_proj_a: TensorParallelColumnLinear,
    },
    // Qwen3.5 TP-safe split for packed in_proj_qkv [q|k|v].
    SplitQkvZaMerged {
        in_proj_qkv: MergedParallelColumnLinear,
        in_proj_z: TensorParallelColumnLinear,
        in_proj_b: TensorParallelColumnLinear,
        in_proj_a: TensorParallelColumnLinear,
    },
}

pub struct GatedDeltaNet {
    projection: GdnProjection,
    out_proj: TensorParallelRowLinear,
    conv_weight: Tensor,
    conv_bias: Option<Tensor>,
    a_log: Tensor,
    dt_bias: Tensor,
    gdn_norm_weight: Tensor,
    gdn_norm_bias: Option<Tensor>,
    num_k_heads: usize,
    num_v_heads: usize,
    head_k_dim: usize,
    head_v_dim: usize,
    key_dim: usize,
    value_dim: usize,
    kv_group_size: usize,
    gdn_layer_idx: usize,
    rms_norm_eps: f64,
    scale: f64,
    kernel_dtype: DType,
    projection_dtype: DType,
}

impl GatedDeltaNet {
    fn is_weight_quantized(vb: &VarBuilder, quant_method: &str) -> bool {
        match quant_method {
            "fp8" => vb.contains_tensor("weight_scale") || vb.contains_tensor("weight_scale_inv"),
            "mxfp4" => vb.contains_tensor("weight_packed") || vb.contains_tensor("blocks"),
            "nvfp4" => {
                let has_mlx = vb.contains_tensor("weight") && vb.contains_tensor("scales");
                let has_packed =
                    vb.contains_tensor("weight_packed") || vb.contains_tensor("blocks");
                let has_scale = vb.contains_tensor("weight_scale") || vb.contains_tensor("scales");
                let has_modelopt =
                    vb.contains_tensor("weight_scale_2") || vb.contains_tensor("input_scale");
                has_mlx || (has_packed && has_scale) || (has_modelopt && has_scale)
            }
            _ => true,
        }
    }

    fn resolve_quant_for_weight(
        vb: &VarBuilder,
        quantization_config: &Option<crate::openai::models::QuantConfig>,
    ) -> Option<crate::openai::models::QuantConfig> {
        if let Some(cfg) = quantization_config {
            if Self::is_weight_quantized(vb, &cfg.quant_method) {
                return quantization_config.clone();
            }
        }
        None
    }

    fn load_projection(
        vb: &VarBuilder,
        hidden_size: usize,
        key_dim_global: usize,
        value_dim_global: usize,
        num_v_heads_global: usize,
        comm: Rc<Comm>,
        config: &Config,
        dtype: DType,
        is_quantized: bool,
    ) -> Result<GdnProjection> {
        let (quantization_config, _quant) = if is_quantized {
            (config.quantization_config.clone(), config.isq_quant.clone())
        } else {
            (None, None)
        };
        let mut load_errors = Vec::new();

        let projection_size_qkvz = key_dim_global * 2 + value_dim_global * 2;
        let projection_size_ba = num_v_heads_global * 2;

        let vb_qkvz = vb.pp("in_proj_qkvz");
        let qc_qkvz = Self::resolve_quant_for_weight(&vb_qkvz, &quantization_config);
        let fused_qkvz = TensorParallelColumnLinear::load_with_hints(
            hidden_size,
            projection_size_qkvz,
            false,
            vb_qkvz,
            comm.clone(),
            &None,
            &qc_qkvz,
        );

        let vb_ba = vb.pp("in_proj_ba");
        let qc_ba = Self::resolve_quant_for_weight(&vb_ba, &quantization_config);
        let fused_ba = TensorParallelColumnLinear::load_with_hints(
            hidden_size,
            projection_size_ba,
            false,
            vb_ba,
            comm.clone(),
            &None,
            &qc_ba,
        );

        match (fused_qkvz, fused_ba) {
            (Ok(in_proj_qkvz), Ok(in_proj_ba)) => {
                return Ok(GdnProjection::FusedQkvzBa {
                    in_proj_qkvz,
                    in_proj_ba,
                });
            }
            (qkvz, ba) => {
                if let Err(err) = qkvz {
                    load_errors.push(format!("in_proj_qkvz: {err}"));
                }
                if let Err(err) = ba {
                    load_errors.push(format!("in_proj_ba: {err}"));
                }
            }
        };

        let vb_z = vb.pp("in_proj_z");
        let qc_z = Self::resolve_quant_for_weight(&vb_z, &quantization_config);
        let split_z = TensorParallelColumnLinear::load_with_hints(
            hidden_size,
            value_dim_global,
            false,
            vb_z,
            comm.clone(),
            &None,
            &qc_z,
        );

        let vb_b = vb.pp("in_proj_b");
        let qc_b = Self::resolve_quant_for_weight(&vb_b, &quantization_config);
        let split_b = TensorParallelColumnLinear::load_with_hints(
            hidden_size,
            num_v_heads_global,
            false,
            vb_b,
            comm.clone(),
            &None,
            &qc_b,
        );

        let vb_a = vb.pp("in_proj_a");
        let qc_a = Self::resolve_quant_for_weight(&vb_a, &quantization_config);
        let split_a = TensorParallelColumnLinear::load_with_hints(
            hidden_size,
            num_v_heads_global,
            false,
            vb_a,
            comm.clone(),
            &None,
            &qc_a,
        );

        match (split_z, split_b, split_a) {
            (Ok(in_proj_z), Ok(in_proj_b), Ok(in_proj_a)) => {
                if comm.world_size() > 1 {
                    let vb_qkv = vb.pp("in_proj_qkv");
                    let qc_qkv = Self::resolve_quant_for_weight(&vb_qkv, &quantization_config);
                    let split_qkv_merged = MergedParallelColumnLinear::load_merged_chunks(
                        hidden_size,
                        key_dim_global * 2 + value_dim_global,
                        0,
                        vec![key_dim_global, key_dim_global, value_dim_global],
                        vb_qkv,
                        comm.clone(),
                        &qc_qkv,
                        &None,
                        dtype,
                    );

                    match split_qkv_merged {
                        Ok(in_proj_qkv) => {
                            return Ok(GdnProjection::SplitQkvZaMerged {
                                in_proj_qkv,
                                in_proj_z,
                                in_proj_b,
                                in_proj_a,
                            });
                        }
                        Err(err) => {
                            if is_quantized {
                                candle_core::bail!(
                                "Unable to load TP-safe quantized Qwen3.5 split in_proj_qkv: {}",
                                err
                            );
                            }
                        }
                    }
                }

                let vb_qkv = vb.pp("in_proj_qkv");
                let qc_qkv = Self::resolve_quant_for_weight(&vb_qkv, &quantization_config);
                let split_qkv_legacy = TensorParallelColumnLinear::load_with_hints(
                    hidden_size,
                    key_dim_global * 2 + value_dim_global,
                    false,
                    vb_qkv,
                    comm.clone(),
                    &None,
                    &qc_qkv,
                );

                if let Ok(in_proj_qkv) = split_qkv_legacy {
                    return Ok(GdnProjection::SplitQkvZaLegacy {
                        in_proj_qkv,
                        in_proj_z,
                        in_proj_b,
                        in_proj_a,
                    });
                } else if let Err(err) = split_qkv_legacy {
                    load_errors.push(format!("in_proj_qkv: {err}"));
                }
            }
            (z, b, a) => {
                if let Err(err) = z {
                    load_errors.push(format!("in_proj_z: {err}"));
                }
                if let Err(err) = b {
                    load_errors.push(format!("in_proj_b: {err}"));
                }
                if let Err(err) = a {
                    load_errors.push(format!("in_proj_a: {err}"));
                }
            }
        }

        candle_core::bail!(
            "Unable to load Qwen3.5/Qwen3Next linear attention projection weights: {}",
            load_errors.join("; ")
        )
    }

    fn fix_qwen3next_projection_order(
        &self,
        mixed_qkvz: &Tensor,
        mixed_ba: &Tensor,
    ) -> Result<(Tensor, Tensor, Tensor, Tensor, Tensor, Tensor)> {
        let seq_len = mixed_qkvz.dim(0)?;
        let qkvz_group_dim =
            self.head_k_dim + self.head_k_dim + self.kv_group_size * self.head_v_dim * 2;
        let ba_group_dim = 2 * self.kv_group_size;

        let mixed_qkvz = mixed_qkvz.reshape((seq_len, self.num_k_heads, qkvz_group_dim))?;
        let mixed_ba = mixed_ba.reshape((seq_len, self.num_k_heads, ba_group_dim))?;

        let mut offset = 0usize;
        let query = mixed_qkvz.narrow(2, offset, self.head_k_dim)?;
        offset += self.head_k_dim;
        let key = mixed_qkvz.narrow(2, offset, self.head_k_dim)?;
        offset += self.head_k_dim;
        let value = mixed_qkvz.narrow(2, offset, self.kv_group_size * self.head_v_dim)?;
        offset += self.kv_group_size * self.head_v_dim;
        let z = mixed_qkvz.narrow(2, offset, self.kv_group_size * self.head_v_dim)?;

        let b = mixed_ba.narrow(2, 0, self.kv_group_size)?;
        let a = mixed_ba.narrow(2, self.kv_group_size, self.kv_group_size)?;

        Ok((
            query.reshape((seq_len, self.key_dim))?,
            key.reshape((seq_len, self.key_dim))?,
            value.reshape((seq_len, self.value_dim))?,
            z.reshape((seq_len, self.value_dim))?,
            b.reshape((seq_len, self.num_v_heads))?,
            a.reshape((seq_len, self.num_v_heads))?,
        ))
    }

    fn project_inputs(
        &self,
        xs: &Tensor,
    ) -> Result<(Tensor, Tensor, Tensor, Tensor, Tensor, Tensor)> {
        let xs = &if xs.dtype() != self.projection_dtype {
            xs.to_dtype(self.projection_dtype)?
        } else {
            xs.clone()
        };
        match &self.projection {
            GdnProjection::FusedQkvzBa {
                in_proj_qkvz,
                in_proj_ba,
            } => {
                let mixed_qkvz = in_proj_qkvz.forward(xs)?;
                let mixed_ba = in_proj_ba.forward(xs)?;
                self.fix_qwen3next_projection_order(&mixed_qkvz, &mixed_ba)
            }
            GdnProjection::SplitQkvZaLegacy {
                in_proj_qkv,
                in_proj_z,
                in_proj_b,
                in_proj_a,
            } => {
                let proj_qkv = in_proj_qkv.forward(xs)?;
                let q = proj_qkv.narrow(1, 0, self.key_dim)?.contiguous()?;
                let k = proj_qkv
                    .narrow(1, self.key_dim, self.key_dim)?
                    .contiguous()?;
                let v = proj_qkv
                    .narrow(1, self.key_dim * 2, self.value_dim)?
                    .contiguous()?;
                let z = in_proj_z.forward(xs)?;
                let b = in_proj_b.forward(xs)?;
                let a = in_proj_a.forward(xs)?;
                Ok((q, k, v, z, b, a))
            }
            GdnProjection::SplitQkvZaMerged {
                in_proj_qkv,
                in_proj_z,
                in_proj_b,
                in_proj_a,
            } => {
                let qkv = in_proj_qkv.forward(xs)?;
                if qkv.len() != 3 {
                    candle_core::bail!(
                        "Expected 3 chunks from merged in_proj_qkv, got {}",
                        qkv.len()
                    );
                }
                let q = qkv[0].clone();
                let k = qkv[1].clone();
                let v = qkv[2].clone();
                // z/b/a are projected from the original hidden states, not q/k/v chunks.
                let z = in_proj_z.forward(xs)?;
                let b = in_proj_b.forward(xs)?;
                let a = in_proj_a.forward(xs)?;
                Ok((q, k, v, z, b, a))
            }
        }
    }

    fn repeat_kv_heads(&self, x: Tensor) -> Result<Tensor> {
        if self.num_k_heads == self.num_v_heads {
            return Ok(x);
        }
        let (seq_len, _h, _d) = x.dims3()?;
        x.unsqueeze(2)?
            .broadcast_as((
                seq_len,
                self.num_k_heads,
                self.kv_group_size,
                self.head_k_dim,
            ))?
            .reshape((seq_len, self.num_v_heads, self.head_k_dim))
    }

    pub fn new(
        vb: VarBuilder,
        comm: Rc<Comm>,
        config: &Config,
        gdn_layer_idx: usize,
    ) -> Result<Self> {
        let hidden_size = config.hidden_size;
        let hybrid = resolve_qwen3_hybrid_config(config);
        let world_size = comm.world_size();
        let rank = comm.rank();

        let num_v_heads_global = hybrid.num_v_heads;
        let num_k_heads_global = hybrid.num_k_heads;
        if num_v_heads_global % num_k_heads_global != 0 {
            candle_core::bail!(
                "linear_num_value_heads ({}) must be divisible by linear_num_key_heads ({})",
                num_v_heads_global,
                num_k_heads_global
            );
        }
        if num_v_heads_global % world_size != 0 || num_k_heads_global % world_size != 0 {
            candle_core::bail!(
                "linear attention heads must be divisible by tensor parallel world_size (num_v_heads={}, num_k_heads={}, world_size={})",
                num_v_heads_global,
                num_k_heads_global,
                world_size
            );
        }

        let is_quantized = config.quantization_config.is_some();
        let dtype = vb.dtype();
        let kernel_dtype = if config.is_f16_mode {
            DType::F32
        } else {
            dtype
        };
        let projection_dtype = dtype;

        let num_v_heads = num_v_heads_global / world_size;
        let num_k_heads = num_k_heads_global / world_size;
        let head_k_dim = hybrid.key_head_dim;
        let head_v_dim = hybrid.value_head_dim;
        let key_dim_global = num_k_heads_global * head_k_dim;
        let value_dim_global = num_v_heads_global * head_v_dim;
        let key_dim = num_k_heads * head_k_dim;
        let value_dim = num_v_heads * head_v_dim;
        let kv_group_size = num_v_heads / num_k_heads;
        let conv_kernel_size = hybrid.conv_kernel_size;
        let conv_dim_global = key_dim_global * 2 + value_dim_global;

        // Learned GDN parameters (always F32 - required by fused_gdn_gating kernel).
        let sd = shard(0, rank, world_size);
        let a_log = vb.get_with_hints_dtype((num_v_heads_global,), "A_log", sd, DType::F32)?;
        let dt_bias = vb.get_with_hints_dtype((num_v_heads_global,), "dt_bias", sd, DType::F32)?;

        let projection = Self::load_projection(
            &vb,
            hidden_size,
            key_dim_global,
            value_dim_global,
            num_v_heads_global,
            comm.clone(),
            config,
            dtype,
            is_quantized,
        )?;

        // Conv1D weights are stored global; slice rank-local q/k/v channel blocks.
        let conv_weight = match vb.get((conv_dim_global, 1, conv_kernel_size), "conv1d.weight") {
            Ok(weight) => weight,
            Err(_) => vb
                .get((conv_dim_global, conv_kernel_size, 1), "conv1d.weight")?
                .permute((0, 2, 1))?,
        };
        let q_start = rank * key_dim;
        let k_start = key_dim_global + rank * key_dim;
        let v_start = key_dim_global * 2 + rank * value_dim;
        let q_w = conv_weight.narrow(0, q_start, key_dim)?;
        let k_w = conv_weight.narrow(0, k_start, key_dim)?;
        let v_w = conv_weight.narrow(0, v_start, value_dim)?;
        let conv_weight = Tensor::cat(&[&q_w, &k_w, &v_w], 0)?;

        let conv_bias = vb.get((conv_dim_global,), "conv1d.bias").ok();
        let conv_bias = if let Some(cb) = conv_bias {
            let q_b = cb.narrow(0, q_start, key_dim)?;
            let k_b = cb.narrow(0, k_start, key_dim)?;
            let v_b = cb.narrow(0, v_start, value_dim)?;
            Some(Tensor::cat(&[&q_b, &k_b, &v_b], 0)?)
        } else {
            None
        };

        // Output projection
        let vb_out = vb.pp("out_proj");
        let qc_out = if is_quantized {
            Self::resolve_quant_for_weight(&vb_out, &config.quantization_config)
        } else {
            None
        };
        let out_proj = TensorParallelRowLinear::load_with_hints(
            value_dim_global,
            hidden_size,
            false,
            vb_out,
            comm.clone(),
            &None,
            &qc_out,
        )?;

        // GDN output norm (gated RMSNorm): both Qwen3.5 and Qwen3Next use per-head params.
        // Always F32 to match vllm.rs precision.
        let gdn_norm_weight = vb
            .get_with_hints_dtype((head_v_dim,), "norm.weight", Default::default(), DType::F32)
            .map_err(|err| {
                candle_core::Error::Msg(format!(
                    "Unable to load linear_attn.norm.weight as per-head [{head_v_dim}]: {err}"
                ))
            })?;
        let gdn_norm_bias = vb
            .get((head_v_dim,), "norm.bias")
            .ok()
            .map(|b| b.to_dtype(DType::F32))
            .transpose()?;
        let scale = 1.0f64 / (head_k_dim as f64).sqrt();
        Ok(Self {
            projection,
            out_proj,
            conv_weight,
            conv_bias,
            a_log,
            dt_bias,
            gdn_norm_weight,
            gdn_norm_bias,
            num_k_heads,
            num_v_heads,
            head_k_dim,
            head_v_dim,
            key_dim,
            value_dim,
            kv_group_size,
            gdn_layer_idx,
            rms_norm_eps: config.rms_norm_eps,
            scale,
            kernel_dtype,
            projection_dtype,
        })
    }

    pub fn forward(
        &self,
        xs: &Tensor,
        mamba_cache: &mut MambaCache,
        input_metadata: &InputMetadata,
        seq_slots: &Tensor,
    ) -> Result<Tensor> {
        let slot_count = seq_slots.dim(0)?;
        if slot_count == 0 {
            candle_core::bail!("Linear attention requires non-empty sequence slots");
        }
        let original_dtype = xs.dtype();
        let (token_count, _hidden) = xs.dims2()?;
        let is_prefill = input_metadata.is_prefill;

        let (q, k, v, z, b, a) = self.project_inputs(xs)?;

        let (q, k, v, z, b, a) = if q.dtype() != self.kernel_dtype {
            (
                q.to_dtype(self.kernel_dtype)?,
                k.to_dtype(self.kernel_dtype)?,
                v.to_dtype(self.kernel_dtype)?,
                z.to_dtype(self.kernel_dtype)?,
                b.to_dtype(self.kernel_dtype)?,
                a.to_dtype(self.kernel_dtype)?,
            )
        } else {
            (q, k, v, z, b, a)
        };
        let mixed_qkv = Tensor::cat(&[&q, &k, &v], 1)?;

        let (kv_conv, prefill_conv_state) = if is_prefill {
            let mut conv_state = mamba_cache.get_batch_conv_state(self.gdn_layer_idx, seq_slots)?;
            let cu_seqlens = input_metadata
                .cu_seqlens_q
                .as_ref()
                .expect("cu_seqlens_q must be present in prefill!");

            let out = gdn::causal_conv1d_fwd(
                &mixed_qkv,
                &self.conv_weight,
                self.conv_bias.as_ref(),
                &mut conv_state,
                None,
                Some(cu_seqlens),
                true, // SiLU activation
            )?;
            (out, Some(conv_state))
        } else {
            if token_count != slot_count {
                candle_core::bail!(
                    "Linear attention decode mismatch: {} tokens vs {} sequence slots",
                    token_count,
                    slot_count
                );
            }
            let out = gdn::causal_conv1d_update_slots(
                &mixed_qkv,
                &self.conv_weight,
                self.conv_bias.as_ref(),
                mamba_cache.conv_state_mut(self.gdn_layer_idx),
                seq_slots,
                true,
            )?;
            (out, None)
        };
        if let Some(conv_state) = prefill_conv_state {
            mamba_cache.set_batch_conv_state(self.gdn_layer_idx, seq_slots, &conv_state)?;
        }

        // Split convolved output back into q', k', v'
        let q_conv = kv_conv.narrow(1, 0, self.key_dim)?;
        let k_conv = kv_conv.narrow(1, self.key_dim, self.key_dim)?;
        let v_conv = kv_conv.narrow(1, self.key_dim * 2, self.value_dim)?;

        // Fused GDN gating
        let (a_expanded, b_expanded) = (a.unsqueeze(0)?, b.unsqueeze(0)?); // [1, seq_len, num_heads]
        let (g, beta) =
            gdn::fused_gdn_gating(&self.a_log, &a_expanded, &b_expanded, &self.dt_bias)?;
        let (g, beta) = (g.squeeze(0)?, beta.squeeze(0)?);

        let q = q_conv.reshape((token_count, self.num_k_heads, self.head_k_dim))?;
        let k = k_conv.reshape((token_count, self.num_k_heads, self.head_k_dim))?;
        let v = v_conv.reshape((token_count, self.num_v_heads, self.head_v_dim))?;
        let q = gdn::l2_norm_last_dim(&q, 1e-6)?;
        let k = gdn::l2_norm_last_dim(&k, 1e-6)?;

        let output = if is_prefill {
            let cu_seqlens = input_metadata
                .cu_seqlens_q
                .as_ref()
                .expect("cu_seqlens_q must be present in prefill!");
            let global_state = mamba_cache.recurrent_state_mut(self.gdn_layer_idx);
            let try_flashinfer = self.num_k_heads != self.num_v_heads
                && !input_metadata.is_mtp_verify
                && crate::openai::utils::sm90_lower_precision_gdn_prefill();
            let flashinfer_result = if try_flashinfer {
                #[cfg(all(feature = "cuda", feature = "flashinfer"))]
                {
                    let g_exp = g.exp()?;
                    gdn::gated_delta_rule_prefill_flashinfer_gqa(
                        &q,
                        &k,
                        &v,
                        &g_exp,
                        &beta,
                        global_state,
                        seq_slots,
                        &cu_seqlens,
                        self.scale as f32,
                    )?
                }
                #[cfg(not(all(feature = "cuda", feature = "flashinfer")))]
                {
                    None
                }
            } else {
                None
            };
            if self.num_k_heads != self.num_v_heads {
                if let Some(output) = flashinfer_result {
                    output
                } else {
                    gdn::gated_delta_rule_recurrence_varlen_gqa(
                        &q,
                        &k,
                        &v,
                        &g,
                        &beta,
                        global_state,
                        seq_slots,
                        &cu_seqlens,
                        self.scale as f32,
                        None,
                    )?
                }
            } else {
                let (q, k) = (self.repeat_kv_heads(q)?, self.repeat_kv_heads(k)?);
                let q_scaled = (&q * self.scale)?;
                gdn::gated_delta_rule_recurrence_varlen(
                    &q_scaled,
                    &k,
                    &v,
                    &g,
                    &beta,
                    global_state,
                    seq_slots,
                    &cu_seqlens,
                    None,
                )?
            }
        } else {
            let batch = slot_count;
            let v_b = v.reshape((batch, self.num_v_heads, self.head_v_dim))?;
            let g_b = g.reshape((batch, self.num_v_heads))?;
            let beta_b = beta.reshape((batch, self.num_v_heads))?;
            let global_state = mamba_cache.recurrent_state_mut(self.gdn_layer_idx);
            let (q, k) = (
                self.repeat_kv_heads(q.clone())?,
                self.repeat_kv_heads(k.clone())?,
            );
            let q_b = (q.reshape((batch, self.num_v_heads, self.head_k_dim))? * self.scale)?;
            let k_b = k.reshape((batch, self.num_v_heads, self.head_k_dim))?;
            gdn::gated_delta_rule_decode_slots(
                &q_b,
                &k_b,
                &v_b,
                &g_b,
                &beta_b,
                global_state,
                seq_slots,
            )?
        };

        // output: [seq_len, num_v_heads, head_v_dim] -> [seq_len, value_dim]
        let output = output.reshape((token_count, self.value_dim))?;

        // Gated RMSNorm: norm(output) * silu(z) via fused kernel
        let gated_output = gdn::gated_rmsnorm_silu_mul(
            &output,
            &z,
            &self.gdn_norm_weight,
            self.gdn_norm_bias.as_ref(),
            self.rms_norm_eps,
            self.head_v_dim,
        )?;

        let out = self
            .out_proj
            .forward(&gated_output.to_dtype(self.projection_dtype)?)?;
        if out.dtype() != original_dtype {
            out.to_dtype(original_dtype)
        } else {
            Ok(out)
        }
    }
}
