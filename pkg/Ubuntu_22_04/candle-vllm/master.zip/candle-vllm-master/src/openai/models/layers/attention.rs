use super::quantized_var_builder::VarBuilder as QVarBuilder;
use super::rotary_emb::ScalingRotaryEmbedding;
#[cfg(feature = "nccl")]
use crate::openai::distributed::AllReduce;
use crate::openai::distributed::{
    kv_head_shard, rms_norm_sharded, rms_norm_x, shard, Comm, MergedParallelColumnLinear, Rc,
    TensorParallelColumnLinear, TensorParallelRowLinear, VarBuilder,
};
use crate::openai::models::layers::qrmsnorm::QRmsNorm;
use crate::openai::models::Config;
use crate::{InputMetadata, PagedAttention};
use candle_core::quantized::QMatMul;
use candle_core::{DType, Device, Module, Result, Tensor};
use candle_nn::var_builder::Shard;
use candle_nn::RmsNorm;

use std::sync::Arc;

enum QkvProjection {
    Separate {
        q_proj: TensorParallelColumnLinear,
        k_proj: TensorParallelColumnLinear,
        v_proj: TensorParallelColumnLinear,
    },
    Packed(MergedParallelColumnLinear),
}

pub struct Attention {
    qkv_proj: QkvProjection,
    o_proj: TensorParallelRowLinear,
    q_norm: Option<RmsNorm>,
    k_norm: Option<RmsNorm>,
    num_heads: usize,
    num_kv_heads: usize,
    head_dim: usize,
    rotary_emb: Arc<ScalingRotaryEmbedding>,
    attn: PagedAttention,
    softcapping: Option<f64>,
    dtype: DType,
    attn_output_gate: bool,
    no_per_head_norm: bool,
    full_dim_qk_norm: bool,
    qk_l2_norm: bool,
    v_norm_eps: Option<f64>,
}

impl Attention {
    fn normalize_sharded_2d(
        t: Tensor,
        shard: candle_nn::var_builder::Shard,
        global_dim0: usize,
        global_dim1: usize,
        name: &str,
    ) -> Result<Tensor> {
        if shard.world_size <= 1 {
            return Ok(t);
        }
        if shard.dim > 1 {
            candle_core::bail!("unexpected shard dim {} for {}", shard.dim, name);
        }
        let (d0, d1) = t.dims2()?;
        if shard.dim == 0 {
            let local = global_dim0 / shard.world_size;
            if d0 == local {
                return Ok(t);
            }
            if d0 == global_dim0 {
                return t.narrow(0, shard.rank * local, local)?.contiguous();
            }
            candle_core::bail!(
                "unexpected {} shape ({}, {}), shard dim 0 expects local {} or global {}",
                name,
                d0,
                d1,
                local,
                global_dim0
            );
        }

        let local = global_dim1 / shard.world_size;
        if d1 == local {
            return Ok(t);
        }
        if d1 == global_dim1 {
            return t.narrow(1, shard.rank * local, local)?.contiguous();
        }
        candle_core::bail!(
            "unexpected {} shape ({}, {}), shard dim 1 expects local {} or global {}",
            name,
            d0,
            d1,
            local,
            global_dim1
        );
    }

    fn normalize_sharded_1d(
        t: Tensor,
        shard: candle_nn::var_builder::Shard,
        global_dim: usize,
        name: &str,
    ) -> Result<Tensor> {
        if shard.world_size <= 1 {
            return Ok(t);
        }
        let d0 = t.dim(0)?;
        let local = global_dim / shard.world_size;
        if d0 == local {
            return Ok(t);
        }
        if d0 == global_dim {
            return t.narrow(0, shard.rank * local, local)?.contiguous();
        }
        candle_core::bail!(
            "unexpected {} shape ({}), expects local {} or global {}",
            name,
            d0,
            local,
            global_dim
        );
    }

    fn load_sharded_bias(
        vb: &VarBuilder,
        out_dim: usize,
        shard: candle_nn::var_builder::Shard,
        dtype: DType,
    ) -> Result<Option<Tensor>> {
        let bias = match vb.get_with_hints_dtype((out_dim,), "bias", shard, DType::F32) {
            Ok(bias) => bias,
            Err(_) => return Ok(None),
        };
        let bias = Self::normalize_sharded_1d(bias, shard, out_dim, "bias")?;
        if bias.dtype() != dtype {
            Ok(Some(bias.to_dtype(dtype)?))
        } else {
            Ok(Some(bias))
        }
    }

    fn try_load_sharded_fp8_weight_scale(
        vb: &VarBuilder,
        out_dim: usize,
        in_dim: usize,
        shard: candle_nn::var_builder::Shard,
        block_size: &[usize],
    ) -> Result<Option<(Tensor, Tensor)>> {
        if !vb.contains_tensor("weight_scale") && !vb.contains_tensor("weight_scale_inv") {
            return Ok(None);
        }

        let by = block_size[0];
        let bx = block_size[1];
        let scale_dim0 = out_dim.div_ceil(by);
        let scale_dim1 = in_dim.div_ceil(bx);

        let weight = match vb
            .get_with_hints_dtype((out_dim, in_dim), "weight", shard, DType::F8E4M3)
            .or_else(|_| vb.get_with_hints_dtype((out_dim, in_dim), "weight", shard, DType::U8))
        {
            Ok(weight) => weight,
            Err(_) => return Ok(None),
        };
        let weight = Self::normalize_sharded_2d(weight, shard, out_dim, in_dim, "weight")?;

        let weight_scale = match vb.get_with_hints_dtype(
            (scale_dim0, scale_dim1),
            "weight_scale",
            shard,
            DType::F32,
        ) {
            Ok(scale) => scale,
            Err(_) => match vb.get_with_hints_dtype(
                (scale_dim0, scale_dim1),
                "weight_scale_inv",
                shard,
                DType::F32,
            ) {
                Ok(scale) => scale,
                Err(_) => return Ok(None),
            },
        };
        let weight_scale = Self::normalize_sharded_2d(
            weight_scale,
            shard,
            scale_dim0,
            scale_dim1,
            "weight_scale",
        )?;

        Ok(Some((weight, weight_scale)))
    }

    fn try_load_packed_qkv(
        vb: &VarBuilder,
        hidden_sz: usize,
        q_out_dim: usize,
        kv_out_dim: usize,
        attention_bias: bool,
        comm: Rc<Comm>,
        kv_shard: Shard,
        dtype: DType,
        quant_cfg: &Option<crate::openai::models::QuantConfig>,
        quant: &Option<String>,
        k_eq_v: bool,
    ) -> Result<Option<QkvProjection>> {
        if quant.is_some() {
            return Ok(None);
        }

        let q_shard = shard(0, comm.rank(), comm.world_size());
        let q_vb = vb.pp("q_proj");
        let k_vb = vb.pp("k_proj");
        let v_vb = if k_eq_v {
            vb.pp("k_proj")
        } else {
            vb.pp("v_proj")
        };

        let is_fp8_quant = quant_cfg
            .as_ref()
            .map(|cfg| cfg.quant_method == "fp8")
            .unwrap_or(false);
        if let Some(cfg) = quant_cfg {
            if cfg.quant_method != "fp8" {
                return Ok(None);
            }
        }

        if is_fp8_quant {
            let Some(block_size) = quant_cfg
                .as_ref()
                .and_then(|cfg| cfg.weight_block_size.clone())
            else {
                candle_core::bail!("LnFp8: weight_block_size must be configured for packed qkv");
            };
            if block_size.len() != 2 {
                candle_core::bail!("LnFp8: weight_block_size must have 2 elements");
            }

            let Some((q_weight, q_scale)) = Self::try_load_sharded_fp8_weight_scale(
                &q_vb,
                q_out_dim,
                hidden_sz,
                q_shard,
                &block_size,
            )?
            else {
                return Ok(None);
            };
            let Some((k_weight, k_scale)) = Self::try_load_sharded_fp8_weight_scale(
                &k_vb,
                kv_out_dim,
                hidden_sz,
                kv_shard,
                &block_size,
            )?
            else {
                return Ok(None);
            };
            let Some((v_weight, v_scale)) = Self::try_load_sharded_fp8_weight_scale(
                &v_vb,
                kv_out_dim,
                hidden_sz,
                kv_shard,
                &block_size,
            )?
            else {
                return Ok(None);
            };

            let local_q = q_weight.dim(0)?;
            let local_k = k_weight.dim(0)?;
            let local_v = v_weight.dim(0)?;
            let by = block_size[0];
            let q_global_start = q_shard.rank * local_q;
            let k_global_start = q_out_dim + kv_shard.rank * local_k;
            let v_global_start = q_out_dim + kv_out_dim + kv_shard.rank * local_v;
            if q_global_start % by != 0 || k_global_start % by != 0 || v_global_start % by != 0 {
                return Ok(None);
            }

            let packed_weight = Tensor::cat(&[&q_weight, &k_weight, &v_weight], 0)?;
            let packed_scale = Tensor::cat(&[&q_scale, &k_scale, &v_scale], 0)?;
            let packed_bias = if attention_bias {
                let q_bias = Self::load_sharded_bias(&q_vb, q_out_dim, q_shard, dtype)?;
                let k_bias = Self::load_sharded_bias(&k_vb, kv_out_dim, kv_shard, dtype)?;
                let v_bias = Self::load_sharded_bias(&v_vb, kv_out_dim, kv_shard, dtype)?;
                match (q_bias, k_bias, v_bias) {
                    (Some(qb), Some(kb), Some(vb)) => Some(Tensor::cat(&[&qb, &kb, &vb], 0)?),
                    (None, None, None) => None,
                    _ => return Ok(None),
                }
            } else {
                None
            };

            #[cfg(feature = "cuda")]
            let sm_version = attention_rs::cuda_utils::sm_version(vb.device().as_cuda_device()?)
                .unwrap_or(0) as usize;

            #[cfg(not(feature = "cuda"))]
            let sm_version = 0;

            let merged = MergedParallelColumnLinear::from_packed_local_fp8(
                packed_weight,
                packed_scale,
                packed_bias,
                block_size,
                sm_version,
                vec![local_q, local_k, local_v],
            );
            return Ok(Some(QkvProjection::Packed(merged)));
        }

        if quant_cfg.is_some() {
            return Ok(None);
        }

        let q_weight =
            q_vb.get_with_hints_dtype((q_out_dim, hidden_sz), "weight", q_shard, dtype)?;
        let k_weight =
            k_vb.get_with_hints_dtype((kv_out_dim, hidden_sz), "weight", kv_shard, dtype)?;
        let v_weight =
            v_vb.get_with_hints_dtype((kv_out_dim, hidden_sz), "weight", kv_shard, dtype)?;
        let q_weight =
            Self::normalize_sharded_2d(q_weight, q_shard, q_out_dim, hidden_sz, "q weight")?;
        let k_weight =
            Self::normalize_sharded_2d(k_weight, kv_shard, kv_out_dim, hidden_sz, "k weight")?;
        let v_weight =
            Self::normalize_sharded_2d(v_weight, kv_shard, kv_out_dim, hidden_sz, "v weight")?;

        let local_q = q_weight.dim(0)?;
        let local_k = k_weight.dim(0)?;
        let local_v = v_weight.dim(0)?;
        let packed_weight = Tensor::cat(&[&q_weight, &k_weight, &v_weight], 0)?;

        let packed_bias = if attention_bias {
            let q_bias = Self::load_sharded_bias(&q_vb, q_out_dim, q_shard, dtype)?;
            let k_bias = Self::load_sharded_bias(&k_vb, kv_out_dim, kv_shard, dtype)?;
            let v_bias = Self::load_sharded_bias(&v_vb, kv_out_dim, kv_shard, dtype)?;
            match (q_bias, k_bias, v_bias) {
                (Some(qb), Some(kb), Some(vb)) => Some(Tensor::cat(&[&qb, &kb, &vb], 0)?),
                (None, None, None) => None,
                _ => return Ok(None),
            }
        } else {
            None
        };

        let merged = MergedParallelColumnLinear::from_packed_local(
            packed_weight,
            packed_bias,
            vec![local_q, local_k, local_v],
        );
        Ok(Some(QkvProjection::Packed(merged)))
    }

    pub fn new(
        rotary_emb: Arc<ScalingRotaryEmbedding>,
        cfg: &Config,
        vb: VarBuilder,
        comm: Rc<Comm>,
        sliding_window: Option<usize>,
    ) -> Result<Self> {
        Self::new_with_option(
            rotary_emb,
            cfg,
            vb.clone(),
            comm,
            sliding_window,
            false,
            false,
            None,
        )
    }

    pub fn new_with_option(
        rotary_emb: Arc<ScalingRotaryEmbedding>,
        cfg: &Config,
        vb: VarBuilder,
        comm: Rc<Comm>,
        sliding_window: Option<usize>,
        k_eq_v: bool,
        qk_l2_norm: bool,
        attention_scale: Option<f32>,
    ) -> Result<Self> {
        let hidden_sz = cfg.hidden_size;
        let num_heads = cfg.num_attention_heads;
        let num_kv_heads = cfg.num_key_value_heads.unwrap();
        let head_dim = cfg.head_dim.unwrap_or(hidden_sz / num_heads);
        let arch = cfg
            .architectures
            .as_ref()
            .and_then(|a| a.first())
            .cloned()
            .unwrap_or_default();
        let is_gemma = matches!(
            arch.as_str(),
            "Gemma3ForConditionalGeneration" | "Gemma3ForCausalLM"
        );
        let is_qwen35_or_next = matches!(
            arch.as_str(),
            "Qwen3_5ForCausalLM"
                | "Qwen3_5ForConditionalGeneration"
                | "Qwen3_5MoeForCausalLM"
                | "Qwen3_5MoeForConditionalGeneration"
                | "Qwen3NextForCausalLM"
                | "Qwen3NextForConditionalGeneration"
        );
        // MLX NVFP4 checkpoints contain the already-materialized norm weights;
        // applying the Gemma/Qwen +1 convention a second time is incorrect.
        let is_mlx_nvfp4 = cfg
            .quantization_config
            .as_ref()
            .is_some_and(|q| q.is_mlx_nvfp4);
        let qk_norm_add_one = is_gemma || (is_qwen35_or_next && !is_mlx_nvfp4);
        let attention_bias = if is_qwen35_or_next {
            cfg.use_qkv_bias.or(cfg.attention_bias).unwrap_or(false)
        } else {
            cfg.attention_bias.unwrap_or(false)
        };
        let attn_output_gate = is_qwen35_or_next;
        let q_out_dim = num_heads * head_dim * if attn_output_gate { 2 } else { 1 };
        let world_size = comm.world_size();
        let (kv_heads, kv_shard) = kv_head_shard(num_kv_heads, comm.rank(), world_size)?;
        let qkv_proj = if let Some(packed) = Self::try_load_packed_qkv(
            &vb,
            hidden_sz,
            q_out_dim,
            num_kv_heads * head_dim,
            attention_bias,
            comm.clone(),
            kv_shard,
            vb.dtype(),
            &cfg.quantization_config,
            &cfg.isq_quant,
            k_eq_v,
        )? {
            packed
        } else {
            let q_proj = TensorParallelColumnLinear::load_with_hints(
                hidden_sz,
                q_out_dim,
                attention_bias,
                vb.pp("q_proj"),
                comm.clone(),
                &cfg.isq_quant,
                &cfg.quantization_config,
            )?;
            let k_proj = TensorParallelColumnLinear::load_with_shard(
                hidden_sz,
                num_kv_heads * head_dim,
                attention_bias,
                vb.pp("k_proj"),
                kv_shard,
                &cfg.isq_quant,
                &cfg.quantization_config,
            )?;
            let high_precision_quant = cfg.isq_quant.as_deref().map(|quant| {
                crate::openai::models::layers::isq_high_precision_quant(quant).to_string()
            });
            let v_proj_quant = if cfg.quantization_config.is_some() {
                &cfg.isq_quant
            } else if cfg.isq_quant.is_some()
                && !matches!(
                    cfg.isq_quant.as_ref().unwrap().as_str(),
                    "gptq" | "awq" | "marlin"
                )
            {
                &high_precision_quant
            } else {
                &cfg.isq_quant
            };
            let v_proj = TensorParallelColumnLinear::load_with_shard(
                hidden_sz,
                num_kv_heads * head_dim,
                attention_bias,
                vb.pp(if k_eq_v { "k_proj" } else { "v_proj" }),
                kv_shard,
                v_proj_quant,
                &cfg.quantization_config,
            )?;
            QkvProjection::Separate {
                q_proj,
                k_proj,
                v_proj,
            }
        };

        let o_proj = TensorParallelRowLinear::load_with_hints(
            num_heads * head_dim,
            hidden_sz,
            false,
            vb.pp("o_proj"),
            comm.clone(),
            &cfg.isq_quant,
            &cfg.quantization_config,
        )?;

        let q_norm_perhead = rms_norm_x(
            head_dim,
            cfg.rms_norm_eps,
            vb.pp("q_norm"),
            DType::F32,
            qk_norm_add_one,
        );
        let k_norm_perhead = rms_norm_x(
            head_dim,
            cfg.rms_norm_eps,
            vb.pp("k_norm"),
            DType::F32,
            qk_norm_add_one,
        );

        let (q_norm, k_norm, full_dim_qk_norm) = if q_norm_perhead.is_ok() && k_norm_perhead.is_ok()
        {
            (
                Some(q_norm_perhead.unwrap()),
                Some(k_norm_perhead.unwrap()),
                false,
            )
        } else {
            let q_shard = shard(0, comm.rank(), comm.world_size());
            let q_full = rms_norm_sharded(
                num_heads * head_dim,
                cfg.rms_norm_eps,
                vb.pp("q_norm"),
                DType::F32,
                qk_norm_add_one,
                q_shard,
            );
            let k_full = rms_norm_sharded(
                num_kv_heads * head_dim,
                cfg.rms_norm_eps,
                vb.pp("k_norm"),
                DType::F32,
                qk_norm_add_one,
                kv_shard,
            );
            if q_full.is_ok() && k_full.is_ok() {
                (Some(q_full.unwrap()), Some(k_full.unwrap()), true)
            } else {
                (None, None, false)
            }
        };

        let is_gemma4 = arch == "Gemma4ForConditionalGeneration" || arch == "Gemma4ForCausalLM";
        let v_norm_eps = if is_gemma4 {
            Some(cfg.rms_norm_eps)
        } else {
            None
        };
        let no_per_head_norm_models: Vec<String> = vec![
            "Gemma3ForConditionalGeneration",
            "Gemma3ForCausalLM",
            "Gemma4ForConditionalGeneration",
            "Gemma4ForCausalLM",
            "Qwen3VLForConditionalGeneration",
            "Qwen3VLMoeForConditionalGeneration",
            "Qwen3_5ForCausalLM",
            "Qwen3_5ForConditionalGeneration",
            "Qwen3_5MoeForCausalLM",
            "Qwen3_5MoeForConditionalGeneration",
            "Qwen3NextForCausalLM",
            "Qwen3NextForConditionalGeneration",
            "MiniMaxM2ForCausalLM",
        ]
        .iter()
        .map(|s| s.to_string())
        .collect();

        assert!(cfg.num_attention_heads >= comm.world_size());
        assert!(cfg.num_attention_heads % comm.world_size() == 0);

        let attention_heads = cfg.num_attention_heads / comm.world_size();
        Ok(Self {
            qkv_proj,
            o_proj,
            q_norm,
            k_norm,
            num_heads: attention_heads,
            num_kv_heads: kv_heads,
            head_dim,
            rotary_emb,
            attn: PagedAttention::new(
                attention_heads,
                head_dim,
                attention_scale.unwrap_or(1. / ((head_dim as f32).sqrt())),
                Some(kv_heads),
                sliding_window,
                vb.device().clone(),
                None,
                cfg.kvcache_dtype.is_fp8_keys(),
            )?,
            softcapping: cfg.attn_logit_softcapping,
            dtype: vb.dtype(),
            attn_output_gate,
            no_per_head_norm: no_per_head_norm_models.contains(&arch),
            full_dim_qk_norm,
            qk_l2_norm,
            v_norm_eps,
        })
    }

    pub fn forward_ext(
        &self,
        xs: &Tensor,
        rotary_emb: Option<&ScalingRotaryEmbedding>,
        attention_mask: Option<&Vec<Tensor>>,
        input_positions: &Tensor,
        cache: Option<(&Tensor, &Tensor)>,
        input_metadata: &InputMetadata,
        q_scale: Option<&Tensor>,
    ) -> Result<Tensor> {
        let (seq_len, _) = xs.dims2()?;

        let (query_states, key_states, value_states) = match &self.qkv_proj {
            QkvProjection::Separate {
                q_proj,
                k_proj,
                v_proj,
            } => (
                q_proj.forward(xs)?,
                k_proj.forward(xs)?,
                v_proj.forward(xs)?,
            ),
            QkvProjection::Packed(qkv_proj) => {
                let qkv = qkv_proj.forward(xs)?;
                if qkv.len() != 3 {
                    candle_core::bail!(
                        "Expected 3 outputs from packed qkv projection, got {}",
                        qkv.len()
                    );
                }
                (qkv[0].clone(), qkv[1].clone(), qkv[2].clone())
            }
        };

        let local_q_dim = self.num_heads * self.head_dim;
        let (query_states, q_gate) = if self.attn_output_gate {
            let q_dim = query_states.dim(1)?;
            if q_dim != local_q_dim * 2 {
                candle_core::bail!(
                    "q_proj output dim mismatch for gated attention, expected {}, got {}",
                    local_q_dim * 2,
                    q_dim
                );
            }
            let q_gate = query_states.reshape((seq_len, self.num_heads, self.head_dim * 2))?;
            let q = q_gate.narrow(2, 0, self.head_dim)?;
            let gate = q_gate.narrow(2, self.head_dim, self.head_dim)?;
            (
                q.reshape((seq_len, local_q_dim))?,
                Some(gate.reshape((seq_len, local_q_dim))?),
            )
        } else {
            (query_states, None)
        };

        let q = query_states.reshape((seq_len, self.num_heads, self.head_dim))?;
        let k = key_states.reshape((seq_len, self.num_kv_heads, self.head_dim))?;
        let v = value_states.reshape((seq_len, self.num_kv_heads, self.head_dim))?;

        let (q, k) = if q.dtype() != DType::F32 {
            (q.to_dtype(DType::F32)?, k.to_dtype(DType::F32)?)
        } else {
            (q, k)
        };

        let (q, k) = if let (Some(q_norm), Some(k_norm)) = (&self.q_norm, &self.k_norm) {
            if self.full_dim_qk_norm {
                let q_2d = q.reshape((seq_len, self.num_heads * self.head_dim))?;
                let k_2d = k.reshape((seq_len, self.num_kv_heads * self.head_dim))?;
                let q_2d = q_norm.forward(&q_2d)?;
                let k_2d = k_norm.forward(&k_2d)?;
                let q = q_2d.reshape((seq_len, self.num_heads, self.head_dim))?;
                let k = k_2d.reshape((seq_len, self.num_kv_heads, self.head_dim))?;
                (q, k)
            } else if self.no_per_head_norm {
                let q = q_norm.forward(&q)?;
                let k = k_norm.forward(&k)?;
                (q, k)
            } else {
                let q_flat = q.flatten(0, 1)?;
                let k_flat = k.flatten(0, 1)?;

                let q_flat = q_norm.forward(&q_flat)?;
                let k_flat = k_norm.forward(&k_flat)?;

                let q = q_flat.reshape((seq_len, self.num_heads, self.head_dim))?;
                let k = k_flat.reshape((seq_len, self.num_kv_heads, self.head_dim))?;

                (q, k)
            }
        } else {
            (q, k)
        };

        let (mut q, mut k) = if let Some(rotary_emb) = rotary_emb {
            rotary_emb.apply_rotary_emb(&q, &k, input_positions)?
        } else {
            (q, k)
        };
        if self.qk_l2_norm {
            let q_rms = (q.sqr()?.mean_keepdim(candle_core::D::Minus1)? + 1e-5)?.sqrt()?;
            let k_rms = (k.sqr()?.mean_keepdim(candle_core::D::Minus1)? + 1e-5)?.sqrt()?;
            q = q.broadcast_div(&q_rms)?;
            k = k.broadcast_div(&k_rms)?;
        }
        if let Some(scale) = q_scale {
            let scale = scale.reshape((seq_len, 1, 1))?;
            q = q.broadcast_mul(&scale.to_dtype(q.dtype())?)?;
        }
        let (q, k) = (q.to_dtype(self.dtype)?, k.to_dtype(self.dtype)?);
        let v = if v.dtype() != self.dtype {
            v.to_dtype(self.dtype)?
        } else {
            v
        };

        let v = if let Some(eps) = self.v_norm_eps {
            let orig_dtype = v.dtype();
            let v_f32 = v.to_dtype(DType::F32)?;
            let mean_sq = v_f32.sqr()?.mean_keepdim(candle_core::D::Minus1)?;
            let rms = (mean_sq + eps)?.sqrt()?;
            v_f32.broadcast_div(&rms)?.to_dtype(orig_dtype)?
        } else {
            v
        };

        let y = self
            .attn
            .forward(
                &q,
                &k,
                &v,
                attention_mask,
                cache.map(|(k_, _)| k_.clone()),
                cache.map(|(_, v_)| v_.clone()),
                input_metadata,
                self.softcapping,
            )?
            .reshape((seq_len, ()))?;

        let y = if let Some(gate) = q_gate {
            let gate = if gate.dtype() != y.dtype() {
                gate.to_dtype(y.dtype())?
            } else {
                gate
            };
            y.broadcast_mul(&candle_nn::ops::sigmoid(&gate)?)?
        } else {
            y
        };

        let y = self.o_proj.forward(&y.to_dtype(xs.dtype())?)?;
        Ok(y)
    }

    pub fn forward(
        &self,
        xs: &Tensor,
        attention_mask: Option<&Vec<Tensor>>,
        input_positions: &Tensor,
        cache: Option<(&Tensor, &Tensor)>,
        input_metadata: &InputMetadata,
    ) -> Result<Tensor> {
        self.forward_ext(
            xs,
            Some(self.rotary_emb.as_ref()),
            attention_mask,
            input_positions,
            cache,
            input_metadata,
            None,
        )
    }
}

pub struct QuantizedAttention {
    attention_wq: QMatMul,
    attention_wk: QMatMul,
    attention_wv: QMatMul,
    attention_bq: Option<Tensor>,
    attention_bk: Option<Tensor>,
    attention_bv: Option<Tensor>,
    attention_wo: QMatMul,
    q_norm: Option<QRmsNorm>,
    k_norm: Option<QRmsNorm>,
    n_head: usize,
    n_kv_head: usize,
    head_dim: usize,
    attn_output_gate: bool,
    attn: PagedAttention,
    rotary_emb: Arc<ScalingRotaryEmbedding>,
    dtype: DType,
    #[cfg(feature = "nccl")]
    all_reduce: Option<AllReduce>,
}

impl QuantizedAttention {
    pub fn new(
        config: &Config,
        vb: &QVarBuilder,
        prefix: &str,
        device: &Device,
        dtype: DType,
        rotary_emb: Arc<ScalingRotaryEmbedding>,
        sliding_window: Option<usize>,
        rank: usize,
        world_size: usize,
        #[allow(unused_variables)] comm: Rc<Comm>,
    ) -> Result<Self> {
        let prefix_vb = vb.pp(prefix);
        let n_kv_head_global = config
            .num_key_value_heads
            .unwrap_or(config.num_attention_heads);
        let (_, kv_shard) = kv_head_shard(n_kv_head_global, rank, world_size)?;
        let attention_wq = prefix_vb.get_sharded_no_shape("attn_q.weight", 0, rank, world_size)?;
        let attention_wk = prefix_vb.get_sharded_no_shape(
            "attn_k.weight",
            0,
            kv_shard.rank,
            kv_shard.world_size,
        )?;
        let attention_wv = prefix_vb.get_sharded_no_shape(
            "attn_v.weight",
            0,
            kv_shard.rank,
            kv_shard.world_size,
        )?;

        let attention_bq = prefix_vb.get_no_shape("attn_q.bias");
        let attention_bk = prefix_vb.get_no_shape("attn_k.bias");
        let attention_bv = prefix_vb.get_no_shape("attn_v.bias");

        let attention_bq = if let Ok(bq) = attention_bq {
            let b = bq.dequantize(device)?.to_dtype(DType::F32)?;
            if world_size > 1 {
                let chunk = b.dim(0)? / world_size;
                Some(b.narrow(0, rank * chunk, chunk)?.contiguous()?)
            } else {
                Some(b)
            }
        } else {
            None
        };

        let attention_bk = if let Ok(bk) = attention_bk {
            let b = bk.dequantize(device)?.to_dtype(DType::F32)?;
            if kv_shard.world_size > 1 {
                let chunk = b.dim(0)? / kv_shard.world_size;
                Some(b.narrow(0, kv_shard.rank * chunk, chunk)?.contiguous()?)
            } else {
                Some(b)
            }
        } else {
            None
        };

        let attention_bv = if let Ok(bv) = attention_bv {
            let b = bv.dequantize(device)?.to_dtype(DType::F32)?;
            if kv_shard.world_size > 1 {
                let chunk = b.dim(0)? / kv_shard.world_size;
                Some(b.narrow(0, kv_shard.rank * chunk, chunk)?.contiguous()?)
            } else {
                Some(b)
            }
        } else {
            None
        };

        let attention_wo =
            prefix_vb.get_sharded_no_shape("attn_output.weight", 1, rank, world_size)?;

        let (q_norm, k_norm) = {
            let q_norm = prefix_vb.get_no_shape("attn_q_norm.weight");
            let k_norm = prefix_vb.get_no_shape("attn_k_norm.weight");
            match (q_norm, k_norm) {
                (Ok(q_norm), Ok(k_norm)) => {
                    let q_norm = QRmsNorm::from_arc_qtensor(q_norm, config.rms_norm_eps)?;
                    let k_norm = QRmsNorm::from_arc_qtensor(k_norm, config.rms_norm_eps)?;
                    (Some(q_norm), Some(k_norm))
                }
                _ => (None, None),
            }
        };

        let head_dim = config
            .head_dim
            .unwrap_or(config.hidden_size / config.num_attention_heads);
        let n_head = config.num_attention_heads / world_size;
        let (n_kv_head, _) = kv_head_shard(n_kv_head_global, rank, world_size)?;
        let expected_q_dim = n_head * head_dim;
        let q_out_dim = attention_wq.shape().dims()[0];
        let attn_output_gate = q_out_dim == expected_q_dim * 2;

        Ok(QuantizedAttention {
            attention_wq: QMatMul::from_arc(attention_wq)?,
            attention_wk: QMatMul::from_arc(attention_wk)?,
            attention_wv: QMatMul::from_arc(attention_wv)?,
            attention_bq,
            attention_bk,
            attention_bv,
            attention_wo: QMatMul::from_arc(attention_wo)?,
            q_norm,
            k_norm,
            n_head,
            n_kv_head,
            head_dim,
            attn_output_gate,
            attn: PagedAttention::new(
                n_head,
                head_dim,
                1. / ((head_dim as f32).sqrt()),
                Some(n_kv_head),
                sliding_window,
                device.clone(),
                None,
                config.kvcache_dtype.is_fp8_keys(),
            )?,
            rotary_emb: rotary_emb.clone(),
            dtype,
            #[cfg(feature = "nccl")]
            all_reduce: if world_size > 1 {
                Some(AllReduce::new(comm))
            } else {
                None
            },
        })
    }

    #[allow(unused_mut)]
    pub fn forward(
        &self,
        x: &Tensor,
        mask: Option<&Vec<Tensor>>,
        input_positions: &Tensor,
        cache: Option<(&Tensor, &Tensor)>,
        input_metadata: &InputMetadata,
    ) -> Result<Tensor> {
        let (seq_len, _) = x.dims2()?;

        let q_raw = self.attention_wq.forward(x)?;
        let k = self.attention_wk.forward(x)?;
        let v = self.attention_wv.forward(x)?;

        let q_raw = if let Some(bq) = &self.attention_bq {
            q_raw.broadcast_add(bq)?
        } else {
            q_raw
        };

        let k = if let Some(bk) = &self.attention_bk {
            k.broadcast_add(bk)?
        } else {
            k
        };

        let v = if let Some(bv) = &self.attention_bv {
            v.broadcast_add(bv)?
        } else {
            v
        };

        let local_q_dim = self.n_head * self.head_dim;
        let (q_linear, gate) = if self.attn_output_gate {
            let q_gate = q_raw.reshape((seq_len, self.n_head, self.head_dim * 2))?;
            let q = q_gate.narrow(2, 0, self.head_dim)?;
            let gate = q_gate.narrow(2, self.head_dim, self.head_dim)?;
            (
                q.reshape((seq_len, local_q_dim))?,
                Some(gate.reshape((seq_len, local_q_dim))?),
            )
        } else {
            (q_raw, None)
        };

        let q = q_linear.reshape((seq_len, self.n_head, self.head_dim))?;
        let k = k.reshape((seq_len, self.n_kv_head, self.head_dim))?;
        let v = v.reshape((seq_len, self.n_kv_head, self.head_dim))?;

        let (q, k) = if let (Some(q_norm), Some(k_norm)) = (&self.q_norm, &self.k_norm) {
            // Per‑head RMSNorm in qwen3
            let q_flat = q.flatten(0, 1)?;
            let k_flat = k.flatten(0, 1)?;

            // q_norm and k_norm weights stored in f32 format in qwen3 gguf
            let q_flat = q_norm.forward(&q_flat)?;
            let k_flat = k_norm.forward(&k_flat)?;

            let q = q_flat.reshape((seq_len, self.n_head, self.head_dim))?;
            let k = k_flat.reshape((seq_len, self.n_kv_head, self.head_dim))?;

            (q, k)
        } else {
            (q, k)
        };

        let (q, k) = self.rotary_emb.apply_rotary_emb(&q, &k, input_positions)?;
        let (q, k, v) = (
            q.to_dtype(self.dtype)?,
            k.to_dtype(self.dtype)?,
            v.to_dtype(self.dtype)?,
        );

        let y = self
            .attn
            .forward(
                &q,
                &k,
                &v,
                mask,
                cache.map(|(k_, _)| k_.clone()),
                cache.map(|(_, v_)| v_.clone()),
                input_metadata,
                None,
            )?
            .reshape((seq_len, ()))?;

        let y = if let Some(gate) = gate {
            let gate = gate.to_dtype(y.dtype())?;
            y.broadcast_mul(&candle_nn::ops::sigmoid(&gate)?)?
        } else {
            y
        };

        let mut y = self.attention_wo.forward(&y.to_dtype(DType::F32)?)?;
        #[cfg(feature = "nccl")]
        if let Some(all_reduce) = &self.all_reduce {
            y = all_reduce.apply(&y.to_dtype(self.dtype)?)?;
            y = y.to_dtype(DType::F32)?;
        }
        Ok(y)
    }
}
