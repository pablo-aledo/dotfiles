use super::{get_token, TokenOrFinishReason};
use crate::backend::gguf;
#[cfg(all(feature = "cuda", feature = "graph"))]
use crate::backend::graph::{CudaGraphFn, CudaGraphWrapper, GraphCapturer, ModelFn};
use crate::backend::progress::{progress_worker, ProgressLike, ProgressReporter};
use crate::openai::logits_processor::LogitsProcessor;
use crate::openai::models::layers::quantized_var_builder::VarBuilder as QVarBuilder;
use crate::openai::models::linear::set_linear_is_prefill;
use crate::openai::models::TokenID;
use crate::openai::multimodal::{get_image_config, ImageProcessConfig};
use crate::openai::requests::StopTokens;
use crate::openai::sampling_params::{GenerationConfig, Logprobs, TopLogprob};
use crate::openai::TokenizerConfig;
use crate::scheduler::sequence::{Sequence, SequenceGroup};
use crate::tools::stream_parser::{ToolConfig, ToolModelType};
#[cfg(all(feature = "cuda", feature = "graph", feature = "flashinfer"))]
use crate::FlashInferKvParams;
use crate::{
    openai::{
        conversation::default_conversation::{
            DefaultConversation, DefaultConversationSeparators, SeparatorStyle,
        },
        models::{
            deepseek::DeepSeek,
            gemma::Gemma,
            gemma3::Gemma3,
            gemma3_vl::Gemma3ForConditionalGeneration,
            gemma4::Gemma4,
            glm4::GLM4,
            glm4_moe_lite::GLM4MoeLiteForCausalLM,
            llama::Llama,
            llama4::LLama4ForConditionalGeneration,
            minimax::MiniMaxForCausalLM,
            mistral::Mistral,
            mistral3_vl::Mistral3ForConditionalGeneration,
            phi2::Phi2,
            phi4::Phi4ForCausalLM as Phi4,
            quantized_deepseek::GGUFDeepSeek,
            quantized_glm4::GGUFGLM4,
            quantized_llama::GGUFLLaMa,
            quantized_phi3::GGUFPhi3,
            quantized_qwen::GGUFQWen,
            quantized_qwen3_5::GGUFQWen3_5,
            quantized_qwen3_5_moe::GGUFQWen3_5MoE,
            quantized_qwen3_moe::GGUFQWenMoE,
            qwen::Qwen,
            qwen3_5::Qwen3_5,
            qwen3_5_moe::Qwen3_5MoE,
            qwen3_moe::Qwen3MoE,
            qwen3_vl::{Qwen3TextModel, Qwen3VLForConditionalGeneration},
            stable_lm::StableLM,
            yi::Yi,
            Config,
        },
        PipelineConfig,
    },
    InputMetadata,
};
use candle_core::quantized::gguf_file;
use candle_core::{DType, Device, Result, Tensor};
use either::Either;
use either::Either::{Left, Right};
use hf_hub::{api::sync::ApiBuilder, Repo, RepoType};
use parking_lot::RwLock;
use rayon::prelude::*;
use regex::Regex;
use std::collections::{HashMap, HashSet, VecDeque};
use std::path::Path;
pub use std::rc::Rc;
use std::{path::PathBuf, sync::Arc};
use tokenizers::Tokenizer;
use tracing::{info, warn};

const EOS_TOKEN: &str = "</s>";
const SAMPLING_SEED: u64 = 299792458;
const MIN_GEN_TOKENS: usize = 128;
const MAX_GEN_TOKENS: usize = 16 * 1024;
pub enum LLMModel {
    Llama(Arc<Llama>),
    LLaMa4(Arc<LLama4ForConditionalGeneration>),
    Phi2(Arc<Phi2>),
    Phi4(Arc<Phi4>),
    Qwen(Arc<Qwen>),
    Qwen3MoE(Arc<Qwen3MoE>),
    Qwen3_5(Arc<Qwen3_5>),
    Qwen3_5MoE(Arc<Qwen3_5MoE>),
    Qwen3VL(Arc<Qwen3VLForConditionalGeneration>),
    Gemma(Arc<Gemma>),
    Gemma3(Arc<Gemma3>),
    Gemma3VL(Arc<Gemma3ForConditionalGeneration>),
    Gemma4(Arc<Gemma4>),
    MiniMax(Arc<MiniMaxForCausalLM>),
    Mistral(Arc<Mistral>),
    Mistral3VL(Arc<Mistral3ForConditionalGeneration>),
    Yi(Arc<Yi>),
    StableLM(Arc<StableLM>),
    GLM4(Arc<GLM4>),
    GLM4MoeLite(Arc<GLM4MoeLiteForCausalLM>),
    DeepSeek(Arc<DeepSeek>),
    GLM5(Arc<DeepSeek>),
    LlamaGGUF(Arc<GGUFLLaMa>),
    Phi3GGUF(Arc<GGUFPhi3>),
    QWenGGUF(Arc<GGUFQWen>),
    QWenGGUFMoE(Arc<GGUFQWenMoE>),
    QWen3_5GGUF(Arc<GGUFQWen3_5>),
    QWen3_5GGUFMoE(Arc<GGUFQWen3_5MoE>),
    GLM4GGUF(Arc<GGUFGLM4>),
    GLM5GGUF(Arc<GGUFDeepSeek>),
    DeepSeekGGUF(Arc<GGUFDeepSeek>),
}

fn tool_model_type_for(model: &LLMModel) -> ToolModelType {
    match model {
        LLMModel::Llama(_) | LLMModel::LlamaGGUF(_) => ToolModelType::LLaMa,
        LLMModel::LLaMa4(_) => ToolModelType::LLaMa4,
        LLMModel::Qwen(_)
        | LLMModel::Qwen3_5(_)
        | LLMModel::Qwen3VL(_)
        | LLMModel::QWenGGUF(_)
        | LLMModel::QWen3_5GGUF(_) => ToolModelType::Qwen,
        LLMModel::Qwen3MoE(_)
        | LLMModel::Qwen3_5MoE(_)
        | LLMModel::QWenGGUFMoE(_)
        | LLMModel::QWen3_5GGUFMoE(_) => ToolModelType::Qwen3MoE,
        LLMModel::Gemma(_) => ToolModelType::Gemma,
        LLMModel::Gemma3(_) | LLMModel::Gemma3VL(_) => ToolModelType::Gemma3,
        LLMModel::Gemma4(_) => ToolModelType::Gemma4,
        LLMModel::MiniMax(_) => ToolModelType::MiniMax,
        LLMModel::Mistral(_) | LLMModel::Mistral3VL(_) => ToolModelType::Mistral,
        LLMModel::Yi(_) => ToolModelType::Yi,
        LLMModel::StableLM(_) => ToolModelType::StableLM,
        LLMModel::GLM4(_)
        | LLMModel::GLM4MoeLite(_)
        | LLMModel::GLM4GGUF(_)
        | LLMModel::GLM5(_)
        | LLMModel::GLM5GGUF(_) => ToolModelType::GLM4,
        LLMModel::DeepSeek(_) | LLMModel::DeepSeekGGUF(_) => ToolModelType::DeepSeek,
        LLMModel::Phi2(_) | LLMModel::Phi3GGUF(_) => ToolModelType::Phi,
        LLMModel::Phi4(_) => ToolModelType::Phi4,
    }
}

/// top-p, multinomial, and argmax sampling are implemented. Beam search is not implemented.
pub struct DefaultPipeline {
    pub model: LLMModel,
    pub tokenizer: Tokenizer,
    pub logits_processor: LogitsProcessor,
    pub conversation: DefaultConversation,
    pub name: String,
    pub dtype: DType,
    pub device: Device,
    pub stop_token_ids: Vec<u32>,
    pub rank: usize,
    pub stream_decoders: RwLock<super::StreamDecoderMap>,
    pub tool_call_start_token_ids: Vec<u32>,
    pub tool_call_end_token_ids: Vec<u32>,
    pub json_end_token_id: Option<u32>,
    pub tool_call_regex: Regex,
    pub tool_config: ToolConfig,
    pub tool_model_type: ToolModelType,
    pub tool_parser_model_id: String,
    pub enforce_parser: Option<String>,
    pub image_config: Option<ImageProcessConfig>,
    #[cfg(all(feature = "cuda", feature = "graph"))]
    pub capturer: GraphCapturer<CudaGraphWrapper<CudaGraphFn>>,
}

pub struct DefaultLoader {
    model_id: Option<String>,
    weight_path: Option<String>,
    weight_file: Option<String>,
    enforce_parser: Option<String>,
    yarn_scaling_factor: Option<f64>,
}

#[derive(Debug, Clone)]
pub struct DefaultModelPaths {
    pub tokenizer_filename: PathBuf,
    pub tokenizer_config_filename: PathBuf,
    pub config_filename: PathBuf,
    pub generation_config_filename: PathBuf,
    pub filenames: Vec<PathBuf>,
    pub auxiliary_filenames: Vec<PathBuf>,
}

impl DefaultModelPaths {
    fn get_config_filename(&self) -> PathBuf {
        self.config_filename.clone()
    }
    fn get_tokenizer_filename(&self) -> PathBuf {
        self.tokenizer_filename.clone()
    }
    fn get_tokenizer_config_filename(&self) -> PathBuf {
        self.tokenizer_config_filename.clone()
    }
    fn get_weight_filenames(&self) -> Vec<PathBuf> {
        self.filenames.clone()
    }
    fn get_generation_config_filename(&self) -> PathBuf {
        self.generation_config_filename.clone()
    }
    fn get_auxiliary_filenames(&self) -> &[PathBuf] {
        &self.auxiliary_filenames
    }
}

impl DefaultLoader {
    pub fn new(
        model_id: Option<String>,
        weight_path: Option<String>,
        weight_file: Option<String>,
        enforce_parser: Option<String>,
        yarn_scaling_factor: Option<f64>,
    ) -> Self {
        Self {
            model_id,
            weight_path,
            weight_file,
            enforce_parser,
            yarn_scaling_factor,
        }
    }

    fn public_model_name(&self) -> Option<String> {
        if let Some(model_id) = &self.model_id {
            if !model_id.trim().is_empty() {
                return Some(model_id.clone());
            }
        }

        if let Some(weight_path) = &self.weight_path {
            let trimmed = weight_path.trim_end_matches(['/', '\\']);
            let path = Path::new(trimmed);
            if let Some(name) = path.file_name().and_then(|s| s.to_str()) {
                if !name.is_empty() {
                    return Some(name.to_string());
                }
            }
            if let Some(component) = path.components().last() {
                let name = component.as_os_str().to_string_lossy().to_string();
                if !name.is_empty() {
                    return Some(name);
                }
            }
        }

        if let Some(weight_file) = &self.weight_file {
            let path = Path::new(weight_file);
            if let Some(name) = path.file_name().and_then(|s| s.to_str()) {
                if !name.is_empty() {
                    return Some(name.to_string());
                }
            }
        }

        None
    }

    fn is_mmproj_filename(name: &str) -> bool {
        let lower = name.to_ascii_lowercase();
        lower.ends_with(".gguf") && lower.starts_with("mmproj")
    }

    fn mmproj_rank(name: &str, main_filename: Option<&str>) -> i32 {
        let lower = name.to_ascii_lowercase();
        let mut score = 0;
        if let Some(main) = main_filename {
            let exact = format!("mmproj-{}", main.to_ascii_lowercase());
            if lower == exact {
                score += 100;
            }
        }
        if lower.contains("bf16") {
            score += 30;
        }
        if lower.contains("f16") {
            score += 20;
        }
        if lower.contains("f32") {
            score += 5;
        }
        score
    }

    fn pick_mmproj_filename<'a, I>(candidates: I, main_filename: Option<&str>) -> Option<String>
    where
        I: IntoIterator<Item = &'a str>,
    {
        candidates
            .into_iter()
            .filter(|name| Self::is_mmproj_filename(name))
            .max_by(|left, right| {
                let lrank = Self::mmproj_rank(left, main_filename);
                let rrank = Self::mmproj_rank(right, main_filename);
                lrank.cmp(&rrank).then_with(|| left.cmp(right))
            })
            .map(ToString::to_string)
    }

    fn find_local_mmproj_file(main_file: &Path) -> Option<PathBuf> {
        let dir = main_file.parent()?;
        let main_name = main_file.file_name()?.to_str()?;
        let mut candidates = Vec::new();
        for entry in std::fs::read_dir(dir).ok()? {
            let path = entry.ok()?.path();
            if !path.is_file() {
                continue;
            }
            let Some(name) = path.file_name().and_then(|s| s.to_str()) else {
                continue;
            };
            if Self::is_mmproj_filename(name) {
                candidates.push(path);
            }
        }
        candidates.into_iter().max_by(|left, right| {
            let lname = left
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or_default();
            let rname = right
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or_default();
            let lrank = Self::mmproj_rank(lname, Some(main_name));
            let rrank = Self::mmproj_rank(rname, Some(main_name));
            lrank.cmp(&rrank).then_with(|| lname.cmp(rname))
        })
    }
}

impl DefaultLoader {
    fn has_gguf_extension(path: &Path) -> bool {
        path.extension()
            .and_then(|e| e.to_str())
            .map(|e| e.eq_ignore_ascii_case("gguf"))
            .unwrap_or(false)
    }

    fn find_main_gguf_in_dir(dir: &Path) -> Option<PathBuf> {
        let entries = std::fs::read_dir(dir).ok()?;
        let mut candidates: Vec<(PathBuf, u64)> = Vec::new();
        for entry in entries.flatten() {
            let path = entry.path();
            if !path.is_file() || !Self::has_gguf_extension(&path) {
                continue;
            }
            let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
            if Self::is_mmproj_filename(name) {
                continue;
            }
            let size = entry.metadata().map(|m| m.len()).unwrap_or(0);
            candidates.push((path, size));
        }
        if candidates.is_empty() {
            return None;
        }
        candidates.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
        Some(candidates[0].0.clone())
    }

    fn local_gguf_model(main_file: &Path) -> Result<DefaultModelPaths> {
        use crate::backend::gguf::find_gguf_shards;
        if !main_file.exists() {
            candle_core::bail!("GGUF file not found: {}", main_file.display());
        }
        let filenames = find_gguf_shards(main_file);
        let auxiliary_filenames = Self::find_local_mmproj_file(&main_file)
            .map(|p| {
                info!(
                    "Found auxiliary GGUF file for multimodal model: {}",
                    p.display()
                );
                vec![p]
            })
            .unwrap_or_default();
        Ok(DefaultModelPaths {
            tokenizer_filename: PathBuf::new(),
            tokenizer_config_filename: PathBuf::new(),
            config_filename: PathBuf::new(),
            filenames,
            generation_config_filename: "".into(),
            auxiliary_filenames,
        })
    }

    fn local_safetensors_model(path: &str) -> Result<DefaultModelPaths> {
        let path_owned = path.to_string();
        Ok(DefaultModelPaths {
            tokenizer_filename: Path::new(path).join("tokenizer.json"),
            tokenizer_config_filename: Path::new(path).join("tokenizer_config.json"),
            config_filename: Path::new(path).join("config.json"),
            filenames: if Path::new(path)
                .join("model.safetensors.index.json")
                .exists()
            {
                crate::hub_load_local_safetensors(&path_owned, "model.safetensors.index.json")?
            } else {
                vec![Path::new(path).join("model.safetensors")]
            },
            generation_config_filename: if Path::new(path).join("generation_config.json").exists() {
                Path::new(path).join("generation_config.json")
            } else {
                "".into()
            },
            auxiliary_filenames: vec![],
        })
    }

    pub fn prepare_model_weights(
        &self,
        hf_token: Option<String>,
        hf_token_path: Option<String>,
    ) -> Result<(DefaultModelPaths, bool)> {
        let (paths, gguf): (DefaultModelPaths, bool) = match (
            &self.model_id,
            &self.weight_path,
            &self.weight_file,
        ) {
            // --w <local_dir> (or --m normalized to weight_path)
            (None, Some(path), None) => {
                let trimmed = path.trim_end_matches(['/', '\\']);
                let dir = Path::new(trimmed);
                if dir.is_dir() {
                    if let Some(main_gguf) = Self::find_main_gguf_in_dir(dir) {
                        info!(
                            "Auto-detected GGUF model in directory: {}",
                            main_gguf.display()
                        );
                        (Self::local_gguf_model(&main_gguf)?, true)
                    } else {
                        (Self::local_safetensors_model(trimmed)?, false)
                    }
                } else {
                    (Self::local_safetensors_model(trimmed)?, false)
                }
            }
            // --f <local_gguf> (with optional --w prefix)
            (None, path, Some(file)) => {
                let path = path.clone().unwrap_or_default();
                let main_file = Path::new(&path).join(file);
                (Self::local_gguf_model(&main_file)?, true)
            }
            // --m <model_id> --f <remote_gguf_file>
            (Some(_), None, Some(_)) => (self.download_gguf_model(None)?, true),
            // --m <model_id_or_path>
            (Some(model), None, None) => {
                let model_path = Path::new(model);
                if model_path.exists() {
                    if model_path.is_dir() {
                        if let Some(main_gguf) = Self::find_main_gguf_in_dir(model_path) {
                            info!(
                                "Auto-detected GGUF model in directory: {}",
                                main_gguf.display()
                            );
                            (Self::local_gguf_model(&main_gguf)?, true)
                        } else {
                            (
                                Self::local_safetensors_model(
                                    model_path.to_str().unwrap_or(model),
                                )?,
                                false,
                            )
                        }
                    } else if model_path.is_file() && Self::has_gguf_extension(model_path) {
                        (Self::local_gguf_model(model_path)?, true)
                    } else {
                        candle_core::bail!(
                            "--m local file must be a .gguf file. Use --m <dir> for safetensors."
                        );
                    }
                } else {
                    let loaded = self.download_model(None, hf_token.clone(), hf_token_path.clone());
                    if loaded.is_ok() {
                        (loaded.unwrap(), false)
                    } else {
                        info!("Try request model using cached huggingface token...");
                        if hf_token.is_none() && hf_token_path.is_none() {
                            let token_path = format!(
                                "{}/.cache/huggingface/token",
                                dirs::home_dir().unwrap().display()
                            );
                            if !Path::new(&token_path).exists() {
                                use std::io::Write;
                                let mut input_token = String::new();
                                warn!("Unable to request model, please provide your huggingface token to download model:\n");
                                std::io::stdin()
                                    .read_line(&mut input_token)
                                    .expect("Failed to read token!");
                                std::fs::create_dir_all(Path::new(&token_path).parent().unwrap())
                                    .unwrap();
                                let mut output = std::fs::File::create(token_path).unwrap();
                                write!(output, "{}", input_token.trim())
                                    .expect("Failed to save token!");
                            }
                        }
                        (
                            self.download_model(None, hf_token.clone(), hf_token_path.clone())?,
                            false,
                        )
                    }
                }
            }
            _ => {
                candle_core::bail!(
                    "No model provided!\n\
                    Usage:\n  \
                    Local GGUF:        --m /path/to/model.gguf  OR  --f /path/to/model.gguf\n  \
                    Local GGUF dir:    --m /path/to/gguf_dir/\n  \
                    Local safetensors: --m /path/to/hf_dir/  OR  --w /path/to/hf_dir/\n  \
                    Remote safetensors: --m org/model_name\n  \
                    Remote GGUF:       --m org/repo-GGUF --f filename.gguf"
                );
            }
        };

        Ok((paths, gguf))
    }

    pub fn download_model(
        &self,
        revision: Option<String>,
        hf_token: Option<String>,
        hf_token_path: Option<String>,
    ) -> Result<DefaultModelPaths> {
        assert!(self.model_id.is_some(), "No model id provided!");

        let api = ApiBuilder::new()
            .with_progress(true)
            .with_token(Some(get_token(hf_token, hf_token_path)?))
            .build()
            .map_err(candle_core::Error::wrap)?;
        let revision = revision.unwrap_or("main".to_string());
        let api = api.repo(Repo::with_revision(
            self.model_id.clone().unwrap(),
            RepoType::Model,
            revision.clone(),
        ));

        let tokenizer_filename = api
            .get("tokenizer.json")
            .map_err(candle_core::Error::wrap)?;

        let config_filename = api.get("config.json").map_err(candle_core::Error::wrap)?;

        let tokenizer_config_filename = match api.get("tokenizer_config.json") {
            Ok(f) => f,
            _ => "".into(),
        };

        let generation_config_filename = match api.get("generation_config.json") {
            Ok(f) => f,
            _ => "".into(),
        };

        // Cache optional chat template artifacts for fallback loading.
        if api.get("chat_template.jinja").is_err() {
            let _ = api.get("chat_template.json");
        }

        let mut filenames = vec![];
        for rfilename in api
            .info()
            .map_err(candle_core::Error::wrap)?
            .siblings
            .iter()
            .map(|x| x.rfilename.clone())
            .filter(|x| x.ends_with(".safetensors"))
        {
            let filename = api.get(&rfilename).map_err(candle_core::Error::wrap)?;
            filenames.push(filename);
        }

        Ok(DefaultModelPaths {
            tokenizer_filename,
            tokenizer_config_filename,
            config_filename,
            filenames,
            generation_config_filename,
            auxiliary_filenames: vec![],
        })
    }

    fn discover_remote_gguf_shards(filename: &str, remote_files: &HashSet<String>) -> Vec<String> {
        let re = Regex::new(r"^(.+)-(\d{5})-of-(\d{5})\.gguf$").unwrap();
        let Some(caps) = re.captures(filename) else {
            return vec![filename.to_string()];
        };
        let prefix = &caps[1];
        let total: usize = caps[3].parse().unwrap_or(1);

        let mut shards: Vec<String> = (1..=total)
            .map(|i| format!("{}-{:05}-of-{:05}.gguf", prefix, i, total))
            .filter(|name| remote_files.contains(name))
            .collect();

        if shards.len() != total {
            warn!(
                "Expected {} remote GGUF shards but found {}; using only {}",
                total,
                shards.len(),
                filename
            );
            return vec![filename.to_string()];
        }

        shards.sort();
        info!("Found {} remote GGUF shards for {}", shards.len(), prefix);
        shards
    }

    pub fn download_gguf_model(&self, revision: Option<String>) -> Result<DefaultModelPaths> {
        assert!(self.model_id.is_some(), "No model id provided!");
        let mut filename = self.weight_file.clone().unwrap();
        info!(
            "Downloading GGUF file {} from repo {}",
            filename,
            self.model_id.as_ref().unwrap(),
        );
        let api = hf_hub::api::sync::Api::new().unwrap();
        let revision = revision.unwrap_or("main".to_string());
        let repo = api.repo(hf_hub::Repo::with_revision(
            self.model_id.clone().unwrap(),
            hf_hub::RepoType::Model,
            revision.to_string(),
        ));

        let repo_info = repo.info().map_err(candle_core::Error::wrap)?;
        let remote_files: HashSet<String> = repo_info
            .siblings
            .iter()
            .map(|s| s.rfilename.clone())
            .collect();

        // If --f is a subfolder (no .gguf extension), discover GGUF files in it
        if !filename.ends_with(".gguf") {
            let subfolder = filename.trim_end_matches('/').to_string();
            let prefix = format!("{}/", subfolder);
            let mut gguf_files: Vec<String> = remote_files
                .iter()
                .filter(|f| {
                    f.starts_with(&prefix)
                        && f.ends_with(".gguf")
                        && !Self::is_mmproj_filename(f.rsplit('/').next().unwrap_or(f))
                })
                .cloned()
                .collect();
            gguf_files.sort();
            if gguf_files.is_empty() {
                candle_core::bail!(
                    "No GGUF files found in subfolder '{}' of repo {}. \
                     Available files: {:?}",
                    subfolder,
                    self.model_id.as_ref().unwrap(),
                    remote_files.iter().take(20).collect::<Vec<_>>()
                );
            }
            info!(
                "Subfolder '{}' contains {} GGUF file(s); using '{}' as primary",
                subfolder,
                gguf_files.len(),
                gguf_files[0]
            );
            filename = gguf_files[0].clone();
        }

        let mmproj_name =
            Self::pick_mmproj_filename(remote_files.iter().map(|s| s.as_str()), Some(&filename));

        let shard_names = Self::discover_remote_gguf_shards(&filename, &remote_files);

        let mut filenames = vec![];
        for shard_name in &shard_names {
            info!("Downloading GGUF: {}", shard_name);
            let downloaded = repo
                .get(shard_name.as_str())
                .map_err(candle_core::Error::wrap)?;
            filenames.push(downloaded);
        }

        let mut auxiliary_filenames = Vec::new();
        if let Some(mmproj_name) = mmproj_name {
            info!(
                "Downloading auxiliary GGUF file {} from repo {}",
                mmproj_name,
                self.model_id.as_ref().unwrap(),
            );
            let mmproj_path = repo
                .get(mmproj_name.as_str())
                .map_err(candle_core::Error::wrap)?;
            auxiliary_filenames.push(mmproj_path);
        }

        Ok(DefaultModelPaths {
            tokenizer_filename: "".into(),
            tokenizer_config_filename: "".into(),
            config_filename: "".into(),
            filenames,
            generation_config_filename: "".into(),
            auxiliary_filenames,
        })
    }

    //support loading in both multithreaded and multiprocess mode
    #[allow(unused_variables)]
    pub async fn load_model(
        &self,
        paths: DefaultModelPaths,
        dtype: DType,
        kv_cache_dtype: DType,
        gguf: bool,
        isq: Option<String>,
        block_size: usize,
        max_num_seqs: usize,
        device_ids: Vec<usize>, //pass only 1 device_id in multiprocess mode, otherwise, multiple device_ids in multithread mode
        #[cfg(feature = "nccl")] comm_id: Option<crate::openai::distributed::Id>, //must pass comm id in multiprocess mode
        local_rank: Option<usize>, //must pass current rank in multiprocess mode
        local_world_size: Option<usize>, //must pass the number of local devices used in multiprocess mode
        #[cfg(feature = "nccl")] global_rank: Option<usize>, //must pass current global rank in multi-node mode
        #[cfg(feature = "nccl")] global_world_size: Option<usize>, //must pass total number of devices used in multi-node mode
    ) -> Result<(Vec<Box<DefaultPipeline>>, PipelineConfig)> {
        let reporter = Arc::new(RwLock::new(ProgressReporter::new(local_rank.unwrap_or(0))));
        let num_subprogress = local_world_size.map_or(0, |n| n - 1);
        #[cfg(feature = "nccl")]
        let pipeline_num_shards = global_world_size
            .or(local_world_size)
            .unwrap_or(device_ids.len());
        #[cfg(not(feature = "nccl"))]
        let pipeline_num_shards = local_world_size.unwrap_or(device_ids.len());
        let _guard = candle_core::InferenceMode::enter();
        attention_rs::reset_paged_attention_layer_counter();
        let (models, devices, config, sep_style) = if gguf {
            let device = crate::new_device(device_ids[0]).unwrap();
            let path = paths.get_weight_filenames()[0].clone();
            info!("Loading quantized model from file {}", path.display());
            let (arch, nlayers) = {
                let mut file = match std::fs::File::open(path.clone())
                    .map_err(candle_core::Error::wrap)
                {
                    Ok(file) => file,
                    Err(e) => {
                        tracing::error!("Failed to open gguf file {}: {}\n ***Tips: use `--w` to load safetensors models.", path.display(), e);
                        return Err(e);
                    }
                };
                let content = match gguf_file::Content::read(&mut file)
                    .map_err(|e| e.with_path(path.clone()))
                    .map_err(candle_core::Error::wrap)
                {
                    Ok(content) => content,
                    Err(e) => {
                        tracing::error!("Failed to open gguf file {}: {}\n ***Tips: use `--w` to load safetensors models.", path.display(), e);
                        return Err(e);
                    }
                };
                let (arch, nlayers) =
                    gguf::get_arch_and_num_of_layers(content).map_err(candle_core::Error::wrap)?;
                if !matches!(
                    arch.as_str(),
                    "llama"
                        | "llama3"
                        | "phi3"
                        | "qwen2"
                        | "qwen3"
                        | "qwen2moe"
                        | "qwen3moe"
                        | "qwen35"
                        | "qwen35moe"
                        | "glm4"
                        | "glm-dsa"
                        | "deepseek2"
                ) {
                    panic!("Model arch {} not supported!", arch);
                } else {
                    info!("Quantized {} model has {} layers.", arch, nlayers,);
                }
                (arch, nlayers)
            };
            let handle =
                progress_worker(Some(num_subprogress), nlayers, Arc::clone(&reporter)).await;
            let gguf_shard_paths = paths.get_weight_filenames();
            if gguf_shard_paths.len() > 1 {
                info!(
                    "Loading {} GGUF shard files for model",
                    gguf_shard_paths.len()
                );
            }
            let vb = QVarBuilder::from_gguf_files(&gguf_shard_paths, &device)
                .map_err(candle_core::Error::wrap)?;
            let gguf_rank = local_rank.unwrap_or(0);
            let gguf_world_size = pipeline_num_shards;
            #[cfg(feature = "nccl")]
            let gguf_comm: crate::openai::distributed::Rc<
                crate::openai::distributed::Comm,
            > = {
                use crate::openai::distributed::{Comm, Id, Rc};
                let id = if let Some(id) = comm_id {
                    id
                } else {
                    Id::new().unwrap()
                };
                let global_r = global_rank.unwrap_or(gguf_rank);
                let global_ws = global_world_size.unwrap_or(gguf_world_size);
                Rc::new(
                    Comm::from_rank(
                        device.as_cuda_device().unwrap().cuda_device(),
                        global_r,
                        global_ws,
                        id,
                    )
                    .expect("Failed to create NCCL communicator for GGUF"),
                )
            };
            #[cfg(not(feature = "nccl"))]
            let gguf_comm =
                crate::openai::distributed::Rc::new(crate::openai::distributed::Comm::default());

            let (model, config, sep_style) = match arch.as_str() {
                "llama" => {
                    let model = GGUFLLaMa::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::LlamaGGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::Llama,
                    )
                }
                "llama3" => {
                    let model = GGUFLLaMa::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::LlamaGGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::Llama3,
                    )
                }
                "phi3" => {
                    let model = GGUFPhi3::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::Phi3GGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::Phi,
                    )
                }
                "qwen2" | "qwen3" => {
                    let model = GGUFQWen::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::QWenGGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::Qwen,
                    )
                }
                "qwen2moe" | "qwen3moe" => {
                    let model = GGUFQWenMoE::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::QWenGGUFMoE(Arc::new(model)),
                        cfg,
                        SeparatorStyle::Qwen,
                    )
                }
                "qwen35" => {
                    let model = GGUFQWen3_5::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    let aux_files = paths.get_auxiliary_filenames();
                    if let Some(aux_path) = aux_files.first() {
                        info!(
                            "Loading GGUF multimodal vision tower from {}",
                            aux_path.display()
                        );
                        let gguf_info = {
                            let mut r = std::fs::File::open(path.clone())
                                .map_err(candle_core::Error::wrap)?;
                            let mut readers = vec![&mut r];
                            let ct =
                                crate::backend::gguf::Content::from_readers(&mut readers).unwrap();
                            crate::backend::gguf::get_gguf_info(&ct)
                                .map_err(candle_core::Error::wrap)?
                        };
                        let text_model = Qwen3TextModel::Dense35GGUF(model);
                        let (vl_model, vl_cfg) = Qwen3VLForConditionalGeneration::from_gguf(
                            text_model,
                            &cfg,
                            aux_path,
                            &gguf_info.tokenizer,
                            dtype,
                            &device,
                        )?;
                        (
                            LLMModel::Qwen3VL(Arc::new(vl_model)),
                            vl_cfg,
                            SeparatorStyle::Qwen,
                        )
                    } else {
                        warn!("No auxiliary GGUF mmproj file found. Vision is disabled; running in text-only mode.");
                        (
                            LLMModel::QWen3_5GGUF(Arc::new(model)),
                            cfg,
                            SeparatorStyle::Qwen,
                        )
                    }
                }
                "qwen35moe" => {
                    let model = GGUFQWen3_5MoE::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    let aux_files = paths.get_auxiliary_filenames();
                    if let Some(aux_path) = aux_files.first() {
                        info!(
                            "Loading GGUF multimodal vision tower from {}",
                            aux_path.display()
                        );
                        let gguf_info = {
                            let mut r = std::fs::File::open(path.clone())
                                .map_err(candle_core::Error::wrap)?;
                            let mut readers = vec![&mut r];
                            let ct =
                                crate::backend::gguf::Content::from_readers(&mut readers).unwrap();
                            crate::backend::gguf::get_gguf_info(&ct)
                                .map_err(candle_core::Error::wrap)?
                        };
                        let text_model = Qwen3TextModel::MoE35GGUF(model);
                        let (vl_model, vl_cfg) = Qwen3VLForConditionalGeneration::from_gguf(
                            text_model,
                            &cfg,
                            aux_path,
                            &gguf_info.tokenizer,
                            dtype,
                            &device,
                        )?;
                        (
                            LLMModel::Qwen3VL(Arc::new(vl_model)),
                            vl_cfg,
                            SeparatorStyle::Qwen,
                        )
                    } else {
                        warn!("No auxiliary GGUF mmproj file found. Vision is disabled; running in text-only mode.");
                        (
                            LLMModel::QWen3_5GGUFMoE(Arc::new(model)),
                            cfg,
                            SeparatorStyle::Qwen,
                        )
                    }
                }
                "glm4" => {
                    let model = GGUFGLM4::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::GLM4GGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::GLM,
                    )
                }
                "glm-dsa" => {
                    let model = GGUFDeepSeek::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::GLM5GGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::GLM,
                    )
                }
                "deepseek2" => {
                    let model = GGUFDeepSeek::from_gguf(
                        &vb,
                        &device,
                        dtype,
                        kv_cache_dtype,
                        self.yarn_scaling_factor,
                        Arc::clone(&reporter),
                        gguf_rank,
                        gguf_world_size,
                        gguf_comm.clone(),
                    )
                    .map_err(candle_core::Error::wrap)?;
                    let cfg = model.get_config().clone();
                    (
                        LLMModel::DeepSeekGGUF(Arc::new(model)),
                        cfg,
                        SeparatorStyle::AddColonSingle,
                    )
                }
                _ => panic!("Model not supported!"),
            };
            handle.join().unwrap();
            (vec![model], vec![device], config.to_owned(), sep_style)
        } else {
            let cfile = paths.get_config_filename();
            let arch = Config::get_model_arch(&cfile)?;

            let mut config = match arch.as_str() {
                "LlamaForCausalLM" => Llama::load_config(&cfile, isq.clone())?,
                "Llama4ForConditionalGeneration" => {
                    LLama4ForConditionalGeneration::load_config(&cfile, isq.clone())?
                }
                "PhiForCausalLM" | "Phi2ForCausalLM" => Phi2::load_config(&cfile, isq.clone())?,
                "Phi3ForCausalLM" | "Phi4ForCausalLM" => Phi4::load_config(&cfile, isq.clone())?,
                "Qwen2ForCausalLM" | "Qwen3ForCausalLM" | "Qwen3VLForConditionalGeneration" => {
                    Qwen::load_config(&cfile, isq.clone())?
                }
                "Qwen3_5ForCausalLM" | "Qwen3_5ForConditionalGeneration" => {
                    Qwen3_5::load_config(&cfile, isq.clone())?
                }
                "Qwen2MoeForCausalLM"
                | "Qwen3MoeForCausalLM"
                | "Qwen3VLMoeForConditionalGeneration" => {
                    Qwen3MoE::load_config(&cfile, isq.clone())?
                }
                "Qwen3_5MoeForCausalLM" | "Qwen3_5MoeForConditionalGeneration" => {
                    Qwen3_5MoE::load_config(&cfile, isq.clone())?
                }
                "Qwen3NextForCausalLM" | "Qwen3NextForConditionalGeneration" => {
                    Qwen3_5MoE::load_config(&cfile, isq.clone())?
                }
                "Gemma2ForCausalLM" => Gemma::load_config(&cfile, isq.clone())?,
                "Gemma3ForConditionalGeneration" => Gemma3::load_config(&cfile, isq.clone())?,
                "Gemma4ForConditionalGeneration" | "Gemma4ForCausalLM" => {
                    Gemma4::load_config(&cfile, isq.clone())?
                }
                "MistralForCausalLM" => Mistral::load_config(&cfile, isq.clone())?,
                "Mistral3ForConditionalGeneration" => {
                    Mistral::load_text_config(&cfile, isq.clone())?
                }
                "yi" => Yi::load_config(&cfile, isq.clone())?,
                "StableLmForCausalLM" => StableLM::load_config(&cfile, isq.clone())?,
                "Glm4ForCausalLM" => GLM4::load_config(&cfile, isq.clone())?,
                "Glm4MoeLiteForCausalLM" => {
                    GLM4MoeLiteForCausalLM::load_config(&cfile, isq.clone())?
                }
                "DeepseekV2ForCausalLM"
                | "DeepseekV3ForCausalLM"
                | "DeepseekV32ForCausalLM"
                | "GlmMoeDsaForCausalLM" => DeepSeek::load_config(&cfile, isq.clone())?,
                "MiniMaxM2ForCausalLM" => MiniMaxForCausalLM::load_config(&cfile, isq.clone())?,
                _ => panic!("Model not supported!"),
            };
            if !matches!(
                arch.as_str(),
                "DeepseekV2ForCausalLM"
                    | "DeepseekV3ForCausalLM"
                    | "DeepseekV32ForCausalLM"
                    | "GlmMoeDsaForCausalLM"
                    | "Glm4MoeLiteForCausalLM"
                    | "Llama4ForConditionalGeneration"
                    | "MiniMaxM2ForCausalLM"
            ) {
                config.apply_runtime_rope_overrides(self.yarn_scaling_factor);
            }
            let global_kvcache = crate::openai::models::KvCacheDtype::get_global();
            if global_kvcache != crate::openai::models::KvCacheDtype::Auto {
                if global_kvcache.is_turboquant()
                    && !cfg!(feature = "cuda")
                    && !cfg!(feature = "metal")
                {
                    tracing::warn!(
                        "TurboQuant ({:?}) requires CUDA or Metal, ignoring on this platform.",
                        global_kvcache
                    );
                } else {
                    config.kvcache_dtype = global_kvcache;
                }
            } else if kv_cache_dtype == DType::U8 {
                config.kvcache_dtype = crate::openai::models::KvCacheDtype::Fp8;
            }

            if let Some(qcfg) = &mut config.quantization_config {
                qcfg.normalize_compressed_tensors();
                if let Some(mode) = &qcfg.mode {
                    if mode.eq_ignore_ascii_case("mxfp4") {
                        panic!(
                            "MLX-quantized models (mode=\"{}\") are not supported. \
                             MLX MXFP4 uses an unsupported packing format. \
                             Please use a modelopt or compressed-tensors quantized model instead \
                             (e.g. an MLX NVFP4 model or nvidia/*-NVFP4).",
                            mode
                        );
                    }
                }
                assert!(
                    qcfg.quant_method == "gptq"
                        || qcfg.quant_method == "awq"
                        || qcfg.quant_method == "fp8"
                        || qcfg.quant_method == "mxfp4"
                        || qcfg.quant_method == "nvfp4"
                        || qcfg.quant_method == "marlin",
                    "Invalid quantization format! Only `gptq`, `awq`, `fp8`, `mxfp4` and `nvfp4` supported, got `{}`",
                    qcfg.quant_method
                );
            }

            config.is_f16_mode = dtype == DType::F16;

            info!("Model {:?}", config);

            info!("Loading {} model.", arch);
            let handle = progress_worker(
                Some(num_subprogress),
                config.num_hidden_layers,
                Arc::clone(&reporter),
            )
            .await;

            use crate::openai::distributed::Comm;
            #[cfg(feature = "nccl")]
            let id = if comm_id.is_some() {
                comm_id.unwrap()
            } else {
                candle_core::cuda_backend::cudarc::nccl::safe::Id::new().unwrap()
            };
            #[cfg(feature = "nccl")]
            assert!(
                (comm_id.is_some() && device_ids.len() == 1)
                    || (comm_id.is_none() && device_ids.len() >= 1)
            );
            let results: Vec<_> = device_ids
                .par_iter()
                .enumerate()
                .map(|(rank, dev_id)| {
                    #[cfg(feature = "nccl")]
                    let rank = if global_rank.is_some() {
                        global_rank.unwrap()
                    } else {
                        rank
                    };
                    #[cfg(feature = "nccl")]
                    let num_shards = if global_world_size.is_some() {
                        global_world_size.unwrap()
                    } else {
                        device_ids.len()
                    };

                    let paths: Vec<PathBuf> = paths.get_weight_filenames();
                    let device = crate::new_device(*dev_id).unwrap();
                    #[cfg(feature = "nccl")]
                    let _ = device.as_cuda_device().unwrap().bind_to_thread();

                    #[cfg(feature = "nccl")]
                    tracing::warn!(
                        "create nccl comm channel rank {}, shards {}, id {:?}",
                        rank,
                        num_shards,
                        id
                    );

                    #[cfg(feature = "nccl")]
                    let comm = Rc::new(
                        Comm::from_rank(
                            device.as_cuda_device().unwrap().cuda_device(),
                            rank,
                            num_shards,
                            id,
                        )
                        .unwrap(),
                    );
                    #[cfg(feature = "nccl")]
                    tracing::warn!("nccl comm created for rank {}", rank);

                    #[cfg(not(feature = "nccl"))]
                    let comm = Rc::new(Comm::default());

                    let vb = unsafe {
                        candle_nn::var_builder::ShardedSafeTensors::var_builder(
                            &paths, dtype, &device,
                        )
                        .unwrap()
                    };

                    let (model, sep) = match arch.as_str() {
                        "LlamaForCausalLM" => (
                            LLMModel::Llama(Arc::new(
                                Llama::load(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Llama3,
                        ),
                        "Llama4ForConditionalGeneration" => (
                            LLMModel::LLaMa4(Arc::new(
                                LLama4ForConditionalGeneration::new(
                                    &vb,
                                    comm,
                                    &config,
                                    dtype,
                                    &device,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Llama3,
                        ),
                        "PhiForCausalLM" | "Ph2ForCausalLM" => (
                            LLMModel::Phi2(Arc::new(
                                Phi2::new(vb, &config, dtype, &device, comm, Arc::clone(&reporter))
                                    .unwrap(),
                            )),
                            SeparatorStyle::Phi,
                        ),
                        "Phi3ForCausalLM" | "Phi4ForCausalLM" => (
                            LLMModel::Phi4(Arc::new(
                                Phi4::new(vb, &config, dtype, &device, comm, Arc::clone(&reporter))
                                    .unwrap(),
                            )),
                            SeparatorStyle::Phi,
                        ),
                        "Qwen2ForCausalLM" | "Qwen3ForCausalLM" => (
                            LLMModel::Qwen(Arc::new(
                                Qwen::new(vb, &config, dtype, &device, comm, Arc::clone(&reporter))
                                    .unwrap(),
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        "Qwen3_5ForCausalLM" => (
                            LLMModel::Qwen3_5(Arc::new(
                                Qwen3_5::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .map_err(|e| {
                                    candle_core::Error::msg(format!(
                                        "Failed to load Qwen3.5 model for arch {} on rank {}: {}",
                                        arch, rank, e
                                    ))
                                })?
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        "Qwen3_5ForConditionalGeneration" => (
                            LLMModel::Qwen3VL(Arc::new(
                                Qwen3VLForConditionalGeneration::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .map_err(|e| {
                                    candle_core::Error::msg(format!(
                                        "Failed to load Qwen3-VL model for arch {} on rank {}: {}",
                                        arch, rank, e
                                    ))
                                })?,
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        "Qwen2MoeForCausalLM" | "Qwen3MoeForCausalLM" => (
                            LLMModel::Qwen3MoE(Arc::new(
                                Qwen3MoE::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        "Qwen3_5MoeForCausalLM" | "Qwen3NextForCausalLM" => (
                            LLMModel::Qwen3_5MoE(Arc::new(
                                Qwen3_5MoE::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .map_err(|e| {
                                    candle_core::Error::msg(format!(
                                        "Failed to load Qwen3.5-MoE model for arch {} on rank {}: {}",
                                        arch, rank, e
                                    ))
                                })?,
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        "Qwen3_5MoeForConditionalGeneration"
                        | "Qwen3NextForConditionalGeneration"
                        | "Qwen3VLForConditionalGeneration"
                        | "Qwen3VLMoeForConditionalGeneration" => (
                            LLMModel::Qwen3VL(Arc::new(
                                Qwen3VLForConditionalGeneration::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .map_err(|e| {
                                    candle_core::Error::msg(format!(
                                        "Failed to load Qwen3-VL model for arch {} on rank {}: {}",
                                        arch, rank, e
                                    ))
                                })?,
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        "Gemma2ForCausalLM" => (
                            LLMModel::Gemma(Arc::new(
                                Gemma::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Gemma,
                        ),
                        "Gemma3ForConditionalGeneration" => (
                            LLMModel::Gemma3VL(Arc::new(
                                Gemma3ForConditionalGeneration::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Gemma,
                        ),
                        "Gemma4ForConditionalGeneration" | "Gemma4ForCausalLM" => (
                            LLMModel::Gemma4(Arc::new(
                                Gemma4::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Gemma,
                        ),
                        "MistralForCausalLM" => (
                            LLMModel::Mistral(Arc::new(
                                Mistral::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Mistral,
                        ),
                        "Mistral3ForConditionalGeneration" => (
                            LLMModel::Mistral3VL(Arc::new(
                                Mistral3ForConditionalGeneration::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .map_err(|e| {
                                    candle_core::Error::msg(format!(
                                        "Failed to load Mistral3-VL model for arch {} on rank {}: {}",
                                        arch, rank, e
                                    ))
                                })?,
                            )),
                            SeparatorStyle::Mistral,
                        ),
                        "yi" => (
                            LLMModel::Yi(Arc::new(
                                Yi::new(vb, &config, dtype, &device, comm, Arc::clone(&reporter))
                                    .unwrap(),
                            )),
                            SeparatorStyle::Yi,
                        ),
                        "StableLmForCausalLM" => (
                            LLMModel::StableLM(Arc::new(
                                StableLM::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::StableLM,
                        ),
                        "Glm4ForCausalLM" => (
                            LLMModel::GLM4(Arc::new(
                                GLM4::new(vb, &config, dtype, &device, comm, Arc::clone(&reporter))
                                    .unwrap(),
                            )),
                            SeparatorStyle::Llama,
                        ),
                        "Glm4MoeLiteForCausalLM" => (
                            LLMModel::GLM4MoeLite(Arc::new(
                                GLM4MoeLiteForCausalLM::new(
                                    &vb,
                                    comm,
                                    &config,
                                    dtype,
                                    false,
                                    &device,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Llama,
                        ),
                        "DeepseekV2ForCausalLM"
                        | "DeepseekV3ForCausalLM"
                        | "DeepseekV32ForCausalLM" => (
                            LLMModel::DeepSeek(Arc::new(
                                DeepSeek::load(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Llama3,
                        ),
                        "GlmMoeDsaForCausalLM" => (
                            LLMModel::GLM5(Arc::new(
                                DeepSeek::load(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .unwrap(),
                            )),
                            SeparatorStyle::Llama,
                        ),
                        "MiniMaxM2ForCausalLM" => (
                            LLMModel::MiniMax(Arc::new(
                                MiniMaxForCausalLM::new(
                                    vb,
                                    &config,
                                    dtype,
                                    &device,
                                    comm,
                                    Arc::clone(&reporter),
                                )
                                .map_err(|e| {
                                    candle_core::Error::msg(format!(
                                        "Failed to load MiniMax model for arch {} on rank {}: {}",
                                        arch, rank, e
                                    ))
                                })?,
                            )),
                            SeparatorStyle::Qwen,
                        ),
                        _ => panic!("Model not supported!"),
                    };

                    Ok((model, device, sep))
                })
                .collect();
            let has_err = results.iter().any(|r| r.is_err());
            if has_err {
                reporter.write().set_progress(config.num_hidden_layers);
            }
            handle.join().unwrap();
            // Separate devices and models from the results
            let mut devices = Vec::new();
            let mut models = Vec::new();
            let mut sep_style = Vec::new();

            for result in results {
                match result {
                    Ok((model, device, sep)) => {
                        devices.push(device);
                        models.push(model);
                        sep_style.push(sep)
                    }
                    Err(e) => {
                        return Err(e);
                    }
                }
            }

            (models, devices, config, sep_style[0].clone())
        };

        warn!("Done loading.");

        //max and min number of tokens generated per request
        let default_max_tokens = (config.max_seq_len / 5).clamp(MIN_GEN_TOKENS, MAX_GEN_TOKENS);

        let cfg_file = paths.get_generation_config_filename();
        let generation_cfg = if cfg_file.display().to_string() != "" && Path::exists(&cfg_file) {
            let str_cfg: Option<String> = std::fs::read_to_string(cfg_file).ok();
            let cfg: GenerationConfig = serde_json::from_str(str_cfg.unwrap().as_str()).unwrap();
            Some(cfg)
        } else {
            None
        };

        let pipeline_config = PipelineConfig {
            max_model_len: config.max_seq_len,
            default_max_tokens,
            generation_cfg,
        };

        #[cfg(feature = "nccl")]
        let global_rank = global_rank.unwrap_or(0);
        #[cfg(not(feature = "nccl"))]
        let global_rank = local_rank.unwrap_or(0);

        let public_model_name = self.public_model_name();
        let pipelines = models
            .into_iter()
            .enumerate()
            .map(|(rank, model)| {
                let logits_processor = {
                    LogitsProcessor::new(
                        SAMPLING_SEED,
                        None,
                        None,
                        None,
                        None,
                    )
                };
                let tokenizer_file = paths.get_tokenizer_filename();
                let (tokenizer, chat_template, bos_token, eos_token): (
                    Tokenizer,
                    Option<String>,
                    Option<String>,
                    Option<String>,
                ) = if tokenizer_file.display().to_string() != "" && Path::exists(&tokenizer_file) {
                    let mut tokenizer = Tokenizer::from_file(tokenizer_file.clone())
                        .map_err(candle_core::Error::wrap).unwrap();
                    let _ = tokenizer.with_truncation(None);
                    let _ = tokenizer.with_padding(None);

                    let tokenizer_cfg_file = paths.get_tokenizer_config_filename();
                    let (mut chat_template, bos, eos) = if Path::exists(&tokenizer_cfg_file) {
                        let tokenizer_cfg: Option<String> =
                            std::fs::read_to_string(tokenizer_cfg_file).ok();
                        let cfg_tokenizer: TokenizerConfig =
                            serde_json::from_str(tokenizer_cfg.unwrap().as_str()).unwrap();
                        (
                            cfg_tokenizer.chat_template,
                            cfg_tokenizer.bos_token,
                            cfg_tokenizer.eos_token,
                        )
                    } else {
                        (None, None, None)
                    };

                    if chat_template.is_none() {
                        if let Some(tokenizer_dir) = tokenizer_file.parent() {
                            let chat_template_jinja = tokenizer_dir.join("chat_template.jinja");
                            let chat_template_json = tokenizer_dir.join("chat_template.json");
                            if Path::exists(&chat_template_jinja) {
                                chat_template = std::fs::read_to_string(chat_template_jinja).ok();
                            } else if Path::exists(&chat_template_json) {
                                chat_template = std::fs::read_to_string(chat_template_json)
                                    .ok()
                                    .and_then(|raw| {
                                        if let Ok(v) =
                                            serde_json::from_str::<serde_json::Value>(&raw)
                                        {
                                            v.get("chat_template")
                                                .and_then(|s| s.as_str())
                                                .map(|s| s.to_string())
                                                .or_else(|| v.as_str().map(|s| s.to_string()))
                                        } else {
                                            Some(raw)
                                        }
                                    });
                            }
                        }
                    }
                    (tokenizer, chat_template, bos, eos)
                } else if gguf {
                    use crate::backend::gguf::{get_gguf_info, Content, GGUFInfo};
                    let gguf_paths = paths.get_weight_filenames();
                    let mut files: Vec<std::fs::File> = gguf_paths
                        .iter()
                        .map(|p| std::fs::File::open(p).unwrap())
                        .collect();
                    let mut readers: Vec<&mut std::fs::File> =
                        files.iter_mut().collect();
                    let content = Content::from_readers(&mut readers).unwrap();
                    let GGUFInfo {
                        tokenizer,
                        bos,
                        eos,
                        unk: _,
                        context_length: _,
                        chat_template,
                    } = get_gguf_info(&content).unwrap();
                    (
                        tokenizer,
                        chat_template,
                        bos,
                        eos,
                    )
                } else {
                    panic!("Missing tokenizer file!");
                };

                if rank == 0 && global_rank == 0 {
                    if chat_template.is_some() {
                        info!("Chat Template {} \n", chat_template.as_ref().unwrap());
                    } else {
                        info!("Warning: Missing tokenizer_config.json \n Warning: Chat Template not found, use built-in template which may not correct!");
                    }
                    info!("{:?}", pipeline_config);
                }

                let mut stop_token_ids = Vec::<u32>::new();
                if let Some(eos_token_id) = &config.eos_token_id {
                    match eos_token_id {
                        TokenID(Either::Left(eos_token)) => {
                            if let Some(tk) = eos_token {
                                stop_token_ids.push(*tk);
                            }
                        }
                        TokenID(Either::Right(eos_token_list)) => {
                            if let Some(tks) = eos_token_list {
                                stop_token_ids.extend(tks)
                            }
                        }
                    }
                }
                //custom stop tokens
                if let Some(custom_stop) = &config.custom_stop_tokens {
                    for stop in custom_stop {
                        if let Some(token) = tokenizer.get_vocab(true).get(stop).copied() {
                            stop_token_ids.push(token)
                        };
                    }
                }

                if let Some(eos) = &eos_token {
                    if let Some(token) = tokenizer.get_vocab(true).get(eos).copied() {
                        if !stop_token_ids.contains(&token) {
                            stop_token_ids.push(token)
                        }
                    };
                }

                if let Some(template) = chat_template.as_ref() {
                    if template.contains("<|eom_id|>") {
                        tracing::warn!("custom stop token <|eom_id|> in chat template");
                        stop_token_ids.push(128008);
                    }
                    if template.contains("<|eot_id|>") {
                        tracing::warn!("custom stop token <|eot_id|> in chat template");
                        stop_token_ids.push(128009);
                    }
                    if template.contains("<|end|>") {
                        tracing::warn!("custom stop token <|end|> in chat template");
                        if let Some(token) = tokenizer.get_vocab(true).get("<|end|>").copied() {
                            stop_token_ids.push(token);
                        }
                    }
                }

                if stop_token_ids.is_empty() {
                    //if no eos_token defined in the config, use default
                    if let Some(token) = tokenizer.get_vocab(true).get("<|endoftext|>").copied() {
                        stop_token_ids.push(token);
                    }
                    if let Some(token) = tokenizer.get_vocab(true).get("<|end|>").copied() {
                        stop_token_ids.push(token);
                    } else if stop_token_ids.is_empty() {
                        let token = tokenizer.token_to_id(EOS_TOKEN).unwrap_or(0);
                        stop_token_ids.push(token);
                    }
                }
                tracing::warn!("stop_token_ids {:?}", stop_token_ids);

                let conversation = DefaultConversation::new(
                    config.architectures.as_ref().unwrap()[0].clone(),
                    chat_template.clone(),
                    Vec::default(),
                    sep_style.clone(),
                    bos_token.clone(),
                    eos_token.clone(),
                    ("user".to_string(), "assistant".to_string()),
                    DefaultConversationSeparators {
                        sep: " ".to_string(),
                        sep2: Some(" </s></s>".to_string()),
                    },
                );

                Box::new(DefaultPipeline::new(
                        model,
                        tokenizer,
                        logits_processor,
                        &config,
                        conversation,
                        dtype,
                        &devices[rank],
                        stop_token_ids,
                        rank,
                        public_model_name.clone(),
                        self.model_id.clone(),
                        self.enforce_parser.clone(),
                        kv_cache_dtype,
                        pipeline_num_shards,
                        #[cfg(all(feature = "cuda", feature = "graph"))]
                        block_size,
                        #[cfg(all(feature = "cuda", feature = "graph"))]
                        max_num_seqs,
                    ).unwrap()
                )
            })
            .collect();

        Ok((pipelines, pipeline_config))
    }
}

impl DefaultPipeline {
    fn output_contains_tool_call_start(&self, seq: &Arc<Sequence>) -> bool {
        if !self.tool_call_start_token_ids.is_empty() {
            return seq
                .deref()
                .get_output_tokens()
                .iter()
                .any(|logprob| self.tool_call_start_token_ids.contains(&logprob.token));
        }
        if self.tool_config.start_token_str.is_empty() {
            return false;
        }

        let mut generated = String::new();
        for logprob in seq.deref().get_output_tokens() {
            generated.push_str(&logprob.bytes);
        }
        generated.contains(&self.tool_config.start_token_str)
    }

    fn is_nested_tool_call_start(&self, seq: &Arc<Sequence>, next_token: u32, text: &str) -> bool {
        let next_is_start = if !self.tool_call_start_token_ids.is_empty() {
            self.tool_call_start_token_ids.contains(&next_token)
        } else {
            !self.tool_config.start_token_str.is_empty()
                && text.contains(&self.tool_config.start_token_str)
        };

        next_is_start && self.output_contains_tool_call_start(seq)
    }

    pub fn new(
        model: LLMModel,
        tokenizer: Tokenizer,
        logits_processor: LogitsProcessor,
        config: &Config,
        conversation: DefaultConversation,
        dtype: DType,
        device: &Device,
        stop_token_ids: Vec<u32>,
        rank: usize,
        model_name: Option<String>,
        tool_parser_model_id: Option<String>,
        enforce_parser: Option<String>,
        _kv_cache_dtype: DType,
        _num_shards: usize,
        #[cfg(all(feature = "cuda", feature = "graph"))] block_size: usize,
        #[cfg(all(feature = "cuda", feature = "graph"))] max_num_seqs: usize,
    ) -> Result<Self> {
        #[cfg(all(feature = "cuda", feature = "graph"))]
        let wrapper = crate::graph_model_wrapper!(
            model,
            device,
            Llama,
            LLaMa4,
            Phi2,
            Phi4,
            Qwen,
            Qwen3MoE,
            Qwen3_5,
            Qwen3_5MoE,
            Gemma,
            Gemma3,
            Gemma4,
            MiniMax,
            Mistral,
            Yi,
            StableLM,
            GLM4,
            GLM4MoeLite,
            DeepSeek,
            GLM5,
            LlamaGGUF,
            Phi3GGUF,
            QWenGGUF,
            QWenGGUFMoE,
            QWen3_5GGUF,
            QWen3_5GGUFMoE,
            GLM4GGUF,
            GLM5GGUF,
            DeepSeekGGUF,
        );
        #[cfg(all(feature = "cuda", feature = "graph", feature = "flashinfer"))]
        let skip_flashinfer = config.kvcache_dtype.is_turboquant()
            || (config.kvcache_dtype.is_fp8_keys() && !attention_rs::has_flashinfer_fp8_e4m3())
            || config.gemma4_per_layer_cache_config().is_some();

        #[cfg(feature = "cuda")]
        if dtype == DType::F16 {
            let sm = device
                .as_cuda_device()
                .ok()
                .and_then(|d| attention_rs::cuda_utils::sm_version(d))
                .unwrap_or(0);
            if sm >= 80 {
                let _will_use_native_flash = {
                    #[cfg(feature = "flashinfer")]
                    {
                        skip_flashinfer
                    }
                    #[cfg(all(feature = "flashattn", not(feature = "flashinfer")))]
                    {
                        config.kvcache_dtype.is_turboquant()
                            || (config.kvcache_dtype.is_fp8_keys() && sm != 90)
                    }
                    #[cfg(not(any(feature = "flashinfer", feature = "flashattn")))]
                    {
                        true
                    }
                };
                if _will_use_native_flash {
                    candle_core::bail!(
                        "F16 dtype is not supported with native flash attention on SM80+ (detected SM{}). \
                         Native flash kernels on SM80+ are compiled for BF16 only. \
                         Use --dtype bf16 (default), or build with flashinfer/flashattn features which support F16.",
                        sm
                    );
                }
            }
        }

        #[cfg(all(feature = "cuda", feature = "graph", feature = "flashinfer"))]
        let flashinfer_kv_params = if skip_flashinfer {
            if config.kvcache_dtype.is_turboquant() {
                tracing::info!(
                    "Use native flash backend ({:?} kvcache, flashinfer disabled)",
                    config.kvcache_dtype
                );
            }
            None
        } else if config.is_mla() {
            Some(FlashInferKvParams {
                kv_dtype: _kv_cache_dtype,
                out_dtype: dtype,
                page_size: block_size,
                num_kv_heads: 1,
                head_dim: config.mla_kv_lora_rank(),
                num_qo_heads: config.num_attention_heads,
            })
        } else if let Some(per_layer_cfg) = config.gemma4_per_layer_cache_config() {
            // For Gemma4 with heterogeneous head_dim, find the first layer with head_dim <= 256
            // FlashInfer can be used for those layers, paged attention for others
            let flash_compatible = per_layer_cfg.iter().find(|(_kv_heads, hd)| *hd <= 256);
            if let Some(&(kv_heads, hd)) = flash_compatible {
                Some(FlashInferKvParams {
                    kv_dtype: _kv_cache_dtype,
                    out_dtype: dtype,
                    page_size: block_size,
                    num_kv_heads: (kv_heads / _num_shards.max(1)).max(1),
                    head_dim: hd,
                    num_qo_heads: config.num_attention_heads / _num_shards,
                })
            } else {
                // All layers have head_dim > 256, can't use FlashInfer
                None
            }
        } else {
            Some(FlashInferKvParams {
                kv_dtype: _kv_cache_dtype,
                out_dtype: dtype,
                page_size: block_size,
                num_kv_heads: (config
                    .num_key_value_heads
                    .unwrap_or(config.num_attention_heads)
                    / _num_shards.max(1))
                .max(1),
                head_dim: config.k_head_dim(),
                num_qo_heads: config.num_attention_heads / _num_shards,
            })
        };

        let tool_model_type = tool_model_type_for(&model);
        let mut tool_config = ToolConfig::for_model_type(&tool_model_type);
        tool_config.validate_with_tokenizer(&tokenizer, &tool_model_type);
        let tool_call_start_token_ids = tool_config.tool_call_start_ids(&tokenizer);
        let tool_call_end_token_ids = tool_config.tool_call_end_ids(&tokenizer);
        let json_end_token_id = tokenizer
            .encode("}", false)
            .ok()
            .and_then(|tokens| tokens.get_ids().last().copied());
        let tool_call_regex =
            Regex::new(r#"(?s)\{\s*"name"\s*:.*"arguments"\s*:.*\}\s*$"#).unwrap();
        let pipeline_name = if let Some(name) = model_name {
            name
        } else {
            config.architectures.as_ref().unwrap()[0].clone()
        };
        let tool_parser_model_id = tool_parser_model_id.unwrap_or_else(|| pipeline_name.clone());
        let tool_markers = [
            tool_config.start_token_str.as_str(),
            tool_config.end_token_str.as_str(),
        ];
        let image_config = get_image_config(config)?;
        let mut conversation = conversation;
        conversation.set_escape_tokens(DefaultConversation::collect_escape_tokens(
            &tokenizer,
            &tool_markers,
        ));
        conversation.set_preserve_tokens(
            image_config
                .as_ref()
                .map(|cfg| cfg.prompt_marker_tokens())
                .unwrap_or_default(),
        );
        Ok(Self {
            model,
            tokenizer,
            logits_processor,
            conversation,
            name: pipeline_name,
            dtype,
            device: device.clone(),
            stop_token_ids,
            rank,
            stream_decoders: RwLock::new(HashMap::new()),
            tool_call_start_token_ids,
            tool_call_end_token_ids,
            json_end_token_id,
            tool_call_regex,
            tool_config,
            tool_model_type,
            tool_parser_model_id,
            enforce_parser,
            image_config,
            #[cfg(all(feature = "cuda", feature = "graph"))]
            capturer: GraphCapturer::new(
                wrapper,
                max_num_seqs,
                config.max_seq_len,
                block_size,
                config.hidden_size,
                config.is_mla(),
                #[cfg(feature = "flashinfer")]
                &flashinfer_kv_params,
            ),
        })
    }

    pub fn forward(
        &self,
        input_tokens: Tensor,
        input_positions: &Tensor,
        kv_cache: Option<&Vec<(Tensor, Tensor)>>,
        input_metadata: &InputMetadata,
        images: Option<&crate::openai::multimodal::ImageData>,
    ) -> Result<Tensor> {
        let _fp8_linear_prefill_guard = set_linear_is_prefill(input_metadata.is_prefill);
        #[cfg(all(feature = "cuda", feature = "graph"))]
        if !input_metadata.is_prefill {
            let input_batch = input_tokens.dim(0)?;
            let require_exact_graph = input_metadata.mamba_slot_mapping.is_some();
            let can_replay = if require_exact_graph {
                self.capturer.is_exact_captured(input_batch)
            } else {
                self.capturer.is_captured(input_batch)
            };
            if can_replay {
                return match &self.model {
                    LLMModel::Qwen3_5(model) => {
                        let _guard = model.lock_mamba_cache_for_graph();
                        self.capturer
                            .replay(&input_tokens, &input_positions, &input_metadata)
                    }
                    LLMModel::Qwen3_5MoE(model) => {
                        let _guard = model.lock_mamba_cache_for_graph();
                        self.capturer
                            .replay(&input_tokens, &input_positions, &input_metadata)
                    }
                    LLMModel::Qwen3VL(model) => {
                        if let Some(_guard) = model.lock_mamba_cache_for_graph() {
                            self.capturer
                                .replay(&input_tokens, &input_positions, &input_metadata)
                        } else {
                            self.capturer
                                .replay(&input_tokens, &input_positions, &input_metadata)
                        }
                    }
                    LLMModel::QWen3_5GGUF(model) => {
                        let _guard = model.lock_mamba_cache_for_graph();
                        self.capturer
                            .replay(&input_tokens, &input_positions, &input_metadata)
                    }
                    LLMModel::QWen3_5GGUFMoE(model) => {
                        let _guard = model.lock_mamba_cache_for_graph();
                        self.capturer
                            .replay(&input_tokens, &input_positions, &input_metadata)
                    }
                    _ => self
                        .capturer
                        .replay(&input_tokens, &input_positions, &input_metadata),
                };
            }
        }

        match &self.model {
            LLMModel::Llama(llama) => {
                llama.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::LLaMa4(m) => {
                m.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Phi2(phi) => {
                phi.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Phi4(phi) => {
                phi.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen3MoE(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen3_5(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen3_5MoE(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen3VL(qwen) => qwen.forward(
                &input_tokens,
                input_positions,
                kv_cache,
                input_metadata,
                images,
            ),
            LLMModel::Gemma(gemma) => {
                gemma.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Gemma3(gemma3) => {
                gemma3.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Gemma3VL(gemma3) => gemma3.forward(
                &input_tokens,
                input_positions,
                kv_cache,
                input_metadata,
                images,
            ),
            LLMModel::Gemma4(gemma4) => {
                gemma4.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::MiniMax(m) => {
                m.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Mistral(mistral) => {
                mistral.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Mistral3VL(mistral) => mistral.forward(
                &input_tokens,
                input_positions,
                kv_cache,
                input_metadata,
                images,
            ),
            LLMModel::Yi(yi) => {
                yi.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::StableLM(stablelm) => {
                stablelm.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM4(glm4) => {
                glm4.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM4MoeLite(m) => {
                m.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::DeepSeek(deepseek) => {
                deepseek.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM5(m) => {
                m.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Phi3GGUF(phi3) => {
                phi3.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::LlamaGGUF(llama) => {
                llama.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWenGGUF(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWenGGUFMoE(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWen3_5GGUF(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWen3_5GGUFMoE(qwen) => {
                qwen.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM4GGUF(glm4) => {
                glm4.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM5GGUF(m) | LLMModel::DeepSeekGGUF(m) => {
                m.forward(&input_tokens, input_positions, kv_cache, input_metadata)
            }
        }
    }

    pub fn forward_embedding(
        &self,
        input_tokens: Tensor,
        input_positions: &Tensor,
        kv_cache: Option<&Vec<(Tensor, Tensor)>>,
        input_metadata: &InputMetadata,
    ) -> Result<Tensor> {
        let _fp8_linear_prefill_guard = set_linear_is_prefill(input_metadata.is_prefill);
        match &self.model {
            LLMModel::Llama(llama) => {
                llama.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::LLaMa4(m) => {
                m.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::MiniMax(m) => {
                m.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Mistral(mistral) => {
                mistral.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Phi4(phi) => {
                phi.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Gemma(gemma) => {
                gemma.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Gemma3(gemma3) => {
                gemma3.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Gemma3VL(gemma3) => gemma3.forward_embedding(
                &input_tokens,
                input_positions,
                kv_cache,
                input_metadata,
                None,
            ),
            LLMModel::Gemma4(gemma4) => {
                gemma4.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen(qwen) => {
                qwen.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen3MoE(qwen3_moe) => qwen3_moe.forward_embedding(
                &input_tokens,
                input_positions,
                kv_cache,
                input_metadata,
            ),
            LLMModel::Qwen3_5(qwen3_5) => {
                qwen3_5.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Qwen3_5MoE(qwen3_5_moe) => qwen3_5_moe.forward_embedding(
                &input_tokens,
                input_positions,
                kv_cache,
                input_metadata,
            ),
            LLMModel::LlamaGGUF(llama) => {
                llama.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Phi3GGUF(phi3) => {
                phi3.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWenGGUF(qwen) => {
                qwen.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWenGGUFMoE(qwen_moe) => {
                qwen_moe.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWen3_5GGUF(qwen) => {
                qwen.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::QWen3_5GGUFMoE(qwen) => {
                qwen.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM4GGUF(glm4) => {
                glm4.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM5GGUF(m) | LLMModel::DeepSeekGGUF(m) => {
                m.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM4MoeLite(m) => {
                m.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::GLM5(m) => {
                m.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            LLMModel::Yi(yi) => {
                yi.forward_embedding(&input_tokens, input_positions, kv_cache, input_metadata)
            }
            _ => candle_core::bail!("Model not supported for embedding!"),
        }
    }

    pub fn sample(
        &mut self,
        logits: &Tensor,
        groups: &VecDeque<Arc<SequenceGroup>>,
    ) -> Result<Vec<TokenOrFinishReason>> {
        let (
            tokens_generated,
            custom_stop_tokens,
            frequency_panalties,
            presence_panalties,
            reference_tokens,
        ): (
            Vec<i32>,
            Vec<Vec<String>>,
            Vec<f32>,
            Vec<f32>,
            Vec<Vec<u32>>,
        ) = groups
            .into_par_iter()
            .map(|group| {
                let sampling_params = &group.sampling_params;
                let seq = group.get_seqs().values().next().unwrap();
                let sq = seq.deref_mut();
                let tokens = sq
                    .get_token_ids()
                    .iter()
                    .map(|x| *x as u32)
                    .collect::<Vec<_>>();
                let generated = sq.get_len() - sq.get_prompt_len();

                let custom_stop_token = match &sampling_params.stop {
                    Some(StopTokens::Multi(v)) => v.to_vec(),
                    Some(StopTokens::Single(v)) => {
                        vec![v.clone()]
                    }
                    _ => vec![],
                };

                let ref_tokens = if (sampling_params.frequency_penalty != 0.
                    || sampling_params.presence_penalty != 0.)
                    && sampling_params.repeat_last_n.unwrap_or(128) < generated
                {
                    let start_at = tokens
                        .len()
                        .saturating_sub(sampling_params.repeat_last_n.unwrap_or(128));
                    tokens[start_at..].to_vec()
                } else {
                    vec![]
                };
                (
                    if generated > sampling_params.max_tokens {
                        -1i32
                    } else {
                        generated as i32
                    },
                    custom_stop_token,
                    sampling_params.frequency_penalty,
                    sampling_params.presence_penalty,
                    ref_tokens,
                )
            })
            .collect::<Vec<(i32, Vec<String>, f32, f32, Vec<u32>)>>()
            .into_iter()
            .fold(
                (Vec::new(), Vec::new(), Vec::new(), Vec::new(), Vec::new()),
                |mut acc, (gen, stop, penalty1, penalty2, ref_t)| {
                    acc.0.push(gen);
                    acc.1.push(stop);
                    acc.2.push(penalty1);
                    acc.3.push(penalty2);
                    acc.4.push(ref_t);
                    acc
                },
            );

        let logits = if frequency_panalties.iter().any(|&v| v != 1.0 && v != 0.)
            || presence_panalties.iter().any(|&v| v != 1.0 && v != 0.)
        {
            self.logits_processor.apply_batch_repeat_penalty(
                logits,
                frequency_panalties,
                presence_panalties,
                reference_tokens,
            )?
        } else {
            logits.to_owned()
        };

        let group_ids: Vec<usize> = groups.iter().map(|group| group.group_id).collect();
        let param = &groups[0].sampling_params;
        let sampling_params =
            if param.temperature.is_some() && (param.top_k.is_some() || param.top_p.is_some()) {
                Some(param.to_owned())
            } else {
                None
            };

        let next_tokens = self.logits_processor.sample(&logits, &sampling_params)?;
        let result: Vec<TokenOrFinishReason> = next_tokens
            .into_par_iter()
            .enumerate()
            .map(|(i, next_token)| {
                let group_id = group_ids[i];
                let group = groups
                    .get(i)
                    .expect("group index out of range for sampling");
                let mut text = "".to_string();
                let mut decoder_map = self.stream_decoders.write();
                match decoder_map.get_mut(&group_id) {
                    Some(decoder) => {
                        if let Some(output) = decoder.step(next_token) {
                            text = output
                        }
                    }
                    _ => {
                        let leaked: &'static _ = Box::leak(Box::new(self.tokenizer.clone()));
                        let decoder = leaked.decode_stream(false);
                        let wrapped = super::StreamWithTokenizer {
                            _tokenizer: unsafe { Box::from_raw(leaked as *const _ as *mut _) },
                            stream: decoder,
                        };
                        let mut boxed_decoder: Box<dyn super::DecodeStreamTrait + Send + Sync> =
                            Box::new(wrapped);
                        if let Some(output) = boxed_decoder.step(next_token) {
                            text = output
                        }
                        //stream decoder for the new request
                        decoder_map.insert(group_id, boxed_decoder);
                    }
                }

                let custom_stop_token_match = !custom_stop_tokens[i].is_empty()
                    && custom_stop_tokens[i].contains(&text.trim().to_string());

                if group.sampling_params.mcp_mode.is_some() {
                    let seq = group.get_seqs().values().next().unwrap();
                    if self.tool_call_end_token_ids.contains(&next_token) {
                        if !self.tool_call_start_token_ids.is_empty() {
                            let has_start = self.output_contains_tool_call_start(seq);
                            if !has_start {
                                return Left(Logprobs {
                                    token: next_token,
                                    logprob: 0.0,
                                    top_logprobs: Vec::<TopLogprob>::new(),
                                    bytes: text,
                                });
                            }
                        }
                        let finish_logprobs = Logprobs {
                            token: next_token,
                            logprob: 0.0,
                            top_logprobs: Vec::<TopLogprob>::new(),
                            bytes: text,
                        };
                        seq.deref_mut().deref_mut().pending_finish_logprobs = Some(finish_logprobs);
                        return Right("tool_calls".to_string());
                    }
                    if self.is_nested_tool_call_start(seq, next_token, &text) {
                        warn!(
                            "Nested tool-call start marker detected for request {}; finishing current tool call early",
                            group.request_id
                        );
                        let finish_logprobs = Logprobs {
                            token: next_token,
                            logprob: 0.0,
                            top_logprobs: Vec::<TopLogprob>::new(),
                            bytes: text,
                        };
                        seq.deref_mut().deref_mut().pending_finish_logprobs = Some(finish_logprobs);
                        return Right("tool_calls".to_string());
                    }
                    if self.tool_call_end_token_ids.is_empty()
                        && self.json_end_token_id == Some(next_token)
                    {
                        let mut output_tokens: Vec<u32> = seq
                            .deref()
                            .get_output_tokens()
                            .iter()
                            .map(|logprob| logprob.token)
                            .collect();
                        output_tokens.push(next_token);
                        if let Ok(decoded) = self.tokenizer.decode(&output_tokens, true) {
                            if self.tool_call_regex.is_match(&decoded) {
                                let finish_logprobs = Logprobs {
                                    token: next_token,
                                    logprob: 0.0,
                                    top_logprobs: Vec::<TopLogprob>::new(),
                                    bytes: text,
                                };
                                seq.deref_mut().deref_mut().pending_finish_logprobs =
                                    Some(finish_logprobs);
                                return Right("tool_calls".to_string());
                            }
                        }
                    }
                }

                if tokens_generated[i] < 0 {
                    Right("length".to_string())
                } else if custom_stop_token_match || self.stop_token_ids.contains(&next_token) {
                    Right("stop".to_string())
                } else {
                    Left(Logprobs {
                        token: next_token,
                        logprob: 0.0,
                        top_logprobs: Vec::<TopLogprob>::new(),
                        bytes: text,
                    })
                }
            })
            .collect();
        Ok(result)
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn tokenizer(&self) -> &Tokenizer {
        &self.tokenizer
    }

    pub fn get_conversation(&self) -> DefaultConversation {
        self.conversation.clone()
    }

    pub fn get_model_config(&self) -> Config {
        match &self.model {
            LLMModel::Llama(llama) => llama.get_config().clone(),
            LLMModel::LLaMa4(m) => m.get_config().clone(),
            LLMModel::Phi2(phi) => phi.get_config().clone(),
            LLMModel::Phi4(phi) => phi.get_config().clone(),
            LLMModel::Qwen(qwen) => qwen.get_config().clone(),
            LLMModel::Qwen3MoE(qwen) => qwen.get_config().clone(),
            LLMModel::Qwen3_5(qwen) => qwen.get_config().clone(),
            LLMModel::Qwen3_5MoE(qwen) => qwen.get_config().clone(),
            LLMModel::Qwen3VL(qwen) => qwen.get_config().clone(),
            LLMModel::Gemma(gemma) => gemma.get_config().clone(),
            LLMModel::Gemma3(gemma3) => gemma3.get_config().clone(),
            LLMModel::Gemma3VL(gemma3) => gemma3.get_config().clone(),
            LLMModel::Gemma4(gemma4) => gemma4.get_config().clone(),
            LLMModel::MiniMax(m) => m.get_config().clone(),
            LLMModel::Mistral(mistral) => mistral.get_config().clone(),
            LLMModel::Mistral3VL(mistral) => mistral.get_config().clone(),
            LLMModel::Yi(yi) => yi.get_config().clone(),
            LLMModel::StableLM(stablelm) => stablelm.get_config().clone(),
            LLMModel::GLM4(glm4) => glm4.get_config().clone(),
            LLMModel::GLM4MoeLite(m) => m.get_config().clone(),
            LLMModel::DeepSeek(deepseek) => deepseek.get_config().clone(),
            LLMModel::GLM5(m) => m.get_config().clone(),
            LLMModel::Phi3GGUF(phi3) => phi3.get_config().clone(),
            LLMModel::LlamaGGUF(llama) => llama.get_config().clone(),
            LLMModel::QWenGGUF(qwen) => qwen.get_config().clone(),
            LLMModel::QWenGGUFMoE(qwen) => qwen.get_config().clone(),
            LLMModel::QWen3_5GGUF(qwen) => qwen.get_config().clone(),
            LLMModel::QWen3_5GGUFMoE(qwen) => qwen.get_config().clone(),
            LLMModel::GLM4GGUF(glm4) => glm4.get_config().clone(),
            LLMModel::GLM5GGUF(m) | LLMModel::DeepSeekGGUF(m) => m.get_config().clone(),
        }
    }

    pub fn get_dtype(&self) -> DType {
        self.dtype
    }

    pub fn device(&self) -> &Device {
        &self.device
    }

    pub fn reset_decoder(&mut self) {
        let mut map = self.stream_decoders.write();
        map.clear();
    }

    pub fn rank(&self) -> usize {
        self.rank
    }

    pub fn release_sequence_state(&self, sequence_id: usize) {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.release_sequence_state(sequence_id),
            LLMModel::Qwen3_5MoE(model) => model.release_sequence_state(sequence_id),
            LLMModel::Qwen3VL(model) => model.release_sequence_state(sequence_id),
            LLMModel::QWen3_5GGUF(model) => model.release_sequence_state(sequence_id),
            LLMModel::QWen3_5GGUFMoE(model) => model.release_sequence_state(sequence_id),
            _ => {}
        }
    }

    pub fn ensure_mamba_slots_for_sequences(&self, sequence_ids: &[usize]) -> Result<Vec<usize>> {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.ensure_mamba_slots_for_sequences(sequence_ids),
            LLMModel::Qwen3_5MoE(model) => model.ensure_mamba_slots_for_sequences(sequence_ids),
            LLMModel::Qwen3VL(model) => model.ensure_mamba_slots_for_sequences(sequence_ids),
            LLMModel::QWen3_5GGUF(model) => model.ensure_mamba_slots_for_sequences(sequence_ids),
            LLMModel::QWen3_5GGUFMoE(model) => model.ensure_mamba_slots_for_sequences(sequence_ids),
            _ => Ok(vec![]),
        }
    }

    pub fn get_mamba_slots_for_sequences(&self, sequence_ids: &[usize]) -> Result<Vec<usize>> {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.get_mamba_slots_for_sequences(sequence_ids),
            LLMModel::Qwen3_5MoE(model) => model.get_mamba_slots_for_sequences(sequence_ids),
            LLMModel::Qwen3VL(model) => model.get_mamba_slots_for_sequences(sequence_ids),
            LLMModel::QWen3_5GGUF(model) => model.get_mamba_slots_for_sequences(sequence_ids),
            LLMModel::QWen3_5GGUFMoE(model) => model.get_mamba_slots_for_sequences(sequence_ids),
            _ => Ok(vec![]),
        }
    }

    pub fn has_mamba_slot_for_sequence(&self, sequence_id: usize) -> bool {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.has_mamba_slot_for_sequence(sequence_id),
            LLMModel::Qwen3_5MoE(model) => model.has_mamba_slot_for_sequence(sequence_id),
            LLMModel::Qwen3VL(model) => model.has_mamba_slot_for_sequence(sequence_id),
            LLMModel::QWen3_5GGUF(model) => model.has_mamba_slot_for_sequence(sequence_id),
            LLMModel::QWen3_5GGUFMoE(model) => model.has_mamba_slot_for_sequence(sequence_id),
            _ => false,
        }
    }

    pub fn preallocate_mamba_cache(&self, max_num_seqs: usize) -> Result<()> {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.preallocate_mamba_cache(max_num_seqs),
            LLMModel::Qwen3_5MoE(model) => model.preallocate_mamba_cache(max_num_seqs),
            LLMModel::Qwen3VL(model) => model.preallocate_mamba_cache(max_num_seqs),
            LLMModel::QWen3_5GGUF(model) => model.preallocate_mamba_cache(max_num_seqs),
            LLMModel::QWen3_5GGUFMoE(model) => model.preallocate_mamba_cache(max_num_seqs),
            _ => Ok(()),
        }
    }

    pub fn set_mamba_prefix_cache_capacity(&self, capacity: usize) {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.set_mamba_prefix_cache_capacity(capacity),
            LLMModel::Qwen3_5MoE(model) => model.set_mamba_prefix_cache_capacity(capacity),
            LLMModel::Qwen3VL(model) => model.set_mamba_prefix_cache_capacity(capacity),
            LLMModel::QWen3_5GGUF(model) => model.set_mamba_prefix_cache_capacity(capacity),
            LLMModel::QWen3_5GGUFMoE(model) => model.set_mamba_prefix_cache_capacity(capacity),
            _ => {}
        }
    }

    #[cfg(all(feature = "cuda", feature = "graph"))]
    pub fn clamp_mamba_graph_capture_batches(&mut self, mamba_slot_capacity: usize) {
        self.capturer
            .clamp_mamba_graph_batch_size(mamba_slot_capacity);
    }

    pub fn capture_mamba_prefix_state(
        &self,
        seq_id: usize,
        hash: u64,
        preserve: bool,
    ) -> Result<bool> {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.capture_mamba_prefix_state(seq_id, hash, preserve),
            LLMModel::Qwen3_5MoE(model) => model.capture_mamba_prefix_state(seq_id, hash, preserve),
            LLMModel::Qwen3VL(model) => model.capture_mamba_prefix_state(seq_id, hash, preserve),
            LLMModel::QWen3_5GGUF(model) => {
                model.capture_mamba_prefix_state(seq_id, hash, preserve)
            }
            LLMModel::QWen3_5GGUFMoE(model) => {
                model.capture_mamba_prefix_state(seq_id, hash, preserve)
            }
            _ => Ok(false),
        }
    }

    pub fn has_mamba_prefix_state(&self, hash: u64) -> Result<bool> {
        match &self.model {
            LLMModel::Qwen3_5(model) => Ok(model.has_mamba_prefix_state(hash)),
            LLMModel::Qwen3_5MoE(model) => Ok(model.has_mamba_prefix_state(hash)),
            LLMModel::Qwen3VL(model) => Ok(model.has_mamba_prefix_state(hash)),
            LLMModel::QWen3_5GGUF(model) => Ok(model.has_mamba_prefix_state(hash)),
            LLMModel::QWen3_5GGUFMoE(model) => Ok(model.has_mamba_prefix_state(hash)),
            _ => Ok(true),
        }
    }

    pub fn restore_mamba_prefix_state(&self, seq_id: usize, hash: u64) -> Result<bool> {
        match &self.model {
            LLMModel::Qwen3_5(model) => model.restore_mamba_prefix_state(seq_id, hash),
            LLMModel::Qwen3_5MoE(model) => model.restore_mamba_prefix_state(seq_id, hash),
            LLMModel::Qwen3VL(model) => model.restore_mamba_prefix_state(seq_id, hash),
            LLMModel::QWen3_5GGUF(model) => model.restore_mamba_prefix_state(seq_id, hash),
            LLMModel::QWen3_5GGUFMoE(model) => model.restore_mamba_prefix_state(seq_id, hash),
            _ => Ok(true),
        }
    }

    #[cfg(all(feature = "cuda", feature = "graph"))]
    pub fn warmup_capture(&mut self, kv_caches: Option<&Vec<(Tensor, Tensor)>>) -> Result<()> {
        match &self.model {
            LLMModel::Phi4(_) => Ok(()),
            LLMModel::Phi3GGUF(_) => Ok(()),
            #[cfg(not(feature = "flashinfer"))]
            LLMModel::GLM4MoeLite(_) => Ok(()),
            #[cfg(not(feature = "flashinfer"))]
            LLMModel::DeepSeek(_) => Ok(()),
            #[cfg(not(feature = "flashinfer"))]
            LLMModel::GLM5(_) => Ok(()),
            _ => {
                self.capturer.capture(&self.device, kv_caches)?;
                match &self.model {
                    LLMModel::Qwen3_5(model) => model.reset_mamba_cache()?,
                    LLMModel::Qwen3_5MoE(model) => model.reset_mamba_cache()?,
                    LLMModel::Qwen3VL(model) => model.reset_mamba_cache()?,
                    LLMModel::QWen3_5GGUF(model) => model.reset_mamba_cache()?,
                    LLMModel::QWen3_5GGUFMoE(model) => model.reset_mamba_cache()?,
                    _ => {}
                }
                Ok(())
            }
        }
    }
}

unsafe impl Send for DefaultPipeline {}
unsafe impl Sync for DefaultPipeline {}
