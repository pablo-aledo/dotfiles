use std::{
    collections::{hash_map::Entry, HashMap, HashSet, VecDeque},
    hash::{Hash, Hasher},
    marker::PhantomData,
    ops::Deref,
    sync::{Arc, Mutex, MutexGuard},
};

use super::prefix_cache::{PrefixCache, PrefixCacheConfig, PrefixMatch};
use super::sequence::{Sequence, SequenceGroup};
use crate::openai::multimodal::ImageData;

pub struct LogicalTokenBlock {
    tokens: Vec<u32>,
    block_size: usize,
    num_tokens: usize,
}

impl LogicalTokenBlock {
    pub fn new(block_size: usize) -> Self {
        Self {
            tokens: [0].repeat(block_size),
            block_size,
            num_tokens: 0,
        }
    }

    pub fn is_full(&self) -> bool {
        self.num_tokens == self.block_size
    }

    pub fn is_empty(&self) -> bool {
        self.num_tokens == 0
    }

    pub fn append_token_id(&mut self, token: u32) {
        assert!(!self.is_full());
        self.tokens[self.num_tokens] = token;
        self.num_tokens += 1;
    }

    pub fn append_tokens(&mut self, tokens: &[u32]) {
        for token in tokens {
            self.append_token_id(*token);
        }
    }
}

#[derive(Hash, PartialEq, Eq)]
pub struct _PhysicalTokenBlock {
    pub block_id: usize,
    pub(crate) block_size: usize,
    pub refcount: usize,
    pub(crate) is_gpu: bool,
}

pub struct PhysicalTokenBlock(pub Mutex<_PhysicalTokenBlock>);

impl PhysicalTokenBlock {
    pub fn deref_mut(&self) -> MutexGuard<'_, _PhysicalTokenBlock> {
        loop {
            if let Ok(v) = self.0.try_lock() {
                return v;
            }
        }
    }
}

impl PartialEq for PhysicalTokenBlock {
    fn eq(&self, other: &Self) -> bool {
        *self.deref_mut() == *other.deref_mut()
    }
}

impl Hash for PhysicalTokenBlock {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.deref_mut().hash(state)
    }
}

impl Eq for PhysicalTokenBlock {}

type BlockTable = VecDeque<Arc<PhysicalTokenBlock>>;
struct GPUAllocator;
struct CPUAllocator;

struct GPUAllocatorWrapper(usize);
// struct CPUAllocatorWrapper(usize);

impl Deref for GPUAllocatorWrapper {
    type Target = usize;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

// impl Deref for CPUAllocatorWrapper {
//     type Target = usize;

//     fn deref(&self) -> &Self::Target {
//         &self.0
//     }
// }

struct Allocator<T> {
    free_blocks: BlockTable,
    _ghost: PhantomData<T>,
    num_blocks: usize,
}

impl<T> Allocator<T> {
    fn allocate(&mut self) -> Arc<PhysicalTokenBlock> {
        let block = self.free_blocks.pop_front().unwrap();
        block.deref_mut().refcount = 1;
        block
    }

    fn free_block(&mut self, block: Arc<PhysicalTokenBlock>) {
        if block.deref_mut().refcount == 0 {
            panic!(
                "PhysicalTokenBlock with id {} experienced a double free!",
                block.deref_mut().block_id
            );
        }
        block.deref_mut().refcount -= 1;
        if block.deref_mut().refcount == 0 {
            self.free_blocks.push_back(block);
        }
    }
}

impl Allocator<GPUAllocator> {
    fn new(block_size: usize, num_blocks: usize) -> Self {
        let mut free_blocks = VecDeque::new();
        for id in 0..num_blocks {
            free_blocks.push_back(Arc::new(PhysicalTokenBlock(Mutex::new(
                _PhysicalTokenBlock {
                    block_id: id,
                    block_size,
                    refcount: 0,
                    is_gpu: true,
                },
            ))))
        }
        Allocator {
            free_blocks,
            num_blocks,
            _ghost: PhantomData,
        }
    }

    fn get_num_free_blocks(&self) -> GPUAllocatorWrapper {
        GPUAllocatorWrapper(self.free_blocks.len())
    }

    fn get_num_blocks(&self) -> GPUAllocatorWrapper {
        GPUAllocatorWrapper(self.num_blocks)
    }
}

impl Allocator<CPUAllocator> {
    fn new(block_size: usize, num_blocks: usize) -> Self {
        let mut free_blocks = VecDeque::new();
        for id in 0..num_blocks {
            free_blocks.push_back(Arc::new(PhysicalTokenBlock(Mutex::new(
                _PhysicalTokenBlock {
                    block_id: id,
                    block_size,
                    refcount: 0,
                    is_gpu: false,
                },
            ))))
        }
        Allocator {
            free_blocks,
            _ghost: PhantomData,
            num_blocks,
        }
    }
}

pub enum AllocStatus {
    Ok,
    Later,
    Impossible,
}

type SeqID = usize;

#[derive(Clone)]
struct PendingBlockSwap {
    old_tables: Vec<(SeqID, BlockTable)>,
    new_tables: Vec<(SeqID, BlockTable)>,
}

/// A BlockEngine maps each Sequence (identified by its SeqID), to physical token blocks.
/// The physical token blocks may not match the logical token blocks because during
/// scheduling, physical blocks are allocated to accommodate the new tokens generated.
/// These new tokens will be added to the logical token block for each sequence.
pub struct BlockEngine {
    num_gpu_blocks: usize,
    gpu_allocator: Allocator<GPUAllocator>,
    cpu_allocator: Allocator<CPUAllocator>,
    pub block_tables: HashMap<SeqID, BlockTable>,
    block_size: usize,
    kvcache_mem_gpu: usize,
    prefix_cache: Option<PrefixCache>,
    require_mamba_prefix_snapshots: bool,
    valid_mamba_prefix_hashes: HashSet<u64>,
    prefix_block_id_by_mamba_hash: HashMap<u64, usize>,
    mamba_hashes_by_prefix_block_id: HashMap<usize, HashSet<u64>>,
    pending_swap_out: HashMap<usize, PendingBlockSwap>,
    pending_swap_in: HashMap<usize, PendingBlockSwap>,
}

impl BlockEngine {
    fn image_prefix_seed(images: &ImageData) -> u64 {
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        images.raw.hash(&mut hasher);
        images.shape.hash(&mut hasher);
        images.patches.hash(&mut hasher);
        hasher.finish()
    }

    fn image_seed_and_block(
        images: &ImageData,
        tokens: &[u32],
        block_size: usize,
    ) -> (Option<u64>, Option<usize>) {
        let Some(image_token_id) = images.image_token_id else {
            return (None, None);
        };
        let Some(first_pos) = tokens.iter().position(|&id| id == image_token_id) else {
            return (None, None);
        };
        let seed = Self::image_prefix_seed(images);
        (Some(seed), Some(first_pos / block_size))
    }

    #[must_use]
    pub fn new(
        block_size: usize,
        num_gpu_blocks: usize,
        num_cpu_blocks: usize,
        kvcache_mem_gpu: usize,
        prefix_cache: PrefixCacheConfig,
        require_mamba_prefix_snapshots: bool,
    ) -> Self {
        let prefix_cache = if prefix_cache.enabled && prefix_cache.max_cached_blocks > 0 {
            Some(PrefixCache::new(block_size, prefix_cache))
        } else {
            None
        };
        Self {
            num_gpu_blocks,
            gpu_allocator: Allocator::<GPUAllocator>::new(block_size, num_gpu_blocks),
            cpu_allocator: Allocator::<CPUAllocator>::new(block_size, num_cpu_blocks),
            block_tables: HashMap::new(),
            block_size,
            kvcache_mem_gpu,
            prefix_cache,
            require_mamba_prefix_snapshots,
            valid_mamba_prefix_hashes: HashSet::new(),
            prefix_block_id_by_mamba_hash: HashMap::new(),
            mamba_hashes_by_prefix_block_id: HashMap::new(),
            pending_swap_out: HashMap::new(),
            pending_swap_in: HashMap::new(),
        }
    }

    pub fn get_block_size(&self) -> usize {
        self.block_size
    }

    pub fn requires_mamba_prefix_snapshots(&self) -> bool {
        self.require_mamba_prefix_snapshots
    }

    pub fn get_num_free_blocks(&self) -> usize {
        *self.gpu_allocator.get_num_free_blocks()
    }

    pub fn get_num_blocks(&self) -> usize {
        *self.gpu_allocator.get_num_blocks()
    }

    pub fn get_kvcache_mem_size(&self) -> usize {
        self.kvcache_mem_gpu
    }

    pub fn can_allocate(&mut self, seq_group: &SequenceGroup) -> AllocStatus {
        self.can_allocate_for_prefill(seq_group, 0)
    }

    pub fn can_allocate_for_prefill(
        &mut self,
        seq_group: &SequenceGroup,
        prefill_chunk_size: usize,
    ) -> AllocStatus {
        let block_size = self.block_size;
        let total_required_blocks = seq_group.get_total_logical_token_blocks();
        let num_required_blocks = if let Some(prefix_cache) = self.prefix_cache.as_mut() {
            let seq = seq_group.get_seqs().values().nth(0).unwrap();
            let tokens = seq.deref().deref().get_token_ids();
            let (seed, seed_block) = seq
                .deref()
                .deref()
                .get_images()
                .as_ref()
                .map(|img| Self::image_seed_and_block(img, &tokens, self.block_size))
                .unwrap_or((None, None));
            let PrefixMatch {
                matched_blocks,
                last_hash,
            } = prefix_cache.match_prefix_with_seed(&tokens, seed, seed_block);
            let full_blocks = tokens.len() / block_size;
            let raw_matched_blocks = if matched_blocks == full_blocks
                && tokens.len() % block_size == 0
                && matched_blocks > 0
            {
                matched_blocks - 1
            } else {
                matched_blocks
            };
            let matched_blocks = Self::resolve_valid_mamba_matched_blocks(
                self.require_mamba_prefix_snapshots,
                &self.valid_mamba_prefix_hashes,
                prefix_cache,
                raw_matched_blocks,
                last_hash,
            );
            let cached_tokens = matched_blocks * block_size;
            let warmup_target = Self::mamba_warmup_target(
                self.require_mamba_prefix_snapshots,
                raw_matched_blocks,
                matched_blocks,
                block_size,
                tokens.len(),
            );
            let prefill_end = Self::prefill_chunk_end_with_warmup(
                tokens.len(),
                cached_tokens,
                prefill_chunk_size,
                warmup_target,
            );
            let required_blocks = prefill_end.div_ceil(block_size);
            required_blocks.saturating_sub(matched_blocks)
        } else {
            seq_group
                .get_seqs()
                .values()
                .map(|seq| {
                    let prompt_len = seq.deref().deref().get_prompt_len();
                    let prefill_end = Self::prefill_chunk_end(prompt_len, 0, prefill_chunk_size);
                    prefill_end.div_ceil(block_size)
                })
                .sum()
        };
        let mut num_free_gpu_blocks = *self.gpu_allocator.get_num_free_blocks();
        if num_free_gpu_blocks < num_required_blocks {
            self.evict_prefix_cache_until_free(num_required_blocks);
            num_free_gpu_blocks = *self.gpu_allocator.get_num_free_blocks();
        }

        if self.num_gpu_blocks < total_required_blocks {
            AllocStatus::Impossible
        } else if num_free_gpu_blocks >= num_required_blocks {
            AllocStatus::Ok
        } else {
            AllocStatus::Later
        }
    }

    pub fn has_block_table(&self, seq_group: &SequenceGroup) -> bool {
        seq_group
            .get_seqs()
            .keys()
            .all(|seq_id| self.block_tables.contains_key(seq_id))
    }

    pub fn allocate(
        &mut self,
        seq_group: &SequenceGroup,
        _blocks_to_copy: &mut HashMap<usize, Vec<usize>>,
    ) {
        self.allocate_for_prefill(seq_group, _blocks_to_copy, 0)
    }

    pub fn allocate_for_prefill(
        &mut self,
        seq_group: &SequenceGroup,
        _blocks_to_copy: &mut HashMap<usize, Vec<usize>>,
        prefill_chunk_size: usize,
    ) {
        if self.prefix_cache.is_some() {
            self.allocate_with_prefix(seq_group, prefill_chunk_size);
        } else {
            let mut block_table = VecDeque::new();
            let blocks =
                self.prefill_blocks_to_allocate_without_prefix(seq_group, prefill_chunk_size);
            for _logcical_idx in 0..blocks {
                block_table.push_back(self.gpu_allocator.allocate());
            }
            for (idx, seq_id) in seq_group.get_seqs().keys().enumerate() {
                let table = block_table.clone();
                if idx > 0 {
                    for block in &table {
                        block.deref_mut().refcount += 1;
                    }
                }
                self.block_tables.insert(*seq_id, table);
            }
        }
    }

    fn prefill_chunk_end(prompt_len: usize, cached_tokens: usize, chunk_size: usize) -> usize {
        Self::prefill_chunk_end_with_warmup(prompt_len, cached_tokens, chunk_size, None)
    }

    fn prefill_chunk_end_with_warmup(
        prompt_len: usize,
        cached_tokens: usize,
        chunk_size: usize,
        warmup_target: Option<usize>,
    ) -> usize {
        let cached_tokens = cached_tokens.min(prompt_len);
        if chunk_size == 0 {
            prompt_len
        } else if let Some(target_tokens) = warmup_target {
            if target_tokens > cached_tokens && target_tokens < prompt_len {
                cached_tokens + (target_tokens - cached_tokens).min(chunk_size)
            } else {
                cached_tokens + prompt_len.saturating_sub(cached_tokens).min(chunk_size)
            }
        } else {
            cached_tokens + prompt_len.saturating_sub(cached_tokens).min(chunk_size)
        }
    }

    fn mamba_warmup_target(
        require_mamba_prefix_snapshots: bool,
        raw_matched_blocks: usize,
        matched_blocks: usize,
        block_size: usize,
        prompt_len: usize,
    ) -> Option<usize> {
        if !require_mamba_prefix_snapshots || matched_blocks != 0 || raw_matched_blocks == 0 {
            return None;
        }
        let raw_cached_tokens = raw_matched_blocks * block_size;
        (raw_cached_tokens < prompt_len).then_some(raw_cached_tokens)
    }

    fn prefill_blocks_to_allocate_without_prefix(
        &self,
        seq_group: &SequenceGroup,
        prefill_chunk_size: usize,
    ) -> usize {
        if prefill_chunk_size == 0 {
            return seq_group.get_total_logical_token_blocks();
        }
        seq_group
            .get_seqs()
            .values()
            .map(|seq| {
                let prefill_end = Self::prefill_chunk_end(
                    seq.deref().deref().get_prompt_len(),
                    0,
                    prefill_chunk_size,
                );
                prefill_end.div_ceil(self.block_size)
            })
            .sum()
    }

    pub fn can_append_token_to_seq(&self, seq_group: &SequenceGroup) -> bool {
        let free_blocks = self.gpu_allocator.get_num_free_blocks();
        let blocks_required: usize = seq_group
            .get_seqs()
            .values()
            .map(|seq| self.blocks_required_to_append_token_slot(seq))
            .sum();
        blocks_required <= *free_blocks
    }

    fn blocks_missing_for_sequence(&self, sequence: &Sequence) -> usize {
        let seq = sequence.deref();
        let required_blocks = seq.get_logical_token_blocks();
        let table_len = self
            .block_tables
            .get(&seq.get_id())
            .map(|table| table.len())
            .unwrap_or(0);
        required_blocks.saturating_sub(table_len)
    }

    fn blocks_required_to_append_token_slot(&self, sequence: &Sequence) -> usize {
        let blocks_missing = self.blocks_missing_for_sequence(sequence);
        if blocks_missing > 0 {
            return blocks_missing;
        }

        if sequence.deref().blocks_to_add_new_tok() > 0 {
            return 0;
        }

        let seq_id = sequence.deref().get_id();
        let Some(table) = self.block_tables.get(&seq_id) else {
            return 0;
        };
        let Some(last_block) = table.back() else {
            return 0;
        };
        usize::from(last_block.deref_mut().refcount > 1)
    }

    pub fn prefill_chunk_blocks_required(
        &self,
        seq_group: &SequenceGroup,
        prefill_chunk_size: usize,
    ) -> usize {
        seq_group
            .get_seqs()
            .values()
            .map(|seq| self.blocks_missing_for_prefill_chunk(seq, prefill_chunk_size))
            .sum()
    }

    pub fn can_append_prefill_chunk_to_seq_group(
        &self,
        seq_group: &SequenceGroup,
        prefill_chunk_size: usize,
    ) -> bool {
        self.prefill_chunk_blocks_required(seq_group, prefill_chunk_size)
            <= *self.gpu_allocator.get_num_free_blocks()
    }

    pub fn append_prefill_chunk_slots_to_seq_group(
        &mut self,
        seq_group: &SequenceGroup,
        prefill_chunk_size: usize,
    ) {
        for seq in seq_group.get_seqs().values() {
            let blocks_to_append = self.blocks_missing_for_prefill_chunk(seq, prefill_chunk_size);
            if blocks_to_append == 0 {
                continue;
            }
            let table = self
                .block_tables
                .get_mut(&seq.deref().deref().get_id())
                .expect("prefill continuation must have a block table");
            for _ in 0..blocks_to_append {
                table.push_back(self.gpu_allocator.allocate());
            }
        }
    }

    fn blocks_missing_for_prefill_chunk(
        &self,
        sequence: &Sequence,
        prefill_chunk_size: usize,
    ) -> usize {
        let seq = sequence.deref();
        let prefill_end =
            seq.get_num_cached_tokens() + seq.prefill_chunk_tokens(prefill_chunk_size);
        let required_blocks = prefill_end.div_ceil(self.block_size);
        let table_len = self
            .block_tables
            .get(&seq.get_id())
            .map(|table| table.len())
            .unwrap_or(0);
        required_blocks.saturating_sub(table_len)
    }

    pub fn free_sequence(&mut self, sequence: &Sequence) {
        let block_table = self
            .block_tables
            .get(&sequence.deref_mut().get_id())
            .unwrap();

        // Free from block table
        for block in block_table {
            if block.deref_mut().is_gpu {
                self.gpu_allocator.free_block(block.clone())
            } else {
                self.cpu_allocator.free_block(block.clone())
            }
        }

        self.block_tables.remove(&sequence.deref_mut().get_id());
    }

    pub fn cache_sequence(&mut self, sequence: &Sequence) {
        let Some(prefix_cache) = self.prefix_cache.as_mut() else {
            return;
        };
        if !prefix_cache.enabled() {
            return;
        }

        let tokens = sequence.deref().get_token_ids();
        let full_blocks = tokens.len() / self.block_size;
        if full_blocks == 0 {
            return;
        }

        let table = match self.block_tables.get(&sequence.deref().get_id()) {
            Some(table) => table,
            None => return,
        };
        if table.len() < full_blocks {
            return;
        }

        let blocks: Vec<Arc<PhysicalTokenBlock>> =
            table.iter().take(full_blocks).cloned().collect();
        if blocks.iter().any(|block| !block.deref_mut().is_gpu) {
            return;
        }

        tracing::info!(
            "Prefix cache insert seq {} ({} tokens, {} blocks)",
            sequence.deref().get_id(),
            tokens.len(),
            full_blocks
        );
        let (seed, seed_block) = sequence
            .deref()
            .get_images()
            .as_ref()
            .map(|img| Self::image_seed_and_block(img, &tokens, self.block_size))
            .unwrap_or((None, None));
        let evicted = prefix_cache.insert_prefix_with_seed(&tokens, &blocks, seed, seed_block);
        if !evicted.is_empty() {
            tracing::info!("Prefix cache evicted {} blocks after insert", evicted.len());
        }
        let evicted_block_ids = evicted
            .iter()
            .map(|block| block.deref_mut().block_id)
            .collect::<Vec<_>>();
        self.handle_mamba_prefix_evicted_blocks(&evicted_block_ids);
        for block in evicted {
            self.release_block(block);
        }
    }

    pub fn evict_prefix_cache_until_free(&mut self, min_free_blocks: usize) -> usize {
        let mut total_evicted = 0;
        loop {
            if *self.gpu_allocator.get_num_free_blocks() >= min_free_blocks {
                break;
            }
            let evicted = {
                let Some(prefix_cache) = self.prefix_cache.as_mut() else {
                    break;
                };
                prefix_cache.evict_blocks(1)
            };
            if evicted.is_empty() {
                break;
            }
            let evicted_block_ids = evicted
                .iter()
                .map(|block| block.deref_mut().block_id)
                .collect::<Vec<_>>();
            self.handle_mamba_prefix_evicted_blocks(&evicted_block_ids);
            total_evicted += evicted.len();
            for block in evicted {
                self.release_block(block);
            }
        }
        total_evicted
    }

    pub fn evict_prefix_cache_blocks(&mut self, num_blocks: usize) -> usize {
        let Some(prefix_cache) = self.prefix_cache.as_mut() else {
            return 0;
        };
        if num_blocks == 0 {
            return 0;
        }
        let evicted = prefix_cache.evict_blocks(num_blocks);
        let evicted_count = evicted.len();
        let evicted_block_ids = evicted
            .iter()
            .map(|block| block.deref_mut().block_id)
            .collect::<Vec<_>>();
        self.handle_mamba_prefix_evicted_blocks(&evicted_block_ids);
        for block in evicted {
            self.release_block(block);
        }
        evicted_count
    }

    pub fn prefix_cache_enabled(&self) -> bool {
        self.prefix_cache.is_some()
    }

    pub fn cpu_swap_enabled(&self) -> bool {
        cfg!(feature = "cuda")
    }

    pub fn prefix_cache_blocks(&self) -> usize {
        self.prefix_cache
            .as_ref()
            .map_or(0, |cache| cache.cached_blocks())
    }

    pub fn query_prefix_cache_match_tokens(&mut self, tokens: &[u32]) -> usize {
        if let Some(prefix_cache) = self.prefix_cache.as_mut() {
            let PrefixMatch { matched_blocks, .. } = prefix_cache.match_prefix(tokens);
            matched_blocks * self.block_size
        } else {
            0
        }
    }

    pub fn prefix_hash_for_sequence(
        &self,
        sequence: &Sequence,
        processed_tokens: usize,
    ) -> Option<u64> {
        let prefix_cache = self.prefix_cache.as_ref()?;
        if !prefix_cache.enabled() {
            return None;
        }
        let num_cached = sequence.deref().get_num_cached_tokens();
        if let Some(hash) = sequence.deref().get_mamba_prefix_hash() {
            if num_cached > 0 && processed_tokens <= num_cached {
                return Some(hash);
            }
        }
        let tokens = sequence.deref().get_token_ids();
        let full_blocks = processed_tokens.min(tokens.len()) / self.block_size;
        if full_blocks == 0 {
            return None;
        }
        let (seed, seed_block) = sequence
            .deref()
            .get_images()
            .as_ref()
            .map(|img| Self::image_seed_and_block(img, &tokens, self.block_size))
            .unwrap_or((None, None));
        prefix_cache.hash_for_blocks_with_seed(&tokens, full_blocks, seed, seed_block)
    }

    pub fn exact_prefix_hash_for_sequence(
        &self,
        sequence: &Sequence,
        processed_tokens: usize,
    ) -> Option<u64> {
        let prefix_cache = self.prefix_cache.as_ref()?;
        if !prefix_cache.enabled() {
            return None;
        }
        let tokens = sequence.deref().get_token_ids();
        let full_blocks = processed_tokens.min(tokens.len()) / self.block_size;
        if full_blocks == 0 {
            return None;
        }
        let (seed, seed_block) = sequence
            .deref()
            .get_images()
            .as_ref()
            .map(|img| Self::image_seed_and_block(img, &tokens, self.block_size))
            .unwrap_or((None, None));
        prefix_cache.hash_for_blocks_with_seed(&tokens, full_blocks, seed, seed_block)
    }

    pub fn prefix_hash_chain_for_sequence(
        &self,
        sequence: &Sequence,
        processed_tokens: usize,
    ) -> Vec<(usize, u64)> {
        let Some(prefix_cache) = self.prefix_cache.as_ref() else {
            return Vec::new();
        };
        if !prefix_cache.enabled() {
            return Vec::new();
        }
        let tokens = sequence.deref().get_token_ids();
        let full_blocks = processed_tokens.min(tokens.len()) / self.block_size;
        if full_blocks == 0 {
            return Vec::new();
        }
        let (seed, seed_block) = sequence
            .deref()
            .get_images()
            .as_ref()
            .map(|img| Self::image_seed_and_block(img, &tokens, self.block_size))
            .unwrap_or((None, None));
        let mut hashes = Vec::with_capacity(full_blocks);
        for block_count in 1..=full_blocks {
            if let Some(hash) =
                prefix_cache.hash_for_blocks_with_seed(&tokens, block_count, seed, seed_block)
            {
                hashes.push((block_count * self.block_size, hash));
            }
        }
        hashes
    }

    pub fn prefix_block_id_for_sequence(
        &self,
        sequence: &Sequence,
        full_blocks: usize,
    ) -> Option<usize> {
        if full_blocks == 0 {
            return None;
        }
        self.block_tables
            .get(&sequence.deref().get_id())
            .and_then(|table| table.get(full_blocks.saturating_sub(1)))
            .map(|block| block.deref_mut().block_id)
    }

    pub fn record_mamba_prefix_capture(&mut self, hash: u64, block_id: usize) {
        if let Some(old_block_id) = self.prefix_block_id_by_mamba_hash.insert(hash, block_id) {
            if old_block_id != block_id {
                if let Some(hashes) = self.mamba_hashes_by_prefix_block_id.get_mut(&old_block_id) {
                    hashes.remove(&hash);
                    if hashes.is_empty() {
                        self.mamba_hashes_by_prefix_block_id.remove(&old_block_id);
                    }
                }
            }
        }
        self.valid_mamba_prefix_hashes.insert(hash);
        self.mamba_hashes_by_prefix_block_id
            .entry(block_id)
            .or_default()
            .insert(hash);
    }

    pub fn invalidate_mamba_prefix_hash(&mut self, hash: u64) {
        self.valid_mamba_prefix_hashes.remove(&hash);
        if let Some(block_id) = self.prefix_block_id_by_mamba_hash.remove(&hash) {
            if let Some(hashes) = self.mamba_hashes_by_prefix_block_id.get_mut(&block_id) {
                hashes.remove(&hash);
                if hashes.is_empty() {
                    self.mamba_hashes_by_prefix_block_id.remove(&block_id);
                }
            }
        }
    }

    pub fn invalidate_mamba_prefix_hashes(&mut self, hashes: &[u64]) {
        for &hash in hashes {
            self.invalidate_mamba_prefix_hash(hash);
        }
    }

    pub fn valid_mamba_prefix_hashes(&self) -> &HashSet<u64> {
        &self.valid_mamba_prefix_hashes
    }

    fn handle_mamba_prefix_evicted_blocks(&mut self, evicted_block_ids: &[usize]) {
        if evicted_block_ids.is_empty() {
            return;
        }

        for &block_id in evicted_block_ids {
            if let Some(hashes) = self.mamba_hashes_by_prefix_block_id.remove(&block_id) {
                for hash in hashes {
                    self.valid_mamba_prefix_hashes.remove(&hash);
                    self.prefix_block_id_by_mamba_hash.remove(&hash);
                }
            }
        }
    }

    fn resolve_valid_mamba_matched_blocks(
        require_mamba_prefix_snapshots: bool,
        valid_hashes: &HashSet<u64>,
        prefix_cache: &PrefixCache,
        matched_blocks: usize,
        last_hash: Option<u64>,
    ) -> usize {
        if matched_blocks == 0 {
            return 0;
        }
        if !require_mamba_prefix_snapshots {
            return matched_blocks;
        }
        let Some(last_hash) = last_hash else {
            return 0;
        };
        let hashes = prefix_cache.hashes_for_match(last_hash);
        if hashes.len() < matched_blocks {
            return 0;
        }
        let mut valid_blocks = matched_blocks;
        while valid_blocks > 0 {
            let candidate_hash = hashes[valid_blocks - 1];
            if valid_hashes.contains(&candidate_hash) {
                break;
            }
            valid_blocks -= 1;
        }
        valid_blocks
    }

    fn retain_block(&mut self, block: &Arc<PhysicalTokenBlock>) {
        let (was_zero, is_gpu) = {
            let mut inner = block.deref_mut();
            let was_zero = inner.refcount == 0;
            inner.refcount += 1;
            (was_zero, inner.is_gpu)
        };
        if was_zero {
            if is_gpu {
                self.gpu_allocator
                    .free_blocks
                    .retain(|candidate| !Arc::ptr_eq(candidate, block));
            } else {
                self.cpu_allocator
                    .free_blocks
                    .retain(|candidate| !Arc::ptr_eq(candidate, block));
            }
        }
    }

    fn restore_block_table(&mut self, seq_id: usize, table: BlockTable) {
        for block in &table {
            self.retain_block(block);
        }
        self.block_tables.insert(seq_id, table);
    }

    /// Rebuild a running sequence block table without shared prefix-cache blocks.
    /// Returns false when insufficient free GPU blocks are available for full reallocation.
    pub fn fallback_sequence_to_full_prefill(&mut self, sequence: &Sequence) -> bool {
        let seq_id = sequence.deref().get_id();
        let logical_blocks = sequence.deref().get_logical_token_blocks();

        let Some(old_table) = self.block_tables.remove(&seq_id) else {
            return false;
        };

        for block in &old_table {
            self.release_block(block.clone());
        }

        if *self.gpu_allocator.get_num_free_blocks() < logical_blocks {
            let _ = self.evict_prefix_cache_until_free(logical_blocks);
        }

        if *self.gpu_allocator.get_num_free_blocks() < logical_blocks {
            self.restore_block_table(seq_id, old_table);
            return false;
        }

        let mut new_table = VecDeque::with_capacity(logical_blocks);
        for _ in 0..logical_blocks {
            new_table.push_back(self.gpu_allocator.allocate());
        }
        self.block_tables.insert(seq_id, new_table);
        sequence.deref_mut().set_num_cached_tokens(0);
        sequence.deref_mut().set_mamba_prefix_hash(None);
        sequence.deref_mut().clear_mamba_prefix_warmup();
        true
    }

    /// Rebuild a running sequence block table to reuse only the first `cached_tokens`
    /// of its existing shared prefix blocks, allocating the remainder as fresh GPU blocks.
    /// Returns false when insufficient GPU blocks are available for the rebuild.
    pub fn rebuild_sequence_with_cached_prefix(
        &mut self,
        sequence: &Sequence,
        cached_tokens: usize,
    ) -> bool {
        if cached_tokens == 0 {
            return self.fallback_sequence_to_full_prefill(sequence);
        }

        let seq_id = sequence.deref().get_id();
        let logical_blocks = sequence.deref().get_logical_token_blocks();
        let full_blocks = cached_tokens / self.block_size;
        if full_blocks == 0 || full_blocks > logical_blocks {
            return self.fallback_sequence_to_full_prefill(sequence);
        }

        let Some(target_hash) = self.exact_prefix_hash_for_sequence(sequence, cached_tokens) else {
            return self.fallback_sequence_to_full_prefill(sequence);
        };

        let Some(old_table) = self.block_tables.remove(&seq_id) else {
            return false;
        };
        if old_table.len() < full_blocks {
            self.block_tables.insert(seq_id, old_table);
            return false;
        }

        let prefix_blocks = old_table
            .iter()
            .take(full_blocks)
            .cloned()
            .collect::<Vec<_>>();

        for block in &old_table {
            self.release_block(block.clone());
        }
        for block in &prefix_blocks {
            self.retain_block(block);
        }

        let suffix_blocks = logical_blocks.saturating_sub(full_blocks);
        if *self.gpu_allocator.get_num_free_blocks() < suffix_blocks {
            let _ = self.evict_prefix_cache_until_free(suffix_blocks);
        }

        if *self.gpu_allocator.get_num_free_blocks() < suffix_blocks {
            for block in &prefix_blocks {
                self.release_block(block.clone());
            }
            self.restore_block_table(seq_id, old_table);
            return false;
        }

        let mut new_table = VecDeque::with_capacity(logical_blocks);
        for block in prefix_blocks {
            new_table.push_back(block);
        }
        for _ in full_blocks..logical_blocks {
            new_table.push_back(self.gpu_allocator.allocate());
        }
        self.block_tables.insert(seq_id, new_table);
        sequence
            .deref_mut()
            .set_num_cached_tokens(full_blocks * self.block_size);
        sequence
            .deref_mut()
            .set_mamba_prefix_hash(Some(target_hash));
        sequence.deref_mut().clear_mamba_prefix_warmup();
        true
    }

    pub fn can_swap_out_seq_group(&self, seq_group: &SequenceGroup) -> bool {
        if !self.cpu_swap_enabled() {
            return false;
        }
        let prefix_blocks = self.prefix_block_counts(seq_group);
        let mut blocks_required = HashSet::new();
        let mut group_refs = HashMap::new();
        for (seq_id, table) in self
            .block_tables
            .iter()
            .filter(|(id, _)| seq_group.get_seqs().contains_key(id))
        {
            let prefix_count = prefix_blocks.get(seq_id).copied().unwrap_or(0);
            for block in table.iter().skip(prefix_count) {
                let inner = block.deref_mut();
                if !inner.is_gpu {
                    return false;
                }
                blocks_required.insert(inner.block_id);
                *group_refs.entry(inner.block_id).or_insert(0usize) += 1;
            }
        }

        for block_id in group_refs.keys().copied() {
            let Some(block) = self
                .block_tables
                .values()
                .flat_map(|table| table.iter())
                .find(|block| block.deref_mut().block_id == block_id)
            else {
                continue;
            };
            if block.deref_mut().refcount > group_refs[&block_id] {
                return false;
            }
        }
        !blocks_required.is_empty() && blocks_required.len() <= self.cpu_allocator.free_blocks.len()
    }

    pub fn seq_group_block_count(&self, seq_group: &SequenceGroup) -> usize {
        self.swap_in_required_block_count(seq_group)
    }

    fn prefix_block_counts(&self, seq_group: &SequenceGroup) -> HashMap<SeqID, usize> {
        let mut counts = HashMap::new();
        for (seq_id, table) in self
            .block_tables
            .iter()
            .filter(|(id, _)| seq_group.get_seqs().contains_key(id))
        {
            let seq = seq_group.get_seqs().get(seq_id);
            let cached_blocks = if self.prefix_cache_enabled() {
                seq.map(|seq| seq.deref().deref().get_num_cached_tokens() / self.block_size)
                    .unwrap_or(0)
            } else {
                0
            };
            let mut prefix_count = cached_blocks.min(table.len());
            // Shared blocks are never sequence-owned. This also covers shared
            // beam-search blocks that extend beyond the cached-token boundary.
            while prefix_count < table.len() && table[prefix_count].deref_mut().refcount > 1 {
                prefix_count += 1;
            }
            counts.insert(*seq_id, prefix_count);
        }
        counts
    }

    pub fn swap_in_required_block_count(&self, seq_group: &SequenceGroup) -> usize {
        self.block_tables
            .iter()
            .filter(|(id, _)| seq_group.get_seqs().contains_key(id))
            .flat_map(|(_, table)| table.iter())
            .filter(|block| !block.deref_mut().is_gpu)
            .map(|block| block.deref_mut().block_id)
            .collect::<HashSet<_>>()
            .len()
    }

    /// Update the block table so that the sequence does no longer reserve any GPU
    /// physical blocks for its sequence-owned suffix. Shared prefix blocks stay
    /// on GPU when prefix caching is enabled.
    pub fn swap_out(&mut self, seq_group: &SequenceGroup) -> HashMap<usize, usize> {
        let group_id = *seq_group.get_id();
        let prefix_blocks = self.prefix_block_counts(seq_group);
        let mut new_mapping = HashMap::new();
        let mut old_tables = Vec::new();
        let mut new_tables = Vec::new();
        for seq_id in seq_group.get_seqs().keys() {
            let old_table = self.block_tables.get(seq_id).unwrap().clone();
            let prefix_count = prefix_blocks.get(seq_id).copied().unwrap_or(0);
            let mut new_block_table = old_table.clone();
            for (idx, gpu_block) in old_table.iter().enumerate().skip(prefix_count) {
                let gpu_id = gpu_block.deref_mut().block_id;
                let cpu_block = if let Entry::Vacant(entry) = new_mapping.entry(gpu_id) {
                    let cpu_block = self.cpu_allocator.allocate();
                    entry.insert(cpu_block.clone());
                    cpu_block
                } else {
                    let cpu_block = new_mapping.get(&gpu_id).unwrap().clone();
                    cpu_block.deref_mut().refcount += 1;
                    cpu_block
                };
                new_block_table[idx] = cpu_block;
            }
            old_tables.push((*seq_id, old_table));
            new_tables.push((*seq_id, new_block_table.clone()));
            self.block_tables.insert(*seq_id, new_block_table);
        }

        // Release moved GPU suffix blocks immediately so the rest of this
        // scheduling pass sees the same capacity as the pre-existing swap
        // implementation. The pending tables let rollback restore them if
        // the asynchronous cache copy fails.
        for ((_, old_table), (_, new_table)) in old_tables.iter().zip(&new_tables) {
            for old_block in old_table {
                if !new_table
                    .iter()
                    .any(|new_block| Arc::ptr_eq(old_block, new_block))
                {
                    self.gpu_allocator.free_block(old_block.clone());
                }
            }
        }

        self.pending_swap_out.insert(
            group_id,
            PendingBlockSwap {
                old_tables,
                new_tables,
            },
        );

        new_mapping
            .iter()
            .map(|(k, v)| (*k, v.deref_mut().block_id))
            .collect::<HashMap<_, _>>()
    }

    // Returns the COW mapping (src, dst).
    // COW is performed if there are multiple references to the last physical block.
    pub fn append_token_slot_to_seq(&mut self, sequence: &Sequence) -> Option<(usize, usize)> {
        let blocks_to_append = self.blocks_missing_for_sequence(sequence);
        let table = self
            .block_tables
            .get_mut(&sequence.deref_mut().get_id())
            .unwrap();

        if blocks_to_append > 0 {
            for _ in 0..blocks_to_append {
                table.push_back(self.gpu_allocator.allocate());
            }
            return None;
        }

        if sequence.deref_mut().blocks_to_add_new_tok() > 0 {
            return None;
        }

        let last_block = table.back_mut().unwrap();
        assert!(last_block.deref_mut().is_gpu);
        if last_block.deref_mut().refcount == 1 {
            None
        } else {
            // We would be writing into shared, so COW.
            let new_block = self.gpu_allocator.allocate();
            self.gpu_allocator.free_block(last_block.clone());
            let old_number = last_block.deref_mut().block_id;
            let new_number = new_block.deref_mut().block_id;
            *last_block = new_block;
            Some((old_number, new_number))
        }
    }

    pub fn can_swap_in_seq_group(&self, seq_group: &SequenceGroup) -> bool {
        if !self.cpu_swap_enabled() {
            return false;
        }
        self.swap_in_required_block_count(seq_group) <= self.gpu_allocator.free_blocks.len()
    }

    /// Update the block table so that the sequence does no longer reserve any CPU
    /// physical blocks for its suffix. Shared GPU prefix blocks are retained.
    pub fn swap_in(&mut self, seq_group: &SequenceGroup) -> HashMap<usize, usize> {
        let group_id = *seq_group.get_id();
        let mut new_mapping = HashMap::new();
        let mut old_tables = Vec::new();
        let mut new_tables = Vec::new();
        for seq_id in seq_group.get_seqs().keys() {
            let old_table = self.block_tables.get(seq_id).unwrap().clone();
            let mut new_block_table = old_table.clone();
            for (idx, cpu_block) in old_table.iter().enumerate() {
                if cpu_block.deref_mut().is_gpu {
                    continue;
                }
                let cpu_id = cpu_block.deref_mut().block_id;
                let gpu_block = if let Entry::Vacant(entry) = new_mapping.entry(cpu_id) {
                    let gpu_block = self.gpu_allocator.allocate();
                    entry.insert(gpu_block.clone());
                    gpu_block
                } else {
                    let gpu_block = new_mapping.get(&cpu_id).unwrap().clone();
                    gpu_block.deref_mut().refcount += 1;
                    gpu_block
                };
                new_block_table[idx] = gpu_block;
            }
            old_tables.push((*seq_id, old_table));
            new_tables.push((*seq_id, new_block_table.clone()));
            self.block_tables.insert(*seq_id, new_block_table);
        }

        self.pending_swap_in.insert(
            group_id,
            PendingBlockSwap {
                old_tables,
                new_tables,
            },
        );

        new_mapping
            .iter()
            .map(|(k, v)| (*k, v.deref_mut().block_id))
            .collect::<HashMap<_, _>>()
    }

    pub fn finalize_swap_out(&mut self, group_id: usize) {
        self.pending_swap_out.remove(&group_id);
    }

    pub fn rollback_swap_out(&mut self, group_id: usize) {
        let Some(pending) = self.pending_swap_out.remove(&group_id) else {
            return;
        };
        for ((seq_id, old_table), (_, new_table)) in
            pending.old_tables.iter().zip(&pending.new_tables)
        {
            for new_block in new_table {
                if !old_table
                    .iter()
                    .any(|old_block| Arc::ptr_eq(old_block, new_block))
                {
                    self.cpu_allocator.free_block(new_block.clone());
                }
            }
            for old_block in old_table {
                if !new_table
                    .iter()
                    .any(|new_block| Arc::ptr_eq(old_block, new_block))
                {
                    self.retain_block(old_block);
                }
            }
            self.block_tables.insert(*seq_id, old_table.clone());
        }
    }

    pub fn finalize_swap_in(&mut self, group_id: usize) {
        let Some(pending) = self.pending_swap_in.remove(&group_id) else {
            return;
        };
        for ((_, old_table), (_, new_table)) in pending.old_tables.iter().zip(&pending.new_tables) {
            for old_block in old_table {
                if !new_table
                    .iter()
                    .any(|new_block| Arc::ptr_eq(old_block, new_block))
                {
                    self.cpu_allocator.free_block(old_block.clone());
                }
            }
        }
    }

    pub fn rollback_swap_in(&mut self, group_id: usize) {
        let Some(pending) = self.pending_swap_in.remove(&group_id) else {
            return;
        };
        for (seq_id, old_table) in pending.old_tables {
            let current_table = self.block_tables.remove(&seq_id).unwrap_or_default();
            for new_block in &current_table {
                if !old_table
                    .iter()
                    .any(|old_block| Arc::ptr_eq(old_block, new_block))
                {
                    self.gpu_allocator.free_block(new_block.clone());
                }
            }
            self.block_tables.insert(seq_id, old_table);
        }
    }

    fn allocate_with_prefix(&mut self, seq_group: &SequenceGroup, prefill_chunk_size: usize) {
        let block_size = self.block_size;
        let seqs: Vec<_> = seq_group.get_seqs().values().cloned().collect();
        let mut cached_tokens = 0usize;
        let mut block_table = VecDeque::new();

        if let Some(seq) = seqs.first() {
            let tokens = seq.deref().deref().get_token_ids();
            let valid_hashes = self.valid_mamba_prefix_hashes.clone();
            if let Some(prefix_cache) = self.prefix_cache.as_mut() {
                let (seed, seed_block) = seq
                    .deref()
                    .deref()
                    .get_images()
                    .as_ref()
                    .map(|img| Self::image_seed_and_block(img, &tokens, block_size))
                    .unwrap_or((None, None));
                let PrefixMatch {
                    matched_blocks,
                    last_hash,
                } = prefix_cache.match_prefix_with_seed(&tokens, seed, seed_block);
                let full_blocks = tokens.len() / block_size;
                let raw_matched_blocks = if matched_blocks == full_blocks
                    && tokens.len() % block_size == 0
                    && matched_blocks > 0
                {
                    matched_blocks - 1
                } else {
                    matched_blocks
                };
                let mut matched_blocks = Self::resolve_valid_mamba_matched_blocks(
                    self.require_mamba_prefix_snapshots,
                    &valid_hashes,
                    prefix_cache,
                    raw_matched_blocks,
                    last_hash,
                );
                let warmup_target = Self::mamba_warmup_target(
                    self.require_mamba_prefix_snapshots,
                    raw_matched_blocks,
                    matched_blocks,
                    block_size,
                    tokens.len(),
                );
                if raw_matched_blocks > 0 && matched_blocks == 0 {
                    tracing::info!(
                        "Prefix cache mamba-state miss seq {} (raw {} blocks matched, but no compatible mamba snapshot)",
                        seq.deref().deref().get_id(),
                        raw_matched_blocks
                    );
                }
                if matched_blocks > 0 {
                    let mut matched_hash = None;
                    if let Some(hash) = last_hash {
                        let hashes = prefix_cache.hashes_for_match(hash);
                        if hashes.len() >= matched_blocks {
                            matched_hash = Some(hashes[matched_blocks - 1]);
                        } else {
                            matched_blocks = 0;
                        }
                    } else {
                        matched_blocks = 0;
                    }
                    seq.deref_mut().set_mamba_prefix_hash(matched_hash);
                } else {
                    seq.deref_mut().set_mamba_prefix_hash(None);
                }
                seq.deref_mut()
                    .set_mamba_prefix_warmup_tokens(warmup_target);
                if let Some(target_tokens) = warmup_target {
                    tracing::info!(
                        "Seq {}: scheduling mamba prefix warmup snapshot at {} cached tokens (raw {} blocks, no compatible mamba snapshot)",
                        seq.deref().deref().get_id(),
                        target_tokens,
                        raw_matched_blocks
                    );
                }

                cached_tokens = matched_blocks * block_size;
                if matched_blocks > 0 {
                    tracing::info!(
                        "Prefix cache hit seq {} ({} cached tokens, {} blocks)",
                        seq.deref().deref().get_id(),
                        cached_tokens,
                        matched_blocks
                    );
                } else {
                    tracing::info!("Prefix cache miss seq {}", seq.deref().deref().get_id());
                }
                if matched_blocks > 0 {
                    let mut blocks = prefix_cache.blocks_for_match(last_hash.unwrap());
                    blocks.truncate(matched_blocks);
                    for block in blocks {
                        block.deref_mut().refcount += 1;
                        block_table.push_back(block);
                    }
                }
            }
            seq.deref_mut().set_num_cached_tokens(cached_tokens);
            let prefill_end =
                seq.deref().deref().prefill_chunk_tokens(prefill_chunk_size) + cached_tokens;
            let required_blocks = if prefill_chunk_size == 0 {
                seq.deref().deref().get_logical_token_blocks()
            } else {
                prefill_end.div_ceil(block_size)
            };
            for _ in block_table.len()..required_blocks {
                block_table.push_back(self.gpu_allocator.allocate());
            }
        }

        for (idx, seq) in seqs.iter().enumerate() {
            seq.deref_mut().set_num_cached_tokens(cached_tokens);
            let table = block_table.clone();
            if idx > 0 {
                let hash = (*seqs[0]).deref().get_mamba_prefix_hash();
                seq.deref_mut().set_mamba_prefix_hash(hash);
                let warmup_target = (*seqs[0]).deref().active_mamba_prefix_warmup_target();
                seq.deref_mut()
                    .set_mamba_prefix_warmup_tokens(warmup_target);
                for block in &table {
                    block.deref_mut().refcount += 1;
                }
            } else if seq
                .deref()
                .deref()
                .active_mamba_prefix_warmup_target()
                .is_none()
            {
                seq.deref_mut().clear_mamba_prefix_warmup();
            }
            self.block_tables
                .insert(seq.deref().deref().get_id(), table);
        }
    }

    fn release_block(&mut self, block: Arc<PhysicalTokenBlock>) {
        if block.deref_mut().is_gpu {
            self.gpu_allocator.free_block(block);
        } else {
            self.cpu_allocator.free_block(block);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{BlockEngine, PrefixCacheConfig};
    use crate::openai::requests::{EmbeddingType, EncodingFormat};
    use crate::openai::sampling_params::{EarlyStoppingCondition, Logprobs, SamplingParams};
    use crate::scheduler::sequence::{_Sequence, Sequence, SequenceGroup};
    use std::collections::HashMap;
    use std::sync::Arc;
    use std::time::SystemTime;

    fn make_group(
        seq_id: usize,
        group_id: usize,
        block_size: usize,
        tokens: Vec<u32>,
    ) -> (SequenceGroup, Arc<Sequence>) {
        let seq = Arc::new(Sequence(std::sync::RwLock::new(_Sequence::new(
            &tokens, seq_id, block_size, None,
        ))));
        let sampling_params = SamplingParams::new(
            1,
            None,
            0.0,
            0.0,
            None,
            None,
            None,
            None,
            None,
            false,
            1.0,
            EarlyStoppingCondition::UnlikelyBetterCandidates,
            None,
            vec![],
            false,
            16,
            None,
            None,
            true,
            None,
        )
        .expect("sampling params");
        let group = SequenceGroup::new(
            &[seq.clone()],
            0,
            group_id,
            "req".to_string(),
            SystemTime::now(),
            sampling_params,
            false,
            false,
            EncodingFormat::Float,
            EmbeddingType::Last,
            Vec::new(),
            None,
            false,
        );
        (group, seq)
    }

    #[test]
    fn allocate_with_prefix_cache_reuses_blocks() {
        let block_size = 4;
        let mut engine = BlockEngine::new(
            block_size,
            8,
            8,
            0,
            PrefixCacheConfig {
                enabled: true,
                max_cached_blocks: 4,
            },
            false,
        );

        let (group1, seq1) = make_group(1, 1, block_size, vec![1, 2, 3, 4, 5, 6, 7, 8]);
        let mut blocks_to_copy = HashMap::new();
        let free_before = engine.get_num_free_blocks();
        engine.allocate(&group1, &mut blocks_to_copy);
        let free_after_alloc = engine.get_num_free_blocks();
        assert!(free_after_alloc < free_before);

        let cached_block_ids: Vec<usize> = engine
            .block_tables
            .get(&seq1.deref().get_id())
            .unwrap()
            .iter()
            .take(2)
            .map(|block| block.deref_mut().block_id)
            .collect();

        engine.cache_sequence(&seq1);
        engine.free_sequence(&seq1);
        let free_after_free = engine.get_num_free_blocks();
        assert_eq!(free_after_free, free_after_alloc + 1);

        let (group2, seq2) = make_group(
            2,
            2,
            block_size,
            vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        );
        engine.allocate(&group2, &mut blocks_to_copy);
        assert_eq!(seq2.deref().get_num_cached_tokens(), 8);
        let table = engine.block_tables.get(&seq2.deref().get_id()).unwrap();
        assert_eq!(table[0].deref_mut().block_id, cached_block_ids[0]);
        assert_eq!(table[1].deref_mut().block_id, cached_block_ids[1]);
    }

    #[test]
    fn prefix_cache_eviction_does_not_free_active_sequence_blocks() {
        let block_size = 4;
        let mut engine = BlockEngine::new(
            block_size,
            8,
            8,
            0,
            PrefixCacheConfig {
                enabled: true,
                max_cached_blocks: 4,
            },
            false,
        );

        let (group1, seq1) = make_group(1, 1, block_size, vec![1, 2, 3, 4, 5, 6, 7, 8]);
        let mut blocks_to_copy = HashMap::new();
        engine.allocate(&group1, &mut blocks_to_copy);
        engine.cache_sequence(&seq1);
        engine.free_sequence(&seq1);

        let (group2, seq2) = make_group(
            2,
            2,
            block_size,
            vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        );
        engine.allocate(&group2, &mut blocks_to_copy);
        let active_prefix_ids = engine
            .block_tables
            .get(&seq2.deref().get_id())
            .unwrap()
            .iter()
            .take(2)
            .map(|block| block.deref_mut().block_id)
            .collect::<Vec<_>>();

        assert_eq!(engine.evict_prefix_cache_blocks(2), 2);
        let free_ids = engine
            .gpu_allocator
            .free_blocks
            .iter()
            .map(|block| block.deref_mut().block_id)
            .collect::<Vec<_>>();
        for block_id in active_prefix_ids {
            assert!(!free_ids.contains(&block_id));
        }
    }

    #[test]
    fn append_token_slot_repairs_table_after_skipped_boundary_allocation() {
        let block_size = 4;
        let mut engine = BlockEngine::new(
            block_size,
            4,
            4,
            0,
            PrefixCacheConfig {
                enabled: false,
                max_cached_blocks: 0,
            },
            false,
        );

        let (group, seq) = make_group(1, 1, block_size, vec![1, 2, 3, 4]);
        let mut blocks_to_copy = HashMap::new();
        engine.allocate(&group, &mut blocks_to_copy);

        let seq_id = seq.deref().get_id();
        let removed = engine
            .block_tables
            .get_mut(&seq_id)
            .unwrap()
            .pop_back()
            .unwrap();
        engine.gpu_allocator.free_block(removed);

        seq.deref_mut().add_token(Logprobs {
            token: 5,
            logprob: 0.0,
            bytes: String::new(),
            top_logprobs: Vec::new(),
        });
        assert_eq!(seq.deref().get_logical_token_blocks(), 2);
        assert_eq!(engine.block_tables.get(&seq_id).unwrap().len(), 1);

        assert!(engine.can_append_token_to_seq(&group));
        let op = engine.append_token_slot_to_seq(&seq);
        assert!(op.is_none());
        assert_eq!(engine.block_tables.get(&seq_id).unwrap().len(), 2);
    }

    #[test]
    fn allocate_for_prefill_reserves_and_extends_by_chunk() {
        let block_size = 4;
        let mut engine = BlockEngine::new(
            block_size,
            4,
            4,
            0,
            PrefixCacheConfig {
                enabled: false,
                max_cached_blocks: 0,
            },
            false,
        );

        let (group, seq) = make_group(1, 1, block_size, vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
        let mut blocks_to_copy = HashMap::new();
        assert!(matches!(
            engine.can_allocate_for_prefill(&group, block_size),
            super::AllocStatus::Ok
        ));
        engine.allocate_for_prefill(&group, &mut blocks_to_copy, block_size);

        let seq_id = seq.deref().get_id();
        assert_eq!(engine.block_tables.get(&seq_id).unwrap().len(), 1);

        seq.deref_mut().set_num_cached_tokens(4);
        assert_eq!(engine.prefill_chunk_blocks_required(&group, block_size), 1);
        assert!(engine.can_append_prefill_chunk_to_seq_group(&group, block_size));
        engine.append_prefill_chunk_slots_to_seq_group(&group, block_size);
        assert_eq!(engine.block_tables.get(&seq_id).unwrap().len(), 2);

        seq.deref_mut().set_num_cached_tokens(8);
        engine.append_prefill_chunk_slots_to_seq_group(&group, block_size);
        assert_eq!(engine.block_tables.get(&seq_id).unwrap().len(), 3);
    }

    #[test]
    fn rebuild_sequence_with_cached_prefix_shrinks_cached_tokens() {
        let block_size = 4;
        let mut engine = BlockEngine::new(
            block_size,
            8,
            8,
            0,
            PrefixCacheConfig {
                enabled: true,
                max_cached_blocks: 8,
            },
            false,
        );

        let (group, seq) = make_group(
            1,
            1,
            block_size,
            vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        );
        let mut blocks_to_copy = HashMap::new();
        engine.allocate(&group, &mut blocks_to_copy);
        seq.deref_mut().set_num_cached_tokens(8);

        let original_table = engine.block_tables.get(&seq.deref().get_id()).unwrap();
        let original_first_block = original_table[0].deref_mut().block_id;
        let original_len = original_table.len();

        assert!(engine.rebuild_sequence_with_cached_prefix(&seq, 4));

        let rebuilt_table = engine.block_tables.get(&seq.deref().get_id()).unwrap();
        assert_eq!(rebuilt_table.len(), original_len);
        assert_eq!(rebuilt_table[0].deref_mut().block_id, original_first_block);
        assert_eq!(seq.deref().get_num_cached_tokens(), 4);
        assert!(seq.deref().get_mamba_prefix_hash().is_some());
    }
}
