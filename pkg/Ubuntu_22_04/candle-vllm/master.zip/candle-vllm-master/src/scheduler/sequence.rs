use std::{
    collections::HashMap,
    sync::{Arc, RwLock, RwLockReadGuard, RwLockWriteGuard},
};

use super::block_engine::LogicalTokenBlock;
use crate::openai::multimodal::ImageData;
use crate::openai::sampling_params::{Logprobs, SamplingParams};
use crate::openai::streaming::ChatResponse;
use crate::tools::stream_parser::StreamToolParser;
use crate::tools::{Tool, ToolCall};
use std::time::SystemTime;
use tokio::sync::mpsc::Sender;
#[derive(Clone, PartialEq)]
pub enum SequenceStatus {
    FinishedIgnored,
    Waiting,
    Running,
    Swapped,
    Pending,
    FinishedAborted,
    Finished(String),
}

#[derive(Clone, PartialEq, Debug)]
pub enum ToolCallState {
    Normal,
    MaybeToolCall,
    InToolCall,
}

pub struct SequenceData {
    prompt_token_ids: Vec<u32>,
    output_token_ids: Vec<Logprobs>,
    cumulative_logprob: f32,
    status: SequenceStatus,
    num_cached_tokens: usize, //used for chunked prefill and context cache
    // Tool call and reasoning tracking
    pub accumulated_output: String,
    pub tool_call_state: ToolCallState,
    pub tool_call_buffer: String,
    pub active_reasoning_end: Option<String>,
    pub in_code_block: bool,
    pub stream_tool_parser: Option<StreamToolParser>,
    pub pending_tool_calls: Vec<ToolCall>,
    pub pending_finish_logprobs: Option<Logprobs>,
    pub suppressed_tool_markup: String,
    pub prompt_replay_consumed: bool,
    pub stream_role_sent: bool,
    pub images: Option<ImageData>,
    pub mamba_prefix_hash: Option<u64>,
    pub mamba_prefix_warmup_tokens: Option<usize>,
    swapped_time: Option<SystemTime>,
}

impl SequenceData {
    pub fn new(prompt_token_ids: Vec<u32>, images: Option<ImageData>) -> Self {
        Self {
            prompt_token_ids,
            output_token_ids: Vec::new(),
            cumulative_logprob: 0.,
            status: SequenceStatus::Waiting,
            num_cached_tokens: 0,
            accumulated_output: String::new(),
            tool_call_state: ToolCallState::Normal,
            tool_call_buffer: String::new(),
            active_reasoning_end: None,
            in_code_block: false,
            stream_tool_parser: None,
            pending_tool_calls: Vec::new(),
            pending_finish_logprobs: None,
            suppressed_tool_markup: String::new(),
            prompt_replay_consumed: false,
            stream_role_sent: false,
            images,
            mamba_prefix_hash: None,
            mamba_prefix_warmup_tokens: None,
            swapped_time: None,
        }
    }

    pub fn append_token_id(&mut self, logprobs: Logprobs) {
        self.cumulative_logprob += logprobs.logprob;
        self.output_token_ids.push(logprobs);
    }

    pub fn set_status(&mut self, status: SequenceStatus) {
        self.status = status;
    }

    fn get_cumulative_logprob(&self) -> f32 {
        self.cumulative_logprob
    }
}

/// A Sequence holds information about the data it contains (the tokens), and the logical token blocks
/// to which it is mapped.
pub struct _Sequence {
    data: RwLock<SequenceData>,
    seq_id: usize,
    logical_token_blocks: Vec<LogicalTokenBlock>,
    block_size: usize,
}

impl _Sequence {
    pub fn new(
        prompt_token_ids: &Vec<u32>,
        seq_id: usize,
        block_size: usize,
        images: Option<ImageData>,
    ) -> Self {
        let mut this = Self {
            data: RwLock::new(SequenceData::new(prompt_token_ids.clone(), images)),
            seq_id,
            logical_token_blocks: Vec::new(),
            block_size,
        };
        this.append_tokens_to_blocks(prompt_token_ids);
        this
    }

    pub fn add_token(&mut self, logprobs: Logprobs) {
        self.append_token_to_blocks(logprobs.token);
        self.deref_mut().append_token_id(logprobs);
    }

    pub fn blocks_to_add_new_tok(&self) -> usize {
        let last = self.logical_token_blocks.last();
        if !last.is_some_and(|last| last.is_full() || last.is_empty()) {
            // If we have space
            0
        } else {
            1
        }
    }

    pub fn get_logical_token_blocks(&self) -> usize {
        self.logical_token_blocks.len()
    }

    pub fn get_id(&self) -> usize {
        self.seq_id
    }

    pub fn is_prompt(&self) -> bool {
        self.deref().output_token_ids.is_empty()
    }

    pub fn get_prompt_len(&self) -> usize {
        self.deref().prompt_token_ids.len()
    }

    pub fn get_len(&self) -> usize {
        let dref = self.deref();
        dref.prompt_token_ids.len() + dref.output_token_ids.len()
    }

    pub fn get_token_ids(&self) -> Vec<u32> {
        let mut res = self.deref().prompt_token_ids.clone();
        res.extend(
            self.deref()
                .output_token_ids
                .iter()
                .map(|logprobs| logprobs.token)
                .clone(),
        );
        res
    }

    pub fn get_last_token_id(&self) -> u32 {
        if self.deref().output_token_ids.is_empty() {
            *self.deref().prompt_token_ids.last().unwrap()
        } else {
            self.deref().output_token_ids.last().unwrap().token
        }
    }

    pub fn is_finished(&self) -> bool {
        matches!(
            self.deref().status,
            SequenceStatus::FinishedAborted
                | SequenceStatus::FinishedIgnored
                | SequenceStatus::Finished(_)
        )
    }

    pub fn get_status(&self) -> SequenceStatus {
        self.deref().status.clone()
    }

    pub fn get_cumulative_logprob(&self) -> f32 {
        self.deref().get_cumulative_logprob()
    }

    pub fn set_finish_reason(&mut self, finish_reason: String) {
        self.deref_mut()
            .set_status(SequenceStatus::Finished(finish_reason.clone()));
    }

    pub fn get_finish_reason(&self) -> String {
        match &self.deref().status {
            SequenceStatus::Finished(state) => state.clone(),
            SequenceStatus::FinishedAborted => "abort".to_string(),
            SequenceStatus::FinishedIgnored => "length".to_string(),
            _ => {
                unreachable!("No finish reason.")
            }
        }
    }

    #[must_use]
    /// Clones the internal logprobs.
    pub fn get_output_tokens(&self) -> Vec<Logprobs> {
        self.deref().output_token_ids.clone() // TODO(EricLBuehler): Better way to do this?
    }

    fn append_tokens_to_blocks(&mut self, tokens: &Vec<u32>) {
        for tok in tokens {
            self.append_token_to_blocks(*tok);
        }
    }

    fn append_token_to_blocks(&mut self, token: u32) {
        let last = self.logical_token_blocks.last_mut();
        match last {
            Some(last) => {
                last.append_token_id(token);
            }
            _ => {
                self.logical_token_blocks
                    .push(LogicalTokenBlock::new(self.block_size));
                self.logical_token_blocks
                    .last_mut()
                    .unwrap()
                    .append_token_id(token);
            }
        }
        if self.logical_token_blocks.last().as_ref().unwrap().is_full() {
            self.logical_token_blocks
                .push(LogicalTokenBlock::new(self.block_size));
        }
    }

    pub fn get_num_cached_tokens(&self) -> usize {
        self.deref().num_cached_tokens
    }

    pub fn set_num_cached_tokens(&mut self, num_cached_tokens: usize) {
        self.deref_mut().num_cached_tokens = num_cached_tokens;
    }

    pub fn swapped_time(&self) -> Option<SystemTime> {
        self.deref().swapped_time
    }

    pub fn set_swapped_time(&mut self, swapped_time: Option<SystemTime>) {
        self.deref_mut().swapped_time = swapped_time;
    }

    pub fn get_images(&self) -> Option<ImageData> {
        self.deref().images.clone()
    }

    pub fn set_images(&mut self, images: Option<ImageData>) {
        self.deref_mut().images = images;
    }

    pub fn get_mamba_prefix_hash(&self) -> Option<u64> {
        self.deref().mamba_prefix_hash
    }

    pub fn set_mamba_prefix_hash(&mut self, hash: Option<u64>) {
        self.deref_mut().mamba_prefix_hash = hash;
    }

    pub fn set_mamba_prefix_warmup_tokens(&mut self, tokens: Option<usize>) {
        self.deref_mut().mamba_prefix_warmup_tokens = tokens;
    }

    pub fn clear_mamba_prefix_warmup(&mut self) {
        self.deref_mut().mamba_prefix_warmup_tokens = None;
    }

    pub fn active_mamba_prefix_warmup_target(&self) -> Option<usize> {
        let data = self.deref();
        let target_tokens = data.mamba_prefix_warmup_tokens?;
        if target_tokens > data.num_cached_tokens && target_tokens < data.prompt_token_ids.len() {
            Some(target_tokens)
        } else {
            None
        }
    }

    pub fn prefill_chunk_tokens(&self, default_chunk_size: usize) -> usize {
        let data = self.deref();
        let remaining = data
            .prompt_token_ids
            .len()
            .saturating_sub(data.num_cached_tokens);
        if remaining == 0 {
            return 0;
        }
        if default_chunk_size == 0 {
            return remaining;
        }
        if let Some(target_tokens) = data.mamba_prefix_warmup_tokens {
            if target_tokens > data.num_cached_tokens && target_tokens < data.prompt_token_ids.len()
            {
                let to_target = target_tokens - data.num_cached_tokens;
                return to_target.min(default_chunk_size);
            }
        }
        remaining.min(default_chunk_size)
    }
}

impl _Sequence {
    pub fn deref(&self) -> RwLockReadGuard<'_, SequenceData> {
        // loop {
        //     if let Ok(res) = self.data.try_lock() {
        //         return res;
        //     }
        // }
        self.data.read().unwrap_or_else(|e| e.into_inner())
    }

    pub fn deref_mut(&self) -> RwLockWriteGuard<'_, SequenceData> {
        // loop {
        //     if let Ok(res) = self.data.try_lock() {
        //         return res;
        //     }
        // }
        self.data.write().unwrap_or_else(|e| e.into_inner())
    }
}

pub struct Sequence(pub RwLock<_Sequence>);

impl Sequence {
    pub fn deref(&self) -> RwLockReadGuard<'_, _Sequence> {
        self.0.read().unwrap_or_else(|e| e.into_inner())
    }

    pub fn deref_mut(&self) -> RwLockWriteGuard<'_, _Sequence> {
        // loop {
        //     if let Ok(v) = self.0.try_lock() {
        //         return v;
        //     }
        // }
        self.0.write().unwrap_or_else(|e| e.into_inner())
    }
}

type SeqID = usize;

/// A SequenceGroup holds the `n` (see SamplingParams) sequences generated from a single prompt.
/// A SequenceGroup contains only sequences with the same prompt. They will always be scheduled together.
pub struct SequenceGroup {
    seqs: HashMap<SeqID, Arc<Sequence>>,
    pub arrival_time: u64,
    pub group_id: usize,
    pub request_id: String,
    pub created_time: SystemTime,
    pub sampling_params: SamplingParams,
    pub use_logprobs: bool,
    pub is_embedding: bool,
    pub encoding_format: crate::openai::requests::EncodingFormat,
    pub embedding_type: crate::openai::requests::EmbeddingType,
    pub tools: Vec<Tool>,
    pub sender: Option<Sender<ChatResponse>>,
    pub include_usage: bool,
    // Tool call and reasoning tracking
    pub accumulated_output: String,
    pub tool_call_state: ToolCallState,
    pub tool_call_buffer: String,
    pub active_reasoning_end: Option<String>,
    pub in_code_block: bool,
    /// Token IDs from the generation-prompt suffix (e.g. `<think>\n`) that
    /// should be replayed through the streaming tool parser before the first
    /// real decoded token, so the parser sees the reasoning start marker.
    pub prompt_replay_token_ids: Option<Vec<u32>>,
}

impl SequenceGroup {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        seqs: &[Arc<Sequence>],
        arrival_time: u64,
        group_id: usize,
        request_id: String,
        created_time: SystemTime,
        sampling_params: SamplingParams,
        use_logprobs: bool,
        is_embedding: bool,
        encoding_format: crate::openai::requests::EncodingFormat,
        embedding_type: crate::openai::requests::EmbeddingType,
        tools: Vec<Tool>,
        sender: Option<Sender<ChatResponse>>,
        include_usage: bool,
    ) -> Self {
        let mut seq_map = HashMap::new();
        for seq in seqs {
            seq_map.insert(seq.deref_mut().get_id(), seq.clone());
        }
        Self {
            seqs: seq_map,
            arrival_time,
            group_id,
            request_id,
            created_time,
            sampling_params,
            use_logprobs,
            is_embedding,
            encoding_format,
            embedding_type,
            tools,
            sender,
            include_usage,
            accumulated_output: "".to_string(),
            tool_call_state: ToolCallState::Normal,
            tool_call_buffer: String::new(),
            active_reasoning_end: None,
            in_code_block: false,
            prompt_replay_token_ids: None,
        }
    }

    pub fn set_status(&self, status: SequenceStatus) {
        // for seq in self.seqs.values() {
        //     seq.deref_mut().deref().set_status(status.clone());
        // }
        for seq in self.seqs.values() {
            // Lock each sequence individually and set the status
            if let Ok(seq_guard) = seq.0.write() {
                seq_guard.deref_mut().set_status(status.clone());
            }
        }
    }

    pub fn get_status(&self) -> SequenceStatus {
        self.seqs
            .iter()
            .min_by_key(|(seq_id, _)| *seq_id)
            .expect("sequence group must contain at least one sequence")
            .1
            .deref()
            .get_status()
    }

    /// Blocks to add one new token to each sequence
    pub fn total_blocks_to_add_new_tok(&self) -> usize {
        self.seqs
            .values()
            .map(|seq| seq.deref().blocks_to_add_new_tok())
            .sum()
    }

    pub fn get_prompt_len(&self) -> usize {
        self.seqs
            .iter()
            .min_by_key(|(seq_id, _)| *seq_id)
            .expect("sequence group must contain at least one sequence")
            .1
            .deref()
            .get_prompt_len()
    }

    pub fn get_total_logical_token_blocks(&self) -> usize {
        self.seqs
            .values()
            .map(|seq| seq.deref().get_logical_token_blocks())
            .sum()
    }

    pub fn get_seqs(&self) -> &HashMap<SeqID, Arc<Sequence>> {
        &self.seqs
    }

    pub fn arrival_time(&self) -> u64 {
        self.arrival_time
    }

    pub fn get_id(&self) -> &usize {
        &self.group_id
    }

    pub fn is_finished(&self) -> bool {
        self.seqs.iter().all(|(_, x)| x.deref().is_finished())
    }

    pub fn get_request_id(&self) -> &String {
        &self.request_id
    }

    pub fn get_created_time(&self) -> SystemTime {
        self.created_time
    }
}

#[cfg(test)]
mod tests {
    use super::_Sequence;

    fn test_sequence(len: usize) -> _Sequence {
        let tokens = (0..len as u32).collect::<Vec<_>>();
        _Sequence::new(&tokens, 0, 64, None)
    }

    #[test]
    fn prefill_chunk_tokens_uses_mamba_warmup_boundary() {
        let mut seq = test_sequence(20_000);
        seq.set_num_cached_tokens(0);
        seq.set_mamba_prefix_warmup_tokens(Some(5_824));

        assert_eq!(seq.prefill_chunk_tokens(8_192), 5_824);

        seq.set_num_cached_tokens(5_824);
        assert_eq!(seq.prefill_chunk_tokens(8_192), 8_192);
    }

    #[test]
    fn prefill_chunk_tokens_tracks_multi_chunk_mamba_warmup_boundary() {
        let mut seq = test_sequence(50_000);
        seq.set_mamba_prefix_warmup_tokens(Some(20_000));

        assert_eq!(seq.prefill_chunk_tokens(8_192), 8_192);

        seq.set_num_cached_tokens(8_192);
        assert_eq!(seq.prefill_chunk_tokens(8_192), 8_192);

        seq.set_num_cached_tokens(16_384);
        assert_eq!(seq.prefill_chunk_tokens(8_192), 3_616);

        seq.set_num_cached_tokens(20_000);
        assert_eq!(seq.prefill_chunk_tokens(8_192), 8_192);
    }

    #[test]
    fn prefill_chunk_tokens_ignores_invalid_mamba_warmup_boundary() {
        let mut seq = test_sequence(10_000);
        seq.set_num_cached_tokens(4_096);
        seq.set_mamba_prefix_warmup_tokens(Some(4_096));

        assert_eq!(seq.prefill_chunk_tokens(8_192), 5_904);

        seq.set_mamba_prefix_warmup_tokens(Some(12_000));
        assert_eq!(seq.prefill_chunk_tokens(8_192), 5_904);
    }

    #[test]
    fn prefill_chunk_tokens_zero_chunk_size_ignores_warmup_boundary() {
        let mut seq = test_sequence(10_000);
        seq.set_num_cached_tokens(1_000);
        seq.set_mamba_prefix_warmup_tokens(Some(5_000));

        assert_eq!(seq.prefill_chunk_tokens(0), 9_000);
    }
}
