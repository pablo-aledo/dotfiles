mod cache;
pub mod gguf;
pub mod gptq;
#[cfg(feature = "cuda")]
pub fn get_or_load_func(
    ptx_file: &'static str,
    kernel_base: &str,
    dtype: candle_core::DType,
    suffix: Option<&str>,
    device: &CudaDevice,
) -> Result<CudaFunction, APIError> {
    use candle_core::DType;
    let spec = match dtype {
        DType::U8 => "_u8",
        DType::U32 => "_u32",
        DType::I64 => "_i64",
        DType::BF16 => "_bf16",
        DType::F16 => "_f16",
        DType::F32 => "_f32",
        DType::F64 => "_f64",
        DType::F8E8M0 | DType::F8E4M3 => "_u8",
    };
    let spec = if let Some(suffix) = suffix {
        spec.to_owned() + suffix
    } else {
        spec.to_owned()
    };
    let kernel = kernel_base.to_owned() + &spec;
    device
        .get_or_load_func(&kernel, ptx_file)
        .map_err(APIError::from)
}

#[allow(unused_imports)]
use crate::openai::responses::APIError;
pub use cache::*;
#[cfg(feature = "cuda")]
use candle_core::{cuda_backend::cudarc::driver::CudaFunction, CudaDevice};
pub use gptq::*;
pub use std::ops::Deref;
pub mod custom_ops;
#[cfg(all(feature = "cuda", feature = "graph"))]
pub mod graph;
#[cfg(feature = "nccl")]
pub mod heartbeat;
pub mod progress;
