const L = require("../index")
const l = new L();
(async () => {
  await l.install("7B")
})();
