const Dalai = require("../index")
new Dalai().serve(3000)
