# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025-2026  Philipp Emanuel Weidmann <pew@worldwidemann.com> + contributors

from dataclasses import dataclass
from typing import Any

from optuna.study import StudyDirection
from pydantic import BaseModel

from .config import DatasetSpecification, ScorerConfig, Settings
from .model import Model
from .plugin import Context, is_builtin_plugin, load_plugin
from .scorer import Score, Scorer
from .utils import parse_study_direction, print


@dataclass
class ScorerEntry:
    scorer: Scorer
    name: str
    config: ScorerConfig


class Evaluator:
    """
    Manages evaluation of the model using configured scorer plugins.

    Loads scorers, establishes baseline scores, and runs scorers during optimization.
    """

    settings: Settings
    model: Model

    def __init__(self, settings: Settings, model: Model):
        self.settings = settings
        self.model = model
        self._scorer_entries: list[ScorerEntry] = []

        print()
        print("Loading and initializing scorers...")
        self._load_and_init_scorers()

        print()
        print("Getting baseline scores...")
        self.baseline_scores = self.get_baseline_scores()
        for name, score in self.baseline_scores:
            print(f"* Baseline [bold]{name}:[/] [green]{score.rich_display}[/]")

    def _load_and_init_scorers(self) -> None:
        """
        Load and instantiate all configured scorer plugins,
        then runs their initialization hooks.
        """
        scorer_configs = self.settings.scorers
        if not scorer_configs:
            raise ValueError("No scorers configured. Set 'scorers' in config.toml")

        scorer_keys: set[str] = set()

        # Resolve plugin classes from names and validate.
        for config in scorer_configs:
            scorer_cls = load_plugin(name=config.plugin, base_class=Scorer)
            scorer_cls.validate_contract()

            print(
                f"* Loaded: [bold]{scorer_cls.__name__}{' - ' + config.instance_name if config.instance_name else ''}[/bold]"
            )

            # Instantiate scorers.
            instance_name = config.instance_name or None

            raw_settings = scorer_cls.get_settings_raw(
                self.settings.model_extra,
                "scorer",
                instance_name,
            )
            scorer_settings: BaseModel | None = scorer_cls.validate_settings(
                raw_settings
            )

            scorer = scorer_cls(
                heretic_settings=self.settings,
                settings=scorer_settings,
            )

            # External labeling key: ensures multiple instances can coexist.
            # Uses underscore to match the TOML namespace format (`scorer.<Class>_<instance>`).
            scorer_key = (
                scorer_cls.__name__
                if not instance_name
                else f"{scorer_cls.__name__}_{instance_name}"
            )
            if scorer_key in scorer_keys:
                raise ValueError(
                    f"Duplicate scorer instance name: {scorer_key}. "
                    "Give each instance a unique `instance_name`."
                )
            scorer_keys.add(scorer_key)

            scorer_instance_name = (
                f"{scorer.score_name} - {instance_name}"
                if instance_name
                else scorer.score_name
            )
            self._scorer_entries.append(
                ScorerEntry(scorer=scorer, config=config, name=scorer_instance_name)
            )

        # Run scorer init hooks.
        ctx = Context(settings=self.settings, model=self.model)

        for entry in self._scorer_entries:
            entry.scorer.init(ctx)

    def get_dataset_specifications(self) -> list[DatasetSpecification]:
        """
        Collect the dataset specifications declared in the settings of all
        loaded scorers.
        """
        specifications = []
        for entry in self._scorer_entries:
            specifications.extend(entry.scorer.get_dataset_specifications())
        return specifications

    def all_scorers_reproducible(self) -> bool:
        """
        Returns True if all scorers are reproducible,
        False if not.
        """
        return all(entry.scorer.reproducible for entry in self._scorer_entries)

    def all_scorers_builtin(self) -> bool:
        """
        Returns True if all scorers are built-in,
        i.e included in Heretic by default.
        """
        return all(
            is_builtin_plugin(entry.config.plugin) for entry in self._scorer_entries
        )

    def get_scores(self) -> list[tuple[str, Score]]:
        """
        Run all scorers and return their scores and names

        Returns:
            List of `Score` from each scorer and its name.
        """
        ctx = Context(settings=self.settings, model=self.model)
        return [
            (entry.name, entry.scorer.get_score(ctx)) for entry in self._scorer_entries
        ]

    def get_baseline_scores(self) -> list[tuple[str, Score]]:
        """
        Run all scorers and return their baseline scores and names

        Returns:
            List of `Score` from each scorer and its name.
        """
        ctx = Context(settings=self.settings, model=self.model)
        return [
            (entry.name, entry.scorer.get_baseline_score(ctx))
            for entry in self._scorer_entries
        ]

    def get_paired_score_records(
        self, scores: list[tuple[str, Score]]
    ) -> list[dict[str, Any]]:
        """
        Pair each trial score with its baseline into one serializable record.

        `scores` (from `get_scores()`) and `self.baseline_scores` are both ordered
        by `_scorer_entries`, so they align positionally.
        """
        records: list[dict[str, Any]] = []
        for (name, score), (baseline_name, baseline) in zip(
            scores, self.baseline_scores
        ):
            assert name == baseline_name, (
                f"Score/baseline order mismatch: {name!r} != {baseline_name!r}"
            )
            records.append(
                {
                    "name": name,
                    "score": dict(score.__dict__),
                    "baseline": dict(baseline.__dict__),
                }
            )
        return records

    def _objective_entries(self) -> list[ScorerEntry]:
        """
        Scorer entries that participate in optimization, in canonical order.
        Single source of truth for which scorers are objectives and in what
        order. Every objective-derived list (names, directions, values) is built
        from this so they stay positionally aligned: Optuna matches the objective
        values returned each trial to the study `directions` by index, so a length
        or order mismatch here would silently corrupt the optimization.
        """
        return [
            entry
            for entry in self._scorer_entries
            if parse_study_direction(entry.config.optimization)
            != StudyDirection.NOT_SET
        ]

    def get_objective_names(self) -> list[str]:
        """Return objective names for scores used in optimization."""
        return [entry.name for entry in self._objective_entries()]

    def get_objective_values(
        self, scores: list[tuple[str, Score]]
    ) -> tuple[float, ...]:
        """
        Extract objective values as a tuple for Optuna.

        Ordered by `_objective_entries()` so the result aligns by index with
        `get_objective_names()` and `get_objective_directions()`.
        """
        score_by_name = {name: score for name, score in scores}
        return tuple(
            score_by_name[entry.name].value for entry in self._objective_entries()
        )

    def get_objective_directions(self) -> list[StudyDirection]:
        """Get optimization directions for objectives."""
        return [
            parse_study_direction(entry.config.optimization)
            for entry in self._objective_entries()
        ]
