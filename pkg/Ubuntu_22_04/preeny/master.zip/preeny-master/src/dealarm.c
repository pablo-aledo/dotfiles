#include "logging.h"

unsigned int alarm(unsigned int seconds)
{
	preeny_info("alarm blocked\n");
	return 0;
}
