package complete

func Bash() string {
	return `complete -o filenames -C fx fx
`
}
