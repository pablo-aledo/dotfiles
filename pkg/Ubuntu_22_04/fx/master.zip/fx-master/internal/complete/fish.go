package complete

func Fish() string {
	return `complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'
`
}
