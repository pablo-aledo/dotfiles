# Updating

The bindings are automatically generated. See [CONTRIBUTING](../../../CONTRIBUTING.md#regenerating-the-ggml-bindings).
