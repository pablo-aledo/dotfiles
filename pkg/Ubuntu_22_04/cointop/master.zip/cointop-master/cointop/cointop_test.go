package cointop

import (
	"testing"
)

// TestRun tests that cointop runs
func TestRun(t *testing.T) {
	// Run()
}
