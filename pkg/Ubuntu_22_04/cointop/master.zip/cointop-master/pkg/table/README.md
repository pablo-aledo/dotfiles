gocui table
