---
title: "Searching"
date: 2020-01-01T00:00:00-00:00
draft: false
---
# Searching

To search for coins, press <kbd>/</kbd> to bring up the search prompt. Enter the search query and then hit <kbd>Enter</kbd> to submit. The coin that matches closes to the query will be highlighted.

Press <kbd>Esc</kbd> to exit the search prompt.
