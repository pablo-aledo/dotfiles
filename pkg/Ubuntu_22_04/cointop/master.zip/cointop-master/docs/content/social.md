---
title: "Social"
date: 2020-01-01T00:00:00-00:00
draft: false
---
# Social

- Follow on twitter [@cointop](https://twitter.com/cointop)
- Discuss on [Discord](https://discord.gg/pUVGy7ECGg)

## Mentioned in

Cointop has been mentioned in:

- [@Ubuntu Twitter](https://twitter.com/ubuntu/status/985947962311311360?lang=en)
- [Ubuntu Podcast](https://ubuntupodcast.org/2018/04/12/s11e06-six-feet-over-it/)
- [Terminals Are Sexy](https://github.com/k4m4/terminals-are-sexy#tools-and-plugins)
- [The Changelog News](https://changelog.com/news/cointop-coin-tracking-for-hackers-rAzZ)
