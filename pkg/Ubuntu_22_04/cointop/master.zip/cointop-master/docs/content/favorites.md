---
title: "Favorites"
date: 2020-01-01T00:00:00-00:00
draft: false
---
# Favorites

## View favorites

To view your portfolio, press <kbd>F</kbd> (Shift+f)

## Exit favorites

To exit out of the portfolio view press, <kbd>F</kbd> (Shift+f) again or <kbd>q</kbd> or <kbd>Esc</kbd>

## Add favorite

To add a coin to your favorites, press <kbd>f</kbd> or <kbd>Space</kbd> on the highlighted coin to favorite. Favorited coins are marked with an `*` asterisk.

## Remove favorite

To remove a coin from your favorites, press <kbd>f</kbd> or <kbd>Space</kbd> on the favorited highlighted coin to unfavorite.
