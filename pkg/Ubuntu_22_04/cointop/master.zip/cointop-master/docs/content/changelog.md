---
title: "Changelog"
date: 2020-01-01T00:00:00-00:00
draft: false
---
# Changelog

See [CHANGELOG.md](https://github.com/cointop-sh/cointop/blob/master/CHANGELOG.md) on Github for a user-friendly changelog.

See [releases](https://github.com/cointop-sh/cointop/releases) on Github for more detailed commit information of each release.
