---
title: "Assets"
date: 2020-01-01T00:00:00-00:00
draft: false
---
# Assets

## Logo

<a href="https://s3.amazonaws.com/assets.cointop.sh/logo/cointop.png">
  <img src="https://s3.amazonaws.com/assets.cointop.sh/logo/cointop.png" />
</a>

## Header

<a href="https://s3.amazonaws.com/assets.cointop.sh/logo/cointop.png">
  <img src="https://s3.amazonaws.com/assets.cointop.sh/header/cointop.png" />
</a>

## Colors

- Black: `#000000`
- Green: `#00FF00`
- Cyan: `#00FFFF`

## Font

["Alien Encounters - Regular"](https://www.dafont.com/alien-encounters.font?text=COINTOP)
