---
title: "Tip Jar"
date: 2020-01-01T00:00:00-00:00
draft: false
---
# Tip Jar

[![BTC Tip Jar](https://img.shields.io/badge/BTC-tip-yellow.svg?logo=bitcoin&style=flat)](https://www.blockchain.com/btc/address/3KdMW53vUMLPEC33xhHAUx4EFtvmXQF8Kf) `3KdMW53vUMLPEC33xhHAUx4EFtvmXQF8Kf`

[![ETH Tip Jar](https://img.shields.io/badge/ETH-tip-blue.svg?logo=ethereum&style=flat)](https://etherscan.io/address/0xC014b8F6F43f467922E93De62C9216F0538E0F8f) `0xC014b8F6F43f467922E93De62C9216F0538E0F8f`

Thank you for tips! 🙏
