#### Assets

Some of these cointop assets are being used in the cointop [flatpak](https://github.com/flathub/com.github.miguelmota.Cointop/blob/master/com.github.miguelmota.Cointop.json).

Make sure to update flatpak if modifying names of assets in here.
