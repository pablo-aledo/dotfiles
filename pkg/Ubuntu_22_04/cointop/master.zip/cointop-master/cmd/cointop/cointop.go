package main

import (
	cmd "github.com/cointop-sh/cointop/cmd/commands"
)

func main() {
	cmd.Execute()
}
