"""Drawing of separate map elements."""
