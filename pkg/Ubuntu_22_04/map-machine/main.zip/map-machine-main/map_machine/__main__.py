"""Map Machine entry point."""
from map_machine.main import main

__author__ = "Sergey Vartanov"
__email__ = "me@enzet.ru"

if __name__ == "__main__":
    main()
