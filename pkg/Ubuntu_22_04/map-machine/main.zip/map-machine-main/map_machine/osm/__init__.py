"""OpenStreetMap-specific things."""
