"""Icons and points."""
