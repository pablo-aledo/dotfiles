"""Tiles generation for slippy maps."""
