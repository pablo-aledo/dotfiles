"""Map geometry: dealing with coordinates, projections."""
