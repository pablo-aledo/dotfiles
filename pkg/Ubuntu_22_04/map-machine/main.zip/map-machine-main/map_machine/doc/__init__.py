"""Documentation utilities."""
