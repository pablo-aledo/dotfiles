---@class LazyVimGlobals
vim.g = {}

_G.lazyvim_docs = true
