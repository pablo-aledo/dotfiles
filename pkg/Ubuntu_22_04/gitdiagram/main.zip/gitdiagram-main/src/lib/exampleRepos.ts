export const exampleRepos = {
  FastAPI: "/fastapi/fastapi",
  Streamlit: "/streamlit/streamlit",
  Flask: "/pallets/flask",
  "api-analytics": "/tom-draper/api-analytics",
  Monkeytype: "/monkeytypegame/monkeytype",
};
