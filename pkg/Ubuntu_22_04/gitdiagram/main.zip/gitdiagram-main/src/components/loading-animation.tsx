"use client";

import { trio } from "ldrs";

trio.register();

const LoadingAnimation = () => {
  return <l-trio size="40" speed="2.0" color="black" />;
};

export default LoadingAnimation;
