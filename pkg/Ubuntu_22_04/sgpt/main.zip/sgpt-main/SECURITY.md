# Security Policy

## Supported Versions

Only the last stable version at any given point.

## Reporting a Vulnerability

Vulnerabilies can be disclosed in private using GitHub
advisories: [https://github.com/tbckr/sgpt/security](https://github.com/tbckr/sgpt/security)

Thanks!
