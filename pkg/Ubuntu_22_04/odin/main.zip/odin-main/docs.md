If you made changes to the code, do:

1. ```docker build -t patrikkukic/odin:latest .```
2. ```docker push patrikkukic/odin:latest```
