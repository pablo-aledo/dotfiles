export interface Selection {
    anchor: {
        ch: number,
        line: number,
    },
    head: {
        ch: number,
        line: number,
    }
}