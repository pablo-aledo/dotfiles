export const loadingText = "Data loading. Please wait.";

export const noSelectedText = "Please select some text and try again.";

export const fetchFailed = "Failed fetching data. Please try again.";

export const updateFailed = "Failed updating data. You might need to restart the app.";