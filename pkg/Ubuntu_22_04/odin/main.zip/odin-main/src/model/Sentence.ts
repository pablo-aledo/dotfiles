export interface Sentence {
    content: string,
    repo: {
        path: string,
        type: string,
    },
}