export interface AnalyticsNode {
    id: number,
    repo: {
        path: string,
        type: string,
    },
}