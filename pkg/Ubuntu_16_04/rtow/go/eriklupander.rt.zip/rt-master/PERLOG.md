# Some performance numbers

Std scene, 640x480

### Single threaded
real	0m45.319s
user	1m11.707s
sys	0m0.728s

real	0m45.428s
user	1m12.641s
sys	0m0.689s

real	0m44.951s
user	1m11.773s
sys	0m0.687s

### One pixel per worker
real	0m19.696s
user	2m11.190s
sys	0m1.676s

real	0m19.948s
user	2m15.547s
sys	0m1.729s

### One line per worker
real	0m19.516s
user	2m3.791s
sys	0m2.076s

real	0m19.387s
user	2m1.752s
sys	0m1.910s

real	0m18.921s
user	1m59.795s
sys	0m1.933s

New big: 17m14.517650246s