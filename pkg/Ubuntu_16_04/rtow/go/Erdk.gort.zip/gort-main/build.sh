#!/bin/bash

go build .
