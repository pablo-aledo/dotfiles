# GoRaytracing
Go raytracer implemented from scratch based on the "ray tracing in one weekend" by Peter Shirley

It's a small learning project to learn Go, don't expect the best quality code or practices.
I will update as I learn more

![Render](/show.png)
