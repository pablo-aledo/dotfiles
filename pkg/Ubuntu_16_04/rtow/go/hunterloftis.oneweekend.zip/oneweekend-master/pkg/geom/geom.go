// Package geom provides types for manipulating 3D vectors
// and 3D unit vectors.
package geom
