package messages

const (
	RenderRequest         = "Render"
	PixelResult           = "Pixel"
	RenderingCompleted    = "Rendered"
	RenderRequestResponse = "RenderResponse"
)
