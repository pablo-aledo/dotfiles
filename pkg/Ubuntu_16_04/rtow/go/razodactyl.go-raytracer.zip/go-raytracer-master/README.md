# Go Ray Tracer
Ray tracing tutorial written so I could learn Golang.

See: https://raytracing.github.io/

![Image rendered using this project.](/images/screenshot.png)
