#! /bin/sh

cd `dirname $0`
java -jar ./target/scala-2.12/ray-tracing-iow.jar "$@"