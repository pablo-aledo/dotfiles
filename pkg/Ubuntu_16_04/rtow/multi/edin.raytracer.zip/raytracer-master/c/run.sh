g++ RayTracer.c -x c -O3 -o gcc-raytracer.exe
./gcc-raytracer.exe
