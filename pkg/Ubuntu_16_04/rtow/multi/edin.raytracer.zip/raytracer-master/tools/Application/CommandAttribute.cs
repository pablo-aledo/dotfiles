﻿using System;

namespace Tools.Application
{
    internal class CommandAttribute : Attribute
    {
    }
}