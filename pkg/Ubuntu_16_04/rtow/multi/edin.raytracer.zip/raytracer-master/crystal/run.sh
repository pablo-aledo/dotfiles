crystal build RayTracer.cr -o RayTracer.exe --release
./RayTracer.exe