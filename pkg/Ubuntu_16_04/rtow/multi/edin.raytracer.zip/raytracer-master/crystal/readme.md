# Install

Restore packages using:

```
shards install --ignore-crystal-version
```

# Run

Run raytracer using:

```
./run.sh
```