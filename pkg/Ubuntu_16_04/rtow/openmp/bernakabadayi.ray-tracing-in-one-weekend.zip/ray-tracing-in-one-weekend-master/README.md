## Sample Outputs

![Image](png/output_1.png "Title")
![Target image](png/output_2.png)
![Predicted image](png/output_3.png)