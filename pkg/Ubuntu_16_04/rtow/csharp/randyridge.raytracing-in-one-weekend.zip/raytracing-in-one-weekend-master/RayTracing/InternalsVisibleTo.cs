﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("RayTracing.Tests")]
