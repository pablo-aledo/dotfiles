# Ray Tracing in One Weekend

This is my C# .NET Core 3.1 port of Peter Shirley's [Ray Tracing in One Weekend](https://raytracing.github.io/) which is now available for free. I bought his books when they came out and never got around to implementing them. It made for a fun holiday project.

_This is my port. There are many like it, but this one is mine._

![Ray Tracing in One Weekend](https://github.com/randyridge/raytracing-in-one-weekend/raw/master/RayTracing.Tests/OutputImages/raytracing-in-one-weekend.png)
