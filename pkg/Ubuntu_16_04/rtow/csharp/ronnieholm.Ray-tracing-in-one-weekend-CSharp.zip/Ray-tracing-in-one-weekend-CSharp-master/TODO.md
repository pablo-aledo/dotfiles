# TODO

- Analyse a run for allocations
  https://channel9.msdn.com/Shows/Visual-Studio-Toolbox/Performance-Profiling--NET-Object-Allocation-Tracking-Tool
- Add conditional compilation for benchmarking
- Add rendering time like for F# solution
- Make recursive coloring function non-recursive