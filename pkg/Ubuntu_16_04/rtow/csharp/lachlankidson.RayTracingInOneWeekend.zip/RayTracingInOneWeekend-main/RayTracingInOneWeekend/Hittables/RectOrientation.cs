﻿namespace RayTracing.Hittables
{
    public enum RectOrientation
    {
        XY,
        XZ,
        YZ,
    }
}
