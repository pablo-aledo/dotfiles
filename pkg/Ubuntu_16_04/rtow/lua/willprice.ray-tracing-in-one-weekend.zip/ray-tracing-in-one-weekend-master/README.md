# Raytracer in a weekend

Implementation of the raytracer from the book: [Ray Tracing in One Weekend](http://amzn.to/2oqMIRj)

Peter Shirley makes his final raytracer available on [github](https://github.com/petershirley/raytracinginoneweekend)
