# ray-tracing-in-one-weekend-python

Python code for the book [ray tracing in one weekend](http://www.amazon.com/Ray-Tracing-Weekend-Minibooks-Book-ebook/dp/B01B5AODD8)

* master branch is boring, please check the branches
* I made a talk for ThaiPy, presentation can be found in master branch though. 
