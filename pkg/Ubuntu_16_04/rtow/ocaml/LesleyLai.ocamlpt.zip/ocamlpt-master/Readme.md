# Ocamlpt

**Ocamlpt** is a path tracer live-coded in [Youtube stream](https://www.youtube.com/playlist?list=PLlw1FcLpWd42vMLPlR3K7iq-CuCtkZr8o).
It is based on [Peter Shirley](http://psgraphics.blogspot.com/)'s fantastic book "[Ray Tracing in a Weekend](https://raytracing.github.io/books/RayTracingInOneWeekend.html)."

## Galleries

![Ray-tracing-in-one-weekend](galleries/one-weekend.jpg)

## License
The codebase in released under the MIT License.
