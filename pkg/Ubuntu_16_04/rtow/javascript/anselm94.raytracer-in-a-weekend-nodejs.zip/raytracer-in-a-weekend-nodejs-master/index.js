console.log("---------------------------------------");
console.log("Raytracing in a Weekend - Peter Shirley");
console.log("---------------------------------------");
console.log("NodeJS implementation by Merbin J Anselm");
console.log("\nStart running exercises by executing following command(s)");
console.log("> npm run ex<EXERCISE_NUMBER>");
console.log("\nExample:\n> npm run ex5");