class Material {
    scatter(rayIn, hitRecord, vectorAttenuation, rayScattered) {
    }
}

module.exports = Material;