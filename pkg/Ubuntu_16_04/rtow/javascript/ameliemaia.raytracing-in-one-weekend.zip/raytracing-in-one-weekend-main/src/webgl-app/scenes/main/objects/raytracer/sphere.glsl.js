export default `
  struct Sphere {
    vec3 center;
    float radius;
    Material material;
  };
`;
