module.exports = {
  textures: {
    resize: false,
    sizes: []
  },
  models: {
    convert: false
  }
};
