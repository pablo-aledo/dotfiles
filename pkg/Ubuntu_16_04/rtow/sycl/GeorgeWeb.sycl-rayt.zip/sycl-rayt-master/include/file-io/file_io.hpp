#ifndef RAYT_FILE_IO_HPP
#define RAYT_FILE_IO_HPP

#include <iostream>

#endif  // RAYT_FILE_IO_HPP
