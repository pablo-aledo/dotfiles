# simple_raytracing_sycl2020
Ray Tracing in One Weekend Ported to SYCL 2020
