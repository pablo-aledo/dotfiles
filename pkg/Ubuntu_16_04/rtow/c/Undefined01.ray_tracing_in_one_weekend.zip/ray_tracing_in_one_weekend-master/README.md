# Ray-Tracing in One Weekend

参考 https://raytracing.github.io ，用 C 编写的一个简易光追渲染器。

#### 截图

![metal](https://user-images.githubusercontent.com/20395867/109777728-fda1fb80-7c3e-11eb-9065-ed2fa6fcb3a0.jpg)

![glass](https://user-images.githubusercontent.com/20395867/109777726-fc70ce80-7c3e-11eb-8094-dd1a597f7729.jpg)

![final](https://user-images.githubusercontent.com/20395867/109777696-f67aed80-7c3e-11eb-93e0-f57bf5b707dc.jpg)
