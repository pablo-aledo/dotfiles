These are just images that I reference in documents and want to hyperlink to.
These are not meant to be used in the rendering program.  If you're looking for
those, check the `assets/` folder at the root of this repo.

So things also fit/load nicely in the README, I've reduced their sizes.  You can
find the original sizes in the `full_size/` directory.
