// implement STB Image here to save on compile times

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
