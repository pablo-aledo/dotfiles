nim c -r --threads:on -d:nvgGL3 -d:release src/gui.nim -o gui
