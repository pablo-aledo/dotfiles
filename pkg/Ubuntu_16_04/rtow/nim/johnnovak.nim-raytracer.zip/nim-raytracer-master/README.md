# nim-raytracer

Writing a fully-featured raytracer from the ground up in Nim.
