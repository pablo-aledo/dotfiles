using RayTracingWeekend
using Test

@testset "RayTracingWeekend.jl" begin
    # Write your tests here.
end
