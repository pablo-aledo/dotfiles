# Ray Tracing in one weekend in Julia

Super unoptimised version of [this book](http://www.realtimerendering.com/raytracing/Ray%20Tracing%20in%20a%20Weekend.pdf)
in Julia.

![normals](img/normals.png)
![normals](img/grey.png)
![normals](img/metal.png)
![normals](img/scene.png)
