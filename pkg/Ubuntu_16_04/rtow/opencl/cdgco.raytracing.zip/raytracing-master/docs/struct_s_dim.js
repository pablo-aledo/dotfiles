var struct_s_dim =
[
    [ "m_iX", "struct_s_dim.html#a3b7818230960d905e6f9c4bb4cc19d02", null ],
    [ "m_iY", "struct_s_dim.html#ad07ee609369f9cfe8b0fdab88a584667", null ]
];