var struct__cl__image__format =
[
    [ "image_channel_data_type", "struct__cl__image__format.html#ae965ba5f74cd52eabffc4e0904adea34", null ],
    [ "image_channel_order", "struct__cl__image__format.html#aaedf0bf00bd2b217e865cad706bfad02", null ]
];