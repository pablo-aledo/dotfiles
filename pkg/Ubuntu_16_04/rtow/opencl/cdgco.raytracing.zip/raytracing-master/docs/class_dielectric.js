var class_dielectric =
[
    [ "Dielectric", "class_dielectric.html#ac374becfc9c50157be7ab7c305a0d6ed", null ],
    [ "MatColor", "class_dielectric.html#aacf25febc79937c8e3aba4637747b490", null ],
    [ "MatFuzz", "class_dielectric.html#ad6f85fb0db28bf3349d5cc19ca02ec42", null ],
    [ "MatRef", "class_dielectric.html#a2e412aec6108ba04ef0d7b441c32348b", null ],
    [ "MatType", "class_dielectric.html#a936f7e7f95354a96302248121195ea92", null ],
    [ "Scatter", "class_dielectric.html#a04429b341f68dff811d8214cb1b24f53", null ],
    [ "m_dRefId", "class_dielectric.html#ae16e57e88fe9c8f6e2364f424be1dadc", null ]
];