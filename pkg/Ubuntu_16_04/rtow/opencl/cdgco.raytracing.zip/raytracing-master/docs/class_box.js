var class_box =
[
    [ "Box", "class_box.html#aca78d7db44972bfa78d46b7bbc8796f6", null ],
    [ "Box", "class_box.html#a23744cb6cbb33cb8a4c6c5c713e2496d", null ],
    [ "clBound1", "class_box.html#abe4373a2ce3397f5f24887e8a9ba6e22", null ],
    [ "clBound2", "class_box.html#a2e8a0f4a643f43fa8a9a4d0cf14de823", null ],
    [ "clCenter", "class_box.html#abc1b02750888c8648a4ddfe44e0a308f", null ],
    [ "clRadius", "class_box.html#a9af30a365404b0f4e133859bad1880fe", null ],
    [ "clType", "class_box.html#a80cfb5901def0650b5eefb68ea27a793", null ],
    [ "CurMat", "class_box.html#a535bc25f958ab43ee14de569a8fa94cc", null ],
    [ "Hit", "class_box.html#a4bd2091ead3712b2cc8ee27704d324f2", null ],
    [ "NormalCalc", "class_box.html#a2c45fe1416908c648cbba950886ef4aa", null ],
    [ "m_pmCurMat", "class_box.html#a537270475e233fdadf9da24dc75fd24c", null ],
    [ "m_vBounds", "class_box.html#a68f7a80fb0a734d66ed4fb6cdfa16a00", null ],
    [ "m_vCenter", "class_box.html#a8be3c85fef9a912cfc238f44f1962d01", null ]
];