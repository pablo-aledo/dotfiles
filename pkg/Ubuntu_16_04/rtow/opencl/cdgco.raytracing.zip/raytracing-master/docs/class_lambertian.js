var class_lambertian =
[
    [ "Lambertian", "class_lambertian.html#a18404393ce4347b7f32aeb82d115b9ba", null ],
    [ "MatColor", "class_lambertian.html#a22d59de20f59ed42e391fe5c64c2b751", null ],
    [ "MatFuzz", "class_lambertian.html#a821c79e7d74a90880c1db355dc9d5256", null ],
    [ "MatRef", "class_lambertian.html#a55a1fa265fb0bc24eff12a9c624043a9", null ],
    [ "MatType", "class_lambertian.html#a007f966868212095072d2aeff229ac69", null ],
    [ "Scatter", "class_lambertian.html#ade7e79cd1ea12a9aebe7f3f94a6dd508", null ],
    [ "m_vAlbedo", "class_lambertian.html#a85ee6109887971f74021e08d46d20bd9", null ]
];