var hierarchy =
[
    [ "Camera", "class_camera.html", null ],
    [ "HitRecord", "struct_hit_record.html", null ],
    [ "Material", "class_material.html", [
      [ "Dielectric", "class_dielectric.html", null ],
      [ "Lambertian", "class_lambertian.html", null ],
      [ "Metal", "class_metal.html", null ]
    ] ],
    [ "Object", "class_object.html", [
      [ "Box", "class_box.html", null ],
      [ "Sphere", "class_sphere.html", null ]
    ] ],
    [ "Ray", "class_ray.html", null ],
    [ "RayTracer", "class_ray_tracer.html", null ],
    [ "SDim", "struct_s_dim.html", null ],
    [ "Vector3D", "class_vector3_d.html", null ]
];