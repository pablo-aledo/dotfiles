var class_object =
[
    [ "clBound1", "class_object.html#ac843d579f98bcbc036c2c3432cb9a4dc", null ],
    [ "clBound2", "class_object.html#aa47c7c21399076aef74acbab270f2613", null ],
    [ "clCenter", "class_object.html#ae2ba2432f2f0dd6bdc379ff831b9f130", null ],
    [ "clRadius", "class_object.html#a345a6599759ed330d31fd69608e88f91", null ],
    [ "clType", "class_object.html#a525901e1e89a1baf830ff61f69def484", null ],
    [ "CurMat", "class_object.html#a938dcd198753ea31820fdb87cf0418fd", null ],
    [ "Hit", "class_object.html#a2fbb0f11aeffb9d3f7943abda2791618", null ]
];