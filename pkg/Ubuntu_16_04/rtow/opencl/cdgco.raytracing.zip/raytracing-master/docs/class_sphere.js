var class_sphere =
[
    [ "Sphere", "class_sphere.html#a890a63ff583cb88e7ec4e840b4ef5eb9", null ],
    [ "Sphere", "class_sphere.html#a6ce190a28872e2182a22c2161999e03c", null ],
    [ "clBound1", "class_sphere.html#a371efc95372ea422a8dce23899f8ef83", null ],
    [ "clBound2", "class_sphere.html#aec76ceb490f5602ea0df34200be5faf7", null ],
    [ "clCenter", "class_sphere.html#a8d2bf514c9f8905497076b17e9c30661", null ],
    [ "clRadius", "class_sphere.html#adb556db17a6d5dfb6e349d705d5b3d11", null ],
    [ "clType", "class_sphere.html#aabe09990a9330a02b5e872feeef57897", null ],
    [ "CurMat", "class_sphere.html#acb56849ba7d72a69c8f784213184a931", null ],
    [ "Hit", "class_sphere.html#a87ddf107085f97a6c9827faadef8b3f4", null ],
    [ "m_dRadius", "class_sphere.html#a700cbe897277b993a46b8ce29ed25dcd", null ],
    [ "m_pmCurMat", "class_sphere.html#a39de784614d5fde2eff137e7c236d377", null ],
    [ "m_vCenter", "class_sphere.html#ade29546cc2a206bbc239e676363b1184", null ]
];