var class_ray_tracer =
[
    [ "RayTracer", "class_ray_tracer.html#a7f59fcfc6b645680b6c5723df307e6e9", null ],
    [ "RayTracer", "class_ray_tracer.html#a249d0cd596cc3c7fb4885d34389ffd95", null ],
    [ "RayTracer", "class_ray_tracer.html#ad8afcdfc881d72e2199ef4b645a4ee97", null ],
    [ "~RayTracer", "class_ray_tracer.html#ab5b30fead4f47d46be62bddb4a5283e6", null ],
    [ "AddItem", "class_ray_tracer.html#aa06183ba7829e1200a1bb56da8d90cf6", null ],
    [ "ClearItems", "class_ray_tracer.html#ad73650432e4754017ae7c42b37e23362", null ],
    [ "clRender", "class_ray_tracer.html#a6353af6b373614eabddbdb1cc58b6d9d", null ],
    [ "Color", "class_ray_tracer.html#a3c3f043e7dd6e67ff234f7791282848a", null ],
    [ "OpenImage", "class_ray_tracer.html#a80ed1bbb4abbc9f3600147b8ca6d7ba9", null ],
    [ "RandomScene", "class_ray_tracer.html#ad265ff165d4fa65158f21d55ab56275a", null ],
    [ "Render", "class_ray_tracer.html#adee1b8956b5522d79fa34a3491af9bb7", null ],
    [ "SetCamera", "class_ray_tracer.html#acf143af8680e121745cea13c79f5c59d", null ],
    [ "ShowPerformance", "class_ray_tracer.html#acae1085fc114910358f930344372e619", null ],
    [ "m_camera", "class_ray_tracer.html#aac767b22c0adf5fd85e03c3130d3fea4", null ],
    [ "m_dims", "class_ray_tracer.html#a118507c48ddd69a9c2ec208cde403ded", null ],
    [ "m_iRaysPerPixel", "class_ray_tracer.html#aa065350a257f7ce144cd792001f65d57", null ],
    [ "m_list", "class_ray_tracer.html#ae0778dc62cc58b7a50314ac81c02ba0b", null ]
];