var annotated_dup =
[
    [ "Box", "class_box.html", "class_box" ],
    [ "Camera", "class_camera.html", "class_camera" ],
    [ "Dielectric", "class_dielectric.html", "class_dielectric" ],
    [ "HitRecord", "struct_hit_record.html", "struct_hit_record" ],
    [ "Lambertian", "class_lambertian.html", "class_lambertian" ],
    [ "Material", "class_material.html", "class_material" ],
    [ "Metal", "class_metal.html", "class_metal" ],
    [ "Object", "class_object.html", "class_object" ],
    [ "Ray", "class_ray.html", "class_ray" ],
    [ "RayTracer", "class_ray_tracer.html", "class_ray_tracer" ],
    [ "SDim", "struct_s_dim.html", "struct_s_dim" ],
    [ "Sphere", "class_sphere.html", "class_sphere" ],
    [ "Vector3D", "class_vector3_d.html", "class_vector3_d" ]
];