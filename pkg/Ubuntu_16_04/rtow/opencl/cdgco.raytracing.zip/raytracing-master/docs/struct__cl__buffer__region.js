var struct__cl__buffer__region =
[
    [ "origin", "struct__cl__buffer__region.html#ad3b41b7ad499abfc0d0621791af8a50c", null ],
    [ "size", "struct__cl__buffer__region.html#a42a9ed9284cac1ed167664874ed2f0ee", null ]
];