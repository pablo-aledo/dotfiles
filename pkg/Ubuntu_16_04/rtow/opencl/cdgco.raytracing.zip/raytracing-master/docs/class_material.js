var class_material =
[
    [ "MatColor", "class_material.html#a20ce74a8a319ab494d525e50d171f4b3", null ],
    [ "MatFuzz", "class_material.html#a1ec0c28fbedd8b94df056150197d0ae6", null ],
    [ "MatRef", "class_material.html#a617e62a96982bfe1bd63924fee1ed761", null ],
    [ "MatType", "class_material.html#ae76fd2d097c7fc4a2f6599e111bc4e93", null ],
    [ "Scatter", "class_material.html#a16accf2a15fd22ad8dac96f4a17e7654", null ]
];