var class_metal =
[
    [ "Metal", "class_metal.html#a62a0a25fb987ea0a309954e18906bddc", null ],
    [ "MatColor", "class_metal.html#a3c90c890709abbf4b75e219630a0b043", null ],
    [ "MatFuzz", "class_metal.html#aef8f5d70ed29a1c69152ee85ecc1689c", null ],
    [ "MatRef", "class_metal.html#abe9c41a9e1ed1fd291939b40035f30e7", null ],
    [ "MatType", "class_metal.html#a3ff26866968b81ec3b569e2df2ec1b34", null ],
    [ "Scatter", "class_metal.html#a20b7bfc081ad2005d78e08ff3837bbd4", null ],
    [ "m_dFuzz", "class_metal.html#aff23e44ce7ae8a29b0ceebceebc6fcf7", null ],
    [ "m_vAlbedo", "class_metal.html#af803d7f06cf86e6993a56613b4b4dee4", null ]
];