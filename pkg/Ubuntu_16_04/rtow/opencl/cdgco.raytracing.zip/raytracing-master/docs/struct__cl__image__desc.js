var struct__cl__image__desc =
[
    [ "buffer", "struct__cl__image__desc.html#ad80d3ad3150af776182f10a680ea6705", null ],
    [ "image_array_size", "struct__cl__image__desc.html#a8c5a9f11016b833f7a24f0af587ecd67", null ],
    [ "image_depth", "struct__cl__image__desc.html#afb66100243f2d30d4262956bbe95e5ca", null ],
    [ "image_height", "struct__cl__image__desc.html#a525597aeaaa9340c85dcea9343d399af", null ],
    [ "image_row_pitch", "struct__cl__image__desc.html#af05bbf727bac00ed3dabdf0d925f94d6", null ],
    [ "image_slice_pitch", "struct__cl__image__desc.html#af22e2bc150e213bcf2c673479581b9ca", null ],
    [ "image_type", "struct__cl__image__desc.html#aad9377b93ee8875dbbc24cffc44d353f", null ],
    [ "image_width", "struct__cl__image__desc.html#a0eb67a2cecf5e7ee550e287ef74b65ea", null ],
    [ "mem_object", "struct__cl__image__desc.html#a123968c3667b229ad12f9651ce90c6ac", null ],
    [ "num_mip_levels", "struct__cl__image__desc.html#a97f4cab1d305d0fbf97b1e94880b0681", null ],
    [ "num_samples", "struct__cl__image__desc.html#a6732865527d69bd112224a378a4f0297", null ]
];