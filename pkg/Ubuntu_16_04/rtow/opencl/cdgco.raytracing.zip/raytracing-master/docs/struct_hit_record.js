var struct_hit_record =
[
    [ "m_dT", "struct_hit_record.html#a19ca0909b37730b44c3914a76e41c3f7", null ],
    [ "m_pmCurMat", "struct_hit_record.html#a038e6ab2fa0529e5ce2c504ea1acf57a", null ],
    [ "m_vNormal", "struct_hit_record.html#a8790518bf3d0fb655c60392072119f86", null ],
    [ "m_vP", "struct_hit_record.html#a65c6b7c62ca2561634b07864f07d1965", null ]
];