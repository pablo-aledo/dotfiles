var files_dup =
[
    [ "box.h", "box_8h_source.html", null ],
    [ "camera.h", "camera_8h_source.html", null ],
    [ "dielectric.h", "dielectric_8h_source.html", null ],
    [ "lambertian.h", "lambertian_8h_source.html", null ],
    [ "material.h", "material_8h_source.html", null ],
    [ "metal.h", "metal_8h_source.html", null ],
    [ "object.h", "object_8h_source.html", null ],
    [ "ray.h", "ray_8h_source.html", null ],
    [ "ray_tracer.h", "ray__tracer_8h_source.html", null ],
    [ "sphere.h", "sphere_8h_source.html", null ],
    [ "vector.h", "vector_8h_source.html", null ]
];