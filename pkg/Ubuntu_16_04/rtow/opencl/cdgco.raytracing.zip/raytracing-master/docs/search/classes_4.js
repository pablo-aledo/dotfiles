var searchData=
[
  ['lambertian',['Lambertian',['../class_lambertian.html',1,'']]]
];
