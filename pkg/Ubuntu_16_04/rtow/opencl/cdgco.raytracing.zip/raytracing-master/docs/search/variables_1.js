var searchData=
[
  ['b',['B',['../class_ray.html#a9343f490f7df2c9604ba18fc14633f85',1,'Ray']]]
];
