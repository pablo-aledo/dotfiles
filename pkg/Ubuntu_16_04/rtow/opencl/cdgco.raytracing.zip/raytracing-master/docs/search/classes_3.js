var searchData=
[
  ['hitrecord',['HitRecord',['../struct_hit_record.html',1,'']]]
];
