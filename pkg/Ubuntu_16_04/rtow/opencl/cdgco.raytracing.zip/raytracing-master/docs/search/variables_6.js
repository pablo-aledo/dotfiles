var searchData=
[
  ['pmcurmat',['pmCurMat',['../class_box.html#a66e3dd69b59f2602631f6b2c9b9113b5',1,'Box::pmCurMat()'],['../struct_hit_record.html#aff5a261638e0f540eb7c491a68086a42',1,'HitRecord::pmCurMat()'],['../class_sphere.html#abbd8e823caab223cac063cb38ee31685',1,'Sphere::pmCurMat()']]]
];
