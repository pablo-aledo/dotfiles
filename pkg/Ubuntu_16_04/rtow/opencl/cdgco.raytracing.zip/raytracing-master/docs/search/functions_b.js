var searchData=
[
  ['r',['r',['../class_vector3_d.html#ad6d319efb48c26deb8fc418651ff3788',1,'Vector3D']]],
  ['randominunitdisk',['RandomInUnitDisk',['../class_camera.html#a86de1055fab138506903009bff8017b1',1,'Camera']]],
  ['randominunitsphere',['RandomInUnitSphere',['../class_material.html#a714b7d7c4c2a9871183bbed2ea5ed5b6',1,'Material']]],
  ['randomscene',['RandomScene',['../class_ray_tracer.html#ad265ff165d4fa65158f21d55ab56275a',1,'RayTracer']]],
  ['ray',['Ray',['../class_ray.html#a4d5c4b12e9375750324726bd184d4ba5',1,'Ray']]],
  ['raytracer',['RayTracer',['../class_ray_tracer.html#a7f59fcfc6b645680b6c5723df307e6e9',1,'RayTracer::RayTracer()'],['../class_ray_tracer.html#a249d0cd596cc3c7fb4885d34389ffd95',1,'RayTracer::RayTracer(const SDim &amp;dims, const int iRaysPerPixel=100)'],['../class_ray_tracer.html#ad8afcdfc881d72e2199ef4b645a4ee97',1,'RayTracer::RayTracer(const SDim &amp;dims, const int iRaysPerPixel, Camera &amp;cam)']]],
  ['reflect',['Reflect',['../class_material.html#a61e2546b09a6c761d137910e76c60f52',1,'Material']]],
  ['refract',['Refract',['../class_dielectric.html#a0883e90e42f70d07458e2de57a9c2c73',1,'Dielectric']]],
  ['render',['Render',['../class_ray_tracer.html#adee1b8956b5522d79fa34a3491af9bb7',1,'RayTracer']]]
];
