#ifndef EXTERNAL_HPP
#define EXTERNAL_HPP

#include <CL/cl.hpp>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <cmath>
#include <random>

#endif
