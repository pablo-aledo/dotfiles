#ifndef IMAGE_HPP
#define IMAGE_HPP
// stbi
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <custom/stb_image_write.h>

#define STB_IMAGE_IMPLEMENTATION
#include <custom/stb_image.h>

#endif

