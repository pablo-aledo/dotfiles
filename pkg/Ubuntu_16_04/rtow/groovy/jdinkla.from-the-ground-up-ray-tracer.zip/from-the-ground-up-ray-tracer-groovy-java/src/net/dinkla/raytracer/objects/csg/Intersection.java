package net.dinkla.raytracer.objects.csg;

/**
 * Created by IntelliJ IDEA.
 * User: jorndinkla
 * Date: 28.06.2010
 * Time: 22:11:51
 * To change this template use File | Settings | File Templates.
 */
public class Intersection extends AbstractNode {
    
}
