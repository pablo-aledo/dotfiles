package net.dinkla.raytracer.objects.acceleration.kdtree;

/**
 * Created by IntelliJ IDEA.
 * User: jorndinkla
 * Date: 11.06.2010
 * Time: 14:32:48
 * To change this template use File | Settings | File Templates.
 */
public class IBuilder {
}
