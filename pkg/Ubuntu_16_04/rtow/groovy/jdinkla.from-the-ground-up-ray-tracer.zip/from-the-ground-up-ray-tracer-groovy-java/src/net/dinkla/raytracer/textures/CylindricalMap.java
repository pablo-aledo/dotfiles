package net.dinkla.raytracer.textures;

import net.dinkla.raytracer.math.Point3D;
import net.dinkla.raytracer.utilities.Resolution;

/**
 * Created by IntelliJ IDEA.
 * User: jorndinkla
 * Date: 02.06.2010
 * Time: 21:24:18
 * To change this template use File | Settings | File Templates.
 */
public class CylindricalMap extends Mapping {

    @Override
    public Mapped getTexelCoordinates(Point3D p, Resolution res) {
        return null;
        // TODO Implementieren
    }
    
}
