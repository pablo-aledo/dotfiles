package net.dinkla.raytracer.colors;/*
 * Copyright (c) 2012 by Jörn Dinkla, www.dinkla.com, All rights reserved.
 */

public class RGBBytes {

    public final byte red, green, blue;

    public RGBBytes(final byte r, final byte g, final byte b) {
        red = r;
        green = g ;
        blue = b;
    }

}
