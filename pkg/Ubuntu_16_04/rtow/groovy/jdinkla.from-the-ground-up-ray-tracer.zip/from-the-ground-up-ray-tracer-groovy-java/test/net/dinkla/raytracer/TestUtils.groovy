package net.dinkla.raytracer

/**
 * Created by IntelliJ IDEA.
 * User: jorndinkla
 * Date: 08.07.2015
 * Time: 09:30:40
 */
class TestUtils {

    static final public String PLY_EXAMPLE = "resources/TwoTriangles.ply"

    static final public String PLY_BINARY_EXAMPLE = "resources/Isis.ply"

}
