# Bash Ray Tracer

A simple ray tracer written in pure Bash. Inspired by [Cmake Ray Tracer](https://github.com/64/cmake-raytracer).

![image](render.png)

## Usage

```
> ./raytracer.sh output.ppm
