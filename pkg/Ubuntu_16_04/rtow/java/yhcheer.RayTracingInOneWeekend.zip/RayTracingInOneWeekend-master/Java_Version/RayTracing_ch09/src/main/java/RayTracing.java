public class RayTracing {

    public static void main(String[] args){
        Display TracingDisplay = new Display(1980,1080,"Ray Tracer"); //1980*1080p
    }

}
