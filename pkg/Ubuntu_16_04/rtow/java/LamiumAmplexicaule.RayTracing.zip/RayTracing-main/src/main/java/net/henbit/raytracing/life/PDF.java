package net.henbit.raytracing.life;

public class PDF
{

    private double value;

    public PDF()
    {
        value = 0;
    }

    public void copy(double value)
    {
        this.value = value;
    }

}
