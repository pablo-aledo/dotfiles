# RayTracing in Java

## Done
[Weekend](src/main/java/net/henbit/raytracing/weekend) from [_Ray Tracing in One Weekend_](https://raytracing.github.io/books/RayTracingInOneWeekend.html)  
![Weekend Sample](image/weekend-chapter13.png "weekend sample")  
[Nextweek](src/main/java/net/henbit/raytracing/nextweek) from [_Ray Tracing: The Next Week_](https://raytracing.github.io/books/RayTracingTheNextWeek.html)  
![Nextweek Sample](image/nextweek-chapter10.png "nextweek sample")  
[Life](src/main/java/net/henbit/raytracing/life) from [_Ray Tracing: The Rest of Your Life_](https://raytracing.github.io/books/RayTracingTheRestOfYourLife.html)  
![Life Sample](image/life-chapter12.png "life sample")  

## ToDo
__Faster.__
