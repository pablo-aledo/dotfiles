# Raytracer in a Weekend

Based on [this article](https://raytracing.github.io/books/RayTracingInOneWeekend.html).

To generate the PPM image, run:

```sh
cargo run > image.ppm
```
