#!/usr/bin/env bash

simple-http-server -t 8 -c js,html,css,wasm -p 8008 -i
