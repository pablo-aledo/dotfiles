import rtw from "./pkg/wasm.js";

console.log(rtw);
