ls *.js src/*.rs build.sh Cargo.toml | entr -c ./build.sh
