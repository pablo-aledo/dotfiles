rm montage.jpg; montage -geometry 400x250 -border 2x2 -bordercolor black -background black *.{jpg,png} montage.jpg
