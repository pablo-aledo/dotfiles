# Dasom example #1 - Three Balls

![three balls](three_balls(1280x720).png)

Three balls maybe you might know. It took about 70 seconds to render this on my machine.

## My machine

|||
|-|-|
|OS|Arch Linux on Windows 10 (WSL2)|
|CPU|AMD Ryzen 3600|
|Memory|16 GB|
|rustc|1.51.0-nightly|
