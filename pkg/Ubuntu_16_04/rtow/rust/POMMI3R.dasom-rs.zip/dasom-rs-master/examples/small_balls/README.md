# Dasom example #2 - Small Balls

![small balls](small_balls(1280x720).png)

Well-known small random balls. It took about 100 minutes to render this on my machine.

## My machine

|||
|-|-|
|OS|Arch Linux on Windows 10 (WSL2)|
|CPU|AMD Ryzen 3600|
|Memory|16 GB|
|rustc|1.51.0-nightly|