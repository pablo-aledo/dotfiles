use crate::Real;

pub type Vector = nalgebra::Vector3< Real >;