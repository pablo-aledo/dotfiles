pub mod sphere;

/// Triangle, the simplest primitive.
pub mod triangle;

pub trait Shape {}
