import('./index').catch((e) => console.error(`Failed to load index.ts: ${e}`));
