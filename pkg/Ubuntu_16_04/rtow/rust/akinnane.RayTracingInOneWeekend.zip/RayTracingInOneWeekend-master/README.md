# Ray tracing in one weekend

![Final Scene](https://github.com/akinnane/RayTracingInOneWeekend/raw/master/final_scene.png)


See https://raytracing.github.io/books/RayTracingInOneWeekend.html




https://www.reddit.com/r/rust/comments/cfryv9/i_implemented_ray_tracing_in_a_weekend_in_rust_it/

https://bheisler.github.io/post/writing-raytracer-in-rust-part-1/

https://www.scratchapixel.com/index.php
