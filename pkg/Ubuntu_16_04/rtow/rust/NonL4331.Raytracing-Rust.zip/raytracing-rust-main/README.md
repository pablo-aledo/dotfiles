# Raytracing-Rust
A toy raytracer written in rust.

# Features
 - Multithreading
 - Model loading
