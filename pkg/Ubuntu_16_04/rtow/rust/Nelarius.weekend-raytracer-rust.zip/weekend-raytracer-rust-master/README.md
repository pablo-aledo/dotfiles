# Ray Tracing in One Weekend

This is a fairly straightforward implementation of Peter Shirley's "Ray Tracing in One Weekend" book in Rust.

![cover_image](https://raw.githubusercontent.com/Nelarius/weekend-raytracer-rust/master/img/cover_image.png)
