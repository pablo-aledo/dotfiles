# rtiow
Raytracing in one weekend implementation in Rust

![Resulting image](image.png)
