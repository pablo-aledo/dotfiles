# Raytracing: WebAssembly vs JavaScript

- Blog post: https://matt-harrison.com/posts/raytracing-webassembly-vs-javascript/
- Interactive Demo here: https://mtharrison.github.io/wasm-raytracer/
- Based on awesome tutorial here: https://github.com/tmcw/literate-raytracer

![preview](preview.png)
