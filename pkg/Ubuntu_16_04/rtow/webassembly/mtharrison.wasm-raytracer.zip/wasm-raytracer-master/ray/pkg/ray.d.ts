/* tslint:disable */
export function binding(arg0: string, arg1: number, arg2: number): Float32Array;

