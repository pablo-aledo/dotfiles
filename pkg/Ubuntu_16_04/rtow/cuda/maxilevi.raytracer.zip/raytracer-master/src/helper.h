/*
 * Created by Maximiliano Levi on 4/12/2021.
 */

#ifndef RAYTRACER_CXX_HELPER_H
#define RAYTRACER_CXX_HELPER_H

long long TimeIt(std::chrono::time_point<std::chrono::steady_clock>& prev_time);

#endif //RAYTRACER_HELPER_H
