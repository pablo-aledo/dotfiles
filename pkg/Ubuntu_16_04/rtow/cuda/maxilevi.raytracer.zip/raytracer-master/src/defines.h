/*
 * Created by Maximiliano Levi on 4/16/2021.
 */

#ifndef RAYTRACER_DEFINES_H
#define RAYTRACER_DEFINES_H

typedef double decimal_t;

#endif //RAYTRACER_DEFINES_H
