var searchData=
[
  ['lambertian_10',['Lambertian',['../classLambertian.html',1,'']]]
];
