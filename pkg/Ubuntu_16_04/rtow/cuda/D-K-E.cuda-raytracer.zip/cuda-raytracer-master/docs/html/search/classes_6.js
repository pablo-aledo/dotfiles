var searchData=
[
  ['kernelarg_31',['KernelArg',['../structKernelArg.html',1,'']]]
];
