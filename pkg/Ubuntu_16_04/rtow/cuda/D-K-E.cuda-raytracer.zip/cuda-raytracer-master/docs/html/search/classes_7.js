var searchData=
[
  ['lambertian_32',['Lambertian',['../classLambertian.html',1,'']]]
];
