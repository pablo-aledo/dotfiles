var indexSectionsWithContent =
{
  0: "abcdhiklmnprstv",
  1: "abcdhiklmnprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

