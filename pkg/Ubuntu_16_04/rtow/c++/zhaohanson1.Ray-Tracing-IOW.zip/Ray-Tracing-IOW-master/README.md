# Ray-Tracing-IOW

My annotated implementation (copying) of Peter Shirley's "Ray Tracing in One Weekend". https://github.com/petershirley/raytracinginoneweekend

Used to practice C++ syntax and learn some ray-tracing.
