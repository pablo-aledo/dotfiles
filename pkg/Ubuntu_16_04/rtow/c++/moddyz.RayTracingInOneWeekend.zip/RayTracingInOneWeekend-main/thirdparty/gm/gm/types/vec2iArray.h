//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file vec2iArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/vec2i.h>

GM_NS_OPEN

/// \typedef Vec2iArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Vec2i.
using Vec2iArray = std::vector< Vec2i >;

GM_NS_CLOSE