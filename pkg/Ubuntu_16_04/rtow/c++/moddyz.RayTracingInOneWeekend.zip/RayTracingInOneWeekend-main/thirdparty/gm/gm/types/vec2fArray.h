//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file vec2fArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/vec2f.h>

GM_NS_OPEN

/// \typedef Vec2fArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Vec2f.
using Vec2fArray = std::vector< Vec2f >;

GM_NS_CLOSE