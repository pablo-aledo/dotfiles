//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file boolArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

GM_NS_OPEN

/// \typedef BoolArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref bool.
using BoolArray = std::vector< bool >;

GM_NS_CLOSE