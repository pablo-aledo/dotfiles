//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file floatArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

GM_NS_OPEN

/// \typedef FloatArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref float.
using FloatArray = std::vector< float >;

GM_NS_CLOSE