//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file vec4fArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/vec4f.h>

GM_NS_OPEN

/// \typedef Vec4fArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Vec4f.
using Vec4fArray = std::vector< Vec4f >;

GM_NS_CLOSE