//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file vec3fArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/vec3f.h>

GM_NS_OPEN

/// \typedef Vec3fArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Vec3f.
using Vec3fArray = std::vector< Vec3f >;

GM_NS_CLOSE