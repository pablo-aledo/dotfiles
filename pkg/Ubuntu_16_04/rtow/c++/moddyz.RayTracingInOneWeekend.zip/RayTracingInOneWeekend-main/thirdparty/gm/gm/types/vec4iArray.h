//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file vec4iArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/vec4i.h>

GM_NS_OPEN

/// \typedef Vec4iArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Vec4i.
using Vec4iArray = std::vector< Vec4i >;

GM_NS_CLOSE