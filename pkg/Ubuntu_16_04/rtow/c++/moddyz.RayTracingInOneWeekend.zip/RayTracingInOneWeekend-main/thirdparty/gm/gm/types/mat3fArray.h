//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file mat3fArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/mat3f.h>

GM_NS_OPEN

/// \typedef Mat3fArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Mat3f.
using Mat3fArray = std::vector< Mat3f >;

GM_NS_CLOSE