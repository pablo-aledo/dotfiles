//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file mat4fArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/mat4f.h>

GM_NS_OPEN

/// \typedef Mat4fArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Mat4f.
using Mat4fArray = std::vector< Mat4f >;

GM_NS_CLOSE