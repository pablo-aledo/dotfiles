//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file intArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

GM_NS_OPEN

/// \typedef IntArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref int.
using IntArray = std::vector< int >;

GM_NS_CLOSE