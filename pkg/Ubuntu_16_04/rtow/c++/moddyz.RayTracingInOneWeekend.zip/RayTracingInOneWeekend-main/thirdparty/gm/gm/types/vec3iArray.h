//
// This file is auto-generated, please do not modify directly!
//

#pragma once

/// \file vec3iArray.h
/// \ingroup gm_types_array

#include <gm/gm.h>

#include <vector>

#include <gm/types/vec3i.h>

GM_NS_OPEN

/// \typedef Vec3iArray
/// \ingroup gm_types_array
///
/// Type definition of an array of \ref Vec3i.
using Vec3iArray = std::vector< Vec3i >;

GM_NS_CLOSE