#ifndef _PIXEL_H
#define _PIXEL_H

#include <Eigen/Core>


namespace mrtp {

typedef Eigen::Vector3d Pixel;

} //namespace mrtp

#endif //_PIXEL_H
