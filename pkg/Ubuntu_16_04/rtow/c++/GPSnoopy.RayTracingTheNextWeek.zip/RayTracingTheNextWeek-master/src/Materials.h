#pragma once

#include "Materials/Dielectric.h"
#include "Materials/DiffuseLight.h"
#include "Materials/Isotropic.h"
#include "Materials/Lambertian.h"
#include "Materials/Metal.h"
