# extlibs

This directory contains any external libraries Photorealistic uses

Used Libraries

* [imgui](https://github.com/ocornut/imgui)
* [json](https://github.com/nlohmann/json)
* [indicators](https://github.com/p-ranav/indicators)
* [stb_image](https://github.com/nothings/stb/blob/master/stb_image.h)
* Gl stuff