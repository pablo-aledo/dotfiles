#!/bin/sh
g++ -o book1 -std=c++1z -Wall -Wextra -O3 -ffast-math -march=skylake main.cpp -lpthread
