# Ray Tracing in One Weekend -- In Haskell

This is an implementation of the Ray Tracing in One Weekend tutorial in Haskell. It's kind of a loose interpretation, as I'm using it to experiment with as much FP as possible. It may be a little excessive at times, but who cares since this project is 100% for fun and learning.