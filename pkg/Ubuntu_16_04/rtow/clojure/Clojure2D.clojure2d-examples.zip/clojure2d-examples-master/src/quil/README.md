## Quil examples

* Page: http://quil.info/examples
* Repository: https://github.com/quil/quil
  
## Quil licencing // Copyright

```
Distributed under the Eclipse Public License either version 1.0 or (at your option) any later version.

The official Processing.org's jars, used as dependencies, are distributed under LGPL and their code can be found on http://processing.org/
```
