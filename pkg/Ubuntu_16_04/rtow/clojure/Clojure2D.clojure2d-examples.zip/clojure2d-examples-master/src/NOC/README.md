## Nature of Code examples

* Book: http://natureofcode.com/
* Repository: https://github.com/shiffman/The-Nature-of-Code-Examples
  
## Licencing // Copyright

```
All of the book's code examples are licensed under the MIT License.

Author of originals: Daniel Shiffman, http://shiffman.net/ 
```
