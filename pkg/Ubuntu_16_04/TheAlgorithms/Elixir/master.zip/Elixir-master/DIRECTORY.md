
## Arithmetic Analysis

## Backtracking

## Blockchain

## Boolean Algebra

## Ciphers

## Compression

## Conversions

## Data Structures
  * Linked List
    * [Singly Linked List](https://github.com/TheAlgorithms/Elixir/blob/master/lib/data_structures/singly_linked_list.ex)
    * [Doubly Linked List](https://github.com/TheAlgorithms/Elixir/blob/master/lib/data_structures/doubly_linked_list.ex)

## Digital Image Processing

## Divide And Conquer

## Dynamic Programming

## File Transfer

## Fuzzy Logic

## Graphs

## Hashes

## Linear Algebra

## Machine Learning

## Maths

## Matrix

## Networking Flow

## Neural Network

## Other

## Project Euler

## Searches

## Sorts
 * [Bubblesort](https://en.wikipedia.org/wiki/Bubble_sort)
 * [Mergesort](https://en.wikipedia.org/wiki/Merge_sort)
 * [Quicksort](https://en.wikipedia.org/wiki/Quicksort)

## Strings

## Traversals

## Web Programming
