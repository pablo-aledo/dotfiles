# Nombre del algoritmo

Escribe una breve descripción del algoritmo como:

1. Complejidad temporal
2. Complejidad espacial
3. Aplicaciones
4. Nombre del fundador
5. etc ...

## Pasos

Describe el algoritmo en pasos claros, simples y comprensibles.

## Ejemplo

Rastree el algoritmo con datos de entrada de muestra.

## Implementación

Enlaces a su implementación en lenguajes de programación.
NOTA: El enlace debe estar dentro de los otros repositorios de esta organización únicamente.

## URL del vídeo

Adjunte una URL de un video que explique el algoritmo.

## Otros

Cualquier otra información es siempre bienvenida y debe incluirse en esta sección.
