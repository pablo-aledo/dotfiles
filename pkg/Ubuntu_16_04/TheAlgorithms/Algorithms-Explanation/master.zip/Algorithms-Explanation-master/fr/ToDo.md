# Algo à faire

* Terminer de remplir les infos pour fibo et max

* Filtres audio
  * filtre iir
  * montrer reponse
* math
  * Basiquement tout
* tri
  * basiquement tout
* Tout le reste
