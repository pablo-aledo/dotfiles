# Nom de l'algorithme

## Description

Écrivez une courte description de l'algorithme :

1. Complexité temporelle
2. Complexité spatiale
3. Applications possibles
4. Nom de l'auteur
5. ...

## Étapes

Décrire l'algorithme en étapes concises et compréhensibles.

## Exemple

Écrivez le fonctionnement de l'algorithme avec un exemple.

## Implémentation

Liens vers des implémentations de ce programme dans des langages.
NOTE : Merci de ne mettre des liens que vers les dossiers de cette organisation.
Si le programme n'existe pas dans un langage, n'hésitez pas à le rajouter !

## Vidéo

Lien vers une vidéo qui explique le fonctionnement de l'algorithme.

## Autres

D'autres informations sont toujours les bienvenues and doivent être incluses dans cette section.
