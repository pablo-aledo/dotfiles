# Nome do Algoritmo

Escreva uma breve descrição do algoritmo como:

1. Complexidade de tempo
2. Complexidade do Espaço
3. Aplicativos
4. Nome do fundador
5. etc ...

## Passos

Descreva o algoritmo em etapas claras, de forma simples e compreensível.

## Exemplo

Rastreie o algoritmo com dados de entrada de amostra.

## Implementação

Links para sua implementação em linguagens de programação.
NOTA: O link deve estar apenas em outros repositórios desta organização.

## URL do vídeo

Anexe um URL de um vídeo que explica o algoritmo.

## Outras

Qualquer outra informação é sempre bem-vinda e deve ser incluída nesta seção.
