namespace Algorithms.Math

module Abs =
    let absVal num = if num < 0 then -num else num
