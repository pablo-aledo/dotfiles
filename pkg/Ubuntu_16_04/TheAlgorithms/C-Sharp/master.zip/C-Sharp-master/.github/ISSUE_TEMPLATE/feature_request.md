---
name: Feature request
about: Suggest an idea for this project
title: Add something cool
labels: enhancement
assignees: ''

---

I propose to add [algorithm/data structure] [name]. It helps to solve problems such as [...]. It's best described in book(s), on website(s): [...].
