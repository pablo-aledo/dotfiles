﻿namespace Algorithms.Numeric.GreatestCommonDivisor
{
    public interface IGreatestCommonDivisorFinder
    {
        int FindGcd(int a, int b);
    }
}
