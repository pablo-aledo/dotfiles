﻿using NUnit.Framework;

[assembly: Parallelizable(ParallelScope.Children)]
