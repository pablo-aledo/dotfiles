import { ArrayQueue } from '../array_queue'
import { testQueue } from './queue'

describe('Array Queue', () => testQueue(ArrayQueue))
