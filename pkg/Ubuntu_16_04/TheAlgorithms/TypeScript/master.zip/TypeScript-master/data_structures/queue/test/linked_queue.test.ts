import { testQueue } from './queue'
import { LinkedQueue } from '../linked_queue'

describe('Linked Queue', () => testQueue(LinkedQueue))
