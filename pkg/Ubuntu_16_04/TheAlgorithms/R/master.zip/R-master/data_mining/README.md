# Data Mining in R

## Tutorials

  - [Top 10 data mining algorithms in plain R](https://hackerbits.com/data/top-10-data-mining-algorithms-in-plain-r/)
