library(cluster)
fit <- kmeans(X, 3) # 5 cluster solution
