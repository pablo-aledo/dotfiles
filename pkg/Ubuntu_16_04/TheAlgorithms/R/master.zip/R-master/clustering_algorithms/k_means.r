library(cluster)
set.seed(42)
fit <- kmeans(X, 3) # 3 cluster solution
