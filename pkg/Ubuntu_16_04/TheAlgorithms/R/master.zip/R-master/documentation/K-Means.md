

```r
library(cluster)
fit <- kmeans(X, 3) # 5 cluster solution
```

```
## Error in as.matrix(x): object 'X' not found
```

