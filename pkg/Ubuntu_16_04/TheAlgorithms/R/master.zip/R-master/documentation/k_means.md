

```r
library(cluster)
set.seed(42)
fit <- kmeans(X, 3) # 3 cluster solution
```

```
## Error in as.matrix(x): object 'X' not found
```

