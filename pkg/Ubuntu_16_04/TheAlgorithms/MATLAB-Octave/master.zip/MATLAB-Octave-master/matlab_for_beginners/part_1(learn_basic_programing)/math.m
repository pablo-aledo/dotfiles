%%Ex. 3 Basic math operations

a = 3;
b = 9;
c = 2*a+b^2-a*b+b/a-10

%Output:53
