%%Addition
a = 3;
b = 5;
c = a+b
%%Output:8
