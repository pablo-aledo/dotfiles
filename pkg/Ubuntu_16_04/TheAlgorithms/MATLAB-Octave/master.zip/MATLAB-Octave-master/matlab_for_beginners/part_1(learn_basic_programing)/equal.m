%%Ex. 2 The meaning of "a = b"


%In Matlab and in any programming language, the statement "a = b" does not mean
%"a equals b". Instead, it prompts the action of replacing the content of a by the
%content of b.
a = 3;
b = a;
b

%Output:3
