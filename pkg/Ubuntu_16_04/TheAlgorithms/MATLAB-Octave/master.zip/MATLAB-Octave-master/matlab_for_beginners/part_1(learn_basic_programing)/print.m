%%Ex. 5 Formatted output

fprintf('Hello')
%Output:Hello
