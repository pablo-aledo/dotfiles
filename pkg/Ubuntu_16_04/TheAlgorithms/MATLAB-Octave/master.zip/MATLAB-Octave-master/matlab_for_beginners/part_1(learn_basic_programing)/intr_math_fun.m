%%Ex. 11 Intrinsic math functions and constants
x = pi;
y = sin(pi/2)
z = exp(-sin(pi/2))


%Output:
    %    y = 1
    %    z = 0.3679