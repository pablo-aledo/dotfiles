%%Ex. 10 Continuation to next line
summation1 = 1 + 3 + 5 + 7 ...
 + 9 + 11


%Note: The three periods (...) allow continuation to the next line of commands. The two
%  lines in the above example are essentially one line of "summation1 = 1+3+5+7+9+11".