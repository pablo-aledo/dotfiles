%%Ex. 4 The meaning of "a = b", continued
a = 3;
a = a+1;
a

%Output:4

