%%Ex. 9 Comment
%
% This program demonstrates how to "comment out"
% a segment of code

A = 3;
B = A*A;
%
% B = 2*B <--- This statement is not executed
%
C = A+B



%Output: c = 12