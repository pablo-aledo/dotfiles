

This part-1 contains basics programs of matlab to make you familiar with the language.
For better understanding the basics of the matlab programming,
please go through the programs according the following
sequence. Details of each the programs is given alongside:--

1- add.m  ( addition of numbers)
2- equal.m ( The meaning of "a = b" )
3- math.m   ( Basic math operations )
4- equal_add.m  ( The meaning of "a = b", continued )
5- print.m      ( Formatted output )
6- formatted_output.m    ( Formatted output continued )
7- array.m              ( Simple addition of array )
8- individual_eL_add.m  ( Extracting an individual element of an array )
9- comment.m         ( The use of comment)
10- continuation.m   ( Continuation to next line )
11- intr_math_fun.m  ( Intrinsic math functions and constants )
12- nam_var.m        ( Naming a variable )
13- Plot a graph     ( for making a quick plot)

