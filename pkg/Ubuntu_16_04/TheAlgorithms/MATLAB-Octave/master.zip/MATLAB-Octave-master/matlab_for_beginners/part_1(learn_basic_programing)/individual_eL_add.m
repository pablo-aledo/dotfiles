%%Ex. 8 Extracting an individual element of an array


a = [3 6 7];
b = [1 9 4 5];
c = a(2) + b(4)


%Output:  c = 11