%%Ex. 7 Arrays


a = [3 6 7];
b = [1 9 4];
c = a + b


%Output:   4 15 11