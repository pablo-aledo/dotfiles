author - Puneet Prakash Arya
email  - puneetarya66@gmail.com
github - https://github.com/puneet-pr-arya




"MATLAB" is a programming platform designed specifically for engineers and scientists. 
The heart of MATLAB is the MATLAB language, a matrix-based language allowing the most natural expression of computational mathematics.


What can you do with MATLAB?

Using MATLAB, you can:

Analyze data
Develop algorithms
Create models and applications


Matlab Advantages

                 (.) Implement and test your algorithms easily
                 (.) Develop the computational codes easily
                 (.) Debug easily
                 (.) Use a large database of built in algorithms
                 (.) Process still images and create simulation videos easily
                 (.) Symbolic computation can be easily done
                 (.) Call external libraries 
                 (.) Perform extensive data analysis and visualization
                 (.) Develop application with graphics user interface


Who uses MATLAB?

Millions of engineers and scientists in industry and academia use MATLAB. 
You can use MATLAB for a range of applications, including deep learning and machine learning,
signal processing and communications, image and video processing, control systems, test and measurement, 
computational finance, and computational biology.


With these tutorials, i would like to give all of you a basic idea of matlab so that all of you got familiar with the platform
and can work on it in future.

Thank you and all the best.