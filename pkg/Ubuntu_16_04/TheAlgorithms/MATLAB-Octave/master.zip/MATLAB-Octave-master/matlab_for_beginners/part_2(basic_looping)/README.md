

This part-2 introduces the concept of loops in the matlab language.

For understanding the concept of looping just go through the programs one by one.
 After that u will be able to apply the loops.

1 - program1 -   ( Loop: Using for command )

2-  program2 -  ( For loop: Utility of the dummy index )


3 - program3 -   ( For loop: More on the dummy index)

4 - program4 -    (Treatment of array within a loop)

5 - program5 -     ( Double loop )


6 - program6 -     ( another double lopp )


7-  program7 -    ( More complicated use of loop and index )


8-  wh_loop  -     ( while loop )