%% Ex.3 For loop: More on the dummy index

sum1 = 0;
for k = 1:9
 sum1 = sum1+k;
end
sum1
%Output:
%         45
% Remark: this program performs the summation of 1+2+3+4+5+6+7+8+9 (= 45).