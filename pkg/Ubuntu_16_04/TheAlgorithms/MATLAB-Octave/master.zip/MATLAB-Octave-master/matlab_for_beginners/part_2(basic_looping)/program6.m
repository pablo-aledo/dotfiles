%% Ex. 6 Double loop

for n = 1:2
 for m = 1:3
 fprintf('n = %3u m = %3u \r', n, m)
 end
end


%Output:
% n = 1 m = 1
% n = 1 m = 2
% n = 1 m = 3
% n = 2 m = 1
% n = 2 m = 2
% n = 2 m = 3