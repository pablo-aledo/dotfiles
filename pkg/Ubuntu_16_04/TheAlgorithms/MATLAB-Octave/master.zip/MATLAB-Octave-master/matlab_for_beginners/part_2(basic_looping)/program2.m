%% Ex. 2 For loop: Utility of the dummy index

b = 3;
for k = 1:5
 b^k
end
%Output:
% 3
% 9
% 27
% 81
% 243

%Remark: The outputs are 3^1, 3^2, 3^3, 3^4, and 3^5. the value of "k" keeps changing as
% we go through the loop