%% Ex. 5 Double loop

sum1 = 0;
for n = 1:2
 for m = 1:3
 sum1 = sum1+n*m;
 end
end
sum1


%Output:
       18
% Remark: this program performs the summation of
% Sum1 = 1*1+1*2+1*3 +2*1+2*2+2*3 = 18