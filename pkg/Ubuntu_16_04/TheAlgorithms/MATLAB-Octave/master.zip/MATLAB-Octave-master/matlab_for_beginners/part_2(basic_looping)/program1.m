%% The for loop
%Ex. 1 Loop: Using for command
b = 3;
for k = 1:5
 b
end


%Output: 
%  3
%  3
%  3
%  3
%  3

%Remark: The blue-colored segment in lines 2-4 forms a "for-loop". The statement
% sandwiched between "for k = 1:5" and "end" is repeated 5 times, with the "k" index
% going from 1 to 5 step 1