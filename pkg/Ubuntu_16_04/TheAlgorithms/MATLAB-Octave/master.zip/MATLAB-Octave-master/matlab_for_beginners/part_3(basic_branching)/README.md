
This part-3 makes you familiar with the basic branching concept which basically means using 
loops,if, if else and basics of matlab.

Just go through the programs in the given sequence. All required Information about the question is given in the program itself.


1 -program1 - (The if command)


2- program2 - (if - elseif - else (This example is self-explanatory. Try to change the given value
                of num1 and observe the outcome.)

3- program3-  (An application - determine whether a given year is a leap year (try to change the
                given value of nyear and observe the outcome)


4- program4-  (Combine looping and branching)



Thank you...