%% Ex. 9 An efficient way to assign the content of an array


a = [0:0.5:4];
a

%Output:
%        a = 0 0.5 1 1.5 2 2.5 3 3.5 4