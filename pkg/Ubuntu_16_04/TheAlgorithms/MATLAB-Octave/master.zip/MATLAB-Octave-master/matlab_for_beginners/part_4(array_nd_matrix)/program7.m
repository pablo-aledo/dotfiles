%% Ex. 7 Elementary functions with a vectorial variable

a = [2 3 5];
b = sin(a)
% Output:
%        b = 0.9092 0.1411 -0.9589


%Remark: The content of b is [sin(2) sin(3) sin(5)].