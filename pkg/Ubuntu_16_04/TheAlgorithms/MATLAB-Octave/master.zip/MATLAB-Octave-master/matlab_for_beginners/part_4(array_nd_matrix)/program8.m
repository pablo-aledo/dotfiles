%% Ex. 8 Another example of elementary functions with a vectorial variable

a = [2 3 5];
b = 2*a.^2+3*a+4


%Output:
%        b = 18 31 69
%   Remark: The content of b is
%    b = [2*(a(1))^2+3*a(1)+4 2*(a(2))^2+3*a(2)+4 2*(a(3))^2+3*a(3)+4].