%% Ex. 3 Multiplication involving a scalar and an array (or a matrix)

a = [3 5; 1 4];
b = 2*a


%Output:
%  b = 6 10
%      2 8