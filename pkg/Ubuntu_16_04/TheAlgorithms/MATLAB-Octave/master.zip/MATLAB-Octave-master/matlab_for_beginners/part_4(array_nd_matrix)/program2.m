%% Ex. 2 Assign the content of a matrix; Addition of two matrices

a = [3 4; 1 6];
b = [5 2; 11 7];
c = a+b

%Output:
%     c = 8 6
%        12 13


