%% Ex. 5 Element-by-element multiplication of two matrices

a = [2 3; 1 4];
b = [5 1; 7 2];
c = a.*b


%Output:
%      c = 10 3
%           7 8