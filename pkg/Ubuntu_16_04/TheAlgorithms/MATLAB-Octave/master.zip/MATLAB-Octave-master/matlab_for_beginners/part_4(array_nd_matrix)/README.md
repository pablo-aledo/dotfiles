


This part-4 conatains array and matrix related problems.

All the programs are arranged in the order just to give you the proper understanding of the array and matrix.

Just Go through the programs.All the program's name and their work is specified inside the program itself.


1 -  program1 - ( Assign the content of an array/matrix; Basic operations )
                                                         

2 -  program2 -  ( Assign the content of a matrix; Addition of two matrices )

3 -  program3 -  ( Multiplication involving a scalar and an array (or a matrix )

4 -  program4 -  ( Element-by-element multiplication involving two 1-D arrays or two matrices of the same dimension )

5 -  program5 -  ( Element-by-element multiplication of two matrices )

6 -  program6 -  ( Direct (not element-by-element) multiplication of two matrices )

7 -  program7 -  ( Elementary functions with a vectorial variable )

8 -  program8 -  ( Another example of elementary functions with a vectorial variable )

9 -  program9 -  ( An efficient way to assign the content of an array )

10 - program10 - ( Extracting the individual element(s) of a matrix )

11 - program11 - ( Another example for the usage of index for a matrix )

12 - program12 - ( Solving a system of linear equation )

Thank You...