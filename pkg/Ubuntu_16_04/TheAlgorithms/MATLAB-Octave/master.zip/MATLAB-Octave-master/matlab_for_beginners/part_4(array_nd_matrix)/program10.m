%% Ex 10. Extracting the individual element(s) of a matrix


A = [3 5; 2 4];
c = A(2,2)+A(1,2)

%Output:
%     c= 9
%   Remark: With the given A matrix, we have A(1,1) = 3, A(1,2) = 5, A(2,1) = 2, and
%   A(2,2) = 4.