%% 1. Assign the content of an array/matrix; Basic operations


%Ex. 1 Assign the content of a (one-dimensional) array; Addition of two arrays


a = [2 12 25];
b = [3 7 4];
c = a+b
% Output:
 %      c = 5 19 29