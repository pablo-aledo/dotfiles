%% Ex.6 Direct (not element-by-element) multiplication of two matrices


a = [2 3; 1 4];
b = [5 1; 7 2];
c = a*b
% Output:
%        c = 31 8
 %           33 9

 
 %Remark: Observe how the outcome of this example differs from Ex. 32.