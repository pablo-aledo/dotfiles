result = max(pfz(600851475143));
save myResult.mat result
printf("The greates prime factor is %d\n",result)