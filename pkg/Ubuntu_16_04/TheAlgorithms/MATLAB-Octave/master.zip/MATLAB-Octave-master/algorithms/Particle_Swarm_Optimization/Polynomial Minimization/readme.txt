This Matlab code optimizes a polynomial by minimizing it within a given range using Particle Swarm optimization.
