function z = Parabola(x)
    z = sum(x.^2);
end