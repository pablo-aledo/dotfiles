function z= minone(x)
    z = sum(x.^2);
end