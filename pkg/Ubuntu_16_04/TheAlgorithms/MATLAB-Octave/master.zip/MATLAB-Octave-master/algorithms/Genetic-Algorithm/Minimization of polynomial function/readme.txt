this is a minimization agorithm for a single variable function using genetic algorithm
