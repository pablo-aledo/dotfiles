# List of all files

## Searches
  * [Linear Search](https://github.com/TheAlgorithms/OCaml/blob/master/searches/linear_search.ml)

## Sorts
  * [Quicksort](https://github.com/TheAlgorithms/OCaml/blob/master/Sorts/quicksort.ml)
