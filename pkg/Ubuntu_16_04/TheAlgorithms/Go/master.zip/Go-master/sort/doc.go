// Package sort a package for demonstrating sorting algorithms in Go
package sort
