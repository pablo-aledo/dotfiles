// Package hashing containing different implementation of certain hashing
package hashing
