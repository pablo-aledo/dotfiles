// Empty test file to keep track of all the tests for the algorithms.

package hashing
