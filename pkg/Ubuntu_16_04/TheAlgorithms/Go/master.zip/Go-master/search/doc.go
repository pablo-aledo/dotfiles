// Package search is a subpackage dedicated to all searching algorithms related to slices/arrays.
package search
