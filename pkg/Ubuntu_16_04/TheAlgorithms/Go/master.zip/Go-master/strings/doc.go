// Package strings is a package that contains all algorithms
// that are used to analyse and manipulate strings.
package strings
