// Package conversion is a package of implementations which converts one data structure to another.
package conversion
