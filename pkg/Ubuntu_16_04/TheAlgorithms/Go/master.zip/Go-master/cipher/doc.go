// Package cipher is a package containing different implementations of certain ciphers
package cipher
