// Package graph demonstrates Graph search algorithms
// reference: https://en.wikipedia.org/wiki/Tree_traversal
package graph
