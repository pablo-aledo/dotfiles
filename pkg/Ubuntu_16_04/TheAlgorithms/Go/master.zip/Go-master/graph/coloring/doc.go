// Package coloring provides implementation of different graph coloring
// algorithms, e.g. coloring using BFS, using Backtracking, using greedy
// approach.
// Author(s): [Shivam](https://github.com/Shivam010)
package coloring
