// Package math is a package that contains mathematical algorithms and its different implementations.
package math
