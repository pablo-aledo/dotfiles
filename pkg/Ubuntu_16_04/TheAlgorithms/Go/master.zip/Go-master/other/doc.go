// Package other is dedicated to algorithms that
// do not quite fit into any of the other subpackages in this repository.
package other
