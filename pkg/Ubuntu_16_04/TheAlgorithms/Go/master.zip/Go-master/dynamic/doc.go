// Package dynamic is a package of certain implementations of dynamically run algorithms.
package dynamic
