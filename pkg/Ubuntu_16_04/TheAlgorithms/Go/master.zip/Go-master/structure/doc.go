// Package structure is a subpackage that is dedicated to
// different implementations of data structures in the
// domain of computer science.
package structure
