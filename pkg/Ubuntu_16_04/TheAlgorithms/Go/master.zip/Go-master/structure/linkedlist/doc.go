// Package linkedlist demonstrates different implementations on linkedlists.
package linkedlist
