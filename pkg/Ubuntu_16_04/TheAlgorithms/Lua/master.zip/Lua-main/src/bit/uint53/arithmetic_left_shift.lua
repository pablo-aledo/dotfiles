-- Arithmetic left shift: Same as logical left shift
return require("bit.uint53.logical_left_shift")
