return function(
	x -- number
)
	if x < 0 then
		return -x
	end
	return x
end
