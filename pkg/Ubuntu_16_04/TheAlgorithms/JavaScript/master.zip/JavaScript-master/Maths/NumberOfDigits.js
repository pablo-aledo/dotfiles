/**
 *
 * Author: dephraiim
 * License: GPL-3.0 or later
 *
 * Returns the number of digits of a given integer
 *
 */

const numberOfDigit = (n) => Math.abs(n).toString().length

export { numberOfDigit }
