abs_value(number) {
  return number < 0 ? -number : number;
}

void main() {
  print(abs_value(-34));
}
