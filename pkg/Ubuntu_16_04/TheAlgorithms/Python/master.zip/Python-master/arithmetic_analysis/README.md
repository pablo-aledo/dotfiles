# Arithmetic analysis

Arithmetic analysis is a branch of mathematics that deals with solving linear equations.

* <https://en.wikipedia.org/wiki/System_of_linear_equations>
* <https://en.wikipedia.org/wiki/Gaussian_elimination>
* <https://en.wikipedia.org/wiki/Root-finding_algorithms>
