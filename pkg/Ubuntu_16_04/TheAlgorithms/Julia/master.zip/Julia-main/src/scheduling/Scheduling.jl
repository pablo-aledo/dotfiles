export Scheduling
"""
  Scheduling

`Scheduling` algorithms in Julia.
"""
module Scheduling

using TheAlgorithms

export fcfs

include("fcfs.jl")

end
