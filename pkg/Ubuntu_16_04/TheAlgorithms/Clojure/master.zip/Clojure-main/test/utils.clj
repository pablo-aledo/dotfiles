(ns utils)

(defn random-number-seq
  [size]
  (shuffle (range size)))
