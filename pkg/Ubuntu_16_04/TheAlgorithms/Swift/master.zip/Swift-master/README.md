# The Algorithms - Swift

### All algorithms implemented in Swift (for education)

These implementations are for learning purposes. They may be less efficient than the implementations in the Swift standard library.

## Community Channel

We're on [Gitter](https://gitter.im/TheAlgorithms)! Please join us.

## List of Algorithms

See our [directory](DIRECTORY.md).
