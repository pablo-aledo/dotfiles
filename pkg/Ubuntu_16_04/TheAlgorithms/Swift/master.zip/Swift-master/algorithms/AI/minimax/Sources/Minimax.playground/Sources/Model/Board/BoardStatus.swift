public enum BoardStatus {

    case continues

    case win

    case draw
}
