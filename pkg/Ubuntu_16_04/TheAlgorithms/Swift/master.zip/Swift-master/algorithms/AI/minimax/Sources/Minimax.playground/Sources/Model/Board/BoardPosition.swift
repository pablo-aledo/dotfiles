public typealias Position = (row: Int, column: Int)
