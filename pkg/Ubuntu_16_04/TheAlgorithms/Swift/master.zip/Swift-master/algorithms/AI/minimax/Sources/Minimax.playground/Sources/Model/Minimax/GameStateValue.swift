public enum GameStateValue: Int {

    case min = -1

    case null = 0

    case max = 1
}
