public enum DifficultLevel: Int {

    case easy = 2

    case medium = 3

    case hard = 5
}
