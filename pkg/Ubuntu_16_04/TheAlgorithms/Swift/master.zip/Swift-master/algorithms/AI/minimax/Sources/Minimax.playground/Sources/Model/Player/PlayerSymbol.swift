public enum PlayerSymbol: String {

    case empty = ""

    case circle = "⭕️"

    case cross = "❌"
}
