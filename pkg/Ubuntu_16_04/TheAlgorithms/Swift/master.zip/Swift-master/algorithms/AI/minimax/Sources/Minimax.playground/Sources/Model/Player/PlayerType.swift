public enum PlayerType {

    case computer

    case human
}
