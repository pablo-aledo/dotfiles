# List of all files

## Src
  * [Main](https://github.com/TheAlgorithms/Elm/blob/master/src/Main.elm)
  * Sorting
    * [Bubblesort](https://github.com/TheAlgorithms/Elm/blob/master/src/Sorting/BubbleSort.elm)
    * [Insertionsort](https://github.com/TheAlgorithms/Elm/blob/master/src/Sorting/InsertionSort.elm)
    * [Mergesort](https://github.com/TheAlgorithms/Elm/blob/master/src/Sorting/MergeSort.elm)
    * [Selectionsort](https://github.com/TheAlgorithms/Elm/blob/master/src/Sorting/SelectionSort.elm)
  * Structures
    * [Binarytree](https://github.com/TheAlgorithms/Elm/blob/master/src/Structures/BinaryTree.elm)
  * [Util](https://github.com/TheAlgorithms/Elm/blob/master/src/Util.elm)
