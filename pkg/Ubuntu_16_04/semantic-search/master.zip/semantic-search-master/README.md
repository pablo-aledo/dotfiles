# How to build a Semantic Search Engine in Rust

Accompanying source code for the article https://sachaarbonel.medium.com/how-to-build-a-semantic-search-engine-in-rust-e96e6378cfd9

## Getting Started

### M1
`cargo run --target x86_64-apple-darwin`

### Intel
`cargo run`
