#pragma once

//-----------------------------------------------------------------------------
// System includes
//-----------------------------------------------------------------------------
#pragma region

// Targetting the highest available Windows platform.
#include <SDKDDKVer.h>

#pragma endregion