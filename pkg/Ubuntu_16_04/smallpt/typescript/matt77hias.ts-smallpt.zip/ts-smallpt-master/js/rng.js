function uniform_float() {
    return Math.random();
}
