function uniform_float(): number {
    return Math.random();
}