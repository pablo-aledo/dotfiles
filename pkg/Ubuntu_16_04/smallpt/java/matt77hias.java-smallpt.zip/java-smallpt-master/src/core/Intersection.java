package core;

public class Intersection {
	public int id;
	
	public Intersection() {
		this.id = 0;
	}
}