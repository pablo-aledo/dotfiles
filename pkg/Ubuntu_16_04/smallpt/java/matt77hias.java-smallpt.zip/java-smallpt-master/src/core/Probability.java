package core;

public class Probability {

	public double pr;
	
	public Probability() {
		this.pr = 0.0;
	}
}
