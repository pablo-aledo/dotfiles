from prompt import Prompt
from reactengineer import ReactEngineer

if __name__ == "__main__":
	prompt = Prompt()
	react_engineer = ReactEngineer(prompt)
	react_engineer.run()