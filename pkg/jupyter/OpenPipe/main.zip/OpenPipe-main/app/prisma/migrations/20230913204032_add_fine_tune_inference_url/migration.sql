-- AlterTable
ALTER TABLE "FineTune" ADD COLUMN     "inferenceUrl" TEXT;
