-- AlterTable
ALTER TABLE "User" ADD COLUMN     "gitHubUsername" TEXT;
