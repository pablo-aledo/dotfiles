-- AlterTable
ALTER TABLE "FineTune" ADD COLUMN     "numTrainingAutoretries" INTEGER NOT NULL DEFAULT 0;
