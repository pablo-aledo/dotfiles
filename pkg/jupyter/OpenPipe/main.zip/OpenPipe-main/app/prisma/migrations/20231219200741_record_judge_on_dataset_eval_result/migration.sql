-- AlterTable
ALTER TABLE "DatasetEvalResult" ADD COLUMN     "judge" TEXT;
