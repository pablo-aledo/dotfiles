-- AlterTable
ALTER TABLE "DatasetEvalResult" ADD COLUMN     "wasFirst" BOOLEAN;
