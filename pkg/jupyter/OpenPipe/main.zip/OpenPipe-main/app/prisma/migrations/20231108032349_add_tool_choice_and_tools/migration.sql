-- AlterTable
ALTER TABLE "DatasetEntry" ADD COLUMN     "tool_choice" JSONB,
ADD COLUMN     "tools" JSONB;
