-- AlterTable
ALTER TABLE "FineTune" ADD COLUMN     "gpt4FallbackEnabled" BOOLEAN NOT NULL DEFAULT false;
