-- AlterTable
ALTER TABLE "User" ADD COLUMN     "lastViewedProjectId" UUID;
