-- AlterTable
ALTER TABLE "DatasetEntry" ALTER COLUMN "inputTokens" DROP NOT NULL,
ALTER COLUMN "outputTokens" DROP NOT NULL;
