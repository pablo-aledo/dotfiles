-- AlterTable
ALTER TABLE "FineTuneTestingEntry" ADD COLUMN     "finishReason" TEXT;
