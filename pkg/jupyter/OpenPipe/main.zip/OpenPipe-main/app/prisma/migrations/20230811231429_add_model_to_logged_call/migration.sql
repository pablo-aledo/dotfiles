-- AlterTable
ALTER TABLE "LoggedCall" ADD COLUMN     "model" TEXT;
