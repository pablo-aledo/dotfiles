-- AlterTable
ALTER TABLE "FineTuneTestingEntry" ADD COLUMN     "score" DOUBLE PRECISION;
