-- AlterTable
ALTER TABLE "ModelOutput" ADD COLUMN     "timeToComplete" INTEGER NOT NULL DEFAULT 0;
