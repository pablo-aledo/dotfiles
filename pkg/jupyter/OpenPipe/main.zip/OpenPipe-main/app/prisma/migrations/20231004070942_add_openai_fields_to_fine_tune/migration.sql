-- AlterTable
ALTER TABLE "FineTune" ADD COLUMN     "openaiModelId" TEXT,
ADD COLUMN     "openaiTrainingJobId" TEXT;
