-- AlterTable
ALTER TABLE "DatasetEntry" ADD COLUMN     "response_format" JSONB;
