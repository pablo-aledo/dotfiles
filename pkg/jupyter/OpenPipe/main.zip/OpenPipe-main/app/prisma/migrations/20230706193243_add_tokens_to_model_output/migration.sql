-- AlterTable
ALTER TABLE "ModelOutput" ADD COLUMN     "completionTokens" INTEGER,
ADD COLUMN     "promptTokens" INTEGER;
