import { configDotenv } from "dotenv";

configDotenv({
  path: ".env.test",
});
