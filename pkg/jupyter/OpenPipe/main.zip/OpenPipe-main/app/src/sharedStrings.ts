export const rateLimitErrorMessage = "429 - Rate limit exceeded.";
