/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TSOutput = {
  status: "running" | "done" | "error";
  error?: string;
};
