/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Choice } from "./Choice";
import type { Usage } from "./Usage";
export type Output = {
  id: string;
  choices: Array<Choice>;
  usage: Usage;
};
