/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Input = {
  base_model: string;
  lora_model: string;
  prompt: string;
  n?: number;
  max_tokens?: number;
  temperature?: number;
};
