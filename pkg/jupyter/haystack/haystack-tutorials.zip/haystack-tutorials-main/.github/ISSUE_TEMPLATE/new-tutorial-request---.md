---
name: "New Tutorial Request \U0001F4D3"
about: Suggest a new tutorial for this repository
title: 'New tutorial for: '
labels: new tutorial
assignees: ''

---

**Describe the tutorial you would like to see here**
A clear and concise description of what the problem is. Ex. I'd like to see a tutorial about [...]

**Additional context**
Add any other context or screenshots about the feature request here.

[ ] I've checked the existing tutorials
