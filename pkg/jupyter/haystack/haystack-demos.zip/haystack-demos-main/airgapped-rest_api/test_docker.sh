curl --request POST --url http://0.0.0.0:8000/query \
     --header 'accept: application/json' \
     --header 'content-type: application/json' \
     --data '{"query": "what is my name"}'
