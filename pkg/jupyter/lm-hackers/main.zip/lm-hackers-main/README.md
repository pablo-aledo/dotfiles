# A Hackers' Guide to Language Models

This material is to accompany the video [A Hackers' Guide to Language Models](https://youtu.be/jkrNMKz9pWU). The notebook from the video is [lm-hackers.ipynb](lm-hackers.ipynb). The other files are for axolotl fine-tuning.
