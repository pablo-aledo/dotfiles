+++
title = "Pages"
sort_by = "date"
template = "blog.html"
page_template = "blog-page.html"

[extra]
class_name = "page"
+++