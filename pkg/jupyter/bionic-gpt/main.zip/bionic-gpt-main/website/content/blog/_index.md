+++
title = "Blog Posts"
sort_by = "date"
template = "blog.html"
page_template = "blog-page.html"

[extra]
class_name = "blog"
+++