pub mod delete;
pub mod form;
pub mod index;
pub mod model_table;
pub mod model_type;
pub mod top_users_table;

pub use index::index;
