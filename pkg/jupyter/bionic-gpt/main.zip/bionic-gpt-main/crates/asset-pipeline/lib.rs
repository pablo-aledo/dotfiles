include!(concat!(env!("OUT_DIR"), "/templates.rs"));

pub use templates::statics as files;
