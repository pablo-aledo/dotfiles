#include "Core/Core.h"

int main()
{
	Core::PrintHelloWorld();
}