#pragma once

namespace Core {

	void PrintHelloWorld();

}