echo "Enable ufw firewall"
source ~/.local/share/omarchy/install/development/firewall.sh
