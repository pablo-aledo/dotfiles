echo "Update .config/hypr/hyprlock.conf to include failed attempt counter"
omarchy-refresh-hyprlock
