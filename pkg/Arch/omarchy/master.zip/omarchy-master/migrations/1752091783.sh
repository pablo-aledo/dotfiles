echo "Install Plymouth splash screen"
source "$HOME/.local/share/omarchy/install/config/login.sh"
