echo "Permanently fix F-keys on Apple-mode keyboards (like Lofree Flow84)"
source ~/.local/share/omarchy/install/config/fix-fkeys.sh
