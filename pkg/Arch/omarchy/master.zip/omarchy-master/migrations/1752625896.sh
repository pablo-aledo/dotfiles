echo "Copy desktop file for new Omarchy TUI"
cp ~/.local/share/omarchy/applications/omarchy.desktop ~/.local/share/applications/
