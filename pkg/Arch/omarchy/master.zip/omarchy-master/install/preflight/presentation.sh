#!/bin/bash

yay -S --noconfirm --needed gum python-terminaltexteffects
