return {
  { "tahayvr/matteblack.nvim", lazy = false, priority = 1000 },
  {
		"LazyVim/LazyVim",
		opts = {
			colorscheme = "matteblack",
		},
	},
}