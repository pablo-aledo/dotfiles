Welcome to the ChatGPT wiki!

- [Installation and setup](https://github.com/acheong08/ChatGPT/wiki/Setup)
- [CLI usage](https://github.com/acheong08/ChatGPT/wiki/CLI-use)
- [Developing with ChatGPT](https://github.com/acheong08/ChatGPT/wiki/Developer-Docs)
- [Contributing](https://github.com/acheong08/ChatGPT/wiki/Contributors)

WIP. Please add more docs