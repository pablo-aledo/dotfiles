#define {= uc_name =}_IMPLEMENTATION
#include "{= name =}/{= name =}.h"
