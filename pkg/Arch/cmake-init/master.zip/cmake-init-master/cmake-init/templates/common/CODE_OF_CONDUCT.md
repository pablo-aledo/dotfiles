# Code of Conduct

* You will be judged by your contributions first, and your sense of humor
  second.
* Nobody owes you anything.
