auto main() -> int
{
  return 0;
}
