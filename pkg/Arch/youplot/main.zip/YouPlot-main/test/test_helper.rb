# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require 'youplot'

require 'test/unit'
