# frozen_string_literal: true

module YouPlot
  VERSION = '0.4.5'
end
