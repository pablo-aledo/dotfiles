# <small>nlohmann::adl_serializer::</small>from_json

```cpp
// (1)
template<typename BasicJsonType, typename TargetType = ValueType>
static auto from_json(BasicJsonType && j, TargetType& val) noexcept(
    noexcept(::nlohmann::from_json(std::forward<BasicJsonType>(j), val)))
-> decltype(::nlohmann::from_json(std::forward<BasicJsonType>(j), val), void())

// (2)
template<typename BasicJsonType, typename TargetType = ValueType>
static auto from_json(BasicJsonType && j) noexcept(
noexcept(::nlohmann::from_json(std::forward<BasicJsonType>(j), detail::identity_tag<TargetType> {})))
-> decltype(::nlohmann::from_json(std::forward<BasicJsonType>(j), detail::identity_tag<TargetType> {}))
```

This function is usually called by the [`get()`](../basic_json/get.md) function of the
[basic_json](../basic_json) class (either explicit or via conversion operators).

1. This function is chosen for default-constructible value types.
2. This function is chosen for value types which are not default-constructible.

## Parameters

`j` (in)
:   JSON value to read from

`val` (out)
:   value to write to

## Return value

Copy of the JSON value, converted to `ValueType`

!!! note

    This documentation page is a stub.

## Version history

- Added in version 2.1.0.
