#include <iostream>

#include "my_lib.h"

int main()
{
    print_hello_world();

    return 0;
}
