# CMake, Testing and Tooling for C/C++

This is the code to my Udemy course:  
*CMake, Testing and Tooling for C/C++* by Jan Schaffranek.
