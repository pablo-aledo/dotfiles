#!/usr/bin/env bash

echo 'Ubuntu clang-format version 3.2.0-1~exp1 (trunk) (based on LLVM 3.2.0)'
