#!/bin/bash
\vim -E -c "CheatPager! $@" -c q
